# Mapa de campos de Spec en Jira (sección ↔ campo)

> **Este archivo es el contrato entre Jira y las skills** (ADR-004). Las skills leen
> de aquí qué campos traer y **en qué orden** reconstruir el documento. Si un campo se
> crea, renombra o parte en dos y este archivo no se actualiza en el mismo MR, el
> snapshot sale incompleto. Dueño editorial: **Arquitecto**; cambia por MR.

## Reglas

1. **Un campo por sección** de la plantilla; una sección larga se parte en sub-campos
   y la skill los concatena bajo su encabezado (ver §5 de la Funcional).
2. **El `id` manda, no el nombre.** Los nombres visibles se pueden renombrar en Jira;
   los ids (`customfield_XXXXX`) no cambian. Las skills usan el id.
3. **Nombres prefijados `Spec · …`** y **contexto acotado** al tipo `#Spec` y a los
   proyectos donde viven las Specs — para no aparecer en formularios ajenos.
4. Tipo de campo: **texto multilínea con formato** (párrafo enriquecido), salvo donde
   se indique otra cosa.
5. **La descripción del issue no es contenedor:** queda como *resumen ejecutivo*
   (objetivo en una frase + enlaces). El contenido de la Spec vive en estos campos.
6. Verificar el **límite de caracteres por campo** con el admin y anotarlo en la
   columna correspondiente. Si una sección lo roza, se parte — no se resume.

---

## Spec de Proyecto (`PROJ`) — plantilla `plantilla-spec-proyecto.md`

| # | Sección de la plantilla | Campo en Jira | id | Límite |
|---|---|---|---|---|
| 1 | Resumen y Contexto | `Spec · Resumen y contexto` | `<customfield_XXXXX>` | `<n>` |
| 2 | Usuarios, Áreas y Responsables | `Spec · Usuarios y áreas` | `<customfield_XXXXX>` | `<n>` |
| 3 | Alcance y Consideraciones Iniciales | `Spec · Alcance y consideraciones` | `<customfield_XXXXX>` | `<n>` |
| 4 | Definiciones y Restricciones Transversales | `Spec · Definiciones transversales` | `<customfield_XXXXX>` | `<n>` |
| 5 | Backlog de Specs Funcionales | `Spec · Backlog de specs` | `<customfield_XXXXX>` | `<n>` |
| 6 | Referencias | `Spec · Referencias` | `<customfield_XXXXX>` | `<n>` |

*Definición de Terminado: checklist del gate — vive en el workflow, no en un campo.*

---

## Spec Funcional — plantilla `plantilla-spec-funcional.md`

| # | Sección de la plantilla | Campo en Jira | id | Límite |
|---|---|---|---|---|
| — | Encabezado (Spec UX asociada · Spec de Proyecto) | enlaces y jerarquía nativos de Jira | — | — |
| 1 | Resumen y Contexto | `Spec · Resumen y contexto` | `<customfield_XXXXX>` | `<n>` |
| 2 | Usuarios y Responsables | `Spec · Usuarios y responsables` | `<customfield_XXXXX>` | `<n>` |
| 3 | Alcance y Consideraciones Iniciales | `Spec · Alcance y consideraciones` | `<customfield_XXXXX>` | `<n>` |
| 4 | Flujo y Comportamiento Esperado | `Spec · Flujo y comportamiento` | `<customfield_XXXXX>` | `<n>` |
| 5a | Requisitos funcionales (`RF-*`) | `Spec · Requisitos funcionales` | `<customfield_XXXXX>` | `<n>` |
| 5b | Reglas de negocio (`RN-*`) | `Spec · Reglas de negocio` | `<customfield_XXXXX>` | `<n>` |
| 5c | Datos y validaciones (`DAT-*`) | `Spec · Datos y validaciones` | `<customfield_XXXXX>` | `<n>` |
| 5d | Permisos (`PER-*`) | `Spec · Permisos` | `<customfield_XXXXX>` | `<n>` |
| 6 | Criterios de Aceptación (`AC-*`) | `Spec · Criterios de aceptación` | `<customfield_XXXXX>` | `<n>` |
| 7 | Requisitos No Funcionales | `Spec · Requisitos no funcionales` | `<customfield_XXXXX>` | `<n>` |
| 8 | Impactos, Restricciones y Referencias | `Spec · Impactos y referencias` | `<customfield_XXXXX>` | `<n>` |
| 9 | Pendientes de Definición | `Spec · Pendientes de definición` | `<customfield_XXXXX>` | `<n>` |

**§5 se parte en cuatro** (5a–5d): son las secciones más largas y las más consultadas
por separado. Al reconstruir, la skill las une bajo el encabezado
`## ⚙️ 5. Requisitos y Reglas de Negocio` con sus subtítulos originales.

---

## Spec UX/UI — plantilla `plantilla-spec-ux.md`

| # | Sección de la plantilla | Campo en Jira | id | Límite |
|---|---|---|---|---|
| — | Encabezado (Spec Funcional · Spec de Proyecto) | enlaces y jerarquía nativos | — | — |
| 1 | Intención de Experiencia | `Spec UX · Intención de experiencia` | `<customfield_XXXXX>` | `<n>` |
| 2 | Flujo de Experiencia TO-BE (`UX-FLU`) | `Spec UX · Flujo TO-BE` | `<customfield_XXXXX>` | `<n>` |
| 3 | Inventario de Pantallas (`UX-VIEW`) | `Spec UX · Inventario de vistas` | `<customfield_XXXXX>` | `<n>` |
| 4 | Estructura y Jerarquía | `Spec UX · Estructura y jerarquía` | `<customfield_XXXXX>` | `<n>` |
| 5 | Componentes y Design System (`UX-COMP`, `UX-NEW`) | `Spec UX · Componentes y DS` | `<customfield_XXXXX>` | `<n>` |
| 6 | Interacciones (`UX-INT`) | `Spec UX · Interacciones` | `<customfield_XXXXX>` | `<n>` |
| 7 | Estados de la Experiencia (`UX-STATE`) | `Spec UX · Estados` | `<customfield_XXXXX>` | `<n>` |
| 8 | Formularios y Validaciones Visuales (`UX-DAT`) | `Spec UX · Formularios y validaciones` | `<customfield_XXXXX>` | `<n>` |
| 9 | Textos de Interfaz (`UX-MSG`, `UX-TXT`) | `Spec UX · Textos de interfaz` | `<customfield_XXXXX>` | `<n>` |
| 10 | Responsive, Dispositivos y Accesibilidad | `Spec UX · Responsive y accesibilidad` | `<customfield_XXXXX>` | `<n>` |
| 11 | Transiciones y Animaciones (`UX-MOTION`) | `Spec UX · Motion` | `<customfield_XXXXX>` | `<n>` |
| 12 | Restricciones UX/UI (`UX-RES`) | `Spec UX · Restricciones` | `<customfield_XXXXX>` | `<n>` |
| 13 | Referencias | `Spec UX · Referencias` | `<customfield_XXXXX>` | `<n>` |
| 14 | Pendientes de Definición | `Spec UX · Pendientes de definición` | `<customfield_XXXXX>` | `<n>` |

*Los campos `Spec UX · …` son propios del tipo UX; no se comparten con los de la
Funcional aunque el nombre se parezca — el significado es distinto y mezclarlos haría
imposible consultar unos sin los otros.*

---

## Cómo lo usan las skills

`inicio-tarea` lee este mapa, trae **solo** los campos listados para el tipo de Spec que
corresponda, los ordena por `#` y reconstruye el documento con los encabezados de la
plantilla. Campo vacío = sección ausente en el snapshot, con una línea explícita
`> [sección sin contenido en el issue]` para que se vea la falta en lugar de esconderla.

El **hash** que guarda el snapshot (`campos_hash`) se calcula sobre los valores en ese
mismo orden, así que dos snapshots del mismo issue sin cambios dan el mismo hash — y
cualquier edición de contenido lo cambia. Comentarios, etiquetas y transiciones de
estado **no** lo alteran.

---
*Dueño: Arquitecto · cambia por MR · ADR-004.*
