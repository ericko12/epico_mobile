# Estándares de API (contratos HTTP y eventos)

> Los usa la skill `contrato-api` al redactar todo `openapi.json`, y el Arquitecto como
> checklist de aprobación. Si un contrato existente viola algo de aquí, **no se corrige
> rompiendo**: se documenta la excepción y se alinea en la siguiente versión.

## Formato del contrato
- OpenAPI 3.x serializado en **JSON** (`contracts/openapi.json`), porque así lo
  exponen los servicios .NET 10. Se redacta a mano y se **congela antes de
  construir** — el modelo sigue siendo contract-first, solo cambió la sintaxis
  (antes YAML).
- El servicio .NET 10 expone su propio documento en runtime (`/openapi/v1.json`, vía
  el paquete nativo `Microsoft.AspNetCore.OpenApi`). Ese documento **no es una fuente
  alterna del contrato**: el CI lo compara contra `contracts/openapi.json` ya en
  Desarrollo para detectar si el código derivó — si difieren, se corrige el código,
  nunca el contrato congelado.

## Rutas y verbos
- Recursos en español, plural, kebab-case: `/actividades`, `/solicitudes-credito`.
- Versión en la ruta: `/v1/...`. Los cambios dentro de una versión son **aditivos**.
- Verbos: `GET` consulta · `POST` crea o ejecuta una acción (`/{id}/check-in`) ·
  `PUT/PATCH` actualiza · nunca verbos en la ruta salvo acciones de dominio con `POST`.

## Respuestas y errores
- Errores con cuerpo estándar: `{ "codigo": "RN-03", "mensaje": "<texto para el usuario>", "detalle": {...} }`.
- Códigos: `400` petición malformada · `401/403` auth · `404` no existe · `409` conflicto
  de estado (p. ej. RN-02) · `422` regla de negocio (p. ej. RN-03).
- **El mensaje de una regla de negocio sale de la Spec Funcional** (sus AC/EX) — el
  mismo texto que aprobó el equipo. Si la Spec UX define el `UX-MSG` correspondiente,
  debe coincidir; una discrepancia es un `[NEEDS CLARIFICATION]`, no una elección.
- Si un servicio compartido implementa reglas de **varias** specs, prefija el código
  con el folio para mantenerlo único: `SPEC-1.RN-02`.

## Datos
- Fechas/horas en ISO-8601 **UTC** (`2026-09-15T14:30:00Z`); la zona la resuelve el front.
- Ids opacos (no expongas ids internos de BD si existe alternativa).
- Paginación: `?page=&limit=` con `meta: { total, page, limit }` en la respuesta.
- Campos en camelCase en el JSON; nada de abreviaturas crípticas.

## Idempotencia y estado
- Toda acción que registra algo (check-in, crear solicitud) es **idempotente** por clave
  natural (actividad+operación) — reintentos de red no duplican.
- Los estados válidos y sus transiciones vienen de la Spec; el servicio los aplica, el
  front solo los refleja.

## Eventos (RabbitMQ)
- Naming: `<contexto>.<entidad>.<accion>` en pasado: `actividad.checkin.registrado`.
- Schema versionado dentro del contrato del productor; cambios **aditivos**; breaking →
  evento `v2` conviviendo con `v1` hasta migrar consumidores.
- Todo evento nuevo se registra en `CATALOGO_SERVICIOS.md` en el mismo MR.

## Checklist de aprobación del Arquitecto
- [ ] ¿El servicio es compartido? → ¿el cambio es 100% aditivo?
- [ ] Errores de reglas con su código `RN-*` y el mensaje de la Spec
- [ ] Idempotencia definida para toda escritura
- [ ] Ejemplos (`examples`) en cada operación — de ahí salen los mocks del front
- [ ] Eventos registrados en el catálogo
