# Enlace issue ↔ página: cómo encuentra la skill la Spec en Confluence

> **Este archivo es el contrato entre Jira, Confluence y las skills** (ADR-005). Aquí
> está la regla con la que `inicio-tarea` pasa de una **clave de issue** (`EF-50620`) a
> **la página** que contiene la Spec, qué verifica antes de congelarla y cómo calcula el
> hash de deriva. Dueño editorial: **Arquitecto**; cambia por MR. Los valores del
> proyecto (sitio, espacio, ids) no van aquí: van en la línea `Confluence:` del
> `CLAUDE.md` de cada repo de código.

## 1 · Dónde vive cada cosa

| Cosa | Jira | Confluence |
|---|---|---|
| Spec de Proyecto | issue **`#Release`** del proyecto (nivel 2) — p. ej. `EF-50612` | página `00_SPEC_PROYECTO_<slug>` (plantilla `plantilla-spec-proyecto.md`), folio `PROJ-SPEC-<xxxx>-<nnn>` |
| Spec Funcional | issue **`#Partial release (Spec)`** (nivel 1), hijo del `#Release` — p. ej. `EF-50620`. **Su clave es la identidad** de la Spec | página `SPEC-F<fase>-<nnn>_<slug>` (plantilla `plantilla-spec-funcional.md`), hija de la de Proyecto |
| Spec UX/UI | **sin issue propio** — hereda la clave de la funcional (sus tareas son `#Task` bajo la `#Historia de Spec` de front) | página `UX-SPEC-F<fase>-<nnn>_<slug>` (plantilla `plantilla-spec-ux.md`), hermana de la funcional |
| Trabajo | `#Historia de Spec` (nivel 0) y `#Task` (subtareas) bajo la Spec | — |
| Bitácoras | comentarios del issue de la Spec | — |
| Complementos del BA | — | páginas «Reglas de negocio …» y «Decisiones pendientes» que citan el folio |

En el equipo al `#Partial release (Spec)` se le dice **«la Spec»** o `#Spec`. Las skills
lo reconocen porque el **nombre del tipo contiene «Spec»**; el nombre exacto se declara
en el `CLAUDE.md` del repo (`Tipo de issue de la Spec:`), por si otro proyecto lo llama
distinto.

**Estados del issue** (workflow observado): `Backlog → Discovery → Definition →
Development → …` (+ `Pause`, `Canceled`). **Estado de la página** (cabecera
`Estado:`): `Borrador → Ready for Dev`. El gate del contenido es el de la **página**;
el del flujo es el del **issue** — la skill exige ambos (§4).

## 2 · Cabecera de la página — de ahí salen las referencias

Toda página de Spec abre con una lista numerada; la skill la lee tal cual:

```
1. Spec Funcional: SPEC-F2-002                 ← folio de esta página
2. Spec UX/UI asociada: UX-SPEC-F2-002         ← con esto se resuelve la página UX
3. Spec de Proyecto / Iniciativa: PROJ-SPEC-SFEP-001
4. Responsable BA: <nombre>
5. Versión: 0.2
6. Última actualización: 04-09-2026
7. Estado: Borrador | Ready for Dev            ← el gate del contenido
```

(La UX trae `Spec UX/UI:` y `Spec Funcional:`; la de Proyecto, `Spec de Proyecto:` y
`Responsable PO:`.) **Recomendado:** agregar la fila `Issue Jira: EF-50620` como
**enlace inteligente** al issue — Jira crea solo el enlace remoto (§3, vía 1) y la
página queda visible en el panel del issue.

## 3 · Regla de resolución: de la clave a la página (en este orden)

`inicio-tarea` prueba cada vía y **se detiene en la primera que devuelve exactamente
una página**. Registra cuál usó en el front matter (`resuelto_por:`).

| # | Vía | Cómo | `resuelto_por` |
|---|---|---|---|
| 1 | **Enlace remoto** del issue a Confluence | Enlaces remotos del issue cuya URL contenga `/wiki/`. Si hay varios, se queda con el que su título empiece por `SPEC-` (no `UX-SPEC-`); si aún hay más de uno, **pregunta** | `enlace-remoto` |
| 2 | **Folio en el título o descripción** del issue | Patrón `\bSPEC-F\d+-\d{3}\b` (sin `UX-` delante) → CQL `space = <PE> AND type = page AND title ~ "<folio>*"` | `folio-en-titulo` |
| 3 | **La página menciona la clave** | CQL `space = <PE> AND type = page AND text ~ "<CLAVE>"`, descartando páginas cuyo título empiece por `UX-SPEC-` o `00_SPEC_PROYECTO` | `mencion-en-pagina` |
| 4 | **Manual** | La skill pide la URL o el id de la página, continúa, y deja en el resumen final la instrucción de enlazar la página al issue | `manual` |

Cero páginas en todas las vías = **la Spec no es construible**: la skill lo reporta y
no inventa. Más de una página en una vía = pregunta, no elige.

**Página UX:** de la cabecera de la funcional (`Spec UX/UI asociada: UX-SPEC-F2-002`)
→ CQL `title ~ "UX-SPEC-F2-002*"` (`resuelto_por: cabecera-funcional`). `N/A`, vacío o
«sin UX» = la Spec no tiene experiencia; la skill lo anota y sigue.

**Página de Proyecto:** el id declarado en el `CLAUDE.md` del repo
(`Spec de Proyecto: página <id>` → `resuelto_por: claude-md`); si no está, CQL
`title ~ "00_SPEC_PROYECTO*"` cuyo texto contenga el folio `PROJ-SPEC-…` de la cabecera
(`resuelto_por: titulo-proyecto`).

**Páginas complementarias:** CQL `space = <PE> AND type = page AND text ~ "<folio>" AND
(title ~ "Reglas de negocio*" OR title ~ "Decisiones pendientes*")`. La skill las lista
y **el humano confirma** cuáles van como anexos del snapshot.

> Nota de CQL: el guion bajo **no** separa palabras (`title ~ "PROYECTO"` no encuentra
> `00_SPEC_PROYECTO_…`); usar el prefijo completo con comodín, como arriba.

## 4 · Qué verifica la skill antes de congelar

| Verificación | Si falla |
|---|---|
| El tipo del issue contiene «Spec» (`#Partial release (Spec)` / `#Spec`) | Detente: no es una Spec. Si es el `#Release`, pide la clave de una Spec hija |
| El issue **no** está en `Backlog` ni `Discovery` | Detente: el flujo no llegó a Definición |
| La página funcional dice **`Estado: Ready for Dev`** | Detente. Excepción: el humano lo pide explícitamente → `estado_pagina_al_congelar: Borrador (forzado por <nombre>)` |
| La checklist «Validación para Ready for Dev» no tiene ítems críticos sin marcar; §9 sin `[NEEDS CLARIFICATION]` críticos | Detente e imprime cuáles y su dueño |
| El folio de la cabecera coincide con el esperado (vías 2 y 3) | Pregunta: la búsqueda pudo traer una página parecida |
| La página UX (si existe) está en `Ready for Dev` | Se congela la funcional; **las tareas de front quedan bloqueadas** hasta la UX |

## 5 · Hash de deriva (`contenido_hash`)

Se calcula sobre el **cuerpo Markdown que devuelve Confluence** (formato `markdown`),
normalizado así — la misma regla para la skill, el CI y quien quiera recomputarlo:

1. Saltos de línea `\r\n` → `\n`.
2. Quitar espacios al final de cada línea.
3. Quitar líneas en blanco al inicio y al final del documento.
4. Si hay anexos confirmados, concatenar sus cuerpos (misma normalización) en orden
   de id de página, separados por `\n\n---\n\n`.
5. `SHA-256` del resultado en UTF-8 → `sha256:<64 hex>`.

El front matter y el banner del snapshot **no** entran al hash. La fecha
`Última actualización` y la `Versión` de la cabecera **sí** (son parte del cuerpo):
cambiarlas es un cambio de la Spec y debe revisarse.

**Deriva** = el hash recalculado hoy ≠ `contenido_hash` del snapshot. Lo revisan
`inicio-tarea --refresh`, `front-feature` (paso 2) y `cierre-tarea` (chequeo de salida).
Sin MCP en la sesión, la skill pregunta al humano si la página cambió — no asume.

## 6 · Habilitación mínima (una vez por Spec, la hace el BA)

1. Abrir el issue `#Partial release (Spec)` → panel de Confluence → **enlazar** la
   página `SPEC-…` (o insertar el issue como enlace inteligente en la cabecera de la
   página, que hace lo mismo).
2. Poner el **folio al inicio del título** del issue: `SPEC-F1-003 · Ligar pedidos a
   propuesta comercial` — sirve de respaldo (vía 2) y a los humanos en el tablero.
3. En la descripción del issue: objetivo en una frase + enlace a la página. Nada más.
4. Cuando la página esté completa: cabecera `Estado: Ready for Dev` y checklist
   marcada. Ese es el gate.

---
*Dueño: Arquitecto · cambia por MR · ADR-005.*
