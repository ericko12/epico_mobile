# base-docs

Repositorio base de documentación del modelo operativo y de los activos de IA. Sirve a
**cualquier proyecto**: lo transversal vive en la raíz y lo propio de cada producto en
`productos/<producto>/`. **Aquí no hay código de producto** — hay verdad técnica.

## Qué es fuente de qué

- `docs/` — **transversal**: estándares de API y la **regla de enlace issue ↔ página**
  (`ENLACE_SPEC_CONFLUENCE.md`: cómo llega la skill de la clave de Jira a la página de
  Confluence de la Spec, qué verifica y cómo calcula el hash de deriva).
- `docs/adr/` — decisiones **del modelo** (cómo trabajamos), una por archivo, numeradas.
- `productos/<producto>/` — lo propio de cada plataforma: `ARQUITECTURA.md`,
  `CATALOGO_SERVICIOS.md`, `SISTEMA_DISENO.md` y sus `adr/`. **Lectura de inicio** de
  toda sesión técnica de ese producto. Cuál aplica lo declara la línea `Producto:` del
  `CLAUDE.md` de cada repo de código.
- `plantillas/` — la **fuente única** de formato de todos los artefactos (.md) del modelo.
  Las aplican las skills; nadie las copia a mano.
- `ejemplos/` — el ejemplo dorado (EF-50575) de cada artefacto bien llenado. Ante la
  duda, imitar el ejemplo.
- `ia/` — instrucciones del Proyecto compartido de Claude y guía de sesiones.

## Reglas para trabajar aquí (humanos e IA)

1. Todo cambio va por merge request. **Dueño editorial: el Arquitecto** (specs de
   plantilla de Jira: BA).
2. La Spec de una capacidad **no vive aquí**: vive en **su página de Confluence**,
   enlazada desde su issue de Jira (regla en `docs/ENLACE_SPEC_CONFLUENCE.md`,
   ADR-005); su copia congelada, en la rama de trabajo. Este repo no guarda specs (sí
   sus plantillas y el ejemplo dorado).
3. Un servicio o evento que no esté en el `CATALOGO_SERVICIOS.md` de su producto **no
   existe** — registrarlo es parte del mismo MR que lo crea.
4. Un producto nuevo se agrega copiando la estructura de `productos/` (ver su README);
   lo transversal **no se duplica** por producto.
5. Si la app de Claude y este repo se contradicen, **este repo manda**.
6. Cambiar una plantilla = revisar que las skills que la aplican sigan alineadas.
