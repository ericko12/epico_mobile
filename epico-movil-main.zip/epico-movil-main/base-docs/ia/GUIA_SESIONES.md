# Guía de sesiones con IA — las 10 reglas

> Para pegar en la pared. Aplican a toda sesión de Claude Code, de cualquier rol.

1. **Una sola fuente por tipo de información.** La Spec —gobierno y contenido— vive en
   su issue `#Spec` de Jira: el estado y los gates en el workflow, la especificación en
   los campos del issue. La verdad técnica, en Git. Nada se redacta dos veces — si dos
   lugares se contradicen, se corrige la fuente, no la copia.
2. **Una sesión ≈ una tarea.** No mezclar specs en una sesión: contexto revuelto
   produce código revuelto.
3. **Abrir leyendo, cerrar escribiendo.** Toda sesión inicia con `inicio-tarea`
   (snapshot · plan · subtareas · bitácora) y termina con `cierre-tarea` (bitácora →
   Jira). Sin excepciones, incluido UX.
4. **Contrato antes que integración.** Si el contrato no existe, el siguiente paso es
   escribirlo — no rodearlo con datos inventados "mientras tanto".
5. **Decisión nueva, artefacto el mismo día.** Cambia el comportamiento → el campo que
   le toca en la Spec (BA); con construcción en vuelo el hash deja de coincidir y el
   snapshot se refresca por decisión explícita.
   Decisión técnica transversal → ADR (Arquitecto).
6. **La IA propone, la persona decide.** Ninguna inferencia de la IA se vuelve regla de
   negocio sin validación humana explícita.
7. **El contexto se cura, no se pelea.** Si la IA repite un error, se corrige el
   CLAUDE.md o la skill por MR — no a mano en cada chat.
8. **Diez minutos re-descubriendo = faltó escribirlo.** Se anota en la retro y se decide
   dónde debió vivir: Spec, bitácora, CLAUDE.md o catálogo.
9. **Un humano responsable por cada cambio.** Quien firma el MR responde por el código.
   Nadie aprueba su propio código generado con IA.
10. **Buscar antes de crear.** Componentes, helpers, endpoints y eventos: primero en lo
    existente (catálogo, sistema de diseño). Lo transversal pasa por el Arquitecto.
