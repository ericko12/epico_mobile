# ADR-005 — La Spec vive en su página de Confluence; el issue de Jira la gobierna y la enlaza

**Estado:** Aceptada · 2026-09-11 · **Reemplaza a ADR-004** · **Restaura y precisa a ADR-003** · **Dueño:** Arquitecto

> **Por qué otro ADR y no borrar el anterior:** las decisiones se reemplazan, no se
> borran. ADR-003 (Confluence) y ADR-004 (campos por sección) se conservan como
> historia de lo evaluado. Este ADR fija lo vigente y agrega lo que ADR-003 dejó sin
> resolver: **cómo encuentra la skill la página desde la clave del issue**, qué es el
> gate y cómo se detecta la deriva sin depender del número de versión de Confluence.

## Contexto

Las Specs del piloto ya están escritas en Confluence, con la estructura de las
plantillas oficiales, y el equipo las mantiene ahí. Observado en el sitio real
(`exodusmx.atlassian.net`, 2026-09-11):

- **Confluence** — espacio `PE` («Proyectos EXODUS»), árbol
  `<Proyecto> → Specs → 00_SPEC_PROYECTO_<slug>` con las páginas hijas
  `SPEC-F<fase>-<nnn>_<slug>` (funcionales) y `UX-SPEC-F<fase>-<nnn>_<slug>` (UX), más
  páginas complementarias del BA («Reglas de negocio …», «Decisiones pendientes»).
  Cada página abre con un **bloque de cabecera** numerado: folios (`Spec Funcional:
  SPEC-F2-002`, `Spec UX/UI asociada: UX-SPEC-F2-002`, `Spec de Proyecto / Iniciativa:
  PROJ-SPEC-SFEP-001`), responsable, `Versión`, `Última actualización` y **`Estado`**
  (`Borrador` → `Ready for Dev`), y cierra con la checklist «Validación para Ready for
  Dev».
- **Jira** (proyecto `EF`) — la Spec es un issue tipo **`#Partial release (Spec)`**
  (nivel 1, «Spec que clarifica a los agentes de IA las funcionalidades a
  desarrollar»), **hijo del `#Release` del proyecto** (nivel 2) y padre de
  `#Historia de Spec` (nivel 0) y `#Task` (subtareas). En el equipo se le llama
  «la Spec» o `#Spec`. Sus estados: `Backlog → Discovery → Definition → Development →
  …` (más `Pause` / `Canceled`). **No hay estado «Ready for Dev» en Jira**: ese gate
  vive en la cabecera de la página.
- **Hoy el issue no enlaza su página**: sin enlace remoto, sin folio en el título y con
  la descripción vacía. Es lo único que falta para que la lectura sea automática.
- El **MCP de Atlassian** (`.mcp.json` de cada repo) cubre Jira y Confluence con la
  misma autorización y devuelve el cuerpo de la página **en Markdown limpio**, con los
  encabezados de la plantilla. **No expone el número de versión** de la página; sí la
  fecha de última modificación.

ADR-004 (un campo por sección) exigía ~30 campos personalizados, un mapa de ids y una
reconstrucción; con el contenido ya en Confluence, eso es costo sin beneficio.

## Decisión

1. **La página de Confluence es la fuente de la especificación.** Una página por Spec
   Funcional (`SPEC-F<fase>-<nnn>_<slug>`), una por Spec UX (`UX-SPEC-…`) y una por
   Spec de Proyecto (`00_SPEC_PROYECTO_<slug>`), todas con la plantilla oficial. La
   descripción del issue queda como **resumen ejecutivo + enlace**, no como contenedor.
2. **La clave del issue sigue siendo la identidad** (`EF-50620` nombra la rama, los
   archivos y las referencias — ADR-003 §1). El **folio** de la página
   (`SPEC-F1-003`) se registra en el snapshot como referencia cruzada, no sustituye a la
   clave.
3. **El issue enlaza su página** — regla de enlace, en orden de resolución (detalle en
   `docs/ENLACE_SPEC_CONFLUENCE.md`):
   1. **Enlace remoto a Confluence** en el issue (panel «Páginas de Confluence» /
      *Link Confluence page*; también se crea solo al insertar el issue como enlace
      inteligente en la cabecera de la página). Es la vía canónica.
   2. **Folio en el título del issue** (`SPEC-F1-003 · Ligar pedidos…`) → búsqueda CQL
      por título en el espacio del proyecto.
   3. **La página menciona la clave** (`Issue Jira: EF-50620` en su cabecera) →
      búsqueda CQL por texto.
   4. **Manual**: la skill pide la URL, sigue, y deja anotado que hay que enlazar.
   Si ninguna vía resuelve a **una** página, la skill se detiene — no adivina.
4. **La Spec UX y la Spec de Proyecto se resuelven desde la cabecera de la funcional**
   (`Spec UX/UI asociada:` y `Spec de Proyecto / Iniciativa:`) y por la convención de
   títulos. La UX **no necesita issue propio**: hereda la clave de la funcional.
5. **El gate tiene dos partes** y la skill verifica ambas: la **página** en
   `Estado: Ready for Dev` (checklist completa) y el **issue** fuera de
   `Backlog`/`Discovery`. Página en `Borrador` = no se construye; la excepción es
   explícita del humano y queda registrada en el snapshot.
6. **El snapshot es una copia verbatim** del Markdown que devuelve Confluence (ya no se
   reconstruye nada) con front matter: clave, folio, página, fecha de modificación,
   `Versión`/`Estado` de la cabecera, cómo se resolvió el enlace y el hash.
7. **La deriva se detecta por hash de contenido** (`contenido_hash`, SHA-256 del
   cuerpo normalizado — la regla de normalización está en
   `ENLACE_SPEC_CONFLUENCE.md`). La fecha de modificación se registra como dato para
   humanos; **el hash es la verificación**. El refresco sigue siendo un commit
   explícito (`--refresh`) autorizado por una persona.
8. **Páginas complementarias** («Reglas de negocio …», «Decisiones pendientes») que
   referencien el folio se ofrecen como **anexos** del snapshot; el humano confirma
   cuáles aplican. Una decisión pendiente abierta cuenta como `[NEEDS CLARIFICATION]`.
9. **Nadie escribe la Spec desde una skill.** La IA propone texto y dice en qué sección
   de qué página va y quién lo lleva (BA / UX / PO). Las bitácoras siguen siendo
   comentarios del issue.

## Consecuencias

- (+) Cero campos personalizados, cero mapa de ids, cero reconstrucción: lo que ya
  existe en Confluence es lo que se congela. `CAMPOS_SPEC_JIRA.md` se retira.
- (+) La página conserva historial nativo (quién, cuándo, comparación de versiones)
  para los humanos; el hash da a la skill y al CI una verificación determinista.
- (+) Un solo `.mcp.json` y una sola autorización cubren Jira + Confluence.
- (−) Dos sistemas al arrancar; mitigado: `inicio-tarea` los recorre en un paso y
  registra cómo resolvió el enlace.
- (−) La regla de enlace depende de una disciplina mínima: **enlazar la página al
  issue** (o poner el folio en el título). Hoy no está hecha en ningún issue del
  piloto; es la primera tarea de habilitación (ver README del paquete).
- (−) Sin número de versión expuesto, el hash cambia con cualquier edición de la
  página, incluida una coma — eso es deseable (toda edición se revisa), pero exige que
  las ediciones cosméticas se hagan antes del congelado o se acepten como refresh.
- (−) `Ready for Dev` es un texto en la cabecera de la página, no un estado con
  permisos: quien lo cambia debe ser el dueño de la Spec (BA / UX). Si el equipo
  quiere un gate con control de acceso, la alternativa es un estado propio en el
  workflow de Jira; este ADR no lo exige.

## Referencias

ADR-001 (snapshot en la rama, enmendado por ADR-004 y ahora por este) · ADR-002
(ramas desde release) · ADR-003 (restaurada) · ADR-004 (reemplazada) ·
`docs/ENLACE_SPEC_CONFLUENCE.md` · `plantillas/plantilla-snapshot.md` · skills
`inicio-tarea`, `front-feature`, `contrato-api`, `cierre-tarea`.
