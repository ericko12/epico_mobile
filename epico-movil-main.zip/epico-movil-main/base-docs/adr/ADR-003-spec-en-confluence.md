# ADR-003 — La Spec vive en Confluence; Jira gobierna y enlaza el «Doc en vivo»

**Estado:** ~~Aceptada~~ · ~~Reemplazada por ADR-004 (2026-09-07)~~ · **Restaurada y precisada por ADR-005** (2026-09-11) · **Dueño:** Arquitecto

> **Historia:** ADR-004 reemplazó este ADR con «un campo por sección» en el issue;
> ADR-005 lo revirtió porque las Specs ya viven en Confluence. **Lo vigente es
> ADR-005**, que toma de aquí la decisión de fondo (Confluence contiene, Jira gobierna,
> la clave del issue es la identidad) y corrige dos puntos: el tipo de issue real es
> `#Partial release (Spec)` (no `#Spec`), la Spec UX **no tiene issue propio** (se
> resuelve desde la cabecera de la página funcional) y la deriva se detecta por **hash
> del contenido**, no por número de versión — el MCP de Atlassian no lo expone. Lo
> demás de este documento se conserva tal como se escribió.

## Contexto
La descripción del issue en Jira no alcanza para el contenido de una Spec: el límite
efectivo de nuestra configuración (~3 000 caracteres) queda muy por debajo de las
plantillas oficiales (4 000+). Además el documento necesita tablas, secciones y una
historia de cambios legible — cosas que Confluence hace de forma nativa.

Por otro lado, el tipo de issue quedó definido como **`#Spec`** y **puede existir en
varios proyectos de Jira**, de modo que la clave del issue depende del proyecto
(`EF-50575`). El esquema anterior —un folio propio escrito en el título— duplicaba
identidad y podía divergir de la clave real.

## Decisión
1. **La clave del issue de Jira es la identidad de la Spec.** `EF-50575` nombra la
   rama (`EF-50575/<breve>`), los archivos de trabajo y las referencias cruzadas. No
   se inventan folios paralelos: donde las plantillas piden un folio, va la clave real.
2. **Jira gobierna:** tipo `#Spec`, estado y gates (READY FOR DEV…), dueños,
   jerarquía (las Specs Funcional y UX son **hijas** de la Spec de Proyecto),
   subtareas y bitácoras (comentarios).
3. **Confluence contiene:** cada `#Spec` enlaza su **«Doc en vivo»** — la página de
   Confluence con el contenido de la Spec, redactado desde su plantilla oficial. Ese
   documento es la **fuente de la especificación**.
4. **Los snapshots se generan del Doc en vivo**, no de la descripción de Jira. El
   front matter registra la página y su **número de versión de Confluence**; el
   contenido va íntegro y sin reordenar, igual que antes.
5. **La deriva se detecta por versión.** Confluence versiona cada edición con un
   entero, así que comparar `confluence_version` del snapshot contra la versión viva
   dice, sin ambigüedad, si la Spec cambió con construcción en vuelo. El refresco
   sigue siendo un commit explícito.
6. **El tipo de Spec** (Proyecto / Funcional / UX) se reconoce por el encabezado del
   Doc en vivo y por la jerarquía en Jira — no por el nombre del issue.

## Consecuencias
- (+) El documento deja de estar limitado por un campo de texto y gana versionado,
  comparación de versiones e historial con autor y fecha.
- (+) La detección de cambios pasa de una automation frágil a una **comparación de
  versión** verificable por la skill y por el CI.
- (+) La clave de Jira es única en el sitio: enlaza commits, ramas y MRs sin traducción.
- (−) Hay dos sistemas que consultar al arrancar una tarea; mitigado: la skill
  `inicio-tarea` lo hace en un solo paso, y una sola conexión (MCP de Atlassian)
  cubre Jira y Confluence.
- (−) Si un issue `#Spec` no tiene «Doc en vivo», la Spec es inconstruible; la skill
  se detiene y lo reporta en lugar de adivinar.

## Referencias
ADR-001 (snapshot en la rama) · ADR-002 (ramas desde release) ·
`base-docs/plantillas/plantilla-snapshot.md` · skills `inicio-tarea`, `front-feature`.
