# ADR-001 — La Spec se gobierna en Jira y se construye desde un snapshot en la rama

**Estado:** Aceptada · 2026-08-26 · **Enmendada por ADR-004** (2026-09-07) · **Dueño:** Arquitecto

## Contexto
La Spec vive en Jira (edición sin fricción, gates, dueños). Pero el agente de código
trabaja sobre archivos: leer la Spec vía conector en cada paso es frágil, no diffeable
y sin evidencia de versión. Además, una descripción de Jira puede editarse en caliente
durante la construcción sin que nadie lo note.

## Decisión
Al pasar una Spec a `READY FOR DEV`, la skill `inicio-tarea` la copia como
`spec.snapshot.md` en la rama de trabajo, con front matter (clave, fecha, versión) y
banner de "no editar aquí". El agente construye **solo** desde el snapshot. Una
automation de Jira etiqueta `SPEC-MODIFICADA` si la descripción cambia con construcción
en vuelo; el refresco del snapshot es un commit explícito, nunca silencioso.

## Consecuencias
- (+) El MR conserva la evidencia exacta de qué versión de la Spec se construyó.
- (+) El agente no depende del conector a media sesión; lee, greppea y diffea local.
- (+) El "congelado" deja de ser disciplina y se vuelve mecanismo.
- (−) Un archivo derivado más por rama; mitigado: lo genera y refresca la skill, no la gente.

## Enmienda (ADR-004)
Lo que se congela ya **no es la descripción del issue** sino el documento
**reconstruido a partir de sus campos** —uno por sección de la plantilla— en el orden
que fija `CAMPOS_SPEC_JIRA.md`. Y la detección de cambios no depende solo de la
automation `SPEC-MODIFICADA`: el snapshot guarda un **hash del contenido de los campos**
y la skill lo compara al arrancar. El mecanismo —congelar en la rama, construir solo
desde ahí, refrescar con commit explícito— no cambia.

## Referencias
Contrapropuesta V2.1 §3 · ADR-004 (vigente) · ADR-003 (reemplazada) · plantilla en
`base-docs/plantillas/plantilla-snapshot.md`.
