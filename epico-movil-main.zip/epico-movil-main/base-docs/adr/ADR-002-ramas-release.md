# ADR-002 — Las ramas de Spec nacen de una release y regresan a esa release

**Estado:** Aceptada · 2026-09-03 · **Dueño:** Arquitecto

## Contexto
El CI/CD actual de la plataforma opera por ramas `release/*`: lo que llega a `main`
llega vía releases, no vía ramas de trabajo. Si las ramas `SPEC-XXX/*` salieran de
`main` o mergearan directo a `main`, el modelo del piloto rompería el pipeline
existente y los cortes perderían su unidad de despliegue.

## Decisión
Todo repositorio conserva su `main`, pero **toda rama `SPEC-XXX/*` se crea desde una
rama `release/*` y su merge request apunta a esa misma release** — nunca a `main`.
La skill `inicio-tarea` (y `contrato-api` para ramas de contrato) pregunta al humano
de qué release nace la rama, u ofrece crear una release nueva pidiéndole el nombre;
la release elegida queda anotada en el `plan.md` y es el target del MR. `main` recibe
releases según el proceso de CI/CD vigente, que no cambia.

## Consecuencias
- (+) El modelo respeta el CI/CD actual sin excepciones ni ramas huérfanas.
- (+) Cada release agrupa las Specs de su corte: se despliega y se audita por corte.
- (−) Una pregunta más al abrir tarea; mitigada: la hace la skill, con la lista de
  releases existentes y la opción de crear una nueva.

## Referencias
Skill `inicio-tarea` §1 · skill `contrato-api` §3 · CLAUDE.md del front (regla 5) y
de la plantilla (regla 6).
