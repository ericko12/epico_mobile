# ADR-004 — La Spec vive en campos del issue, uno por sección

**Estado:** ~~Aceptada~~ · **Reemplazada por ADR-005** (2026-09-11) · Reemplazaba a ADR-003 · **Dueño:** Arquitecto

> **Por qué se reemplazó:** el equipo ya tenía las Specs escritas y mantenidas en
> Confluence con la plantilla oficial; crear ~30 campos personalizados y reconstruir el
> documento era costo sin beneficio. ADR-005 restaura Confluence como fuente y resuelve
> lo que faltaba (cómo se enlaza la página al issue, qué es el gate, cómo se detecta la
> deriva). Este ADR se conserva como historia: documenta la alternativa y su
> razonamiento. Lo que sigue vigente de aquí: la deriva se detecta por **hash de
> contenido**, y la descripción del issue es resumen ejecutivo, no contenedor.

## Contexto
El contenido de una Spec no cabe en la descripción del issue (límite efectivo ~3 000
caracteres contra plantillas de 4 000+). ADR-003 resolvió eso sacando el documento a
Confluence, pero eso partía la Spec en dos sistemas: el gobierno en Jira y el contenido
fuera, con dos permisos, dos historiales y una consulta extra en cada arranque.

Existe una alternativa que mantiene todo en un solo lugar: **la plantilla de Spec ya
está seccionada**, así que cada sección puede ser su **propio campo** del issue. El
límite deja de morder porque aplica por campo, no al documento completo.

## Decisión
1. **La Spec vive en el issue `#Spec` de Jira, en campos personalizados: uno por
   sección de su plantilla.** Nada de documento externo. La descripción queda como
   **resumen ejecutivo** (objetivo en una frase + enlaces), no como contenedor.
2. **El mapa sección ↔ campo es un artefacto versionado:**
   `base-docs/docs/CAMPOS_SPEC_JIRA.md`, con el **id** de cada campo
   (`customfield_XXXXX`), su nombre visible y el orden canónico por tipo de Spec
   (Proyecto / Funcional / UX). Las skills leen de ahí; cambia por MR.
3. **El snapshot se reconstruye**, no se copia: la skill trae los campos, los ordena
   según el mapa, les pone su encabezado de sección y produce el documento Markdown
   íntegro. El resultado es determinista — el mismo issue produce el mismo archivo.
4. **La deriva se detecta por hash de contenido.** El snapshot guarda
   `campos_hash` (SHA-256 de los valores concatenados en orden canónico). Comparar el
   hash es inmune a comentarios, etiquetas y cambios de estado: solo cambia si cambió
   el **contenido** de la Spec. El refresco sigue siendo un commit explícito.
5. **La automation de Jira vuelve a ser viable** y se usa como aviso proactivo: si
   cualquier campo de Spec cambia con el issue en DEVELOPMENT → etiqueta
   `SPEC-MODIFICADA` + aviso al canal. El hash es la verificación; la etiqueta, el
   madrugador.
6. **Una sección larga se parte en sub-campos** en lugar de rozar el límite: §5 de la
   Funcional se divide en *Requisitos funcionales*, *Reglas de negocio*, *Datos y
   validaciones* y *Permisos*. El mapa registra la partición y la skill los concatena
   bajo su sección al reconstruir.

## Consecuencias
- (+) Una sola herramienta y un solo permiso: el issue es la Spec. Sin salto a otro
  producto al arrancar una tarea.
- (+) Cada sección es consultable y automatizable por separado (JQL, tableros,
  validadores del gate) — algo que un documento monolítico no permite.
- (+) El límite de caracteres deja de ser un problema estructural: aplica por sección.
- (−) Se pierden el versionado y la comparación de versiones nativos del documento;
  mitigado con `campos_hash` + el historial de cambios del issue, que registra campo
  por campo qué cambió, cuándo y quién.
- (−) Requiere ~30 campos personalizados y su contexto por tipo de issue; el admin de
  Jira debe crearlos con nombres prefijados (`Spec · …`) y **acotados por tipo y
  proyecto** para no contaminar otros formularios. Verificar el **límite por campo**
  antes de cerrar el diseño: si es el mismo ~3 000, las secciones de requisitos y
  criterios son las que lo rozarán primero.
- (−) Leer la Spec completa en la interfaz de Jira es menos cómodo que una página; se
  compensa con el orden de la pantalla del issue y con el snapshot reconstruido, que sí
  es un documento legible de corrido.

## Referencias
ADR-001 (snapshot en la rama, enmendado) · ADR-003 (reemplazada) ·
`base-docs/docs/CAMPOS_SPEC_JIRA.md` · `base-docs/plantillas/plantilla-snapshot.md` ·
skill `inicio-tarea`.
