---
# ejemplo dorado — contenido ilustrativo; folios, páginas y estructura son los reales del piloto
spec: EF-50575
folio: SPEC-F2-002
tipo: funcional
titulo: Check-in / Check-out de actividad comercial
spec_proyecto: EF-50612 · PROJ-SPEC-SFEP-001 · página 1659863046
spec_ux: UX-SPEC-F2-002 · página 1659797599 · Ready for Dev
origen: Confluence · espacio PE · página 1659895864 «SPEC-F2-002_Check_in_Check_out» · modificada 2026-09-15 · cabecera Versión 1.0 · Estado Ready for Dev
resuelto_por: enlace-remoto
anexos: ninguno
contenido_hash: sha256:5d8f440b796b5367704fe0a79290422d0809c438beca7ed9d92bd7a1446573ce
estado_pagina_al_congelar: Ready for Dev
estado_issue_al_congelar: Development
rama: EF-50575/checkin-checkout
generado_por: skill inicio-tarea v1.4
---

# ⚠ SNAPSHOT — Copia congelada de la página de Confluence de EF-50575 (SPEC-F2-002). No editar este archivo.
> La Spec se edita **en su página de Confluence**. Si la página cambia durante la
> construcción, el hash deja de coincidir: la skill lo avisa. El refresco es un commit
> visible (`/inicio-tarea EF-50575 --refresh`).

# 📄 Check-in / Check-out de actividad comercial

1. **Spec Funcional:** SPEC-F2-002
2. **Spec UX/UI asociada:** UX-SPEC-F2-002
3. **Spec de Proyecto / Iniciativa:** PROJ-SPEC-SFEP-001
4. **Issue Jira:** EF-50575
5. **Responsable BA:** BA del piloto
6. **Versión:** 1.0
7. **Última actualización:** 15-09-2026
8. **Estado:** Ready for Dev

---

## 🎯 1. Resumen y Contexto

- **Necesidad / Problema específico:** La coordinación no sabe qué visitas están
  ocurriendo; el asesor reporta tarde o no reporta. El dato de asistencia llega al día
  siguiente y con errores.
- **Objetivo:** El asesor registra inicio y fin de su visita desde el móvil en menos de
  30 segundos, y la coordinación ve el estado de las actividades del día en tiempo real.
- **Relación con el objetivo del Proyecto:** Primera capacidad comercial que migra de
  Salesforce a Epico; hoy esto se hace en Salesforce y por teléfono.
- **Valor de negocio específico:** El dato de asistencia queda disponible el mismo día
  y sin captura manual posterior.

---

## 👥 2. Usuarios y Responsables

- **Público objetivo:**
  - **Usuarios y Áreas beneficiadas:** Coordinación comercial.
  - **Usuarios y Áreas que utilizarán la funcionalidad:** Asesores comerciales
    (check-in/out desde móvil) y coordinadores (vista de equipo).
  - **Usuarios y Áreas impactadas:** Sistema Cobranza (consume `ms-actividades`).

- **Responsables de la Spec:**
  - **PO:** PO del piloto · **BA:** BA del piloto · **UX:** UX del piloto
  - **DEV:** Dev-A (front) / Dev-B (back) · **QA:** QA del piloto · **ARQ:** Arquitecto

---

## 💡 3. Alcance y Consideraciones Iniciales

- **En el alcance (In Scope):**
  - Check-in y check-out sobre actividades **ya asignadas** al asesor.
  - Vista «Mis actividades de hoy» (asesor) y vista de equipo (coordinador).
  - Registro con **hora del servidor**.

- **Fuera del alcance (Out of Scope):**
  - Modo sin conexión (se evaluará con volumen real, en un corte posterior).
  - Geocercas / validación de ubicación.
  - Reagendar o crear actividades (ya existe en Epico; no se toca).

- **Criterios de éxito:**
  - **CRI-01.** El registro completo (abrir → check-in) toma menos de 30 segundos.
  - **CRI-02.** El coordinador ve el cambio de estado en su vista en menos de 1 minuto.

- **Riesgos a considerar:**
  - **RISG-01.** Pico de carga 8–9 am: todos los asesores hacen check-in a la vez.

- **Dependencias a considerar:**
  - **DEP-01.** `ms-actividades` — se extiende. ⚠ Servicio compartido (lo consume
    Sistema Cobranza): cambios aditivos únicamente.
  - **DEP-02.** `ms-notificaciones` — consume el evento de check-in para la vista del
    coordinador.

- **Supuestos no validados:**
  - **SUP-01.** Las actividades del día ya existen asignadas en Epico (módulo actual).

---

## 🔄 4. Flujo y Comportamiento Esperado

- **Flujo principal:**
  1. El asesor abre «Mis actividades de hoy» → lista con estado y horario.
  2. Toca la actividad y ejecuta **Check-in** → la actividad pasa a `en_curso`.
  3. Al terminar ejecuta **Check-out** → pasa a `terminada` y registra duración.
  4. El coordinador ve el cambio reflejado en su vista al momento.

- **Escenarios alternos / excepciones:**
  - **EX-01.** Check-in fuera del horario de la actividad → se bloquea con mensaje:
    **"Aún no inicia tu actividad"** (antes) / **"Tu actividad ya venció"** (después).
  - **EX-02.** Check-in con otra actividad `en_curso` → se bloquea con mensaje:
    **"Tienes otra actividad en curso: ciérrala primero"**.
  - **EX-03.** Falla de red al registrar → reintento con aviso; nunca doble registro
    (idempotencia por actividad+operación).

---

## ⚙️ 5. Requisitos y Reglas de Negocio

### Requisitos funcionales

- **RF-01.** Listar las actividades del día del asesor autenticado, con estado y horario.
- **RF-02.** Registrar check-in de una actividad con hora del servidor.
- **RF-03.** Registrar check-out con hora del servidor y duración calculada.
- **RF-04.** Reflejar el estado de las actividades del equipo en la vista del coordinador.

### Reglas de negocio

- **RN-01.** Solo se puede hacer check-in en actividades asignadas al propio asesor.
- **RN-02.** Un asesor solo puede tener **una** actividad `en_curso` a la vez.
- **RN-03.** No se permite check-in fuera del horario de la actividad (antes de su hora
  de inicio o después de su hora de fin).

### Datos y validaciones

- **DAT-01. Registro de asistencia**
  - **Descripción:** actividad, asesor, hora check-in, hora check-out, duración calculada.
  - **Origen:** Sistema (hora del servidor — la del dispositivo no es válida).
  - **Obligatorio:** Sí · **Editable:** No.
  - **Validación:** RN-01, RN-02 y RN-03 se evalúan en el servidor.
  - **Comportamiento si no es válido:** operación bloqueada con el mensaje de la regla
    (EX-01 / EX-02); nada se registra.
- **DAT-02. Estado de la actividad**
  - **Descripción:** `pendiente → en_curso → terminada`; excepción `no_realizada`
    (la marca el coordinador).
  - **Origen:** Sistema · **Obligatorio:** Sí · **Editable:** No (solo por transición).
  - **Validación:** solo transiciones válidas del estado.
  - **Comportamiento si no es válido:** 409 conflicto de estado.

### Permisos

- **PER-01.** Rol `asesor`: solo sus propias actividades.
- **PER-02.** Rol `coordinador`: lectura de las actividades de su equipo.
- **PER-03.** Todo registro queda auditado (quién, qué, cuándo — hora del servidor).

---

## ✅ 6. Criterios de Aceptación

- **AC-01 — Check-in dentro del horario:**
  - **Dado que** Laura tiene la actividad «Visita Cliente Norte» asignada de 17:00 a 18:00
  - **Cuando** hace check-in a las 17:05
  - **Entonces** la actividad queda `en_curso` y se registra la hora del servidor.

- **AC-02 — Check-in fuera del horario:**
  - **Dado que** la actividad inicia a las 17:00
  - **Cuando** Laura intenta check-in a las 14:30
  - **Entonces** Epico impide la operación y muestra **"Aún no inicia tu actividad"**.

- **AC-03 — Solo una actividad en curso:**
  - **Dado que** Laura tiene otra actividad `en_curso`
  - **Cuando** intenta check-in en «Visita Cliente Norte»
  - **Entonces** Epico impide la operación y muestra **"Tienes otra actividad en curso:
    ciérrala primero"**.

- **AC-04 — Check-out registra duración:**
  - **Dado que** Laura hizo check-in a las 17:05
  - **Cuando** hace check-out a las 17:50
  - **Entonces** la actividad queda `terminada`, la duración registrada es 45 minutos y
    el coordinador ve el nuevo estado en su vista de equipo.

---

## 🛡️ 7. Requisitos No Funcionales

- **NFR-PERF-01.** Soportar el pico de 8–9 am; la lista del día puede servirse con
  cache de hasta 5 minutos; las escrituras son directas.
- **NFR-SEC-01.** Auditoría estructurada de cada operación (op, usuario, actividad,
  timestamp del servidor).
- **NFR-INT-01.** El evento de check-in se publica versionado (v1) y con cambios
  aditivos — el servicio es compartido.

---

## 🔗 8. Impactos, Restricciones y Referencias

### Impactos

- **IMP-01.** `ms-actividades` (⚠ compartido con Sistema Cobranza): solo cambios aditivos.
- **IMP-02.** Vista de equipo del coordinador (consume el evento vía `ms-notificaciones`).

### Restricciones descubiertas

- **RES-01.** La hora válida es **siempre** la del servidor; el reloj del dispositivo
  no participa en RN-03.

### Referencias

- **Spec de Proyecto:** PROJ-SPEC-SFEP-001 (`00_SPEC_PROYECTO_Migracion_Salesforce_Epico`) · **Spec UX/UI:** UX-SPEC-F2-002 · **Issue Jira:** EF-50575
- **Discovery:** Confluence «Discovery Check-in» + video Loom
- **Contrato / OpenAPI:** `ms-actividades/contracts/openapi.json` (congelado 2026-09-15)
- **BDD `.feature`:** `ms-actividades/tests/features/EF-50575.feature` (se deriva de los
  AC durante Construcción)
- **MR:** !88

---

## ❓ 9. Pendientes de Definición

- **[NEEDS CLARIFICATION]** ¿El mensaje de EX-01 debe mostrar la hora de inicio de la
  actividad? — dueño: BA · **no crítico** (no bloquea Construcción).

---

## ✅ Validación para Ready for Dev

- [x] Objetivo específico claramente definido.
- [x] Relación con el objetivo del Proyecto comprendida.
- [x] Usuarios / actores relevantes identificados.
- [x] Alcance y fuera de alcance delimitados.
- [x] Flujo funcional principal definido de principio a fin.
- [x] Escenarios alternos y excepciones relevantes considerados.
- [x] Requisitos funcionales concretos y verificables.
- [x] Reglas de negocio aplicables definidas.
- [x] Datos y validaciones funcionales relevantes definidos.
- [x] Permisos aplicables definidos.
- [x] Criterios de Aceptación suficientes para validar el comportamiento.
- [x] NFR específicos definidos cuando aplican.
- [x] NFR transversales del Proyecto considerados.
- [x] Dependencias particulares identificadas.
- [x] Impactos y restricciones conocidos identificados.
- [x] Spec UX/UI asociada y en Ready for Dev cuando la funcionalidad requiera experiencia o interfaz.
- [x] No existen `[NEEDS CLARIFICATION]` críticos para Construcción.
- [x] BA, DEV, QA y ARQ cuentan con información funcional suficiente según corresponda.
