---
# ejemplo dorado — contenido ilustrativo; folios, páginas y estructura son los reales del piloto
spec: EF-50575
folio: UX-SPEC-F2-002
tipo: ux
spec_funcional: SPEC-F2-002 · página 1659895864
titulo: Check-in / Check-out · experiencia del asesor
spec_proyecto: EF-50612 · PROJ-SPEC-SFEP-001 · página 1659863046
origen: Confluence · espacio PE · página 1659797599 «UX-SPEC-F2-002_Check_in_Check_out» · modificada 2026-09-15 · cabecera Versión 1.0 · Estado Ready for Dev
resuelto_por: cabecera-funcional
anexos: ninguno
contenido_hash: sha256:4a6160c737351240d23311168f5fb8e71787c5f71a8b74bda31c46b8cc97076d
estado_pagina_al_congelar: Ready for Dev
estado_issue_al_congelar: Development
rama: EF-50575/checkin-checkout
generado_por: skill inicio-tarea v1.4
---

# ⚠ SNAPSHOT UX — Copia congelada de la página de Confluence UX-SPEC-F2-002 (issue EF-50575). No editar este archivo.
> La experiencia se edita **en su página de Confluence**. Misma regla de deriva: si el
> hash deja de coincidir, la skill lo avisa y el refresco es un commit visible.

# 🎨 Check-in / Check-out · experiencia del asesor

1. **Spec UX/UI:** UX-SPEC-F2-002
2. **Spec Funcional:** SPEC-F2-002
3. **Spec de Proyecto / Iniciativa:** PROJ-SPEC-SFEP-001
4. **Issue Jira:** EF-50575
5. **Responsable UX:** UX del piloto
6. **Versión:** 1.0
7. **Última actualización:** 15-09-2026
8. **Estado:** Ready for Dev

---

## 🎯 1. Intención de Experiencia

1. **Objetivo de experiencia:** que el asesor registre su check-in **en la calle, con
   una mano y en menos de 30 segundos**, sin pensar en el sistema.
2. **Problema de experiencia:** hoy el registro es una llamada o captura tardía en
   Salesforce — fricción alta, dato tarde.
3. **Resultado esperado para el usuario:** abrir la app, ver su día, tocar un botón y
   seguir con su visita.
4. **Principios de experiencia particulares:**
   - **UX-PRI-01.** Una sola acción dominante por pantalla.
   - **UX-PRI-02.** Legible a pleno sol (uso en exteriores).

---

## 🧭 2. Flujo de Experiencia TO-BE

### Flujo principal

1. **UX-FLU-01 — Check-in de la visita**
   1. **Punto de entrada:** ícono de la app → «Mis actividades de hoy».
   2. **Objetivo del usuario:** registrar que su visita comenzó.
   3. **Paso 1:** identifica su actividad en la lista (la próxima aparece resaltada).
   4. **Paso 2:** toca **Check-in** en la tarjeta.
   5. **Paso 3:** ve la confirmación y el nuevo estado `en curso`.
   6. **Resultado:** regresa a su visita; la coordinación ya lo ve en su tablero.

### Flujos alternos

- **UX-FLU-02 — Check-in bloqueado (fuera de horario / otra en curso):** el intento
  muestra el mensaje canónico de la regla, sin salir de la lista, y la tarjeta queda
  como estaba.

---

## 🖥️ 3. Inventario de Pantallas / Vistas

### UX-VIEW-01 — Mis actividades de hoy

- **Propósito:** ver el día de un vistazo y ejecutar check-in/check-out sin navegar.
- **Entrada desde:** inicio de la app.
- **Salida hacia:** UX-VIEW-02 (tocando la tarjeta) o permanece.
- **Referencia Figma:** [Frame «Mis actividades v3»]

### UX-VIEW-02 — Detalle de actividad

- **Propósito:** contexto de la visita (cliente, horario, notas) + las mismas acciones.
- **Entrada desde:** UX-VIEW-01.
- **Salida hacia:** regreso a UX-VIEW-01.
- **Referencia Figma:** [Frame «Detalle actividad v2»]

---

## 🧱 4. Estructura y Jerarquía de la Interfaz

### UX-VIEW-01 — Mis actividades de hoy

1. **Estructura principal:** encabezado con fecha · lista de tarjetas de actividad.
2. **Jerarquía de información:** **Primaria:** la actividad próxima/en curso y su botón ·
   **Secundaria:** el resto del día · **Complementaria:** actividades terminadas.
3. **Acción principal:** **Check-in** (o **Check-out** si hay una `en curso`).
4. **Acciones secundarias:** abrir detalle · pull-to-refresh.
5. **Consideraciones particulares:** nunca dos botones primarios visibles a la vez
   (UX-PRI-01); la tarjeta `en curso` siempre arriba.

---

## 🧩 5. Componentes y Design System

### Fuentes heredadas

- **Catálogo de componentes Front:** `base-docs/productos/epico/SISTEMA_DISENO.md`
- **Reglas de gobierno del DS:** `epico-front/.claude/rules/design-system.md`

### Componentes utilizados por esta funcionalidad

#### UX-COMP-01 — ListaActividades

- **Componente existente:** `ListaActividades` · **Vista:** UX-VIEW-01
- **Uso:** lista del día con estados vacío y carga ya resueltos.
- **Decisión:** Reutilizar.

#### UX-COMP-02 — TarjetaActividad

- **Componente existente:** `TarjetaActividad` · **Vista:** UX-VIEW-01 / 02
- **Uso:** actividad con horario, estado y acción.
- **Variante / configuración:** con slot de acción (botón primario).
- **Estados particulares:** resaltada cuando está `en curso`.
- **Decisión:** **Extender** (slot de acción — no existía).

#### UX-COMP-03 — EtiquetaEstado · UX-COMP-04 — BotonPrimario · UX-COMP-05 — Alerta

- **Componentes existentes**, se reutilizan tal cual: estado con color semántico,
  acción principal (máx. 1 por vista), errores de regla con mensaje canónico.

### Componentes nuevos requeridos

- **Ninguno.** La extensión de UX-COMP-02 se propone como `PROPUESTA-DS` en el MR y se
  registra en `SISTEMA_DISENO.md` al aprobarse (acuerdo UX + Dev Front).

---

## 🖱️ 6. Interacciones y Comportamientos

### UX-INT-01 — Tocar Check-in

- **Elemento:** BotonPrimario de la TarjetaActividad · **Disparador:** tap.
- **Comportamiento esperado:** botón se deshabilita + indicador de carga; al confirmar
  el servidor, la tarjeta pasa a `en curso`.
- **Resultado visual:** toast de éxito (UX-MSG-04) y tarjeta resaltada.
- **Condición:** actividad `pendiente` dentro de horario.
- **Referencia funcional:** RN-03 / AC-01.

### UX-INT-02 — Intento bloqueado por regla

- **Elemento:** el mismo botón · **Disparador:** tap con regla incumplida.
- **Comportamiento esperado:** Alerta inline con el mensaje canónico; sin navegación.
- **Referencia funcional:** RN-02, RN-03 / AC-02, AC-03 / EX-01, EX-02.

---

## 🔄 7. Estados de la Experiencia

- **UX-STATE-01 — Inicial:** lista del día con la próxima actividad resaltada;
  acciones: check-in / abrir detalle.
- **UX-STATE-02 — Vacío:** sin actividades hoy → UX-MSG-05, sin acción primaria.
- **UX-STATE-03 — Carga:** skeleton de tarjetas (componente del DS); lista bloqueada.
- **UX-STATE-04 — Error:** regla incumplida → Alerta **inline** con el mensaje canónico
  del AC (UX-MSG-02/03); recuperación: corregir (cerrar la otra actividad / esperar
  horario). Error de red → reintento con aviso (EX-03).
- **UX-STATE-05 — Éxito:** toast UX-MSG-04 + tarjeta `en curso` resaltada; siguiente
  acción natural: nada (el asesor sigue su visita).
- **UX-STATE-06 — Deshabilitado:** botón Check-in inactivo fuera de horario, con la
  hora de inicio visible como motivo (pendiente no crítico en EF-50575 §9).

---

## ✍️ 8. Formularios, Datos y Validaciones Visuales

- **No aplica** — la experiencia no captura datos; todo es acción de un toque.

---

## 💬 9. Textos de Interfaz y Feedback

### Mensajes

- **UX-MSG-02 — Error (RN-03):** "Aún no inicia tu actividad" / "Tu actividad ya
  venció" — canónico en EF-50575 AC-02 / EX-01.
- **UX-MSG-03 — Error (RN-02):** "Tienes otra actividad en curso: ciérrala primero" —
  canónico en EF-50575 AC-03.
- **UX-MSG-04 — Éxito:** "Check-in registrado a las {HH:MM}".
- **UX-MSG-05 — Estado vacío:** "No tienes actividades hoy".

### Etiquetas relevantes

- **UX-TXT-01.** Botón de acción → "Check-in" / "Check-out".

### Reglas de contenido particulares

- Tuteo, frases cortas, sin tecnicismos ("actividad", nunca "work item").

---

## 📱 10. Adaptabilidad (Responsive), Dispositivos y Accesibilidad

- **UX-RESP-01.** Móvil primero; en escritorio la lista pasa a dos columnas.
- **UX-ACC-01.** Áreas de toque ≥ 44 px (uso con una mano).
- **UX-ACC-02.** Contraste AA verificado en exteriores (escenario `@manual` de QA).

---

## 🎬 11. Transiciones, Animaciones y Feedback Visual

- **UX-MOTION-01.** Solo el toast de éxito y la transición de estado de la tarjeta;
  nada decorativo.

---

## 🚧 12. Restricciones y Consideraciones UX/UI

- **UX-RES-01.** Sin modales en el flujo de check-in (una mano, en la calle).
- **UX-RES-02.** No crear componentes nuevos: extender `TarjetaActividad` vía
  `PROPUESTA-DS`.

---

## 🔗 13. Referencias

1. **Spec Funcional:** SPEC-F2-002 (issue EF-50575) · 2. **Spec de Proyecto:** PROJ-SPEC-SFEP-001
3. **Prototipo / Figma:** [URL] · 6. **Catálogo Front:** `base-docs/productos/epico/SISTEMA_DISENO.md`
7. **Reglas DS:** `epico-front/.claude/rules/design-system.md`
11. **Contrato:** `ms-actividades/contracts/openapi.json`
12. **Reglas de mocks:** `epico-front/.claude/rules/mocks.md`

---

## ❓ 14. Pendientes de Definición

- Sin `[NEEDS CLARIFICATION]` críticos. (El de la hora visible en el estado
  deshabilitado vive en EF-50575 §9, no bloquea.)
