# language: es
# EF-50575 · Check-in / Check-out — los AC de la Spec, ejecutables.
# Los criterios canónicos viven como AC-XX en la Spec Funcional; este archivo los
# materializa 1:1 durante Construcción y SE EJECUTA:
# Reqnroll en ms-actividades (tests/features/) · e2e marcados corren con Playwright.

@EF-50575
Característica: Check-in de una actividad comercial
  Como asesor comercial
  quiero registrar el inicio y fin de mis visitas desde el móvil
  para que la coordinación vea el estado de mi día en tiempo real

  Antecedentes:
    Dado que Laura es asesora con la actividad "Visita Cliente Norte" asignada de 17:00 a 18:00

  @AC-01 @RN-03
  Escenario: Check-in dentro del horario
    Cuando Laura hace check-in a las 17:05
    Entonces la actividad queda "en curso"
    Y se registra la hora del servidor como inicio

  @AC-02 @RN-03
  Escenario: Check-in fuera del horario
    Cuando Laura intenta hacer check-in a las 14:30
    Entonces Epico impide la operación
    Y muestra el mensaje "Aún no inicia tu actividad"

  @AC-03 @RN-02
  Escenario: Solo una actividad en curso a la vez
    Dado que Laura tiene otra actividad "en curso"
    Cuando intenta hacer check-in en "Visita Cliente Norte"
    Entonces Epico impide la operación
    Y muestra el mensaje "Tienes otra actividad en curso: ciérrala primero"

  @AC-04
  Escenario: Check-out registra la duración
    Dado que Laura hizo check-in a las 17:05
    Cuando hace check-out a las 17:50
    Entonces la actividad queda "terminada"
    Y la duración registrada es de 45 minutos
    Y el coordinador ve el nuevo estado en su vista de equipo

  @manual
  Escenario: Legibilidad en exteriores
    # Decisión de QA: se valida a mano en piloto (brillo/contraste en calle), no se automatiza.
    Dado que el asesor usa el móvil a pleno sol
    Entonces los estados y botones deben distinguirse sin esfuerzo
