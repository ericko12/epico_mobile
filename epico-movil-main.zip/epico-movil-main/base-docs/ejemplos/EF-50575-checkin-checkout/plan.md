---
spec: EF-50575
tipo: plan-tecnico
autor: Dev-B + Claude Code
revisado_por: Arquitecto (aprobado 2026-09-15 — toca servicio compartido)
generado_por: skill plan-tecnico v1.0
---

# Plan técnico — EF-50575 · Check-in / Check-out

## 1. Enfoque en una frase
Extender `ms-actividades` con dos operaciones y un evento, front nuevo sobre
componentes existentes, integración vía contrato congelado.
Rama base: `release/2026-q4-c1` — los MR de esta spec apuntan ahí (ADR-002).
Spec: EF-50575 · SPEC-F2-002 · página 1659895864 (hash 5d8f440b) · UX-SPEC-F2-002
congelada en `spec-ux.snapshot.md` (hash 4a6160c7) — el front construye desde ahí.

## 2. Servicios afectados
| Servicio | Acción | ¿Compartido? | Implicación |
|---|---|---|---|
| `ms-actividades` | **Extender** (2 endpoints + 1 evento) | ⚠ Sí — lo consume Sistema Cobranza | Solo cambios **aditivos**; regresión sobre endpoints existentes |
| Gateway (Ocelot) | Ruta nueva `/actividades/*` → ms-actividades | — | Tarea explícita T06 |
| `ms-notificaciones` | Sin cambios (consume el evento nuevo) | No | Solo suscripción |

## 3. ¿Extender o crear servicio? (regla del modelo)
**Extender.** El dominio "actividades" ya tiene dueño (`ms-actividades`); crear un
servicio nuevo violaría la regla por defecto. No requiere ADR.

## 4. Contrato
`ms-actividades/contracts/openapi.json` — congelado 2026-09-15 (aprobación Arq.):
- `POST /v1/actividades/{id}/check-in` → 200 nuevo estado · 409 RN-02 · 422 RN-03
- `POST /v1/actividades/{id}/check-out` → 200 con duración
- `GET  /v1/actividades/dia` → lista del día con estado y horario
- Evento `actividad.checkin.registrado` v1 (RabbitMQ) — schema en el catálogo.
El front genera cliente + datos simulados **desde este contrato** (nada inventado).

## 5. Reutilización
Back: validador de horarios del módulo actividades, middleware de auditoría de la
plantilla. Front: `ListaActividades`, `TarjetaActividad`, `EtiquetaEstado`.

## 6. Datos
Nueva tabla `registro_asistencia` (actividad_id, asesor_id, checkin_at, checkout_at,
duracion). Índice por asesor+fecha. Migración aditiva — sin tocar tablas existentes.

## 7. Seguridad
Authz por asignación (RN-CI-001) en Application, no en el front. Auditoría estructurada
a Elastic (op, usuario, actividad, timestamp servidor). Idempotencia por actividad+op.

## 8. Observabilidad
Log estructurado `op=checkin|checkout` · métrica contador por resultado (ok/regla/error)
· alerta si tasa de error > umbral en 5 min.

## 9. Riesgos
| Riesgo | Mitigación |
|---|---|
| Reloj del dispositivo ≠ servidor | La hora válida es **siempre** la del servidor (RN-03 se evalúa ahí — RES-01) |
| Pico de carga 8–9 am (todos hacen check-in) | Cache Redis 5 min para `GET /dia`; escrituras directas |

## 10. Estrategia de pruebas
Reqnroll: los 4 AC (`@AC-01..04`) del `behavior.feature` + unitarias del validador.
Playwright: flujo feliz + error RN-03 y los UX-STATE verificables. CI: no-deriva del contrato.

## 11. Tareas propuestas (→ subtareas en Jira, con dueño)
| # | Tarea | Dueño sugerido | Toca |
|---|---|---|---|
| T01 | Contrato + fixtures | Dev-B | contracts/ |
| T02 | Cliente generado + mocks MSW | Dev-A | epico-front/src/mocks |
| T03 | Pantallas (UX-VIEW-01/02, estados UX-STATE) | UX | epico-front/features/actividades |
| T04 | Endpoints + validaciones RN-01..03 | Dev-B | ms-actividades ⚠ |
| T05 | Evento + suscripción | Dev-B | ms-actividades, catálogo |
| T06 | Ruta Ocelot + authz | Dev-B | gateway |
| T07 | Steps Reqnroll | QA | ms-actividades/tests |
| T08 | e2e Playwright | QA | epico-front |
