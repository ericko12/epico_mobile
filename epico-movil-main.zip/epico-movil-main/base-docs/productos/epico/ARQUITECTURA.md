# Arquitectura de la plataforma Epico (visión para humanos e IA)

> Lectura de inicio de toda sesión técnica. El detalle de cada servicio vive en su repo;
> aquí está el mapa. Dueño editorial: **Arquitecto** (cambios por MR).

## El mapa en 30 segundos

```text
Navegador (React · epico-front)
        │  HTTPS
        ▼
   Traefik (ingreso)
        ▼
   Ocelot (API Gateway: rutas, authz)     ← toda capacidad nueva registra aquí su ruta
        ▼
   ms-* · microservicios .NET 10 (contenedores en Docker Swarm / RHEL)
    │        │         │
    ▼        ▼         ▼
  Redis   RabbitMQ   Base de datos por servicio
 (cache)  (eventos)
    └──── logs y telemetría estructurados ────► Elastic
```

## Principios que la IA debe respetar
1. **Todos los servicios nacen de la plantilla** — misma estructura, mismas convenciones;
   si un repo se desvía, su `CLAUDE.md` lo anota.
2. **El acceso externo pasa por Ocelot** — ningún servicio se expone directo.
3. **Servicios compartidos = cambios aditivos** (ver `CATALOGO_SERVICIOS.md`).
4. Comunicación entre servicios: **eventos RabbitMQ** para hechos consumibles por otros;
   HTTP síncrono solo cuando la respuesta es parte de la operación.
5. Logs estructurados a Elastic con `op`, usuario y correlación; toda capacidad nueva
   define su telemetría en el `plan.md`.
6. Config por variables de entorno; secretos jamás en el repo.

## Entornos
`dev` (local/compose) → `integracion` (Swarm, aquí se apagan los mocks) →
`staging` (validación QA/PO) → `produccion` (liberación con feature flag).

## Decisiones registradas
Las decisiones de esta plataforma viven en `productos/epico/adr/`; las del modelo de
trabajo, en `docs/adr/` — una página por decisión, con su porqué.
