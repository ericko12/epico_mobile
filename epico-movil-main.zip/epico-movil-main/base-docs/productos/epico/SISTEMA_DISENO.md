# Sistema de diseño del front (catálogo para humanos e IA)

> La skill `front-feature` obliga a **buscar aquí antes de crear** cualquier componente.
> Un componente nuevo se propone con la marca `PROPUESTA-DS` en el MR y entra a este
> catálogo solo con acuerdo UX + Dev. Dueños: **UX + Dev front**.

## Componentes disponibles (`epico-front/src/components/`)

| Componente | Cuándo usarlo | Notas |
|---|---|---|
| `EncabezadoPagina` | Título + acciones de toda pantalla | Nunca armar encabezados a mano |
| `ListaActividades` | Listados con estado y hora | Ya maneja vacío y carga |
| `TarjetaActividad` | Elemento de actividad con acciones | Usada en check-in/out |
| `EtiquetaEstado` | Estado con color semántico | Estados nuevos se registran aquí |
| `BotonPrimario` / `BotonSecundario` | Acción principal / secundaria | Máx. 1 primario por vista |
| `Alerta` | Errores y avisos con mensaje de la Spec | Variantes: error, aviso, éxito |
| `CampoTexto` / `CampoFecha` | Formularios | Con validación y mensaje integrados |
| `ModalConfirmacion` | Confirmar acciones destructivas | No usar para flujos largos |
| `EstadoVacio` | Pantallas sin datos | Texto útil, nunca "no hay datos" |
| *<completar inventario en Semana 0>* | | |

## Reglas de uso (las mismas que carga la IA)
1. **Los 4 estados son obligatorios** en toda pantalla: éxito · vacío · error · carga.
2. **Los datos vienen del cliente generado del contrato** — prohibido hardcodear.
3. Los textos de error de reglas de negocio son **los de la Spec**, tal cual.
4. Tokens (colores, tipografía, espaciado) desde el tema — nunca valores sueltos.
5. Accesibilidad mínima: interactivos con etiqueta, navegable con teclado, contraste AA.
