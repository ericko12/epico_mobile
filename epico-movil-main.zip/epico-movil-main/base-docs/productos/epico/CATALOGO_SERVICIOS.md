# Catálogo de servicios de la plataforma

> **Regla: servicio que no está en este catálogo, no existe.** Todo servicio nuevo se
> registra aquí **en el mismo MR** que lo crea (la skill `nuevo-microservicio` lo hace).
> La columna *Consumidores* es la salvaguarda de los servicios compartidos: antes de
> tocar un contrato, revisa quién más lo usa.
>
> **Columna Contrato:** ruta a `contracts/openapi.json` (OpenAPI 3.x en JSON,
> redactado a mano y congelado antes de construir) dentro del repo del servicio dueño
> — no la URL runtime que el propio servicio .NET 10 expone (`/openapi/v1.json`); esa
> es solo para que el CI la compare contra el archivo congelado, nunca la fuente.

## Microservicios
| Servicio | Propósito | Dueño | Contrato | Consumidores | ¿Compartido? | Versiones |
|---|---|---|---|---|---|---|
| SucursalService | Datos de sucursales: listado, estatus, direcciones, directorio | Ferrari | http://sucursalesservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2 |
| StockService | Existencia de productos por sucursal | Redbull | http://Stock_Service.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| regionshymcservice | Regiones comerciales asociadas a sucursales por cliente | Redbull | http://regionshymcservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| SeguridadProyectoService | Validación de permisos de acceso (objeto/proyecto) por sucursal | Ferrari | http://seguridadproyectoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v3 |
| EpicoService | Usuarios, roles y empleados internos de Epico | Ferrari | http://epicousuarioservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | NO | v1 |
| IdentityService | Autenticación (emisión de token vía `connect/token`) | Ferrari | NA | Epico Móvil | ⚠ Sí | N/A |
| FacturacionInfoService | Facturas pendientes de pago y envío de CFDI por correo | Mercedes | http://facturacioninfo.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2 |
| CreditoPedidosRetenidosService | Política de retención de pedidos por crédito | Mercedes | http://pedidosretenidos.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| EvidenciaEntregaService | Envío de reportes/evidencia de facturas | Mercedes | http://evidenciaentregaservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| NotasCreditoService | Notas de crédito del cliente | Mercedes | http://notascreditoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v2 |
| PoliticaComercialService | Parámetros de política comercial por cliente | Ferrari | http://politicacomercialservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| ProductoService | Datos y validación de productos (ficha técnica, validación, consulta por cliente) | Ferrari | http://productoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2, v3 |
| RutasService | Visitas de vendedor a cliente por ruta | Ferrari | http://rutasasesorservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| SMCService | Motor de evaluación SMC (mini-caja / condiciones especiales) para pedidos | Ferrari | http://smcservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| PasarelaPagoService | Pasarela de pago de pedidos | Ferrari | http://pasarelapagoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| PedidoService | Núcleo de pedidos: creación, montos, cotizaciones, división, preferencias de envío | Ferrari | http://pedidoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v3, v4 |
| PrecioEspecialService | Precios especiales por cliente/producto | Ferrari | http://precioespecialservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2 |
| PriceListService | Listas de precio por cliente | Ferrari | http://pricelistservice.apymsa-testsvr.apymsa.com.mx/swagger/v2/swagger.json | Epico Móvil | ⚠ Sí | v2 |
| ReporteVentasApiService | Reportes de ventas: histórico de precio facturado, indicadores de desempeño | Ferrari | http://reporteventasapi.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| PoolServicios | Pool de servicios: liberación y consulta de activos de pedidos en pool | Mercedes | http://poolservicios.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2, v3 |
| SolicitudPedidoService | Solicitudes de pedido: rechazo y motivos de rechazo | Ferrari | http://solicitudpedidoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| CatalogoExtendidoService | Catálogo extendido de productos genéricos (TLC) | Ferrari | http://catalogoextendidoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| EstadisticaService | Estadísticas de productos (ej. dejados de comprar) | Ferrari | http://estadisticaservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| ProductoCicloDeVidaService | Ciclo de vida / etapas de productos | Mercedes | http://ProductoCicloDeVidaApi.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| PromocionService | Promociones de productos | Ferrari | http://promocionservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2, v3 |
| SatApi | Validación y sugerencia de claves SAT de producto | Mercedes | http://sat.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| DireccionesService | Direcciones de clientes/sucursales y paqueterías por dirección | Ferrari | http://direccionservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1, v2, v3 |
| AdminExcepciones | Excepciones de configuración de dirección de cliente | Redbull | http://adminexcepciones.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| CatalogService | Catálogo de servicios de entrega: portes y concesiones | Ferrari | http://catalogservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| CourierService | Paqueterías/couriers activos | Redbull | http://couriersservice.apymsa-testsvr.apymsa.com.mx/swagger/iv1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| EvaluadorSMC4 | Evaluador SMC4: cálculo y verificación de existencia | Redbull | http://smc4-alg-evaluador.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| VendedorService | Datos de vendedor por empleado / jefe directo | Ferrari | http://vendedorservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| LeadService | Leads de telemarketing | Ferrari | http://LeadService.apymsa-testsvr.apymsa.com.mx/swagger/v2/swagger.json | Epico Móvil | ⚠ Sí | v2 |
| GarantiaDevolucionService | Garantías y devoluciones de producto | Ferrari | http://garantiadevolucionservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| ServicioLigero | Catálogo auxiliar de vehículos/refacciones (años, marcas, categorías) | Ferrari | http://servicioligeroservice.apymsa-testsvr.apymsa.com.mx/swagger/v2/swagger.json | Epico Móvil | ⚠ Sí | v2 |
| IApymsa.Search | Búsqueda de productos (motor de búsqueda nuevo, switch de transporte propio) | Ferrari| http://iapymsa-search-service.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | No | v1 |
| ClienteService | Datos de clientes y clientes-vendedores: contactos, clasificaciones, información general, límite de crédito | Ferrari | http://clienteservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v2, v3 |
| CreditoService | Estatus de crédito del cliente-vendedor y envío de estado de cuenta | Ferrari | http://creditoservice.apymsa-testsvr.apymsa.com.mx/swagger/v1/swagger.json | Epico Móvil | ⚠ Sí | v2 |
| NotificacionesApi | Suscripción a notificaciones | Ferrari | http://notificacionesapi.apymsa-testsvr.apymsa.com.mx/swagger/v1.0/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| PlanLealtadApi | Plan de lealtad: clientes LMS, puntos, beneficios y conversiones | Ferrari | http://planlealtad.apymsa-testsvr.apymsa.com.mx/swagger/v1.0/swagger.json | Epico Móvil | ⚠ Sí | v1 |
| tdc-ingestionevento | Registro de eventos del ciclo de vida de pedidos (webhook) y resolución de `correlationId` para monitoreo en Torre de Control | Redbull | http://tdc-ingestionevento.apymsa-testsvr.apymsa.com.mx/swagger/v1.0/swagger.json | Epico Móvil | ⚠ Sí | v1 |



> Candidatas agregadas por `catalogar-dependencias` el 2026-09-11, generadas desde
> `epico-movil` (repo consumidor) cruzando sus endpoints reales contra el `ocelot.json`
> del API gateway (`epicoapigateway`) — Dueño y Contrato pendientes de que el
> Arquitecto los confirme. El cruce fue por ruta literal (no por substring), pero
> sigue siendo un candidato, no un hecho de arquitectura.
>
> Casos para revisar con especial atención:

>
> Candidata agregada por `catalogar-dependencias` el 2026-09-18, generada desde
> `epico-movil` — feature `ControlTowerLogs`. **No pasa por `epicoapigateway`/Ocelot**:
> tiene transporte propio (`TORRECONTROL_API` en `axios/axios_helper.ts`, baseURL
> `NEXT_PUBLIC_BASE_TORREDECONTROL_GATEWAY=/api/tdc`) que `next.config.mjs` reescribe
> directo a `NEXT_PUBLIC_TDC_GATEWAY_URL` (`http://tdc-gateway.apymsa-<amb>svr.apymsa.com.mx/api/v1/...`),
> sin pasar por el proxy BFF (`/api/proxy`) ni por Redis/Authorization. El código solo
> mostraba el hostname del gateway (`tdc-gateway`), no el nombre real del servicio
> detrás. Dos endpoints vistos: `POST /Webhook` (alta de evento) y
> `GET /CorrelationResolver/{orderId}/{branchId}` (resolución de correlationId). Único
> consumidor hoy: `features/orders/infraestructure/ui/Cancellation/ModalRequestCancellation`
> (cancelación de pedido).
>
> Confirmada el 2026-09-18 por Jose Nuño: el servicio real detrás del gateway es
> `tdc-ingestionevento` (ambos endpoints le pegan al mismo servicio), Dueño Redbull,
> compartido, solo v1 — ya está en la tabla de arriba sin marca de candidato.



## Eventos (RabbitMQ) — también son contrato

| Evento | Versión | Productor | Consumidores | Schema |
|---|---|---|---|---|

## Reglas

1. **Servicios compartidos: cambios aditivos únicamente.** Un cambio que rompe exige
   nueva versión del endpoint/evento + ADR + aviso a cada consumidor listado.
2. Todo cambio a `contracts/` pasa por MR con aprobación del **Arquitecto**.
3. Los eventos siguen el naming `<contexto>.<entidad>.<accion>` y versionan su schema.
4. Este archivo cambia por MR; dueño editorial: **Arquitecto**.
