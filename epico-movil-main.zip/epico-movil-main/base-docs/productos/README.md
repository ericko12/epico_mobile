# productos/ — lo propio de cada producto

La raíz de `base-docs` es **transversal**: plantillas, guías de IA, estándares, el mapa
de campos de Jira, los ADRs del modelo y el ejemplo dorado. Todo eso aplica igual a
cualquier proyecto.

Lo que **cambia de un producto a otro** vive aquí, en una carpeta por producto:

```text
productos/<producto>/
├── ARQUITECTURA.md          el mapa de esa plataforma
├── CATALOGO_SERVICIOS.md    sus servicios y eventos — «si no está aquí, no existe»
├── SISTEMA_DISENO.md        el catálogo de componentes de su front
└── adr/                     las decisiones técnicas propias de ese producto
```

**Cómo sabe la IA cuál le toca:** el `CLAUDE.md` de cada repo de código declara su
producto (línea `Producto:`), y de ahí salen las rutas
`base-docs/productos/<producto>/…`. Un producto nuevo se agrega copiando esta
estructura — nada más se toca.

**Dónde va cada ADR:** las decisiones del **modelo** (cómo trabajamos) van en
`docs/adr/`; las decisiones de **una plataforma** (crear un microservicio, cambiar un
patrón de integración) van en `productos/<producto>/adr/`.
