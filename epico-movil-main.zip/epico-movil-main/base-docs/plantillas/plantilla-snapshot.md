# Plantilla de snapshot (la aplica la skill `inicio-tarea` — nadie la llena a mano)

El snapshot es la **copia verbatim** de la página de Confluence de la Spec, tal como la
devuelve el MCP de Atlassian en Markdown (ADR-005). La identidad es la **clave del
issue** (p. ej. `EF-50620`); el **folio** de la página (`SPEC-F1-003`) va como referencia.
Cómo se encuentra la página desde la clave: `base-docs/docs/ENLACE_SPEC_CONFLUENCE.md`.

```markdown
---
spec: <CLAVE-JIRA>                       # p. ej. EF-50620 — identidad de la Spec
folio: <folio de la página>              # p. ej. SPEC-F1-003 (cabecera de la página)
tipo: funcional                          # proyecto | funcional | ux
titulo: <título de la página>
spec_proyecto: <CLAVE del #Release> · <folio PROJ-SPEC-…> · página <id>
spec_ux: <folio UX-SPEC-…> · página <id> · <Ready for Dev | Borrador> | —
origen: Confluence · espacio <PE> · página <id> «<título>» · modificada <fecha que reporta Confluence> · cabecera Versión <n> · Estado <estado>
resuelto_por: enlace-remoto | folio-en-titulo | mencion-en-pagina | manual   # UX: cabecera-funcional · Proyecto: claude-md | titulo-proyecto
anexos: <ids de páginas complementarias confirmadas> | ninguno
contenido_hash: sha256:<64 hex>          # ← la deriva se detecta comparando esto
estado_pagina_al_congelar: Ready for Dev # o "Borrador (forzado por <nombre>)"
estado_issue_al_congelar: <Definition | Development>
rama: <CLAVE-JIRA>/<nombre-corto>
generado_por: skill inicio-tarea v<versión>
---

# ⚠ SNAPSHOT — Copia congelada de la página de Confluence de <CLAVE-JIRA> (<folio>). No editar este archivo.
> La Spec se edita **en su página de Confluence**. Si la página cambia durante la
> construcción, el hash deja de coincidir: la skill lo avisa. El refresco es un commit
> visible (`/inicio-tarea <CLAVE> --refresh`).

<CUERPO DE LA PÁGINA, VERBATIM: cabecera numerada + las 9 secciones + la checklist
«Validación para Ready for Dev». Sin resumir, sin reordenar, sin omitir.>

<ANEXOS confirmados, si los hay, cada uno bajo
"## Anexo <A|B> · <título de la página> (página <id>)" y su cuerpo verbatim.>
```

**Validación de CI** (job `check-snapshot` en ramas `<CLAVE>/*`): existe el archivo ·
el front matter trae `spec`, `contenido_hash`, `origen` y `generado_por` · el valor de
`spec` coincide con el prefijo del nombre de la rama (patrón `[A-Z][A-Z0-9]+-[0-9]+`) ·
el `contenido_hash` tiene forma de SHA-256 · `estado_pagina_al_congelar` es
`Ready for Dev` o trae la marca `forzado por`. Si algo falta → pipeline rojo con el
mensaje de qué faltó. *(Opcional, si el runner tiene credencial de lectura a Confluence:
recalcular el hash con la regla de `ENLACE_SPEC_CONFLUENCE.md §5` y avisar de la deriva
en el MR.)*

**Spec UX:** si la cabecera de la funcional referencia una `UX-SPEC-…` y su página está
en `Ready for Dev`, `inicio-tarea` genera además `spec-ux.snapshot.md` con este mismo
formato: `tipo: ux`, `folio: UX-SPEC-…`, `spec_funcional: <folio> · página <id>`, su
propio `contenido_hash` y en `spec:` la **misma clave** de la funcional (la UX no tiene
issue propio). Banner: `# ⚠ SNAPSHOT UX — …`. Mismas reglas: no se edita a mano y se
refresca solo con commit explícito.

**Spec de Proyecto:** `inicio-tarea` genera también `spec-proyecto.snapshot.md`
(`tipo: proyecto`, la página `00_SPEC_PROYECTO_…`) para que las **definiciones y
restricciones transversales** (§4 de esa plantilla) viajen en la rama. Se omite con
`--sin-proyecto` si la página no existe o el equipo decide no arrastrarla.

**Hash:** SHA-256 del cuerpo Markdown normalizado (saltos `\n`, sin espacios finales,
sin líneas en blanco al inicio/fin; anexos concatenados con `\n\n---\n\n`), en UTF-8. El
front matter y el banner no entran. Regla completa en `ENLACE_SPEC_CONFLUENCE.md §5`.
