# Plantilla de bitácora (comentario en Jira — la publica la skill `cierre-tarea`)

```markdown
**📓 Bitácora · <AAAA-MM-DD am/pm> · <Rol/Nombre> (+ Claude Code)**

- **Hecho:** <qué se completó, con referencia a tareas Txx>
- **Decisiones:** <las tomadas en la sesión, con enlace — o "ninguna">
  <Si alguna cambia el COMPORTAMIENTO: no va aquí, va a la Spec ese mismo día.>
- **Sigue:** <la siguiente acción concreta>
- **Bloqueos:** <qué y quién lo destraba — o "ninguno">  **MRs:** <!nn estado>
```

**Reglas:** máximo ~6 líneas — es un traspaso, no un reporte. Una entrada por sesión de
trabajo, siempre en el Work Item de la Spec. Si alguien tardó >10 minutos en re-descubrir
algo, faltó una entrada aquí (se anota en la retro).
