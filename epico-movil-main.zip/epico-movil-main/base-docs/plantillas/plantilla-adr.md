# Plantilla de ADR (registro de decisión de arquitectura)

> Un ADR por decisión técnica, numerado consecutivo. **Decisiones del modelo** (cómo
> trabajamos) → `docs/adr/`; **decisiones de una plataforma** (crear un microservicio,
> cambiar un patrón de integración) → `productos/<producto>/adr/`.
> Corto: si pasa de una página, son dos decisiones. Dueño: Arquitecto.

```markdown
# ADR-XXX — <La decisión, enunciada como afirmación>

**Estado:** Propuesta | Aceptada | Reemplazada por ADR-YYY · <fecha> · **Dueño:** <quién>

## Contexto
<Qué problema o fuerza motiva la decisión. 3–5 líneas.>

## Decisión
<Qué se decidió, en presente y sin ambigüedad.>

## Consecuencias
- (+) <lo que se gana>
- (−) <lo que se paga, y cómo se mitiga>

## Referencias
<Spec/MR/documento que la originó.>
```
