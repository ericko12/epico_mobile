# Plantilla de plan técnico (la aplica la skill `plan-tecnico`; se revisa en el MR)

```markdown
---
spec: <SPEC-XXX>
tipo: plan-tecnico
autor: <Dev> + Claude Code
revisado_por: <Arquitecto — OBLIGATORIO si toca varios servicios, seguridad, datos
              o un servicio compartido; si no, el propio Dev lo indica>
generado_por: skill plan-tecnico v<versión>
---

# Plan técnico — <SPEC-XXX · nombre>

## 1. Enfoque en una frase
## 2. Servicios afectados
| Servicio | Acción (extender/crear/consumir) | ¿Compartido? | Implicación |
|---|---|---|---|
## 3. ¿Extender o crear servicio?
<Regla por defecto: extender el dueño del dominio. Crear = ADR que lo justifique.>
## 4. Contrato
<Endpoints/eventos nuevos o modificados + fecha de congelado + aprobación.>
## 5. Reutilización
<Qué ya existe y se usa: módulos, validadores, componentes.>
## 6. Datos
<Tablas/campos nuevos; migraciones SIEMPRE aditivas en servicios compartidos.>
## 7. Seguridad
<Authz, auditoría, idempotencia.>
## 8. Observabilidad
<Logs, métricas y alertas que esta capacidad estrena.>
## 9. Riesgos
| Riesgo | Mitigación |
|---|---|
## 10. Estrategia de pruebas
<Reqnroll (escenarios @SPEC) · unitarias · e2e Playwright · no-deriva del contrato.>
## 11. Tareas propuestas (→ subtareas en Jira, con dueño)
| # | Tarea | Dueño | Toca |
|---|---|---|---|
```
