# ?? [Nombre de la Funcionalidad / Experiencia]

1. **Spec UX/UI:** [UX-SPEC-XXX]
2. **Spec Funcional:** [SPEC-XXX]
3. **Spec de Proyecto / Iniciativa:** [PROJ-SPEC-XXX]
4. **Responsable UX:** [Nombre]
5. **Version:** 0.1
6. **Ultima actualizacion:** DD-MM-YYYY
7. **Estado:** [Borrador / Definicion / Ready for Dev / En Construccion / Validada]

---

## ?? 1. Intencion de Experiencia

1. **Objetivo de experiencia:** [Objetivo]
2. **Problema de experiencia que se busca resolver:** [Dolor / friccion / necesidad]
3. **Resultado esperado para el usuario:** [Resultado]
4. **Principios de experiencia particulares:**
   - **UX-PRI-01.** [Principio]
   - **UX-PRI-02.** [Principio]

---

## ?? 2. Flujo de Experiencia TO-BE

### Flujo principal

1. **UX-FLU-01 �X [Nombre del flujo]**
   1. **Punto de entrada:** [Origen]
   2. **Objetivo del usuario:** [Objetivo]
   3. **Paso 1:** [Accion / interaccion]
   4. **Paso 2:** [Accion / interaccion]
   5. **Paso 3:** [Accion / interaccion]
   6. **Resultado:** [Resultado]

### Flujos alternos

- **UX-FLU-02 �X [Nombre del flujo alterno]:** [Descripcion]
- **UX-FLU-03 �X [Nombre del flujo alterno]:** [Descripcion]

---

## ??? 3. Inventario de Pantallas / Vistas

### UX-VIEW-01 �X [Nombre de pantalla / vista]

- **Proposito:** [Descripcion]
- **Entrada desde:** [Origen]
- **Salida hacia:** [Destino]
- **Referencia Figma:** [URL / Frame]
- **Referencia visual:** [URL / Imagen / No aplica]

### UX-VIEW-02 �X [Nombre de pantalla / vista]

- **Proposito:** [Descripcion]
- **Entrada desde:** [Origen]
- **Salida hacia:** [Destino]
- **Referencia Figma:** [URL / Frame]
- **Referencia visual:** [URL / Imagen / No aplica]

---

## ?? 4. Estructura y Jerarquia de la Interfaz

### UX-VIEW-01 �X [Nombre]

1. **Estructura principal:**
   - [Encabezado]
   - [Area principal]
   - [Panel / seccion]
   - [Acciones]
   - [Pie / navegacion]

2. **Jerarquia de informacion:**
   - **Primaria:** [Informacion / accion]
   - **Secundaria:** [Informacion]
   - **Complementaria:** [Informacion]

3. **Accion principal:** [Accion]

4. **Acciones secundarias:**
   - [Accion]
   - [Accion]

5. **Consideraciones particulares:**
   - [Regla de composicion]
   - [Orden]
   - [Prioridad]
   - [Visibilidad]

---

## ?? 5. Componentes y Design System

### Fuentes heredadas

- **Catalogo de componentes Front:** [`SISTEMA_DISENO.md` / Ruta]
- **Reglas de gobierno del DS:** [`design-system.md` / Ruta]
- **Design System / Figma:** [URL / referencia]
- **Libreria Front:** [Repositorio / ruta]

### Componentes utilizados por esta funcionalidad

#### UX-COMP-01 �X [Nombre / proposito]

- **Componente existente:** [Nombre exacto]
- **Vista donde se utiliza:** [UX-VIEW-XX]
- **Uso en esta experiencia:** [Uso]
- **Variante / configuracion:** [Variante / Default]
- **Comportamiento particular:** [Descripcion / No aplica]
- **Estados particulares:** [Descripcion / No aplica]
- **Referencia Figma:** [Frame / componente / No aplica]
- **Decision:** [Reutilizar / Extender]

#### UX-COMP-02 �X [Nombre / proposito]

- **Componente existente:** [Nombre exacto]
- **Vista donde se utiliza:** [UX-VIEW-XX]
- **Uso en esta experiencia:** [Uso]
- **Variante / configuracion:** [Variante / Default]
- **Comportamiento particular:** [Descripcion / No aplica]
- **Estados particulares:** [Descripcion / No aplica]
- **Referencia Figma:** [Referencia]
- **Decision:** [Reutilizar / Extender]

### Componentes nuevos requeridos

- **UX-NEW-01 �X `PROPUESTA-DS`:** [Nombre conceptual]
  - **Necesidad:** [Necesidad]
  - **Justificacion:** [Justificacion]
  - **Comportamiento / variantes:** [Descripcion]
  - **Estados:** [Estados]
  - **Referencia Figma:** [URL / Frame]
  - **Validacion requerida:** [UX + Dev Front]

---

## ??? 6. Interacciones y Comportamientos

### UX-INT-01 �X [Nombre de interaccion]

- **Elemento:** [Componente / control]
- **Disparador:** [Evento]
- **Comportamiento esperado:** [Descripcion]
- **Resultado visual:** [Resultado]
- **Condicion:** [Condicion]
- **Referencia funcional:** [RF-XX / RN-XX / AC-XX / No aplica]
- **Referencia visual:** [Figma / prototipo / frame]

### UX-INT-02 �X [Nombre de interaccion]

- **Elemento:** [Componente / control]
- **Disparador:** [Evento]
- **Comportamiento esperado:** [Descripcion]
- **Resultado visual:** [Resultado]
- **Condicion:** [Condicion]
- **Referencia funcional:** [RF-XX / RN-XX / AC-XX / No aplica]
- **Referencia visual:** [Referencia]

---

## ?? 7. Estados de la Experiencia

### UX-STATE-01 �X Estado inicial

- **Condicion:** [Condicion / referencia funcional]
- **Elementos visibles:** [Elementos]
- **Acciones disponibles:** [Acciones]
- **Comportamiento esperado:** [Descripcion]

### UX-STATE-02 �X Estado vacio

- **Condicion:** [Condicion / referencia funcional]
- **Mensaje:** [UX-MSG-XX / referencia]
- **Accion disponible:** [Accion]
- **Comportamiento esperado:** [Descripcion]

### UX-STATE-03 �X Estado de carga

- **Condicion:** [Evento]
- **Indicador:** [Skeleton / Spinner / Progress / componente DS]
- **Elementos bloqueados:** [Elementos / Ninguno]
- **Comportamiento esperado:** [Descripcion]

### UX-STATE-04 �X Estado de error

- **Condicion:** [RN-XX / EX-XX / AC-XX / situacion]
- **Mensaje:** [UX-MSG-XX / referencia canonica]
- **Presentacion:** [Alerta / Inline / Modal / Otro]
- **Accion de recuperacion:** [Reintentar / Regresar / Corregir / Otro]
- **Comportamiento esperado:** [Descripcion]

### UX-STATE-05 �X Estado exitoso

- **Condicion:** [Resultado / AC-XX]
- **Feedback:** [Toast / mensaje / cambio de estado / navegacion]
- **Siguiente accion:** [Descripcion]

### UX-STATE-06 �X Estado deshabilitado

- **Condicion:** [RN-XX / PER-XX / condicion]
- **Elementos afectados:** [Elementos]
- **Motivo visible al usuario:** [Si / No / Descripcion]

---

## ?? 8. Formularios, Datos y Validaciones Visuales

### UX-DAT-01 �X [Campo / dato]

- **Referencia funcional:** [DAT-XX / RN-XX]
- **Componente:** [Componente DS]
- **Etiqueta:** [Texto / UX-TXT-XX]
- **Placeholder:** [Texto / No aplica]
- **Ayuda contextual:** [Texto / No aplica]
- **Indicador visual de obligatorio:** [Comportamiento / heredado del DS]
- **Presentacion de validacion:** [Inline / resumen / otro]
- **Mensaje visible:** [UX-MSG-XX / referencia canonica]
- **Formato de presentacion:** [Formato visual / No aplica]

### UX-DAT-02 �X [Campo / dato]

- **Referencia funcional:** [DAT-XX / RN-XX]
- **Componente:** [Componente DS]
- **Etiqueta:** [Texto]
- **Placeholder:** [Texto / No aplica]
- **Ayuda contextual:** [Texto / No aplica]
- **Indicador visual de obligatorio:** [Comportamiento / heredado del DS]
- **Presentacion de validacion:** [Comportamiento]
- **Mensaje visible:** [UX-MSG-XX / referencia canonica]
- **Formato de presentacion:** [Formato visual]

---

## ?? 9. Textos de Interfaz y Feedback

### Mensajes

- **UX-MSG-01 �X Confirmacion:** [Texto / referencia]
- **UX-MSG-02 �X Error:** [Texto / referencia canonica]
- **UX-MSG-03 �X Advertencia:** [Texto / referencia]
- **UX-MSG-04 �X Exito:** [Texto / referencia]
- **UX-MSG-05 �X Estado vacio:** [Texto / referencia]

### Etiquetas relevantes

- **UX-TXT-01.** [Elemento] �� "[Texto]"
- **UX-TXT-02.** [Elemento] �� "[Texto]"

### Reglas de contenido particulares

- [Tono]
- [Terminologia]
- [Palabras a evitar]
- [Convencion]

---

## ?? 10. Adaptabilidad (Responsive), Dispositivos y Accesibilidad

### Consideraciones particulares de dispositivo / Responsive

- **UX-RESP-01.** [Comportamiento]
- **UX-RESP-02.** [Comportamiento]
- **UX-RESP-03.** [Comportamiento]

### Consideraciones particulares de accesibilidad

- **UX-ACC-01.** [Condicion]
- **UX-ACC-02.** [Condicion]
- **UX-ACC-03.** [Condicion]

---

## ?? 11. Transiciones, Animaciones y Feedback Visual

- **UX-MOTION-01.**
  - **Elemento:** [Elemento]
  - **Evento:** [Evento]
  - **Comportamiento:** [Transicion / animacion]
  - **Proposito:** [Proposito]

- **UX-MOTION-02.**
  - **Elemento:** [Elemento]
  - **Evento:** [Evento]
  - **Comportamiento:** [Descripcion]
  - **Proposito:** [Proposito]

---

## ?? 12. Restricciones y Consideraciones UX/UI

- **UX-RES-01.** [Restriccion]
- **UX-RES-02.** [Restriccion]
- **UX-RES-03.** [Restriccion]

---

## ?? 13. Referencias

1. **Spec Funcional:** [SPEC-XXX / URL]
2. **Spec de Proyecto:** [PROJ-SPEC-XXX / URL]
3. **Discovery:** [URL / referencia]
4. **Prototipo / Figma:** [URL]
5. **Blueprint / User Flow:** [URL / No aplica]
6. **Catalogo Front / `SISTEMA_DISENO.md`:** [Ruta]
7. **Reglas DS / `design-system.md`:** [Ruta]
8. **Libreria de Componentes Front:** [URL / repositorio]
9. **Estandares Front:** [Ruta / URL]
10. **Reglas Generales del Proyecto:** [Ruta / URL]
11. **Contrato / OpenAPI:** [Ruta / URL / No aplica]
12. **Reglas de mocks:** [Ruta / No aplica]
13. **Contexto de IA / conversacion:** [URL]
14. **Prompt de Implementacion Front:** [Ruta / No aplica]
15. **Otros:** [URL / referencia]

---

## ? 14. Pendientes de Definicion

- **[NEEDS CLARIFICATION]** [Pregunta o definicion pendiente]
- **[NEEDS CLARIFICATION]** [Pregunta o definicion pendiente]
- **[NEEDS CLARIFICATION]** [Pregunta o definicion pendiente]

---

## ? Validacion UX/UI para Ready for Dev

- [ ] Spec Funcional asociada, vigente y sin definiciones funcionales criticas pendientes.
- [ ] Intencion de experiencia definida.
- [ ] Flujo de experiencia TO-BE definido cuando aplica.
- [ ] Pantallas / vistas a implementar identificadas.
- [ ] Prototipo / Figma disponible cuando aplica.
- [ ] Jerarquia y acciones principales claras.
- [ ] Componentes existentes del catalogo identificados para esta funcionalidad.
- [ ] Extensiones o `PROPUESTA-DS` justificadas cuando aplican.
- [ ] Interacciones relevantes definidas sin duplicar reglas funcionales.
- [ ] Estados vacio, carga, error y exito definidos para la experiencia cuando aplican.
- [ ] Estado deshabilitado e inicial definidos cuando aportan a la implementacion.
- [ ] Presentacion de validaciones y errores definida cuando aplica.
- [ ] Textos relevantes definidos o referenciados a su fuente canonica.
- [ ] Comportamiento Responsive particular definido cuando aplica.
- [ ] Condiciones particulares de accesibilidad definidas cuando aplican.
- [ ] Restricciones UX/UI particulares identificadas.
- [ ] Referencias a DS, catalogo Front y estandares vinculadas.
- [ ] No existen `[NEEDS CLARIFICATION]` criticos.
- [ ] DEV cuenta con informacion suficiente para implementar la experiencia.
- [ ] La IA cuenta con contexto suficiente para generar una primera implementacion sin inventar decisiones criticas.
