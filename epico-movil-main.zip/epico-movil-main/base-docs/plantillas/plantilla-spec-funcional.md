# 📄 [Nombre de la Funcionalidad / Feature]

1. **Spec Funcional:** [SPEC-XXX]
2. **Spec UX/UI asociada:** [UX-SPEC-XXX / No aplica]
3. **Spec de Proyecto / Iniciativa:** [PROJ-SPEC-XXX]
4. **Responsable BA:** [Nombre]
5. **Versión:** 0.1
6. **Última actualización:** DD-MM-YYYY
7. **Estado:** [Borrador / Definición / Ready for Dev / En Construcción / Validada]

---

## 🎯 1. Resumen y Contexto

- **Necesidad / Problema específico:** [Descripción]
- **Objetivo:** [Resultado esperado]
- **Relación con el objetivo del Proyecto:** [Descripción]
- **Valor de negocio específico:** [Descripción / No aplica]

---

## 👥 2. Usuarios y Responsables

- **Público objetivo:**
  - **Usuarios y Áreas beneficiadas:** [Roles y Áreas]
  - **Usuarios y Áreas que utilizarán la funcionalidad:** [Roles y Áreas]
  - **Usuarios y Áreas impactadas:** [Roles y Áreas]

- **Responsables de la Spec:**
  - **PO:** [Nombre]
  - **BA:** [Nombre]
  - **UX:** [Nombre / No aplica]
  - **DEV:** [Nombre]
  - **QA:** [Nombre]
  - **ARQ:** [Nombre / No aplica]

---

## 💡 3. Alcance y Consideraciones Iniciales

- **En el alcance (In Scope):**
  - [Capacidad / comportamiento]
  - [Capacidad / comportamiento]
  - [Capacidad / comportamiento]

- **Fuera del alcance (Out of Scope):**
  - [Capacidad / comportamiento]
  - [Capacidad / comportamiento]

- **Criterios de éxito:**
  - **CRI-01.** [Resultado observable o medible]
  - **CRI-02.** [Resultado observable o medible]

- **Riesgos a considerar:**
  - **RISG-01.** [Riesgo]
  - **RISG-02.** [Riesgo]

- **Dependencias a considerar:**
  - **DEP-01.** [Sistema / funcionalidad / Spec / equipo / dato / integración]
  - **DEP-02.** [Dependencia]

- **Supuestos no validados:**
  - **SUP-01.** [Supuesto]
  - **SUP-02.** [Supuesto]

---

## 🔄 4. Flujo y Comportamiento Esperado

- **Flujo principal:**
  1. [Condición / punto de inicio]
  2. [Acción del usuario o sistema]
  3. [Comportamiento funcional esperado]
  4. [Validación / procesamiento]
  5. [Resultado final]

- **Escenarios alternos / excepciones:**
  - **EX-01.** [Situación y comportamiento funcional esperado]
  - **EX-02.** [Situación y comportamiento funcional esperado]

---

## ⚙️ 5. Requisitos y Reglas de Negocio

### Requisitos funcionales

- **RF-01.** [Requisito funcional]
- **RF-02.** [Requisito funcional]
- **RF-03.** [Requisito funcional]

### Reglas de negocio

- **RN-01.** [Regla de negocio]
- **RN-02.** [Regla de negocio]

### Datos y validaciones

- **DAT-01. [Nombre del dato]**
  - **Descripción:** [Descripción]
  - **Origen:** [Usuario / Sistema / Integración / Otro]
  - **Obligatorio:** [Sí / No]
  - **Editable:** [Sí / No]
  - **Validación:** [Condición]
  - **Comportamiento si no es válido:** [Resultado funcional esperado]

- **DAT-02. [Nombre del dato]**
  - **Descripción:** [Descripción]
  - **Origen:** [Usuario / Sistema / Integración / Otro]
  - **Obligatorio:** [Sí / No]
  - **Editable:** [Sí / No]
  - **Validación:** [Condición]
  - **Comportamiento si no es válido:** [Resultado funcional esperado]

### Permisos

- **PER-01.** [Rol / permiso / condición]
- **PER-02.** [Rol / permiso / condición]
- **PER-03.** [Rol / permiso / condición]

---

## ✅ 6. Criterios de Aceptación

- **AC-01 — [Nombre del escenario]:**
  - **Dado que** [condición o contexto inicial]
  - **Cuando** [acción, evento o condición]
  - **Entonces** [resultado observable esperado]

- **AC-02 — [Nombre del escenario]:**
  - **Dado que** [condición o contexto inicial]
  - **Cuando** [acción, evento o condición]
  - **Entonces** [resultado observable esperado]

---

## 🛡️ 7. Requisitos No Funcionales

- **NFR Rendimiento:**
  - **NFR-PERF-01.** [Condición]

- **NFR Seguridad:**
  - **NFR-SEC-01.** [Condición]

- **NFR Arquitectura:**
  - **NFR-ARQ-01.** [Condición]

- **NFR Integración / Datos:**
  - **NFR-INT-01.** [Condición]

- **Otros NFR específicos:**
  - **NFR-OTR-01.** [Condición]

---

## 🔗 8. Impactos, Restricciones y Referencias

### Impactos

- **IMP-01.** [Proceso / sistema / módulo / funcionalidad afectada]
- **IMP-02.** [Impacto]

### Restricciones descubiertas

- **RES-01.** [Restricción]
- **RES-02.** [Restricción]

### Referencias

- **Spec de Proyecto:** [PROJ-SPEC-XXX]
- **Spec UX/UI:** [UX-SPEC-XXX / No aplica]
- **Contexto de IA / conversación:** [URL]
- **Discovery:** [URL / referencia]
- **Documentación funcional / negocio:** [URL]
- **Spec relacionada:** [SPEC-XXX]
- **Sistema / funcionalidad actual:** [URL / referencia]
- **Contrato / OpenAPI:** [Ruta / URL / No aplica]
- **BDD `.feature`:** [Ruta / se agrega durante Construcción]
- **Otros:** [URL / referencia]

---

## ❓ 9. Pendientes de Definición

- **[NEEDS CLARIFICATION]** [Pregunta o definición pendiente]
- **[NEEDS CLARIFICATION]** [Pregunta o definición pendiente]

---

## ✅ Validación para Ready for Dev

- [ ] Objetivo específico claramente definido.
- [ ] Relación con el objetivo del Proyecto comprendida.
- [ ] Usuarios / actores relevantes identificados.
- [ ] Alcance y fuera de alcance delimitados.
- [ ] Flujo funcional principal definido de principio a fin.
- [ ] Escenarios alternos y excepciones relevantes considerados.
- [ ] Requisitos funcionales concretos y verificables.
- [ ] Reglas de negocio aplicables definidas.
- [ ] Datos y validaciones funcionales relevantes definidos.
- [ ] Permisos aplicables definidos.
- [ ] Criterios de Aceptación suficientes para validar el comportamiento.
- [ ] NFR específicos definidos cuando aplican.
- [ ] NFR transversales del Proyecto considerados.
- [ ] Dependencias particulares identificadas.
- [ ] Impactos y restricciones conocidos identificados.
- [ ] Spec UX/UI asociada y en Ready for Dev cuando la funcionalidad requiera experiencia o interfaz.
- [ ] No existen `[NEEDS CLARIFICATION]` críticos para Construcción.
- [ ] BA, DEV, QA y ARQ cuentan con información funcional suficiente según corresponda.
