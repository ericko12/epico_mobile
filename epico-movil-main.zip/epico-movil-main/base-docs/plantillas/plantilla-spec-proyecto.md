# 📘 [Nombre del Proyecto / Iniciativa]

1. **Spec de Proyecto:** [PROJ-SPEC-XXX]
2. **Responsable PO:** [Nombre]
3. **Versión:** 0.1
4. **Última actualización:** DD-MM-YYYY
5. **Estado:** [Borrador / Definición / Ready for Dev / En Construcción / Validada]

---

## 🎯 1. Resumen y Contexto

- **Necesidad / Problema actual:** [Descripción]
- **Objetivo del Proyecto:** [Resultado general esperado]
- **Valor de negocio:** [Descripción]
  - **Impacto esperado:** [Descripción]
  - **Métricas / KPI:** [Indicadores de éxito]

---

## 👥 2. Usuarios, Áreas y Responsables

- **Público objetivo:**
  - **Usuarios y Áreas beneficiadas:** [Roles y Áreas]
  - **Usuarios y Áreas que utilizarán la solución:** [Roles y Áreas]
  - **Usuarios y Áreas impactadas:** [Roles y Áreas]

---

## 💡 3. Alcance y Consideraciones Iniciales

- **En el alcance (In Scope):**
  - [Capacidad / proceso / módulo / resultado]
  - [Capacidad / proceso / módulo / resultado]
  - [Capacidad / proceso / módulo / resultado]

- **Fuera del alcance (Out of Scope):**
  - [Capacidad / proceso / resultado]
  - [Capacidad / proceso / resultado]

- **Criterios de éxito del Proyecto:**
  - **CRI-P-01.** [Resultado observable o medible]
  - **CRI-P-02.** [Resultado observable o medible]

- **Riesgos generales a considerar:**
  - **RISG-P-01.** [Riesgo]
  - **RISG-P-02.** [Riesgo]

- **Dependencias generales:**
  - **DEP-P-01.** [Sistema / equipo / proceso / integración / decisión]
  - **DEP-P-02.** [Dependencia]

- **Supuestos no validados:**
  - **SUP-P-01.** [Supuesto]
  - **SUP-P-02.** [Supuesto]

---

## 🧭 4. Definiciones y Restricciones Transversales

- **Restricciones generales:**
  - **RES-P-01.** [Restricción]
  - **RES-P-02.** [Restricción]

- **Sistemas / Integraciones involucradas:**
  - **INT-P-01.** [Sistema / integración]
  - **INT-P-02.** [Sistema / integración]

- **Consideraciones de Seguridad:**
  - [Condición transversal / No aplica]

- **Consideraciones de Arquitectura:**
  - [Condición transversal / No aplica]

- **Consideraciones UX/UI:**
  - [DS / patrón / plataforma / dispositivo / No aplica]

- **Otras definiciones aplicables a todas las Specs:**
  - [Definición]
  - [Definición]

---

## 📚 5. Backlog de Specs Funcionales

- **SPEC-001 — [Nombre de la funcionalidad]**
  - **Objetivo:** [Resultado particular esperado]
  - **Prioridad:** [Alta / Media / Baja]
  - **Estado:** [Backlog / Habilitada / Discovery / Definición / Ready for Dev / Construcción / Validación / Liberada]
  - **Dependencia entre Specs:** [SPEC-XXX / Ninguna]
  - **Microcélula:** [Equipo / Por asignar]

- **SPEC-002 — [Nombre de la funcionalidad]**
  - **Objetivo:** [Resultado particular esperado]
  - **Prioridad:** [Alta / Media / Baja]
  - **Estado:** [Estado]
  - **Dependencia entre Specs:** [SPEC-XXX / Ninguna]
  - **Microcélula:** [Equipo / Por asignar]

- **SPEC-003 — [Nombre de la funcionalidad]**
  - **Objetivo:** [Resultado particular esperado]
  - **Prioridad:** [Alta / Media / Baja]
  - **Estado:** [Estado]
  - **Dependencia entre Specs:** [SPEC-XXX / Ninguna]
  - **Microcélula:** [Equipo / Por asignar]

---

## 🔗 6. Referencias

- **Contexto de IA / Conversación con IA:** [URL]
- **Documentación existente:** [URL]
- **Procesos actuales:** [URL]
- **Sistemas actuales:** [URL / App / referencia]
- **Otros:** [URL]

---

## ✅ Definición de Terminado

- [ ] Necesidad / problema general definido.
- [ ] Objetivo del proyecto definido.
- [ ] Valor e indicadores de éxito identificados.
- [ ] Usuarios y áreas involucradas identificados.
- [ ] Alcance general delimitado.
- [ ] Fuera de alcance identificado.
- [ ] Riesgos generales conocidos registrados.
- [ ] Dependencias generales identificadas.
- [ ] Supuestos iniciales registrados.
- [ ] Restricciones transversales conocidas documentadas.
- [ ] Proyecto segmentado en Specs funcionales.
- [ ] Specs iniciales priorizadas.
- [ ] Dependencias principales entre Specs identificadas.
- [ ] PO y TL tienen claridad de la capacidad requerida.
- [ ] No existen pendientes críticos que impidan habilitar el backlog.
