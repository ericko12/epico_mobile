import { ISettingsCamera } from "@/features/digitization/domain/interface/ISettingsCamera"

export const InitSettingsCamera: ISettingsCamera = {
    // FRAME SETTINGS
    letterAspect: 11 / 8.5,// ≈ 1.2941 vertical
    // FRAME SETTINGS
    letterAspectHorizontal: 0.65,
    // Margins (percentage of container width/height)
    frameMarginPct: 0.02,
    frameMarginPctHorizontal: 0.01,
    // Mask opacity (outside the frame)
    maskAlpha: 0.2,
    // Corner length (percentage of the short side of the frame)
    cornerLenPCT: 0.16,
    //Readability percentage in OCR document
    confidence: 40,
}