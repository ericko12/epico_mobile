/**
 * Camera capabilities and constraints that Chromium implements but that are not
 * part of the standard `lib.dom` typings for MediaTrack.
 *
 * They are all optional and device-dependent: Android exposes most of them,
 * Safari/iOS exposes almost none, so every read must be guarded before use.
 *
 * @see https://w3c.github.io/mediacapture-image/#mediatracksupportedconstraints-section
 */

/**
 * Result of `MediaStreamTrack.getCapabilities()` including the image-capture
 * extensions used to keep a document in focus and on the main (non ultra-wide) lens.
 */
export type ExtendedMediaTrackCapabilities = MediaTrackCapabilities & {
    /** Optical/digital zoom range. A device that opens at zoom > 1 is usually on the ultra-wide lens. */
    zoom?: { min: number; max: number };
    /** e.g. ['none', 'manual', 'single-shot', 'continuous'] */
    focusMode?: string[];
    /** e.g. ['none', 'manual', 'single-shot', 'continuous'] */
    exposureMode?: string[];
    /** e.g. ['none', 'manual', 'single-shot', 'continuous'] */
    whiteBalanceMode?: string[];
    /** Present when the device accepts a focus/exposure target point. */
    pointsOfInterest?: unknown;
    /** LED torch. Reported as `true` or as a list of supported values. */
    torch?: boolean | boolean[];
};

/**
 * A single constraint set for `MediaStreamTrack.applyConstraints({ advanced: [...] })`,
 * including the image-capture extensions.
 */
export type ExtendedMediaTrackConstraintSet = MediaTrackConstraintSet & {
    zoom?: number;
    focusMode?: string;
    exposureMode?: string;
    whiteBalanceMode?: string;
    /** Normalised (0..1) focus/exposure target, relative to the frame. */
    pointsOfInterest?: { x: number; y: number }[];
    torch?: boolean;
};
