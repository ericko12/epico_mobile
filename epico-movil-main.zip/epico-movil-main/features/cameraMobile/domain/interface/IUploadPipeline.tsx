/**
 * Contract for the capture-to-upload image pipeline.
 * @see features/cameraMobile/infrastructure/utils/imagePipeline.ts
 */

/**
 * Options controlling how a captured canvas is turned into the uploaded JPEG.
 * @interface IUploadPipelineOptions
 */
export interface IUploadPipelineOptions {
    /** Hard byte ceiling accepted by the backend for a single file. */
    maxBytes: number;
    /** Name of the resulting file. Must end in .jpg: the backend validates by extension. */
    fileName: string;
    /**
     * Try to detect the sheet of paper and warp it flat. Worth it for invoices;
     * pointless (and potentially harmful) for photos that are not documents.
     * Defaults to false.
     */
    dewarp?: boolean;
    /** Upper bound for the long edge of the result, in pixels. Defaults to 2600. */
    maxLongSide?: number;
}

/**
 * What the pipeline produced, including the figures needed to report the real
 * quality of the shot back to the user.
 * @interface IUploadPipelineResult
 */
export interface IUploadPipelineResult {
    /** The JPEG to upload. */
    file: File;
    /** Final width in pixels. */
    width: number;
    /** Final height in pixels. */
    height: number;
    /** Whether perspective correction actually found and rectified a document. */
    dewarped: boolean;
    /** False when the wasm encoder failed to load and canvas.toBlob was used instead. */
    usedMozjpeg: boolean;
}
