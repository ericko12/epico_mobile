/**
 * Interface representing the result of an OCR process.
 * @interface IOcrResult
 * @property {string} text - Extracted text from the OCR process.
 * @property {number | null} confidence - Confidence level of the OCR recognition (percentage or score), or null if unavailable.
 * @property {boolean} isLegible - Indicates if the recognized document is a valid invoice.
 * @property {string | null} previewDataUrl - Data URL of the preview image, or null if not generated.
 * @property {string} [errorTxt] - Optional error message if the OCR process failed.
 * @property {File | null} [sourceFile] - Optional original file processed by the OCR.
 */
export interface IOcrResult {
    text: string;
    confidence: number | null;
    isLegible: boolean;
    /**
     * True when the Serie-Folio of the invoice the user selected was read back off
     * the photo. This is the conclusive check — it proves the capture is of THAT
     * document — whereas isLegible only says the image was readable.
     */
    matchesFolio?: boolean;
    /**
     * Serie-Folio actually read off the sheet, when one could be made out, e.g.
     * "VAOF-386681". Together with matchesFolio this separates the two failures
     * that need different answers: a photo that cannot be read at all, and a photo
     * that reads fine but belongs to a DIFFERENT invoice.
     */
    detectedFolio?: string | null;
    previewDataUrl: string | null;
    errorTxt?: string;
    sourceFile?: File | null;
}

/**
 * Interface representing the return value of the useOcrProcessing hook.
 * @interface IUseOcrProcessingReturn
 * @property {boolean} isLoading - Indicates if the OCR process is loading.
 * @property {string | null} error - Error message if the OCR process failed, or null if successful.
 * @property {IOcrResult | null} result - OCR result, or null if not processed.
 * @property {(file: File, options?: IOcrProcessingOptions) => Promise<IOcrResult>} processImage - Function to process an image with OCR.
 * @property {() => void} clearResult - Function to clear the OCR result.
 */
export interface IUseOcrProcessingReturn {
    isLoading: boolean;
    error: string | null;
    result: IOcrResult | null;
    processImage: (file: File, options?: IOcrProcessingOptions) => Promise<IOcrResult>;
    clearResult: () => void;
}

/**
 * Interface representing the options for the useOcrProcessing hook.
 * @interface IOcrProcessingOptions
 * @property {number} [minConfidence] - Optional confidence threshold to consider the OCR result "legible".
 * @property {boolean} [rotateImage] - Optional flag to rotate the image (for photos taken in the camera).
 * @property {boolean} [autoRun] - Optional flag to run OCR automatically when receiving the file (default is true).
 */
export interface IOcrProcessingOptions {
    minConfidence?: number;
    rotateImage?: boolean;
    autoRun?: boolean;
}