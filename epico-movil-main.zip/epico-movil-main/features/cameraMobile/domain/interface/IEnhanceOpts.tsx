/**
 * Configuration options for enhancing an image before OCR processing.
 * @typedef {Object} EnhanceOpts
 * @property {boolean} [grayscale] - Whether to convert the image to grayscale (default is true, recommended for OCR).
 * @property {number} [contrast] - Contrast adjustment factor; 1.0 keeps it equal, 1.10 increases contrast by 10%.
 * @property {number} [brightness] - Brightness adjustment factor; 1.0 keeps it equal, 1.03 increases brightness by 3%.
 * @property {number} [gamma] - Gamma correction value; values less than 1 brighten midtones slightly.
 */
export type EnhanceOpts = {
  grayscale?: boolean; // defaults to true (OCR loves gray)
  contrast?: number; // 1.0 = equal; 1.10 = +10%
  brightness?: number; // 1.0 = equal; 1.03 = +3%
  gamma?: number; // <1 gently brightens midtones
};