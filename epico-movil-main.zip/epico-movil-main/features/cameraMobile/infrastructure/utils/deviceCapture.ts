/**
 * Orientation helpers for the capture flow.
 *
 * There is deliberately no device-detection function here any more. Two attempts
 * at one — a viewport breakpoint, then an operating-system probe — each sent some
 * device to the in-app browser stream by mistake, so the capture source is now a
 * fixed default (the phone's camera app) with a manual escape in the UI.
 */

/**
 * Locks the screen to the orientation the device is in right now, so the layout
 * cannot flip while a capture is in progress.
 *
 * Reads the current orientation instead of forcing a fixed one: a tablet is used
 * both ways, and pinning it to portrait would fight whoever is holding it
 * sideways. Freezing whatever they chose is what "do not rotate on me" means.
 *
 * Best-effort throughout. Most browsers only grant the lock in fullscreen, and
 * some refuse it outright; a failure here must never stop the camera from opening.
 */
export const lockCurrentOrientation = async (): Promise<void> => {
    try {
        if (!document.fullscreenElement) {
            // Always the document, never a single element inside the modal.
            // Fullscreen renders ONLY the chosen element and its descendants, so
            // targeting the video container hid every sibling — including the
            // button row that holds the shutter, which simply vanished.
            await document.documentElement.requestFullscreen?.();
        }
    } catch {
        // Fullscreen denied: the lock below will probably fail too, which is fine.
    }

    try {
        const orientation = screen.orientation as (ScreenOrientation & {
            lock?: (type: string) => Promise<void>;
        }) | undefined;
        if (!orientation?.lock) return;
        // orientation.type is the exact current state, e.g. 'landscape-primary'.
        await orientation.lock(orientation.type);
    } catch {
        // Unsupported or refused by the browser; the flow continues unlocked.
    }
};

/**
 * Releases the orientation lock and leaves fullscreen, undoing lockCurrentOrientation.
 */
export const releaseOrientation = (): void => {
    try {
        const orientation = screen.orientation as (ScreenOrientation & {
            unlock?: () => void;
        }) | undefined;
        orientation?.unlock?.();
    } catch {
        // Nothing to release.
    }

    try {
        if (document.fullscreenElement) void document.exitFullscreen?.();
    } catch {
        // Already out of fullscreen.
    }
};
