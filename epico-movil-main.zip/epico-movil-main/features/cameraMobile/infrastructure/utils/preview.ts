// Returns a Blob/URL for preview always correctly oriented (without EXIF)
export async function makeUprightPreviewURL(fileOrBlob: Blob): Promise<string> {
  let bmp: ImageBitmap;

  try {
    // Respect EXIF ​​orientation if the browser supports it
    bmp = await createImageBitmap(fileOrBlob, { imageOrientation: 'from-image' });
  } catch {
    // Fallback (some older iOS)
    bmp = await createImageBitmap(fileOrBlob);
  }

  const c = document.createElement('canvas');
  c.width = bmp.width;
  c.height = bmp.height;
  const ctx = c.getContext('2d')!;
  ctx.drawImage(bmp, 0, 0);
  bmp.close?.();

  const blob: Blob = await new Promise((resolve, reject) =>
    c.toBlob(b => (b ? resolve(b) : reject(new Error('toBlob failed'))), 'image/jpeg', 0.95)
  );

  return URL.createObjectURL(blob); // <- without EXIF, will no longer rotate in <img>
}