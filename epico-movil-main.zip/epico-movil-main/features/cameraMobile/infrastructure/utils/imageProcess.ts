import { EnhanceOpts } from "@/features/cameraMobile/domain/interface/IEnhanceOpts";
/**
 * Enhances a canvas image to improve OCR (Optical Character Recognition) accuracy.
 *
 * @param {HTMLCanvasElement} src - The source canvas element to process
 * @param {EnhanceOpts} [opts={}] - Optional enhancement options (e.g., grayscale, contrast, sharpening, binarization)
 * @returns {HTMLCanvasElement} A new canvas element with enhanced contrast and clarity for OCR processing
 *
 * @description
 * - Applies configurable image preprocessing operations such as grayscale conversion, contrast adjustment,
 *   unsharp masking, and thresholding.
 * - Optimized to make printed or scanned text more legible before running OCR.
 * - Commonly used in the invoice digitization flow to improve text recognition results.
 */
export const enhanceForOcr = (
  src: HTMLCanvasElement,
  opts: EnhanceOpts = {}
): HTMLCanvasElement => {
  const {
    grayscale = true,
    contrast = 1.12,    
    brightness = 1.04,  
    gamma = 0.92        
  } = opts;

  const out = document.createElement('canvas');
  out.width = src.width;
  out.height = src.height;

  const ctx = out.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(src, 0, 0);

  const img = ctx.getImageData(0, 0, out.width, out.height);
  const data = img.data;

  // helpers
  const clamp = (v: number) => (v < 0 ? 0 : v > 255 ? 255 : v);
  const applyGamma = (v: number) => Math.pow(v / 255, 1 / gamma) * 255;

  for (let i = 0; i < data.length; i += 4) {
    let r = data[i], g = data[i + 1], b = data[i + 2];

    // Grayscale (better for OCR)
    let v = grayscale ? (0.2126 * r + 0.7152 * g + 0.0722 * b) : r;

    // Soft gamma to lift letters without darkening the background
    v = applyGamma(v);

    // Contrast around the midpoint (128)
    v = (v - 128) * contrast + 128;

    // Slight brightness
    v = v * brightness;

    v = clamp(v);

    if (grayscale) {
      data[i] = data[i + 1] = data[i + 2] = v;
    } else {
      data[i] = v; // if you ever want to keep the color
    }
    // alpha stays the same
  }

  ctx.putImageData(img, 0, 0);
  return out;
};
