
/**
 * Rotates a given canvas by the specified angle in radians and returns a new canvas.
 *
 * @param {HTMLCanvasElement} src - The source canvas element to rotate
 * @param {number} radians - The rotation angle in radians (e.g., Math.PI / 2 for 90°)
 * @returns {HTMLCanvasElement} A new canvas element containing the rotated image
 */
export const rotateCanvas = (
  src: HTMLCanvasElement,
  radians: number
): HTMLCanvasElement => {
  const out = document.createElement("canvas");
  const ctx = out.getContext("2d")!;
  const w = src.width, h = src.height;

  const sin = Math.abs(Math.sin(radians));
  const cos = Math.abs(Math.cos(radians));
  out.width  = Math.round(w * cos + h * sin);
  out.height = Math.round(w * sin + h * cos);

  ctx.translate(out.width / 2, out.height / 2);
  ctx.rotate(radians);
  ctx.drawImage(src, -w / 2, -h / 2);
  return out;
};
/**
 * Ensures that a vertically oriented canvas is adjusted to landscape orientation
 * by splitting it into horizontal stripes and reassembling them.
 *
 * @param {HTMLCanvasElement} srcVertical - The source vertical canvas element to adjust
 * @returns {HTMLCanvasElement} A new canvas element converted to landscape orientation
 */
export const ensureLandscapeByStripes = (srcVertical: HTMLCanvasElement): HTMLCanvasElement => {

  const right90 = rotateCanvas(srcVertical, Math.PI / 2);
  return right90;
  
};
