import { createWorker, PSM, OEM, type Worker } from "tesseract.js";

/**
 * OCR for the invoice header.
 *
 * Two things were wrong with the previous version and both are fixed here.
 *
 * 1. The engine parameters were being thrown away. `Tesseract.recognize(image,
 *    langs, options)` takes WorkerOptions as its third argument — worker/core/lang
 *    paths — not engine parameters, so `tessedit_pageseg_mode`, the character
 *    whitelist and the dictionary switches were silently ignored on every call.
 *    A `const opts: any` was what hid it from the compiler. Init-only parameters
 *    now travel in createWorker's config argument and runtime ones through
 *    setParameters, which are the channels the engine actually reads.
 *
 * 2. A whole worker was created and destroyed per attempt, recompiling the ~4 MB
 *    wasm module and re-initialising the language data every time. The worker is
 *    now a module-level singleton, so only the first recognition pays that cost.
 */

let workerPromise: Promise<Worker> | null = null;

/** Characters that can appear in a Serie-Folio ("VAOF-386680") or in "FACTURA". */
const HEADER_CHARSET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-';

/**
 * Creates the shared worker, or returns the one already running.
 */
const getWorker = async (): Promise<Worker> => {
  if (!workerPromise) {
    workerPromise = (async () => {
      const worker = await createWorker(
        'spa',
        OEM.LSTM_ONLY,
        undefined,
        {
          // Init-only: the dictionaries actively hurt here. A folio like
          // "VAOF-386680" is not a Spanish word, and leaving the lexicon on makes
          // the engine bend unfamiliar strings towards real words.
          load_system_dawg: '0',
          load_freq_dawg: '0',
        },
      );
      return worker;
    })().catch((err) => {
      // Let the next attempt rebuild it instead of poisoning the module.
      workerPromise = null;
      throw err;
    });
  }
  return workerPromise;
};

/**
 * Runs OCR over a preprocessed image of the invoice header.
 *
 * @param {string} preprocessedImage - Data URL of the region to read.
 * @returns The recognition data: text, per-word confidence and metadata.
 */
export const OCRProcess = async (preprocessedImage: string) => {
  const worker = await getWorker();

  await worker.setParameters({
    // The region handed over is a block of header text, not scattered words on a
    // page. PSM 12 (sparse text with orientation detection) was the wrong model
    // for it and is much slower; a uniform block is what this actually is.
    tessedit_pageseg_mode: PSM.SINGLE_BLOCK,
    tessedit_char_whitelist: HEADER_CHARSET,
  });

  const { data } = await worker.recognize(preprocessedImage);
  return data;
};

/**
 * Releases the shared worker. Worth calling when the digitisation flow closes, so
 * a long-lived PWA session does not hold the wasm heap for the rest of the day.
 */
export const disposeOcrWorker = async () => {
  if (!workerPromise) return;
  const pending = workerPromise;
  workerPromise = null;
  try {
    const worker = await pending;
    await worker.terminate();
  } catch {
    // Already gone.
  }
};
