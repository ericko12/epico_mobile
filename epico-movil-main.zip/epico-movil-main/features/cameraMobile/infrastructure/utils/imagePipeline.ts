import { IUploadPipelineOptions, IUploadPipelineResult } from '@/features/cameraMobile/domain/interface/IUploadPipeline';

/**
 * Image pipeline that turns a freshly captured canvas into the JPEG that gets
 * uploaded, in a single encode.
 *
 * Three things it does that the plain canvas.toBlob path could not:
 *
 * 1. Rectifies the sheet (scanic). A photo of an invoice on a desk is trapezoidal
 *    and surrounded by background. Warping it flat and cropping to the paper means
 *    every byte of the budget is spent on the document instead of the table.
 * 2. Downscales with Lanczos + unsharp (pica) instead of the browser's bilinear
 *    filter, which matters a lot for small text.
 * 3. Encodes with MozJPEG (@jsquash/jpeg) aiming AT the byte budget rather than
 *    merely under it, with chroma subsampling off so thin coloured strokes survive.
 *
 * Every dependency is imported dynamically: they are WASM-backed and browser-only,
 * and they must not weigh on the initial bundle of a PWA used over mobile data.
 */

/** Where the MozJPEG wasm is served from. See scripts/copy-wasm.js. */
const MOZJPEG_WASM_URL = '/wasm/mozjpeg_enc.wasm';

/** Aim at this share of the budget: JPEG size is not perfectly predictable. */
const BUDGET_SAFETY = 0.96;

/** Quality bounds. Below ~0.62 MozJPEG starts blocking on text. */
const Q_MAX = 94;
const Q_MIN = 62;

let encoderReady: Promise<void> | null = null;

/**
 * Initialises the MozJPEG encoder once per session, pointing it at the wasm in
 * /public so no bundler configuration is involved.
 */
const ensureEncoder = async () => {
  if (!encoderReady) {
    encoderReady = (async () => {
      const { init } = await import('@jsquash/jpeg/encode');
      await init({ locateFile: () => MOZJPEG_WASM_URL });
    })().catch((err) => {
      // Let a later capture retry instead of poisoning the module for good.
      encoderReady = null;
      throw err;
    });
  }
  return encoderReady;
};

/**
 * The detected quad must cover at least this share of the frame.
 *
 * The input here is a FULL photo taken with the phone's camera app, so the sheet
 * sits inside a scene with desk around it and does not fill the frame — hence a
 * moderate floor rather than a high one. It is still far above what a printed box
 * inside the invoice can reach: those run well under 20% of a framed photo, which
 * is exactly the candidate that has to be rejected.
 */
const MIN_DOCUMENT_COVERAGE = 0.30;

/**
 * Accepted long/short ratio for the rectified result. US Letter is 1.294 exactly,
 * and the sheet size is known, so the band is tight: wide enough for perspective
 * error, narrow enough that half a sheet (≈0.65 or ≈2.6) or an inner table cannot
 * pass as the page.
 */
const MIN_DOCUMENT_RATIO = 1.17;
const MAX_DOCUMENT_RATIO = 1.45;

/**
 * Minimum detector confidence.
 *
 * This is the gate that actually rejects, and it has to live here: scanic's own
 * minimum and maximum options do NOT filter candidates, they only change which one
 * wins the ordering, so tightening them alone lets a bad quad through with a low
 * score attached. Reading the score back is what turns it into a real barrier.
 */
const MIN_DETECTION_CONFIDENCE = 0.6;

/** Long side the image is reduced to BEFORE warping. */
const DEWARP_WORK_LONG_SIDE = 2600;

/** Area of the detected quadrilateral, via the shoelace formula. */
const quadArea = (corners: { x: number; y: number }[]): number => {
  let sum = 0;
  for (let i = 0; i < corners.length; i++) {
    const a = corners[i];
    const b = corners[(i + 1) % corners.length];
    sum += a.x * b.y - b.x * a.y;
  }
  return Math.abs(sum) / 2;
};

/**
 * Detects the sheet of paper and warps it flat.
 *
 * Returns null whenever the result does not look like the sheet, in which case the
 * caller keeps the full frame. That guard is the whole point: scanic ships very
 * permissive defaults (a document may cover as little as 4% of the frame, at up to
 * an 8:1 aspect), and on an invoice photographed against a pale desk the paper
 * edges are the LOWEST contrast lines in the shot while the printed table borders
 * are the highest. Left to the defaults the detector locks onto an inner table and
 * happily rectifies that instead of the page.
 */
const tryDewarp = async (source: HTMLCanvasElement): Promise<HTMLCanvasElement | null> => {
  try {
    const { scanDocument } = await import('scanic');
    const result = await scanDocument(source, {
      mode: 'extract',
      output: 'canvas',
      // The detector only needs a reduced copy to find the edges; the warp is
      // still applied to the full resolution source.
      maxProcessingDimension: 900,
      // Tighten every permissive default so an inner box cannot pass as the page.
      minDocumentCoverageRatio: MIN_DOCUMENT_COVERAGE,
      minDocumentFillRatio: 0.55,
      minDocumentSideRatio: 0.5,
      maxDocumentAspectRatio: MAX_DOCUMENT_RATIO,
    });

    if (!result?.success || !result.output) return null;
    const output = result.output as HTMLCanvasElement;
    if (!output.width || !output.height) return null;

    // Gate 1 — detector score. See MIN_DETECTION_CONFIDENCE: the library's own
    // thresholds rank candidates but never reject them, so this is the barrier.
    const confidence = result.confidence ?? 0;
    if (confidence < MIN_DETECTION_CONFIDENCE) {
      console.info(`Recorte descartado: confianza ${confidence.toFixed(2)} del detector.`);
      return null;
    }

    // Gate 2 — how much of the photo the quad covers.
    if (result.corners) {
      const { topLeft, topRight, bottomRight, bottomLeft } = result.corners;
      const coverage = quadArea([topLeft, topRight, bottomRight, bottomLeft]) / (source.width * source.height);
      if (coverage < MIN_DOCUMENT_COVERAGE) {
        console.info(`Recorte descartado: el área detectada cubre ${(coverage * 100).toFixed(0)}% de la foto.`);
        return null;
      }
    }

    // Gate 3 — shape. A letter sheet is 1.294 whichever way round it is.
    const ratio = Math.max(output.width, output.height) / Math.min(output.width, output.height);
    if (ratio < MIN_DOCUMENT_RATIO || ratio > MAX_DOCUMENT_RATIO) {
      console.info(`Recorte descartado: proporción ${ratio.toFixed(2)}, fuera del rango de una hoja carta.`);
      return null;
    }

    // Gate 4 — orientation. The ratio test above uses max/min, so it passes a
    // result that is correct in shape but standing on end. Letting that through
    // would hand the OCR a page rotated 90° and show the courier a sideways sheet.
    if (output.height > output.width) {
      console.info('Recorte descartado: el resultado quedó vertical y la factura es apaisada.');
      return null;
    }

    console.info(`Hoja recortada: ${output.width}x${output.height}, confianza ${confidence.toFixed(2)}.`);
    return output;
  } catch (err) {
    console.warn('No se pudo rectificar el documento, se usa la imagen completa:', err);
    return null;
  }
};

/**
 * Downscales with Lanczos and a mild unsharp pass. The unsharp is what recovers
 * the crispness a downscale always costs; the values are deliberately gentle so
 * printed text does not get a halo.
 */
const resizeCanvas = async (source: HTMLCanvasElement, longSide: number): Promise<HTMLCanvasElement> => {
  const currentLong = Math.max(source.width, source.height);
  if (currentLong <= longSide) return source;

  const ratio = longSide / currentLong;
  const target = document.createElement('canvas');
  target.width = Math.max(1, Math.round(source.width * ratio));
  target.height = Math.max(1, Math.round(source.height * ratio));

  try {
    const Pica = (await import('pica')).default;
    await Pica().resize(source, target, {
      unsharpAmount: 60,
      unsharpRadius: 0.6,
      unsharpThreshold: 2,
    });
    return target;
  } catch (err) {
    console.warn('pica no disponible, se reduce con canvas:', err);
    const ctx = target.getContext('2d', { alpha: false })!;
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(source, 0, 0, target.width, target.height);
    return target;
  }
};

/** Encodes a canvas with MozJPEG at a given quality. */
const encodeMozjpeg = async (canvas: HTMLCanvasElement, quality: number): Promise<Blob> => {
  await ensureEncoder();
  const encode = (await import('@jsquash/jpeg/encode')).default;
  const ctx = canvas.getContext('2d', { alpha: false })!;
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const buffer = await encode(imageData, {
    quality,
    progressive: true,
    optimize_coding: true,
    // Trellis quantisation buys bytes back on text, but multipass is by far the
    // most expensive knob in the encoder — several seconds on a mid-range phone
    // for a multi-megapixel frame. The two cheap passes keep most of the benefit.
    trellis_multipass: false,
    trellis_opt_zero: true,
    trellis_opt_table: true,
    // Keep 4:2:0. Disabling chroma subsampling was a mistake under a FIXED byte
    // budget: it costs 15-25% more bytes, and on a near-monochrome document those
    // bytes come straight out of the luma channel — which is where the legibility
    // of the text actually lives. Full-resolution chroma on black-on-white print
    // buys nothing worth that trade.
    auto_subsample: true,
  });
  return new Blob([buffer], { type: 'image/jpeg' });
};

/** Fallback for browsers where the wasm encoder fails to load. */
const encodeCanvasNative = (canvas: HTMLCanvasElement, quality: number): Promise<Blob> =>
  new Promise((resolve, reject) =>
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('toBlob falló'))),
      'image/jpeg',
      quality / 100,
    ),
  );

/**
 * Finds the highest quality that still fits the budget at a given size.
 *
 * Deliberately probes rather than binary-searching the full range: each encode of
 * a multi-megapixel image costs real time on a mid-range phone, so this settles
 * for a good answer in two or three passes instead of the perfect one in seven.
 * Returns null when even Q_MIN overshoots, which tells the caller to shrink.
 */
const encodeToBudget = async (
  canvas: HTMLCanvasElement,
  maxBytes: number,
  encoder: (c: HTMLCanvasElement, q: number) => Promise<Blob>,
): Promise<Blob | null> => {
  // First probe near the top of the range: on a document at this size it usually
  // already fits, and then one encode is the whole cost.
  const first = await encoder(canvas, 88);
  if (first.size <= maxBytes) return first;

  // It overshot. JPEG size moves with quality smoothly enough that the overshoot
  // ratio predicts a good second guess, which beats blind bisection: one informed
  // step lands close instead of walking there in four encodes.
  const ratio = maxBytes / first.size;
  let guess = Math.round(88 * Math.pow(ratio, 0.55));
  guess = Math.min(Q_MAX, Math.max(Q_MIN, guess));

  const second = await encoder(canvas, guess);
  if (second.size <= maxBytes) {
    // Try once to claw back quality, but only when there is real headroom left.
    if (second.size < maxBytes * 0.8 && guess < Q_MAX - 4) {
      const third = await encoder(canvas, Math.min(Q_MAX, guess + 5));
      if (third.size <= maxBytes) return third;
    }
    return second;
  }

  // Still over: one last attempt at the floor before the caller shrinks the image.
  const floor = await encoder(canvas, Q_MIN);
  return floor.size <= maxBytes ? floor : null;
};

/**
 * Runs a captured canvas through the whole pipeline and returns the file to upload
 * plus the numbers describing what came out, so the UI can report them honestly.
 */
export const buildUploadFile = async (
  source: HTMLCanvasElement,
  options: IUploadPipelineOptions,
): Promise<IUploadPipelineResult> => {
  const { maxBytes, fileName, dewarp = false, maxLongSide = 2600 } = options;
  const budget = Math.floor(maxBytes * BUDGET_SAFETY);

  let working = source;
  let dewarped = false;

  if (dewarp) {
    // Reduce BEFORE warping. The homography is the same either way and the final
    // output is identical, but running it on a 12 MP still means minutes of work
    // and hundreds of MB of canvas buffers on a mid-range phone — for pixels the
    // size ladder below discards immediately afterwards.
    const forDetection = await resizeCanvas(source, DEWARP_WORK_LONG_SIDE);
    const rectified = await tryDewarp(forDetection);
    if (rectified) {
      working = rectified;
      dewarped = true;
      if (forDetection !== source && forDetection !== rectified) {
        forDetection.width = 0;
        forDetection.height = 0;
      }
    } else {
      // No sheet found with enough confidence: keep the photo as it was framed.
      working = forDetection;
    }
  }

  // Pick the encoder once: if the wasm will not load, everything below still runs.
  let encoder = encodeMozjpeg;
  let usedMozjpeg = true;
  try {
    await ensureEncoder();
  } catch (err) {
    console.warn('MozJPEG no disponible, se codifica con canvas:', err);
    encoder = encodeCanvasNative;
    usedMozjpeg = false;
  }

  // Step down in size only as far as the budget actually forces us to.
  const startLong = Math.min(maxLongSide, Math.max(working.width, working.height));
  const sizeLadder = [startLong, startLong * 0.85, startLong * 0.72, startLong * 0.6, startLong * 0.5]
    .map((s) => Math.round(s))
    .filter((s) => s >= 640);

  let finalBlob: Blob | null = null;
  let finalCanvas = working;

  for (const longSide of sizeLadder) {
    const resized = await resizeCanvas(working, longSide);
    const blob = await encodeToBudget(resized, budget, encoder);
    if (blob) {
      finalBlob = blob;
      finalCanvas = resized;
      break;
    }
    // Release the rejected intermediate: Safari iOS caps total canvas memory.
    if (resized !== working) {
      resized.width = 0;
      resized.height = 0;
    }
  }

  // Nothing fit the ladder: take the smallest rung at minimum quality and let the
  // caller's own size guard decide what to do about it.
  if (!finalBlob) {
    const smallest = await resizeCanvas(working, sizeLadder[sizeLadder.length - 1] ?? 640);
    finalBlob = await encoder(smallest, Q_MIN);
    finalCanvas = smallest;
  }

  return {
    file: new File([finalBlob], fileName, { type: 'image/jpeg' }),
    width: finalCanvas.width,
    height: finalCanvas.height,
    dewarped,
    usedMozjpeg,
  };
};

/**
 * Decodes an arbitrary image file (a shot from the phone's own camera app, for
 * instance) into a canvas the pipeline can consume.
 *
 * The decode is capped on purpose: a 50 MP still is ~200 MB once expanded to RGBA,
 * which is enough to blow up a mid-range phone. createImageBitmap can scale during
 * decode, so the full-size bitmap is never materialised.
 */
export const fileToCanvas = async (file: File, maxLongSide = 2600): Promise<HTMLCanvasElement> => {
  let bitmap: ImageBitmap;
  try {
    // Probe WITH the EXIF orientation applied. Phone and tablet cameras usually
    // record the sensor's raw frame and note the rotation in EXIF rather than
    // turning the pixels, so a probe without this reports the pre-rotation shape:
    // the cap would then be computed against the wrong axis, and — for anything
    // under the cap, which skipped the second decode entirely — the image was used
    // sideways. Since the caller decides whether to rotate by comparing width and
    // height, that measurement has to be the one a person actually sees.
    const probe = await createImageBitmap(file, { imageOrientation: 'from-image' });
    const longSide = Math.max(probe.width, probe.height);
    if (longSide > maxLongSide) {
      const ratio = maxLongSide / longSide;
      const resizeWidth = Math.round(probe.width * ratio);
      probe.close?.();
      bitmap = await createImageBitmap(file, {
        resizeWidth,
        resizeQuality: 'high',
        imageOrientation: 'from-image',
      });
    } else {
      bitmap = probe;
    }
  } catch {
    bitmap = await createImageBitmap(file);
  }

  const canvas = document.createElement('canvas');
  canvas.width = bitmap.width;
  canvas.height = bitmap.height;
  const ctx = canvas.getContext('2d', { alpha: false })!;
  ctx.drawImage(bitmap, 0, 0);
  bitmap.close?.();
  return canvas;
};
