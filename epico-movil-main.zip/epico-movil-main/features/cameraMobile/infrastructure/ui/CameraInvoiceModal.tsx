import React, { useEffect, useRef, useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  IconButton,
  CircularProgress,
  Typography,
  Tooltip,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { ICameraInvoiceModalProps } from '@/features/cameraMobile/infrastructure/ui/CameraInvoiceModal.types';
import InvoiceOcrValidateModal from '@/features/cameraMobile/infrastructure/ui/InvoiceOcr/InvoiceOcrValidateModal';
import { IOcrResult } from '@/features/cameraMobile/domain/interface/IOcrResult';
import CheckCircle from '@mui/icons-material/CheckCircleOutline';
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { makeUprightPreviewURL } from '@/features/cameraMobile/infrastructure/utils/preview';
import CachedIcon from "@mui/icons-material/Cached";
import FlashOnIcon from "@mui/icons-material/FlashOn";
import FlashOffIcon from "@mui/icons-material/FlashOff";
import PhotoCameraIcon from "@mui/icons-material/PhotoCamera";
import ZoomInIcon from "@mui/icons-material/ZoomIn";
import ImageQualityViewer from '@/features/cameraMobile/infrastructure/ui/ImageQualityViewer/ImageQualityViewer';
import { InitSettingsCamera } from '@/features/cameraMobile/domain/data/CameraInvoiceModal.data';
import {
  ExtendedMediaTrackCapabilities,
  ExtendedMediaTrackConstraintSet,
} from '@/features/cameraMobile/domain/interface/IExtendedMediaTrack';
import { ensureLandscapeByStripes } from '@/features/cameraMobile/infrastructure/utils/orientation';
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import {
  DialogContentSx,
  MainContainerSx,
  VideoContainerSx,
  PreviewOverlaySx,
  PreviewImageSx,
  ButtonRowSx,
  IconButtonSx,
  CaptureButtonInnerSx,
  CheckIconButtonSx,
} from '@/features/cameraMobile/infrastructure/ui/CameraInvoice.styles';
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";
import { regexMobileOperatingSystem } from "@/features/common/infrastructure/utils/regexGlobal";

/**
 * Component that displays a modal to capture an invoice image using the device camera.
 * @param {ICameraInvoiceModalProps} props - The component props.
 * @param {boolean} props.open - Controls whether the modal is open or closed.
 * @param {() => void} props.onClose - Callback function triggered when the modal is closed.
 * @param {(file: File) => void} props.onResult - Callback executed when a file is captured/selected.
 */


export const CameraInvoiceModal: React.FC<ICameraInvoiceModalProps> = ({
  open, onClose, onResult, onAttemptsChange, useOcr = true, limitTry = 2, currentStep, expectedFolio
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  // We save the frame rectangle
  const frameRef = useRef<{ x: number; y: number; w: number; h: number }>({ x: 0, y: 0, w: 0, h: 0 });
  // We save isMobile value when camera opens to prevent reinitialization on orientation change
  const isMobileOnOpenRef = useRef<boolean>(false);

  // State
  const [showOcr, setShowOcr] = useState(false);
  const [resultOcr, setresultOcr] = useState<IOcrResult | null>(null);
  const { showSnackbar } = useSnackbar();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>('');
  // preview
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [capturedFile, setCapturedFile] = useState<File | null>(null);
  const [rotateImage, setRotateImage] = useState<boolean>(false); // We know if the image should be rotated when sending to OCR
  const [processingImage, setProcessingImage] = useState<boolean>(false); // Avoid starting OCR before compression is complete

  const [ocrAttempts, setOcrAttempts] = useState(0);
  const [manualAttempts, setManualAttempts] = useState(0);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false); // show confirmation modal when max attempts reached
  const { isMobile } = useWindowDimensions();

  // Manual camera controls. Availability is device-dependent (Chromium exposes
  // them, Safari/iOS does not), so both are hidden unless the track reports them.
  const [torchAvailable, setTorchAvailable] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [canTapFocus, setCanTapFocus] = useState(false);
  // Transient ring drawn where the user tapped to focus.
  const [focusPoint, setFocusPoint] = useState<{ x: number; y: number } | null>(null);
  const focusPointTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Full screen quality review of the shot just taken.
  const [showQualityViewer, setShowQualityViewer] = useState(false);

  // Refs to track what type of attempt change should be notified
  const shouldNotifyOcrRef = useRef(false);
  const shouldNotifyManualRef = useRef(false);
  // Ref to store file and previewUrl to upload after manual attempt is notified
  const pendingUploadRef = useRef<{ file: File; previewUrl: string } | null>(null);
  // Hidden file input backing the "use the phone's camera app" route.
  const nativeInputRef = useRef<HTMLInputElement | null>(null);

  /**
   * Where the photo comes from.
   *
   * 'native' hands off to the phone's own camera app: full sensor resolution, the
   * manufacturer's HDR and noise reduction, real phase-detect autofocus and its
   * own flash — none of which getUserMedia can reach. It is the default on mobile
   * because the browser stream tops out around 1080p-4K no matter what the sensor
   * is capable of, and because torch/zoom/focus controls are unevenly exposed
   * across devices.
   *
   * 'live' is the in-app stream with the letter guide. Kept for desktop, and
   * reachable on mobile for anyone who wants the framing overlay.
   */
  const [captureMode, setCaptureMode] = useState<'native' | 'live'>('native');

  // New limit: 1 MB decimal = 1,000,000 bytes
  const validationMaxBytes = 1_000_000; // 1MB (decimal) in bytes
  const effectiveShowInstructionText = currentStep === 2 ? false : true;
  useEffect(() => {
    const start = async () => {
      // Capture isMobile value when opening camera to prevent reinitialization on orientation change
      isMobileOnOpenRef.current = isMobile;
      setOcrAttempts(0);
      setManualAttempts(0);
      setError('');
      
      // Fullscreen and the orientation lock are handled when the modal opens, for
      // both capture modes. They used to be forced here to portrait on a narrow
      // viewport and landscape otherwise, which fought a tablet held sideways and
      // never ran at all in native mode.

      try {
        clearPreview();
        const videoConstraints: MediaTrackConstraints = {
          // Ask high, in LANDSCAPE, and let the UA come down. Android enumerates
          // its camera modes landscape (3264x2448, 1920x1080, …), so asking in
          // portrait — as this briefly did — makes the browser resolve the request
          // by cropping rather than by picking a mode, throwing away part of the
          // horizontal field for nothing. A 4:3 mode is preferred over 16:9
          // because the 16:9 video modes are themselves a vertical crop of the
          // sensor's native 4:3.
          width: { ideal: 3264 },
          height: { ideal: 2448 },
          frameRate: { ideal: 24, max: 30 },
          // No aspectRatio constraint: it used to contradict width/height inside
          // the same set (1.78 vs 1.294), which made Chrome crop the track to
          // satisfy it. The letter guide is only an overlay, and takePhoto()
          // already crops to it by hand.
        };

        // The evidence is ALWAYS shot with the rear camera. `ideal` is only a
        // preference: when the UA cannot satisfy it, it silently hands over
        // whatever camera it finds — on several Android devices with multiple
        // lenses that ends up being the front one. `exact` makes it a hard
        // requirement instead, so ask for that first.
        //
        // The fallback is reserved for OverconstrainedError, i.e. the device
        // genuinely has no rear camera (a desktop webcam). Any other failure —
        // permission denied above all — must propagate untouched, or we would
        // pointlessly re-prompt and then report the wrong reason.
        let stream: MediaStream;
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: { ...videoConstraints, facingMode: { exact: 'environment' } },
            audio: false,
          });
        } catch (exactErr) {
          const errName = (exactErr as DOMException)?.name;
          const isConstraintIssue = errName === 'OverconstrainedError' || errName === 'ConstraintNotSatisfiedError';
          if (!isConstraintIssue) throw exactErr;
          console.warn('Sin cámara trasera disponible, se usa la cámara por defecto:', exactErr);
          stream = await navigator.mediaDevices.getUserMedia({
            video: { ...videoConstraints, facingMode: { ideal: 'environment' } },
            audio: false,
          });
        }
        streamRef.current = stream;

        // Negotiate what the device can actually deliver. Every step here is
        // optional and device-dependent (iOS reports almost no capabilities), so
        // each is guarded on its own: a rejection must never stop the camera from
        // opening.
        const videoTrack = stream.getVideoTracks()[0];
        if (videoTrack) {
          try {
            const caps = videoTrack.getCapabilities?.() ?? {};
            if (caps.height?.max && (videoTrack.getSettings().height ?? 0) < caps.height.max) {
              await videoTrack.applyConstraints({
                width: { ideal: caps.width?.max },
                height: { ideal: caps.height.max },
              });
            }
          } catch (capsErr) {
            console.warn('No se pudo subir la resolución del track:', capsErr);
          }

          // Expose the manual controls this particular device actually supports.
          let hasTorch = false;
          try {
            const caps = (videoTrack.getCapabilities?.() ?? {}) as ExtendedMediaTrackCapabilities;
            hasTorch = caps.torch === true || (Array.isArray(caps.torch) && caps.torch.includes(true));
            setTorchAvailable(hasTorch);
            setCanTapFocus(Boolean(caps.pointsOfInterest) || Boolean(caps.focusMode?.includes('single-shot')));
          } catch {
            setTorchAvailable(false);
            setCanTapFocus(false);
          }

          // The light comes on by itself for EVERY capture in this module, invoice
          // included. Evidence is shot wherever the delivery happens — inside a
          // van, a dark warehouse, a doorway at dusk — and the courier should not
          // have to remember a button. If a sheet of paper ever picks up a hotspot
          // from it, the manual toggle turns it off for that shot.
          //
          // Note this is `torch`, a CONTINUOUS LED, not a shutter-synced flash:
          // the web platform exposes nothing else here. It is the better fit
          // anyway — the courier sees the lit scene before pressing the shutter.
          const wantTorch = hasTorch;

          try {
            const caps = (videoTrack.getCapabilities?.() ?? {}) as ExtendedMediaTrackCapabilities;
            const advanced: ExtendedMediaTrackConstraintSet[] = [];
            // zoom:1 is the one that matters most: several Android devices open
            // the ultra-wide lens by default, the worst sensor on the phone for
            // reading a document.
            if (caps.zoom && caps.zoom.min <= 1 && caps.zoom.max >= 1) advanced.push({ zoom: 1 });
            if (caps.focusMode?.includes('continuous')) advanced.push({ focusMode: 'continuous' });
            if (caps.exposureMode?.includes('continuous')) advanced.push({ exposureMode: 'continuous' });
            if (caps.whiteBalanceMode?.includes('continuous')) advanced.push({ whiteBalanceMode: 'continuous' });
            if (wantTorch) advanced.push({ torch: true });
            if (advanced.length) await videoTrack.applyConstraints({ advanced });
            setTorchOn(wantTorch);
          } catch (focusErr) {
            console.warn('No se pudieron ajustar enfoque/exposición/linterna:', focusErr);
            setTorchOn(false);
          }

          // There was no instrumentation anywhere in the flow, so the resolution
          // each device really hands over was unknown. Log it once so any further
          // tuning is based on measurements instead of assumptions.
          console.info('Settings reales del track de video:', videoTrack.getSettings());
          console.info('Capacidades de la camara:', videoTrack.getCapabilities?.());
        }

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => { drawOverlay(); };
          await videoRef.current.play();
          drawOverlay();
        }

        // Second attempt at the torch, once the track is actually delivering
        // frames. Chrome on Android often reports an incomplete capability set in
        // the moment right after getUserMedia resolves — `torch` simply is not
        // listed yet — and the first attempt above then turns nothing on and hides
        // the button, silently. Re-reading after playback starts is what makes the
        // light come on reliably rather than "usually".
        if (videoTrack && videoTrack.readyState === 'live') {
          try {
            const caps = (videoTrack.getCapabilities?.() ?? {}) as ExtendedMediaTrackCapabilities;
            const torchNow = caps.torch === true || (Array.isArray(caps.torch) && caps.torch.includes(true));
            if (torchNow) {
              setTorchAvailable(true);
              await applyCameraConstraints(videoTrack, [], true);
              setTorchOn(true);
            }
          } catch (retryErr) {
            console.warn('Segundo intento de encender la linterna fallido:', retryErr);
          }
        }
      } catch (err: any) {
        setError('No se pudo acceder a la cámara: ' + (err?.message ?? 'permiso denegado o no disponible'));
      }
    };

    const stop = () => {
      if (streamRef.current) {
        // Turn the torch off before releasing the track: on several Android
        // devices the LED stays lit after the track is stopped.
        const videoTrack = streamRef.current.getVideoTracks()[0];
        if (videoTrack) {
          try {
            const advanced: ExtendedMediaTrackConstraintSet[] = [{ torch: false }];
            void videoTrack.applyConstraints({ advanced });
          } catch {
            // Device does not support torch: nothing to turn off.
          }
        }
        streamRef.current.getTracks().forEach(t => t.stop());
        streamRef.current = null;
      }
      setTorchOn(false);
      setTorchAvailable(false);
      setCanTapFocus(false);
      setFocusPoint(null);
      if (focusPointTimerRef.current) {
        clearTimeout(focusPointTimerRef.current);
        focusPointTimerRef.current = null;
      }
      if (videoRef.current) videoRef.current.srcObject = null;

      // The orientation lock is NOT released here. stop() also runs when the
      // capture mode switches to native — there is no stream to keep in that mode —
      // so unlocking here would immediately undo the lock taken when the modal
      // opened. It is released when the modal actually closes instead.
    };

    // Only the in-app stream needs a MediaStream. In native mode the phone's
    // camera app owns the hardware, so opening one here would take the camera for
    // nothing and, on several Android devices, leave the native app unable to bind
    // it a moment later.
    if (open && captureMode === 'live') start(); else stop();
    return () => stop();
  }, [open, captureMode]);

  // Freeze the orientation for as long as the modal stays open.
  //
  // The capture source is no longer decided here: it is 'native' from the initial
  // state, at every resolution. Two earlier rules were wrong in the same way, each
  // sending some device to the in-app stream — first a viewport breakpoint, which
  // an 11.5" tablet always cleared, then an operating-system probe, which "request
  // desktop site" could defeat. Any rule evaluated AFTER the first render also left
  // a window in which the modal was still showing the live camera and could be used
  // through it, which is what made the fallback appear intermittently.
  //
  // The in-app stream remains reachable through the on-screen link, so a desktop
  // without a camera app still has a way through.
  useEffect(() => {
    if (!open) return;
    let cancelled = false;

    // Back to the phone's camera on every open. Without this, one trip through the
    // "use the in-app camera" link would stick for the rest of the session, since
    // the modal is not remounted between captures.
    setCaptureMode('native');

    (async () => {
      const { lockCurrentOrientation } =
        await import('@/features/cameraMobile/infrastructure/utils/deviceCapture');
      if (cancelled) return;
      // Pin whatever orientation the device is in right now. This used to live
      // inside the stream startup, so in native mode — where no stream is opened —
      // nothing was locked and the layout flipped mid-capture.
      await lockCurrentOrientation();
    })();

    return () => {
      cancelled = true;
      // Released here, on close, and not in stop(): stop() also fires when the
      // capture mode flips to native, and releasing there would undo the lock a
      // moment after taking it.
      void import('@/features/cameraMobile/infrastructure/utils/deviceCapture')
        .then(({ releaseOrientation }) => releaseOrientation());
    };
    // Only on open: re-running this when the viewport changes would yank the user
    // out of the mode they chose and re-lock on every rotation.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  /*
  *  Redraw overlay when resizing window
  */
  useEffect(() => {
    const onResize = () => drawOverlay();
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // Effect to notify parent about OCR attempts changes (after state update)
  useEffect(() => {
    if (shouldNotifyOcrRef.current && onAttemptsChange && useOcr) {
      shouldNotifyOcrRef.current = false;
      // Notify parent about OCR attempt change, keeping current manual attempts value
      onAttemptsChange({
        ocrAttempts: ocrAttempts,
        manualAttempts: manualAttempts,
        previewUrl
      });
    }
  }, [ocrAttempts, manualAttempts, previewUrl, onAttemptsChange, useOcr]);

  // Effect to notify parent about manual attempts changes (after state update)
  useEffect(() => {
    if (shouldNotifyManualRef.current && onAttemptsChange && useOcr) {
      shouldNotifyManualRef.current = false;
      // Notify parent about manual attempt change, keeping current OCR attempts value
      onAttemptsChange({
        ocrAttempts: ocrAttempts,
        manualAttempts: manualAttempts,
        previewUrl
      });

      // If there's a pending upload (from handleConfirmYes), execute it now
      if (pendingUploadRef.current) {
        const { file, previewUrl: uploadPreviewUrl } = pendingUploadRef.current;
        pendingUploadRef.current = null;
        handleDirectUpload(file, uploadPreviewUrl, true); // skipNotification = true
        showSnackbar('Documento aceptado.', 'success');
      }
    }
  }, [manualAttempts, ocrAttempts, previewUrl, onAttemptsChange, useOcr]);

  // Helper function to notify parent about final attempts when process completes
  const notifyFinalAttempts = (previewUrl: string | null) => {
    if (onAttemptsChange && useOcr) {
      onAttemptsChange({
        ocrAttempts: ocrAttempts,
        manualAttempts: manualAttempts,
        previewUrl
      });
    }
  };

  // Handler to start OCR process and register the attempt
  /**
   * Fires the OCR by itself as soon as the processed photo is ready.
   *
   * The phone's camera app already makes the courier accept or retake the shot
   * before handing it back, so asking for a second tap here to start the check was
   * confirming the same photo twice. This screen now reports a result instead of
   * gating on one: it only needs input when something is actually wrong.
   *
   * Guarded on showOcr/resultOcr so it runs once per capture, not on every render
   * while the recognition is in flight.
   */
  useEffect(() => {
    if (!open || !useOcr) return;
    if (!capturedFile || processingImage) return;
    if (showOcr || resultOcr) return;
    if (ocrAttempts >= limitTry) return; // let the confirmation dialog take over
    handleStartOcr();
    // handleStartOcr is stable enough for this guard set; adding it would re-run
    // the effect on every render through its state closures.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, useOcr, capturedFile, processingImage, showOcr, resultOcr, ocrAttempts, limitTry]);

  const handleStartOcr = () => {
    if (processingImage) return; // avoid starting OCR while compressing
    // If limit is reached, show confirmation modal instead of processing OCR
    if (ocrAttempts >= limitTry) {
      setShowConfirmationModal(true);
      return;
    }

    // Only register OCR attempt if limit is not reached
    const nextAttempt = ocrAttempts + 1;
    shouldNotifyOcrRef.current = true; // Mark that we should notify about OCR change
    setOcrAttempts(nextAttempt);
    setShowOcr(true);
    // Notification will happen in useEffect after state update
  };

  /**
   * The letter-shaped guide only makes sense for the invoice, whose OCR reads a
   * fixed quadrant of the framed shot. Evidence photos have no such constraint,
   * so they use the full frame.
   */
  const useLetterFrame = useOcr;

  /*
  *  Calculate and draw the FRAME
  */
  const drawOverlay = () => {
    const canvas = overlayRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const cw = container.clientWidth;
    const ch = container.clientHeight;
    if (cw === 0 || ch === 0) return;

    // Draw the overlay at physical resolution. It used to be sized in CSS pixels
    // only, so on a phone with dpr 3 the frame and its corners were rendered at a
    // third of the screen's real resolution and then upscaled by the compositor:
    // that alone made the whole guide look soft.
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.round(cw * dpr);
    canvas.height = Math.round(ch * dpr);
    canvas.style.width = `${cw}px`;
    canvas.style.height = `${ch}px`;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    // Everything below is expressed in CSS pixels.
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // The guide is sized against the CONTAINER, and the video fills it with
    // object-fit: cover.
    //
    // Fitting the guide to the displayed video rect (with object-fit: contain)
    // made it a function of whatever raster the driver happened to hand over: on a
    // landscape raster in a portrait viewport the video collapses to a short band,
    // and the letter-shaped guide inside it fell to 19% of its former area — a
    // 164×212 px window to frame a document in and to judge focus by. It did
    // capture ~1.6x more pixels, but the 1 MB budget discards most of those again,
    // so the trade was strongly negative. Resolution is recovered through the
    // capture constraints instead, which raise the raster without shrinking the
    // viewport: with cover and a 4:3 raster the crop is ~2.7 MP at full guide size.
    const marginPct = isMobileOnOpenRef.current ? InitSettingsCamera.frameMarginPct : InitSettingsCamera.frameMarginPctHorizontal;
    const usableW = cw - cw * marginPct * 2;
    const usableH = ch - ch * marginPct * 2;

    let frameW: number;
    let frameH: number;

    if (useLetterFrame) {
      // Invoice: fit the guide to letter proportions (height/width = LETTER_ASPECT)
      // within the usable area. The shape matters here because the OCR reads a
      // fixed quadrant of the framed capture.
      const letterAspect = isMobileOnOpenRef.current ? InitSettingsCamera.letterAspect : InitSettingsCamera.letterAspectHorizontal;
      frameW = usableW;
      frameH = frameW * letterAspect;
      if (frameH > usableH) {
        // If the width is too wide, adjust the height
        frameH = usableH;
        frameW = frameH / letterAspect;
      }
    } else {
      // Evidence: no letter shape to respect, so the guide takes the whole frame.
      // A smaller guide forced the courier to physically walk the phone closer
      // until the subject filled it; capturing everything the viewport shows
      // removes that entirely and yields more pixels, not fewer.
      frameW = usableW;
      frameH = usableH;
    }

    const frameX = (cw - frameW) / 2;
    const frameY = (ch - frameH) / 2;

    // Save frame rectangle for later cropping
    frameRef.current = { x: frameX, y: frameY, w: frameW, h: frameH };

    // Clean and draw mask + window + corners
    ctx.clearRect(0, 0, cw, ch);

    // 1) Dark mask (adjustable by MASK_ALPHA)
    ctx.fillStyle = `rgba(0, 0, 0, ${InitSettingsCamera.maskAlpha})`;
    ctx.fillRect(0, 0, cw, ch);

    // 2) Transparent frame window
    ctx.globalCompositeOperation = 'destination-out';
    ctx.fillStyle = `${ColorsEpico.ColorblackLiteSecondary}`;
    ctx.fillRect(frameX, frameY, frameW, frameH);

    // 3) Return to normal and draw subtle edges/corners
    ctx.globalCompositeOperation = 'source-over';

    // Cornerbacks
    const cornerLen = Math.min(frameW, frameH) * InitSettingsCamera.cornerLenPCT;
    ctx.lineWidth = 4;
    ctx.lineCap = 'round';   // << rounded edges at ends
    ctx.lineJoin = 'round';  // << smoothed joins

    // Radius of the curve in the “L”
    const r = Math.min(cornerLen * 0.35, 14); // adjustable (px); 10–14 

    // Helper for drawing a rounded “L” with 'arcTo'
    // x,y = vertex of the frame; dx/dy define the direction of the L (+1 / -1)
    const drawCorner = (x: number, y: number, dx: 1 | -1, dy: 1 | -1) => {
      ctx.beginPath();
      // Vertical segment: from outside towards the vertex leaving space 'r'
      ctx.moveTo(x, y + dy * cornerLen);
      ctx.lineTo(x, y + dy * r);
      // Curve at the vertex
      ctx.arcTo(x, y, x + dx * r, y, r);
      // Horizontal segment
      ctx.lineTo(x + dx * cornerLen, y);
      ctx.stroke();
    };

    // Corners (clockwise)
    // top-left (dx=+1, dy=+1)
    drawCorner(frameX, frameY, +1, +1);
    // top-right (dx=-1, dy=+1)
    drawCorner(frameX + frameW, frameY, -1, +1);
    // bottom-right (dx=-1, dy=-1)
    drawCorner(frameX + frameW, frameY + frameH, -1, -1);
    // bottom-left (dx=+1, dy=-1)
    drawCorner(frameX, frameY + frameH, +1, -1);
  };

  /**
   * Single exit point from capture to upload: rectify, downscale with Lanczos and
   * encode with MozJPEG aiming AT the byte budget.
   *
   * The old path encoded to JPEG here and then `compressIfNeeded` decoded and
   * re-encoded it, so every upload carried two generations of loss and, worse,
   * anything that happened to land under the ceiling was shipped as-is — leaving
   * most of the budget unspent instead of buying quality with it.
   *
   * Perspective correction only runs for the invoice: a warped quad is the right
   * model for a sheet of paper, not for a photo of a damaged package.
   */
  const runUploadPipeline = async (canvas: HTMLCanvasElement): Promise<File> => {
    const { buildUploadFile } = await import('@/features/cameraMobile/infrastructure/utils/imagePipeline');
    const result = await buildUploadFile(canvas, {
      maxBytes: validationMaxBytes,
      fileName: `captura_${Date.now()}.jpg`,
      // Crop to the sheet and flatten its perspective, on BOTH steps: the evidence
      // is itself a photo of the signed invoice, so it is just as much a document
      // as the invoice step is.
      //
      // Gated on the native route only, and that is the whole reason this works
      // now. The in-app shutter hands over a canvas already cropped to the guide,
      // with no paper border left to find, so the detector settles for the
      // highest-contrast rectangle that remains — a printed box on the invoice. A
      // photo from the phone's camera app is the whole scene, desk included, which
      // is exactly what the detector needs.
      //
      // Safe to run on a capture that is NOT a document: the confidence, coverage,
      // shape and orientation gates reject it and the photo passes through whole.
      dewarp: captureMode === 'native',
    });
    console.info('Resultado del pipeline de imagen:', {
      px: `${result.width}x${result.height}`,
      mp: ((result.width * result.height) / 1_000_000).toFixed(1),
      kb: Math.round(result.file.size / 1000),
      rectificada: result.dewarped,
      mozjpeg: result.usedMozjpeg,
    });
    return result.file;
  };

  /**
   * Handles a photo taken with the phone's own camera app.
   *
   * This is the only route to the full native pipeline — the sensor's real
   * resolution (50 MP on the Galaxy A17), HDR, multi-frame noise reduction and
   * the phone's proper phase-detect autofocus. getUserMedia cannot reach any of
   * that: it delivers a preview stream, which tops out around 1080p-4K.
   *
   * The trade-off is that there is no guide frame, so the shot is not cropped to
   * the letter rectangle. That is why this is only offered where OCR is off
   * (evidence photos); the invoice step keeps the guided capture because its OCR
   * reads a fixed quadrant of the framed image.
   */
  const handleNativePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = e.target.files?.[0];
    // Reset immediately so picking the same file twice still fires onChange.
    e.target.value = '';
    if (!picked) return;

    setBusy(true);
    try {
      // Decode with a size cap — a 50 MP still is ~200 MB once expanded to RGBA —
      // then run the same pipeline as the in-app shutter so both routes produce a
      // file of the same shape and the same .jpg name the backend requires.
      const { fileToCanvas } = await import('@/features/cameraMobile/infrastructure/utils/imagePipeline');
      const canvas = await fileToCanvas(picked);

      // The invoice is a LANDSCAPE letter sheet (11 × 8.5 in) and the courier is
      // told to lay it turned to the left, so a shot framed portrait arrives with
      // the header running up the left edge. Turning it clockwise puts the header
      // back on top and the sheet horizontal, which is both how a person reads it
      // and what the OCR quadrant assumes.
      //
      // Driven by the actual shape rather than by a flag: if the phone was already
      // held landscape the photo needs no turn, and rotating it anyway would lay a
      // correct capture on its side.
      const oriented = (useLetterFrame && canvas.height > canvas.width)
        ? ensureLandscapeByStripes(canvas)
        : canvas;

      const processed = await runUploadPipeline(oriented);
      await showPreview(processed);
    } catch (nativeErr) {
      setError('Error al procesar la foto: ' + ((nativeErr as Error)?.message ?? 'desconocido'));
    } finally {
      setBusy(false);
    }
  };

  /**
   * Single entry point for every applyConstraints call on the video track.
   *
   * applyConstraints REPLACES the track's whole constraint set, so any call that
   * sends one property on its own silently drops everything negotiated before it:
   * the torch goes out, zoom:1 is lost (which can hand the camera back to the
   * ultra-wide lens) and the continuous modes are cleared. This rebuilds the base
   * set every time and layers the caller's extras on top — advanced sets are
   * applied in order, so a later entry wins over the base for the same property.
   */
  const applyCameraConstraints = async (
    track: MediaStreamTrack,
    extra: ExtendedMediaTrackConstraintSet[] = [],
    torchOverride?: boolean,
  ) => {
    const caps = (track.getCapabilities?.() ?? {}) as ExtendedMediaTrackCapabilities;
    const advanced: ExtendedMediaTrackConstraintSet[] = [];

    if (caps.zoom && caps.zoom.min <= 1 && caps.zoom.max >= 1) advanced.push({ zoom: 1 });
    if (caps.focusMode?.includes('continuous')) advanced.push({ focusMode: 'continuous' });
    if (caps.exposureMode?.includes('continuous')) advanced.push({ exposureMode: 'continuous' });
    if (caps.whiteBalanceMode?.includes('continuous')) advanced.push({ whiteBalanceMode: 'continuous' });

    advanced.push(...extra);

    const torchSupported = caps.torch === true || (Array.isArray(caps.torch) && caps.torch.includes(true));
    const torchWanted = torchOverride ?? torchOn;
    if (torchSupported) advanced.push({ torch: torchWanted });

    if (advanced.length) await track.applyConstraints({ advanced });
  };

  /**
   * Focuses the camera on a point the user tapped, the same gesture the native
   * camera app offers. Coordinates are normalised (0..1) over the displayed video.
   *
   * Chromium-only and device-dependent; on hardware without `pointsOfInterest`
   * this degrades to a single-shot refocus, and on Safari/iOS it does nothing.
   */
  const focusAtPoint = async (xNorm: number, yNorm: number) => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    try {
      const caps = (track.getCapabilities?.() ?? {}) as ExtendedMediaTrackCapabilities;
      const extra: ExtendedMediaTrackConstraintSet[] = [];
      if (caps.pointsOfInterest) extra.push({ pointsOfInterest: [{ x: xNorm, y: yNorm }] });
      if (caps.focusMode?.includes('single-shot')) extra.push({ focusMode: 'single-shot' });
      await applyCameraConstraints(track, extra);
    } catch (focusErr) {
      console.warn('No se pudo enfocar en el punto indicado:', focusErr);
    }
  };

  /**
   * Maps a tap on the preview to normalised video coordinates and focuses there.
   * The video is drawn with object-fit: contain, so the letterbox offset has to be
   * removed before normalising, or the focus point lands off-target.
   */
  const handlePreviewTap = (e: React.MouseEvent<HTMLDivElement>) => {
    if (previewUrl || busy) return; // not while reviewing a shot or mid-capture
    const container = containerRef.current;
    const video = videoRef.current;
    if (!container || !video || !video.videoWidth || !video.videoHeight) return;

    const rect = container.getBoundingClientRect();
    const px = e.clientX - rect.left;
    const py = e.clientY - rect.top;

    // Same object-fit: cover mapping as takePhoto. The raster overflows the
    // container, so half the excess is added before normalising; there are no
    // letterbox bars to exclude, the video covers the whole container.
    const scale = Math.max(rect.width / video.videoWidth, rect.height / video.videoHeight);
    const displayedW = video.videoWidth * scale;
    const displayedH = video.videoHeight * scale;
    const offsetHalfX = (displayedW - rect.width) / 2;
    const offsetHalfY = (displayedH - rect.height) / 2;

    const xNorm = Math.min(1, Math.max(0, (px + offsetHalfX) / displayedW));
    const yNorm = Math.min(1, Math.max(0, (py + offsetHalfY) / displayedH));

    setFocusPoint({ x: px, y: py });
    if (focusPointTimerRef.current) clearTimeout(focusPointTimerRef.current);
    focusPointTimerRef.current = setTimeout(() => setFocusPoint(null), 900);

    void focusAtPoint(xNorm, yNorm);
  };

  /**
   * Toggles the LED torch. On an invoice photographed inside a delivery van this
   * is often the difference between readable and not.
   */
  const toggleTorch = async () => {
    const track = streamRef.current?.getVideoTracks()[0];
    if (!track) return;
    const next = !torchOn;
    try {
      await applyCameraConstraints(track, [], next);
      setTorchOn(next);
    } catch (torchErr) {
      console.warn('No se pudo cambiar la linterna:', torchErr);
      setTorchAvailable(false);
    }
  };

  /**
   * Asks the camera to focus on the centre of the guide, waits for autofocus and
   * auto-exposure to converge, and then resolves on a genuinely NEW video frame.
   *
   * Both halves matter: without the delay the shutter captures whatever frame was
   * last decoded, which is usually the one carrying the shake of the finger tap;
   * without the fresh-frame wait the delay alone would not guarantee that the
   * converged frame is the one we read.
   *
   * Everything here is best-effort — Safari/iOS exposes none of these controls —
   * so no failure is allowed to block the capture.
   */
  const settleFocus = async (track?: MediaStreamTrack) => {
    if (track) {
      try {
        const caps = (track.getCapabilities?.() ?? {}) as ExtendedMediaTrackCapabilities;
        const extra: ExtendedMediaTrackConstraintSet[] = [];
        if (caps.pointsOfInterest) extra.push({ pointsOfInterest: [{ x: 0.5, y: 0.5 }] });
        if (caps.focusMode?.includes('single-shot')) extra.push({ focusMode: 'single-shot' });
        // Through the helper so the torch stays lit through the shot.
        await applyCameraConstraints(track, extra);
      } catch {
        // Not supported on this device: the delay below still helps.
      }
    }

    // Typical AF + AE convergence window.
    await new Promise((resolve) => setTimeout(resolve, 450));

    // Wait for a frame decoded AFTER the settle window, when the browser can tell
    // us (Chromium). Capped by a timeout so an unsupported or stalled video can
    // never hang the shutter.
    const video = videoRef.current as (HTMLVideoElement & {
      requestVideoFrameCallback?: (cb: () => void) => number;
    }) | null;
    if (video?.requestVideoFrameCallback) {
      await new Promise<void>((resolve) => {
        let done = false;
        const finish = () => { if (!done) { done = true; resolve(); } };
        video.requestVideoFrameCallback!(finish);
        setTimeout(finish, 300);
      });
    }

    // Hand autofocus back to continuous. Without this the track stays in
    // 'single-shot' after the first capture, with the focus distance frozen where
    // that shot left it — so every retake, which is exactly when the courier is
    // trying to get a better picture, comes out focused for the previous frame.
    if (track) {
      try {
        // The base set the helper rebuilds already puts focusMode back to
        // 'continuous' and re-asserts the torch, so no extras are needed.
        await applyCameraConstraints(track);
      } catch {
        // Not supported: nothing to restore.
      }
    }
  };

  /*
  *  Photo capture (with frame cropping)
  */
  const takePhoto = async () => {
    if (!videoRef.current || !streamRef.current || !containerRef.current) return;
    setBusy(true);
    try {
      const track = streamRef.current.getVideoTracks()[0];
      const w = window as any;

      // Give autofocus/exposure a chance to converge and make sure we read a
      // FRESH frame. The shutter used to fire instantly on whatever frame was
      // last decoded — typically the one holding the shake of the finger tap.
      await settleFocus(track);

      // ImageCapture.takePhoto() reconfigures the camera and captures at the
      // sensor's PHOTO resolution instead of the preview's, which is several times
      // more pixels. It used to be gated behind `!isMobileDevice`, i.e. disabled on
      // Chrome Android — the only mobile browser that implements it — and enabled
      // on desktop, where webcams have no separate photo mode and it gains nothing.
      // Now it is gated on the capability, with a silent fallback to the video
      // frame (which is the path iOS/Safari always takes, since it has no
      // ImageCapture in any version).
      let photoBlob: Blob | null = null;

      // Desktop only. Enabling this on Android looked like free resolution, but it
      // brought a non-deterministic failure this flow cannot absorb: the still and
      // the preview do not always share an orientation, and the crop below maps one
      // onto the other assuming they do — so the sheet comes back cut on the wrong
      // side and the Serie-Folio block, which is what the OCR reads, can fall
      // outside the frame. On Samsung the promised gain is not there either:
      // takePhoto() reconfigures the capture session, which discards the autofocus
      // convergence settleFocus() just waited for.
      const isMobileDevice = regexMobileOperatingSystem.test(navigator.userAgent);

      if (!isMobileDevice && track && typeof w.ImageCapture === 'function') {
        try {
          const imageCapture = new w.ImageCapture(track);
          // Ask for the real maximum instead of a hardcoded 2560x1440: passing
          // dimensions outside getPhotoCapabilities() makes takePhoto() throw on
          // several Android devices.
          let photoSettings: Record<string, unknown> = {};
          try {
            const photoCaps = await imageCapture.getPhotoCapabilities();
            if (photoCaps?.imageWidth?.max && photoCaps?.imageHeight?.max) {
              photoSettings = {
                imageWidth: photoCaps.imageWidth.max,
                imageHeight: photoCaps.imageHeight.max,
              };
            }
          } catch {
            // Not supported: takePhoto() with no settings still uses the sensor default.
          }
          photoBlob = await imageCapture.takePhoto(photoSettings);
        } catch (captureErr) {
          console.warn('takePhoto() no disponible, se usa el frame de video:', captureErr);
          photoBlob = null;
        }
      }

      // We calculate the crop according to the visible frame (object-fit: contain)
      const video = videoRef.current!;
      const container = containerRef.current!;

      const videoW = video.videoWidth;
      const videoH = video.videoHeight;
      const contW = container.clientWidth;
      const contH = container.clientHeight;

      if (!videoW || !videoH) {
        setError('Error al capturar la foto: el video aún no tiene dimensiones');
        return;
      }

      // Must match the video CSS: objectFit 'cover'. The raster overflows the
      // container, so its top-left sits at a NEGATIVE offset and half the excess
      // has to be added back before dividing by the scale.
      const scale = Math.max(contW / videoW, contH / videoH);
      const displayedW = videoW * scale;
      const displayedH = videoH * scale;

      const offsetHalfX = (displayedW - contW) / 2;
      const offsetHalfY = (displayedH - contH) / 2;

      const { x: frameX, y: frameY, w: frameW, h: frameH } = frameRef.current;

      // Container mapping -> video coords
      const srcX_video = (frameX + offsetHalfX) / scale;
      const srcY_video = (frameY + offsetHalfY) / scale;
      const srcW_video = frameW / scale;
      const srcH_video = frameH / scale;

      if (photoBlob) {
        // === Option B: Crop the ImageCapture photo while maintaining better quality
        // Convert the blob to an ImageBitmap (or HTMLImageElement)
        let bitmap: ImageBitmap;
        try {
          // some 'TS' do not have type imageOrientation -> we ignore the type error
          bitmap = await createImageBitmap(photoBlob, { imageOrientation: 'from-image' });
        } catch {
          // fallback: as before
          bitmap = await createImageBitmap(photoBlob);
        }
        const photoW = bitmap.width;
        const photoH = bitmap.height;

        // Convert the crop computed in VIDEO coordinates into PHOTO coordinates.
        // These two rasters often have different aspect ratios (a 16:9 preview is
        // usually a centred crop of the sensor's native 4:3 still), so scaling the
        // fractions straight onto photoW/photoH — as this did before — shifted and
        // stretched the crop whenever they disagreed. Instead, locate the preview's
        // field of view inside the photo first: the largest centred rect with the
        // video's aspect ratio.
        const videoAspect = videoW / videoH;
        const photoAspect = photoW / photoH;
        let fovW = photoW;
        let fovH = photoH;
        if (photoAspect > videoAspect) {
          // Photo is wider than the preview: the preview is a horizontal crop.
          fovW = photoH * videoAspect;
        } else if (photoAspect < videoAspect) {
          // Photo is taller than the preview: the preview is a vertical crop.
          fovH = photoW / videoAspect;
        }
        const fovX = (photoW - fovW) / 2;
        const fovY = (photoH - fovH) / 2;

        // Now the video-relative fractions map linearly inside that field of view.
        const fovScale = fovW / videoW;
        const srcX_photo = fovX + srcX_video * fovScale;
        const srcY_photo = fovY + srcY_video * fovScale;
        const srcW_photo = srcW_video * fovScale;
        const srcH_photo = srcH_video * fovScale;

        // Clamp in case the fractions go beyond the edges
        const sx = Math.max(0, Math.min(photoW, srcX_photo));
        const sy = Math.max(0, Math.min(photoH, srcY_photo));
        const sw = Math.max(1, Math.min(photoW - sx, srcW_photo));
        const sh = Math.max(1, Math.min(photoH - sy, srcH_photo));

        const outCanvas = document.createElement('canvas');
        outCanvas.width = Math.round(sw);
        outCanvas.height = Math.round(sh);
        const outCtx = outCanvas.getContext('2d', { alpha: false })!;
        outCtx.imageSmoothingEnabled = true;
        outCtx.imageSmoothingQuality = 'high';
        outCtx.drawImage(bitmap, sx, sy, sw, sh, 0, 0, outCanvas.width, outCanvas.height);
        // Only the invoice is rotated. That 90° turn exists because the courier is
        // told to lay the sheet sideways ("Colocar la factura vertical orientada a
        // la izquierda") and the OCR expects the result upright. Evidence photos
        // get no such instruction, so rotating them just delivered every one of
        // them lying on its side.
        const readyCanvas = (isMobile && useLetterFrame)
          ? ensureLandscapeByStripes(outCanvas)
          : outCanvas;
        // Close bitmap to prevent memory leak
        bitmap.close?.();
        const file = await runUploadPipeline(readyCanvas);
        await showPreview(file);
      } else {
        // =========== OPTION B: Fallback (crop from the <video> frame) ===========
        // Clamp the source rect to the frame. drawImage with an out-of-bounds
        // source silently yields transparent/blank edges; the ImageCapture branch
        // above already clamps, this one did not.
        const sx = Math.max(0, Math.min(videoW, srcX_video));
        const sy = Math.max(0, Math.min(videoH, srcY_video));
        const sw = Math.max(1, Math.min(videoW - sx, srcW_video));
        const sh = Math.max(1, Math.min(videoH - sy, srcH_video));

        // 1:1 with the real video pixels. This canvas used to be sized
        // srcW_video * devicePixelRatio with imageSmoothingEnabled = false, which
        // replicated pixels nearest-neighbour: dpr² times the bytes (~7x on a
        // typical Android), zero extra detail, stair-stepped edges, and the
        // inflated file then dragged the quality search down to q=0.60.
        const outCanvas = document.createElement('canvas');
        outCanvas.width = Math.round(sw);
        outCanvas.height = Math.round(sh);
        const outCtx = outCanvas.getContext('2d', { alpha: false })!;
        outCtx.imageSmoothingEnabled = true;
        outCtx.imageSmoothingQuality = 'high';

        outCtx.drawImage(
          video,
          sx, sy, sw, sh,
          0, 0, outCanvas.width, outCanvas.height
        );

        // Same rule as the ImageCapture branch above: rotate the invoice only.
        const readyCanvas = (isMobile && useLetterFrame)
          ? ensureLandscapeByStripes(outCanvas)
          : outCanvas;
        const file = await runUploadPipeline(readyCanvas);
        await showPreview(file);
      }

    } catch (err: any) {
      setError('Error al capturar la foto: ' + (err?.message ?? 'desconocido'));
    } finally {
      setBusy(false);
    }
  };

  /**
     * Compresses an image file to ensure it does not exceed a target size in bytes.
     *
     * @param {File} file - The original image file to check and compress if necessary
     * @param {number} [targetBytes=1024*1024] - Maximum allowed file size in bytes (default: 1 MB)
     * @returns {Promise<File>} A promise that resolves with:
     * - The original file if its size is already under the limit
     * - A new compressed JPEG file if it exceeds the size limit
     */
  const compressIfNeeded = async (file: File, targetBytes = validationMaxBytes) => {
    // We accept files that are at or below the limit.
    if (file.size <= targetBytes) return file; 
    // Upload respecting EXIF
    let bmp: ImageBitmap;
    try {
      // @ts-ignore: some TS do not type imageOrientation
      bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
    } catch {
      bmp = await createImageBitmap(file);
    }
    // Redraw at a given long-side length, downscaling with high-quality filtering.
    const drawScaled = (longSide: number) => {
      const scale = Math.min(1, longSide / Math.max(bmp.width, bmp.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bmp.width * scale));
      canvas.height = Math.max(1, Math.round(bmp.height * scale));
      const ctx = canvas.getContext('2d', { alpha: false })!;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
      return canvas;
    };

    const toBlobAsync = (canvas: HTMLCanvasElement, q: number) =>
      new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (b) => (b ? resolve(b) : reject(new Error('toBlob falló'))),
          'image/jpeg',
          q
        )
      );

    // Reduce DIMENSIONS first and keep quality high, instead of holding the
    // dimensions and driving quality down to 0.60 (which is what this function
    // used to do — it never rescaled at all). On text, JPEG block artefacts
    // destroy legibility much faster than a moderate downscale does: ~1800 px on
    // the long side is ~165 DPI over a letter sheet, and at that size 1 MB
    // affords q≈0.90 with no visible blocking.
    const LONG_SIDES = [2400, 2000, 1800, 1600, 1400, 1200];
    // Preferred quality band: shrink the image rather than drop below this.
    const Q_HIGH = [0.92, 0.88];
    // Only used if even 1200 px on the long side will not fit the budget.
    const Q_LAST_RESORT = [0.84, 0.80, 0.75, 0.70];

    let best: Blob | null = null;
    // Release each intermediate canvas: Safari iOS caps total canvas memory per
    // page and starts returning blank images once that cap is hit.
    const release = (canvas: HTMLCanvasElement) => { canvas.width = 0; canvas.height = 0; };

    const trySizes = async (qualities: number[]) => {
      for (const longSide of LONG_SIDES) {
        const canvas = drawScaled(longSide);
        try {
          for (const q of qualities) {
            const blob = await toBlobAsync(canvas, q);
            // Keep the smallest attempt so far, in case nothing ever fits.
            if (!best || blob.size < best.size) best = blob;
            if (blob.size <= targetBytes) return true;
          }
        } finally {
          release(canvas);
        }
      }
      return false;
    };

    // Pass 1: hold quality high and come down in dimensions. Pass 2 only runs if
    // the budget is still not met at the smallest size.
    if (!(await trySizes(Q_HIGH))) {
      await trySizes(Q_LAST_RESORT);
    }
    bmp.close?.();

    if (!best) throw new Error('No se pudo comprimir la imagen');
    return new File([best], file.name.replace(/\.[^.]+$/, '') + '_u1mb.jpg', { type: 'image/jpeg' });
  };

  /*
  *  show image preview
  */
  const showPreview = async (file: File) => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setProcessingImage(true);
    // Quick preview but disable OCR until we have compressed version
    const fastUrl = URL.createObjectURL(file);
    setPreviewUrl(fastUrl);
    setCapturedFile(null); // avoid using uncompressed file
    setShowOcr(false);
    videoRef.current?.pause();

    // Then validate and compress in background
    try {
      const sizedFile = await compressIfNeeded(file, validationMaxBytes);
      
      // Check if compression was successful
      if (sizedFile.size > validationMaxBytes) {
        const kb = Math.round(sizedFile.size / 1000);
        showSnackbar(`La imagen pesa ${kb} KB y no se pudo comprimir lo suficiente (máximo permitido: 1000 KB). Toma otra imagen.`, 'warning');
        setTimeout(() => { clearPreview(false); }, 2000);
        return;
      }
      setCapturedFile(sizedFile);
      URL.revokeObjectURL(fastUrl);
      const compressedUrl = URL.createObjectURL(sizedFile);
      setPreviewUrl(compressedUrl);

      // Evidence goes straight up once it is processed. A confirm step here was
      // redundant: the shot lands in the evidence list on the digitisation screen,
      // which already offers exactly the same choice — keep it or remove it — so
      // asking twice only put a second tap between the courier and the next photo.
      if (!useOcr) {
        handleDirectUpload(sizedFile, compressedUrl);
        return;
      }

      // Continue with upright preview for OCR
      Promise.resolve().then(async () => {
        try {
          const uprightUrl = await makeUprightPreviewURL(sizedFile);
          setPreviewUrl(prev => {
            if (prev === compressedUrl) {
              URL.revokeObjectURL(compressedUrl);
              return uprightUrl;
            } else {
              URL.revokeObjectURL(uprightUrl);
              return prev!;
            }
          });
        } catch (err) {
          console.warn("OCR preview upright failed, using compressedUrl instead:", err);
        }
      });
    } catch (err) {
      console.error("Error processing image:", err);
      showSnackbar('Error al procesar la imagen. Intenta nuevamente.', 'error');
      clearPreview(false);
    } finally {
      setProcessingImage(false);
    }
  };

  /*
  * Close preview and return to camera
  * @param {boolean} isManualAttempt - If true, counts as a manual retry attempt (outside OCR)
  */
  const clearPreview = (isManualAttempt: boolean = false) => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setCapturedFile(null);
    setShowOcr(false);
    setresultOcr(null);
    setShowQualityViewer(false); // the image it was inspecting is gone
    videoRef.current?.play(); // resume video

    // Count manual attempts when user manually rejects the photo
    if (isManualAttempt) {
      shouldNotifyManualRef.current = true; // Mark that we should notify about manual change
      setManualAttempts(prev => prev + 1);
      // Notification will happen in useEffect after state update
    }
  };

  /*
  * Handles the invoice review result button with OCR
  */
  const handleOcrResult = (r: IOcrResult) => {
    setresultOcr(r);

    // A photo that reads cleanly but carries ANOTHER invoice's folio is a
    // different problem from one that cannot be read, and it needs a different
    // answer: retaking the same sheet will never fix it. Say so on the first
    // attempt, naming both folios, so the courier goes and gets the right sheet
    // instead of burning attempts on this one.
    const wrongInvoice =
      Boolean(expectedFolio) && r.matchesFolio === false && Boolean(r.detectedFolio);

    if (wrongInvoice) {
      showSnackbar(
        `Esta no es la factura que estás cargando. Se esperaba ${expectedFolio} y la foto muestra ${r.detectedFolio}. Verifica el documento.`,
        'error',
      );
      clearPreview(false);
      return;
    }

    if (!r.isLegible) {
      // Attempt was already registered when OCR started, just check limit
      if (ocrAttempts < limitTry) {
        showSnackbar(`La factura NO es legible. Intento ${ocrAttempts}/${limitTry}. Vuelve a tomar la foto.`, 'info');
        clearPreview(false); // OCR attempt, not manual
        return;
      }
      // LIMIT REACHED - Show confirmation modal
      setShowOcr(false);
      setresultOcr(null);
      setShowConfirmationModal(true);
      return;
    }
    // Readable case (success)
    const sizeBytes = r.sourceFile?.size ?? capturedFile?.size ?? 0;
    const under1MB = sizeBytes > 0 && sizeBytes <= validationMaxBytes;
    if (!under1MB) {
      const kb = sizeBytes ? Math.round(sizeBytes / 1000) : 0;
      showSnackbar(`La imagen pesa ${kb} KB (máximo permitido: 1000 KB). Toma otra imagen.`, 'info');
      clearPreview(false); // Technical error, not a manual attempt
      return;
    }

    // Process completed successfully - send final attempts
    notifyFinalAttempts(r.previewDataUrl);

    // Reset counters after notifying
    setOcrAttempts(0);
    setManualAttempts(0);

    onResult?.(r);
    handleClose();
    showSnackbar('Documento válido.', 'success');
  };

  /*
  * Handles the "Yes" action in the confirmation modal.
  */
  const handleConfirmYes = () => {
    if (capturedFile && previewUrl) {
      shouldNotifyManualRef.current = true;
      // Store file and previewUrl to upload after notification
      pendingUploadRef.current = { file: capturedFile, previewUrl };
      setManualAttempts(prev => prev + 1);
      // The useEffect will notify about the manual attempt change and then execute the upload
    }
  };
  /*
   * Handles the "No" action in the confirmation modal.
   */
  const handleConfirmNo = () => {
    setShowConfirmationModal(false);
    setresultOcr(null);
    clearPreview(true); // Manual rejection, counts as manual attempt
    showSnackbar('Vuelve a tomar la foto de la factura.', 'info');
  };

  /*
  * Handles direct upload without OCR processing
  * @param file - The file to upload
  * @param previewUrl - The preview URL of the image
  * @param skipNotification - If true, skips the final attempts notification (used when already notified)
  */
  const handleDirectUpload = (file: File, previewUrl: string, skipNotification: boolean = false) => {
    // Process completed successfully - send final attempts (unless already notified)
    if (!skipNotification) {
      notifyFinalAttempts(previewUrl);
    }

    // Create a mock OCR result for direct upload
    const mockOcrResult: IOcrResult = {
      text: 'Imagen subida',
      confidence: null,
      isLegible: true, // Mark as valid to allow upload
      previewDataUrl: previewUrl,
      sourceFile: file
    };

    // Reset counters after notifying
    setOcrAttempts(0);
    setManualAttempts(0);

    showSnackbar('Imagen subida', 'success');
    onResult?.(mockOcrResult);
    handleClose();
  }

  /*
  * Handles the cleaning and closing of the chamber
  */
  const handleClose = () => {
    clearPreview(false);
    setOcrAttempts(0);
    setManualAttempts(0);
    setShowConfirmationModal(false);
    onClose();
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      fullScreen
    >
      <DialogTitle sx={{ p: 1 }}>
        <Button onClick={onClose} color="primary">
          <ArrowBackIcon sx={{ fontSize: 18, mr: 1 }} /> VOLVER
        </Button>
      </DialogTitle>
      <DialogContent sx={DialogContentSx}>
        <Box sx={MainContainerSx}>

          {/* Errors */}
          <Box sx={{ p: 1, color: 'crimson', fontSize: 14 }}>
            {error && <p style={{ color: 'crimson', marginTop: 0 }}>{error}</p>}
            {previewUrl && (
              <Typography sx={{ fontSize: FontSizesEnum.Epsilon, color: ColorsEpico.ColorPrimary, fontWeight: FontWeightEnum.Medium }}>
                Verifica que tu imagen esta correcta.
              </Typography>
            )}

            {!previewUrl && isMobile && effectiveShowInstructionText && (
              <Typography sx={{ fontSize: FontSizesEnum.Epsilon, color: ColorsEpico.ColorPrimary, fontWeight: FontWeightEnum.Medium }}>
                Colocar la factura vertical orientada a la izquierda
              </Typography>
            )}
          </Box>


          {/* Container that defines the visible size and supports absolute overlay */}
          <Box
            ref={containerRef}
            sx={{
              ...VideoContainerSx,
              cursor: captureMode === 'live' && canTapFocus && !previewUrl ? 'crosshair' : 'default',
            }}
            onClick={captureMode === 'live' && canTapFocus ? handlePreviewTap : undefined}
          >
            {/* Native mode: no live stream at all. One tap opens the phone's own
                camera app; the shot comes back through handleNativePhoto and lands
                in the same preview as any other capture. */}
            {captureMode === 'native' && !previewUrl && (
              <Box
                sx={{
                  position: 'absolute',
                  inset: 0,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 2.5,
                  px: 4,
                  textAlign: 'center',
                }}
              >
                <PhotoCameraIcon sx={{ fontSize: 64, color: ColorsEpico.ColorWhite, opacity: 0.9 }} />
                <Typography sx={{ color: ColorsEpico.ColorWhite, fontSize: FontSizesEnum.Delta, fontWeight: FontWeightEnum.Medium }}>
                  Toma la foto con la cámara del teléfono
                </Typography>
                <Typography sx={{ color: ColorsEpico.ColorWhite, opacity: 0.75, fontSize: FontSizesEnum.Epsilon }}>
                  Se abrirá tu cámara con toda su calidad y su flash. Al terminar
                  regresas aquí para revisarla y enviarla.
                </Typography>
                <Button
                  variant="contained"
                  size="large"
                  startIcon={<PhotoCameraIcon />}
                  disabled={busy}
                  onClick={() => nativeInputRef.current?.click()}
                  sx={{ mt: 1, px: 4, py: 1.5, borderRadius: 8 }}
                >
                  Abrir cámara
                </Button>
                <Button
                  variant="text"
                  onClick={() => setCaptureMode('live')}
                  sx={{
                    color: ColorsEpico.ColorWhite,
                    opacity: 0.8,
                    fontSize: FontSizesEnum.Epsilon,
                    // Con la fuente de 12px y el padding por defecto de MUI este botón
                    // sale a ~33px, por debajo del objetivo táctil de 44px, y el tema no
                    // lo sube: `MuiButton` solo declara `textTransform`. No es un control
                    // marginal —es el único camino desde el modo nativo a la cámara con
                    // guía—, así que se le fija el alto. Solo en móvil: desde la 3.40.0 el
                    // modo nativo también se abre en escritorio, y ahí va el de fábrica
                    // (sin alto mínimo y 8px de relleno, el del botón de texto).
                    minHeight: { xs: 44, md: 'auto' },
                    px: { xs: 2, md: 1 },
                  }}
                >
                  Usar la cámara de la app con guía
                </Button>
              </Box>
            )}

            {/* Full screen video inside the container */}
            <video
              ref={videoRef}
              hidden={captureMode !== 'live'}
              style={{
                position: 'absolute',
                inset: 0,
                width: '100%',
                height: '100%',
                // 'cover'. Letterboxing the raster with 'contain' shrank the live
                // view — and with it the guide — to a fraction of the viewport on
                // any landscape raster, which is what the courier frames and judges
                // focus by. See drawOverlay for the full reasoning.
                objectFit: 'cover',
              }}
              autoPlay
              playsInline
              muted
            />

            {/* Canvas overlay for the frame/guide */}
            <canvas
              ref={overlayRef}
              hidden={captureMode !== 'live'}
              style={{
                position: 'absolute',
                inset: 0,
                width: '100%',
                height: '100%',
                pointerEvents: 'none', // important: does not block clicks
              }}
            />

            {/* Focus ring: feedback for the tap-to-focus gesture */}
            {focusPoint && !previewUrl && (
              <Box
                sx={{
                  position: 'absolute',
                  left: focusPoint.x - 32,
                  top: focusPoint.y - 32,
                  width: 64,
                  height: 64,
                  borderRadius: '50%',
                  border: `2px solid ${ColorsEpico.ColorWhite}`,
                  boxShadow: '0 0 0 1px rgba(0,0,0,0.4)',
                  pointerEvents: 'none',
                }}
              />
            )}

            {/* The input backing the phone's camera app. Always mounted, because
                Safari refuses to open the picker for an input that is not
                rendered, and both capture modes reach it. */}
            <input
              ref={nativeInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleNativePhoto}
              style={{ position: 'absolute', left: -9999, width: 1, height: 1 }}
            />

            {/* In live mode, a shortcut to the phone's camera app without leaving. */}
            {captureMode === 'live' && !previewUrl && (
              <Tooltip title="Tomar con la cámara del teléfono (máxima calidad)">
                <IconButton
                  aria-label="Tomar con la cámara del teléfono"
                  onClick={(e) => { e.stopPropagation(); nativeInputRef.current?.click(); }}
                  sx={{
                    position: 'absolute',
                    top: 12,
                    left: 12,
                    bgcolor: 'rgba(0,0,0,0.45)',
                    color: ColorsEpico.ColorWhite,
                    '&:hover': { bgcolor: 'rgba(0,0,0,0.65)' },
                  }}
                >
                  <PhotoCameraIcon />
                </IconButton>
              </Tooltip>
            )}

            {/* Torch: only for the in-app stream. The phone's camera app runs its
                own flash, and the track is not even open in native mode. */}
            {captureMode === 'live' && torchAvailable && !previewUrl && (
              <IconButton
                aria-label={torchOn ? 'Apagar linterna' : 'Encender linterna'}
                onClick={(e) => { e.stopPropagation(); void toggleTorch(); }}
                sx={{
                  position: 'absolute',
                  top: 12,
                  right: 12,
                  bgcolor: 'rgba(0,0,0,0.45)',
                  color: torchOn ? ColorsEpico.ColorPrimary : ColorsEpico.ColorWhite,
                  '&:hover': { bgcolor: 'rgba(0,0,0,0.65)' },
                }}
              >
                {torchOn ? <FlashOnIcon /> : <FlashOffIcon />}
              </IconButton>
            )}
            {/* Processing overlay. The pipeline decodes, rescales and encodes a
                multi-megapixel photo, which takes a visible moment on a mid-range
                phone; without this the screen just sits there and the courier taps
                again thinking nothing happened. */}
            {(busy || processingImage) && (
              <Box
                sx={{
                  position: 'absolute',
                  inset: 0,
                  zIndex: 5,
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: 2,
                  bgcolor: 'rgba(0,0,0,0.72)',
                }}
              >
                <CircularProgress size={48} sx={{ color: ColorsEpico.ColorWhite }} />
                <Typography sx={{ color: ColorsEpico.ColorWhite, fontSize: FontSizesEnum.Delta, fontWeight: FontWeightEnum.Medium }}>
                  Procesando la foto…
                </Typography>
                <Typography sx={{ color: ColorsEpico.ColorWhite, opacity: 0.7, fontSize: FontSizesEnum.Epsilon }}>
                  No cierres esta pantalla
                </Typography>
              </Box>
            )}

            {/* show the photo taken */}
            {previewUrl && (
              <Box sx={PreviewOverlaySx}>
                <Box
                  component="img"
                  src={previewUrl}
                  alt="Vista previa"
                  onClick={() => setShowQualityViewer(true)}
                  sx={{ ...PreviewImageSx, cursor: 'zoom-in' }}
                />
                {/* The inline preview is too small to judge legibility; this opens
                    the full screen viewer with zoom and the real pixel figures. */}
                <Tooltip title="Revisar calidad (ampliar)">
                  <IconButton
                    aria-label="Revisar calidad de la foto"
                    onClick={() => setShowQualityViewer(true)}
                    sx={{
                      position: 'absolute',
                      bottom: 12,
                      right: 12,
                      bgcolor: 'rgba(0,0,0,0.55)',
                      color: ColorsEpico.ColorWhite,
                      '&:hover': { bgcolor: 'rgba(0,0,0,0.75)' },
                    }}
                  >
                    <ZoomInIcon />
                  </IconButton>
                </Tooltip>
              </Box>
            )}
          </Box>

          {/* Button row */}
          <Box sx={ButtonRowSx}>
            {/****BUTTONS*****/}

            {/* Left button: Resume */}
            <Box>
              <IconButton
                aria-label="Retomar"
                disabled={!previewUrl}
                onClick={() => clearPreview(true)}
                sx={IconButtonSx}
              >
                <CachedIcon />
              </IconButton>
            </Box>

            {/*  column 2 */}

            {/* Middle button type fire with loading */}

            {/* Shutter: only for the in-app stream. In native mode the phone's
                camera app owns the shutter, so rendering a dead one here would
                just be a control that does nothing. */}
            <DialogActions sx={{ justifyContent: "center", visibility: captureMode === 'live' || previewUrl ? 'visible' : 'hidden' }}>
              <Box
                onClick={captureMode === 'live' && !busy && !showOcr && !previewUrl ? takePhoto : undefined}
                sx={{
                  width: 76,
                  height: 76,
                  borderRadius: "50%",
                  border: `4px solid ${ColorsEpico.ColorGrayLite}`,
                  display: "grid",
                  placeItems: "center",
                  cursor: busy ? "not-allowed" : "pointer",
                  opacity: busy ? 0.5 : 1,
                }}
              >
                {busy ? (
                  <CircularProgress size={36} color="primary" />
                ) : (
                  <Box sx={CaptureButtonInnerSx} />
                )}
              </Box>
            </DialogActions>

            {/*  column 3 (OCR / placeholder) */}
            {(() => {
              const shouldShowOcrButton = previewUrl && !resultOcr && useOcr;
              const shouldReserveSpace = !shouldShowOcrButton && (effectiveShowInstructionText || !useOcr);
              const showSpinner = showOcr || processingImage;

              if (shouldShowOcrButton) {
                return (
                  <IconButton
                    onClick={handleStartOcr}
                    disabled={showSpinner || !capturedFile}
                    sx={CheckIconButtonSx}
                  >
                    {showSpinner ? (
                      <CircularProgress size={20} color="primary" />
                    ) : (
                      <CheckCircle sx={{ color: ColorsEpico.ColorBlack }} />
                    )}
                  </IconButton>
                );
              }
              if (shouldReserveSpace) {
                return <Box sx={{ width: 48, height: 48 }} />;
              }
              return null;
            })()}
          </Box>
          {/* Full screen quality review of the shot just taken */}
          <ImageQualityViewer
            open={showQualityViewer && Boolean(previewUrl)}
            src={previewUrl}
            file={capturedFile}
            onClose={() => setShowQualityViewer(false)}
          />

          {/* only mounts when the user clicks "Check invoice" */}
          {previewUrl && showOcr && (
            <InvoiceOcrValidateModal
              file={capturedFile}
              minConfidence={InitSettingsCamera.confidence}
              rotateImage={rotateImage}
              expectedFolio={expectedFolio}
              onResult={(r: IOcrResult) => { handleOcrResult(r) }}
            />
          )}

          {/* Confirmation modal when max OCR attempts reached */}
          {showConfirmationModal && (
            <Dialog
              open={showConfirmationModal}
              maxWidth="sm"
              fullWidth
            >
              <DialogTitle sx={{ textAlign: 'center', fontWeight: FontWeightEnum.Bold }}>
                Verificación de Imagen
              </DialogTitle>
              <DialogContent>
                <Typography sx={{ textAlign: 'center', fontSize: FontSizesEnum.Epsilon, mb: 2 }}>
                  ¿La imagen capturada muestra la factura de forma clara, visible y legible?
                </Typography>
              </DialogContent>
              <DialogActions sx={{ justifyContent: 'space-around', pb: 3, px: 3 }}>
                <Button
                  variant="outlined"
                  color="error"
                  onClick={handleConfirmNo}
                  sx={{ minWidth: 120 }}
                >
                  No
                </Button>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={handleConfirmYes}
                  sx={{ minWidth: 120 }}
                >
                  Sí
                </Button>
              </DialogActions>
            </Dialog>
          )}
        </Box>
      </DialogContent>
    </Dialog>
  );
};