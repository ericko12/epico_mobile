/**
 * Props for the ImageQualityViewer component.
 * @interface IImageQualityViewerProps
 * @property {boolean} open - Controls whether the viewer is open.
 * @property {string | null} src - Object URL of the image to inspect.
 * @property {File | null} [file] - Captured file, used to report its weight in KB.
 * @property {() => void} onClose - Callback fired when the viewer is dismissed.
 */
export interface IImageQualityViewerProps {
    open: boolean;
    src: string | null;
    file?: File | null;
    onClose: () => void;
}
