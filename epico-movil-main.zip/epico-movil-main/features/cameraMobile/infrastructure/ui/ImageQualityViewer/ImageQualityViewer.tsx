import React, { useEffect, useRef, useState } from 'react';
import { Dialog, Box, IconButton, Typography } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ZoomInIcon from '@mui/icons-material/ZoomIn';
import ZoomOutIcon from '@mui/icons-material/ZoomOut';
import CenterFocusStrongIcon from '@mui/icons-material/CenterFocusStrong';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import { IImageQualityViewerProps } from '@/features/cameraMobile/infrastructure/ui/ImageQualityViewer/ImageQualityViewer.types';

/** Zoom stops. 1 = fit to screen; the rest are multiples of that fit. */
const ZOOM_STEPS = [1, 2, 4, 8];

/**
 * Full screen viewer to inspect a freshly captured photo before sending it.
 *
 * The point is to answer one question the small inline preview cannot: is the
 * text on this evidence actually readable? So it zooms up to 8x with drag to pan,
 * and reports the real pixel dimensions and file weight — the two numbers that
 * say whether a shot is worth keeping.
 */
const ImageQualityViewer: React.FC<IImageQualityViewerProps> = ({ open, src, file, onClose }) => {
    const [zoomIndex, setZoomIndex] = useState(0);
    const [offset, setOffset] = useState({ x: 0, y: 0 });
    const [naturalSize, setNaturalSize] = useState<{ w: number; h: number } | null>(null);

    // Drag state lives in a ref: updating it must not re-render on every pointer move.
    const dragRef = useRef<{ active: boolean; startX: number; startY: number; originX: number; originY: number }>({
        active: false, startX: 0, startY: 0, originX: 0, originY: 0,
    });

    const zoom = ZOOM_STEPS[zoomIndex];

    // Reset the view whenever a different image is opened.
    useEffect(() => {
        if (open) {
            setZoomIndex(0);
            setOffset({ x: 0, y: 0 });
            setNaturalSize(null);
        }
    }, [open, src]);

    const changeZoom = (delta: number) => {
        setZoomIndex((current) => {
            const next = Math.min(ZOOM_STEPS.length - 1, Math.max(0, current + delta));
            // Recentre when returning to fit: a stale offset would leave the image
            // parked off-screen with no way to bring it back.
            if (ZOOM_STEPS[next] === 1) setOffset({ x: 0, y: 0 });
            return next;
        });
    };

    const resetView = () => {
        setZoomIndex(0);
        setOffset({ x: 0, y: 0 });
    };

    const onPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
        if (zoom === 1) return; // nothing to pan while fitted
        dragRef.current = {
            active: true,
            startX: e.clientX,
            startY: e.clientY,
            originX: offset.x,
            originY: offset.y,
        };
        e.currentTarget.setPointerCapture(e.pointerId);
    };

    const onPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
        const drag = dragRef.current;
        if (!drag.active) return;
        setOffset({
            x: drag.originX + (e.clientX - drag.startX),
            y: drag.originY + (e.clientY - drag.startY),
        });
    };

    const onPointerUp = (e: React.PointerEvent<HTMLDivElement>) => {
        dragRef.current.active = false;
        if (e.currentTarget.hasPointerCapture(e.pointerId)) {
            e.currentTarget.releasePointerCapture(e.pointerId);
        }
    };

    const sizeLabel = file ? `${Math.round(file.size / 1000)} KB` : null;
    const pixelLabel = naturalSize ? `${naturalSize.w} × ${naturalSize.h} px` : null;
    const megapixels = naturalSize ? (naturalSize.w * naturalSize.h) / 1_000_000 : null;

    return (
        <Dialog open={open} onClose={onClose} fullScreen>
            <Box
                sx={{
                    position: 'relative',
                    width: '100%',
                    height: '100%',
                    bgcolor: ColorsEpico.ColorBlack,
                    overflow: 'hidden',
                    touchAction: 'none', // we handle panning ourselves
                }}
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerUp}
            >
                {src && (
                    <Box
                        component="img"
                        src={src}
                        alt="Revisión de calidad"
                        draggable={false}
                        onLoad={(e: React.SyntheticEvent<HTMLImageElement>) => {
                            const img = e.currentTarget;
                            setNaturalSize({ w: img.naturalWidth, h: img.naturalHeight });
                        }}
                        sx={{
                            position: 'absolute',
                            inset: 0,
                            margin: 'auto',
                            maxWidth: '100%',
                            maxHeight: '100%',
                            objectFit: 'contain',
                            transform: `translate(${offset.x}px, ${offset.y}px) scale(${zoom})`,
                            transformOrigin: 'center center',
                            transition: dragRef.current.active ? 'none' : 'transform 120ms ease-out',
                            cursor: zoom > 1 ? 'grab' : 'default',
                            userSelect: 'none',
                        }}
                    />
                )}

                {/* Close */}
                <IconButton
                    aria-label="Cerrar revisión"
                    onClick={onClose}
                    sx={{
                        position: 'absolute', top: 12, right: 12,
                        bgcolor: 'rgba(0,0,0,0.5)', color: ColorsEpico.ColorWhite,
                        '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' },
                    }}
                >
                    <CloseIcon />
                </IconButton>

                {/* Objective quality read-out: what the shot actually is */}
                {(pixelLabel || sizeLabel) && (
                    <Box
                        sx={{
                            position: 'absolute', top: 12, left: 12,
                            px: 1.5, py: 0.75, borderRadius: 1,
                            bgcolor: 'rgba(0,0,0,0.55)',
                            pointerEvents: 'none',
                        }}
                    >
                        <Typography sx={{ color: ColorsEpico.ColorWhite, fontSize: FontSizesEnum.Epsilon }}>
                            {[pixelLabel, megapixels ? `${megapixels.toFixed(1)} MP` : null, sizeLabel]
                                .filter(Boolean)
                                .join('  ·  ')}
                        </Typography>
                    </Box>
                )}

                {/* Zoom controls */}
                <Box
                    sx={{
                        position: 'absolute', bottom: 20, left: 0, right: 0,
                        display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 1.5,
                    }}
                >
                    <IconButton
                        aria-label="Alejar"
                        onClick={() => changeZoom(-1)}
                        disabled={zoomIndex === 0}
                        sx={{ bgcolor: 'rgba(0,0,0,0.5)', color: ColorsEpico.ColorWhite, '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' } }}
                    >
                        <ZoomOutIcon />
                    </IconButton>

                    <Box
                        sx={{
                            minWidth: 64, textAlign: 'center', px: 1.5, py: 0.75, borderRadius: 1,
                            bgcolor: 'rgba(0,0,0,0.55)', pointerEvents: 'none',
                        }}
                    >
                        <Typography sx={{ color: ColorsEpico.ColorWhite, fontSize: FontSizesEnum.Epsilon }}>
                            {zoom === 1 ? 'Ajustado' : `${zoom}×`}
                        </Typography>
                    </Box>

                    <IconButton
                        aria-label="Acercar"
                        onClick={() => changeZoom(1)}
                        disabled={zoomIndex === ZOOM_STEPS.length - 1}
                        sx={{ bgcolor: 'rgba(0,0,0,0.5)', color: ColorsEpico.ColorWhite, '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' } }}
                    >
                        <ZoomInIcon />
                    </IconButton>

                    <IconButton
                        aria-label="Restablecer vista"
                        onClick={resetView}
                        disabled={zoom === 1 && offset.x === 0 && offset.y === 0}
                        sx={{ bgcolor: 'rgba(0,0,0,0.5)', color: ColorsEpico.ColorWhite, '&:hover': { bgcolor: 'rgba(0,0,0,0.7)' } }}
                    >
                        <CenterFocusStrongIcon />
                    </IconButton>
                </Box>
            </Box>
        </Dialog>
    );
};

export default ImageQualityViewer;
