/**
 * Interface that defines the props of the CameraInvoiceModal.
 * @interface ICameraInvoiceModalProps
 */
import { IOcrResult } from '@/features/cameraMobile/domain/interface/IOcrResult';
/**
 * Interface for camera attempt tracking.
 * @interface ICameraAttempts
 * @property {number} ocrAttempts - Number of failed OCR attempts.
 * @property {number} manualAttempts - Number of manual retry attempts (outside OCR validation).
 */
export interface ICameraAttempts {
    ocrAttempts: number;
    manualAttempts: number;
    previewUrl: string | null;
}

/**
 * Props for the CameraInvoiceModal component.
 * @interface ICameraInvoiceModalProps
 * @property {boolean} open - Controls whether the modal is open or closed.
 * @property {() => void} onClose - Callback function triggered when the modal is closed.
 * @property {(file: File) => void} [onCheck] - Optional callback executed when a file is selected for checking.
 * @property {(result: IOcrResult) => void} [onResult] - Optional callback to return the OCR result to the parent component.
 * @property {(attempts: ICameraAttempts) => void} [onAttemptsChange] - Optional callback to report attempt counts when they change.
 * @property {boolean} [useOcr] - Optional flag to enable/disable OCR processing. Defaults to true.
 * @property {number} [limitTry] - Optional number of tries for OCR processing. Defaults to 0.
 * @property {number} [currentStep] - Optional current step in a multi-step process.
 * @property {string | null} [expectedFolio] - Serie-Folio of the selected invoice, e.g. "VAOF-386680", used to confirm the photo is of that document.
 */
export interface ICameraInvoiceModalProps {
    open: boolean;
    onClose: () => void;
    onCheck?: (file: File) => void;
    onResult?: (result: IOcrResult) => void;
    onAttemptsChange?: (attempts: ICameraAttempts) => void;
    useOcr?: boolean;
    limitTry?: number;
    currentStep?: number;
    expectedFolio?: string | null;
}