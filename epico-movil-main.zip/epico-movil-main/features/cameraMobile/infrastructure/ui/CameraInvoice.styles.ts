import { SxProps, Theme } from '@mui/material';
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";

export const DialogContentSx: SxProps = {
    p: 0,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
};

export const MainContainerSx: SxProps = {
    width: '100%',
    height: '100%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
};

export const VideoContainerSx: SxProps = {
    position: 'relative',
    width: '100%',
    flex: 1,
    overflow: 'hidden',
    bgcolor: ColorsEpico.ColorBlack,
};

export const PreviewOverlaySx: SxProps = {
    position: 'absolute',
    inset: 0,
    bgcolor: ColorsEpico.ColorblackLite,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    p: 2,
};

export const PreviewImageSx: SxProps = {
    maxWidth: '100%',
    height: '100%',
    objectFit: 'contain',
    // No image-rendering override here. Chromium treats 'crisp-edges' as an
    // invalid value so it did nothing there, but Safari and Firefox do honour it,
    // and on a downscaled photo it disables the smooth filter and produces
    // aliasing — the opposite of what a legibility check needs.
    borderRadius: 2,
    boxShadow: 3,
};

export const ButtonRowSx: SxProps = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 2,
};

export const IconButtonSx: SxProps<Theme> = {
    width: 52,
    height: 52,
    borderRadius: "50%",
    backgroundColor: (t: Theme) =>
        t.palette.mode === "dark" ? ColorsEpico.ColorWhite08 : ColorsEpico.ColorWhiteLite,
};

export const CaptureButtonInnerSx: SxProps = {
    width: 58,
    height: 58,
    borderRadius: "50%",
    backgroundColor: ColorsEpico.ColorWhite,
    boxShadow: `inset 0 0 0 1px ${ColorsEpico.ColorblackLiteSecondary}`,
};

export const CheckIconButtonSx: SxProps<Theme> = {
    width: 52,
    height: 52,
    borderRadius: "50%",
    overflow: "hidden",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: (t: Theme) =>
        t.palette.mode === "dark" ? ColorsEpico.ColorWhite08 : ColorsEpico.ColorWhiteLite,
};


