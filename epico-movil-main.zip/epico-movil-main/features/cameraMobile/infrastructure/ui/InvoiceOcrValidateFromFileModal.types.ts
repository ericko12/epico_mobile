

import { IOcrResult } from "@/features/cameraMobile/domain/interface/IOcrResult";

/**
 * Props for the Invoice OCR validation modal when processing from a file.
 * @interface InvoiceOcrValidateFromFileModalProps
 * @property {File | null} file - File of the photo taken in CameraInvoiceModal.
 * @property {number} [minConfidence] - Optional confidence threshold to consider the OCR result "legible".
 * @property {boolean} [autoRun] - Optional flag to run OCR automatically when receiving the file (default is true).
 * @property {boolean} rotateImage - Indicates if the image should be rotated (for photos taken in the camera).
 * @property {(result: IOcrResult) => void} [onResult] - Optional callback to return the OCR result to the parent component.
 */
export interface InvoiceOcrValidateFromFileModalProps {
  /** File of the photo taken in CameraInvoiceModal */
  file: File | null;
  /** Threshold to consider "readable"*/
  minConfidence?: number;
  /** Automatically run OCR upon receiving the file (default true) */
  autoRun?: boolean;
  /** rotate image 'take photo in camera' */
  rotateImage: boolean;
  /**
   * Serie-Folio the photo is expected to show, e.g. "VAOF-386680", built from the
   * invoice the user picked. When given, reading it back off the sheet is what
   * validates the capture: it proves this is the right document, not merely a
   * legible one. Leave undefined to fall back to the generic legibility check.
   */
  expectedFolio?: string | null;
  /** Optional callback to return the result to the parent */
  onResult?: (result: IOcrResult) => void;
}