import React, { useEffect, useRef, useState } from 'react';
import { InvoiceOcrValidateFromFileModalProps } from '@/features/cameraMobile/infrastructure/ui/InvoiceOcrValidateFromFileModal.types';
import { OCRProcess } from "@/features/cameraMobile/infrastructure/utils/ocrProcess";
import { enhanceForOcr } from '@/features/cameraMobile/infrastructure/utils/imageProcess';
import { regexInvoiceSerieFolio } from '@/features/common/infrastructure/utils/regexGlobal';

/**
 * Component that validates an invoice image using OCR (Optical Character Recognition).
 * 
 * @param {Object} props - The component props
 * @param {File | null} props.file - Image file to process with OCR
 * @param {number} [props.minConfidence=40] - Minimum confidence threshold to consider the text legible
 * @param {boolean} [props.autoRun=true] - Whether to automatically run OCR when a file is provided
 * @param {boolean} props.rotateImage - Whether to rotate the image before processing
 * @param {(result: IOcrResult) => void} [props.onResult] - Optional callback to return the OCR result
 * @returns {JSX.Element} The modal component for validating invoice images through OCR
 */

const InvoiceOcrValidateModal: React.FC<InvoiceOcrValidateFromFileModalProps> = ({
  file,
  minConfidence = 40,
  autoRun = true,
  rotateImage,
  expectedFolio,
  onResult,
}) => {

  // State
  const [image, setImage] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [psm, setPsm] = useState(12); // we keep your default value

  const aliveRef = useRef(true);
  useEffect(() => {
    aliveRef.current = true;
    return () => { aliveRef.current = false; };
  }, []);
  /*
  *  When the File that comes through props changes, we synchronize state and clean up previous results
  */
  useEffect(() => {
    setImage(file ?? null);
    setError('');
  }, [file]);
  /*
  *  Automatically trigger OCR if a File arrives and autoRun=true
  */
  useEffect(() => {
    if (autoRun && image) {
      // validate that it is an image
      if (!image.type.startsWith('image/')) {
        setError('El archivo recibido no es una imagen.');
        return;
      }
      handleOcr();
    }
  }, [autoRun, image]);

  /*
  *  Function to check if the text contains the word 'FACTURA'
  */
  const containsFacturaWord = (text: string): boolean => {
    if (!text) return false;
    // Normalize the text: remove accents, convert to uppercase, and remove extra spaces
    const normalizedText = text
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '') // Remove accents
      .toUpperCase()
      .replace(/\s+/g, ' ') // Replace multiple spaces with single space
      .trim();
    
    // Regex to find the word FACTURA (with possible variations)
    // \b ensures word boundaries
    const facturaRegex = /\bFACTURA\b/i;
    
    return facturaRegex.test(normalizedText);
  };

  /**
   * Looks for the Serie-Folio of the invoice the user picked inside the recognised
   * text, e.g. "VAOF-386680".
   *
   * Compares on letters and digits only, because the separator is the character
   * OCR gets wrong most often on a photographed sheet: a hyphen turns into an
   * em dash, a space, or nothing at all. Also accepts the folio on its own, since
   * the series can sit in a different cell of the header table than the number.
   */
  const findsExpectedFolio = (text: string, expected?: string | null): boolean => {
    if (!text || !expected) return false;
    const squash = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, '');
    const haystack = squash(text);
    const needle = squash(expected);
    if (!needle) return false;
    if (haystack.includes(needle)) return true;

    // Fall back to the numeric part: "386680" is long enough to be conclusive on
    // its own, and the series may have been read as part of another word.
    const digits = needle.replace(/[^0-9]/g, '');
    return digits.length >= 5 && haystack.includes(digits);
  };

  /**
   * Pulls whatever looks like a Serie-Folio out of the recognised text.
   *
   * The shape is fixed on these invoices — a letter series, a separator, then the
   * consecutive number (VAOF-386680) — so it can be located without knowing which
   * invoice was expected. That is what lets the caller say "this is invoice X, not
   * the one you picked" instead of the useless "not readable".
   */
  const extractFolio = (text: string): string | null => {
    if (!text) return null;
    const normalized = text.toUpperCase().replace(/\s+/g, ' ');
    // Separator optional: the hyphen is the character OCR loses most often.
    const match = normalized.match(regexInvoiceSerieFolio);
    return match ? `${match[1]}-${match[2]}` : null;
  };

  /*
  *  Handles the process of applying OCR to the image
  */
  const handleOcr = async () => {
    if (!image) return;
    setLoading(true);
    setError('');
    try {

      const preprocessedImage = await preprocessImage(image);
      if (!aliveRef.current) return;
      const data = await OCRProcess(preprocessedImage);
      if (!aliveRef.current) return;

      // Check if the text contains 'FACTURA'
      const hasFacturaWord = containsFacturaWord(data.text);
      const matchesFolio = findsExpectedFolio(data.text, expectedFolio);

      // Reading back the Serie-Folio of the invoice that was selected is a far
      // stronger result than recognising the word "FACTURA": it proves this photo
      // is of THAT document, not just of some invoice. When it matches, the
      // capture is accepted on its own merit — the mean confidence score is an
      // average over every word in the region, so noise around the header can drag
      // it under the threshold even when the folio itself came through perfectly.
      const isLegible = matchesFolio || (data.confidence >= minConfidence && hasFacturaWord);
      const detectedFolio = extractFolio(data.text);

      // Callback to the parent
      onResult?.({
        text: data.text,
        confidence: data.confidence == null || data.confidence == 0 ? null : data.confidence,
        isLegible: isLegible,
        matchesFolio,
        detectedFolio,
        errorTxt: error,
        previewDataUrl: preprocessedImage,
        sourceFile: file ?? null
      });
    } catch (err) {
      if (!aliveRef.current) return;
      setError('Error procesando la imagen.');
    } finally {
      if (aliveRef.current) setLoading(false);
    }
  };

  // Limita el lado largo del canvas a maxLong (mantiene aspecto)
  const downscaleToMaxLong = (canvas: HTMLCanvasElement, maxLong: number) => {
    const w = canvas.width, h = canvas.height;
    const long = Math.max(w, h);
    if (long <= maxLong) return canvas;
    const scale = maxLong / long;
    const out = document.createElement('canvas');
    out.width = Math.round(w * scale);
    out.height = Math.round(h * scale);
    const ctx = out.getContext('2d')!;
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(canvas, 0, 0, out.width, out.height);
    return out;
  }

  /*
  * We process the image for OCR, select a quadrant and rotate it if necessary.
  */
  const preprocessImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.src = e.target!.result as string;

        img.onload = () => {
        const src = document.createElement("canvas");
        const sctx = src.getContext("2d")!;
        src.width = img.width;
        src.height = img.height;
        sctx.drawImage(img, 0, 0);
        // === QUADRANT CROP ===
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d")!;
        // Smoothing ON. This used to magnify the region 3x with nearest-neighbour,
        // handing Tesseract stair-stepped letter edges — the engine then has to
        // recognise the blockiness as well as the glyph. Bilinear keeps the strokes
        // continuous, which is what the recogniser is trained on.
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        const scale = 3;
        const halfWidth = src.width / 2;
        const halfHeight = src.height / 2;
        const quarterHeight = halfHeight / 2;

        canvas.width = halfWidth * scale;
        canvas.height = quarterHeight * scale;

        ctx.drawImage(
            src,
            halfWidth,     // starting x (right half)
            0,             // starting y (top)
            halfWidth,     // width (right half)
            quarterHeight, // height (first top third)
            0, 0,
            canvas.width,
            canvas.height
          );
        const OCR_LONG_MAX = 1920;
        const small = downscaleToMaxLong(canvas, OCR_LONG_MAX);
        const enhanced = enhanceForOcr(small, {
          contrast: 1.15,
          brightness: 1.5, 
          gamma: 0.97
        });
        resolve(enhanced.toDataURL('image/png'));
        };
      };
      reader.readAsDataURL(file);
    });
  };

  return (
    <>
    </>
  );
};
export default InvoiceOcrValidateModal;