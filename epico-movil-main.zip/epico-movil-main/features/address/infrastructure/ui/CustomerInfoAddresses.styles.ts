import { SxProps } from "@mui/material";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";

export const styleCenterItem: SxProps = {
    display: 'flex',
    alignItems: 'flex-end',
    height: '100%',
    padding: 0,

};

export const styleSpaceBetweem: SxProps = {
    display: 'flex',
    alignItems: 'flex-end',
    justifyContent: 'space-between'
};
export const styleHeaderCardAddresses: SxProps = {
    fontSize: FontSizesEnum.Delta,
    fontWeight: FontWeightEnum.Medium,
    lineHeight: '20px',
    color: ColorsEpico.ColorDarkCharcoal,
    textAlign: 'start',
    padding: 0,
};
export const styleRowClienteInfo: SxProps = {
    width: '100%',
    margin: 0,
    padding: '0px 32px',
};