import { IAddress } from "@/features/address/domain/interface/IAddress";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { IEditCustomerAddress } from "@/features/address/domain/interface/IEditCustomerAddress";
import { IFormAddress } from "@/features/address/domain/interface/IFormAddress";

/**
 * Props for the `AddressForm` component.
 * 
 * This interface defines the properties required by the `AddressForm` component
 * @interface IAddressFormProps
 * @param {number} customerId - The customer ID for whom the address is being registered or edited.
 * @param {IFormAddress} [editAddressValues] - Predefined address values (for editing). Optional.
 * @param {() => void} onClose - Callback function to close the form.
 * @param {?(data: IAddress) => Promise<void>} onSave - Callback function to save the form.
 * @param {?(update?: boolean, data?: IEditCustomerAddress) => Promise<void>} onUpdate - Callback function to update the form.
 */
export interface IAddressFormProps {
  customerId: number;
  editAddressValues?: IFormAddress | undefined;
  onClose: () => void;
  onSave?: (data: IAddress) => Promise<void>;
  onUpdate?: (update?: boolean, data?: IEditCustomerAddress) => Promise<void>;
}