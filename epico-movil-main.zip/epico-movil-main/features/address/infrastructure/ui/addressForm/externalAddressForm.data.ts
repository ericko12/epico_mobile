import { IFormExternalAddress } from "@/features/address/domain/interface/IFormExternalAddress";

export const INITIALDIREXTERNAL_VALUES: Readonly<IFormExternalAddress> = {
    externalAddressId: 0,
    street: '',
    exteriorNumber: '',
    interiorNumber: '',
    postalCode: '',
    neighborhoodId: 0,
    neighborhood: '',
    state: '',
    cityId: 0,
    city: '',
    latitud: 0,
    longitud: 0
};

/**
 * A frozen object holding the names of the form parameters.
 * This can be used to reference form fields consistently throughout the code.
 */
export const FORMDIREXTERNAL_PARAM = Object.freeze({
    direccionExternaId: 'DireccionExternaId',
    calle: 'Calle',
    ext: 'Ext',
    int: 'Int',
    codigoPostal: 'Codigo Postal',
    colonia: 'Colonia',
    estado: 'Estado',
    municipio: 'Municipio'
});
