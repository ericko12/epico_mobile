import { Box, Button, Grid2 } from "@mui/material"
import { ChangeEvent, FC, useActionState, useEffect, useState, useTransition } from "react";
import { IFormAddress } from "@/features/address/domain/interface/IFormAddress";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { InputLabel } from "@/features/common/infrastructure/ui/inputs/inputLabel/InputLabel";
import { SelectLabel } from "@/features/common/infrastructure/ui/select/selectLabel/SelectLabel";
import { IEstadoCiudadMunicipio } from "@/features/address/domain/interface/IEstadoCiudadMunicipio";
import { ICustomerParcels } from "@/features/address/domain/interface/IParcels";
import { IColonia } from "@/features/address/domain/interface/IColonia";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { NOTIFICATIONS_ADDRESS } from "@/features/common/infrastructure/utils/messages/NotificationsAddress";
import { addressService } from "@/features/address/application/service/AddressService";
import { IAddress } from "@/features/address/domain/interface/IAddress";
import { submitAddress } from "@/features/address/application/actions/submitAddress";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { formAddressState } from "@/features/address/application/formStates/formAddressState";
import { IAddressFormProps } from "@/features/address/infrastructure/ui/addressForm/AddressForm.types";
import { FORM_PARAM, INITIAL_VALUES } from "@/features/address/infrastructure/ui/addressForm/addressForm.data";
import { regexNumber } from "@/features/common/infrastructure/utils/regexGlobal";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { IEditCustomerAddress } from "@/features/address/domain/interface/IEditCustomerAddress";
import { GeopositionModal } from '@/features/common/infrastructure/ui/google/map/GeopositionModal';

// api
const apiAddress = addressService();

/**
 * AddressForm Component
 *
 * This component represents an address form for a customer.
 * It allows adding or editing addresses. If edit values (editAddressValues) are provided,
 * the form is initialized with those values.
 * Additionally, it receives the customer ID and a function to close the form.
 *
 * @component
 * @param {IAddressFormProps} props - Component properties.
 * @param {number} props.customerId - The customer ID for whom the address is being registered or edited.
 * @param {IFormAddress} [props.editAddressValues] - Predefined address values (for editing). Optional.
 * @param {() => void} props.onClose - Callback function to close the form.
 *
 * @returns {JSX.Element} Renders the address form.
 */
export const AddressForm: FC<IAddressFormProps> = ({ customerId, editAddressValues, onClose, onSave, onUpdate }) => {
    // hooks
    const { showSnackbar } = useSnackbar();
    const [isPending, startTransition] = useTransition();
    // states
    const [states, setState] = useState<IEstadoCiudadMunicipio>();
    const [parcels, setParcels] = useState<ICustomerParcels[]>([]);
    const [colonies, setColonies] = useState<IColonia[]>([]);
    const [loading, setLoading] = useState({ state: false, parcels: false, colonies: false });
    const [formValues, setFormValues] = useState<IFormAddress>(editAddressValues ?? INITIAL_VALUES);
    const [state, action, pending] = useActionState<formAddressState, FormData>(submitAddress, undefined);
    const [openMapsModal, setOpenMapsModal] = useState(false);
    const [pendingEditData, setPendingEditData] = useState<IEditCustomerAddress | null>(null);
    const [resolvedInitialLatLng, setResolvedInitialLatLng] = useState<{ lat: number; lng: number } | undefined>(undefined);

    const { coloniaId } = formValues;

    /**
    * Component initialization
    */
    useEffect(() => {
        init();
    }, []);
    /**
    * Validates the change of selected address to update the form
    */
    useEffect(() => {
        setFormValues(editAddressValues || INITIAL_VALUES)
    }, [editAddressValues])
    /**
    * Validates whether the action to be performed is to update or create a customer address
    */
    useEffect(() => {
        if (state?.responses && state.responses.success && !pending && !state.initialState) {
            if (formValues.direccionId !== undefined)
                putAddress();
            else postAddress();
        }
    }, [state, pending])
    /**
    * validates the change of colony
    */
    useEffect(() => {
        if (coloniaId !== "")
            fetchStateByColonie(coloniaId);
    }, [coloniaId])
    /**
    * See in real time if the entered zip code is 5 characters long.
    */
    useEffect(() => {
        if (formValues.codigoPostal.length === 5) {
            fetchColoniesByCP(formValues.codigoPostal);
        }
    }, [formValues.codigoPostal])


    /**
     * Main function of the component, ciamdp the component is mounted
     *
     * @async
     */
    const init = async () => {
        fetchParcels();
    };

    /**
     * Obtains data from the parcel services
     * @async
     */
    const fetchParcels = async () => {
        try {
            setLoading((prev) => ({ ...prev, parcels: true }));
            const resParcels = await apiAddress.getCustomerParcels();

            handleRequestDto({
                response: resParcels,
                snackBar: showSnackbar,
                messages: {
                    error: NOTIFICATIONS_ADDRESS.PARCELS.FETCH_ERROR,
                    invalid: NOTIFICATIONS_ADDRESS.PARCELS.FETCH_ERROR,
                },
                onSuccess: () => {
                    setParcels(resParcels.data!);
                },
            });
        } catch (e) {
            useSnackbar();
        } finally {
            setLoading((prev) => ({ ...prev, parcels: false }));
        }
    };

    /**
        * Detects changes in the postal code
        * @param {ChangeEvent<HTMLInputElement | HTMLTextAreaElement>} e
        */
    const handlePostalCode = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const cp: string = e.target.value;

        // Validation to accept only numbers
        const valid: boolean = regexNumber.test(cp);

        if (!valid) return; // If the value is not numeric, it does not update.

        // If the postal code is longer than 5, it does not allow more characters.
        if (cp.length > 5) return;

        // We update the status with the postal code
        setFormValues({ ...formValues, codigoPostal: e.target.value })

        // We run the neighborhood search function if the postal code has a length of 5
        if (cp.length === 5) {
            fetchColoniesByCP(cp);
        }

        // Clean up previous colonies and restore status
        setColonies([]);
        setFormValues((prevValues) => ({
            ...prevValues,
            estadoId: INITIAL_VALUES.estadoId, // Resets the status of 'stateId'
            coloniaId: INITIAL_VALUES.coloniaId, // Resets the state of 'colonyId'
        }));
    };

    /**
     * Get the colonies by postal code
     * @param {string} cp - postal code
     * @async
     */
    const fetchColoniesByCP = async (cp: string) => {
        try {
            setLoading((prev) => ({ ...prev, colonies: true }));
            const resColonies = await apiAddress.getColoniasByCPostal(cp);

            handleRequestDto({
                response: resColonies,
                snackBar: showSnackbar,
                messages: {
                    error: NOTIFICATIONS_ADDRESS.COLONIES.FETCH_ERROR,
                    invalid: NOTIFICATIONS_ADDRESS.COLONIES.FETCH_ERROR,
                },
                onSuccess: () => setColonies(resColonies.data!),
            });
        } catch (e) {
            useSnackbar();
        } finally {
            setLoading((prev) => ({ ...prev, colonies: false }));
        }
    }

    /**
     * Obtains the state through the colony
     * @param {number} colonieId - colony
     * @async
     */
    const fetchStateByColonie = async (colonieId: number) => {
        try {
            setLoading((prev) => ({ ...prev, error: true }));
            const resState = await apiAddress.getEstadoByColonia(colonieId);

            handleRequestDto({
                response: resState,
                snackBar: showSnackbar,
                messages: {
                    error: NOTIFICATIONS_ADDRESS.COLONIES.FETCH_ERROR,
                    invalid: NOTIFICATIONS_ADDRESS.COLONIES.FETCH_ERROR,
                },
                onSuccess: () => {
                    setState(resState.data!);
                    setFormValues((prevValues) => ({
                        ...prevValues,
                        estadoId: resState.data!.estadoId,
                    }));
                },
            });
        } catch (e) {
            useSnackbar();
        } finally {
            setLoading((prev) => ({ ...prev, error: false }));
        }
    }

    /**
     * Register a new address for the customer
     * @async
     */
    const postAddress = async () => {
        startTransition(async () => {
            const data: IAddress = {
                clienteId: customerId,
                codigoPostal: formValues.codigoPostal,
                calle: formValues.calle,
                coloniaId: formValues.coloniaId === "" ? 0 : formValues.coloniaId,
                noExterior: formValues.ext,
                noInterior: formValues.int.trimStart().trimEnd(),
                ciudadId: states?.ciudadId!,
                ...(formValues.paqueteriaId !== "" && { paqueteriaId: formValues.paqueteriaId }),
                latitud: 0,
                longitud: 0
            };
            await onSave!(data);
        });
    }

    /**
     * edit the customer's address
     * @async
     */
    const putAddress = async () => {
        startTransition(async () => {
            let col = colonies.filter(x => (x.coloniaId === formValues.coloniaId))[0];
            const coloniaIdValue = formValues.coloniaId === "" ? 0 : formValues.coloniaId;

            // Resolve initial lat/lng: from BD if available, otherwise from API suggestion
            let initialLatLng: { lat: number; lng: number } | undefined = formValues.geoPosicion
                ? { lat: formValues.geoPosicion.lat, lng: formValues.geoPosicion.lng }
                : undefined;

            if (!initialLatLng) {
                const geoRes = await apiAddress.getGeoposicion({
                    ciudadId: states?.ciudadId ?? 0,
                    calle: formValues.calle,
                    coloniaId: coloniaIdValue,
                    codigoPostal: formValues.codigoPostal,
                    noExterior: formValues.ext,
                });
                if (geoRes.data) {
                    initialLatLng = {
                        lat: geoRes.data.geoposicionLatitud,
                        lng: geoRes.data.geoposicionLongitud,
                    };
                }
            }

            const dataEdit: IEditCustomerAddress = {
                direccionId: formValues.direccionId ?? 0,
                fiscal: false,
                colonia: col.colonia,
                clienteId: customerId,
                codigoPostal: formValues.codigoPostal,
                calle: formValues.calle,
                coloniaId: coloniaIdValue,
                noExterior: formValues.ext,
                noInterior: formValues.int.trimStart().trimEnd(),
                ciudadId: states?.ciudadId!,
                referenciaDireccion: '',
                ...(formValues.paqueteriaId !== "" && { paqueteriaId: formValues.paqueteriaId }),
                geoPosicion: initialLatLng
                    ? { geoposicionLatitud: initialLatLng.lat, geoposicionLongitud: initialLatLng.lng }
                    : { geoposicionLatitud: 0, geoposicionLongitud: 0 }
            };

            setResolvedInitialLatLng(initialLatLng);
            setPendingEditData(dataEdit);
            setOpenMapsModal(true);
        });
    }

    /**
     * Called when the user confirms the geoposition in the map modal.
     * Merges the final coordinates into the pending address data and calls onUpdate.
     * Wraps the call in startTransition so the "Aceptar" button stays in loading state
     * while the update request is in progress.
     * @param {google.maps.LatLngLiteral | undefined} latLng - The confirmed marker position.
     */
    const handleMapConfirm = (latLng: { lat: number; lng: number } | undefined): void => {
        if (!pendingEditData) return;
        const finalData: IEditCustomerAddress = {
            ...pendingEditData,
            geoPosicion: latLng
                ? { geoposicionLatitud: latLng.lat, geoposicionLongitud: latLng.lng }
                : pendingEditData.geoPosicion
        };
        startTransition(async () => {
            await onUpdate!(true, finalData);
        });
    };


    /**
     * handles closing the address modal and clears the form
     */
    const handleClose = () => {
        setFormValues(INITIAL_VALUES)
        onClose();
    };
    return (
        <Box component={'form'} action={action} mt={2} >
            {openMapsModal && (
                <GeopositionModal
                    open
                    onClose={() => setOpenMapsModal(false)}
                    onConfirm={handleMapConfirm}
                    initialLatLng={resolvedInitialLatLng}
                />
            )}
            <Grid2 container rowSpacing={2.5} sx={{
                border: `2px solid ${ColorsEpico.ColorSkyBlue}`,
                padding: '1rem',
                borderRadius: '8px',
                backgroundColor: ColorsEpico.ColorNeutro,
            }}>
                <Grid2 size={{ xs: 12, md: 12 }}>
                    <InputLabel
                        required
                        label="Calle"
                        name={FORM_PARAM.calle}
                        value={formValues.calle}
                        max={150}
                        error={!!state?.errors?.calle}
                        errorMessage={state?.errors?.calle?.[0]}
                        onChange={(e) => setFormValues({ ...formValues, calle: e.target.value })}
                    />
                </Grid2>
                <Grid2 container spacing={3} rowSpacing={2.5}>
                    <Grid2 size={{ xs: 12, md: 4 }}>
                        <InputLabel
                            required
                            label="Número ext"
                            name={FORM_PARAM.ext}
                            value={formValues.ext}
                            error={!!state?.errors?.ext}
                            errorMessage={state?.errors?.ext?.[0]}
                            onChange={(e) => setFormValues({ ...formValues, ext: e.target.value })}
                            max={15}

                        />
                    </Grid2>
                    <Grid2 size={{ xs: 12, md: 4 }}>
                        <InputLabel
                            label="Número int"
                            name={FORM_PARAM.int}
                            value={formValues.int}
                            error={!!state?.errors?.int}
                            errorMessage={state?.errors?.int?.[0]}
                            onChange={(e) => setFormValues({ ...formValues, int: e.target.value })}
                            max={15}
                        />
                    </Grid2>
                    <Grid2 size={{ xs: 12, md: 4 }}>
                        <InputLabel
                            required
                            label="Código postal"
                            name={FORM_PARAM.codigoPostal}
                            value={formValues.codigoPostal}
                            error={!!state?.errors?.codigoPostal}
                            errorMessage={state?.errors?.codigoPostal?.[0]}
                            onChange={handlePostalCode}
                            max={5}
                        />
                    </Grid2>
                    <Grid2 size={{ xs: 12, md: 4 }}>
                        <SelectLabel
                            required
                            label="Colonia"
                            name={FORM_PARAM.coloniaId}
                            value={formValues.coloniaId ?? ""}
                            error={!!state?.errors?.coloniaId}
                            errorMessage={state?.errors?.coloniaId?.[0]}
                            onChange={(e) => setFormValues({ ...formValues, coloniaId: e.target.value })}
                            selectProps={{
                                disabled: colonies.length === 0,
                                defaultValue: null,
                                loading: loading.colonies,
                                options: colonies.map((colonie: IColonia) => ({
                                    value: colonie.coloniaId,
                                    label: colonie.colonia,
                                })),

                            }}
                        />

                    </Grid2>
                    <Grid2 size={{ xs: 12, md: 4 }}>
                        <SelectLabel
                            required
                            label="Estado"
                            name={FORM_PARAM.estadoId}
                            value={formValues.estadoId ?? ""}
                            error={!!state?.errors?.estadoId}
                            errorMessage={state?.errors?.estadoId?.[0]}
                            readOnly={true}
                            selectProps={{
                                sxSelect: {
                                    '&.MuiSelect-select': {
                                        color: 'rgba(0, 0, 0, 0.26)'
                                    },
                                    '&.MuiSelect-icon': {
                                        color: 'rgba(0, 0, 0, 0.26) !important'
                                    },
                                    '&.MuiOutlinedInput-notchedOutline': {
                                        borderColor: 'rgba(0, 0, 0, 0.26)'
                                    },
                                    color: 'rgba(0, 0, 0, 0.26)',
                                    borderColor: 'rgba(0, 0, 0, 0.26)',
                                    pointerEvents: 'none'
                                },
                                loading: loading.state,
                                options: [{
                                    value: states?.estadoId ?? 0,
                                    label: states?.estado ?? '',
                                }],
                            }}
                        />
                    </Grid2>
                    <Grid2 size={{ xs: 12, md: 4 }}>
                        <SelectLabel
                            required
                            label="Paqueteria"
                            name={FORM_PARAM.paqueteriaId}
                            value={formValues.paqueteriaId ?? ""}
                            error={!!state?.errors?.paqueteriaId}
                            errorMessage={state?.errors?.paqueteriaId?.[0]}
                            onChange={(e) => setFormValues({ ...formValues, paqueteriaId: e.target.value })}
                            allowClear
                            onClear={() => setFormValues({ ...formValues, paqueteriaId: "" })}
                            selectProps={{
                                loading: loading.parcels,
                                defaultValue: null,
                                options: parcels.map((parcel: ICustomerParcels) => ({
                                    value: parcel.paqueteriaId,
                                    label: parcel.paqueteria,
                                })),
                            }}
                        />
                    </Grid2>

                </Grid2>
            </Grid2>
            <Grid2 display="flex" justifyContent="flex-end" sx={{ mt: 2.5 }}>
                <Button
                    onClick={handleClose}
                    variant="outlined"
                    size="small"
                    disabled={pending || isPending}
                    sx={{
                        mr: 1,
                        width: "6rem",
                        borderRadius: '4px',
                        height: '32px',
                        fontWeight: FontWeightEnum.Medium,
                        color: ColorsEpico.ColorDarkCharcoal,
                        borderColor: ColorsEpico.ColorGrayNeutral,
                        fontSize: FontSizesEnum.Gamma,
                        '&.Mui-disabled': {
                            opacity: .5,
                        }
                    }}
                >
                    Cerrar
                </Button>
                <ButtonLoading
                    variant='contained'
                    type='submit'
                    loading={pending || isPending}
                    color="primary"
                    size="small"
                    sx={{
                        width: "6.35rem",
                        background: ColorsEpico.ColorPrimary,
                        fontSize: FontSizesEnum.Gamma,
                        borderRadius: '4px',
                        height: '32px',
                        '&.Mui-disabled': {
                            backgroundColor: ColorsEpico.ColorBlueView,
                            color: ColorsEpico.ColorWhite,
                            opacity: 1,
                        }
                    }}

                >
                    Aceptar
                </ButtonLoading>
            </Grid2>
        </Box>
    )
}