import { IFormAddress } from '@/features/address/domain/interface/IFormAddress';

/**
 * Initial form values for address.
 * These values will be pre-filled in the form fields on page load or reset.
 *
 * @type {Readonly<IFormAddress>}
 */
export const INITIAL_VALUES: Readonly<IFormAddress> = {
    direccionId: undefined,
    calle: '',
    ext: '',
    int: '',
    codigoPostal: '',
    coloniaId: '',
    estadoId: '',
    paqueteriaId: '',
};

/**
 * A frozen object holding the names of the form parameters.
 * This can be used to reference form fields consistently throughout the code.
 */
export const FORM_PARAM = Object.freeze({
    direccionId: 'direccionId',
    calle: 'calle',
    ext: 'ext',
    int: 'int',
    codigoPostal: 'codigoPostal',
    coloniaId: 'coloniaId',
    estadoId: 'estadoId',
    paqueteriaId: 'paqueteriaId',
});

