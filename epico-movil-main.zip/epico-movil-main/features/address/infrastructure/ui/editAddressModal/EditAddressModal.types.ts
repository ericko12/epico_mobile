import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { IEditCustomerAddress } from "@/features/address/domain/interface/IEditCustomerAddress";

/**
 * Interface for Edit Address Modal.
 * 
 * This interface defines the structure for an edit address modal, including properties for controlling 
 * the modal's visibility, customer information, the address being edited, and event handlers for saving and closing.
 * 
 * @interface IEditAddressModal
 * 
 * @property {boolean} open - Determines whether the modal is open or closed.
 * @property {string} customerName - The name of the customer whose address is being edited.
 * @property {number} customerId - The unique identifier for the customer whose address is being edited.
 * @property {number} addressId - The unique identifier for the address being edited.
 * @property {ICustomerAddresses[]} addressCustomer - An array of customer addresses. This is used for selecting the address to edit.
 * @property {() => void} onClose - The function to call when closing the modal. This is typically used to dismiss the modal without saving.
 * @property {(update?: boolean, data?: IEditCustomerAddress, addressId?: number) => Promise<void>} onSave - 
 * The function to call when saving the edited address. It takes an optional `update` flag (indicating whether it's an update or a new address), 
 * optional address data (`data`), and an optional address ID (`addressId`). The function returns a promise indicating the save operation's result.
 */
export interface IEditAddressModal {
    open: boolean;
    customerName: string;
    customerId: number;
    addressId: number;
    addressCustomer: ICustomerAddresses[];
    onClose: () => void;
    onSave: (update?: boolean, data?: IEditCustomerAddress, addressId?: number) => Promise<void>;
}