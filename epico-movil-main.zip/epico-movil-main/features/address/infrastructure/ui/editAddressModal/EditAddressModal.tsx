import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { Grid2, IconButton, Stack, Typography } from "@mui/material";
import { JSX, useEffect, useState, useTransition } from "react";
import { SelectLabel } from "@/features/common/infrastructure/ui/select/selectLabel/SelectLabel";
import { Delete as DeleteIcon } from "@mui/icons-material";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { ModalDelete } from "@/features/common/infrastructure/ui/modal/ModalDelete";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { handleCathError } from "@/features/common/infrastructure/utils/handleCathError";
import { IFormAddress } from "@/features/address/domain/interface/IFormAddress";
import { IEditAddressModal } from "@/features/address/infrastructure/ui/editAddressModal/EditAddressModal.types";
import { addressService } from "@/features/address/application/service/AddressService";
import { useAppSelector } from "@/features/common/application/redux/hooks";
import { FORM_PARAM, INITIAL_VALUES } from "@/features/address/infrastructure/ui/addressForm/addressForm.data";
import { AddressForm } from "@/features/address/infrastructure/ui/addressForm/AddressForm";
import { ModalWithoutButtons } from "@/features/common/infrastructure/ui/modal/modalWithoutButton/ModalWithoutButtons";

// api
const apiAddress = addressService();

/**
 * `EditAddressModal` Component
 * 
 * This component represents a modal for editing an existing address. 
 * It allows users to update address details for a specific customer.
 * 
 * @param {IEditAddressModal} props - The properties for the `EditAddressModal` component.
 * @param {boolean} props.open - Determines whether the modal is open or closed. When `true`, the modal is visible; otherwise, it is hidden.
 * @param {number} props.customerId - The unique identifier of the customer associated with the address. This links the modal to a specific customer.
 * @param {string} props.customerName - The name of the customer whose address is being edited. This is displayed for context within the modal.
 * @param {number} props.addressId - The unique identifier of the address to be edited. This allows the modal to target a specific address.
 * @param {ICustomerAddresses[]} props.addressCustomer - An array of customer addresses. This is used for selecting and editing a specific address from the customer's list.
 * @param {() => void} props.onClose - Callback function triggered when the modal is closed, typically to cancel the edit and close the modal.
 * @param {(update?: boolean, data?: ICustomerAddresses, addressId?: number) => Promise<void>} props.onSave - Callback function triggered when saving the edited address. It may optionally take an `update` flag (indicating whether it's an update operation), the `data` (edited address details), and the `addressId` to identify which address is being saved.
 * 
 * @returns {JSX.Element} The modal component for editing an address, including form fields to update address details.
 */
const EditAddresModal: React.FC<IEditAddressModal> = ({ open, customerId, customerName, addressId, addressCustomer, onClose, onSave }): JSX.Element => {
    // hooks
    const { showSnackbar } = useSnackbar();
    const [pendingDelete, startPendingDelete] = useTransition();
    // states
    const [addresses, setAddresses] = useState<ICustomerAddresses[]>(addressCustomer);
    const [addressToEdit, setAddressToEdit] = useState<IFormAddress>(INITIAL_VALUES);
    const [loading, setLoading] = useState(true);
    const [modalDelete, setModalDelete] = useState(false);
    /**
     * Validate if we have the addresses pre-loaded or we have to search for them with a request
     */
    useEffect(() => {
        if (!!addresses?.length) setLoading(false);
        handleFetchCustomerAddresses(customerId);
    }, [addressCustomer])
    /**
     * Maps the selected id address
     */
    useEffect(() => {
        if (!loading) addressSelected(addressId);
    }, [addressId, loading])

    /**
     * Fetches the list of addresses for a given customer.
     * 
     * @param {number} customerId - The unique identifier of the customer.
     * @returns {Promise<void>} A promise that resolves once the process is complete.
     */
    const handleFetchCustomerAddresses = async (customerId: number) => {
        try {
            const addressesResponse = await apiAddress.getCustomerAddresses(customerId);
            await handleRequestDto({
                snackBar: showSnackbar,
                response: addressesResponse,
                messages: {
                    error: "Ocurrió un error al obtener las dirreciones",
                    invalid: addressesResponse.error.mensaje
                },
                onSuccess: () => setAddresses(addressesResponse?.data!),
                onInvalid: () => setAddresses(addressesResponse?.data!)
            })
            setLoading(false)
        } catch (e) {
            handleCathError(e, showSnackbar);
        }
    }

    /**
     * Handles the selection of an address by filtering the list of addresses 
     * and setting the selected address to be edited.
     * 
     * @param {number} value - The ID of the selected address.
     */
    const addressSelected = (value: number) => {
        let dir = addresses.filter(x => (x.direccionId === value && !x.fiscal))[0];

        if (dir) {
            var formAddress: IFormAddress = {
                direccionId: dir.direccionId,
                calle: dir.calle ?? '',
                ext: dir.noExterior ?? '',
                int: dir.noInterior ?? '',
                codigoPostal: dir.codigoPostal ?? '',
                coloniaId: dir.coloniaId ?? '',
                estadoId: dir.estadoId ?? '',
                paqueteriaId: dir.paqueteriaId ?? '',
                geoPosicion: dir.geoPosicion
                    ? { lat: dir.geoPosicion.latitud, lng: dir.geoPosicion.longitud }
                    : undefined
            }
            setAddressToEdit(formAddress);
        }
    }

    /**
     * Deletes the selected address from the customer's address list.
     * 
     * @returns {Promise<void>} A promise that resolves once the deletion process is complete.
     */
    const deleteAddress = async () => {
        if (addressToEdit?.direccionId !== undefined) {
            startPendingDelete(() => onSave(false, undefined, addressToEdit?.direccionId));
        }
    }

    return (
        <Grid2>
            <ModalWithoutButtons
                openModal={open}
                onClose={onClose}
                titulo="EDICIÓN DIRECCIONES DEL CLIENTE"
            >
                <Stack gap={2}>
                    <Typography fontSize={FontSizesEnum.Gamma} fontWeight={FontWeightEnum.Medium}>
                        CLIENTE
                    </Typography>
                    <Typography fontSize={FontSizesEnum.Alpha} fontWeight={FontWeightEnum.Bold}>
                        {customerName}
                    </Typography>
                    <Grid2 container alignItems="center" spacing={2} >
                        <Grid2 size={{ xs: 12 }}>
                            <SelectLabel
                                label="DIRECCIONES"
                                multiline
                                name={FORM_PARAM.direccionId}
                                value={addressToEdit?.direccionId ?? ''}
                                onChange={(e) => addressSelected(Number(e.target.value))}
                                onDeleted={() => setModalDelete(true)}
                                selectProps={{
                                    defaultValue: null,
                                    options: addresses?.map((address: ICustomerAddresses) => ({
                                        value: address.direccionId,
                                        label: `${address.calle} ${address.noExterior} ${address.noInterior && ' Int. ' + address.noInterior || ''}, ${address.colonia}, ${address.codigoPostal} ${address.ciudad}, ${address.estado}`,
                                    })),
                                }}
                            />

                        </Grid2>
                    </Grid2>
                    {!loading && <AddressForm
                        customerId={customerId}
                        editAddressValues={addressToEdit}
                        onClose={onClose}
                        onUpdate={onSave}
                    />}
                </Stack>
            </ModalWithoutButtons>

            {modalDelete && <ModalDelete
                titulo="ELIMINAR DIRECCIÓN"
                description="Si eliminas esta dirección ya no podrás utilizarla para futuros envíos de pedidos"
                question="¿Estas seguro de querer eliminarla?"
                openModal={modalDelete}
                onClose={() => setModalDelete(false)}
                onOk={() => deleteAddress()}
                loading={pendingDelete}
            />}
        </Grid2>

    );
};

export default EditAddresModal;