'use client'
import React from 'react';
import { useState } from 'react';
import { Grid2, Button, Typography } from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import AddressesCards from '@/features/address/infrastructure/ui/card/AddressesCards';
import { addressService } from '@/features/address/application/service/AddressService';
import { handleRequestDto } from '@/features/common/application/handleRequestDto/handleRequestDto';
import { handleCathError } from '@/features/common/infrastructure/utils/handleCathError';
import { useSnackbar } from '@/context/snackBar/SnackBarContext';
import NewAddresModal from '@/features/address/infrastructure/ui/newAddressModal/NewAddressModal';
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import { FontWeightEnum } from '@/features/common/domain/enums/FontWeight';
import { IAddress } from "@/features/address/domain/interface/IAddress";
import { NOTIFICATIONS_ADDRESS } from '@/features/common/infrastructure/utils/messages/NotificationsAddress';
import { IAddressResponse } from '@/features/address/domain/interface/IAddressResponse';
import { IResponseDto } from '@/features/common/domain/axios/IResponseDto';
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";

/**
 * `CustomerInfoAddresses` Component
 *
 * This component manages the display and interaction with a customer's addresses.
 * It allows viewing, creating, and editing customer addresses.
 * It also integrates with an address service to fetch and manage the addresses of a customer.
 *
 * @param {number} customerId - The ID of the customer whose addresses are to be managed. This is used to fetch and manage the customer's addresses.
 * @param {?string} customerName - The name of the customer (optional, for display purposes). If provided, it will be used to display the customer's name.
 * @param {ICustomerAddresses[]} addressCustomer - An array of customer addresses. This holds all the addresses associated with the customer and is used for displaying them.
 * @param {(newAddresses: ICustomerAddresses[]) => void} setAddressCustomer - A function to update the list of addresses. This is typically used to update the state after adding, editing, or removing an address.
 * 
 * @returns {JSX.Element} A component that displays and allows interaction with the customer's addresses.
 */
export const CustomerInfoAddresses = ({ customerId, customerName, addressCustomer, setAddressCustomer }: {
    customerId: number,
    customerName: string | undefined,
    addressCustomer: ICustomerAddresses[],
    setAddressCustomer: (newAddresses: ICustomerAddresses[]) => void;
}) => {
    //hooks
    const { showSnackbar } = useSnackbar();

    //states
    const [newAddressModal, setNewAddressModal] = useState(false);

    //services
    const { postAddress, getCustomerAddresses } = addressService();

    /**
     * Handles the creation (POST) of a new address.
     * 
     * @param {IAddress} data - The address data to be submitted for creation. The `IAddress` interface contains 
     * details like street name, external and internal numbers, postal code, etc.
     * 
     * @returns {Promise<void>} A promise that resolves when the address has been successfully created or rejected
     * if there is an error during the request.
     */
    const handelPostAddress = async (data: IAddress) => {
        const resAddress: IResponseDto<IAddressResponse | null> = await postAddress(data);
        await handleRequestDto({
            response: resAddress,
            snackBar: showSnackbar,
            messages: {
                error: NOTIFICATIONS_ADDRESS.ADDRESS.POST_ERROR,
                invalid: resAddress.error.erroresValidaciones[0]?.errores[0] || NOTIFICATIONS_ADDRESS.ADDRESS.POST_ERROR,
                success: NOTIFICATIONS_ADDRESS.ADDRESS.POST_SUCCESS,
            },
            onSuccess: async () => {
                if (resAddress.data?.agregadoConExito) {
                    await handleFetchCustomerAddresses(customerId);
                    setNewAddressModal(false)
                }
            }
        });
        setNewAddressModal(false)
    }

    /**
     * Fetches customer addresses from the API.
     * 
     * @param {number} customerId - The unique identifier of the customer whose addresses need to be fetched.
     * 
     * @returns {Promise<void>} A promise that resolves when the fetch operation completes.
     */
    const handleFetchCustomerAddresses = async (customerId: number) => {
        try {
            const addressesResponse = await getCustomerAddresses(customerId);

            handleRequestDto({
                snackBar: showSnackbar,
                response: addressesResponse,
                messages: {
                    error: "Ocurrió un error al obtener las dirreciones",
                    invalid: addressesResponse.error.mensaje
                },
                onSuccess: () => setAddressCustomer(addressesResponse?.data!),
                onInvalid: () => setAddressCustomer(addressesResponse?.data!)
            })
        } catch (e) {
            handleCathError(e, showSnackbar);
        }
    }
    return (
        <>
            {newAddressModal &&
                <NewAddresModal
                    onClose={() => setNewAddressModal(false)}
                    onSave={handelPostAddress}
                    open={newAddressModal}
                    customerName={customerName ?? ''}
                    customerId={customerId ?? 0}
                />}
            <Grid2
                container
                spacing={2}
                sx={{ paddingTop: '20px' }}
                alignItems="center"
            >

                <Grid2 size={{ xs: 6 }}>
                    <Typography fontSize={FontSizesEnum.Delta} fontWeight={FontWeightEnum.Medium}>DIRECCIONES</Typography>
                </Grid2>

                <Grid2 size={{ xs: 6 }} sx={{ textAlign: 'right' }}>
                    <Button
                        sx={{ height: '24px', display: 'none'}} //Se oculta boton por requerimiento - REQ-23921
                        variant="contained"
                        endIcon={<AddIcon />}
                        onClick={() => setNewAddressModal(true)}
                    >
                        Nueva dirección
                    </Button>
                </Grid2>

                <Grid2 size={{ xs: 12 }}>
                    <AddressesCards
                        customerId={customerId}
                        customerName={customerName ?? ''}
                        customerAddresses={handleFetchCustomerAddresses}
                        addressCustomer={addressCustomer}
                    />
                </Grid2>
            </Grid2>
        </>
    )
}


