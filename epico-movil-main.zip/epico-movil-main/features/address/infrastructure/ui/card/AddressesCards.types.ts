import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";

/**
 * Interface for the properties of the `AddressesCards` component.
 *
 * This interface defines the structure of the props used to display 
 * customer address cards.
 * 
 * @interface IAddressesCardsProps
 * 
 * @property {number} customerId - The unique identifier of the customer.
 * @property {string} customerName - The name of the customer.
 * @property {(customerId: number) => Promise<void>} customerAddresses - A function to update the Redux store with the customer's address data.
 * @property {ICustomerAddresses[]} addressCustomer - An array of customer addresses to be displayed in the component.
 */
export interface IAddressesCardsProps {
    customerId: number;
    customerName: string;
    customerAddresses: (customerId: number) => Promise<void>;
    addressCustomer: ICustomerAddresses[];
}