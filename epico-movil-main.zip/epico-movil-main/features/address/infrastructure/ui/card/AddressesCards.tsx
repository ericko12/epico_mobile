import React, { useState } from "react";
import { Box, Button, Typography, Card, CardContent, Grid2, TextField, InputAdornment } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import QrCodeIcon from "@mui/icons-material/QrCode";
import { WatchLater, Edit, Height } from "@mui/icons-material";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { IAddressesCardsProps } from "@/features/address/infrastructure/ui/card/AddressesCards.types";
import EditAddresModal from "@/features/address/infrastructure/ui/editAddressModal/EditAddressModal";
import { useAppSelector } from "@/features/common/application/redux/hooks";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { NOTIFICATIONS_ADDRESS } from "@/features/common/infrastructure/utils/messages/NotificationsAddress";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { IAddressResponse } from "@/features/address/domain/interface/IAddressResponse";
import { addressService } from "@/features/address/application/service/AddressService";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { IEditCustomerAddress } from "@/features/address/domain/interface/IEditCustomerAddress";

/**
 * `AddressesCards` Component
 * 
 * This component displays a grid of address cards for each customer address. Each card shows information 
 * like the address, shipping method, QR status, and an "Edit" button. It is designed to allow users to 
 * quickly view and manage customer address details.
 * 
 * @param {IAddressesCardsProps} props - The properties for the component.
 * @param {number} props.customerId - The unique identifier of the customer.
 * @param {string} props.customerName - The name of the customer.
 * @param {(customerId: number) => Promise<void>} props.customerAddresses - A function that updates the client's address data in the Redux store.
 * @param {ICustomerAddresses[]} props.addressCustomer - An array of customer addresses to be displayed in the component.
 * 
 * @returns {JSX.Element} A set of cards displaying customer address details, each with information like the address, shipping method, and an "Edit" button.
 */
const AddressesCards: React.FC<IAddressesCardsProps> = ({ customerId, customerName, customerAddresses, addressCustomer }) => {
    //hooks
    const { showSnackbar } = useSnackbar();
    //services
    const { editCustomerAddress, deleteCustomerAddress } = addressService();
    //states
    const [openEditModal, setOpenEditModal] = useState(false);
    const [selectedAddressId, setSelectedAddressId] = useState(0);
    const [search, setSearch] = useState("");


    /**
    * Handles the update (PUT) or delete (DELETE) operation for an address.
    * 
    * @param {?boolean} [update] - Optional flag indicating whether the operation is an update (PUT). 
    * If true, the address will be updated.
    * @param {?IEditCustomerAddress} [data] - Optional address data to be updated. This is required if the operation is an update (PUT).
    * @param {?number} [addressId] - Optional address ID for the address to be updated or deleted.
    * If provided with `update`, it will update the specified address. If provided without `update`, 
    * the address will be deleted.
    * 
    * @returns {Promise<void>} A promise indicating the result of the operation (update or delete).
    */
    const handelPutOrDeleteAddress = async (update?: boolean, data?: IEditCustomerAddress, addressId?: number) => {
        if (update) {
            const resAddress: IResponseDto<IAddressResponse | null> = await editCustomerAddress(data!);
            handleRequestDto({
                response: resAddress,
                snackBar: showSnackbar,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: resAddress.error.mensaje,
                    success: NOTIFICATIONS_ADDRESS.ADDRESS.PUT_SUCCESS,
                },
                onSuccess: async () => {
                    if (resAddress.data) {
                        await customerAddresses(customerId)
                        setOpenEditModal(false)
                    }
                }
            });
        } else {
            const resAddress = await deleteCustomerAddress(customerId, addressId!);
            await handleRequestDto({
                response: resAddress,
                snackBar: showSnackbar,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: NOTIFICATIONS_ADDRESS.ADDRESS.DELETE_ERROR,
                    success: NOTIFICATIONS_ADDRESS.ADDRESS.DELETE_SUCCESS,
                },
                onSuccess: async () => {
                    await customerAddresses(customerId)
                    setOpenEditModal(false)
                }
            });
        }
    }
    return (
        <>
            {/* SearchBar */}
            <Box mb={2}>
                <TextField
                    sx={{
                        width: { xs: '100%', md: '20%' }, paddingLeft: { xs: 0, md: '20px' }, borderRadius: '.5rem',
                        '& fieldset': {
                            borderRadius: '.5rem',
                            borderColor: ColorsEpico.ColorLightBlueishGray,
                        },
                        '& .MuiInputBase-input': {
                            height: '18px',
                        },
                    }}
                    variant="outlined"
                    size="small"
                    placeholder="Buscar dirección..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <SearchIcon sx={{ color: ColorsEpico.ColorBlack }} fontSize="small" />
                            </InputAdornment>
                        ),
                    }}
                />
            </Box>
            <Box sx={{ maxHeight: '400px', overflowY: 'auto', pr: 1, display: 'grid', gap: 2, width: '100%' }}>
                {openEditModal && <EditAddresModal
                    open={openEditModal}
                    customerId={customerId}
                    customerName={customerName}
                    addressId={selectedAddressId}
                    addressCustomer={addressCustomer}
                    onClose={() => setOpenEditModal(false)}
                    onSave={handelPutOrDeleteAddress}
                />}

                {addressCustomer && (() => {
                    var filtered = addressCustomer.filter((cust) => {
                        const direccion = `${cust.calle} ${cust.noExterior}${cust.noInterior ? ' Int. ' + cust.noInterior : ''}, ${cust.colonia}, ${cust.codigoPostal} ${cust.ciudad}, ${cust.estado}`;
                        const searchLower = search.toLowerCase();
                        return direccion.toLowerCase().includes(searchLower)
                            || (cust.paqueteria && cust.paqueteria.toLowerCase().includes(searchLower))
                            || (cust.direccionQr ? "activado" : "desactivado").includes(searchLower);
                    });
                    if (filtered.length === 0) {
                        return (
                            <Box display="flex" justifyContent="center" alignItems="center" height="200px" width="100%">
                                <Typography variant="h6" color={ColorsEpico.ColorGray}>
                                    No se encontraron direcciones
                                </Typography>
                            </Box>
                        );
                    }
                    return filtered.map((cust, index) => {
                        const direccion = `${cust.calle} ${cust.noExterior}${cust.noInterior ? ' Int. ' + cust.noInterior : ''}, ${cust.colonia}, ${cust.codigoPostal} ${cust.ciudad}, ${cust.estado}`;
                        const cardData = [
                            {
                                title: cust.fiscal ? "DIRECCIÓN FISCAL" : "DIRECCIÓN",
                                icon: <LocalShippingIcon sx={{ alignSelf: "center", fontSize: FontSizesEnum.Delta, color: ColorsEpico.ColorBlack, fontWeight: FontWeightEnum.Medium }} />,
                                content: direccion,
                                fiscal: cust.fiscal,
                                size: 6.9
                            },
                            {
                                title: "FORMA DE ENVÍO",
                                icon: <WatchLater sx={{ alignSelf: "center", fontSize: FontSizesEnum.Delta, color: ColorsEpico.ColorBlack }} />,
                                content: cust.paqueteria || "No especificado",
                                size: 2
                            },
                            {
                                title: "QR",
                                icon: <QrCodeIcon sx={{ alignSelf: "center", fontSize: FontSizesEnum.Delta, color: ColorsEpico.ColorBlack }} />,
                                content: (
                                    <Typography sx={{ fontSize: FontSizesEnum.Gamma, color: cust.direccionQr ? ColorsEpico.ColorForestGreen : ColorsEpico.ColorDeepCrimson, fontWeight: FontWeightEnum.Medium }}>
                                        {cust.direccionQr ? "Activado" : "Desactivado"}
                                    </Typography>
                                ),
                                size: 1.6
                            }
                        ];

                        // flexWrap nowrap en xs: `Grid2 container` trae wrap de fábrica,
                        // y una columna que envuelve reparte sus hijos en columnas
                        // nuevas hacia la derecha en cuanto el alto le queda corto. Cada
                        // bloque mide el 100% del renglón, así que esas columnas salen
                        // fuera de la pantalla y arrastran el documento: las tarjetas se
                        // ven cortadas por la izquierda y "Editar" aparece suelto a la
                        // derecha. Es el anti-patrón 9. En columna no hay nada que
                        // envolver.
                        return (
                            <Grid2
                                container
                                flexDirection={{ xs: 'column', md: 'row' }}
                                sx={{ flexWrap: { xs: 'nowrap', md: 'wrap' }, minWidth: 0 }}
                                rowGap={{ xs: 1, md: 0 }}
                                key={"cont-1-" + index}
                            >
                                {cardData.map((data, idx) => (
                                    <Grid2 size={{ xs: 12, md: data.size }} key={`${index}-${idx}`} px={{ xs: 0, md: '20px' }} >
                                        <Card
                                            variant="outlined"
                                            sx={{
                                                borderRadius: "8px",
                                                minHeight: '65px'
                                            }}
                                        >
                                            <CardContent sx={{ padding: "8px!important" }}>
                                                <Box display="flex" alignItems="start" gap={1}>
                                                    {data.icon}
                                                    <Typography sx={{ fontSize: FontSizesEnum.Delta, fontWeight: FontWeightEnum.Medium }}>
                                                        {`${data.title} ${(!cust.fiscal && idx === 0) ? index : ''}`}
                                                    </Typography>
                                                </Box>
                                                <Box component="div" display="flex" alignItems="center">
                                                    <Typography variant="subtitle1" sx={{ fontSize: FontSizesEnum.Gamma, color: ColorsEpico.ColorBlack, wordWrap: "break-word", width: "100%" }} >
                                                        {data.content}
                                                    </Typography>
                                                </Box>
                                            </CardContent>
                                        </Card>
                                    </Grid2>
                                ))}
                                <Grid2
                                    key={"cont-2-" + index}
                                    size={{ xs: 12, md: 1.5 }}
                                    sx={{
                                        display: "flex",
                                        justifyContent: { xs: "flex-end", md: "center" },
                                        alignItems: "center",
                                        // El `minHeight: 100%` existe para centrar el
                                        // botón a lo alto de la fila en escritorio. En
                                        // columna el porcentaje se mide contra un alto
                                        // automático, la caja se queda en cero y el
                                        // botón —centrado— se desborda por arriba y por
                                        // abajo, encimándose con la tarjeta anterior.
                                        minHeight: { xs: "auto", md: "100%" },
                                        // Objetivo táctil: es la única forma de editar
                                        // una dirección.
                                        "& .MuiButton-root": { minHeight: { xs: 44, md: "auto" } },
                                    }}
                                >
                                    {!cust.fiscal ? (
                                        <Button
                                            onClick={() => {
                                                setSelectedAddressId(cust.direccionId);
                                                setOpenEditModal(true);
                                            }}
                                            endIcon={<Edit sx={{ color: ColorsEpico.ColorGray }} />}
                                        >
                                            <Typography
                                                fontWeight={FontWeightEnum.Regular}
                                                color={ColorsEpico.ColorBlack}
                                                fontSize={FontSizesEnum.Delta}>
                                                Editar
                                            </Typography>
                                        </Button>
                                    ) : null}
                                </Grid2>
                            </Grid2>
                        );
                    })
                })()}
            </Box>
        </>

    );
};

export default AddressesCards;