import { Skeleton, Stack } from "@mui/material";

/**
 * Component that displays a loading skeleton for the delivery address form.
 * Shows placeholder animations for form fields like address, postal code,
 * and other input fields while the actual data is being loaded.
 * 
 * @component
 * @returns {JSX.Element} A skeleton loading UI for the delivery address form
 */
export const SkeletonDeliveryAdress = () => {
    return (
        <Stack direction={"column"} spacing={2} width="100%">
            <Stack direction={"row"} alignItems={'center'} justifyContent={'space-between'}>
                <Skeleton variant="text" width={180} height={30} />
                <Skeleton variant="rounded" width={152} height={24} />
            </Stack>

            <Skeleton variant="rounded" width="100%" height={40} />

            <Skeleton variant="text" width={180} height={30} />
            <Skeleton variant="rounded" width="100%" height={40} />

            <Stack direction={"row"} spacing={2} width="100%">
                <Stack direction={"column"} spacing={1} width="100%">
                    <Skeleton variant="text" width={120} height={30} />
                    <Skeleton variant="rounded" width="100%" height={40} />
                </Stack>
                <Stack direction={"column"} spacing={1} width="100%">
                    <Skeleton variant="text" width={160} height={30} />
                    <Skeleton variant="rounded" width="100%" height={40} />
                </Stack>
            </Stack>
        </Stack>
    );
};