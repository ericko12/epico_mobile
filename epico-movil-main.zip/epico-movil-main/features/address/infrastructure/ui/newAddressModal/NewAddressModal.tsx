import { JSX } from "react";
import { IModalNewAddress } from "@/features/address/infrastructure/ui/newAddressModal/NewAddressModal.types";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { Stack, Typography } from "@mui/material";
import { ModalWithoutButtons } from "@/features/common/infrastructure/ui/modal/modalWithoutButton/ModalWithoutButtons";
import { AddressForm } from "@/features/address/infrastructure/ui/addressForm/AddressForm";

/**
 * NewAddresModal Component
 * 
 * This component represents a modal for adding a new address for a customer.
 * It provides a form where the user can input the address details.
 * 
 * @component
 * @param {IModalNewAddress} props - The properties passed to the component.
 * @param {boolean} props.open - Determines if the modal is open or closed.
 * @param {() => void} props.onClose - Function to close the modal.
 * @param { (data: IAddress) => Promise<void>} props.onSave - Function to save action and close the modal.
 * @param {number} props.customerId - The unique identifier of the customer.
 * @param {string} props.customerName - The name of the customer.
 * 
 * @returns {JSX.Element} A JSX element representing the new address modal.
 */
const NewAddresModal: React.FC<IModalNewAddress> = ({ open, onSave, onClose, customerId, customerName }): JSX.Element => {

    return (
        <ModalWithoutButtons
            openModal={open}
            onClose={onClose}
            titulo="Nueva direccion de cliente"
            children={
                <Stack>
                    <Typography fontSize={FontSizesEnum.Gamma} fontWeight={FontWeightEnum.Medium}>
                        CLIENTE
                    </Typography>
                    <Typography fontSize={FontSizesEnum.Alpha} fontWeight={FontWeightEnum.Bold}>
                        {customerName}
                    </Typography>
                    <AddressForm
                        customerId={customerId}
                        onClose={onClose}
                        onSave={onSave}
                    />
                </Stack>
            }
        />
    );
};

export default NewAddresModal;