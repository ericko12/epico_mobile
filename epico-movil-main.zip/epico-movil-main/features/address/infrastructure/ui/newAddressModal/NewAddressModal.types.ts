import { IAddress } from "@/features/address/domain/interface/IAddress";

/**
 * Interface for the properties of the modal component for adding a new address.
 * @interface IModalNewAddress
 * 
 * @property {boolean} open - Determines whether the modal is open (`true`) or closed (`false`).
 * @property {number} customerId - The unique identifier of the customer associated with the new address.
 * @property {string} customerName - The name of the customer associated with the new address.
 * @property {() => void} onClose - Callback function executed when the modal is closed.
 * @property {(data: IAddress) => Promise<void>} onSave - Callback function executed when the save action is triggered.
 */
export interface IModalNewAddress {
    open: boolean;
    customerName: string;
    customerId: number;
    onClose: () => void;
    onSave: (data: IAddress) => Promise<void>;
}