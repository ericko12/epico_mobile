import React from 'react';
import { Grid2, Skeleton, Stack } from '@mui/material';

/**
 * Skeleton Loader for Customer Addresses Information.
 * 
 * @returns {JSX.Element} The skeleton loader element for customer addresses.
 */
export const CustomerInfoAddressesSkeleton = (): React.JSX.Element => {
    return (
        <Grid2
            container
            spacing={2}
            sx={{ paddingTop: '20px' }}
            alignItems="center"
        >
            <Stack direction="row" justifyContent="space-between" alignItems="center" width="100%">
                <Skeleton width={80} height={30} />
                <Skeleton width={180} height={60} />
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center"
                width="100%" spacing={2}>
                <Skeleton width="50%" height={130} />
                <Skeleton width="30%" height={130} />
                <Skeleton width="20%" height={130} />
            </Stack>
        </Grid2>
    )
}


