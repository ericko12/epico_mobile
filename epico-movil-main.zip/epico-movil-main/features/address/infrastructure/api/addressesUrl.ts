/**
 * Get the URL for the list of addresses.
 * 
 * This function returns the URL endpoint for retrieving all addresses.
 * 
 * @returns {string} The URL string for fetching all addresses.
 */
export const UrlAddresses = () => {
    return `/api/v1/Direcciones`; // Endpoint for fetching all addresses.
}

/**
 * Get the URL for posting a new address.
 * 
 * This function returns the URL endpoint for posting a new address.
 * 
 * @returns {string} The URL string for creating a new address.
 */
export const UrlPostAddress = () => {
    return `/api/v2/Direcciones`; // Endpoint for creating a new address.
}
/**
 * Get the URL for posting a new address.
 * 
 * This function returns the URL endpoint for posting a new address.
 * 
 * @returns {string} The URL string for creating a new address.
 */
export const UrlPostExternalAddress = () => {
    return `/api/v3/Direcciones`; // Endpoint for creating a new address.
}

/**
 * Get the URL for retrieving a geolocation suggestion based on address details.
 *
 * This function returns the URL endpoint for fetching a suggested geographical position
 * for a given address using the v2 Direcciones Geoposicion resource.
 *
 * @returns {string} The URL string for the geolocation suggestion endpoint.
 */
export const UrlGetGeoposicion = () => {
    return `/api/v2/Direcciones/Geoposicion`;
}
/**
 * Get the URL for retrieving customer addresses.
 * 
 * This function returns the URL endpoint for fetching addresses associated with a specific customer, 
 * identified by their `clienteId`.
 * 
 * @param {number} clienteId - The unique identifier of the customer.
 * @returns {string} The URL string for fetching the customer's addresses.
 */
export const UrlGetCustomerAddresses = (clienteId: number) => {
    return `/api/v1/Direcciones/Clientes/${clienteId}`; // Endpoint for fetching a customer's addresses.
}

/**
 * Get the URL for retrieving available shipping services.
 * 
 * This function returns the URL endpoint for fetching available parcel or shipping services.
 * 
 * @returns {string} The URL string for fetching parcel or shipping services.
 */
export const UrlGetCustomerParcels = () => {
    return `/api/v1/Direcciones/Paqueterias`; // Endpoint for fetching available shipping services.
}

/**
 * Get the URL for retrieving colonies (neighborhoods or districts) by postal code.
 * 
 * This function returns the URL endpoint for fetching colonies that match the provided postal code.
 * 
 * @param {string} cPostal - The postal code for which to retrieve colonies.
 * @returns {string} The URL string for fetching colonies by postal code.
 */
export const UrlGetColoniasByCPostal = (cPostal: string) => {
    return `/api/v2/Direcciones/Colonias/${cPostal}`; // Endpoint for fetching colonies by postal code.
}

/**
 * Get the URL for deleting an address.
 * 
 * This function returns the URL endpoint for deleting an address associated with a specific customer.
 * 
 * @param {number} clienteId - The unique identifier of the customer.
 * @param {number} direccionId - The unique identifier of the address to be deleted.
 * @returns {string} The URL string for deleting the address.
 */
export const UrlDeleteAddresses = (clienteId: number, direccionId: number) => {
    return `/api/v1/Direcciones/${clienteId}/${direccionId}`; // Endpoint for deleting a customer's address.
}

/**
 * Get the URL for retrieving the state based on the colonia (neighborhood) ID.
 * 
 * This function returns the URL endpoint for fetching the state related to a specific colonia (neighborhood).
 * 
 * @param {number} coloniaId - The unique identifier of the colonia (neighborhood).
 * @returns {string} The URL string for retrieving the state by colonia ID.
 */
export const UrlGetEstadoByColonia = (coloniaId: number) => {
    return `/api/v1/Direcciones/Ciudad/Municipio/Estado/${coloniaId}`; // Endpoint for fetching the state based on colonia ID.
}

/**
 * Get the URL for retrieving all colonies.
 * 
 * This function returns the URL endpoint for fetching a list of all available colonies.
 * 
 * @returns {string} The URL string for fetching all colonies.
 */
export const UrlGetColonies = () => {
    return `/api/v1/Direcciones/Colonias`; // Endpoint for fetching all colonies.
}

/**
 * Get the URL for retrieving states based on country ID.
 * 
 * This function returns the URL endpoint for fetching the states available in a specific country, 
 * identified by the `ContryId`. If no `ContryId` is provided, it returns the URL for all states.
 * 
 * @param {number | null} ContryId - The country ID (optional). If `null`, fetches states for all countries.
 * @returns {string} The URL string for fetching states by country ID.
 */
export const UrlGetStates = (ContryId: number | null) => {
    if (ContryId !== null) {
        return `/api/v1/Direcciones/Estados?paisId=${ContryId}`; // Endpoint for fetching states for a specific country.
    }
    return `/api/v1/Direcciones/Estados`; // Endpoint for fetching all states.
}

/**
 * Get the URL for retrieving all cities.
 * 
 * This function returns the URL endpoint for fetching a list of all available cities.
 * 
 * @returns {string} The URL string for fetching all cities.
 */
export const UrlGetCities = () => {
    return `/api/v1/Direcciones/Ciudades`; // Endpoint for fetching all cities.
}

/**
 * Get the URL for retrieving all municipalities.
 * 
 * This function returns the URL endpoint for fetching a list of all available municipalities.
 * 
 * @returns {string} The URL string for fetching all municipalities.
 */
export const UrlGetMunicipalities = () => {
    return `/api/v1/Direcciones/Municipios`; // Endpoint for fetching all municipalities.
}