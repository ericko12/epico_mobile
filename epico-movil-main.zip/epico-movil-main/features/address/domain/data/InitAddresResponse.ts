import { IAddressResponse } from "@/features/address/domain/interface/IAddressResponse";

/**
 * Default values for the IAddressResponse interface.
 * Used when no data is available or to initialize the response object.
 *
 * @type {IAddressResponse}
 */
export const DefaultIAddressResponse: IAddressResponse = {
    direccionId: 0,
    agregadoConExito: false
};