/**
 * Interface for Parcel/Shipping Service model.
 * 
 * This interface defines the structure for a shipping or parcel service, including the unique identifier
 * for the shipping service and its name.
 * 
 * @property {number} paqueteriaId - The unique identifier for the shipping or parcel service.
 * @property {string} paqueteria - The name of the shipping or parcel service.
 */
export interface ICustomerParcels {
    paqueteriaId: number;
    paqueteria: string;
}
