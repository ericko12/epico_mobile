/**
 * Interface for customer address information.
 * @interface ICustomerAddresses
 * 
 * This interface defines the structure for an address associated with a customer. It includes various properties
 * that represent the address details, such as street name, postal code, neighborhood, city, and courier service.
 * 
 * @property {number} direccionId - The unique identifier of the address.
 * @property {number} clienteId - The ID of the customer to whom the address belongs. (Required)
 * @property {?boolean} [esSucursal] - A boolean indicating whether the address is a branch (true or false). This property is optional.
 * @property {?string} [sucursal] - The name of the branch, if the address is a branch. Can be undefined if not a branch.
 * @property {string} [codigoPostal] - The postal code of the address. (Required)
 * @property {string} [calle] - The street name of the address. (Required)
 * @property {string} [noExterior] - The exterior number of the address (can be numeric or alphanumeric). (Required)
 * @property {string} [noInterior] - The interior number of the address (e.g., apartment number, if applicable).
 * @property {boolean} fiscal - A boolean indicating whether the address is a fiscal address. (Required)
 * @property {string} [colonia] - The name of the neighborhood or district. (Required)
 * @property {?number} [coloniaId] - The ID of the neighborhood or district.
 * @property {number} ciudadId - The ID of the city where the address is located. (Required)
 * @property {?string} [ciudad] - The name of the city. Can be undefined if not provided.
 * @property {?number} [municipioId] - The ID of the municipality.
 * @property {?string} [municipio] - The name of the municipality.
 * @property {?number} [estadoId] - The ID of the state.
 * @property {?string} [estado] - The name of the state.
 * @property {?boolean} [principal] - A boolean indicating whether the address is the customer's main address.
 * @property {string} [referenciaDireccion] - Additional reference for the address, such as landmarks or specific details. Can be undefined.
 * @property {number} [paqueteriaId] - The ID of the courier or shipping company associated with this address. (Required)
 * @property {?string} [paqueteria] - The name of the courier service or shipping company.
 * @property {?string} [direccionQr] - The QR code associated with the address. Can be undefined if not available.
 * @property {?string} [pais] - address service modified, now returns the country for LMS registration. Can be undefined if not available.
 * @property {?number} [iva] - The IVA (VAT) percentage associated with the address. Can be undefined if not available.
 * @property {?Object} [geoPosicion] - Geographical position of the address.
 * @property {number} [geoPosicion.latitud] - The latitude coordinate of the address.
 * @property {number} [geoPosicion.longitud] - The longitude coordinate of the address.
*/
export interface ICustomerAddresses {
    direccionId: number;
    clienteId: number; //Required
    esSucursal?: boolean;
    sucursal?: undefined | string;
    codigoPostal: undefined | string; //Required
    calle: undefined | string; //Required
    noExterior: undefined | string; //Required
    noInterior: undefined | string; //Required
    fiscal: boolean; //Required
    colonia: undefined | string; //Required
    coloniaId?: number;
    ciudadId: number; //Required
    ciudad?: undefined | string;
    municipioId?: number;
    municipio?: undefined | string;
    estadoId?: number;
    estado?: undefined | string;
    principal?: boolean;
    referenciaDireccion: undefined | string; //Required
    paqueteriaId?: undefined | number; //Required
    paqueteria?: undefined | string;
    direccionQr?: undefined | string;
    pais?: undefined | string;
    iva?: number;
    geoPosicion?: {
        latitud: number;
        longitud: number;
    }
}
