/**
 * Interface for Colonia model.
 * 
 * This interface defines the structure of a colonia (neighborhood or district), including the city ID,
 * colonia ID, the name of the colonia, and its postal code.
 * 
 * @property {number} ciudadId - The unique identifier for the city that this colonia belongs to.
 * @property {number} coloniaId - The unique identifier for the colonia.
 * @property {string} colonia - The name of the colonia (neighborhood or district).
 * @property {string} codigoPostal - The postal code of the colonia.
 */
export interface IColonia {
    ciudadId: number;
    coloniaId: number;
    colonia: string;
    codigoPostal: string;
}
