
/**
 * Represents the structure of an external address form.
 * 
 * @interface IFormExternalAddress
 * 
 * @property {number} externalAddressId - The unique identifier for the external address.
 * @property {string} street - The street name of the address.
 * @property {string} exteriorNumber - The exterior number of the building.
 * @property {string} interiorNumber - The interior number or apartment/suite number.
 * @property {string} postalCode - The postal/ZIP code of the address.
 * @property {number} neighborhoodId - The unique identifier for the neighborhood.
 * @property {string} neighborhood - The name of the neighborhood.
 * @property {string} state - The state or province of the address.
 * @property {number} cityId - The unique identifier for the city.
 * @property {string} city - The name of the city.
 * @property {number | string} latitud - The latitude coordinate of the address location.
 * @property {number | string} longitud - The longitude coordinate of the address location.
 */
export interface IFormExternalAddress {
    externalAddressId: number;
    street: string;
    exteriorNumber: string;
    interiorNumber: string;
    postalCode: string;
    neighborhoodId: number;
    neighborhood: string;
    state: string;
    cityId: number;
    city: string;
    latitud: number | string;
    longitud: number | string;
}