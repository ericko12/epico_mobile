/**
 * Interface for State, City, and Municipality model.
 * 
 * This interface defines the structure of a location that includes the state, city, municipality,
 * and their associated identifiers and postal code.
 * 
 * @property {number} ciudadId - The unique identifier for the city.
 * @property {string} ciudad - The name of the city.
 * @property {string} codigoPostal - The postal code of the city.
 * @property {number} municipioId - The unique identifier for the municipality.
 * @property {string} municipio - The name of the municipality.
 * @property {number} estadoId - The unique identifier for the state.
 * @property {string} estado - The name of the state.
 */
export interface IEstadoCiudadMunicipio {
    // ids
    ciudadId: number;
    estadoId: number;
    municipioId: number;

    // data
    estado: string;
    ciudad: string;
    municipio: string;
    codigoPostal: string;
}
