/**
 * Interface for City model.
 * 
 * This interface defines the structure of a city, which includes information like the city ID,
 * municipality ID, and the name of the city.
 * 
 * @property {number} ciudadId - The unique identifier for the city.
 * @property {number} municipioId - The unique identifier for the municipality to which the city belongs.
 * @property {string} ciudad - The name of the city.
 */
export interface ICity {
    // ids
    ciudadId: number,
    municipioId: number,

    // data
    ciudad: string,
}
