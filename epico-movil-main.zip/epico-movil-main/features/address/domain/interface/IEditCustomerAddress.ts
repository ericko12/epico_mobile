/**
 * Interface for editing a customer address.
 *
 * This interface defines the structure of the request body used to update an existing customer address,
 * including address details and optional geolocation coordinates.
 *
 * @property {number} direccionId - The unique identifier of the address to edit.
 * @property {boolean} fiscal - Indicates whether the address is a fiscal address.
 * @property {string} colonia - The name of the neighborhood or district.
 * @property {number} clienteId - The unique identifier of the customer.
 * @property {string} codigoPostal - The postal code of the address.
 * @property {string} calle - The street name of the address.
 * @property {number} coloniaId - The unique identifier of the neighborhood or district.
 * @property {string} noExterior - The exterior number of the address.
 * @property {string} noInterior - The interior number of the address (e.g., apartment number).
 * @property {number} ciudadId - The unique identifier of the city.
 * @property {string} referenciaDireccion - Additional reference for the address, such as landmarks or specific details.
 * @property {number} [paqueteriaId] - The unique identifier of the courier or shipping company. Optional.
 * @property {Object} [geoPosicion] - The geographical position of the address.
 * @property {number} [geoPosicion.geoposicionLatitud] - The latitude coordinate of the address.
 * @property {number} [geoPosicion.geoposicionLongitud] - The longitude coordinate of the address.
 */
export interface IEditCustomerAddress {
    direccionId: number;
    fiscal: boolean;
    colonia: string;
    clienteId: number;
    codigoPostal: string;
    calle: string;
    coloniaId: number;
    noExterior: string;
    noInterior: string;
    ciudadId: number;
    referenciaDireccion: string;
    paqueteriaId?: number;
    geoPosicion?: {
        geoposicionLatitud: number;
        geoposicionLongitud: number;
    };
}
