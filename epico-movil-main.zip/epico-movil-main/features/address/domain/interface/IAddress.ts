
/**
 * Interface for the address properties.
 * @interface IAddress
 * 
 * @property {number} clienteId - The ID of the customer associated with the address.
 * @property {string} codigoPostal - The postal code of the address.
 * @property {string} calle - The street name of the address.
 * @property {number} coloniaId - The ID of the neighborhood or district to which the address belongs.
 * @property {string} noExterior - The exterior number of the address (can be numeric or alphanumeric).
 * @property {string} noInterior - The interior number of the address (e.g., apartment number, if applicable).
 * @property {?number} paqueteriaId - The ID of the courier service associated with the address. This property is optional.
 * @property {number} ciudadId - The ID of the city where the address is located.
 * @property {number} latitud - The latitude coordinate of the address.
 * @property {number} longitud - The longitude coordinate of the address.
 */
export interface IAddress {
    clienteId: number;
    codigoPostal: string;
    calle: string;
    coloniaId: number;
    noExterior: string;
    noInterior: string;
    paqueteriaId?: number;
    ciudadId: number;
    latitud: number;
    longitud: number;
}