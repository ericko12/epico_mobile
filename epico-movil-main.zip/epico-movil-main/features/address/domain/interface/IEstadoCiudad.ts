import { ICity } from "@/features/address/domain/interface/ICity";

/**
 * Represents a state and its associated cities.
 *
 * This interface defines the structure of a geographical state
 * that contains a list of cities belonging to it.
 *
 * @property {number} estadoId - Unique identifier of the state.
 * @property {string} estado - Name of the state.
 * @property {ICity[]} cuidades - List of cities associated with the state.
 */
export interface IEstadoCiudad {
    estadoId: number;
    estado: string;
    cuidades: ICity[];

}

