/**
 * Interface for Address Form.
 * 
 * @property {?number} direccionId - The unique identifier for the address. This is optional and may be `undefined` 
 * if the address is new or doesn't have an identifier.
 * @property {string} calle - The street name of the address.
 * @property {string} ext - The external number of the building or house.
 * @property {string} int - The internal number (apartment, unit) if applicable.
 * @property {string} codigoPostal - The postal code of the address.
 * @property {number | ""} coloniaId - The ID of the colonia (neighborhood or district) associated with this address. 
 * It can be a number or an empty string if not provided.
 * @property {number | ""} estadoId - The ID of the state associated with this address. It can be a number or an empty string 
 * if not provided.
 * @property {number | ""} paqueteriaId - The ID of the package service associated with this address. 
 * It can be a number or an empty string if not provided.
 * @property {{ lat: number; lng: number }} [geoPosicion] - Optional geographical coordinates of the address.
 */
export interface IFormAddress {
    direccionId?: number;
    calle: string;
    ext: string;
    int: string;
    codigoPostal: string;
    coloniaId: number | "";
    estadoId: number | "";
    paqueteriaId: number | "";
    geoPosicion?: { lat: number; lng: number };
}
