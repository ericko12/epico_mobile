import { IFormAddress } from "@/features/address/domain/interface/IFormAddress";

/**
 * Extended interface for the address form.
 * 
 * @property {?number} direccionId - The unique identifier for the address. Optional, may be `undefined` if the address is new.
 * @property {string} calle - The street name of the address.
 * @property {string} ext - The external number of the building or house.
 * @property {string} int - The internal number (apartment, unit) if applicable.
 * @property {string} codigoPostal - The postal code of the address.
 * @property {string} estado - The state of the address.
 * @property {number | ""} coloniaId - The ID of the colonia (neighborhood or district) associated with this address. Can be a number or an empty string.
 * @property {number | ""} estadoId - The ID of the state associated with this address. Can be a number or an empty string.
 * @property {number | ""} paqueteriaId - The ID of the package service associated with this address. Can be a number or an empty string.
 * @property {number} municipioId - The ID of the associated municipality.
 * @property {string} municipio - The name of the municipality.
 */
export interface IFormAddressCompleted extends IFormAddress {
    estado: string;
    municipioId: number | "";
    municipio: string;
}
