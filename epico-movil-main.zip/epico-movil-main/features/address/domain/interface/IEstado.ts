/**
 * Interface for State model.
 * 
 * This interface defines the structure of a state, including the state ID, name, and abbreviation.
 * 
 * @property {number} estadoId - The unique identifier for the state.
 * @property {string} estado - The name of the state.
 * @property {string} abreviatura - The abbreviation of the state (e.g., "CA" for California).
 */
export interface IEstado {
    // ids
    estadoId: number,

    // data
    estado: string,
    abreviatura: string,
}
