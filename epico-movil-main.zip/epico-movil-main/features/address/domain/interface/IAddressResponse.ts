/**
 * Interface for the response from the endpoint to create a new address (postAddress).
 * @interface IAddressResponse
 * 
 * @property {number} direccionId - The ID of the newly created address.
 * @property {boolean} agregadoConExito - A flag indicating whether the address was successfully added (`true`) or not (`false`).
 */
export interface IAddressResponse {
    direccionId: number;
    agregadoConExito: boolean;
}

