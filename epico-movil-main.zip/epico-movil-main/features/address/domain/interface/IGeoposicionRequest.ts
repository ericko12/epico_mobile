/**
 * Interface for the geolocation suggestion request body.
 *
 * This interface defines the structure of the request sent to the geolocation endpoint
 * to retrieve a suggested geographical position based on address details.
 *
 * @interface IGeoposicionRequest
 * @property {number} ciudadId - The unique identifier of the city.
 * @property {string} calle - The street name of the address.
 * @property {number} coloniaId - The unique identifier of the neighborhood or district.
 * @property {string} codigoPostal - The postal code of the address.
 * @property {string} noExterior - The exterior number of the address.
 */
export interface IGeoposicionRequest {
    ciudadId: number;
    calle: string;
    coloniaId: number;
    codigoPostal: string;
    noExterior: string;
}
