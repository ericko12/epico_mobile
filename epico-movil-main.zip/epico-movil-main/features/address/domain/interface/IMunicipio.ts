/**
 * Interface for Municipality model.
 * 
 * This interface defines the structure of a municipality, including the state ID, municipality ID,
 * and the name of the municipality.
 * 
 * @property {number} estadoId - The unique identifier for the state that the municipality belongs to.
 * @property {number} municipioId - The unique identifier for the municipality.
 * @property {string} municipio - The name of the municipality.
 */
export interface IMunicipio {
    // ids
    estadoId: number,
    municipioId: number,

    // data
    municipio: string,
}
