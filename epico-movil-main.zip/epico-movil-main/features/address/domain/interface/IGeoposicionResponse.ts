/**
 * Interface for the geolocation suggestion response.
 *
 * This interface defines the structure of the response returned by the geolocation endpoint,
 * containing the formatted address string and the suggested geographical coordinates.
 *
 * @interface IGeoposicionResponse
 * @property {string} direccion - The formatted address string resolved from the given address details.
 * @property {number} geoposicionLatitud - The suggested latitude coordinate.
 * @property {number} geoposicionLongitud - The suggested longitude coordinate.
 */
export interface IGeoposicionResponse {
    direccion: string;
    geoposicionLatitud: number;
    geoposicionLongitud: number;
}
