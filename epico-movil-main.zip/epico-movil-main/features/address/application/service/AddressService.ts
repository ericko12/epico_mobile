import {
    UrlAddresses,
    UrlGetCities,
    UrlGetStates,
    UrlGetColonies,
    UrlGetMunicipalities,
    UrlDeleteAddresses,
    UrlGetCustomerParcels,
    UrlGetEstadoByColonia,
    UrlGetColoniasByCPostal,
    UrlGetCustomerAddresses,
    UrlPostAddress,
    UrlPostExternalAddress,
    UrlGetGeoposicion
} from "@/features/address/infrastructure/api/addressesUrl";
import { EPICO_API } from "@/axios/axios_helper";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { IEditCustomerAddress } from "@/features/address/domain/interface/IEditCustomerAddress";
import { IGeoposicionRequest } from "@/features/address/domain/interface/IGeoposicionRequest";
import { IGeoposicionResponse } from "@/features/address/domain/interface/IGeoposicionResponse";
import { IColonia } from "@/features/address/domain/interface/IColonia";
import { IEstado } from "@/features/address/domain/interface/IEstado";
import { IEstadoCiudadMunicipio } from "@/features/address/domain/interface/IEstadoCiudadMunicipio";
import { IMunicipio } from "@/features/address/domain/interface/IMunicipio";
import { ICity } from "@/features/address/domain/interface/ICity";
import { IAddress } from "@/features/address/domain/interface/IAddress";
import { IAddressResponse } from "@/features/address/domain/interface/IAddressResponse";
import { ICustomerParcels } from "@/features/address/domain/interface/IParcels";
import { handleRequest } from "@/features/common/infrastructure/api/handleRequest";

/**
 * Service for consuming the Address microservice.
 */
export const addressService = () => ({
    /**
     * Retrieves customer addresses by customer ID.
     * @param {number} clienteId - Customer ID.
     * @returns {Promise<IResponseDto<ICustomerAddresses[]>>} - The API response.
     */
    getCustomerAddresses: (clienteId: number) =>
        handleRequest<ICustomerAddresses[]>(EPICO_API.get(UrlGetCustomerAddresses(clienteId))),

    /**
     * Retrieves customer parcels.
     * @returns {Promise<IResponseDto<ICustomerParcels[]>>} - The API response.
     */
    getCustomerParcels: () =>
        handleRequest<ICustomerParcels[]>(EPICO_API.get(UrlGetCustomerParcels())),

    /**
     * Retrieves colonies by postal code.
     * @param {string} cPostal - Postal code.
     * @returns {Promise<IResponseDto<IColonia[]>>} - The API response.
     */
    getColoniasByCPostal: (cPostal: string) =>
        handleRequest<IColonia[]>(EPICO_API.get(UrlGetColoniasByCPostal(cPostal))),

    /**
     * Retrieves the state by colony ID.
     * @param {number} coloniaId - Colony ID.
     * @returns {Promise<IResponseDto<IEstadoCiudadMunicipio>>} - The API response.
     */
    getEstadoByColonia: (coloniaId: number) =>
        handleRequest<IEstadoCiudadMunicipio>(EPICO_API.get(UrlGetEstadoByColonia(coloniaId))),

    /**
     * Creates a new customer address.
     * @param {ICustomerAddresses} body - Address data to create.
     * @returns {Promise<IResponseDto<null>>} - The API response.
     */
    createCustomerAddress: (body: ICustomerAddresses) =>
        handleRequest<null>(EPICO_API.post(UrlAddresses(), body)),

    /**
     * Edits an existing customer address.
     * @param {ICustomerAddresses} body - Address data to update.
     * @returns {Promise<IResponseDto<null>>} - The API response.
     */
    editCustomerAddress: (body: IEditCustomerAddress) =>
        handleRequest<null>(EPICO_API.put(UrlAddresses(), body)),

    /**
     * Deletes a customer address.
     * @param {number} clienteId - Customer ID.
     * @param {number} direccionId - Address ID.
     * @returns {Promise<IResponseDto<null>>} - The API response.
     */
    deleteCustomerAddress: (clienteId: number, direccionId: number) =>
        handleRequest<null>(EPICO_API.delete(UrlDeleteAddresses(clienteId, direccionId))),

    /**
     * Retrieves a list of colonies.
     * @returns {Promise<IResponseDto<IColonia[] | null>>} - The API response.
     */
    getColonies: () =>
        handleRequest<IColonia[]>(EPICO_API.get(UrlGetColonies())),

    /**
     * Retrieves a list of states by country ID.
     * @param {number | null} ContryId - Country ID.
     * @returns {Promise<IResponseDto<IEstado[] | null>>} - The API response.
     */
    getStates: (ContryId: number | null) =>
        handleRequest<IEstado[]>(EPICO_API.get(UrlGetStates(ContryId))),

    /**
     * Retrieves a list of municipalities.
     * @returns {Promise<IResponseDto<IMunicipio[] | null>>} - The API response.
     */
    getMunicipalities: () =>
        handleRequest<IMunicipio[]>(EPICO_API.get(UrlGetMunicipalities())),

    /**
     * Retrieves a list of cities.
     * @returns {Promise<IResponseDto<ICity[] | null>>} - The API response.
     */
    getCities: () =>
        handleRequest<ICity[]>(EPICO_API.get(UrlGetCities())),

    /**
     * Posts a new address.
     * @param {IAddress} data - Address data to post.
     * @returns {Promise<IResponseDto<IAddressResponse | null>>} - The API response.
     */
    postAddress: (data: IAddress) =>
        handleRequest<IAddressResponse | null>(EPICO_API.post(UrlPostAddress(), data)),
    /**
         * Posts a new external address.
         * @param {IAddress} data - Address data to post.
         * @returns {Promise<IResponseDto<IAddressResponse | null>>} - The API response.
         */
    postExternalAddress: (data: IAddress) =>
        handleRequest<IAddressResponse | null>(EPICO_API.post(UrlPostExternalAddress(), data)),

    /**
     * Retrieves a geolocation suggestion for the given address details.
     * @param {IGeoposicionRequest} body - Address data to resolve into coordinates.
     * @returns {Promise<IResponseDto<IGeoposicionResponse | null>>} - The API response with the suggested coordinates.
     */
    getGeoposicion: (body: IGeoposicionRequest) =>
        handleRequest<IGeoposicionResponse | null>(EPICO_API.post(UrlGetGeoposicion(), body)),

});

export type ApiTypeAddress = ReturnType<typeof addressService>;