
/**
 * Represents the state of the form for creating a role.
 * It includes form values, errors, a message, and response status. 
 */
export type formAddressState =
    | {
        values?: {
            calle?: string
            ext?: string
            int?: string
            codigoPostal?: string
            coloniaId?: number
            estadoId?: number
            paqueteriaId?: number
        }
        errors?: {
            calle?: string[]
            ext?: string[]
            int?: string[]
            codigoPostal?: string[]
            coloniaId?: string[]
            estadoId?: string[]
            paqueteriaId?: string[]
        }
        message?: string
        responses?: {
            success: boolean
        }
        initialState?: boolean
    }
    | undefined