import { FORM_PARAM } from "@/features/address/infrastructure/ui/addressForm/addressForm.data";
import { formAddressState } from "@/features/address/application/formStates/formAddressState";
import { ADDRESS_VALIDATION_SCHEMA } from "@/features/address/application/actions/validators/formNewAddressSchema";


/**
 * Validation of customer address forms
 *
 * @async
 * @param {formAddressState} _state 
 * @param {FormData} formData 
 * @returns {Promise<formAddressState>} 
 */
export const submitAddress = async (_state: formAddressState, formData: FormData): Promise<formAddressState> => {
    const address = {
        calle: formData.get(FORM_PARAM.calle)?.toString().trim(),
        ext: formData.get(FORM_PARAM.ext)?.toString().trim(),
        int: formData.get(FORM_PARAM.int)?.toString().trim(),
        codigoPostal: formData.get(FORM_PARAM.codigoPostal)?.toString().trim(),
        coloniaId: Number(formData.get(FORM_PARAM.coloniaId)),
        estadoId: Number(formData.get(FORM_PARAM.estadoId)),
        paqueteriaId: Number(formData.get(FORM_PARAM.paqueteriaId))
    }
    const validatedFields = ADDRESS_VALIDATION_SCHEMA.safeParse(address);
    if (!validatedFields.success) {
        return { values: address, errors: validatedFields.error.flatten().fieldErrors };
    }
    return { values: address, errors: undefined, responses: { success: true } };

}