import { z } from "zod";
/**
 * Validation schema using `zod` for form fields.
 * This schema validates address-related input data (street, number, postal code, etc.)
 */
export const ADDRESS_VALIDATION_SCHEMA = z.object({
    calle: z
        .string()
        .trim()
        .max(150, { message: 'Excede los 150 characteres permitidos' }) // Max length validation
        .nonempty({ message: 'Campo requerido' }), // Ensures that the field is not empty

    ext: z
        .string()
        .trim()
        .max(15, { message: 'Excede los 15 characteres permitidos' }) // Max length validation
        .nonempty({ message: 'Campo requerido' }), // Ensures the field is not empty

    int: z
        .string()
        .trim()
        .max(15, { message: 'Excede los 15 characteres permitidos' }), // Max length validation

    codigoPostal: z
        .string()
        .trim()
        .min(5, { message: 'Min. 5 digitos' }) // Ensures postal code is exactly 5 digits
        .max(5, { message: 'Min. 5 digitos' }) // Ensures postal code is exactly 5 digits
        .nonempty({ message: 'Campo requerido' }), // Ensures the field is not empty

    coloniaId: z
        .number({ invalid_type_error: "Campo requerido" })
        .min(1, "Campo requerido"),

    estadoId: z
        .number({ invalid_type_error: "Campo requerido" })
        .min(1, "Campo requerido"),

    paqueteriaId: z
        .number({ invalid_type_error: "Campo requerido" })
        .min(1, "Campo requerido"),
});
