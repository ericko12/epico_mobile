import { IBranchAddress } from "@/features/branch/domain/interfaces/branch/IBranchAddress";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";

/**
 * Formats the address of a branch or customer address.
 *
 * @param {(IBranchAddress | ICustomerAddresses)} Address - Object with the address of the branch or customer. Can be of type `IBranchAddress` or `ICustomerAddresses`.
 * @returns {string} The formatted address as a string.
 */
export const formatBranchAddress = (Address: IBranchAddress | ICustomerAddresses): string => {
    const {
        calle,
        noExterior,
        noInterior,
        colonia,
        codigoPostal,
        municipio,
        estado,
    } = Address;

    const interior = noInterior ? ` Int. ${noInterior}` : '';

    return `${calle} ${noExterior}${interior}, ${colonia}, ${codigoPostal} ${municipio}, ${estado}`;
};