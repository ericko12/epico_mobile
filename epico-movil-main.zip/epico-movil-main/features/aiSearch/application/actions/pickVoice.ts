/**
 * Elegir la voz de Ania, y prepararle el texto.
 *
 * **Por qué hace falta elegir.** `speechSynthesis.getVoices()` devuelve lo que
 * tenga instalado el dispositivo, en un orden que no significa nada. Tomar la
 * primera voz `es-MX` es lo que hacía este código antes, y en Windows eso suele
 * ser **Microsoft Raúl**: masculina y de las locales, que son justo las que suenan
 * a robot de los noventa. Las buenas están casi siempre más abajo en la lista.
 *
 * **Qué separa una voz fluida de una robótica.** No es el idioma, es el motor:
 *
 * - Las **locales** (`localService: true`) son las viejas de síntesis por
 *   concatenación. Suenan metálicas y entrecortadas.
 * - Las **de red** (`localService: false`) son neuronales y suenan como una
 *   persona. Se reconocen por el nombre: `Natural`, `Neural`, `Online`,
 *   `Wavenet`, o las de `Google`.
 *
 * En Edge está «Microsoft Dalia Online (Natural) - Spanish (Mexico)», que es
 * femenina y neuronal; en Android, «Google español de México»; en iOS, «Paulina».
 * Las tres son buenas, y las tres perdían contra Raúl con el criterio anterior.
 *
 * Aquí no se adivina el género por ningún dato del navegador —la API no lo
 * expone— sino por el nombre propio de la voz, que es lo único que hay.
 */

/** Una voz, con lo poco que la API dice de ella. */
export interface IVoiceLike {
    name: string;
    lang: string;
    localService?: boolean;
}

/** Nombres de voces femeninas que traen los motores en español. */
const FEMENINAS = [
    "sabina", "dalia", "paulina", "monica", "mónica", "renata", "ximena", "isabela",
    "esperanza", "helena", "laura", "marisol", "lupe", "angelica", "angélica",
    "camila", "catalina", "elena", "jimena", "luciana", "salome", "salomé",
    "valentina", "yolanda", "carmen", "francisca", "sofia", "sofía", "tania",
    "karla", "andrea", "larissa", "maria", "maría", "teresa", "elvira", "nuria",
    "conchita", "lucia", "lucía", "penelope", "penélope", "female", "femenina", "mujer",
];

/** Nombres de voces masculinas, para descartarlas cuando se pide femenina. */
const MASCULINAS = [
    "raul", "raúl", "jorge", "diego", "carlos", "juan", "pablo", "miguel",
    "enrique", "alonso", "liberto", "alvaro", "álvaro", "mateo", "tomas", "tomás",
    "gonzalo", "javier", "felipe", "pedro", "luis", "ricardo", "andres", "andrés",
    "arnau", "dario", "darío", "emilio", "gerardo", "hector", "héctor", "lorenzo",
    "rodrigo", "male", "masculino", "hombre",
];

/**
 * Las voces elegidas para Ania, **en orden de preferencia**.
 *
 * - **Dalia** («Microsoft Dalia Online (Natural) - Spanish (Mexico)») es neuronal
 *   y femenina, y es la que suena bien. La expone **Edge**, no Chrome: es una voz
 *   de servidor de Microsoft, y por eso no está en todas partes.
 * - **Sabina** («Microsoft Sabina - Spanish (Mexico)») es la mejor de las locales
 *   de Windows. Es de síntesis por concatenación, así que suena más dura, pero
 *   está instalada en cualquier Windows y es la que salva a quien usa Chrome.
 *
 * Se eligieron a mano en vez de dejarlo todo a la puntuación porque la decisión ya
 * está tomada: es la voz del asistente y conviene que sea la misma en los equipos
 * que puedan darla.
 *
 * ⚠️ **En Android y en iOS no existe ninguna de las dos.** Ahí decide la
 * puntuación de abajo con lo que traiga el dispositivo. Uniformar la voz de verdad
 * exigiría sintetizar en servidor, y eso se descartó por costo.
 */
const PREFERIDAS = ["dalia", "sabina"];

/**
 * Cuánto pesa ser una de las elegidas, y cuánto baja por cada puesto.
 *
 * El escalón importa: donde estén las dos —un Windows con Edge—, Dalia tiene que
 * ganar a Sabina aunque Sabina también esté en la lista.
 */
const BONO_PREFERIDA = 500;
const ESCALON_PREFERIDA = 60;

/** Marcas en el nombre que delatan un motor neuronal. */
const NEURONALES = ["natural", "neural", "online", "wavenet", "premium", "enhanced", "google"];

/** Sexo deducido del nombre de la voz. */
export enum VoiceGenderEnum {
    Femenina = "femenina",
    Masculina = "masculina",
    Desconocido = "desconocido",
}

/**
 * Deduce el sexo por el nombre propio de la voz.
 *
 * @param {string} name - Nombre de la voz tal como lo da el navegador.
 * @returns {VoiceGenderEnum} Lo que se puede deducir del nombre.
 */
export const voiceGender = (name: string): VoiceGenderEnum => {
    const n = (name ?? "").toLowerCase();
    if (FEMENINAS.some((f) => n.includes(f))) return VoiceGenderEnum.Femenina;
    if (MASCULINAS.some((m) => n.includes(m))) return VoiceGenderEnum.Masculina;
    return VoiceGenderEnum.Desconocido;
};

/**
 * ¿Es una voz en español?
 *
 * @param {IVoiceLike} v - Voz a comprobar.
 * @returns {boolean} `true` si habla español.
 */
export const isSpanish = (v: IVoiceLike): boolean =>
    (v.lang ?? "").toLowerCase().startsWith("es");

/**
 * Puntúa una voz. Más alto es mejor.
 *
 * El orden de importancia sale de lo que de verdad se nota al oírla: primero que
 * suene a persona (motor neuronal), después que sea femenina —lo que se pidió— y
 * al final el acento. Una voz neuronal de España se entiende mucho mejor que una
 * local mexicana.
 *
 * @param {IVoiceLike} v - Voz a puntuar.
 * @returns {number} Puntuación; negativa si no sirve.
 */
export const scoreVoice = (v: IVoiceLike): number => {
    if (!isSpanish(v)) return -1000;

    const nombre = (v.name ?? "").toLowerCase();
    const lang = (v.lang ?? "").toLowerCase().replace("_", "-");
    let s = 0;

    // 0. Las voces decididas para Ania, si el dispositivo las trae. Por encima de
    // todo, y en orden: primero Dalia, después Sabina.
    const puesto = PREFERIDAS.findIndex((f) => nombre.includes(f));
    if (puesto >= 0) s += BONO_PREFERIDA - puesto * ESCALON_PREFERIDA;

    // 1. Que suene a persona. Es lo que más pesa, con diferencia.
    if (NEURONALES.some((q) => nombre.includes(q))) s += 60;
    if (v.localService === false) s += 40;

    // 2. Que sea mujer.
    const sexo = voiceGender(v.name);
    if (sexo === VoiceGenderEnum.Femenina) s += 50;
    else if (sexo === VoiceGenderEnum.Masculina) s -= 70;

    // 3. El acento, al final.
    if (lang === "es-mx") s += 20;
    else if (lang.startsWith("es-419") || lang === "es-us") s += 14;
    else if (lang === "es-co" || lang === "es-ar" || lang === "es-cl") s += 8;
    else if (lang === "es-es") s += 4;

    return s;
};

/**
 * Ordena las voces en español de mejor a peor.
 *
 * @param {IVoiceLike[]} voices - Todo lo que devolvió el navegador.
 * @returns {IVoiceLike[]} Solo las de español, de mejor a peor.
 */
export const rankVoices = <T extends IVoiceLike>(voices: T[]): T[] =>
    (voices ?? [])
        .filter(isSpanish)
        .map((v) => ({ v, s: scoreVoice(v) }))
        .sort((a, b) => b.s - a.s || a.v.name.localeCompare(b.v.name))
        .map((x) => x.v);

/**
 * Elige la voz que se va a usar.
 *
 * No hay nada que configurar: gana **Dalia** si está, si no **Sabina**, y si no
 * hay ninguna de las dos, la mejor que haya según la puntuación. Se decidió así en
 * vez de ofrecer un selector porque el catálogo de voces cambia de un equipo a
 * otro y elegir a oído es trabajo que no le toca al vendedor.
 *
 * @param {IVoiceLike[]} voices - Todo lo que devolvió el navegador.
 * @returns {IVoiceLike | undefined} La voz elegida, o nada si no hay ninguna en
 * español —entonces el navegador usa la del sistema—.
 */
export const pickVoice = <T extends IVoiceLike>(voices: T[]): T | undefined =>
    rankVoices(voices)[0];

/**
 * Prepara un texto para que se lea con naturalidad.
 *
 * Los motores de síntesis leen los signos: unas comillas angulares se convierten
 * en un tropiezo, una línea en blanco no produce ninguna pausa y un guion largo
 * se lee como silencio raro. Esto no cambia la voz, pero sí la cadencia, que es
 * la mitad de lo que hace que suene entrecortada.
 *
 * @param {string} texto - La prosa del agente, tal como llegó.
 * @returns {string} El mismo texto, dicho de forma que se lea seguido.
 */
export const textToSpeak = (texto: string): string => {
    let t = (texto ?? "").trim();
    if (!t) return "";

    // Los saltos de línea sí tienen que sonar a pausa: si el renglón no acaba en
    // signo, se le pone punto para que el motor baje la entonación en vez de
    // encadenar dos frases sin respirar.
    t = t.replace(/\s*\n+\s*/g, (m, offset: number) => {
        const antes = t[offset - 1] ?? "";
        return /[.,;:!?]/.test(antes) ? " " : ". ";
    });

    // Signos que el motor pronuncia o que le hacen tropezar.
    t = t.replace(/[«»“”"‘’*#_`|]/g, " ");
    // El guion largo se lee mejor como coma.
    t = t.replace(/\s+[—–]\s+/g, ", ");
    // Paréntesis: se quedan las palabras, se va el tropiezo.
    t = t.replace(/[()]/g, " ");

    t = t.replace(/\s{2,}/g, " ").replace(/\s+([.,;:!?])/g, "$1").trim();
    // Puntuación repetida por la unión de renglones.
    t = t.replace(/([.,;:!?])\1+/g, "$1").replace(/\.\s*,/g, ".");

    // Que acabe en punto: sin él, la última palabra se corta en seco.
    if (!/[.!?…]$/.test(t)) t += ".";
    return t;
};

/** Cómo se pide que se diga: velocidad y tono. */
export interface IProsody {
    rate: number;
    pitch: number;
}

/**
 * Ajustes de habla según el motor que va a hablar.
 *
 * Esto es contraintuitivo y merece la explicación: **a una voz neuronal no se le
 * toca el tono**. Trae su propia entonación aprendida, y moverle el `pitch` la
 * vuelve metálica, que es justo lo que se quiere evitar. A las locales, en cambio,
 * subirles un poco el tono y bajarles la velocidad las hace algo menos duras,
 * porque de entonación propia no tienen ninguna.
 *
 * @param {IVoiceLike} [v] - Voz elegida; si no hay, se asume lo conservador.
 * @returns {IProsody} Velocidad y tono para la locución.
 */
export const prosodyFor = (v?: IVoiceLike | null): IProsody => {
    const nombre = (v?.name ?? "").toLowerCase();
    const neuronal = !!v && (NEURONALES.some((q) => nombre.includes(q)) || v.localService === false);
    // Un pelo por debajo de 1: el nombre de una pieza mal entendido obliga a
    // repetir el turno entero.
    if (neuronal) return { rate: 0.97, pitch: 1 };
    return { rate: 0.94, pitch: 1.12 };
};

/**
 * Longitud a partir de la cual se trocea la locución.
 *
 * Chrome corta las locuciones largas cuando la voz es de red: alrededor de los
 * quince segundos deja de hablar a media frase, sin error ni `onend`. Se trocea
 * por frases y se encolan: `speechSynthesis` las reproduce seguidas, así que no
 * se oye la costura, y ninguna llega al límite.
 */
export const SPEECH_CHUNK_MAX = 180;

/**
 * Parte un texto en trozos que se puedan decir seguidos.
 *
 * Corta por final de frase, y solo si un trozo sigue siendo demasiado largo baja
 * a comas y después a espacios. Nunca parte una palabra.
 *
 * @param {string} texto - Texto ya preparado con {@link textToSpeak}.
 * @param {number} [max] - Longitud máxima por trozo.
 * @returns {string[]} Los trozos, en orden.
 */
export const splitForSpeech = (texto: string, max: number = SPEECH_CHUNK_MAX): string[] => {
    const t = (texto ?? "").trim();
    if (!t) return [];
    if (t.length <= max) return [t];

    const frases = t.match(/[^.!?…]+[.!?…]*\s*/g) ?? [t];
    const trozos: string[] = [];
    let actual = "";

    /** Baja a comas, y de ahí a espacios, para lo que no cabe ni así. */
    const partirLargo = (s: string): string[] => {
        const piezas: string[] = [];
        let resto = s.trim();
        while (resto.length > max) {
            const ventana = resto.slice(0, max);
            const corte = Math.max(
                ventana.lastIndexOf(", "),
                ventana.lastIndexOf("; "),
                ventana.lastIndexOf(" ")
            );
            const en = corte > max * 0.4 ? corte + 1 : max;
            piezas.push(resto.slice(0, en).trim());
            resto = resto.slice(en).trim();
        }
        if (resto) piezas.push(resto);
        return piezas;
    };

    for (const frase of frases) {
        const f = frase.trim();
        if (!f) continue;
        if (f.length > max) {
            if (actual) {
                trozos.push(actual);
                actual = "";
            }
            trozos.push(...partirLargo(f));
            continue;
        }
        // Se juntan frases cortas mientras quepan: menos costuras, más fluidez.
        if (!actual) actual = f;
        else if (actual.length + 1 + f.length <= max) actual = `${actual} ${f}`;
        else {
            trozos.push(actual);
            actual = f;
        }
    }
    if (actual) trozos.push(actual);
    return trozos;
};
