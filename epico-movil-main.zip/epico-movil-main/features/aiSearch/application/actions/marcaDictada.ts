import { IMarcaDicha } from "@/features/aiSearch/domain/interfaces/IDictado";
import { CORTES, DISPARADORES_MARCA } from "@/features/aiSearch/domain/data/dictado.data";
import { tokenizar } from "@/features/aiSearch/application/actions/dictadoHipotesis";

/**
 * Encontrar la palabra que el usuario dijo como nombre de marca.
 *
 * **Esta función es la puerta de todo el rescate.** Si devuelve `null` no hay
 * aviso, no hay sonda y no hay oferta: el turno se queda exactamente como está
 * hoy. Y devuelve `null` en la gran mayoría de las frases, que es lo correcto.
 *
 * El criterio es deliberadamente estrecho —**un solo token, inmediatamente
 * detrás de la palabra «marca»**— porque en el navegador no hay ningún léxico del
 * español con el que distinguir una marca de una palabra corriente, ni ninguna
 * lista completa de marcas del catálogo contra la que reconocerla. Lo único que
 * queda es la posición en la frase, así que la posición tiene que ser inequívoca.
 *
 * Lo que este criterio deja fuera, a propósito:
 *
 * - **«de» no es disparador.** Es la palabra más frecuente del español, y en
 *   refacciones «de» más sustantivo es la forma normal de *nombrar la pieza*: «un
 *   juego de balatas», «bomba de agua». Con «de» como disparador, la palabra que
 *   dice **qué** se pide pasaría a ser candidata a marca.
 * - **Preguntar por las marcas no es nombrar una.** En «¿de qué marca tienes
 *   balatas para un Tsuru?» —la pregunta más común del mostrador— detrás de
 *   «marca» viene «tienes», que es palabra de corte. No hay marca dicha.
 * - **«Focos QBH», sin la palabra «marca», no se detecta.** Es el precio de no
 *   reescribir «de ese lado». Ensancharlo exigiría la lista completa de marcas,
 *   que es exactamente lo que no existe.
 */

/**
 * Localiza el nombre de marca que el usuario dijo.
 *
 * Se juzga **el último** disparador de la frase: si detrás de él no hay una
 * palabra nombrable, no se sigue buscando hacia atrás. Es más seguro no encontrar
 * ninguna marca que encontrar la equivocada.
 *
 * @param {string} texto - La frase tal como se envió.
 * @returns {IMarcaDicha | null} La palabra y su posición, o `null` si no se nombró
 * ninguna marca.
 */
export const localizarMarcaDicha = (texto: string): IMarcaDicha | null => {
    const tokens = tokenizar(texto);
    // Desde el penúltimo: un disparador al final de la frase no tiene nada detrás.
    for (let i = tokens.length - 2; i >= 0; i--) {
        if (!DISPARADORES_MARCA.includes(tokens[i].normal)) continue;

        // «la marca es QBH»: el verbo no es la marca.
        let j = i + 1;
        if (tokens[j] && tokens[j].normal === "es") j += 1;

        const candidato = tokens[j];
        if (!candidato) return null;
        if (CORTES.includes(candidato.normal)) return null;
        // Un nombre de marca tiene letras. Un token de solo cifras es una medida,
        // un año o un número de parte, y esos no se tocan nunca.
        if (!/[a-z]/.test(candidato.normal)) return null;

        return { palabra: candidato.crudo, indice: j };
    }
    return null;
};
