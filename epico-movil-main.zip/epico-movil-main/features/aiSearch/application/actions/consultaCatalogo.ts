import { IProductSearch } from "@/features/products/domain/interfaces/IProduct";
import {
    ISearchFacet,
    SearchModeEnum,
} from "@/features/products/domain/interfaces/ISearchProducts";
import {
    ISearchHydrationContext,
    searchCatalogueProducts,
} from "@/features/products/application/actions/searchCatalogueProducts";
import { CatalogueFilterDimensionEnum } from "@/features/products/application/actions/quickCatalogueFilters";
import { IConsultaCatalogo } from "@/features/aiSearch/domain/interfaces/IAiSearchState";

/**
 * Con qué frase abrir el catálogo desde una respuesta del asistente.
 *
 * El botón «Ver los N resultados en el catálogo» mandaba la frase tal cual el
 * usuario la dijo, y el catálogo busca **literal**. Medido contra producción con
 * un caso real:
 *
 * - `modo: ia`, «que tipo de cintas tienes» → `total: 66`.
 * - `modo: normal`, la misma frase → **`total: 0`**, y sin `terminoCorregido` al
 *   que caer de vuelta.
 * - `modo: normal`, `cinta` → `total: 66`, el mismo conjunto.
 *
 * El agente entiende la pregunta; el índice no. Y el servicio **no dice qué
 * buscó**: `terminoCorregido` y `marcaDetectada` vuelven en `null`. Lo único que
 * lo delata son las facetas, donde la familia con más resultados era `cinta`.
 *
 * De ahí las dos piezas de aquí: sacar esa familia, y **preguntar antes de
 * prometer**. La frase se sondea contra el índice, y solo si no encuentra nada se
 * cae a la familia. Así una consulta que ya funcionaba —«balatas chevy 2005»— no
 * pierde su precisión a cambio de arreglar la que no.
 */

/**
 * La familia con más resultados de una respuesta del buscador.
 *
 * Es lo más parecido a «qué buscó el agente» que el servicio deja ver.
 *
 * @param {ISearchFacet[]} [facets] - Facetas de la respuesta.
 * @returns {string | undefined} El valor de la familia principal, o nada.
 */
export const familiaPrincipal = (facets?: ISearchFacet[]): string | undefined => {
    const familia = facets?.find((f) => f.campo === CatalogueFilterDimensionEnum.Familia);
    const mejor = (familia?.valores ?? []).reduce<{ valor: string; conteo: number } | null>(
        (top, v) => (!top || v.conteo > top.conteo ? { valor: v.valor, conteo: v.conteo } : top),
        null
    );
    return mejor?.valor || undefined;
};

/**
 * Lo que devuelve un sondeo, reducido a lo que decide.
 *
 * @interface ISondeoConsulta
 */
export interface ISondeoConsulta {
    ok: boolean;
    total: number;
}

/**
 * Elige la consulta con la que abrir el catálogo.
 *
 * **La frase manda si funciona**: es más específica que la familia, y cambiarla
 * por «cinta» cuando el usuario escribió «balatas chevy 2005» le quitaría al
 * catálogo justo lo que hacía útil el enlace.
 *
 * Devuelve `null` cuando ninguna de las dos encuentra nada, y entonces el hilo no
 * pinta el botón: es mejor no ofrecer una salida que llevar a una pantalla vacía,
 * que es exactamente el defecto que esto arregla.
 *
 * @param {string} frase - Lo que se envió al asistente.
 * @param {ISondeoConsulta} [sondeoFrase] - Qué dijo el índice de la frase.
 * @param {string} [familia] - Familia principal de las facetas.
 * @param {ISondeoConsulta} [sondeoFamilia] - Qué dijo el índice de la familia.
 * @returns {IConsultaCatalogo | null} Consulta y total, o `null`.
 */
export const elegirConsultaCatalogo = (
    frase: string,
    sondeoFrase?: ISondeoConsulta,
    familia?: string,
    sondeoFamilia?: ISondeoConsulta
): IConsultaCatalogo | null => {
    if (sondeoFrase?.ok && sondeoFrase.total > 0) {
        return { consulta: frase.trim(), total: sondeoFrase.total };
    }
    if (familia && sondeoFamilia?.ok && sondeoFamilia.total > 0) {
        return { consulta: familia, total: sondeoFamilia.total };
    }
    return null;
};

/**
 * Pregunta al índice por una frase, en modo normal y sin gastar nada.
 *
 * Es la misma sonda barata del rescate del dictado: **sin agente** —así que no
 * cuesta un token de Bedrock—, **sin `sesionId`** —no escribe en el historial de
 * la conversación— y **sin hidratar** —no arrastra precios ni existencias—.
 *
 * @param {string} texto - Lo que se sondea.
 * @param {IProductSearch} params - Parámetros de búsqueda de la pantalla.
 * @param {ISearchHydrationContext} context - Cliente y sucursal.
 * @returns {Promise<ISondeoConsulta>} Si se pudo servir, y cuántos casan.
 */
const sondear = async (
    texto: string,
    params: IProductSearch,
    context: ISearchHydrationContext
): Promise<ISondeoConsulta> => {
    const r = await searchCatalogueProducts(
        {
            ...params,
            CadenaBusqueda: texto,
            MarcaIdProducto: undefined,
            FamiliaIdProducto: undefined,
            clasificacionId: undefined,
            CategoriaIdProducto: undefined,
            Paginado: { ...params.Paginado, Pagina: 1, RegistrosPagina: 1 },
        },
        context,
        undefined,
        SearchModeEnum.Normal,
        null,
        { skipHydration: true }
    );
    return { ok: r.ok, total: r.total };
};

/**
 * Resuelve con qué consulta abrir el catálogo para un turno del asistente.
 *
 * Gasta **una** sonda en el caso normal —la frase funciona— y **dos** cuando hay
 * que caer a la familia. Ninguna pasa por el agente.
 *
 * @param {string} frase - Lo que se envió al asistente.
 * @param {ISearchFacet[] | undefined} facets - Facetas de la respuesta.
 * @param {IProductSearch} params - Parámetros de búsqueda de la pantalla.
 * @param {ISearchHydrationContext} context - Cliente y sucursal.
 * @returns {Promise<IConsultaCatalogo | null>} Consulta y total, o `null`.
 */
export const resolverConsultaCatalogo = async (
    frase: string,
    facets: ISearchFacet[] | undefined,
    params: IProductSearch,
    context: ISearchHydrationContext
): Promise<IConsultaCatalogo | null> => {
    const limpio = frase.trim();
    // La consulta del servicio exige de 3 a 300 caracteres: por debajo responde
    // 400 y la sonda sería una petición tirada.
    if (limpio.length < 3) return null;

    const sondeoFrase = await sondear(limpio, params, context);
    if (sondeoFrase.ok && sondeoFrase.total > 0) {
        return elegirConsultaCatalogo(limpio, sondeoFrase);
    }

    const familia = familiaPrincipal(facets);
    if (!familia || familia.length < 3) return null;

    const sondeoFamilia = await sondear(familia, params, context);
    return elegirConsultaCatalogo(limpio, sondeoFrase, familia, sondeoFamilia);
};
