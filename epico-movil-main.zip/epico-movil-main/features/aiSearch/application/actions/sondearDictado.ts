import { ISondeo } from "@/features/aiSearch/domain/interfaces/IDictado";
import { IProductSearch } from "@/features/products/domain/interfaces/IProduct";
import { SearchModeEnum } from "@/features/products/domain/interfaces/ISearchProducts";
import {
    ISearchHydrationContext,
    searchCatalogueProducts,
} from "@/features/products/application/actions/searchCatalogueProducts";

/**
 * Preguntarle al índice si una frase nombra una marca que existe.
 *
 * Es la única parte impura del rescate, y es deliberadamente tonta: **aquí no vive
 * ninguna regla de decisión**. Recorre textos, pregunta y devuelve lo que le
 * dijeron. Quién decide qué se ofrece está en `ofertaRescate`.
 *
 * Por qué una sonda es barata, que es lo que hace todo esto defendible:
 *
 * - **`modo: normal`**, así que no interviene el agente: es una consulta al índice
 *   y no gasta ni un token de Bedrock;
 * - **sin `sesionId`**, así que no escribe en el historial de la conversación y no
 *   deja en Redis frases que el usuario no dijo;
 * - **un solo resultado y sin hidratar**, así que no arrastra la composición de
 *   precios ni de existencias.
 *
 * Aun así cargan al mismo microservicio que sirve el catálogo, y por eso hay tope
 * y corte temprano: el caso normal son **dos** peticiones, la de la frase enviada
 * y la de la primera candidata.
 */

/**
 * Sondea varias frases y devuelve qué dijo el servicio de cada una.
 *
 * Corta en cuanto una **candidata** —cualquiera menos la primera de la lista, que
 * es la frase que ya se envió— resulta reconocida con resultados: a partir de ahí
 * las demás no cambiarían la decisión.
 *
 * @param {string[]} textos - La frase enviada primero, y después las candidatas.
 * @param {IProductSearch} params - Parámetros de búsqueda de la pantalla.
 * @param {ISearchHydrationContext} context - Cliente y sucursal.
 * @returns {Promise<ISondeo[]>} Un resultado por texto sondeado, en orden.
 */
export const sondearDictado = async (
    textos: string[],
    params: IProductSearch,
    context: ISearchHydrationContext
): Promise<ISondeo[]> => {
    const sondeos: ISondeo[] = [];

    for (let i = 0; i < textos.length; i++) {
        const texto = textos[i];
        const resultado = await searchCatalogueProducts(
            {
                ...params,
                CadenaBusqueda: texto,
                MarcaIdProducto: undefined,
                FamiliaIdProducto: undefined,
                clasificacionId: undefined,
                CategoriaIdProducto: undefined,
                Paginado: { ...params.Paginado, Pagina: 1, RegistrosPagina: 1 },
            },
            context,
            undefined,
            SearchModeEnum.Normal,
            null,
            { skipHydration: true }
        );

        sondeos.push({
            texto,
            ok: resultado.ok,
            total: resultado.total,
            marcaDetectada: resultado.detectedBrand,
        });

        // La primera es la frase que ya se envió: esa se sondea siempre, porque sin
        // ella no se puede comparar sonda contra sonda.
        if (i > 0 && resultado.ok && resultado.detectedBrand && resultado.total > 0) break;
    }

    return sondeos;
};
