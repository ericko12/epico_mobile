import { ChatRoleEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
import { IChatMessage } from "@/features/aiSearch/domain/interfaces/IAiSearchState";

/**
 * A dónde se lleva la vista del hilo cuando algo cambia.
 *
 * El hilo bajaba siempre al final, también cuando lo que entraba era la
 * respuesta: con tarjetas, el texto de Ania queda muy por encima del fondo y el
 * vendedor tenía que subir a buscar dónde empezaba a leer. Visto en el teléfono.
 *
 * - `final`: el vendedor acaba de escribir o se espera respuesta. Tiene que ver
 *   su propio mensaje y los puntos de «buscando…».
 * - `mensaje`: acaba de entrar lo que dijo Ania. Se lee desde el principio.
 */
export type DestinoHilo =
    | { tipo: "final" }
    | { tipo: "mensaje"; id: string };

/**
 * Decide el destino con lo que hay ahora en el hilo.
 *
 * Es el **último** mensaje el que manda, no el que acaba de cambiar: así la
 * misma regla vale al abrir el panel con un hilo guardado y al abrir o cerrar el
 * teclado, que encoge el hilo pero no mueve el principio de la respuesta.
 *
 * @param {IChatMessage[]} messages - Hilo completo, del más antiguo al más reciente.
 * @param {boolean} loading - Si se está esperando respuesta.
 * @returns {DestinoHilo} Hasta dónde desplazar.
 */
export const destinoDelHilo = (messages: IChatMessage[], loading: boolean): DestinoHilo => {
    const ultimo = messages[messages.length - 1];
    if (loading || !ultimo || ultimo.rol !== ChatRoleEnum.Assistant) return { tipo: "final" };
    return { tipo: "mensaje", id: ultimo.id };
};
