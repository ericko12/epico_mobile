import { ChatRoleEnum, ContextoPreciosEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
import { IChatMessage, IContextoPrecios } from "@/features/aiSearch/domain/interfaces/IAiSearchState";
import { ICheckOut } from "@/features/checkout/domain/interfaces/checkOut/ICheckOut";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";

/**
 * De quién son los precios que enseña una tarjeta del hilo.
 *
 * El catálogo vuelve a buscar cuando el vendedor cambia de cliente
 * —`ProductCatalogue` lleva el `clienteId` en las dependencias de su efecto—, pero
 * el hilo del asistente no: vive en `sessionStorage` y sobrevive al cambio. Una
 * tarjeta de hace tres turnos sigue enseñando el precio, el precio tachado, la
 * existencia y la «P» de promoción del cliente con el que se buscó.
 *
 * El dinero no se equivoca —`ProductCard` revalida contra el cliente activo antes
 * de agregar—, pero **lo que el vendedor lee en voz alta sí**. Esto es lo que
 * decide cuándo avisarlo.
 */

/**
 * Rellenos que el proyecto guarda en `cliente` y que no son un nombre.
 *
 * `InitOrderSummary` deja literalmente `cliente: "NA"`, así que sin este filtro el
 * aviso diría «estos precios son de "NA"».
 */
const NOMBRES_DE_RELLENO = ["", "NA", "N/A"];

/**
 * Descarta los rellenos y devuelve un nombre utilizable, o nada.
 *
 * @param {string} [nombre] - Lo que venga en el campo.
 * @returns {string | undefined} El nombre limpio, o `undefined` si no sirve.
 */
const nombreUtilizable = (nombre?: string): string | undefined => {
    const limpio = nombre?.trim() ?? "";
    return NOMBRES_DE_RELLENO.includes(limpio.toUpperCase()) ? undefined : limpio;
};

/**
 * Reduce un identificador a lo que de verdad distingue una petición de otra.
 *
 * Dos motivos, los dos comprobados en el código y no supuestos:
 *
 * - **`undefined` y `0` son la misma sucursal.** `hydrateSearchProducts` pide la
 *   existencia con `SucursalId: branchId ?? 0`, así que un pedido sin sucursal de
 *   destino y otro con la cero preguntan exactamente lo mismo. Tratarlos como
 *   distintos avisaría de un cambio que nunca ocurrió.
 * - **`InitOrderSummary` deja `clienteId` y `sucursalIdDestino` en `NaN`**, y `??`
 *   no lo atrapa porque `NaN` no es nulo. Sin esta red, `NaN !== NaN` marcaría
 *   **todos** los mensajes del hilo para siempre sin que nada hubiera cambiado, y
 *   el fallo sería mudo. Ese objeto hoy no llega a ser el pedido activo —el estado
 *   arranca en `null`—, pero es la clase de detalle que un `spread` reintroduce.
 *   `NaN` tampoco sobrevive a `JSON.stringify`: se persistiría como `null`.
 *
 * @param {number} [valor] - El identificador tal como viene del pedido.
 * @returns {number} El identificador, o `0` si no es un número utilizable.
 */
const identificador = (valor?: number): number => (Number.isFinite(valor) ? (valor as number) : 0);

/**
 * Cliente con el que el catálogo pide precios cuando no hay caja activa y se entró
 * desde el menú: el mostrador. Es la misma regla que `ProductCatalogue`, el detalle y
 * `ProductCard` (`clienteId ?? (sourceFromMenu ? 1 : 0)`).
 *
 * ⚠️ El chat no la tenía y mandaba siempre `0`, y el servicio de precios dejó de
 * aceptarlo: «Entidad ClienteId (0) no encontrada», con todas las tarjetas sin precio.
 * Visto en producción el 16-oct-2026.
 */
const CLIENTE_MOSTRADOR = Number(process.env.NEXT_PUBLIC_CLIENTE_MOSTRADOR) || 1;

/**
 * Congela el contexto con el que se va a hidratar un turno.
 *
 * **Es el único sitio donde se normaliza**, y lo usan tanto quien sella como quien
 * compara: así no pueden discrepar. Devuelve el mismo `clienteId ?? 0` que viaja a
 * la hidratación; si el sello guardara `undefined` donde la búsqueda usó `0`, la
 * comparación mentiría en cuanto no hubiera pedido activo.
 *
 * @param {IOrderSummary | null} [orderSummary] - Pedido activo.
 * @param {ICheckOut[]} [checkOutList] - Cajas abiertas, de donde se rescata el
 * nombre cuando el del pedido viene vacío o de relleno: `ICheckOut.cliente` es
 * obligatorio y `IOrderSummary.cliente` no.
 * @param {boolean} [desdeMenu] - Se entró al catálogo desde el menú. Sin caja activa,
 * se pide con el cliente mostrador, como hace el catálogo.
 * @returns {IContextoPrecios} Contexto listo para pedir y para sellar.
 */
export const sellarContextoPrecios = (
    orderSummary?: IOrderSummary | null,
    checkOutList?: ICheckOut[],
    desdeMenu = false,
): IContextoPrecios => {
    const delPedido = identificador(orderSummary?.clienteId);
    // Se sella el mismo que viaja: si el sello dijera 0 y se pidiera con el
    // mostrador, el aviso de "precios de otro cliente" compararía otra cosa.
    if (delPedido === 0 && desdeMenu) {
        return {
            clienteId: CLIENTE_MOSTRADOR,
            sucursalId: identificador(orderSummary?.sucursalIdDestino),
            clienteNombre: "cliente mostrador",
        };
    }
    const clienteId = delPedido;
    // Sin cliente no se busca nombre: un `find` sobre `clienteId === 0`
    // engancharía cualquier caja mal formada.
    const deLaCaja = clienteId === 0
        ? undefined
        : nombreUtilizable(checkOutList?.find((caja) => caja.clienteId === clienteId)?.cliente);
    return {
        clienteId,
        sucursalId: identificador(orderSummary?.sucursalIdDestino),
        clienteNombre: nombreUtilizable(orderSummary?.cliente) ?? deLaCaja,
    };
};

/**
 * Compara el sello de un mensaje contra el contexto de ahora.
 *
 * @param {IContextoPrecios} [sello] - Con qué se hidrató. `undefined` en los hilos
 * anteriores a este cambio.
 * @param {IContextoPrecios} actual - Cliente y sucursal del pedido activo.
 * @returns {ContextoPreciosEnum} Qué habría que avisar.
 */
export const evaluarContextoPrecios = (
    sello: IContextoPrecios | undefined,
    actual: IContextoPrecios,
): ContextoPreciosEnum => {
    if (!sello) return ContextoPreciosEnum.Desconocido;
    // El cliente manda: si cambió, caducan precio, promociones y existencia a la
    // vez, y su aviso ya los nombra los dos. Por eso no hay un quinto estado para
    // «cambiaron los dos»: no tendría texto propio.
    if (identificador(sello.clienteId) !== identificador(actual.clienteId)) {
        return ContextoPreciosEnum.OtroCliente;
    }
    // Normalizado también aquí, y no solo al sellar: un sello guardado por otra
    // versión, o armado a mano en una prueba, no tiene por qué venir limpio.
    if (identificador(sello.sucursalId) !== identificador(actual.sucursalId)) {
        return ContextoPreciosEnum.OtraSucursal;
    }
    return ContextoPreciosEnum.Vigente;
};

/**
 * Qué aviso le toca a un mensaje del hilo.
 *
 * Las dos primeras guardas son lo que evita que el hilo se llene de cajas al
 * cambiar de caja: una burbuja del vendedor y un turno de solo texto no afirman
 * ningún precio, y un aviso que sale casi siempre enseña a desconfiar del
 * asistente. Es la misma regla que ya sigue el hilo con la marca detectada: lo
 * normal no se anuncia.
 *
 * @param {IChatMessage} message - Mensaje del hilo.
 * @param {IContextoPrecios} actual - Contexto vigente.
 * @returns {ContextoPreciosEnum} Qué avisar, o `Vigente` si no hay nada.
 */
export const avisoDeMensaje = (
    message: IChatMessage,
    actual: IContextoPrecios,
): ContextoPreciosEnum => {
    if (message.rol !== ChatRoleEnum.Assistant) return ContextoPreciosEnum.Vigente;
    if (!message.productos?.length) return ContextoPreciosEnum.Vigente;
    return evaluarContextoPrecios(message.contextoPrecios, actual);
};

/**
 * El texto del aviso, o `null` si no hay que pintar ninguno.
 *
 * Se arma en dos mitades —de quién son las cifras y qué hacer— porque la segunda
 * depende del pedido de **ahora** y no del sello: se puede cerrar la última caja y
 * quedarse sin ningún cliente activo, y ahí «el cliente de ahora» no existe.
 *
 * No promete que «al agregar se recalculan»: `ProductCard` apaga el botón cuando
 * el `sinPrecio` congelado dice que no había precio, y ese defecto no se arregla
 * aquí. Lo que sí es verdad en todos los casos es volver a preguntar.
 *
 * @param {ContextoPreciosEnum} aviso - Lo que devolvió `avisoDeMensaje`.
 * @param {IContextoPrecios} actual - El contexto vigente, para saber si hay
 * cliente al que referirse.
 * @param {IContextoPrecios} [sello] - El sello del mensaje, para nombrar al cliente.
 * @returns {string | null} El texto, o `null` si no se pinta nada.
 */
export const textoAvisoContexto = (
    aviso: ContextoPreciosEnum,
    actual: IContextoPrecios,
    sello?: IContextoPrecios,
): string | null => {
    // Cambió la sucursal y no el cliente: caduca la existencia, no el precio.
    // Decirlo al revés sería mentir con la misma caja que pide confianza.
    if (aviso === ContextoPreciosEnum.OtraSucursal) {
        return "Estas existencias son de otra sucursal; los precios sí son de este cliente. Vuelve a preguntarme para verlas al día.";
    }
    if (aviso !== ContextoPreciosEnum.OtroCliente) return null;

    // No había cliente: eran precios de lista. Decir «de otro cliente» sería
    // inventarse uno.
    const deQuienSon = sello?.clienteId === 0
        ? "Estos precios y existencias son de una búsqueda sin cliente."
        : sello?.clienteNombre
            ? `Estos precios y existencias son de «${sello.clienteNombre}».`
            : "Estos precios y existencias son de otro cliente.";

    // Sin pedido activo no hay «cliente de ahora» al que remitir: cerrar la última
    // caja deja `selectedOrderSummary` en `null`.
    const queHacer = identificador(actual.clienteId) === 0
        ? "Vuelve a preguntarme para verlos al día."
        : "Vuelve a preguntarme para verlos con el cliente de ahora.";

    return `${deQuienSon} ${queHacer}`;
};
