import {
    ICandidataDictado,
    IDictado,
    IOfertaRescate,
    IPlanRescate,
    ISondeo,
} from "@/features/aiSearch/domain/interfaces/IDictado";
import { ConfirmacionEnum, MotivoOfertaEnum } from "@/features/aiSearch/domain/enums/DictadoEnums";
import {
    CONFIRMACIONES_NO,
    CONFIRMACIONES_SI,
    OFERTA_TTL_MS,
} from "@/features/aiSearch/domain/data/dictado.data";
import { normalizarComparacion } from "@/features/aiSearch/application/actions/dictadoHipotesis";
import { elegirCandidatas } from "@/features/aiSearch/application/actions/candidatosDictado";
import { localizarMarcaDicha } from "@/features/aiSearch/application/actions/marcaDictada";

/**
 * Decidir si hay algo que ofrecer, y leer la respuesta del usuario.
 *
 * Aquí no hay ningún umbral que calibrar. La pregunta «¿esta palabra es una marca
 * del catálogo?» **no se responde en el cliente**: se le hace al servicio, que
 * tiene el índice completo. Y la pregunta «¿la cambio?» se le hace al usuario. El
 * cliente solo decide a quién preguntar y en qué orden.
 */

/** Lo que hace falta saber del turno para decidir si se rescata. */
export interface IEntradaRescate {
    /** Lo que entregó el reconocedor, ya prefijado. `null` si el turno fue escrito. */
    dictado?: IDictado | null;
    /** La frase que de verdad viajó al servicio. */
    textoEnviado: string;
    /** Si el turno entró por el micrófono. */
    porVoz: boolean;
    /** Si la bandera de ambiente permite gastar sondas. */
    rescateActivo: boolean;
    /** Si el servicio pudo servir la búsqueda. */
    ok: boolean;
    /** Cuántos productos devolvió. */
    total: number;
    /** La marca que el servicio reconoció, si reconoció alguna. */
    marcaDetectada: string | null;
}

/**
 * Decide si hay que sondear, y qué.
 *
 * Devuelve `null` —cero peticiones, cero coste— en todos estos casos, que son la
 * inmensa mayoría de los turnos:
 *
 * - la bandera está apagada;
 * - el turno se escribió a mano (lo escrito se escribió a propósito y no se toca
 *   nunca);
 * - el servicio falló: sondear contra un servicio que ya dijo que no es tirar
 *   peticiones, y la candidata fallaría igual;
 * - **el servicio reconoció la marca**: el turno funcionó, no hay nada que
 *   rescatar. Aquí es donde «GM» deja de correr peligro de convertirse en «GMB»;
 * - no se nombró ninguna marca.
 *
 * Cuando sí devuelve un plan, `candidatas` puede venir vacío: entonces tampoco se
 * gasta ninguna petición, y lo único que queda es pedir el deletreo o que la
 * escriba.
 *
 * @param {IEntradaRescate} entrada - El turno que acaba de terminar.
 * @returns {IPlanRescate | null} Qué sondear, o `null` si no hay nada que hacer.
 */
export const planearRescate = (entrada: IEntradaRescate): IPlanRescate | null => {
    if (!entrada.rescateActivo) return null;
    if (!entrada.porVoz || !entrada.dictado) return null;
    if (!entrada.ok) return null;
    if (entrada.marcaDetectada) return null;

    const marca = localizarMarcaDicha(entrada.textoEnviado);
    if (!marca) return null;

    const motivo = entrada.total === 0
        ? MotivoOfertaEnum.SinResultados
        // Devolvió cosas, pero de cualquier marca: parecen buenos resultados y no
        // lo son, que es peor que no devolver nada.
        : MotivoOfertaEnum.MarcaNoReconocida;

    return {
        motivo,
        marca,
        candidatas: elegirCandidatas(entrada.dictado, entrada.textoEnviado, marca),
    };
};

/**
 * Decide si una sonda aprobó alguna candidata.
 *
 * Dos reglas, y las dos son restricciones, no facilidades:
 *
 * - **Se compara sonda contra sonda, las dos en modo normal.** Comparar el `total`
 *   de una sonda contra el de un turno de IA sería tomar por evidencia sobre *el
 *   texto* algo que es evidencia sobre *el modo*, y dispararía el rescate sobre
 *   transcripciones correctas que el agente simplemente no supo contestar.
 * - **Más resultados no es evidencia.** Se exige que la candidata haga que el
 *   servicio **reconozca una marca** donde antes no reconocía ninguna. Perder la
 *   marca *ensancha* la búsqueda: «focos de la marca QH» sin marca devuelve miles,
 *   así que aceptar por conteo premiaría exactamente el fallo que se quiere
 *   arreglar.
 *
 * @param {ICandidataDictado[]} candidatas - Las que se sondearon.
 * @param {MotivoOfertaEnum} motivo - Por qué se está rescatando.
 * @param {string} textoAnterior - La frase que se envió y no funcionó.
 * @param {ISondeo} sondaPrincipal - La sonda de la frase enviada.
 * @param {ISondeo[]} sondasCandidatas - Las sondas de las candidatas.
 * @param {number} ahora - Marca de tiempo, para poder caducar la oferta.
 * @returns {IOfertaRescate | null} La oferta, o `null` si ninguna candidata pasó.
 */
export const decidirOferta = (
    candidatas: ICandidataDictado[],
    motivo: MotivoOfertaEnum,
    textoAnterior: string,
    sondaPrincipal: ISondeo,
    sondasCandidatas: ISondeo[],
    ahora: number
): IOfertaRescate | null => {
    if (!sondaPrincipal.ok) return null;
    // El índice sí reconoce la marca en la frase original: la transcripción estaba
    // bien y el fallo fue del agente. Ofrecer una sustitución aquí sería absurdo.
    if (sondaPrincipal.marcaDetectada) return null;

    for (const sonda of sondasCandidatas) {
        if (!sonda.ok || !sonda.marcaDetectada || sonda.total <= 0) continue;
        const candidata = candidatas.find((c) => c.texto === sonda.texto);
        if (!candidata) continue;
        return {
            textoAnterior,
            textoNuevo: candidata.texto,
            palabraAntes: candidata.palabraAntes,
            palabraDespues: candidata.palabraDespues,
            total: sonda.total,
            motivo,
            creada: ahora,
        };
    }

    return null;
};

/**
 * ¿Sigue viva una oferta?
 *
 * @param {IOfertaRescate | null} oferta - La oferta pendiente.
 * @param {number} ahora - Marca de tiempo actual.
 * @returns {boolean} `true` si todavía se puede aceptar.
 */
export const ofertaVigente = (oferta: IOfertaRescate | null, ahora: number): boolean =>
    !!oferta && ahora - oferta.creada <= OFERTA_TTL_MS;

/**
 * Lee un «sí» o un «no» dicho en voz alta.
 *
 * El vocabulario es **cerrado y corto** a propósito, y esa es la clave de que la
 * confirmación hablada sea segura donde reconocer un nombre de marca no lo es: se
 * resuelve en el dispositivo, comparando la frase completa contra dos listas, y su
 * peor caso es «no me oyó, no pasa nada». Cualquier otra cosa devuelve `Nada`, la
 * oferta se descarta en silencio y lo dictado se trata como un turno nuevo: el
 * usuario **nunca** queda atrapado en un diálogo de confirmación.
 *
 * @param {string} texto - Lo que se dictó.
 * @returns {ConfirmacionEnum} Sí, no, o ninguna de las dos.
 */
export const leerConfirmacion = (texto: string): ConfirmacionEnum => {
    const dicho = normalizarComparacion(texto);
    if (!dicho) return ConfirmacionEnum.Nada;
    if (CONFIRMACIONES_SI.some((f) => normalizarComparacion(f) === dicho)) return ConfirmacionEnum.Si;
    if (CONFIRMACIONES_NO.some((f) => normalizarComparacion(f) === dicho)) return ConfirmacionEnum.No;
    return ConfirmacionEnum.Nada;
};
