import { IDictado } from "@/features/aiSearch/domain/interfaces/IDictado";
import { ModoDictadoEnum } from "@/features/aiSearch/domain/enums/DictadoEnums";
import { MAX_HIPOTESIS } from "@/features/aiSearch/domain/data/dictado.data";

/**
 * Componer lo que el reconocedor entregó, y las herramientas de texto que el
 * resto del rescate reutiliza.
 *
 * El reconocedor no entrega una frase: entrega una lista de **segmentos**, y cada
 * segmento trae sus propias hipótesis ordenadas de mejor a peor. Hasta ahora solo
 * se leía la primera de cada uno y las demás se tiraban. Aquí se componen las
 * frases completas sin cambiar en nada la principal, que sigue siendo, byte a
 * byte, lo que se envía.
 */

/** Signos que se quitan de los bordes de una palabra antes de compararla. */
const SIGNOS = "¿?¡!.,;:«»“”\"'()[]{}…";

/**
 * Un token de la frase, con las dos caras que hacen falta: la que se enseña y la
 * que se compara.
 *
 * @interface IToken
 */
export interface IToken {
    /** Tal como se dijo, sin los signos de los bordes. Es lo que se le enseña. */
    crudo: string;
    /** En minúsculas y sin acentos. Es lo que se compara. */
    normal: string;
}

/**
 * Quita los signos de los bordes de una palabra.
 *
 * @param {string} t - Palabra cruda.
 * @returns {string} La palabra sin signos alrededor.
 */
const limpiarBordes = (t: string): string => {
    let a = 0;
    let b = t.length;
    while (a < b && SIGNOS.includes(t[a])) a++;
    while (b > a && SIGNOS.includes(t[b - 1])) b--;
    return t.slice(a, b);
};

/**
 * Forma canónica para comparar dos textos.
 *
 * Sin ella, «marca QBH» y «marca qbh» se tomarían por frases distintas y se
 * sondearían las dos, o «Pregunté» y «Pregunte» impedirían ver que una
 * alternativa es la misma frase de siempre.
 *
 * @param {string} s - Texto de entrada.
 * @returns {string} Minúsculas, sin acentos y con los espacios colapsados.
 */
export const normalizarComparacion = (s: string): string =>
    (s ?? "")
        .normalize("NFD")
        // Los diacríticos que `NFD` acaba de separar, por código: escritos como
        // caracteres sueltos en el fuente son invisibles y se pierden al editar.
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .replace(/\s+/g, " ")
        .trim();

/**
 * Parte una frase en tokens comparables.
 *
 * @param {string} texto - La frase.
 * @returns {IToken[]} Un token por palabra, sin los vacíos.
 */
export const tokenizar = (texto: string): IToken[] =>
    (texto ?? "")
        .split(/\s+/)
        .map((t) => limpiarBordes(t))
        .filter((t) => t.length > 0)
        .map((t) => ({ crudo: t, normal: normalizarComparacion(t) }));

/**
 * Sustituye una palabra de la frase conservando todo lo demás.
 *
 * Respeta los signos de los bordes: en «¿tienes focos de la marca QH?» la palabra
 * que se cambia es `QH`, y el signo de cierre se queda donde estaba.
 *
 * @param {string} texto - La frase original.
 * @param {number} indice - Índice de la palabra a sustituir, contando desde cero.
 * @param {string} nueva - La palabra que entra.
 * @returns {string} La frase con la palabra sustituida.
 */
export const sustituirToken = (texto: string, indice: number, nueva: string): string => {
    let i = -1;
    return (texto ?? "").replace(/\S+/g, (m) => {
        i += 1;
        if (i !== indice) return m;
        const limpio = limpiarBordes(m);
        const corte = m.indexOf(limpio);
        const pre = corte >= 0 ? m.slice(0, corte) : "";
        const post = corte >= 0 ? m.slice(corte + limpio.length) : "";
        return `${pre}${nueva}${post}`;
    });
};

/**
 * Compone la frase principal y las alternativas a partir de los segmentos.
 *
 * **La principal no se toca.** Se compone concatenando la hipótesis `[0]` de cada
 * segmento sin separador, que es exactamente lo que hacía el hook antes de que
 * existiera este mecanismo; hay una prueba que lo fija como invariante, porque de
 * eso depende que subir `maxAlternatives` no cambie lo que se envía.
 *
 * Las alternativas se generan variando **un segmento a la vez** y recorriendo por
 * profundidad, para respetar el orden de preferencia del reconocedor. No se hace
 * el producto cartesiano: tres segmentos por cinco hipótesis son ciento
 * veinticinco frases, casi todas ruido, y cada una costaría una petición.
 *
 * `confidence` no se usa para nada, a propósito: en la ruta de reconocimiento en
 * dispositivo está cableado a 1.0, y en la de red el navegador rellena ese hueco
 * con la **estabilidad** del resultado provisional cuando el servicio no manda
 * confianza. Y los dos errores que originaron todo esto —«QH» y «Kuhn»— son
 * errores de un reconocedor **confiado**: un umbral los habría dejado pasar.
 *
 * @param {string[][]} segmentos - Una fila por resultado final, con sus hipótesis.
 * @param {ModoDictadoEnum} modo - Habla libre o deletreo.
 * @param {number} [maxHipotesis] - Cuántas alternativas se conservan.
 * @returns {IDictado} La principal, las alternativas y el modo.
 */
export const construirHipotesis = (
    segmentos: string[][],
    modo: ModoDictadoEnum = ModoDictadoEnum.Libre,
    maxHipotesis: number = MAX_HIPOTESIS
): IDictado => {
    const filas = (segmentos ?? []).map((f) => f ?? []);
    const texto = filas.map((f) => f[0] ?? "").join("").trim();

    const vistas = new Set<string>([normalizarComparacion(texto)]);
    const alternativas: string[] = [];
    const profundidad = filas.reduce((m, f) => Math.max(m, f.length), 0);

    for (let d = 1; d < profundidad; d++) {
        for (let i = 0; i < filas.length; i++) {
            const otra = filas[i][d];
            if (otra === undefined) continue;
            const compuesta = filas
                .map((f, j) => (j === i ? otra : f[0] ?? ""))
                .join("")
                .trim();
            const clave = normalizarComparacion(compuesta);
            if (!clave || vistas.has(clave)) continue;
            vistas.add(clave);
            alternativas.push(compuesta);
            if (alternativas.length >= maxHipotesis) return { texto, alternativas, modo };
        }
    }

    return { texto, alternativas, modo };
};

/**
 * Añade delante lo que el usuario ya tenía escrito.
 *
 * Hace falta porque el hueco de la marca se localiza sobre **el texto que
 * viajó**, y ese texto es lo escrito más lo dictado. Sin prefijar las
 * alternativas, compararlas contra la frase enviada daría siempre distinto número
 * de palabras y ninguna llegaría a candidata.
 *
 * @param {IDictado} dictado - Lo que entregó el reconocedor.
 * @param {string} prefijo - Lo que había escrito en el compositor.
 * @returns {IDictado} El mismo dictado con el prefijo puesto en todas las frases.
 */
export const prefijarDictado = (dictado: IDictado, prefijo: string): IDictado => {
    const p = (prefijo ?? "").trim();
    if (!p) return dictado;
    return {
        texto: `${p} ${dictado.texto}`.trim(),
        alternativas: dictado.alternativas.map((a) => `${p} ${a}`.trim()),
        modo: dictado.modo,
    };
};
