import { ICandidataDictado, IDictado, IMarcaDicha } from "@/features/aiSearch/domain/interfaces/IDictado";
import {
    MAX_CANDIDATAS,
    MAX_PALABRAS_NOMBRE_LETRA,
    MAX_SIMBOLOS_DELETREO,
    MIN_SIMBOLOS_DELETREO,
    NOMBRES_LETRA,
} from "@/features/aiSearch/domain/data/dictado.data";
import {
    normalizarComparacion,
    tokenizar,
} from "@/features/aiSearch/application/actions/dictadoHipotesis";
import {
    SEARCH_MAX_MESSAGE_LENGTH,
    SEARCH_MIN_QUERY_LENGTH,
} from "@/features/products/domain/data/searchProducts.config";

/**
 * Decidir qué frases merecen que se le pregunte al servicio, y recomponer un
 * acrónimo deletreado.
 *
 * Las dos funciones comparten una propiedad que es la que hace todo esto seguro:
 * **nunca inventan una palabra**. Una candidata es siempre una hipótesis que el
 * propio reconocedor produjo, o el acrónimo que componen las letras que el usuario
 * dictó cuando se le pidió deletrear. No hay diccionario, no hay distancia de
 * edición sobre nombres de marca y no hay alias escritos a mano, así que es
 * imposible que aparezca una marca que nadie mencionó.
 *
 * Por qué no hay distancia de edición: los acrónimos del sector viven casi todos
 * en dos y tres letras —SKF, NTN, NGK, TRW, KYB, LTH, GMB, LUK, QBH, QH— y una
 * sola edición separa a cualquiera de las otras. Cualquier métrica calibrada para
 * acertar «QH» → «QBH» abre todas esas colisiones a la vez.
 */

/**
 * Elige las alternativas que se van a sondear.
 *
 * Las cuatro condiciones son acumulativas, y cada una tapa un fallo concreto:
 *
 * 1. **Difiere en exactamente un token.** Sin esto, una alternativa que cambia el
 *    modelo, el lado o la medida se ofrecería etiquetada como corrección de marca.
 * 2. **Ese token es el de la marca.** Es el único hueco de la frase donde una
 *    sustitución es defendible.
 * 3. **Ningún token con cifras.** Los dígitos son lo que el reconocedor más falla,
 *    y «Aveo 2012» → «Aveo 2010» ofrecido con un conteo tranquilizador son balatas
 *    del año equivocado: eso no es un error de catálogo, es un freno mal surtido.
 * 4. **La longitud cabe en el contrato del servicio.** Se comprueba **antes** de
 *    gastar la petición, porque por debajo de tres caracteres el servicio devuelve
 *    400 y la candidata se evaporaría sin dejar señal.
 *
 * @param {IDictado} dictado - Lo que entregó el reconocedor, ya prefijado con lo
 * que hubiera escrito el usuario.
 * @param {string} textoEnviado - La frase que de verdad viajó al servicio.
 * @param {IMarcaDicha} marca - El hueco de la marca dentro de esa frase.
 * @param {number} [max] - Cuántas candidatas como máximo.
 * @returns {ICandidataDictado[]} Las candidatas, en el orden de preferencia del
 * reconocedor. Puede venir vacío, y a menudo viene vacío.
 */
export const elegirCandidatas = (
    dictado: IDictado,
    textoEnviado: string,
    marca: IMarcaDicha,
    max: number = MAX_CANDIDATAS
): ICandidataDictado[] => {
    const base = tokenizar(textoEnviado);
    const elegidas: ICandidataDictado[] = [];
    const vistas = new Set<string>([normalizarComparacion(textoEnviado)]);

    for (const alternativa of dictado.alternativas ?? []) {
        if (elegidas.length >= max) break;

        const texto = (alternativa ?? "").trim();
        if (texto.length < SEARCH_MIN_QUERY_LENGTH || texto.length > SEARCH_MAX_MESSAGE_LENGTH) continue;

        const clave = normalizarComparacion(texto);
        if (!clave || vistas.has(clave)) continue;

        const otros = tokenizar(texto);
        if (otros.length !== base.length) continue;

        const distintos: number[] = [];
        for (let i = 0; i < base.length; i++) {
            if (base[i].normal !== otros[i].normal) distintos.push(i);
        }
        if (distintos.length !== 1) continue;

        const i = distintos[0];
        if (i !== marca.indice) continue;
        if (/\d/.test(otros[i].crudo) || /\d/.test(base[i].crudo)) continue;

        vistas.add(clave);
        elegidas.push({
            texto,
            palabraAntes: base[i].crudo,
            palabraDespues: otros[i].crudo,
        });
    }

    return elegidas;
};

/**
 * Recompone el acrónimo que el usuario acaba de deletrear.
 *
 * ⚠️ **Solo se llama en `ModoDictadoEnum.Deletreo`**, es decir, sobre un enunciado
 * que el propio asistente pidió como deletreo. Esa puerta es lo que hace
 * estructuralmente imposible toda una clase de falsos positivos: en habla libre,
 * «focos de ese lado» se convertiría en «DS» y «el balero cinco cinco» en «55»,
 * porque en español los nombres de letra y de dígito son palabras corrientes.
 *
 * Acepta las tres formas con las que la gente deletrea de verdad: nombres de letra
 * («cu be hache»), letras sueltas («Q B H») y mezclas. Los nombres de varias
 * palabras se casan antes que los de una, para que «be grande» no se lea como «B»
 * seguido de la palabra «grande».
 *
 * En cuanto un token no es un nombre de letra ni un símbolo suelto, devuelve
 * `null`: es mejor decir «no la pillé» que recomponer media marca.
 *
 * @param {string} texto - Lo que se dictó en modo deletreo.
 * @returns {string | null} El acrónimo en mayúsculas, o `null` si no era un
 * deletreo.
 */
export const reconstruirDeletreo = (texto: string): string | null => {
    const tokens = tokenizar(texto).map((t) => t.normal);
    if (!tokens.length) return null;

    const simbolos: string[] = [];
    let i = 0;

    while (i < tokens.length) {
        let casado = false;

        // De más palabras a menos: «doble u» antes que «doble».
        for (let n = Math.min(MAX_PALABRAS_NOMBRE_LETRA, tokens.length - i); n >= 1; n--) {
            const frase = tokens.slice(i, i + n).join(" ");
            const letra = NOMBRES_LETRA[frase];
            if (letra) {
                simbolos.push(letra);
                i += n;
                casado = true;
                break;
            }
        }
        if (casado) continue;

        // Una letra o una cifra dicha suelta: el reconocedor a veces las entrega ya
        // como símbolo, sobre todo cuando se deletrea despacio.
        const token = tokens[i];
        if (token.length === 1 && /[a-z0-9]/.test(token)) {
            simbolos.push(token.toUpperCase());
            i += 1;
            continue;
        }

        return null;
    }

    if (simbolos.length < MIN_SIMBOLOS_DELETREO || simbolos.length > MAX_SIMBOLOS_DELETREO) return null;
    return simbolos.join("");
};
