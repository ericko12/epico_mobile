import { AnyAction, Draft, PayloadAction, createSlice } from "@reduxjs/toolkit";
import { REHYDRATE } from "redux-persist";
import {
    IAiSearchState,
    IAniaPosition,
    IChatMessage,
    IConsultaCatalogo,
} from "@/features/aiSearch/domain/interfaces/IAiSearchState";

/**
 * Cuántos mensajes se conservan en el hilo.
 *
 * Acota el crecimiento del estado, que se cifra completo en `sessionStorage` en
 * cada escritura. Muy por encima de lo que dura una conversación real (el
 * historial del servidor caduca a los 20 minutos).
 */
const MAX_MESSAGES = 40;

/**
 * Estado del asistente Ania.
 */
export const aiSearchSlice = createSlice({
    name: "aiSearch",
    initialState: {
        isOpen: false,
        isLoading: false,
        sessionId: null,
        messages: [],
        greetingDismissed: false,
        position: null,
        assistantName: null,
        vozActiva: true,
    } as IAiSearchState,
    reducers: {
        /**
         * Abre o cierra el panel del chat.
         *
         * @param state - Estado actual.
         * @param payload - `true` para abrir.
         */
        setChatOpen: (state: Draft<IAiSearchState>, { payload }: PayloadAction<boolean>) => {
            state.isOpen = payload;
            // Abrir el chat es haber visto el saludo: si no, al cerrar volvería a
            // aparecer el globo de presentación como si fuera la primera vez.
            if (payload) state.greetingDismissed = true;
        },
        /**
         * Marca el saludo como visto sin abrir el chat.
         *
         * @param state - Estado actual.
         */
        dismissGreeting: (state: Draft<IAiSearchState>) => {
            state.greetingDismissed = true;
        },
        /**
         * Enciende o apaga el indicador de espera.
         *
         * @param state - Estado actual.
         * @param payload - `true` mientras se espera al servicio.
         */
        setChatLoading: (state: Draft<IAiSearchState>, { payload }: PayloadAction<boolean>) => {
            state.isLoading = payload;
        },
        /**
         * Guarda el identificador de la conversación.
         *
         * @param state - Estado actual.
         * @param payload - `sesionId` devuelto por el servicio.
         */
        setChatSession: (state: Draft<IAiSearchState>, { payload }: PayloadAction<string | null>) => {
            state.sessionId = payload;
        },
        /**
         * Añade un mensaje al final del hilo.
         *
         * @param state - Estado actual.
         * @param payload - Mensaje a añadir.
         */
        addChatMessage: (state: Draft<IAiSearchState>, { payload }: PayloadAction<IChatMessage>) => {
            state.messages.push(payload);
            if (state.messages.length > MAX_MESSAGES) {
                state.messages.splice(0, state.messages.length - MAX_MESSAGES);
            }
        },
        /**
         * Guarda con qué frase abrir el catálogo desde un turno ya pintado.
         *
         * Va aparte del mensaje porque **se resuelve después**: preguntarle al
         * índice antes de pintar la respuesta le sumaría medio segundo a una
         * espera que ya son cinco, y el botón no es lo primero que se mira. Si el
         * mensaje ya no está —el hilo se vació mientras se sondeaba— no pasa nada.
         *
         * @param state - Estado actual.
         * @param payload - Id del mensaje y la consulta resuelta.
         */
        setChatMessageCatalogo: (
            state: Draft<IAiSearchState>,
            { payload }: PayloadAction<{ id: string; catalogo: IConsultaCatalogo }>
        ) => {
            const mensaje = state.messages.find((m) => m.id === payload.id);
            if (mensaje) mensaje.catalogo = payload.catalogo;
        },
        /**
         * Vacía la conversación y empieza una nueva.
         *
         * @param state - Estado actual.
         */
        resetChat: (state: Draft<IAiSearchState>) => {
            state.messages = [];
            state.sessionId = null;
            state.isLoading = false;
        },
        /**
         * Guarda dónde dejó el usuario el robot.
         *
         * @param state - Estado actual.
         * @param payload - Distancias a las esquinas derecha e inferior.
         */
        setAniaPosition: (state: Draft<IAiSearchState>, { payload }: PayloadAction<IAniaPosition>) => {
            state.position = payload;
        },
        /**
         * Guarda el nombre con el que el servicio presenta al asistente.
         *
         * @param state - Estado actual.
         * @param payload - Nombre devuelto por el servicio.
         */
        setAssistantName: (state: Draft<IAiSearchState>, { payload }: PayloadAction<string>) => {
            state.assistantName = payload;
        },
        /**
         * Enciende o apaga la voz de Ania.
         *
         * @param state - Estado actual.
         * @param payload - `true` para que conteste hablando.
         */
        setVozActiva: (state: Draft<IAiSearchState>, { payload }: PayloadAction<boolean>) => {
            state.vozActiva = payload;
        },
    },
    extraReducers: (builder) => {
        // `isLoading` es transitoria y el estado se persiste completo: si la app
        // muere mientras se espera un turno del agente —cinco segundos son mucho
        // en datos móviles—, la bandera reviviría en `true` al rehidratar y el chat
        // se quedaría con los tres puntos girando para siempre. Es la misma lección
        // que ya costó una corrección en `ProductSlice`.
        builder.addCase(REHYDRATE, (state, action: AnyAction) => {
            const incoming = action.payload?.aiSearchState as IAiSearchState | undefined;
            if (!incoming) return state;
            return { ...state, ...incoming, isLoading: false };
        });
    },
});

export const {
    setChatOpen,
    setChatMessageCatalogo,
    dismissGreeting,
    setChatLoading,
    setChatSession,
    addChatMessage,
    resetChat,
    setAniaPosition,
    setAssistantName,
    setVozActiva,
} = aiSearchSlice.actions;

export default aiSearchSlice.reducer;
