/* eslint-disable @typescript-eslint/no-unsafe-function-type */
import { IChatMessage, IAniaPosition, IConsultaCatalogo } from "@/features/aiSearch/domain/interfaces/IAiSearchState";
import {
    addChatMessage,
    setChatMessageCatalogo,
    dismissGreeting,
    resetChat,
    setAniaPosition,
    setAssistantName,
    setVozActiva,
    setChatLoading,
    setChatOpen,
    setChatSession,
} from "@/features/aiSearch/application/redux/aiSearchSlice";

/**
 * Thunks del asistente.
 *
 * Siguen el molde del proyecto: una fábrica `async` que devuelve otra función
 * `async` que recibe `dispatch`, y se invocan con doble `await`
 * (`await dispatch(await abrirChat(true))`).
 */

/**
 * Abre o cierra el panel del chat.
 *
 * @param {boolean} open - `true` para abrir.
 * @returns Thunk.
 */
export const toggleChatThunk = async (open: boolean) => {
    return async (dispatch: Function) => {
        await dispatch(setChatOpen(open));
    };
};

/**
 * Marca el saludo como visto sin abrir el chat.
 *
 * @returns Thunk.
 */
export const dismissGreetingThunk = async () => {
    return async (dispatch: Function) => {
        await dispatch(dismissGreeting());
    };
};

/**
 * Enciende o apaga el indicador de espera.
 *
 * @param {boolean} loading - `true` mientras se espera al servicio.
 * @returns Thunk.
 */
export const setChatLoadingThunk = async (loading: boolean) => {
    return async (dispatch: Function) => {
        await dispatch(setChatLoading(loading));
    };
};

/**
 * Guarda el identificador de la conversación.
 *
 * @param {string | null} sessionId - `sesionId` del servicio.
 * @returns Thunk.
 */
export const setChatSessionThunk = async (sessionId: string | null) => {
    return async (dispatch: Function) => {
        await dispatch(setChatSession(sessionId));
    };
};

/**
 * Añade un mensaje al hilo.
 *
 * @param {IChatMessage} message - Mensaje a añadir.
 * @returns Thunk.
 */
export const addChatMessageThunk = async (message: IChatMessage) => {
    return async (dispatch: Function) => {
        await dispatch(addChatMessage(message));
    };
};

/**
 * Guarda con qué frase abrir el catálogo desde un turno ya pintado.
 *
 * @param {string} id - Mensaje al que pertenece.
 * @param {IConsultaCatalogo} catalogo - Consulta resuelta y su total.
 * @returns Thunk.
 */
export const setChatMessageCatalogoThunk = async (id: string, catalogo: IConsultaCatalogo) => {
    return async (dispatch: Function) => {
        await dispatch(setChatMessageCatalogo({ id, catalogo }));
    };
};

/**
 * Vacía la conversación.
 *
 * @returns Thunk.
 */
export const resetChatThunk = async () => {
    return async (dispatch: Function) => {
        await dispatch(resetChat());
    };
};

/**
 * Guarda la posición del robot.
 *
 * @param {IAniaPosition} position - Distancias a las esquinas.
 * @returns Thunk.
 */
export const setAniaPositionThunk = async (position: IAniaPosition) => {
    return async (dispatch: Function) => {
        await dispatch(setAniaPosition(position));
    };
};

/**
 * Guarda el nombre que el servicio da al asistente.
 *
 * @param {string} name - Nombre devuelto por el servicio.
 * @returns Thunk.
 */
export const setAssistantNameThunk = async (name: string) => {
    return async (dispatch: Function) => {
        await dispatch(setAssistantName(name));
    };
};

/**
 * Enciende o apaga la voz de Ania.
 *
 * @param {boolean} activa - `true` para que conteste hablando.
 * @returns Thunk.
 */
export const setVozActivaThunk = async (activa: boolean) => {
    return async (dispatch: Function) => {
        await dispatch(setVozActiva(activa));
    };
};

