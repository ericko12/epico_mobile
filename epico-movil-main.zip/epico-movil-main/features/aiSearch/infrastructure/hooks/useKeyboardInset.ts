import { useEffect, useState } from "react";

/**
 * Cuántos píxeles del alto de la ventana está tapando el teclado virtual.
 *
 * **Por qué hace falta.** En el proyecto no había ni una referencia a
 * `visualViewport`: el teclado solo se notaba de refilón por escuchas de
 * `resize`. Eso alcanza en Android, donde el navegador encoge el viewport de
 * maquetación y un elemento anclado con `bottom` sube solo. En iOS y en Safari
 * **no**: el teclado se dibuja *encima* sin cambiar el viewport de maquetación,
 * así que un compositor de chat pegado a `bottom: 0` se queda debajo del teclado y
 * el usuario no ve lo que escribe.
 *
 * `window.visualViewport` sí describe la parte realmente visible en los dos
 * sistemas. La diferencia entre el alto de la ventana y el del viewport visual es
 * lo que ocupa el teclado.
 *
 * @returns {number} Píxeles tapados por el teclado; `0` si está cerrado o si el
 * navegador no expone `visualViewport`.
 */
export const useKeyboardInset = (): number => {
    const [inset, setInset] = useState<number>(0);

    useEffect(() => {
        const vv = typeof window !== "undefined" ? window.visualViewport : undefined;
        if (!vv) return;

        const update = () => {
            // `offsetTop` entra en la cuenta porque al hacer zoom o al desplazar
            // con el teclado abierto el viewport visual se mueve dentro del de
            // maquetación, y sin él el hueco se calcularía de más.
            const hidden = window.innerHeight - vv.height - vv.offsetTop;
            // Un umbral pequeño evita que las barras del navegador, que aparecen y
            // desaparecen al desplazar, se confundan con el teclado.
            setInset(hidden > 120 ? Math.round(hidden) : 0);
        };

        update();
        vv.addEventListener("resize", update);
        vv.addEventListener("scroll", update);
        return () => {
            vv.removeEventListener("resize", update);
            vv.removeEventListener("scroll", update);
        };
    }, []);

    return inset;
};
