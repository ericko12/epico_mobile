/* eslint-disable @typescript-eslint/no-explicit-any */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
    isDictationEnabled,
    isDictationRescueEnabled,
} from "@/features/products/domain/data/searchProducts.config";
import { IDictado } from "@/features/aiSearch/domain/interfaces/IDictado";
import { ModoDictadoEnum } from "@/features/aiSearch/domain/enums/DictadoEnums";
import { MAX_ALTERNATIVAS } from "@/features/aiSearch/domain/data/dictado.data";
import { construirHipotesis } from "@/features/aiSearch/application/actions/dictadoHipotesis";
import {
    pickVoice,
    prosodyFor,
    splitForSpeech,
    textToSpeak,
} from "@/features/aiSearch/application/actions/pickVoice";

/**
 * Hablar y escuchar en el chat del asistente.
 *
 * Usa las dos APIs del navegador, que son independientes entre sí:
 *
 * - **`SpeechRecognition`** para dictar. En Chrome y Edge se llama
 *   `webkitSpeechRecognition`, y Safari la expone con el mismo prefijo desde
 *   iOS 14.5. No existe en Firefox.
 * - **`speechSynthesis`** para que Ania lea su respuesta. Está en todos los
 *   navegadores modernos, pero **no siempre sintetiza en el dispositivo**: ver el
 *   aviso de abajo.
 *
 * ⚠️ **Dónde se procesa la voz. Las dos pueden salir de la red de la empresa.**
 *
 * - **El dictado seguro que sale.** El reconocimiento de Chrome manda el audio a
 *   los servidores de Google. Lo que el usuario dicte —una descripción de pieza,
 *   pero también el nombre de un cliente si lo dice— abandona la red. Por eso el
 *   dictado tiene **su propia bandera** (`isDictationEnabled`), separada de la del
 *   asistente: se puede apagar el micrófono sin apagar el chat.
 * - **La síntesis depende de qué voz toque.** `SpeechSynthesisVoice.localService`
 *   distingue, en palabras de la especificación, una voz «suministrada por un
 *   servicio de síntesis **local**» de una «**remota**». Y `pickVoice` **prefiere
 *   deliberadamente las remotas**, porque son las que suenan bien: la Dalia de Edge
 *   y las de Google se sintetizan en servidores de Microsoft y de Google, así que
 *   con ellas **el texto de la respuesta de Ania sale de la red**.
 *
 * Aquí se decía lo contrario —que la síntesis era local y no mandaba nada—, y era
 * falso. Si algún día esa salida de datos no se acepta, la palanca es filtrar por
 * `localService === true` en `pickVoice`, y el precio es quedarse justo con las
 * voces que sonaban a robot.
 *
 * ⚠️ **Las dos exigen contexto seguro**: HTTPS o `localhost`. En producción se
 * cumple; si algún día se sirviera por HTTP plano, el micrófono no aparecería y
 * el hook devuelve `micDisponible: false` sin romper nada.
 *
 * **Cómo suena.** Qué voces hay depende del dispositivo y del navegador, y no se
 * pueden instalar desde aquí. Lo que sí se puede es elegir bien entre las que
 * haya, y de eso se encarga `pickVoice`: gana Dalia —la neuronal femenina de
 * español de México— si el dispositivo la trae, y si no, la mejor que haya. No hay
 * nada que configurar y no se le pregunta nada al usuario.
 */

/** Idioma del reconocimiento y respaldo del de la voz. */
const LANG = "es-MX";

/**
 * Cuánto silencio se tolera antes de cerrar el micrófono solo.
 *
 * El reconocimiento del navegador ya corta por su cuenta, pero en Android a
 * veces se queda abierto: sin este tope el micrófono quedaría encendido
 * indefinidamente, que es lo peor que puede hacer una aplicación con un permiso
 * de micrófono.
 */
const SILENCIO_MS = 8000;

/** Parámetros del hook. */
export interface IUseVoiceChatOptions {
    /**
     * Se llama cuando el usuario termina de hablar, con la hipótesis principal y
     * las alternativas que el reconocedor entregó. Aquí es donde el llamador envía
     * el turno.
     *
     * ⚠️ `dictado.texto` es lo que hay que enviar, y es **byte a byte** lo que se
     * enviaba antes de que existieran las alternativas. Las alternativas son solo
     * para poder ofrecer una corrección **después**, si el turno fracasa.
     */
    onDictado: (dictado: IDictado) => void;
}

/** Resultado del hook. */
export interface IVoiceChat {
    /** El navegador puede dictar **y** el dictado está permitido por ambiente. */
    micDisponible: boolean;
    /** El navegador puede hablar. */
    vozDisponible: boolean;
    /** El micrófono está abierto. */
    escuchando: boolean;
    /** Ania está leyendo algo en voz alta. */
    hablando: boolean;
    /** Lo entendido hasta ahora en el dictado en curso, definitivo más provisional. */
    parcial: string;
    /** Mensaje de error legible, si el micrófono falló. */
    error: string;
    /** Abre el micrófono. Con `Deletreo`, para que el usuario diga las letras. */
    escuchar: (modo?: ModoDictadoEnum) => void;
    /** Cierra el micrófono sin enviar. */
    dejarDeEscuchar: () => void;
    /**
     * Lee un texto en voz alta.
     *
     * @param texto - Lo que se dice.
     * @param encolar - `true` para decirlo **después** de lo que esté diciendo, en
     * vez de cortarlo. Hace falta cuando la respuesta y la pregunta de una oferta
     * llegan seguidas: la oferta tarda una sonda más, y sin encolar cortaría la
     * respuesta a media frase.
     */
    hablar: (texto: string, encolar?: boolean) => void;
    /** Corta lo que esté diciendo. */
    callar: () => void;
    /** Quita el aviso de error. */
    descartarError: () => void;
}

/**
 * @param {IUseVoiceChatOptions} opciones - Callback del dictado y voz preferida.
 * @returns {IVoiceChat} Estado y controles de la voz.
 */
export const useVoiceChat = ({ onDictado }: IUseVoiceChatOptions): IVoiceChat => {
    const [micDisponible, setMicDisponible] = useState(false);
    const [vozDisponible, setVozDisponible] = useState(false);
    const [escuchando, setEscuchando] = useState(false);
    const [hablando, setHablando] = useState(false);
    const [parcial, setParcial] = useState("");
    const [error, setError] = useState("");

    const reconocedor = useRef<any>(null);
    const temporizador = useRef<ReturnType<typeof setTimeout> | null>(null);
    /** El texto final se guarda en una ref: los eventos no ven el estado. */
    const finalRef = useRef("");
    /**
     * El dictado se cortó por decisión de alguien, no porque terminara.
     *
     * Hace falta distinguirlo porque `onend` se dispara igual cuando el
     * reconocimiento termina solo —y entonces **sí** hay que enviar lo dictado— y
     * cuando se aborta: al pulsar «dejar de escuchar», al abrir otro micrófono o
     * al desmontar el componente. En esos tres casos enviar sería justo lo
     * contrario de lo que pidió el usuario.
     */
    const canceladoRef = useRef(false);
    /** El callback más reciente, para no re-crear el reconocedor en cada render. */
    const onDictadoRef = useRef(onDictado);
    /**
     * Las hipótesis de cada segmento final, indexadas por su posición.
     *
     * `ev.results[i]` es un **segmento** del enunciado, no una palabra, y
     * `ev.results[i].length` es cuántas alternativas llegaron **de verdad**:
     * `maxAlternatives` es un techo pedido, no una promesa, así que nunca se
     * asume que exista `[1]`.
     *
     * Solo se leen alternativas de los resultados con `isFinal`. Las hipótesis
     * n-best las produce el servicio al cerrar el enunciado; los provisionales
     * llegan con una sola, y con la *estabilidad* metida en el hueco de
     * `confidence`.
     */
    const segmentosRef = useRef<string[][]>([]);
    /** Habla libre o deletreo pedido, para el dictado en curso. */
    const modoRef = useRef<ModoDictadoEnum>(ModoDictadoEnum.Libre);
    /**
     * Voces del sistema.
     *
     * `getVoices()` **devuelve vacío la primera vez** en Chrome: la lista llega
     * de forma asíncrona con el evento `voiceschanged`. Sin esperarla, el primer
     * turno hablado saldría con la voz por defecto del sistema —en inglés— y
     * leería el español con fonética inglesa.
     *
     * Solo hace falta en una `ref`: la lista no se enseña en ninguna parte, así
     * que no tiene por qué provocar un render.
     */
    const vocesRef = useRef<SpeechSynthesisVoice[]>([]);
    /** Trozos de locución que faltan por decir, para saber cuándo terminó. */
    const pendientesRef = useRef(0);

    useEffect(() => {
        onDictadoRef.current = onDictado;
    }, [onDictado]);

    /** Detecta qué hay disponible, y se queda a la espera de las voces. */
    useEffect(() => {
        if (typeof window === "undefined") return;

        const SR = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition;
        setMicDisponible(
            !!SR && typeof navigator !== "undefined" && !!navigator.mediaDevices && isDictationEnabled()
        );

        const sintesis = window.speechSynthesis;
        setVozDisponible(!!sintesis);
        if (!sintesis) return;

        const cargarVoces = () => {
            vocesRef.current = sintesis.getVoices();
        };
        cargarVoces();
        sintesis.addEventListener("voiceschanged", cargarVoces);
        return () => sintesis.removeEventListener("voiceschanged", cargarVoces);
    }, []);

    /**
     * Desactiva y cierra el reconocedor vivo, si hay uno.
     *
     * Desenganchar los manejadores **antes** de abortar es lo que impide dos
     * cosas: que el `onend` del abortado envíe un turno que nadie pidió, y que
     * pise el estado de la instancia siguiente dejando la interfaz diciendo que
     * el micrófono está cerrado mientras sigue grabando.
     *
     * @returns {void}
     */
    const matarReconocedor = useCallback((): void => {
        if (temporizador.current) {
            clearTimeout(temporizador.current);
            temporizador.current = null;
        }
        const r = reconocedor.current;
        reconocedor.current = null;
        canceladoRef.current = true;
        finalRef.current = "";
        segmentosRef.current = [];
        if (!r) return;
        r.onstart = null;
        r.onresult = null;
        r.onerror = null;
        r.onend = null;
        try {
            r.abort();
        } catch {
            /* ya estaba cerrado */
        }
    }, []);

    /** Al desmontar: micrófono cerrado y boca cerrada. Nada sigue vivo. */
    useEffect(() => {
        return () => {
            matarReconocedor();
            pendientesRef.current = 0;
            if (typeof window !== "undefined") window.speechSynthesis?.cancel();
        };
    }, [matarReconocedor]);

    /**
     * Cierra el micrófono sin enviar lo dictado.
     *
     * @returns {void}
     */
    const dejarDeEscuchar = useCallback((): void => {
        matarReconocedor();
        setEscuchando(false);
        setParcial("");
        // El aviso se va con el micrófono: dejarlo clavado en el compositor
        // después de cerrarlo no le sirve de nada al usuario.
        setError("");
    }, [matarReconocedor]);

    /**
     * Abre el micrófono y dicta al compositor.
     *
     * @returns {void}
     */
    const escuchar = useCallback((modo: ModoDictadoEnum = ModoDictadoEnum.Libre): void => {
        const SR = (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition;
        if (!SR) return;

        // Si ya hay uno vivo se cierra antes: pulsar el micrófono dos veces
        // seguidas dejaba la primera instancia grabando y fuera de alcance.
        matarReconocedor();

        // Hablar y escuchar a la vez es un bucle: se oiría a sí misma.
        window.speechSynthesis?.cancel();
        pendientesRef.current = 0;
        setHablando(false);
        setError("");
        finalRef.current = "";
        segmentosRef.current = [];
        modoRef.current = modo;
        canceladoRef.current = false;
        setParcial("");

        const r = new SR();
        r.lang = LANG;
        r.continuous = false;
        r.interimResults = true;
        // Se piden varias hipótesis **solo** si el rescate está encendido. Con la
        // bandera apagada se pide una, como siempre: el valor viaja al servicio de
        // reconocimiento, y que pedir cinco no cambie la primera es algo que no
        // está verificado en dispositivo. Así el dictado se comporta exactamente
        // igual que antes mientras eso se mide.
        r.maxAlternatives = isDictationRescueEnabled() ? MAX_ALTERNATIVAS : 1;

        /** Los eventos de una instancia ya reemplazada no tocan nada. */
        const vigente = () => reconocedor.current === r;

        /** Reinicia la cuenta del silencio cada vez que se oye algo. */
        const posponerCierre = () => {
            if (temporizador.current) clearTimeout(temporizador.current);
            temporizador.current = setTimeout(() => {
                try {
                    r.stop();
                } catch {
                    /* ya cerrado */
                }
            }, SILENCIO_MS);
        };

        r.onstart = () => {
            if (!vigente()) return;
            setEscuchando(true);
            posponerCierre();
        };

        r.onresult = (ev: any) => {
            if (!vigente()) return;
            let interino = "";
            for (let i = ev.resultIndex; i < ev.results.length; i++) {
                const res = ev.results[i];
                const trozo = res[0].transcript;
                if (res.isFinal) {
                    finalRef.current += trozo;
                    // `res.length` es cuántas alternativas llegaron de verdad. Se
                    // guardan por índice de segmento para conservar el orden.
                    const alternativas: string[] = [];
                    for (let j = 0; j < res.length; j++) alternativas.push(res[j].transcript);
                    segmentosRef.current[i] = alternativas;
                } else {
                    interino += trozo;
                }
            }
            // Se publica el acumulado, no solo el último trozo: el compositor
            // enseña lo que de verdad se va a enviar.
            setParcial((finalRef.current + interino).trim());
            posponerCierre();
        };

        r.onerror = (ev: any) => {
            if (!vigente()) return;
            // `no-speech` y `aborted` son cotidianos —el usuario no dijo nada, o
            // cerró él—: avisar de eso sería ruido. Los demás sí se cuentan.
            const codigo = ev?.error ?? "";
            if (codigo === "not-allowed" || codigo === "service-not-allowed") {
                setError("No hay permiso para usar el micrófono. Actívalo en los permisos del sitio.");
            } else if (codigo === "audio-capture") {
                setError("No encontramos micrófono en este dispositivo.");
            } else if (codigo === "network") {
                setError("El dictado necesita conexión y no la hay. Escríbelo y funciona igual.");
            } else if (codigo && codigo !== "no-speech" && codigo !== "aborted") {
                setError("No pudimos escucharte. Inténtalo otra vez.");
            }
            setEscuchando(false);
            setParcial("");
        };

        r.onend = () => {
            if (!vigente()) return;
            if (temporizador.current) {
                clearTimeout(temporizador.current);
                temporizador.current = null;
            }
            reconocedor.current = null;
            setEscuchando(false);
            setParcial("");
            const texto = finalRef.current.trim();
            // `Array.from` densifica: si el reconocedor se saltó un índice, esa
            // fila queda como lista vacía en vez de como hueco del array.
            const segmentos = Array.from(segmentosRef.current, (f) => f ?? []);
            const modo = modoRef.current;
            finalRef.current = "";
            segmentosRef.current = [];
            const cancelado = canceladoRef.current;
            canceladoRef.current = false;
            // Si se cortó a mano, lo dictado se queda en el campo para que pueda
            // corregirlo, pero no se envía.
            if (texto && !cancelado) {
                const dictado = construirHipotesis(segmentos, modo);
                // Lo que se envía no puede depender de la recomposición: si por lo
                // que sea no coincidiera con lo acumulado, gana lo acumulado.
                onDictadoRef.current(dictado.texto === texto ? dictado : { ...dictado, texto });
            }
        };

        reconocedor.current = r;
        try {
            r.start();
        } catch {
            // Llamar a `start()` dos veces lanza; se ignora y se deja el estado quieto.
            reconocedor.current = null;
            setEscuchando(false);
        }
    }, [matarReconocedor]);

    /**
     * Dice un texto con una voz concreta, troceándolo si hace falta.
     *
     * @param {string} texto - Lo que se va a decir, tal como llegó.
     * @param {boolean} encolar - `true` para decirlo detrás de lo que ya se esté
     * diciendo.
     * @returns {void}
     */
    const decir = useCallback((texto: string, encolar = false): void => {
        if (typeof window === "undefined" || !window.speechSynthesis) return;

        const limpio = textToSpeak(texto);
        if (!limpio) return;

        if (!encolar) window.speechSynthesis.cancel();

        // La lista puede llegar tarde (ver `vocesRef`), así que se vuelve a pedir.
        const disponibles = vocesRef.current.length
            ? vocesRef.current
            : window.speechSynthesis.getVoices();
        const voz = pickVoice(disponibles);
        const { rate, pitch } = prosodyFor(voz);

        const trozos = splitForSpeech(limpio);
        pendientesRef.current = encolar ? pendientesRef.current + trozos.length : trozos.length;

        trozos.forEach((trozo, i) => {
            const u = new SpeechSynthesisUtterance(trozo);
            // El idioma se toma de la voz elegida: forzar `es-MX` sobre una voz
            // de España hace que algunos motores la sustituyan por otra.
            u.lang = voz?.lang ?? LANG;
            u.rate = rate;
            u.pitch = pitch;
            if (voz) u.voice = voz;

            if (i === 0) u.onstart = () => setHablando(true);
            // Encolando, el primero puede empezar sin que nadie lo anuncie porque
            // ya se estaba hablando; la bandera ya está encendida.
            /** Solo el último trozo apaga la señal de que está hablando. */
            const terminado = () => {
                pendientesRef.current = Math.max(0, pendientesRef.current - 1);
                if (pendientesRef.current === 0) setHablando(false);
            };
            u.onend = terminado;
            u.onerror = terminado;

            window.speechSynthesis.speak(u);
        });
    }, []);

    /**
     * Lee un texto en voz alta.
     *
     * Solo se le pasa la **prosa** del agente: las tarjetas de producto no se
     * dictan. Leer «balata de freno de disco delantera Chevrolet Chevy C2 Tigra
     * Peugeot 306 Bosch F cero tres B ciento cincuenta» no ayuda a nadie.
     *
     * @param {string} texto - Lo que se va a decir.
     * @returns {void}
     */
    const hablar = useCallback(
        (texto: string, encolar = false): void => decir(texto, encolar),
        [decir]
    );

    /**
     * Corta lo que esté diciendo.
     *
     * @returns {void}
     */
    const callar = useCallback((): void => {
        if (typeof window === "undefined") return;
        pendientesRef.current = 0;
        window.speechSynthesis?.cancel();
        setHablando(false);
    }, []);

    /**
     * Quita el aviso de error.
     *
     * @returns {void}
     */
    const descartarError = useCallback((): void => setError(""), []);

    return {
        micDisponible,
        vozDisponible,
        escuchando,
        hablando,
        parcial,
        error,
        escuchar,
        dejarDeEscuchar,
        hablar,
        callar,
        descartarError,
    };
};
