"use client";
import { FC, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
//-- enums
import { AniaStatusEnum, ChatRoleEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
import {
    ConfirmacionEnum,
    ModoDictadoEnum,
    MotivoOfertaEnum,
} from "@/features/aiSearch/domain/enums/DictadoEnums";
import { SearchModeEnum } from "@/features/products/domain/interfaces/ISearchProducts";
//-- interfaces
import {
    IAiSearchState,
    IAniaPosition,
    IChatMessage,
    IContextoPrecios,
} from "@/features/aiSearch/domain/interfaces/IAiSearchState";
import {
    IDictado,
    IMarcaDicha,
    IOfertaRescate,
} from "@/features/aiSearch/domain/interfaces/IDictado";
import { IProduct, IProductSearch } from "@/features/products/domain/interfaces/IProduct";
import { IProductState } from "@/features/products/domain/interfaces/IProductState";
//-- hooks
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks";
import { useProductCardActions } from "@/features/products/infrastructure/hooks/useProductCardActions";
import { useVoiceChat } from "@/features/aiSearch/infrastructure/hooks/useVoiceChat";
//-- redux
import { RootState } from "@/features/common/application/redux/store";
import {
    addChatMessageThunk,
    setChatMessageCatalogoThunk,
    dismissGreetingThunk,
    resetChatThunk,
    setAniaPositionThunk,
    setAssistantNameThunk,
    setChatLoadingThunk,
    setChatSessionThunk,
    setVozActivaThunk,
    toggleChatThunk,
} from "@/features/aiSearch/application/redux/aiSearchThunks";
import {
    updateProductSearchParameters,
    setIsFamilyThunks,
    setIsSaveSearchedThunks,
} from "@/features/products/application/redux/ProductThunks";
//-- actions
import { searchCatalogueProducts } from "@/features/products/application/actions/searchCatalogueProducts";
import { prefijarDictado, sustituirToken } from "@/features/aiSearch/application/actions/dictadoHipotesis";
import { reconstruirDeletreo } from "@/features/aiSearch/application/actions/candidatosDictado";
import { localizarMarcaDicha } from "@/features/aiSearch/application/actions/marcaDictada";
import { sellarContextoPrecios } from "@/features/aiSearch/application/actions/contextoPrecios";
import { resolverConsultaCatalogo } from "@/features/aiSearch/application/actions/consultaCatalogo";
import { sondearDictado } from "@/features/aiSearch/application/actions/sondearDictado";
import {
    decidirOferta,
    leerConfirmacion,
    ofertaVigente,
    planearRescate,
} from "@/features/aiSearch/application/actions/ofertaRescate";
//-- config
import {
    ASSISTANT_DEFAULT_NAME,
    CHAT_MAX_PRODUCT_CARDS,
    isAssistantEnabled,
    isDictationRescueEnabled,
    SEARCH_MAX_MESSAGE_LENGTH,
    SEARCH_MIN_QUERY_LENGTH,
} from "@/features/products/domain/data/searchProducts.config";
//-- components
import { AniaFab } from "@/features/aiSearch/infrastructure/ui/aniaFab/AniaFab";
import { AniaPanel } from "@/features/aiSearch/infrastructure/ui/aniaPanel/AniaPanel";
import { ProductCardActionModals } from "@/features/products/infrastructure/ui/productCardActionModals/ProductCardActionModals";
//-- routes
import { PATH_PAGE } from "@/routes/paths";

/**
 * Punto de montaje del asistente: el botón flotante, el panel y los modales que
 * abren las tarjetas de producto.
 *
 * Se monta en el layout del catálogo, así que vive en `/Catalogo` y en el detalle
 * de producto, y **no** en el resto de la aplicación: es donde tiene contexto útil
 * y donde no compite con los flujos de checkout.
 *
 * Los modales de las tarjetas se montan **aquí**, a nivel del panel y no dentro de
 * cada tarjeta, con el mismo hook que usa el catálogo. Sin ellos «ver
 * aplicaciones» y el icono de promoción del chat no harían nada.
 */

/** Cuánto le dura el mareo cuando la agitan. */
const DIZZY_MS = 2600;

/**
 * Opciones de un envío.
 *
 * @interface IEnvioOpciones
 */
interface IEnvioOpciones {
    /** Lo que entregó el reconocedor, si el turno entró por voz. */
    dictado?: IDictado | null;
    /** El texto anterior, cuando este turno viene de aceptar una corrección. */
    corregidoDe?: string;
    /** No se intenta rescatar. Un rescate no puede encadenar otro. */
    sinRescate?: boolean;
    /**
     * Se manda sin `sesionId`, es decir, empezando conversación.
     *
     * Al aceptar una corrección hace falta: si no, la frase mal entendida se
     * queda como contexto del agente durante los veinte minutos que vive la
     * conversación en Redis, y las anáforas de los turnos siguientes —«de esa
     * marca dame los de doce volts»— se resolverían contra ella.
     */
    sesionNueva?: boolean;
}

/**
 * Genera un identificador local para un mensaje.
 *
 * @returns {string} Identificador único dentro de la sesión.
 */
let messageCounter = 0;
/**
 * El sello de tiempo va dentro a propósito: el contador es de módulo y arranca en
 * cero en cada carga, pero el hilo se rehidrata desde `sessionStorage`, así que
 * `m1` volvía a generarse y dos mensajes distintos compartían `key`.
 */
const nextMessageId = (): string => `m${Date.now().toString(36)}${++messageCounter}`;

/**
 * Componente del asistente.
 *
 * @returns {JSX.Element | null} El asistente, o nada si está apagado.
 */
export const AniaLauncher: FC = () => {
    const dispatch = useAppDispatch();
    const router = useRouter();

    const {
        isOpen,
        isLoading,
        sessionId,
        messages,
        greetingDismissed,
        position,
        assistantName,
        vozActiva,
    } = useAppSelector<IAiSearchState>((state: RootState) => state.sessionState.aiSearchState);
    const { productSearchParameters } = useAppSelector<IProductState>(
        (state: RootState) => state.sessionState.productState
    );
    const { selectedOrderSummary, checkOutList } = useAppSelector(
        (state: RootState) => state.sessionState.checkOutsState
    );

    /**
     * Con qué cliente y sucursal se pide y se sella.
     *
     * Una sola expresión para las dos cosas: calcularlas por separado dejaría
     * mensajes que dicen haberse hidratado con un cliente que no es el que se
     * envió. Baja también al panel, para comparar contra el sello de cada mensaje.
     */
    // Misma lectura que `Catalogue`: sin caja activa y entrando desde el menú, el
    // catálogo pide precios con el cliente mostrador, y el chat tiene que hacer igual.
    const desdeMenu = typeof window !== "undefined" && sessionStorage.getItem("catalogSourceFromMenu") === "true";
    const contextoActual = useMemo<IContextoPrecios>(
        () => sellarContextoPrecios(selectedOrderSummary, checkOutList, desdeMenu),
        [selectedOrderSummary, checkOutList, desdeMenu]
    );

    const { onChangeProductCompatibility, handleShowDiscountModal, modalsState } = useProductCardActions();

    /**
     * Sube con cada turno enviado, para que el compositor vacíe su caja.
     *
     * Un turno dictado lo envía este componente, no el compositor, así que sin
     * esta señal el texto dictado se quedaría escrito después de haberse enviado.
     */
    const [resetKey, setResetKey] = useState(0);

    /** Texto que se devuelve al compositor con «Escribirla yo». */
    const [prefill, setPrefill] = useState<{ texto: string; key: number }>({ texto: "", key: 0 });

    /** Mareo: se enciende al agitarla y se apaga solo. */
    const [dizzy, setDizzy] = useState(false);
    const dizzyTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

    /**
     * Número del turno vigente.
     *
     * Sube al enviar, al cerrar el panel y al empezar una conversación nueva. Cada
     * turno se queda con el número que tenía al empezar y, cuando la respuesta
     * llega cinco segundos después, comprueba que sigue siendo el vigente antes de
     * tocar el hilo o de hablar.
     *
     * Sin esto pasaban tres cosas, las tres confirmadas: cerrar el chat durante la
     * espera y oír a Ania leyendo la respuesta con el panel cerrado; darle a
     * «conversación nueva» y ver aparecer en el hilo vacío la respuesta del turno
     * descartado —resucitando además el `sesionId` viejo—; y silenciarla a mitad
     * de la espera sin que sirviera de nada, porque el turno en vuelo ya se había
     * quedado con el valor anterior.
     */
    const turnoRef = useRef(0);

    /** `vozActiva` en una ref, para que el turno en vuelo lea el valor de ahora. */
    const vozActivaRef = useRef(vozActiva);
    useEffect(() => {
        vozActivaRef.current = vozActiva;
    }, [vozActiva]);

    /** Referencia estable a `enviar`, para que el hook de voz no se recree. */
    const enviarRef = useRef<(texto: string, porVoz: boolean, op?: IEnvioOpciones) => void>(() => { });

    /**
     * La corrección ofrecida y todavía sin contestar.
     *
     * En una `ref` y no en Redux: caduca a los veinte segundos y al enviar
     * cualquier turno, así que persistirla sería pagar un cifrado del árbol de
     * sesión por algo que no sobrevive a la conversación. Y en una tableta
     * compartida no dejaría rastro que nadie pueda ver ni borrar.
     */
    const ofertaRef = useRef<IOfertaRescate | null>(null);
    /** El turno que fracasó, mientras se espera un deletreo para rescatarlo. */
    const deletreoRef = useRef<{ textoAnterior: string; marca: IMarcaDicha } | null>(null);
    /** Modo con el que hay que reabrir el micrófono cuando Ania acabe de hablar. */
    const reabrirRef = useRef<ModoDictadoEnum | null>(null);

    /** Lo que hay escrito en el compositor ahora mismo. */
    const textoCompositorRef = useRef("");
    /**
     * Lo que había escrito cuando se abrió el micrófono.
     *
     * El dictado se **añade** a lo escrito, igual que ya hacía el compositor al
     * pintarlo. Sin esto la pantalla y la red no coincidían: el compositor
     * enseñaba «balatas para un Chevy 2005» y a la red salía solo «un Chevy
     * 2005», porque el hook entrega el trozo dictado y nada más.
     */
    const baseVozRef = useRef("");
    const escuchandoAntesRef = useRef(false);

    /** Referencia estable al manejador del dictado, por lo mismo que `enviarRef`. */
    const dictadoRef = useRef<(dictado: IDictado) => void>(() => { });

    const voz = useVoiceChat({
        onDictado: useCallback((dictado: IDictado) => dictadoRef.current(dictado), []),
    });

    // Ania acabó de hablar: si había quedado pendiente reabrir el micrófono —para
    // oír un «sí» o un deletreo—, se abre ahora. Antes de que termine no se puede,
    // porque el micrófono la oiría a ella.
    useEffect(() => {
        if (voz.hablando) return;
        const modo = reabrirRef.current;
        if (!modo) return;
        reabrirRef.current = null;
        voz.escuchar(modo);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [voz.hablando]);

    useEffect(() => {
        return () => {
            if (dizzyTimer.current) clearTimeout(dizzyTimer.current);
        };
    }, []);

    // Se congela lo escrito en el momento de abrir el micrófono, no al cerrarlo:
    // mientras dicta, el compositor ya está pintando lo escrito más lo entendido,
    // así que leerlo al final contaría lo dictado dos veces.
    useEffect(() => {
        if (voz.escuchando && !escuchandoAntesRef.current) {
            baseVozRef.current = textoCompositorRef.current.trim();
        }
        escuchandoAntesRef.current = voz.escuchando;
    }, [voz.escuchando]);

    /** El robot expresa lo que está pasando, con esta precedencia. */
    const status = useMemo<AniaStatusEnum>(() => {
        if (voz.escuchando) return AniaStatusEnum.Listening;
        if (voz.hablando) return AniaStatusEnum.Speaking;
        if (isLoading) return AniaStatusEnum.Thinking;
        if (dizzy) return AniaStatusEnum.Dizzy;
        if (!greetingDismissed) return AniaStatusEnum.Greeting;
        return AniaStatusEnum.Idle;
    }, [voz.escuchando, voz.hablando, isLoading, dizzy, greetingDismissed]);

    const displayName = assistantName ?? ASSISTANT_DEFAULT_NAME;

    /**
     * Envía un turno al modo IA y añade la respuesta al hilo.
     *
     * @param {string} text - Lo que escribió o dictó el usuario.
     * @param {boolean} porVoz - Si el turno entró por el micrófono.
     * @param {IEnvioOpciones} [op] - Dictado de origen y ajustes del reenvío.
     * @returns {Promise<void>}
     */
    const enviar = useCallback(async (
        text: string,
        porVoz: boolean,
        op?: IEnvioOpciones
    ): Promise<void> => {
        // El servicio exige de 3 a 300 caracteres. El compositor ya lo respeta,
        // pero el camino de voz no pasaba por él: un «sí» dictado salía a la red y
        // volvía como un 400 que el chat enseñaba como fallo genérico.
        const limpio = text.trim().slice(0, SEARCH_MAX_MESSAGE_LENGTH);
        if (limpio.length < SEARCH_MIN_QUERY_LENGTH) return;

        // Cualquier turno nuevo entierra la oferta anterior y el deletreo que se
        // estuviera esperando: son de la pregunta de antes.
        ofertaRef.current = null;
        deletreoRef.current = null;
        reabrirRef.current = null;

        // Si estaba hablando o escuchando, se corta: nadie quiere oír la respuesta
        // anterior mientras hace la pregunta siguiente, y un micrófono que sigue
        // abierto mandaría un segundo turno encima de este.
        voz.callar();
        voz.dejarDeEscuchar();

        const turno = ++turnoRef.current;

        // El sello se congela AQUÍ, no al guardar la respuesta: el turno tarda
        // unos cinco segundos y el vendedor puede cambiar de caja en medio.
        // Releerlo «fresco» en el dispatch produciría un sello que miente, que es
        // peor que no tener sello.
        const contextoTurno = contextoActual;

        // Aceptar una corrección arranca conversación nueva, para que la frase mal
        // entendida no siga siendo el contexto con el que el agente resuelve los
        // turnos siguientes.
        const sesion = op?.sesionNueva ? null : sessionId;
        if (op?.sesionNueva && sessionId) await dispatch(await setChatSessionThunk(null));

        await dispatch(await addChatMessageThunk({
            id: nextMessageId(),
            rol: ChatRoleEnum.User,
            texto: limpio,
            corregidoDe: op?.corregidoDe,
            dictado: op?.dictado?.texto,
        }));
        setResetKey((k) => k + 1);
        await dispatch(await setChatLoadingThunk(true));

        // El cuerpo se arma con los parámetros de búsqueda de la pantalla, pero con
        // la consulta del chat y **sin los chips del sidebar**: en una conversación
        // el usuario acota con palabras, no con filtros, y arrastrar los filtros del
        // catálogo daría resultados que no se explican por lo que escribió.
        const chatParams: IProductSearch = {
            ...productSearchParameters,
            CadenaBusqueda: limpio,
            MarcaIdProducto: undefined,
            FamiliaIdProducto: undefined,
            clasificacionId: undefined,
            CategoriaIdProducto: undefined,
            Paginado: { ...productSearchParameters.Paginado, Pagina: 1 },
        };

        const result = await searchCatalogueProducts(
            chatParams,
            {
                clientId: contextoTurno.clienteId,
                branchId: contextoTurno.sucursalId,
            },
            undefined,
            SearchModeEnum.Ia,
            sesion
        );

        // El usuario cerró el chat o empezó otra conversación mientras esperaba:
        // esta respuesta ya no es de nadie.
        //
        // El guard va **antes** de apagar el «buscando…». Al revés, una respuesta
        // caduca apagaba el indicador de un turno que seguía vivo: el chat se
        // quedaba quieto mientras la pregunta de verdad estaba en vuelo.
        if (turno !== turnoRef.current) return;

        await dispatch(await setChatLoadingThunk(false));

        if (!result.ok) {
            // Se incluye el motivo del gateway cuando lo hay: «no pude buscar» a
            // secas no le dice al usuario si es su conexión o el servicio.
            const detalle = result.errorMessage?.trim();
            const fallo = detalle
                ? `No pude buscar: ${detalle}`
                : "No pude buscar en este momento. Inténtalo de nuevo en unos segundos.";
            await dispatch(await addChatMessageThunk({
                id: nextMessageId(),
                rol: ChatRoleEnum.Assistant,
                texto: fallo,
                error: true,
            }));
            if (porVoz && vozActivaRef.current) voz.hablar(fallo);
            return;
        }

        // El `sesionId` hay que reenviarlo en el turno siguiente o el servicio
        // empieza una conversación nueva y se pierde el contexto.
        if (result.sessionId && result.sessionId !== sessionId) {
            await dispatch(await setChatSessionThunk(result.sessionId));
        }
        if (result.assistantName && result.assistantName !== assistantName) {
            await dispatch(await setAssistantNameThunk(result.assistantName));
        }

        // Cuesta cero peticiones y es la mitad del arreglo: el usuario nombró una
        // marca y el servicio no la reconoció, así que lo que devolvió es de
        // cualquier marca. Va **fuera** de la bandera del rescate a propósito; no
        // tiene ningún riesgo y no gasta nada.
        const marcaDicha = porVoz ? localizarMarcaDicha(limpio) : null;
        const marcaPerdida = marcaDicha && !result.detectedBrand ? marcaDicha : null;

        const withoutResults = result.products.length === 0;
        const texto = result.agentText?.trim()
            ? result.agentText.trim()
            : withoutResults
                ? "No encontré piezas con esa descripción. Prueba con otras palabras, o dime el coche."
                : "Esto es lo que encontré.";

        const idRespuesta = nextMessageId();
        await dispatch(await addChatMessageThunk({
            id: idRespuesta,
            rol: ChatRoleEnum.Assistant,
            texto,
            // Se recortan a propósito: cada tarjeta monta media docena de
            // selectores de Redux, un BroadcastChannel y dos modales. Lo que no
            // cabe se ofrece con el enlace al catálogo.
            productos: result.products.slice(0, CHAT_MAX_PRODUCT_CARDS),
            total: result.total,
            // Con qué cliente y sucursal se hidrataron estas tarjetas. El hilo
            // avisa en cuanto deje de ser el del pedido activo: el precio y la
            // existencia que enseñan son de aquí, y nada más las vuelve a pedir.
            //
            // ⚠️ **Sin sello si la hidratación fracasó del todo.** En ese caso
            // `hydrateSearchProducts` devuelve los productos crudos del índice,
            // con el precio de lista y sin la existencia del cliente. Sellarlos
            // haría que el hilo afirmara más tarde «estos precios son de X» sobre
            // unas cifras que nunca fueron de X: exactamente la mentira que el
            // sello existe para evitar. Sin sello, el mensaje queda en
            // «no se sabe» y no se afirma nada.
            contextoPrecios: result.hydrationFailed ? undefined : contextoTurno,
            // Sin esto el vendedor ve ceros sin explicacion: el catalogo avisa y el
            // chat se callaba.
            hidratacionFallida: result.hydrationFailed || undefined,
            hidratacionError: result.hydrationError || undefined,
            // Estas tres venían en cada respuesta y se tiraban. Pintarlas arregla
            // por sí solo la mitad del defecto: hasta ahora, cuando el servicio
            // perdía la marca, devolvía piezas de cualquier marca y nada lo decía.
            marcaDetectada: result.detectedBrand,
            aproximada: result.approximate,
            terminoCorregido: result.correctedTerm,
            marcaNoReconocida: marcaPerdida?.palabra,
            // Con lo dictado a mano queda el camino de arreglarlo escribiendo, que
            // es mejor que reenviar una frase que ya se sabe que no encuentra nada.
            dictado: marcaPerdida ? limpio : undefined,
            // La que se envió, no la cruda: con el texto crudo, «Ver los N
            // resultados en el catálogo» abría el catálogo con una búsqueda
            // distinta de la que hizo el chat.
            consulta: limpio,
        }));

        // ⚠️ Se lee **solo la prosa**, nunca las tarjetas. Dictar «balata de freno
        // de disco delantera Chevrolet Chevy C2 Tigra Peugeot 306 Bosch efe cero
        // tres be ciento cincuenta» no ayuda a nadie: los productos se ven, no se
        // escuchan. Es la misma razón por la que el agente no los enumera.
        if (porVoz && vozActivaRef.current) voz.hablar(texto);

        // ── Con qué abrir el catálogo desde este turno.
        //
        // Va **después** de pintar y de hablar, no antes: el sondeo tarda, y el
        // botón no es lo primero que se mira de una respuesta. Se resuelve
        // preguntando al índice porque el agente entiende cosas que el catálogo
        // no: medido, «que tipo de cintas tienes» da 66 en modo IA y **cero** en
        // modo normal, mientras que «cinta» -la familia principal de las
        // facetas- da los mismos 66.
        if (result.products.length) {
            const catalogo = await resolverConsultaCatalogo(limpio, result.facets, chatParams, {
                clientId: contextoTurno.clienteId,
                branchId: contextoTurno.sucursalId,
            });
            // El usuario ya empezó otra conversación: este botón no es de nadie.
            if (turno !== turnoRef.current) return;
            if (catalogo) await dispatch(await setChatMessageCatalogoThunk(idRespuesta, catalogo));
        }

        // ── Rescate del dictado, y solo si el turno ya fracasó.
        const plan = planearRescate({
            dictado: op?.dictado ?? null,
            textoEnviado: limpio,
            porVoz,
            // Un rescate no puede encadenar otro: es una cota por construcción, no
            // un contador.
            rescateActivo: isDictationRescueEnabled() && !op?.sinRescate,
            ok: result.ok,
            total: result.total,
            marcaDetectada: result.detectedBrand,
        });
        if (!plan) return;

        let oferta: IOfertaRescate | null = null;
        if (plan.candidatas.length) {
            const sondeos = await sondearDictado(
                [limpio, ...plan.candidatas.map((c) => c.texto)],
                chatParams,
                {
                    clientId: contextoTurno.clienteId,
                    branchId: contextoTurno.sucursalId,
                }
            );
            // Cerrar el panel o empezar de nuevo mientras se sondeaba deja la
            // oferta sin dueño: empujarla al hilo vaciado resucitaría el turno.
            if (turno !== turnoRef.current) return;
            oferta = decidirOferta(
                plan.candidatas,
                plan.motivo,
                limpio,
                sondeos[0],
                sondeos.slice(1),
                Date.now()
            );
        }

        if (oferta) {
            ofertaRef.current = oferta;
            const pregunta = `¿La cambio por «${oferta.palabraDespues}»?`;
            await dispatch(await addChatMessageThunk({
                id: nextMessageId(),
                rol: ChatRoleEnum.Assistant,
                texto: pregunta,
                oferta,
            }));
            if (vozActivaRef.current) {
                // Encolado, para no cortar la respuesta a media frase. Y **pregunta**,
                // nunca afirma: decir «entendí QBH» certificaría el error con la
                // máxima autoridad posible y sin ninguna vuelta atrás para quien no
                // tiene la pantalla delante.
                voz.hablar(
                    `No reconocí la marca ${plan.marca.palabra}. ¿La cambio por ${oferta.palabraDespues}? Dime sí o no.`,
                    true
                );
                reabrirRef.current = ModoDictadoEnum.Libre;
            }
            return;
        }

        // Ninguna hipótesis servía —el caso «Kuhn»—: no se inventa nada, se pide
        // el deletreo. Y si tampoco hay voz, queda el botón de escribirla.
        deletreoRef.current = { textoAnterior: limpio, marca: plan.marca };
        const pedir = "Dímela letra por letra y la busco, o escríbela.";
        await dispatch(await addChatMessageThunk({
            id: nextMessageId(),
            rol: ChatRoleEnum.Assistant,
            texto: pedir,
        }));
        if (vozActivaRef.current) {
            voz.hablar(pedir, true);
            reabrirRef.current = ModoDictadoEnum.Deletreo;
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [dispatch, productSearchParameters, contextoActual, sessionId, assistantName, voz]);

    useEffect(() => {
        enviarRef.current = enviar;
    }, [enviar]);

    /**
     * Dice una frase corta del asistente, y la lee si la voz está encendida.
     *
     * @param {string} texto - Lo que se pinta y se dice.
     * @param {Partial<IChatMessage>} [extra] - Campos adicionales del mensaje.
     * @returns {Promise<void>}
     */
    const decirAlgo = useCallback(async (
        texto: string,
        extra: Partial<IChatMessage> = {}
    ): Promise<void> => {
        await dispatch(await addChatMessageThunk({
            id: nextMessageId(),
            rol: ChatRoleEnum.Assistant,
            texto,
            ...extra,
        }));
        if (vozActivaRef.current) voz.hablar(texto);
    }, [dispatch, voz]);

    /**
     * Acepta una corrección: reenvía el turno con la marca sustituida.
     *
     * Es el **único** camino por el que una palabra se sustituye, junto con el «sí»
     * hablado. No existe ninguno automático.
     *
     * @param {IOfertaRescate} oferta - La corrección aceptada.
     * @returns {void}
     */
    const aceptarOferta = useCallback((oferta: IOfertaRescate): void => {
        ofertaRef.current = null;
        reabrirRef.current = null;
        voz.callar();
        enviarRef.current(oferta.textoNuevo, true, {
            sinRescate: true,
            corregidoDe: oferta.textoAnterior,
            sesionNueva: true,
        });
    }, [voz]);

    /**
     * Rescata un turno con la marca que el usuario acaba de deletrear.
     *
     * No es un turno de chat: lo deletreado no se manda al agente. Se recompone el
     * acrónimo, se le pregunta al índice si existe, y si existe se **ofrece**.
     *
     * @param {string} texto - Lo que se dictó en modo deletreo.
     * @returns {Promise<void>}
     */
    const resolverDeletreo = useCallback(async (texto: string): Promise<void> => {
        const contexto = deletreoRef.current;
        deletreoRef.current = null;
        const acronimo = reconstruirDeletreo(texto);
        // Si el deletreo tampoco sale, se para aquí: no se insiste dos veces, y no
        // se busca «la marca más parecida», porque no hay ninguna lista contra la
        // que parecerse.
        const fallo = "No la pillé. Escríbela y funciona igual.";
        if (!contexto || !acronimo) {
            await decirAlgo(fallo, { dictado: contexto?.textoAnterior });
            return;
        }

        const textoNuevo = sustituirToken(contexto.textoAnterior, contexto.marca.indice, acronimo);
        const turno = turnoRef.current;
        await dispatch(await setChatLoadingThunk(true));
        const sondeos = await sondearDictado(
            [contexto.textoAnterior, textoNuevo],
            {
                ...productSearchParameters,
                MarcaIdProducto: undefined,
                FamiliaIdProducto: undefined,
                clasificacionId: undefined,
                CategoriaIdProducto: undefined,
            },
            {
                clientId: contextoActual.clienteId,
                branchId: selectedOrderSummary?.sucursalIdDestino,
            }
        );
        if (turno !== turnoRef.current) return;
        await dispatch(await setChatLoadingThunk(false));

        const oferta = decidirOferta(
            [{ texto: textoNuevo, palabraAntes: contexto.marca.palabra, palabraDespues: acronimo }],
            MotivoOfertaEnum.Deletreo,
            contexto.textoAnterior,
            sondeos[0],
            sondeos.slice(1),
            Date.now()
        );
        if (!oferta) {
            await decirAlgo(fallo, { dictado: contexto.textoAnterior });
            return;
        }

        ofertaRef.current = oferta;
        const aviso = `Entonces la marca es «${acronimo}».`;
        await dispatch(await addChatMessageThunk({
            id: nextMessageId(),
            rol: ChatRoleEnum.Assistant,
            texto: aviso,
            oferta,
            dictado: contexto.textoAnterior,
        }));
        if (vozActivaRef.current) {
            voz.hablar(`${aviso} ¿La busco así? Dime sí o no.`);
            reabrirRef.current = ModoDictadoEnum.Libre;
        }
    }, [decirAlgo, dispatch, productSearchParameters, selectedOrderSummary, contextoActual, voz]);

    /**
     * Lo que llega del micrófono, en el único orden que funciona.
     *
     * La confirmación se lee **antes** que cualquier otra cosa: un «sí» son dos
     * caracteres y moría en el mínimo de tres que exige el servicio, sin pintar
     * nada y sin que el usuario supiera por qué su respuesta no hacía nada.
     *
     * @param {IDictado} dictado - Lo que entregó el reconocedor.
     * @returns {Promise<void>}
     */
    const manejarDictado = useCallback(async (dictado: IDictado): Promise<void> => {
        if (dictado.modo === ModoDictadoEnum.Deletreo) {
            await resolverDeletreo(dictado.texto);
            return;
        }

        const oferta = ofertaRef.current;
        if (oferta && ofertaVigente(oferta, Date.now())) {
            const respuesta = leerConfirmacion(dictado.texto);
            if (respuesta === ConfirmacionEnum.Si) {
                aceptarOferta(oferta);
                return;
            }
            if (respuesta === ConfirmacionEnum.No) {
                ofertaRef.current = null;
                await decirAlgo("Vale, lo dejo como lo dijiste.");
                return;
            }
            // Dijo otra cosa: la oferta se descarta en silencio y esto se trata como
            // un turno normal. Nadie se queda atrapado en un diálogo.
            ofertaRef.current = null;
        }

        // Lo dictado se añade a lo que hubiera escrito, y se envía solo: pedir un
        // toque después de hablar rompe el único motivo de usar la voz.
        const prefijado = prefijarDictado(dictado, baseVozRef.current);
        enviarRef.current(prefijado.texto, true, { dictado: prefijado });
    }, [aceptarOferta, decirAlgo, resolverDeletreo]);

    useEffect(() => {
        dictadoRef.current = (dictado: IDictado) => { void manejarDictado(dictado); };
    }, [manejarDictado]);

    /**
     * Cierra el panel, y con él el micrófono y la voz.
     *
     * Es la parte que se olvida: un panel cerrado con el micrófono abierto deja el
     * indicador de grabación encendido en el navegador, y una voz que sigue
     * hablando sola después de cerrar es de las cosas más desconcertantes que
     * puede hacer una aplicación.
     *
     * @returns {Promise<void>}
     */
    const cerrar = useCallback(async (): Promise<void> => {
        // El turno en vuelo se queda huérfano: su respuesta no entra al hilo ni se
        // lee en voz alta.
        turnoRef.current += 1;
        voz.dejarDeEscuchar();
        voz.callar();
        // Su turno queda huérfano, y desde que el guard de turno va antes de
        // apagar la espera, nadie más la va a apagar: el panel reabriría con los
        // tres puntos girando para siempre.
        await dispatch(await setChatLoadingThunk(false));
        await dispatch(await toggleChatThunk(false));
    }, [dispatch, voz]);

    /**
     * Empieza una conversación nueva.
     *
     * Cierra el micrófono además de callar la voz: si estaba dictando, ese dictado
     * entraba como primer turno de la conversación que se acababa de vaciar.
     *
     * @returns {Promise<void>}
     */
    const reiniciar = useCallback(async (): Promise<void> => {
        turnoRef.current += 1;
        voz.dejarDeEscuchar();
        voz.callar();
        await dispatch(await resetChatThunk());
    }, [dispatch, voz]);

    /**
     * Lleva la conversación al catálogo, con lo que el usuario escribió.
     *
     * @param {string} query - Consulta del turno.
     * @returns {Promise<void>}
     */
    const seeAllInCatalogue = async (query: string): Promise<void> => {
        await dispatch(await updateProductSearchParameters({
            ...productSearchParameters,
            CadenaBusqueda: query,
            BusquedaInexacta: false,
            EsReferencia: false,
            MarcaIdProducto: undefined,
            FamiliaIdProducto: undefined,
            clasificacionId: undefined,
            CategoriaIdProducto: undefined,
            FamilySelectedFromCatalogue: false,
            Paginado: { ...productSearchParameters.Paginado, Pagina: 1 },
        }));
        // Sin esto el catálogo pintaría el listado de familias en vez de los
        // resultados: `isFamily` es el interruptor entre las dos vistas.
        await dispatch(await setIsFamilyThunks(false));
        // ⚠️ Y sin esto **la búsqueda se borra al llegar**. `Catalogue` al montarse
        // vuelve a familias y vacía `CadenaBusqueda`, salvo que encuentre esta
        // bandera: es el contrato que ya siguen la búsqueda normal
        // (`SearchFilterCatalog`) y el «regresar» del detalle. Y el `push` sí lo
        // vuelve a montar más veces de las que parece: al abrir una caja se entra
        // a `/Catalogo?cvid=…`, y pasar a `/Catalogo` a secas cambia la clave del
        // segmento en el App Router. Así fallaba el primer clic desde la pantalla
        // de familias —el segundo ya salía de `/Catalogo` y no remontaba nada—, y
        // fallaba siempre desde el detalle del producto.
        await dispatch(await setIsSaveSearchedThunks(true));
        await cerrar();
        router.push(PATH_PAGE.catalago.root);
    };

    /**
     * Guarda dónde dejó el usuario el robot.
     *
     * @param {IAniaPosition} newPosition - Distancias a las esquinas.
     * @returns {Promise<void>}
     */
    const persistPosition = async (newPosition: IAniaPosition): Promise<void> => {
        await dispatch(await setAniaPositionThunk(newPosition));
    };

    /**
     * La agitaron: se marea un rato y se le pasa.
     *
     * @returns {void}
     */
    const marear = (): void => {
        setDizzy(true);
        if (dizzyTimer.current) clearTimeout(dizzyTimer.current);
        dizzyTimer.current = setTimeout(() => setDizzy(false), DIZZY_MS);
    };

    // Apagable por ambiente: el chat se puede apagar sin perder la búsqueda nueva.
    if (!isAssistantEnabled()) return null;

    return (
        <>
            {/* El botón se esconde mientras el panel está abierto: el panel ya es la
                puerta, y con los dos a la vez el robot flotaría sobre su propio chat. */}
            {!isOpen && (
                <AniaFab
                    status={status}
                    assistantName={displayName}
                    position={position}
                    showGreeting={!greetingDismissed}
                    onOpen={async () => { await dispatch(await toggleChatThunk(true)); }}
                    onDismissGreeting={async () => { await dispatch(await dismissGreetingThunk()); }}
                    onMoveEnd={persistPosition}
                    onShake={marear}
                />
            )}

            {isOpen && (
                <AniaPanel
                    messages={messages}
                    contextoActual={contextoActual}
                    loading={isLoading}
                    assistantName={displayName}
                    status={status}
                    onClose={cerrar}
                    onReset={reiniciar}
                    onSend={(texto: string) => { void enviar(texto, false); }}
                    onClickCompatibility={(product: IProduct) => onChangeProductCompatibility(product)}
                    onShowDiscounts={(productId: number) => { void handleShowDiscountModal(productId); }}
                    onSeeAllInCatalogue={seeAllInCatalogue}
                    // La conversación no se pierde: el layout del catálogo no se
                    // vuelve a montar al ir al detalle, y el robot la reabre igual.
                    onOpenDetail={() => { void cerrar(); }}
                    onAceptarOferta={aceptarOferta}
                    onEscribirAMano={(texto: string) => {
                        // Se cierra el micrófono: si estaba esperando un deletreo, el
                        // usuario acaba de decidir que prefiere teclearlo.
                        voz.dejarDeEscuchar();
                        ofertaRef.current = null;
                        deletreoRef.current = null;
                        reabrirRef.current = null;
                        setPrefill((p) => ({ texto, key: p.key + 1 }));
                    }}
                    vozDisponible={voz.vozDisponible}
                    vozActiva={vozActiva}
                    onToggleVoz={async () => {
                        // Al silenciarla se calla ya, no al turno siguiente.
                        voz.callar();
                        await dispatch(await setVozActivaThunk(!vozActiva));
                    }}
                    micDisponible={voz.micDisponible}
                    escuchando={voz.escuchando}
                    parcial={voz.parcial}
                    errorVoz={voz.error}
                    // Envuelto a propósito: `onClick` pasa el evento como primer
                    // argumento, y el primer argumento de `escuchar` es el modo.
                    onEscuchar={() => voz.escuchar()}
                    onDejarDeEscuchar={voz.dejarDeEscuchar}
                    onDescartarError={voz.descartarError}
                    onTextoChange={(texto: string) => { textoCompositorRef.current = texto; }}
                    prefill={prefill}
                    resetKey={resetKey}
                />
            )}

            {/* Aplicaciones y promoción de las tarjetas del chat. Son Modal de MUI a
                z-index 1300, por encima del panel (1210) y de su telón (1209). */}
            <ProductCardActionModals state={modalsState} />
        </>
    );
};
