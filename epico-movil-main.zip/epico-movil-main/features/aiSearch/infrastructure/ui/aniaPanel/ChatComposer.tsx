import { FC, useEffect, useRef, useState } from "react";
import { Alert, Box, IconButton, TextField, Tooltip, Typography } from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import MicIcon from "@mui/icons-material/Mic";
import StopIcon from "@mui/icons-material/Stop";
//-- enums
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
//-- config
import {
    SEARCH_MAX_MESSAGE_LENGTH,
    SEARCH_MIN_QUERY_LENGTH,
} from "@/features/products/domain/data/searchProducts.config";

/**
 * El compositor del chat: escribir o dictar.
 *
 * El texto vive en estado **local**, no en Redux: el árbol de sesión se cifra
 * completo en cada escritura, y despachar por cada tecla sería pagar un cifrado
 * por pulsación.
 *
 * @typedef {Object} ChatComposerProps
 * @property {boolean} disabled - Si está esperando respuesta.
 * @property {(text: string) => void} onSend - Envía un mensaje escrito.
 * @property {boolean} micDisponible - El navegador puede dictar.
 * @property {boolean} escuchando - El micrófono está abierto.
 * @property {string} parcial - Lo que se va entendiendo mientras habla.
 * @property {string} errorVoz - Motivo por el que el micrófono falló.
 * @property {() => void} onEscuchar - Abre el micrófono.
 * @property {() => void} onDejarDeEscuchar - Cierra el micrófono sin enviar.
 * @property {() => void} onDescartarError - Quita el aviso de error.
 * @property {(texto: string) => void} [onTextoChange] - Avisa al padre de lo que
 * hay escrito en la caja. Hace falta porque un turno dictado lo envía el padre, y
 * sin esto solo enviaría el trozo dictado: quien escribe «balatas para» y dicta
 * «un Chevy 2005» mandaba a la red únicamente lo dictado, y encima `resetKey` le
 * borraba después lo que había escrito.
 * @property {{ texto: string; key: number }} [prefill] - Texto que el padre pone en
 * la caja. Es el camino de «Escribirla yo»: cuando el reconocedor destrozó una
 * marca y no hay corrección que ofrecer, devolver lo dictado para editarlo es más
 * útil que reenviar una frase que ya se sabe que no encuentra nada. Se aplica al
 * cambiar `key`, para que se pueda repetir el mismo texto.
 * @property {number} resetKey - Cambia cada vez que el padre envía un turno.
 * Hace falta porque un turno dictado lo envía el padre, no este componente, y sin
 * la señal el texto que se acaba de dictar se quedaría en la caja después de
 * haberse enviado.
 */
export type ChatComposerProps = {
    disabled: boolean;
    onSend: (text: string) => void;
    micDisponible: boolean;
    escuchando: boolean;
    parcial: string;
    errorVoz: string;
    onEscuchar: () => void;
    onDejarDeEscuchar: () => void;
    onDescartarError: () => void;
    onTextoChange?: (texto: string) => void;
    prefill?: { texto: string; key: number };
    resetKey: number;
};

/**
 * Campo de escritura, micrófono y botón de enviar.
 *
 * @param {ChatComposerProps} props - Propiedades del componente.
 * @returns {JSX.Element} El compositor.
 */
export const ChatComposer: FC<ChatComposerProps> = ({
    disabled,
    onSend,
    micDisponible,
    escuchando,
    parcial,
    errorVoz,
    onEscuchar,
    onDejarDeEscuchar,
    onDescartarError,
    onTextoChange,
    prefill,
    resetKey,
}) => {
    const [text, setText] = useState("");

    /**
     * Lo que había escrito cuando se abrió el micrófono.
     *
     * El dictado se **añade** a lo que el usuario ya tenía escrito, no lo
     * sustituye. Antes lo pisaba: alguien que escribía «balatas para» y pulsaba
     * el micrófono para dictar el resto perdía lo escrito sin aviso, y encima se
     * enviaba solo la parte dictada.
     */
    const base = useRef("");

    /** El padre envió un turno: la caja se vacía. */
    useEffect(() => {
        if (resetKey > 0) {
            setText("");
            base.current = "";
        }
    }, [resetKey]);

    // Al abrir el micrófono se recuerda lo escrito, para concatenar sobre ello.
    useEffect(() => {
        if (escuchando) base.current = text;
        // Solo al cambiar `escuchando`: leer `text` aquí en cada tecla borraría
        // la base en cuanto el dictado empezara a escribir en el campo.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [escuchando]);

    // Mientras dicta, el campo enseña lo que se va a enviar: lo que ya estaba
    // más lo entendido. Es la única forma de que el usuario sepa que el
    // micrófono lo oye —y de que vea, antes de enviar, que entendió «balatas» y
    // no «malas patas».
    useEffect(() => {
        if (!escuchando || !parcial) return;
        const previo = base.current.trim();
        setText(previo ? `${previo} ${parcial}` : parcial);
    }, [escuchando, parcial]);

    const campoRef = useRef<HTMLInputElement | null>(null);

    // «Escribirla yo»: llega el texto dictado, se escribe y se enfoca. La base del
    // dictado se actualiza también, para que dictar encima concatene sobre esto.
    useEffect(() => {
        if (!prefill?.key || !prefill.texto) return;
        setText(prefill.texto.slice(0, SEARCH_MAX_MESSAGE_LENGTH));
        base.current = prefill.texto;
        campoRef.current?.focus();
        // Solo al cambiar la clave: el texto puede repetirse.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [prefill?.key]);

    // El padre necesita saber qué hay escrito para poder enviar lo escrito **más**
    // lo dictado. Va por callback y no por Redux: el texto se queda en estado
    // local, porque despachar por tecla cifraría el árbol de sesión completo.
    useEffect(() => {
        onTextoChange?.(text);
        // Solo al cambiar el texto: el callback llega como flecha en línea y
        // depender de él haría correr el efecto en cada render del padre.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [text]);

    // El servicio exige de 3 a 300 caracteres: por debajo devuelve 400, así que no
    // se deja enviar en vez de dejar que falle.
    const trimmed = text.trim();
    const canSend = !disabled && !escuchando && trimmed.length >= SEARCH_MIN_QUERY_LENGTH;

    /**
     * Envía el mensaje y limpia el campo.
     *
     * @returns {void}
     */
    const send = () => {
        if (!canSend) return;
        onSend(trimmed);
        setText("");
    };

    return (
        <Box
            sx={{
                flex: "0 0 auto",
                borderTop: `1px solid ${ColorsEpico.ColorsSilverBlue}`,
                backgroundColor: ColorsEpico.ColorWhite,
                p: 1,
                // El teclado del teléfono puede dejar el compositor pegado al borde
                // inferior en dispositivos con gestos.
                pb: "calc(8px + env(safe-area-inset-bottom))",
            }}
        >
            {errorVoz && (
                <Alert
                    severity="warning"
                    onClose={onDescartarError}
                    sx={{ mb: 1, py: 0, fontSize: "11.5px", "& .MuiAlert-message": { minWidth: 0, overflowWrap: "anywhere" } }}
                >
                    {errorVoz}
                </Alert>
            )}

            <Box sx={{ display: "flex", gap: 0.75, alignItems: "flex-end" }}>
                <Box sx={{ flex: "1 1 auto", minWidth: 0 }}>
                    <TextField
                        value={text}
                        onChange={(e) => setText(e.target.value.slice(0, SEARCH_MAX_MESSAGE_LENGTH))}
                        onKeyDown={(e) => {
                            // Enter envía; Mayúsculas+Enter hace salto de línea, como en
                            // cualquier chat. En el teléfono el teclado trae su propio
                            // salto de línea, así que no estorba.
                            if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                send();
                            }
                        }}
                        placeholder={escuchando ? "Te escucho…" : "Escribe la pieza y el coche…"}
                        aria-label="Escribe tu mensaje para Ania"
                        multiline
                        maxRows={4}
                        fullWidth
                        size="small"
                        inputRef={campoRef}
                        slotProps={{
                            input: { sx: { borderRadius: "20px", fontSize: "12.5px", py: 0.75 } },
                        }}
                    />
                    <Typography
                        sx={{
                            display: "block",
                            textAlign: "right",
                            fontSize: "9.5px",
                            color: text.length >= SEARCH_MAX_MESSAGE_LENGTH
                                ? ColorsEpico.ColorRedOpaque
                                : ColorsEpico.ColorNeutral,
                            mt: 0.25,
                            pr: 1,
                        }}
                    >
                        {text.length} / {SEARCH_MAX_MESSAGE_LENGTH}
                    </Typography>
                </Box>

                {/* Micrófono. Solo aparece si el navegador puede dictar: en Firefox,
                    o servido por HTTP plano, no existe la API y un botón que no hace
                    nada es peor que no tenerlo. */}
                {micDisponible && (
                    <Tooltip title={escuchando
                        ? "Dejar de escuchar"
                        : "Dictar por voz. El audio se procesa en un servicio externo."}>
                        <IconButton
                            onClick={escuchando ? onDejarDeEscuchar : onEscuchar}
                            // Estando abierto, cerrarlo tiene que ser posible
                            // siempre: si `loading` lo inhabilitara, un micrófono
                            // abierto justo al enviar se quedaría sin botón de
                            // apagado hasta que llegara la respuesta.
                            disabled={disabled && !escuchando}
                            aria-label={escuchando ? "Dejar de escuchar" : "Dictar por voz"}
                            sx={{
                                width: 44,
                                height: 44,
                                flex: "0 0 auto",
                                border: `1px solid ${escuchando ? ColorsEpico.ColorAvailable : ColorsEpico.ColorGrayNeutral}`,
                                backgroundColor: escuchando ? ColorsEpico.ColorAvailable : "transparent",
                                color: escuchando ? ColorsEpico.ColorWhite : ColorsEpico.ColorGray,
                                "&:hover": {
                                    backgroundColor: escuchando ? ColorsEpico.ColorAvailable : ColorsEpico.ColorSkyBlue,
                                },
                                // Late mientras escucha: es la señal de que el
                                // micrófono está abierto, visible sin leer nada.
                                animation: escuchando ? "mic-late 1.1s ease-in-out infinite" : "none",
                                "@keyframes mic-late": {
                                    "0%,100%": { boxShadow: `0 0 0 0 ${ColorsEpico.ColorAvailable}66` },
                                    "50%": { boxShadow: `0 0 0 7px ${ColorsEpico.ColorAvailable}00` },
                                },
                                "@media (prefers-reduced-motion: reduce)": { animation: "none" },
                            }}
                        >
                            {escuchando ? <StopIcon sx={{ fontSize: 20 }} /> : <MicIcon sx={{ fontSize: 20 }} />}
                        </IconButton>
                    </Tooltip>
                )}

                <IconButton
                    onClick={send}
                    disabled={!canSend}
                    aria-label="Enviar mensaje"
                    sx={{
                        width: 44,
                        height: 44,
                        flex: "0 0 auto",
                        backgroundColor: canSend ? ColorsEpico.ColorPrimary : ColorsEpico.ColorPrimaryDisabled,
                        color: ColorsEpico.ColorWhite,
                        "&:hover": { backgroundColor: ColorsEpico.ColorPrimary },
                        "&.Mui-disabled": {
                            backgroundColor: ColorsEpico.ColorPrimaryDisabled,
                            color: ColorsEpico.ColorWhite,
                        },
                    }}
                >
                    <SendIcon sx={{ fontSize: 20 }} />
                </IconButton>
            </Box>
        </Box>
    );
};
