import { FC, useEffect, useRef } from "react";
import { Alert, Box, Button, Chip, Typography } from "@mui/material";
import LocalOfferOutlinedIcon from "@mui/icons-material/LocalOfferOutlined";
//-- enums
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { ChatRoleEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
//-- interfaces
import { IChatMessage, IContextoPrecios } from "@/features/aiSearch/domain/interfaces/IAiSearchState";
import { IOfertaRescate } from "@/features/aiSearch/domain/interfaces/IDictado";
import { IProduct } from "@/features/products/domain/interfaces/IProduct";
//-- actions
import { avisoDeMensaje, textoAvisoContexto } from "@/features/aiSearch/application/actions/contextoPrecios";
import { destinoDelHilo } from "@/features/aiSearch/application/actions/desplazamientoHilo";
//-- components
import { ProductCard } from "@/features/products/infrastructure/ui/table/productTable/productCard/ProductCard";

/**
 * El hilo de la conversación.
 *
 * Lo importante de este componente no es el aspecto: es **de dónde sale la
 * verdad**. El texto del agente es conversación —y se le ha visto afirmar que una
 * balata de Nissan Frontier «también le queda» a un Chevy 2005—, así que debajo de
 * cada respuesta con productos va un aviso y las tarjetas llevan su botón de
 * aplicaciones a mano. La prosa orienta; la tarjeta manda.
 *
 * ⚠️ **Aquí no se usa `ProductTableItems`.** Ese componente lee `products`,
 * `loadingProducts` y `viewList` de `sessionState.productState`, así que pintar el
 * chat con él obligaría a meter las recomendaciones en el estado del catálogo y
 * pisaría la lista de resultados de la pantalla de fondo. Se llama a `ProductCard`
 * directamente con un array local.
 */

/**
 * @typedef {Object} ChatThreadProps
 * @property {IChatMessage[]} messages - Hilo completo.
 * @property {IContextoPrecios} contextoActual - Cliente y sucursal del pedido
 * activo AHORA. Entra por props y no por `useAppSelector` para que el hilo siga
 * siendo presentacional y se pueda renderizar sin store.
 * @property {boolean} loading - Si se está esperando respuesta.
 * @property {(product: IProduct) => void} onClickCompatibility - Ver aplicaciones.
 * @property {(productId: number) => void} onShowDiscounts - Ver promoción.
 * @property {(query: string) => void} onSeeAllInCatalogue - Abrir la búsqueda en el catálogo.
 * @property {() => void} onOpenDetail - Se abrió el detalle de un producto del hilo:
 * el panel tiene que quitarse de en medio, o el detalle se abre detrás del velo.
 * @property {(oferta: IOfertaRescate) => void} onAceptarOferta - Acepta la
 * corrección de una marca mal entendida. Es uno de los dos únicos caminos por los
 * que una palabra se sustituye; el otro es decir «sí».
 * @property {(texto: string) => void} onEscribirAMano - Devuelve el texto dictado
 * al compositor para que el usuario lo arregle él.
 * @property {number} keyboardInset - Píxeles que tapa el teclado. Entra en las
 * dependencias del autodesplazamiento porque abrir el teclado encoge el hilo y
 * deja el último mensaje fuera de la vista.
 */
export type ChatThreadProps = {
    messages: IChatMessage[];
    contextoActual: IContextoPrecios;
    loading: boolean;
    onClickCompatibility: (product: IProduct) => void;
    onShowDiscounts: (productId: number) => void;
    onSeeAllInCatalogue: (query: string) => void;
    onOpenDetail: () => void;
    onAceptarOferta: (oferta: IOfertaRescate) => void;
    onEscribirAMano: (texto: string) => void;
    keyboardInset: number;
};

/**
 * Aire que se deja sobre la respuesta al llevarla arriba, para que la burbuja no
 * quede pegada al borde y se vea que es el principio de algo.
 */
const MARGEN_RESPUESTA_PX = 8;

/**
 * Molde de los avisos que acompañan a una respuesta.
 *
 * En **tamaño de cuerpo** (11,5 px, el de la burbuja), no en pie de 10,5 px: el
 * texto que explica una duda no puede ser el más pequeño de la pantalla mientras
 * la respuesta dudosa va en el tamaño normal.
 */
const avisoSx = {
    mt: 0.75,
    py: 0,
    width: "100%",
    fontSize: "11.5px",
    alignItems: "center",
    "& .MuiAlert-message": { minWidth: 0, overflowWrap: "anywhere", py: 0.5 },
    "& .MuiAlert-icon": { mr: 0.75, py: 0.5 },
} as const;

/**
 * Molde del aviso de que las tarjetas son de otro cliente.
 *
 * No es transparente como los demás: relleno ámbar y opaco a propósito. El aviso
 * de «confirma la aplicación» sale debajo de **toda** respuesta con productos, así
 * que ya se salta con la vista; con el mismo aspecto, el aviso raro —el que sale
 * pocas veces y hay que leer— nacería invisible.
 *
 * Los colores van explícitos y no por la paleta `warning` de fábrica de MUI: el
 * texto nunca en `ColorVibrantYellow` sobre `ColorSoftBeige`, que son ~2,2:1 de
 * contraste. Con `ColorGray` son ~7:1.
 */
const avisoContextoSx = {
    ...avisoSx,
    alignItems: "flex-start",
    backgroundColor: ColorsEpico.ColorSoftBeige,
    borderColor: ColorsEpico.ColorVibrantYellow,
    color: ColorsEpico.ColorGray,
    "& .MuiAlert-icon": { ...avisoSx["& .MuiAlert-icon"], color: ColorsEpico.ColorVibrantYellow },
} as const;

/**
 * Hilo de mensajes del asistente.
 *
 * @param {ChatThreadProps} props - Propiedades del componente.
 * @returns {JSX.Element} El hilo.
 */
export const ChatThread: FC<ChatThreadProps> = ({
    messages,
    contextoActual,
    loading,
    onClickCompatibility,
    onShowDiscounts,
    onSeeAllInCatalogue,
    onOpenDetail,
    onAceptarOferta,
    onEscribirAMano,
    keyboardInset,
}) => {
    const hilo = useRef<HTMLDivElement>(null);

    /**
     * El hilo se mueve en cuanto entra algo: al final mientras el vendedor
     * escribe y espera, y al **principio de la respuesta** cuando llega.
     *
     * Sin moverse el chat parecía roto: los mensajes se añaden al final de un
     * contenedor con `overflowY: auto`, así que al enviar el segundo turno el
     * usuario **no veía ni su propio mensaje ni los puntos de «buscando…»** —la
     * vista se quedaba donde estaba— y a los cinco segundos seguía viendo lo
     * mismo. Con el teclado abierto quedan 100–150 px de hilo y es inutilizable.
     *
     * Pero bajar al final **también con la respuesta** dejaba el texto de Ania
     * por encima de la vista: debajo van las tarjetas, y el vendedor tenía que
     * subir a buscar dónde empezaba a leer. `destinoDelHilo` decide cuál de las
     * dos toca.
     *
     * `keyboardInset` está en las dependencias porque abrir o cerrar el teclado
     * cambia el alto del contenedor y hay que volver a colocar la vista.
     */
    const destino = destinoDelHilo(messages, loading);
    const idDestino = destino.tipo === "mensaje" ? destino.id : null;
    useEffect(() => {
        const el = hilo.current;
        if (!el) return;
        // Dos fotogramas: el primero deja que React pinte el mensaje nuevo, el
        // segundo mide ya con su alto real. Con uno solo, `scrollHeight` es el de
        // antes y el desplazamiento se queda corto.
        let segundo = 0;
        const primero = requestAnimationFrame(() => {
            segundo = requestAnimationFrame(() => {
                const respuesta = idDestino
                    ? el.querySelector<HTMLElement>(`[data-mensaje-id="${idDestino}"]`)
                    : null;
                if (!respuesta) {
                    el.scrollTop = el.scrollHeight;
                    return;
                }
                // Medido contra el contenedor y no con `offsetTop`, que depende de
                // qué ancestro esté posicionado. El navegador recorta solo al
                // máximo: una respuesta corta acaba igual en el final.
                const desfase = respuesta.getBoundingClientRect().top - el.getBoundingClientRect().top;
                el.scrollTop = Math.max(0, el.scrollTop + desfase - MARGEN_RESPUESTA_PX);
            });
        });
        return () => {
            cancelAnimationFrame(primero);
            cancelAnimationFrame(segundo);
        };
    }, [messages.length, loading, keyboardInset, idDestino]);

    return (
        <Box
            ref={hilo}
            sx={{
                flex: "1 1 auto",
                minHeight: 0,
                overflowY: "auto",
                overflowX: "hidden",
                backgroundColor: ColorsEpico.ColorNeutro,
                px: 1.25,
                py: 1.5,
                display: "flex",
                flexDirection: "column",
                gap: 1.5,
            }}
        >
            {messages.length === 0 && !loading && (
                <Box sx={{ textAlign: "center", py: 3, px: 1 }}>
                    <Typography sx={{ fontSize: "13px", color: ColorsEpico.ColorGray, mb: 1 }}>
                        Cuéntame qué pieza necesitas y para qué coche.
                    </Typography>
                    <Typography sx={{ fontSize: "11.5px", color: ColorsEpico.ColorNeutralGray }}>
                        Por ejemplo: «balatas delanteras para un Chevy 2005».
                    </Typography>
                </Box>
            )}

            {messages.map((message) => {
                const isUser = message.rol === ChatRoleEnum.User;
                const products = message.productos ?? [];
                // Se calcula en el render y no en un efecto: así el aviso aparece
                // en cuanto cambia el pedido activo, y desaparece solo si el
                // vendedor vuelve al cliente con el que buscó.
                const textoContexto = textoAvisoContexto(
                    avisoDeMensaje(message, contextoActual),
                    contextoActual,
                    message.contextoPrecios
                );

                return (
                    <Box
                        key={message.id}
                        data-mensaje-id={message.id}
                        sx={{
                            display: "flex",
                            flexDirection: "column",
                            alignItems: isUser ? "flex-end" : "flex-start",
                            maxWidth: "100%",
                            minWidth: 0,
                        }}
                    >
                        {/* Burbuja del mensaje */}
                        <Box
                            sx={{
                                maxWidth: "88%",
                                px: 1.25,
                                py: 1,
                                borderRadius: "14px",
                                borderBottomRightRadius: isUser ? "4px" : "14px",
                                borderBottomLeftRadius: isUser ? "14px" : "4px",
                                backgroundColor: isUser
                                    ? ColorsEpico.ColorPrimary
                                    : ColorsEpico.ColorWhite,
                                color: isUser ? ColorsEpico.ColorWhite : ColorsEpico.ColorBlack,
                                boxShadow: isUser ? "none" : "0 1px 3px rgba(0,0,0,.11)",
                                fontSize: "12.5px",
                                lineHeight: 1.45,
                                // El agente responde con saltos de línea; se respetan.
                                whiteSpace: "pre-line",
                                // Un código de producto largo no puede empujar el panel.
                                overflowWrap: "anywhere",
                                minWidth: 0,
                            }}
                        >
                            {message.texto}
                            {/* Un turno corregido lleva dentro de dónde salió, para
                                que el hilo siga siendo un registro fiel de lo que
                                pidió el cliente. En tamaño de cuerpo: el texto que
                                explica la duda no puede ser el más pequeño de la
                                pantalla. */}
                            {isUser && message.corregidoDe && (
                                <Typography
                                    component="span"
                                    sx={{
                                        display: "block",
                                        mt: 0.5,
                                        fontSize: "11.5px",
                                        fontStyle: "italic",
                                        opacity: 0.85,
                                        overflowWrap: "anywhere",
                                    }}
                                >
                                    dijiste «{message.corregidoDe}»
                                </Typography>
                            )}
                        </Box>

                        {/* Lo que el servicio ya decía de este turno.
                            La **ausencia** de marca no se anuncia: es el caso normal,
                            y un «marca entendida: ninguna» debajo de la mayoría de
                            las respuestas enseña a desconfiar del asistente. */}
                        {!isUser && message.marcaDetectada && (
                            <Chip
                                size="small"
                                icon={<LocalOfferOutlinedIcon sx={{ fontSize: 14 }} />}
                                label={`Marca: ${message.marcaDetectada}`}
                                sx={{
                                    mt: 0.75,
                                    height: 24,
                                    fontSize: "11.5px",
                                    maxWidth: "100%",
                                    color: ColorsEpico.ColorPrimary,
                                    borderColor: ColorsEpico.ColorPrimary,
                                    "& .MuiChip-label": { overflowWrap: "anywhere" },
                                }}
                                variant="outlined"
                            />
                        )}

                        {!isUser && message.aproximada && (
                            <Alert
                                severity="info"
                                variant="outlined"
                                sx={avisoSx}
                            >
                                {message.terminoCorregido
                                    ? `No encontré eso exacto, así que busqué «${message.terminoCorregido}».`
                                    : "No encontré eso exacto, así que corregí la escritura para encontrar algo."}
                            </Alert>
                        )}

                        {/* La marca se perdió. Este aviso es el arreglo de fondo: sin
                            él, «focos de la marca QH» devolvía focos de cualquier
                            marca y nada en la pantalla lo decía. */}
                        {!isUser && message.marcaNoReconocida && (
                            <Alert severity="warning" variant="outlined" sx={avisoSx}>
                                No reconocí la marca «{message.marcaNoReconocida}».
                            </Alert>
                        )}

                        {/* La corrección, diciendo exactamente qué palabra cambia.
                            No «¿buscabas QBH?», que se lee como una confirmación de
                            lo que el usuario dijo. Sin tocarlo no pasa nada. */}
                        {!isUser && message.oferta && (
                            <Button
                                variant="contained"
                                fullWidth
                                onClick={() => onAceptarOferta(message.oferta!)}
                                sx={{
                                    mt: 1,
                                    minHeight: 44,
                                    fontSize: "12px",
                                    textTransform: "none",
                                    overflowWrap: "anywhere",
                                    backgroundColor: ColorsEpico.ColorPrimary,
                                }}
                            >
                                Cambiar «{message.oferta.palabraAntes}» por «
                                {message.oferta.palabraDespues}» — {message.oferta.total} piezas
                            </Button>
                        )}

                        {/* El deshacer que de verdad sirve: reenviar la transcripción
                            mala tal cual es reenviar algo que ya se sabe que no
                            encuentra nada. */}
                        {!isUser && message.dictado && !message.oferta && (
                            <Button
                                variant="outlined"
                                fullWidth
                                onClick={() => onEscribirAMano(message.dictado!)}
                                sx={{
                                    mt: 1,
                                    minHeight: 44,
                                    fontSize: "12px",
                                    textTransform: "none",
                                    color: ColorsEpico.ColorPrimary,
                                    borderColor: ColorsEpico.ColorPrimary,
                                }}
                            >
                                Escribirla yo
                            </Button>
                        )}

                        {/* Lo que hay que mirar antes de agregar.
                            Cuando las cifras son de otro cliente el aviso va
                            **dentro de esta misma caja** y la tiñe, en vez de
                            añadir una cuarta. Medido a 320×568: fundido ocupa
                            111 px de los 387 px de hilo visible y en dos cajas
                            125 px. Los 14 px cuentan poco; lo que decide es que
                            un mensaje ya puede apilar el chip de la marca, el
                            aviso de búsqueda aproximada y el de marca no
                            reconocida, y dos cajas ámbar seguidas diciendo cosas
                            emparentadas se leen como una sola y se saltan las
                            dos. */}
                        {!isUser && products.length > 0 && (
                            <Alert
                                severity={message.hidratacionFallida ? "error" : "warning"}
                                variant="outlined"
                                sx={textoContexto || message.hidratacionFallida ? avisoContextoSx : avisoSx}
                            >
                                {/* Lo primero, porque invalida todo lo que hay debajo: sin
                                    precio ni existencia las tarjetas salen a «$0.00 · No
                                    disponible». El catálogo ya avisaba de esto y el chat no.
                                    Se incluye el motivo del gateway: un aviso que no explica
                                    nada no se puede accionar. */}
                                {message.hidratacionFallida && (
                                    <Typography
                                        component="span"
                                        sx={{
                                            display: "block",
                                            mb: 0.25,
                                            fontSize: "11.5px",
                                            fontWeight: 700,
                                            overflowWrap: "anywhere",
                                        }}
                                    >
                                        No pudimos traer los precios de este cliente.
                                        {message.hidratacionError ? ` ${message.hidratacionError}` : ""}
                                    </Typography>
                                )}
                                {textoContexto && (
                                    <Typography
                                        component="span"
                                        sx={{
                                            display: "block",
                                            mb: 0.25,
                                            fontSize: "11.5px",
                                            fontWeight: 700,
                                            overflowWrap: "anywhere",
                                        }}
                                    >
                                        {textoContexto}
                                    </Typography>
                                )}
                                Confirma la aplicación en cada pieza antes de agregarla: el resumen es
                                orientativo.
                            </Alert>
                        )}

                        {/* Tarjetas de producto: las mismas del catálogo */}
                        {products.length > 0 && (
                            <Box
                                sx={{
                                    display: "grid",
                                    // Dos por renglon. `minmax(0, 1fr)` y no `1fr`:
                                    // con `1fr` la columna toma el min-content del
                                    // hijo y la rejilla desborda la burbuja.
                                    gridTemplateColumns: products.length > 1
                                        ? "repeat(2, minmax(0, 1fr))"
                                        : "minmax(0, 1fr)",
                                    gap: 0.75,
                                    width: "100%",
                                    mt: 1,
                                    // El aviso solo no basta: medido a 320×568, de
                                    // la tarjeta se ven 198 px con el aviso ya
                                    // arriba del todo, así que al desplazarse
                                    // hasta el precio el aviso se ha ido de la
                                    // pantalla. El marco sí acompaña al número.
                                    //
                                    // `outline` y no `border` ni `padding`: no
                                    // ocupa layout, así que las columnas siguen
                                    // siendo `minmax(0, 1fr)`. Los 4 px que se
                                    // sale caben en los 10 px de `px: 1.25` del
                                    // hilo —medido: 6 px de holgura y cero
                                    // desbordamiento horizontal.
                                    ...(textoContexto
                                        ? {
                                            outline: `2px solid ${ColorsEpico.ColorVibrantYellow}`,
                                            outlineOffset: "2px",
                                            borderRadius: "6px",
                                        }
                                        : {}),
                                }}
                            >
                                {products.map((product) => (
                                    <ProductCard
                                        key={`${message.id}-${product.productoID}`}
                                        product={product}
                                        compact
                                        style={{ width: "100%", maxWidth: "100%", margin: 0 }}
                                        onClickCompatibility={() => onClickCompatibility(product)}
                                        handleShowDiscountModal={() => onShowDiscounts(product.productoID)}
                                        onOpenDetail={onOpenDetail}
                                    />
                                ))}
                            </Box>
                        )}

                        {/* Salida al catálogo: lo que no cabe en el chat se ve completo allí.

                            Se pinta con `catalogo` y **no** con `consulta` y `total`:
                            la frase del chat puede no encontrar nada en el catálogo,
                            que busca literal —medido, «qué tipo de cintas tienes» da
                            66 al agente y cero al índice—, y su total tampoco sería el
                            de la pantalla a la que lleva. `catalogo` trae la frase ya
                            comprobada contra el índice y el total de esa frase; si no
                            hay ninguna que encuentre algo, no se ofrece el botón. */}
                        {!isUser && message.catalogo && message.catalogo.total > products.length && (
                            <Button
                                variant="outlined"
                                fullWidth
                                onClick={() => onSeeAllInCatalogue(message.catalogo!.consulta)}
                                sx={{
                                    mt: 1,
                                    minHeight: 44,
                                    fontSize: "12px",
                                    color: ColorsEpico.ColorPrimary,
                                    borderColor: ColorsEpico.ColorPrimary,
                                }}
                            >
                                Ver los {message.catalogo.total} resultados en el catálogo
                            </Button>
                        )}
                    </Box>
                );
            })}

            {/* Esperando al servicio. Un turno del agente tarda unos 5 segundos, así
                que el indicador no es un adorno: sin él la espera se lee como que
                el chat se colgó. */}
            {loading && (
                <Box
                    sx={{
                        alignSelf: "flex-start",
                        display: "flex",
                        alignItems: "center",
                        gap: 0.75,
                        px: 1.5,
                        py: 1.25,
                        borderRadius: "14px",
                        backgroundColor: ColorsEpico.ColorWhite,
                        boxShadow: "0 1px 3px rgba(0,0,0,.11)",
                        "@keyframes ania-jump": {
                            "0%,60%,100%": { transform: "translateY(0)", opacity: 0.4 },
                            "30%": { transform: "translateY(-5px)", opacity: 1 },
                        },
                    }}
                >
                    {[0, 1, 2].map((i) => (
                        <Box
                            key={i}
                            sx={{
                                width: 7,
                                height: 7,
                                borderRadius: "50%",
                                backgroundColor: ColorsEpico.ColorSecondary,
                                animation: "ania-jump 1.1s ease-in-out infinite",
                                animationDelay: `${i * 0.14}s`,
                                "@media (prefers-reduced-motion: reduce)": { animation: "none" },
                            }}
                        />
                    ))}
                    <Typography sx={{ ml: 0.5, fontSize: "10.5px", color: ColorsEpico.ColorNeutralGray }}>
                        buscando…
                    </Typography>
                </Box>
            )}
        </Box>
    );
};
