import { FC, useRef } from "react";
import { Box, IconButton, Tooltip, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import VolumeUpIcon from "@mui/icons-material/VolumeUp";
import VolumeOffIcon from "@mui/icons-material/VolumeOff";
//-- enums
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { AniaStatusEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
//-- interfaces
import { IChatMessage, IContextoPrecios } from "@/features/aiSearch/domain/interfaces/IAiSearchState";
import { IProduct } from "@/features/products/domain/interfaces/IProduct";
import { IOfertaRescate } from "@/features/aiSearch/domain/interfaces/IDictado";
//-- components
import { AniaAvatar } from "@/features/aiSearch/infrastructure/ui/aniaAvatar/AniaAvatar";
import { ChatThread } from "@/features/aiSearch/infrastructure/ui/aniaPanel/ChatThread";
import { ChatComposer } from "@/features/aiSearch/infrastructure/ui/aniaPanel/ChatComposer";
//-- hooks
import { useKeyboardInset } from "@/features/aiSearch/infrastructure/hooks/useKeyboardInset";

/**
 * El panel del chat de Ania.
 *
 * **Dos formas, decididas por breakpoint del `sx` y no por el flag de móvil.**
 * `getDimensions` devuelve `isMobileExperience: false` en el render de
 * hidratación, así que con el flag el panel se pintaría un frame como escritorio
 * dentro del teléfono y saltaría después. Con CSS ya es correcto en el primer
 * pintado.
 *
 * - **Por debajo de 900 px**: hoja inferior con el contrato que ya usan otras
 *   cuatro pantallas del proyecto —esquinas redondeadas arriba, tirador,
 *   `maxHeight` y `safe-area`—.
 * - **Desde 900 px**: panel fijo abajo a la derecha, que deja ver el catálogo
 *   detrás.
 *
 * ⚠️ **`z-index 1210`, y es un techo, no un gusto.** Las tarjetas de producto que
 * el panel contiene abren sus propios modales de MUI a **1300** (seleccionar
 * cliente, promociones). Si el panel estuviera por encima, esos modales se
 * pintarían detrás y el usuario no podría agregar nada desde el chat. Y 1210 está
 * por encima del `ModalDraggable` (1200), que puede coexistir en pantallas con
 * lead de telemarketing.
 *
 * ⚠️ **El panel se apoya sobre el teclado**, no en el borde de la pantalla. Con
 * `bottom: 0` el compositor se queda debajo del teclado en iOS y no se ve lo que
 * se escribe.
 */

/** Ancho del panel en escritorio. */
const PANEL_WIDTH = 456;

/**
 * @typedef {Object} AniaPanelProps
 * @property {IChatMessage[]} messages - Hilo de la conversación.
 * @property {IContextoPrecios} contextoActual - Cliente y sucursal del pedido
 * activo ahora, para que el hilo detecte los mensajes hidratados con otro.
 * @property {boolean} loading - Si se espera respuesta del servicio.
 * @property {string} assistantName - Nombre del asistente.
 * @property {AniaStatusEnum} status - Qué está haciendo, para el avatar.
 * @property {() => void} onClose - Cerrar el panel.
 * @property {() => void} onReset - Empezar una conversación nueva.
 * @property {(text: string) => void} onSend - Enviar un mensaje.
 * @property {(product: IProduct) => void} onClickCompatibility - Ver aplicaciones.
 * @property {(productId: number) => void} onShowDiscounts - Ver promoción.
 * @property {(query: string) => void} onSeeAllInCatalogue - Abrir la búsqueda en el catálogo.
 * @property {() => void} onOpenDetail - Se abrió el detalle de un producto del hilo.
 * @property {(oferta: IOfertaRescate) => void} onAceptarOferta - Acepta corregir una marca.
 * @property {(texto: string) => void} onEscribirAMano - Devuelve lo dictado al compositor.
 * @property {boolean} vozDisponible - El navegador puede hablar.
 * @property {boolean} vozActiva - Si Ania contesta en voz alta.
 * @property {() => void} onToggleVoz - Enciende o apaga la voz.
 * @property {boolean} micDisponible - El navegador puede dictar.
 * @property {boolean} escuchando - El micrófono está abierto.
 * @property {string} parcial - Lo que se va entendiendo mientras habla.
 * @property {string} errorVoz - Motivo por el que el micrófono falló.
 * @property {() => void} onEscuchar - Abre el micrófono.
 * @property {() => void} onDejarDeEscuchar - Cierra el micrófono.
 * @property {() => void} onDescartarError - Quita el aviso de error.
 * @property {(texto: string) => void} [onTextoChange] - Avisa de lo que hay escrito.
 * @property {{ texto: string; key: number }} [prefill] - Texto que hay que escribir
 * en la caja. Al cambiar `key` se vuelve a aplicar, aunque el texto sea el mismo.
 * @property {number} resetKey - Sube cada vez que se envía un turno.
 */
export type AniaPanelProps = {
    messages: IChatMessage[];
    contextoActual: IContextoPrecios;
    loading: boolean;
    assistantName: string;
    status: AniaStatusEnum;
    onClose: () => void;
    onReset: () => void;
    onSend: (text: string) => void;
    onClickCompatibility: (product: IProduct) => void;
    onShowDiscounts: (productId: number) => void;
    onSeeAllInCatalogue: (query: string) => void;
    onOpenDetail: () => void;
    onAceptarOferta: (oferta: IOfertaRescate) => void;
    onEscribirAMano: (texto: string) => void;
    vozDisponible: boolean;
    vozActiva: boolean;
    onToggleVoz: () => void;
    micDisponible: boolean;
    escuchando: boolean;
    parcial: string;
    errorVoz: string;
    onEscuchar: () => void;
    onDejarDeEscuchar: () => void;
    onDescartarError: () => void;
    onTextoChange?: (texto: string) => void;
    prefill?: { texto: string; key: number };
    resetKey: number;
};

/**
 * Panel del asistente.
 *
 * @param {AniaPanelProps} props - Propiedades del componente.
 * @returns {JSX.Element} El panel y su telón de cierre.
 */
export const AniaPanel: FC<AniaPanelProps> = ({
    messages,
    contextoActual,
    loading,
    assistantName,
    status,
    onClose,
    onReset,
    onSend,
    onClickCompatibility,
    onShowDiscounts,
    onSeeAllInCatalogue,
    onOpenDetail,
    onAceptarOferta,
    onEscribirAMano,
    vozDisponible,
    vozActiva,
    onToggleVoz,
    micDisponible,
    escuchando,
    parcial,
    errorVoz,
    onEscuchar,
    onDejarDeEscuchar,
    onDescartarError,
    onTextoChange,
    prefill,
    resetKey,
}) => {
    const keyboard = useKeyboardInset();

    /**
     * ¿El gesto que está terminando empezó sobre el telón?
     *
     * Sin esto, tocar el robot **no volvía a abrir el chat**: el panel se monta
     * durante el `pointerup` del toque, el navegador dispara después el `click`
     * sobre lo que haya quedado bajo el dedo —que ya es el telón, que ocupa toda
     * la pantalla— y el chat se cerraba en el mismo gesto que lo abría. Se veía
     * como un parpadeo, y salía o no según dónde estuviera el robot, que es lo que
     * hacía que moverlo pareciera arreglarlo.
     *
     * Arregla también el caso simétrico: arrastrar desde dentro del panel y soltar
     * fuera ya no lo cierra.
     */
    const empezoEnElVelo = useRef(false);

    return (
        <>
            {/* Telón: un clic fuera del panel lo cierra.
                Va a 1209, justo debajo del panel (1210) y **debajo de los modales
                de las tarjetas** (1300), así que tocar «seleccionar cliente» o el
                modal de promociones no cierra el chat por detrás.

                ⚠️ El chat con el telón puesto **es modal también en escritorio**:
                un telón a pantalla completa intercepta el clic aunque sea
                transparente. Antes decía aquí que en escritorio se dejaba
                transparente «para no apagar el catálogo», y eso era falso: el
                catálogo quedaba igual de bloqueado, solo que sin decirlo. Se
                oscurece un poco en los dos tamaños, para que el usuario vea que
                está bloqueado y sepa que tocando fuera se cierra. */}
            <Box
                onPointerDown={() => {
                    empezoEnElVelo.current = true;
                }}
                onClick={() => {
                    // Solo cierra el gesto que EMPEZO en el telon. El toque que
                    // abre el panel empieza en el robot, cuando el telon todavia
                    // no existe, asi que su `click` no cuenta.
                    if (!empezoEnElVelo.current) return;
                    empezoEnElVelo.current = false;
                    onClose();
                }}
                aria-hidden="true"
                sx={{
                    position: "fixed",
                    inset: 0,
                    zIndex: 1209,
                    backgroundColor: { xs: "rgba(0,0,0,.32)", md: "rgba(0,0,0,.14)" },
                }}
            />

            <Box
                role="dialog"
                aria-label={`Chat de ${assistantName}`}
                sx={{
                    position: "fixed",
                    zIndex: 1210,
                    display: "flex",
                    flexDirection: "column",
                    overflow: "hidden",
                    backgroundColor: ColorsEpico.ColorWhite,

                    // ── Hoja inferior (<900px)
                    left: 0,
                    right: 0,
                    bottom: `${keyboard}px`,
                    top: "auto",
                    maxHeight: `calc(88% - ${keyboard}px)`,
                    borderRadius: "14px 14px 0 0",
                    boxShadow: "0 -10px 34px rgba(9,17,33,.3)",
                    animation: "ania-slideup .3s ease-out both",

                    // ── Panel lateral (>=900px)
                    "@media (min-width:900px)": {
                        left: "auto",
                        right: 16,
                        bottom: 16,
                        top: 88,
                        width: PANEL_WIDTH,
                        maxHeight: "none",
                        borderRadius: "14px",
                        animation: "ania-fadein .24s ease-out both",
                    },

                    "@keyframes ania-slideup": {
                        from: { transform: "translateY(100%)" },
                        to: { transform: "none" },
                    },
                    "@keyframes ania-fadein": {
                        from: { opacity: 0, transform: "translateY(12px)" },
                        to: { opacity: 1, transform: "none" },
                    },
                    "@media (prefers-reduced-motion: reduce)": { animation: "none" },
                }}
            >
                {/* Cabecera */}
                <Box
                    sx={{
                        flex: "0 0 auto",
                        backgroundColor: ColorsEpico.ColorPrimary,
                        color: ColorsEpico.ColorWhite,
                        display: "flex",
                        alignItems: "center",
                        gap: 1,
                        pl: 1.5,
                        pr: 0.5,
                        py: 0.75,
                    }}
                >
                    <Box sx={{ flex: "0 0 auto", width: 34, height: 34 }}>
                        <AniaAvatar status={status} size={34} name={assistantName} />
                    </Box>
                    <Box sx={{ flex: "1 1 auto", minWidth: 0 }}>
                        <Typography sx={{ fontWeight: 700, fontSize: "13px", lineHeight: 1.2 }}>{assistantName}</Typography>
                        <Typography sx={{ fontSize: "10px", lineHeight: 1.2, opacity: 0.82 }}>
                            {escuchando
                                ? "te escucho…"
                                : status === AniaStatusEnum.Speaking
                                    ? "hablando"
                                    : "asistente del catálogo"}
                        </Typography>
                    </Box>

                    {/* Voz de Ania. Solo si el navegador puede hablar. */}
                    {vozDisponible && (
                        <Tooltip title={vozActiva ? "Silenciar a " + assistantName : "Que me conteste en voz alta"}>
                            <IconButton
                                onClick={onToggleVoz}
                                aria-label={vozActiva ? "Silenciar la voz" : "Activar la voz"}
                                sx={{ width: 44, height: 44, color: ColorsEpico.ColorWhite, flex: "0 0 auto" }}
                            >
                                {vozActiva
                                    ? <VolumeUpIcon sx={{ fontSize: 20 }} />
                                    : <VolumeOffIcon sx={{ fontSize: 20, opacity: 0.6 }} />}
                            </IconButton>
                        </Tooltip>
                    )}

                    <Tooltip title="Empezar una conversación nueva">
                        <IconButton
                            onClick={onReset}
                            aria-label="Empezar una conversación nueva"
                            sx={{ width: 44, height: 44, color: ColorsEpico.ColorWhite, flex: "0 0 auto" }}
                        >
                            <RestartAltIcon sx={{ fontSize: 20 }} />
                        </IconButton>
                    </Tooltip>
                    <IconButton
                        onClick={onClose}
                        aria-label="Cerrar el chat"
                        sx={{ width: 44, height: 44, color: ColorsEpico.ColorWhite, flex: "0 0 auto" }}
                    >
                        <CloseIcon sx={{ fontSize: 20 }} />
                    </IconButton>
                </Box>

                <ChatThread
                    messages={messages}
                    contextoActual={contextoActual}
                    loading={loading}
                    onClickCompatibility={onClickCompatibility}
                    onShowDiscounts={onShowDiscounts}
                    onSeeAllInCatalogue={onSeeAllInCatalogue}
                    onOpenDetail={onOpenDetail}
                    onAceptarOferta={onAceptarOferta}
                    onEscribirAMano={onEscribirAMano}
                    keyboardInset={keyboard}
                />

                <ChatComposer
                    disabled={loading}
                    onSend={onSend}
                    micDisponible={micDisponible}
                    escuchando={escuchando}
                    parcial={parcial}
                    errorVoz={errorVoz}
                    onEscuchar={onEscuchar}
                    onDejarDeEscuchar={onDejarDeEscuchar}
                    onDescartarError={onDescartarError}
                    onTextoChange={onTextoChange}
                    prefill={prefill}
                    resetKey={resetKey}
                />
            </Box>
        </>
    );
};
