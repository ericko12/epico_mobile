import { FC, useEffect, useId, useRef, useState } from "react";
import { Box } from "@mui/material";
import { AniaStatusEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
import { ASSISTANT_DEFAULT_NAME } from "@/features/products/domain/data/searchProducts.config";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";

/**
 * Ania, el asistente del catálogo.
 *
 * **Casco con visor de pantalla, sobre la paleta de la casa.** El cambio de rumbo
 * respecto a las vueltas anteriores —que perseguían a EVA de Wall-E— viene de una
 * referencia de mascota corporativa, y trae tres ventajas que EVA no daba:
 *
 * 1. **La cara es una pantalla, no unos ojos.** Un visor oscuro con ojos de arco
 *    permite un repertorio de expresiones enorme sin cambiar la silueta: arcos
 *    contentos, ojos abiertos, aspas de mareo, onda de voz. Con dos elipses sobre
 *    blanco no había de dónde sacar eso.
 * 2. **Es de esta aplicación.** El azul marino y el naranja son literalmente
 *    `ColorPrimary` y `ColorBrightOrange` del proyecto, no un blanco genérico.
 * 3. **Ya no hay problema de contraste sobre fondo claro.** El visor da 16.23:1 y
 *    el azul marino 10.36:1 sobre blanco, sin depender de trazos finos ni de
 *    sombras. La EVA blanca vivía al borde de desaparecer, y ese era su defecto de
 *    fondo. Aquí el problema se **invierte**, y de eso se ocupa `CANTO`.
 *
 * **El marco de escaneo del visor no es un adorno**: son las cuatro esquinas de un
 * visor de búsqueda, y este asistente busca refacciones. Es el detalle que lo ata
 * al catálogo, igual que en la referencia.
 *
 * Se anima con CSS y no con `framer-motion` aunque esté en el proyecto: son
 * animaciones en bucle sobre un SVG estático, y las de CSS las mueve el compositor
 * sin trabajo de JavaScript. En un botón que flota sobre una lista con
 * desplazamiento eso se nota. Todo el movimiento respeta `prefers-reduced-motion`.
 */

/** Cuánto se desplazan los ojos al seguir al puntero, en unidades del `viewBox`. */
const EYE_TRACK = 2;

/**
 * El azul de los ojos y las luces.
 *
 * No está en `ColorsEpico` porque no es un color de interfaz: es la luz del robot.
 * Se eligió el más claro que sigue leyéndose sobre el visor casi negro.
 */
const LUZ = "#29B6FF";

/**
 * Canto blanco de las piezas azul marino.
 *
 * ⚠️ **Existe por la cabecera del chat, no por estética.** Esa cabecera está
 * pintada de `ColorPrimary`, que es exactamente el mismo azul marino del cuerpo y
 * de las orejeras: sin este canto, ahí las dos piezas se funden con el fondo y
 * Ania se ve como una cabeza flotando. Sobre los fondos claros el canto no se nota
 * —blanco sobre blanco— y sobre el azul la recorta con 10.36:1.
 *
 * Es el mismo truco que el visor pero al revés: allí una pieza oscura ancla la
 * figura sobre fondo claro; aquí una clara la ancla sobre fondo oscuro.
 */
const CANTO = { color: "#FFFFFF", opacity: 0.85, width: 1.4 };

/** Casco: cúpula arriba, mandíbula ancha y recta abajo. 60 × 53. */
const CASCO_PATH =
    "M20 34 C20 15, 33 6, 50 6 C67 6, 80 15, 80 34 L80 44 C80 54, 68 59, 50 59 C32 59, 20 54, 20 44 Z";

/** Aleta naranja. Va **detrás** del casco, así parece que nace de dentro. */
const ALETA_PATH = "M32 18 Q27 5 35 1 Q42 8 38 20 Z";

/** Orejeras: discos a los lados del casco, con su anillo de luz. */
const OREJA = { y: 38, r: 8.5, xLeft: 17, xRight: 83 };

/** Visor: la pantalla donde vive toda la expresión. */
const VISOR = { x: 27, y: 22, w: 46, h: 26, rx: 11 };

/**
 * Marco de escaneo: las cuatro esquinas dentro del visor.
 *
 * Es lo que dice «esto busca». Se dibuja como cuatro codos sueltos y no como un
 * rectángulo, que es justo lo que lo hace leerse como mira y no como borde.
 */
const MARCO = { inset: 4, brazo: 4 };

/** Ojos: centro de cada uno dentro del visor. */
const OJO = { y: 35, xLeft: 40, xRight: 60, ancho: 8, alto: 7.5 };

/** Cuerpo chibi: pequeño a propósito, para que mande la cara. */
const CUERPO = { x: 31, y: 60, w: 38, h: 30, rx: 11 };
const BRAZO = { w: 10, h: 18, rx: 5, y: 64, xLeft: 20, xRight: 70, tilt: 8 };

/**
 * @typedef {Object} AniaAvatarProps
 * @property {AniaStatusEnum} status - Qué está haciendo el asistente.
 * @property {number} [size] - Lado del avatar en píxeles.
 * @property {boolean} [trackPointer] - Si los ojos siguen al puntero.
 * @property {string} [name] - Nombre del asistente, para el texto alternativo.
 */
export type AniaAvatarProps = {
    status: AniaStatusEnum;
    size?: number;
    trackPointer?: boolean;
    name?: string;
};

/**
 * Componente del avatar.
 *
 * @param {AniaAvatarProps} props - Propiedades del componente.
 * @returns {JSX.Element} El robot.
 */
export const AniaAvatar: FC<AniaAvatarProps> = ({
    status,
    size = 64,
    trackPointer = false,
    name = ASSISTANT_DEFAULT_NAME,
}) => {
    const rootRef = useRef<HTMLDivElement>(null);
    const [blink, setBlink] = useState(false);
    const [eye, setEye] = useState({ x: 0, y: 0 });

    /**
     * Sufijo único para los identificadores del SVG.
     *
     * Hace falta porque hay más de un avatar en pantalla a la vez —el botón
     * flotante y la cabecera del panel— y los degradados se referencian por `id`.
     * Con identificadores fijos, dos avatares comparten el mismo `id` y el
     * navegador resuelve las dos referencias al primero.
     */
    const uid = useId().replace(/:/g, "");

    const thinking = status === AniaStatusEnum.Thinking;
    const dragging = status === AniaStatusEnum.Dragging;
    const happy = status === AniaStatusEnum.Greeting;
    const dizzy = status === AniaStatusEnum.Dizzy;
    const listening = status === AniaStatusEnum.Listening;
    const speaking = status === AniaStatusEnum.Speaking;

    /** Ojos abiertos cuando está atenta; arcos contentos el resto del tiempo. */
    const abiertos = listening || thinking;

    /** El halo cambia de color según lo que esté pasando. */
    const haloRgb = dizzy
        ? "255, 143, 0"        // ámbar: algo va raro
        : listening
            ? "34, 174, 0"    // verde: el micrófono está abierto
            : "27, 56, 146";  // azul de marca: lo normal

    /** Parpadeo. Se pausa cuando los ojos ya tienen otra animación propia. */
    useEffect(() => {
        if (thinking || dizzy || listening || speaking) return;
        const id = setInterval(() => {
            setBlink(true);
            setTimeout(() => setBlink(false), 130);
        }, 4200);
        return () => clearInterval(id);
    }, [thinking, dizzy, listening, speaking]);

    /** Los ojos siguen al puntero: es lo que hace que parezca atenta. */
    useEffect(() => {
        if (!trackPointer) return;
        const onMove = (e: PointerEvent) => {
            const el = rootRef.current;
            if (!el) return;
            const r = el.getBoundingClientRect();
            const angle = Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2));
            setEye({ x: Math.cos(angle) * EYE_TRACK, y: Math.sin(angle) * (EYE_TRACK * 0.7) });
        };
        window.addEventListener("pointermove", onMove);
        return () => window.removeEventListener("pointermove", onMove);
    }, [trackPointer]);

    const eyeTransform = blink
        ? "scaleY(0.14)"
        : dizzy || thinking
            ? undefined
            : `translate(${eye.x}px, ${eye.y}px)${listening ? " scaleY(1.15)" : ""}`;

    /**
     * Un ojo, dibujado según lo que esté pasando.
     *
     * La cara es una pantalla, así que la expresión se cambia cambiando el dibujo
     * y no deformando una elipse. Es lo que permite que el mareo sean dos aspas y
     * no unos ojos girando, que a 34 px no se entendía.
     *
     * @param {number} cx - Centro del ojo.
     * @returns {JSX.Element} El ojo.
     */
    const ojo = (cx: number) => {
        if (dizzy) {
            const b = OJO.ancho * 0.62;
            return (
                <g
                    className="ania-eye"
                    style={{ transform: eyeTransform }}
                    stroke={LUZ}
                    strokeWidth="3.4"
                    strokeLinecap="round"
                >
                    <line x1={cx - b} y1={OJO.y - b} x2={cx + b} y2={OJO.y + b} />
                    <line x1={cx + b} y1={OJO.y - b} x2={cx - b} y2={OJO.y + b} />
                </g>
            );
        }
        if (abiertos) {
            return (
                <ellipse
                    className="ania-eye"
                    cx={cx}
                    cy={OJO.y}
                    rx={OJO.ancho * 0.78}
                    ry={OJO.alto * 0.78}
                    fill={`url(#aniaLuz-${uid})`}
                    style={{ transform: eyeTransform }}
                />
            );
        }
        // Arco contento: la cara por defecto, igual que en la referencia.
        return (
            <path
                className="ania-eye"
                d={`M${cx - OJO.ancho} ${OJO.y + 3.5} Q${cx} ${OJO.y - 6.5} ${cx + OJO.ancho} ${OJO.y + 3.5}`}
                fill="none"
                stroke={LUZ}
                strokeWidth="4.2"
                strokeLinecap="round"
                style={{ transform: eyeTransform }}
            />
        );
    };

    /** Los cuatro codos del marco de escaneo. */
    const marco = () => {
        const x1 = VISOR.x + MARCO.inset;
        const x2 = VISOR.x + VISOR.w - MARCO.inset;
        const y1 = VISOR.y + MARCO.inset + 1;
        const y2 = VISOR.y + VISOR.h - MARCO.inset - 1;
        const b = MARCO.brazo;
        const codos = [
            `M${x1} ${y1 + b} L${x1} ${y1} L${x1 + b} ${y1}`,
            `M${x2 - b} ${y1} L${x2} ${y1} L${x2} ${y1 + b}`,
            `M${x1} ${y2 - b} L${x1} ${y2} L${x1 + b} ${y2}`,
            `M${x2 - b} ${y2} L${x2} ${y2} L${x2} ${y2 - b}`,
        ];
        return codos.map((d) => (
            <path
                key={d}
                className="ania-marco"
                d={d}
                fill="none"
                stroke={LUZ}
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity=".55"
            />
        ));
    };

    return (
        <Box
            ref={rootRef}
            sx={{
                width: size,
                height: size,
                position: "relative",
                display: "grid",
                placeItems: "center",
                pointerEvents: "none",
                "&::before": {
                    content: '""',
                    position: "absolute",
                    inset: -size * 0.14,
                    borderRadius: "50%",
                    background: `radial-gradient(circle, rgba(${haloRgb},.46) 0%, rgba(${haloRgb},0) 66%)`,
                    animation: (thinking || listening || speaking)
                        ? "ania-pulse 1.1s ease-in-out infinite"
                        : "ania-pulse 3.6s ease-in-out infinite",
                },
                "& .ania-body": {
                    width: "100%",
                    height: "100%",
                    filter: `drop-shadow(0 ${size * 0.08}px ${size * 0.13}px rgba(12,25,54,.34))`,
                    animation: dizzy ? "ania-dizzy .55s ease-in-out infinite" : "ania-bob 3.6s ease-in-out infinite",
                    animationPlayState: dragging ? "paused" : "running",
                    transform: dragging ? "scale(1.08)" : undefined,
                    transition: "transform .18s ease-out",
                },
                // La cabeza se ladea sola: es lo que le da carácter en reposo, y
                // pensando exagera el gesto.
                "& .ania-head": {
                    transformBox: "fill-box",
                    transformOrigin: "center bottom",
                    animation: dizzy
                        ? "none"
                        : thinking
                            ? "ania-head-think 1.6s ease-in-out infinite"
                            : "ania-head 3.6s ease-in-out infinite",
                },
                "& .ania-arm": {
                    transformBox: "fill-box",
                    transformOrigin: "top center",
                    animation: dizzy
                        ? "ania-arm-dizzy .55s ease-in-out infinite"
                        : listening
                            ? "ania-arm-up .9s ease-in-out infinite alternate"
                            : "ania-arm 3.6s ease-in-out infinite",
                },
                "& .ania-eye": {
                    transformBox: "fill-box",
                    transformOrigin: "center",
                    transition: "transform .12s ease-out",
                    animation: dizzy
                        ? "ania-wobble .7s ease-in-out infinite"
                        : thinking
                            ? "ania-think 1.1s ease-in-out infinite"
                            : "none",
                },
                // El marco de escaneo late cuando está trabajando: es la señal de
                // «estoy buscando» sin escribir una palabra.
                "& .ania-marco": {
                    animation: (thinking || listening)
                        ? "ania-scan 1.3s ease-in-out infinite"
                        : "none",
                },
                // Los anillos de las orejeras laten al escuchar.
                "& .ania-oreja": {
                    animation: listening ? "ania-scan .9s ease-in-out infinite" : "none",
                },
                // La onda de voz, dentro del visor, mientras habla.
                "& .ania-onda": {
                    transformBox: "fill-box",
                    transformOrigin: "center",
                    animation: "ania-onda .5s ease-in-out infinite alternate",
                },
                "@keyframes ania-bob": {
                    "0%,100%": { transform: `translateY(0) rotate(-1.2deg)${dragging ? " scale(1.08)" : ""}` },
                    "50%": { transform: `translateY(-${size * 0.08}px) rotate(1.2deg)${dragging ? " scale(1.08)" : ""}` },
                },
                "@keyframes ania-head": {
                    "0%,100%": { transform: "rotate(-2.5deg)" },
                    "50%": { transform: "rotate(2.5deg)" },
                },
                "@keyframes ania-head-think": {
                    "0%,100%": { transform: "rotate(-8deg) translateY(0)" },
                    "50%": { transform: "rotate(8deg) translateY(-1px)" },
                },
                "@keyframes ania-arm": {
                    "0%,100%": { transform: "rotate(2deg)" },
                    "50%": { transform: "rotate(-3deg)" },
                },
                "@keyframes ania-arm-up": {
                    from: { transform: "rotate(0deg)" },
                    to: { transform: "rotate(-16deg) translateY(-1px)" },
                },
                "@keyframes ania-arm-dizzy": {
                    "0%,100%": { transform: "rotate(12deg)" },
                    "50%": { transform: "rotate(-12deg)" },
                },
                "@keyframes ania-pulse": {
                    "0%,100%": { opacity: 0.3, transform: "scale(.94)" },
                    "50%": { opacity: 0.6, transform: "scale(1.06)" },
                },
                "@keyframes ania-think": {
                    "0%,100%": { transform: "scaleY(1) translateY(0)" },
                    "50%": { transform: "scaleY(.55) translateY(1.4px)" },
                },
                "@keyframes ania-scan": {
                    "0%,100%": { opacity: 0.3 },
                    "50%": { opacity: 1 },
                },
                "@keyframes ania-onda": {
                    from: { transform: "scaleY(.35)" },
                    to: { transform: "scaleY(1)" },
                },
                // Mareada: las aspas se bambolean y el cuerpo se tambalea.
                "@keyframes ania-wobble": {
                    "0%,100%": { transform: "rotate(-16deg)" },
                    "50%": { transform: "rotate(16deg)" },
                },
                "@keyframes ania-dizzy": {
                    "0%": { transform: "translateY(2px) rotate(-10deg)" },
                    "50%": { transform: "translateY(4px) rotate(10deg)" },
                    "100%": { transform: "translateY(2px) rotate(-10deg)" },
                },
                "@media (prefers-reduced-motion: reduce)": {
                    "&::before, & .ania-body, & .ania-head, & .ania-arm, & .ania-eye, & .ania-marco, & .ania-oreja, & .ania-onda": {
                        animation: "none",
                    },
                },
            }}
        >
            <svg
                className="ania-body"
                viewBox="0 0 100 100"
                role="img"
                aria-label={`${name}, asistente del catálogo`}
                style={{ overflow: "visible" }}
            >
                <defs>
                    <linearGradient id={`aniaCasco-${uid}`} x1="0.2" y1="0" x2="0.8" y2="1">
                        <stop offset="0" stopColor="#FFFFFF" />
                        <stop offset=".62" stopColor="#F1F5FA" />
                        <stop offset="1" stopColor="#D3DEEC" />
                    </linearGradient>
                    <linearGradient id={`aniaVisor-${uid}`} x1="0.2" y1="0" x2="0.8" y2="1">
                        <stop offset="0" stopColor="#1E3268" />
                        <stop offset=".5" stopColor="#101E45" />
                        <stop offset="1" stopColor="#08122C" />
                    </linearGradient>
                    <linearGradient id={`aniaMarino-${uid}`} x1="0.2" y1="0" x2="0.8" y2="1">
                        <stop offset="0" stopColor="#2A4CB0" />
                        <stop offset="1" stopColor={ColorsEpico.ColorPrimary} />
                    </linearGradient>
                    <radialGradient id={`aniaLuz-${uid}`} cx=".4" cy=".32" r=".85">
                        <stop offset="0" stopColor="#8FE0FF" />
                        <stop offset="1" stopColor={LUZ} />
                    </radialGradient>
                </defs>

                {/* ── Cuerpo. Pequeño y azul marino: la cara es la que manda. */}
                {[BRAZO.xLeft, BRAZO.xRight].map((x, i) => (
                    <rect
                        key={x}
                        className="ania-arm"
                        x={x}
                        y={BRAZO.y}
                        width={BRAZO.w}
                        height={BRAZO.h}
                        rx={BRAZO.rx}
                        transform={`rotate(${i === 0 ? -BRAZO.tilt : BRAZO.tilt} ${x + BRAZO.w / 2} ${BRAZO.y})`}
                        fill={`url(#aniaCasco-${uid})`}
                        stroke={ColorsEpico.ColorPrimary}
                        strokeWidth="1.6"
                        style={{ animationDelay: i === 1 ? "-1.8s" : undefined }}
                    />
                ))}
                <rect
                    x={CUERPO.x}
                    y={CUERPO.y}
                    width={CUERPO.w}
                    height={CUERPO.h}
                    rx={CUERPO.rx}
                    fill={`url(#aniaMarino-${uid})`}
                    stroke={CANTO.color}
                    strokeOpacity={CANTO.opacity}
                    strokeWidth={CANTO.width}
                />
                {/* Peto claro y su franja de luz. */}
                <rect x="39" y="66" width="22" height="19" rx="8" fill={`url(#aniaCasco-${uid})`} />
                <rect x="44" y="72" width="12" height="3" rx="1.5" fill={LUZ} opacity=".9" />

                {/* ── Cabeza */}
                <g className="ania-head">
                    {/* La aleta va detrás del casco, así parece que nace de dentro. */}
                    <path d={ALETA_PATH} fill={ColorsEpico.ColorBrightOrange} />

                    {/* Orejeras, con su anillo de luz. */}
                    {[OREJA.xLeft, OREJA.xRight].map((cx) => (
                        <g key={cx}>
                            <circle
                                cx={cx}
                                cy={OREJA.y}
                                r={OREJA.r}
                                fill={`url(#aniaMarino-${uid})`}
                                stroke={CANTO.color}
                                strokeOpacity={CANTO.opacity}
                                strokeWidth={CANTO.width}
                            />
                            <circle
                                className="ania-oreja"
                                cx={cx}
                                cy={OREJA.y}
                                r={OREJA.r - 2.6}
                                fill="none"
                                stroke={LUZ}
                                strokeWidth="1.8"
                                opacity=".85"
                            />
                        </g>
                    ))}

                    <path d={CASCO_PATH} fill={`url(#aniaCasco-${uid})`} />
                    {/* Sien azul marino a cada lado: es lo que le da el casco. */}
                    <path
                        d="M20 34 C20 22, 25 14, 32 10 L32 24 C28 27, 26 31, 26 36 L26 47 C22 45, 20 42, 20 40 Z"
                        fill={`url(#aniaMarino-${uid})`}
                        opacity=".92"
                    />
                    <path
                        d="M80 34 C80 22, 75 14, 68 10 L68 24 C72 27, 74 31, 74 36 L74 47 C78 45, 80 42, 80 40 Z"
                        fill={`url(#aniaMarino-${uid})`}
                        opacity=".92"
                    />
                    {/* Brillo del casco. */}
                    <ellipse cx="40" cy="15" rx="9" ry="4.5" fill="#FFFFFF" opacity=".75" transform="rotate(-16 40 15)" />

                    {/* Visor: la pantalla. */}
                    <rect
                        x={VISOR.x}
                        y={VISOR.y}
                        width={VISOR.w}
                        height={VISOR.h}
                        rx={VISOR.rx}
                        fill={`url(#aniaVisor-${uid})`}
                    />
                    {marco()}
                    {ojo(OJO.xLeft)}
                    {ojo(OJO.xRight)}

                    {/* Onda de voz: solo mientras habla, y dentro del visor. */}
                    {speaking && [45, 50, 55].map((x, i) => (
                        <rect
                            key={x}
                            className="ania-onda"
                            x={x - 1.4}
                            y="41.5"
                            width="2.8"
                            height="5"
                            rx="1.4"
                            fill={LUZ}
                            style={{ animationDelay: `${i * 0.12}s` }}
                        />
                    ))}
                </g>
            </svg>
        </Box>
    );
};
