import { FC, useCallback, useEffect, useRef, useState } from "react";
import { Box, Typography } from "@mui/material";
//-- enums
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { AniaStatusEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
//-- interfaces
import { IAniaPosition } from "@/features/aiSearch/domain/interfaces/IAiSearchState";
//-- components
import { AniaAvatar } from "@/features/aiSearch/infrastructure/ui/aniaAvatar/AniaAvatar";
//-- hooks
import { useKeyboardInset } from "@/features/aiSearch/infrastructure/hooks/useKeyboardInset";

/**
 * El botón flotante de Ania.
 *
 * Tres comportamientos que se pidieron explícitamente y que conviven en el mismo
 * gesto:
 *
 * - **Un toque abre el chat.** Toque es cualquier pulsación que no se mueva, sin
 *   importar cuánto dure: el tiempo no distingue nada útil, y exigir rapidez hacía
 *   que apoyar el dedo un segundo no hiciera absolutamente nada.
 * - **Mantener presionado y arrastrar la mueve**, y se queda donde se suelte. Lo
 *   que separa las dos cosas es el desplazamiento: más de 8 px es arrastre.
 * - **Agitarla la marea**, contando cambios de sentido y no velocidad.
 * - **Con el teclado abierto sube**, y al cerrarlo vuelve exactamente a su sitio.
 *
 * Sobre el `z-index`: **1050**, que es el hueco correcto entre lo que ya existe.
 * Por encima del submenú móvil (1000) y del contenido, y por debajo del `AppBar`
 * (1100 implícito de MUI), del `Drawer` del menú (1200) y de los diálogos (1300).
 * Con `bottom: 0` quedaría detrás de la barra inferior de 70 px, que es un
 * anti-patrón ya documentado del proyecto: de ahí el hueco reservado.
 */

/** Lado del botón. Cumple de sobra el objetivo táctil de 44 px. */
const FAB_SIZE = 64;

/**
 * Id del elemento junto al que nace el asistente en escritorio: el botón
 * «Buscar». Si no está en la pantalla, se cae a la esquina.
 *
 * Es el **botón** y no el contenedor de la barra a propósito: el contenedor mide
 * el 42 % del ancho disponible, así que anclarse a su borde derecho dejaba al
 * asistente a doscientos píxeles del botón, flotando en medio de la nada.
 */
const DESKTOP_ANCHOR_ID = "catalogueSearchButton";

/** Separación entre el botón «Buscar» y el asistente. Pegada, no suelta. */
const ANCHOR_GAP = 6;

/** Ancho del globo de presentación. */
const BUBBLE_WIDTH = 230;

/** Cambios de sentido que hay que hacer para marearla. */
const SHAKE_REVERSALS = 5;

/** Ventana en la que se cuentan esos cambios de sentido. */
const SHAKE_WINDOW_MS = 1400;

/** Desplazamiento mínimo entre cambios para que cuente como sacudida. */
const SHAKE_MIN_DELTA = 14;

/** Ancho a partir del cual la experiencia es de escritorio. */
const DESKTOP_MIN_WIDTH = 900;

/** Cuánto se espera a que aparezca la barra de búsqueda antes de rendirse. */
const ANCHOR_WAIT_MS = 4000;

/** Margen mínimo a los bordes de la ventana. */
const EDGE = 12;

/** Hueco que dejan libre la barra inferior móvil (70 px) y su safe-area. */
const BOTTOM_RESERVED = 82;

/** Alto del `AppBar`, para que el robot no se le suba encima. */
const TOP_RESERVED = 64;

/** Desplazamiento a partir del cual el gesto deja de ser un toque. */
const TAP_SLOP = 8;

/**
 * @typedef {Object} AniaFabProps
 * @property {AniaStatusEnum} status - Estado que anima el avatar.
 * @property {IAniaPosition | null} position - Posición guardada, si hay una.
 * @property {boolean} showGreeting - Si se enseña el globo de presentación.
 * @property {() => void} onOpen - Se llama al tocar el botón.
 * @property {() => void} onDismissGreeting - Se llama al descartar el saludo.
 * @property {(position: IAniaPosition) => void} onMoveEnd - Se llama al soltar.
 */
export type AniaFabProps = {
    status: AniaStatusEnum;
    /** Nombre del asistente, tal como lo da el servicio. */
    assistantName: string;
    /** Se llama cuando el usuario la agita de un lado a otro. */
    onShake: () => void;
    position: IAniaPosition | null;
    showGreeting: boolean;
    onOpen: () => void;
    onDismissGreeting: () => void;
    onMoveEnd: (position: IAniaPosition) => void;
};

/**
 * Botón flotante arrastrable del asistente.
 *
 * @param {AniaFabProps} props - Propiedades del componente.
 * @returns {JSX.Element} El botón y, si toca, su globo de diálogo.
 */
export const AniaFab: FC<AniaFabProps> = ({
    status,
    assistantName,
    position,
    showGreeting,
    onOpen,
    onDismissGreeting,
    onMoveEnd,
    onShake,
}) => {
    const keyboard = useKeyboardInset();
    const btnRef = useRef<HTMLButtonElement>(null);

    /** Posición viva, en distancias a las esquinas derecha e inferior. */
    const [pos, setPos] = useState<IAniaPosition>(
        position ?? { right: EDGE, bottom: BOTTOM_RESERVED }
    );
    const [dragging, setDragging] = useState(false);

    /**
     * El `bottom` que se está pintando ahora mismo.
     *
     * Es el guardado o el elevado por el teclado, el que toque. El gesto de
     * arrastre parte de aquí para que el robot siga al dedo también con el teclado
     * abierto, y para que lo que se persiste coincida con lo que se ve.
     */
    const bottomPintado = useRef(0);

    // Estado del gesto en curso. En una `ref` porque cambia en cada `pointermove`
    // y volver a renderizar por eso haría el arrastre a saltos.
    const gesture = useRef({
        id: -1, startX: 0, startY: 0, at: 0, moved: false, right: 0, bottom: 0,
        // Rastro de la sacudida: último sentido en el eje X, cuántas veces cambió,
        // cuándo empezó la cuenta, dónde estaba el dedo y si ya se marea este gesto.
        dir: 0, reversals: 0, shakeAt: 0, lastX: 0, dizzyDone: false,
    });

    /** Si la posición guardada cambia por fuera, se adopta. */
    useEffect(() => {
        if (position) setPos(position);
    }, [position]);

    /**
     * Posición de nacimiento en escritorio: al lado de la barra de búsqueda.
     *
     * En móvil se queda en la esquina inferior derecha, que es donde el pulgar la
     * alcanza. En escritorio no hay pulgar y la esquina queda lejos de donde se
     * está trabajando, así que nace junto a la caja de búsqueda —y desde ahí el
     * usuario la lleva donde quiera—.
     *
     * Solo aplica **la primera vez**: si el usuario ya la movió, su posición
     * manda y no se recalcula nada.
     */
    useEffect(() => {
        if (position) return;
        if (typeof window === "undefined" || window.innerWidth < DESKTOP_MIN_WIDTH) return;

        /**
         * Coloca el asistente al lado de la barra si ya está pintada.
         *
         * ⚠️ No basta con buscarla al montar. El asistente vive en el layout del
         * catálogo y la barra de búsqueda vive en el subheader del layout de
         * arriba, que la enseña **según el breadcrumb** — y el breadcrumb lo pone
         * un `useEffect` de `ProductCatalogue`, que corre *después*. En el primer
         * intento el ancla todavía no existe, y por eso Ania aparecía en la
         * esquina. Se vuelve a intentar con un observador del DOM hasta que
         * aparece, con un tope para no quedarse mirando para siempre.
         *
         * @returns {boolean} `true` si consiguió colocarse.
         */
        const place = (): boolean => {
            const anchor = document.getElementById(DESKTOP_ANCHOR_ID);
            if (!anchor) return false;

            const r = anchor.getBoundingClientRect();
            if (r.width === 0 && r.height === 0) return false;

            // `position: fixed` mide contra la ventana, igual que
            // getBoundingClientRect, así que las dos medidas son comparables.
            setPos(clamp({
                right: window.innerWidth - (r.right + ANCHOR_GAP) - FAB_SIZE,
                bottom: window.innerHeight - (r.top + r.height / 2 + FAB_SIZE / 2),
            }));
            return true;
        };

        if (place()) return;

        const observer = new MutationObserver(() => {
            if (place()) observer.disconnect();
        });
        observer.observe(document.body, { childList: true, subtree: true });

        // Si la barra no llega —otra pantalla del catálogo, por ejemplo—, se deja
        // de observar y el asistente se queda en la esquina, que es un buen sitio.
        const stop = setTimeout(() => observer.disconnect(), ANCHOR_WAIT_MS);

        return () => {
            observer.disconnect();
            clearTimeout(stop);
        };
        // Solo al montar: después manda lo que el usuario haya hecho.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    /**
     * Deja la posición dentro de la ventana.
     *
     * Se recalcula al girar el teléfono: unas coordenadas que valían en vertical
     * pueden dejar el robot fuera en horizontal.
     *
     * @param {IAniaPosition} p - Posición a acotar.
     * @returns {IAniaPosition} Posición dentro de los límites.
     */
    const clamp = useCallback((p: IAniaPosition): IAniaPosition => {
        const maxRight = Math.max(EDGE, window.innerWidth - FAB_SIZE - EDGE);
        const maxBottom = Math.max(EDGE, window.innerHeight - FAB_SIZE - TOP_RESERVED);
        return {
            right: Math.min(Math.max(p.right, EDGE), maxRight),
            bottom: Math.min(Math.max(p.bottom, EDGE), maxBottom),
        };
    }, []);

    /**
     * Alto de la ventana.
     *
     * En estado y no leído en el render: los componentes de cliente también se
     * renderizan en el servidor, donde `window` no existe y una lectura directa
     * lanzaría `ReferenceError`.
     */
    const [viewportHeight, setViewportHeight] = useState(0);

    useEffect(() => {
        // ⚠️ Aquí **no** se toca la posición.
        //
        // Antes hacía `setPos(clamp(prev))`, y eso destruía la posición que había
        // elegido el usuario: al girar el teléfono —o al abrir el teclado en
        // Android, que también dispara `resize`— el robot se mudaba solo al punto
        // acotado y se quedaba ahí para siempre, porque el valor crudo ya no
        // existía. La posición cruda se conserva y el acotado se aplica solo al
        // calcular lo que se pinta, igual que ya se hacía con el teclado.
        const onResize = () => setViewportHeight(window.innerHeight);
        onResize();
        window.addEventListener("resize", onResize);
        window.addEventListener("orientationchange", onResize);
        return () => {
            window.removeEventListener("resize", onResize);
            window.removeEventListener("orientationchange", onResize);
        };
    }, [clamp]);

    /**
     * Empieza el gesto.
     *
     * @param {React.PointerEvent<HTMLButtonElement>} e - Evento de puntero.
     * @returns {void}
     */
    const onPointerDown = (e: React.PointerEvent<HTMLButtonElement>) => {
        gesture.current = {
            id: e.pointerId,
            startX: e.clientX,
            startY: e.clientY,
            at: performance.now(),
            moved: false,
            right: pos.right,
            // Se parte del `bottom` que se está **pintando**, no del guardado: con
            // el teclado abierto el robot está más arriba, y arrancando del valor
            // guardado el primer movimiento lo hacía saltar hacia abajo y luego ya
            // no seguía al dedo.
            bottom: bottomPintado.current,
            dir: 0,
            reversals: 0,
            shakeAt: performance.now(),
            lastX: e.clientX,
            dizzyDone: false,
        };
        // Puede fallar (o no existir) según el navegador; sin captura el arrastre
        // sigue funcionando, solo se pierde si el dedo sale del botón.
        try {
            btnRef.current?.setPointerCapture(e.pointerId);
        } catch {
            /* sin captura, da igual */
        }
    };

    /**
     * Mueve el robot mientras el dedo se desplaza.
     *
     * @param {React.PointerEvent<HTMLButtonElement>} e - Evento de puntero.
     * @returns {void}
     */
    const onPointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
        const g = gesture.current;
        if (g.id !== e.pointerId) return;

        const dx = e.clientX - g.startX;
        const dy = e.clientY - g.startY;
        if (!g.moved && Math.hypot(dx, dy) <= TAP_SLOP) return;

        if (!g.moved) {
            g.moved = true;
            setDragging(true);
            // Al empezar a mover se descarta el saludo: el globo estorbaría.
            if (showGreeting) onDismissGreeting();
        }
        // El eje está invertido porque la posición se guarda como distancia a las
        // esquinas: mover el dedo a la derecha **reduce** `right`.
        setPos({ right: g.right - dx, bottom: g.bottom - dy });

        // ── ¿La está agitando?
        //
        // Se cuentan los **cambios de sentido** en horizontal, no la velocidad:
        // arrastrarla rápido de un lado a otro de la pantalla es un movimiento
        // legítimo, y sacudir es ir y venir. Cada cambio tiene que recorrer un
        // mínimo, o el pulso de la mano bastaría para marearla. Y solo se marea
        // una vez por gesto: si no, agitarla diez segundos encadenaría mareos.
        const ahora = performance.now();
        const paso = e.clientX - g.lastX;
        if (Math.abs(paso) >= SHAKE_MIN_DELTA) {
            const sentido = paso > 0 ? 1 : -1;
            if (g.dir !== 0 && sentido !== g.dir) {
                if (ahora - g.shakeAt > SHAKE_WINDOW_MS) {
                    g.reversals = 1;
                    g.shakeAt = ahora;
                } else {
                    g.reversals += 1;
                }
                if (!g.dizzyDone && g.reversals >= SHAKE_REVERSALS) {
                    g.dizzyDone = true;
                    onShake();
                }
            }
            g.dir = sentido;
            g.lastX = e.clientX;
        }
    };

    /**
     * Termina el gesto y decide si fue un toque o un arrastre.
     *
     * @param {React.PointerEvent<HTMLButtonElement>} e - Evento de puntero.
     * @returns {void}
     */
    const onPointerUp = (e: React.PointerEvent<HTMLButtonElement>) => {
        const g = gesture.current;
        if (g.id !== e.pointerId) return;
        gesture.current.id = -1;
        try {
            btnRef.current?.releasePointerCapture(e.pointerId);
        } catch {
            /* sin captura, da igual */
        }

        if (g.moved) {
            onMoveEnd(pos);
        } else {
            // Sin movimiento **es un toque**, aunque el dedo se haya quedado
            // apoyado. Antes había que ser rápido además de no moverse, así que
            // apoyar el dedo un segundo y levantarlo no abría el chat ni movía
            // nada: el robot se sentía roto justo en el gesto que más se prueba.
            onOpen();
        }
        setDragging(false);
    };

    // El teclado empuja el robot hacia arriba, pero **sin cambiar la posición
    // guardada**: al cerrarse vuelve exactamente a donde el usuario lo dejó.
    // Y se acota aquí, al pintar, no al guardar: así girar el teléfono no destruye
    // la posición que eligió el usuario.
    const acotada = clamp(pos);
    const bottom = Math.max(acotada.bottom, keyboard > 0 ? keyboard + EDGE : acotada.bottom);
    bottomPintado.current = bottom;
    const currentStatus = dragging ? AniaStatusEnum.Dragging : status;

    /**
     * El globo va encima del robot salvo que no quepa: si el robot está en la
     * mitad superior de la pantalla, el globo se sale por arriba y se pone debajo.
     * Alto estimado del globo, con dos líneas de texto y los dos botones.
     */
    const BUBBLE_HEIGHT = 160;
    const bubbleAbove =
        viewportHeight === 0 || bottom + FAB_SIZE + EDGE + BUBBLE_HEIGHT <= viewportHeight - TOP_RESERVED;

    return (
        <>
            <Box
                component="button"
                ref={btnRef}
                type="button"
                aria-label={`Abrir el chat de ${assistantName}`}
                onPointerDown={onPointerDown}
                onPointerMove={onPointerMove}
                onPointerUp={onPointerUp}
                onPointerCancel={onPointerUp}
                sx={{
                    position: "fixed",
                    right: `${acotada.right}px`,
                    bottom: `${bottom}px`,
                    width: FAB_SIZE,
                    height: FAB_SIZE,
                    minWidth: 44,
                    minHeight: 44,
                    padding: 0,
                    border: 0,
                    background: "transparent",
                    // Ver la nota de la cabecera: 1050 es el hueco entre el submenú
                    // móvil (1000) y el AppBar (1100).
                    zIndex: 1050,
                    cursor: dragging ? "grabbing" : "grab",
                    // Imprescindible: sin esto el navegador se queda el gesto para
                    // desplazar la página y el arrastre no llega nunca.
                    touchAction: "none",
                    // La posición se transiciona salvo mientras se arrastra, para
                    // que el teclado la mueva con suavidad y el dedo sin retraso.
                    transition: dragging ? "none" : "bottom .28s cubic-bezier(.34,1.4,.64,1), right .28s cubic-bezier(.34,1.4,.64,1)",
                    "&:focus-visible": {
                        outline: `3px solid ${ColorsEpico.ColorSecondary}`,
                        outlineOffset: 2,
                        borderRadius: "50%",
                    },
                }}
            >
                <AniaAvatar status={currentStatus} size={FAB_SIZE} trackPointer />
            </Box>

            {/* Globo de presentación */}
            {showGreeting && !dragging && (
                <Box
                    sx={{
                        position: "fixed",
                        // El globo se despliega hacia la **derecha** del asistente,
                        // que es donde queda el hueco cuando nace pegada al botón
                        // «Buscar». Si por ese lado no cabe, se apoya en el borde.
                        right: `${Math.max(EDGE, acotada.right - BUBBLE_WIDTH - EDGE)}px`,
                        ...(bubbleAbove
                            ? { bottom: `${bottom + FAB_SIZE + EDGE}px` }
                            : { top: `${Math.max(TOP_RESERVED + EDGE, viewportHeight - bottom + EDGE)}px` }),
                        zIndex: 1051,
                        maxWidth: BUBBLE_WIDTH,
                        // 320px es el ancho de referencia del proyecto: el globo no
                        // puede exigir más de lo que deja la pantalla con sus márgenes.
                        width: "calc(100vw - 24px)",
                        backgroundColor: ColorsEpico.ColorWhite,
                        borderRadius: "12px",
                        boxShadow: "0 8px 24px rgba(12,25,54,.26)",
                        p: 1.25,
                        animation: "ania-pop .34s cubic-bezier(.2,1.5,.5,1) both",
                        "@keyframes ania-pop": {
                            from: { opacity: 0, transform: "scale(.82) translateY(6px)" },
                            to: { opacity: 1, transform: "none" },
                        },
                        "@media (prefers-reduced-motion: reduce)": { animation: "none" },
                    }}
                >
                    <Typography sx={{ fontSize: "12.5px", lineHeight: 1.45, color: ColorsEpico.ColorBlack }}>
                        Soy <b style={{ color: ColorsEpico.ColorPrimary }}>{assistantName}</b>. ¿Buscas algo y no
                        sabes cómo se llama? Cuéntamelo como se lo contarías a un compañero.
                    </Typography>
                    <Typography sx={{ mt: 0.75, fontSize: "11.5px", color: ColorsEpico.ColorNeutralGray, fontStyle: "italic" }}>
                        «Balatas para un Chevy 2005»
                    </Typography>
                    <Box sx={{ display: "flex", gap: 0.75, mt: 1, flexWrap: "wrap" }}>
                        <Box
                            component="button"
                            type="button"
                            onClick={onOpen}
                            sx={{
                                flex: "1 1 auto",
                                minHeight: 44,
                                minWidth: 44,
                                px: 1.5,
                                border: 0,
                                borderRadius: "99px",
                                cursor: "pointer",
                                backgroundColor: ColorsEpico.ColorPrimary,
                                color: ColorsEpico.ColorWhite,
                                fontSize: "11.5px",
                                fontWeight: 500,
                            }}
                        >
                            Platiquemos
                        </Box>
                        <Box
                            component="button"
                            type="button"
                            onClick={onDismissGreeting}
                            sx={{
                                minHeight: 44,
                                minWidth: 44,
                                px: 1.5,
                                border: 0,
                                borderRadius: "99px",
                                cursor: "pointer",
                                backgroundColor: ColorsEpico.ColorSkyBlue,
                                color: ColorsEpico.ColorGray,
                                fontSize: "11.5px",
                                fontWeight: 500,
                            }}
                        >
                            Luego
                        </Box>
                    </Box>
                </Box>
            )}
        </>
    );
};
