/**
 * Tablas del rescate del dictado, separadas del algoritmo.
 *
 * ⚠️ **Aquí NO hay ninguna lista de marcas, y es una decisión, no un olvido.**
 *
 * Se verificó que la aplicación no tiene en ninguna parte un catálogo completo de
 * marcas de producto: ni endpoint, ni faceta, ni tabla en IndexedDB, ni dato
 * estático. Todo lo que hay son «las marcas presentes en el resultado de esta
 * búsqueda», y además acotadas por el contexto de la petición.
 *
 * Un corrector apoyado en una lista incompleta invierte su propia lógica: que la
 * marca dicha no esté en la lista es prueba de que **falta en la lista**, no de
 * que el usuario se equivocara. Medido sobre los acrónimos reales del sector, un
 * corrector así convierte «GM» en «GMB», «LUK» en «LUX» y —humillante— «QBH» en
 * «QB» cuando el dictado fue perfecto. Y se autoconfirma: una marca que el
 * dictado ya no puede pronunciar nunca llega a entrar en la lista, así que queda
 * vetada para siempre en ese dispositivo.
 *
 * El árbitro de si una palabra es una marca es **el servicio**, que sí tiene el
 * índice completo. Aquí solo viven la fonética del español y unas cuantas cotas.
 */

/**
 * Cuántas hipótesis se le piden al reconocedor.
 *
 * Es un techo **pedido**: Chromium lo manda al servicio de reconocimiento
 * recortado a 30, pero no fabrica hipótesis, así que cuántas llegan lo decide el
 * servicio y en frases cortas pueden ser muy pocas o una sola.
 */
export const MAX_ALTERNATIVAS = 5;

/**
 * Cuántas frases compuestas se conservan como alternativas.
 *
 * Se varía **un segmento a la vez**, nunca el producto cartesiano: tres
 * segmentos por cinco alternativas son ciento veinticinco frases y casi todas son
 * ruido.
 */
export const MAX_HIPOTESIS = 12;

/** Cuántas candidatas se sondean como máximo. */
export const MAX_CANDIDATAS = 2;

/**
 * Cuánto vive una oferta sin contestar.
 *
 * Caduca para que un «sí» dicho dos minutos después, ya en otra conversación, no
 * reenvíe una corrección que el usuario ya no recuerda haber visto.
 */
export const OFERTA_TTL_MS = 20000;

/**
 * Lo que dispara la búsqueda de una marca nombrada.
 *
 * Todas contienen literalmente la palabra «marca». **«de» no está en la lista y
 * no puede estarlo**: es la palabra más frecuente del español y en refacciones
 * «de» más sustantivo es la construcción normal para *nombrar la pieza* —«un
 * juego de balatas», «retén de aceite», «bomba de agua»—. Con «de» como
 * disparador, el sustantivo que dice **qué** se pide pasaría a ser candidato a
 * marca.
 */
export const DISPARADORES_MARCA = ["marca", "marcas"];

/**
 * Palabras que cierran el hueco de la marca.
 *
 * Si detrás del disparador viene una de estas, **no se nombró ninguna marca**.
 * Cubre la pregunta más común del mostrador —«¿de qué marca tienes balatas para
 * un Tsuru?»—, donde detrás de «marca» viene «tienes»: preguntar por las marcas
 * no es nombrar una.
 */
export const CORTES = [
    "para", "de", "del", "con", "y", "o", "en", "que", "un", "una", "el", "la",
    "los", "las", "mi", "su", "sus", "por", "a", "al", "modelo", "ano", "año",
    "tienes", "tiene", "tienen", "hay", "manejas", "maneja", "manejan", "venden",
    "vende", "vendes", "quiero", "necesito", "busco", "dame", "ponme", "sirve",
    "cual", "cuales", "cualquier", "esa", "ese", "eso", "esta", "este", "seria",
];

/**
 * Formas con las que se acepta una oferta hablando.
 *
 * Vocabulario **cerrado y corto** a propósito: se resuelve en el dispositivo, no
 * sale a la red, y su peor caso es «no me oyó, no pasa nada». Cualquier palabra
 * fuera de estas listas hace que lo dictado se trate como un turno nuevo.
 */
export const CONFIRMACIONES_SI = [
    "si", "sí", "esa", "esa si", "esa sí", "si esa", "sí esa", "correcto",
    "exacto", "exacta", "dale", "orale", "órale", "afirmativo", "claro",
    "asi es", "así es", "ok", "okay", "va", "sale", "esa es", "aja", "ajá",
];

/** Formas con las que se rechaza una oferta hablando. */
export const CONFIRMACIONES_NO = [
    "no", "no esa", "esa no", "negativo", "dejalo", "déjalo", "para nada",
    "nada", "cancela", "cancelar", "no gracias", "asi no", "así no",
];

/**
 * Nombres de las letras en español de México, y de los dígitos.
 *
 * ⚠️ **Solo se leen en `ModoDictadoEnum.Deletreo`.** En habla libre, «de», «te»,
 * «ce», «ese», «que», «ve», «be», «a», «e», «i», «o», «u» son palabras corrientes
 * y «uno», «dos», «tres» son cantidades: interpretarlas como letras fabricaría
 * acrónimos que nadie dijo.
 *
 * Las formas de varias palabras («be grande», «doble u», «i griega») van aquí
 * enteras y se casan antes que las de una sola, para que «be grande» no se lea
 * como «B» seguido de la palabra «grande».
 *
 * Esta tabla es fonética del español, no un catálogo de refacciones: solo se
 * toca si aparece una variante regional nueva de un nombre de letra.
 */
export const NOMBRES_LETRA: Record<string, string> = {
    // Vocales
    a: "A", e: "E", i: "I", o: "O", u: "U",
    "i latina": "I",
    // Consonantes de una forma
    ce: "C", de: "D", efe: "F", ge: "G", jota: "J", ele: "L", eme: "M",
    ene: "N", "eñe": "Ñ", "ene con tilde": "Ñ", pe: "P", te: "T", ese: "S",
    erre: "R", ere: "R", equis: "X", zeta: "Z", ceta: "Z",
    // B, con las formas que se usan para distinguirla de la V
    be: "B", "be grande": "B", "be larga": "B", "be alta": "B", "be de burro": "B",
    // V
    ve: "V", uve: "V", "ve chica": "V", "ve corta": "V", "ve baja": "V",
    "ve de vaca": "V",
    // H, que en el habla se come con frecuencia
    hache: "H", ache: "H",
    // K y Q, que suenan casi igual
    ka: "K", ca: "K", cu: "Q", ku: "Q", que: "Q", qu: "Q",
    // W
    "doble u": "W", "doble ve": "W", "uve doble": "W", "doble be": "W",
    // Y
    ye: "Y", "i griega": "Y", "y griega": "Y",
    // Dígitos: un acrónimo de refacciones los lleva con frecuencia
    cero: "0", uno: "1", dos: "2", tres: "3", cuatro: "4", cinco: "5",
    seis: "6", siete: "7", ocho: "8", nueve: "9",
};

/** Cuántas palabras puede tener un nombre de letra. Para casar de mayor a menor. */
export const MAX_PALABRAS_NOMBRE_LETRA = 3;

/** Mínimo y máximo de símbolos que se aceptan como acrónimo deletreado. */
export const MIN_SIMBOLOS_DELETREO = 2;
export const MAX_SIMBOLOS_DELETREO = 8;
