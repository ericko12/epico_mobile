import { IProduct } from "@/features/products/domain/interfaces/IProduct";
import { ChatRoleEnum } from "@/features/aiSearch/domain/enums/ChatEnums";
import { IOfertaRescate } from "@/features/aiSearch/domain/interfaces/IDictado";

/**
 * Con qué cliente y sucursal se pidieron precio, promociones y existencia de los
 * productos de un mensaje.
 *
 * Guarda los valores **efectivamente enviados** a la hidratación, no los del
 * estado: el chat manda `clienteId ?? 0`, así que `0` es un valor legítimo que
 * significa «se buscó sin pedido activo», nunca «no se sabe». Lo desconocido es
 * la **ausencia** del sello, jamás un número.
 *
 * Solo identificadores y el nombre: el árbol de sesión se cifra entero en cada
 * escritura y el hilo se poda a 40 mensajes.
 *
 * @interface IContextoPrecios
 */
export interface IContextoPrecios {
    /** Cliente con el que se pidieron precio y promociones. `0` = sin pedido activo. */
    clienteId: number;
    /**
     * `sucursalIdDestino` con el que se pidió la existencia. `0` = ninguna.
     *
     * Opcional solo por compatibilidad: `sellarContextoPrecios` siempre lo escribe.
     * Un pedido sin sucursal de destino sella `0` porque es exactamente lo que
     * viaja —`SucursalId: branchId ?? 0`—, y guardar `undefined` haría que dos
     * peticiones idénticas se compararan como distintas.
     */
    sucursalId?: number;
    /**
     * Nombre del cliente al hidratar, para poder nombrarlo en el aviso.
     *
     * Se congela aquí a propósito: `IOrderSummary.cliente` es opcional y a veces
     * trae el relleno «NA», así que buscarlo al pintar —cuando esa caja puede
     * estar ya cerrada— no lo encontraría.
     */
    clienteNombre?: string;
}

/**
 * Con qué frase abrir el catálogo desde un turno, y cuántos resultados dará.
 *
 * No se deduce de la conversación: la frase del usuario puede no encontrar nada
 * en el índice aunque el agente sí haya entendido la pregunta. Se resuelve
 * preguntándole al índice, en `consultaCatalogo`.
 *
 * @interface IConsultaCatalogo
 */
export interface IConsultaCatalogo {
    /** Lo que se le pasa al catálogo como `CadenaBusqueda`. */
    consulta: string;
    /** Cuántos resultados dará **esa** consulta, no la del chat. */
    total: number;
}

/**
 * Un mensaje del hilo del asistente.
 *
 * @interface IChatMessage
 */
export interface IChatMessage {
    /** Identificador local del mensaje, para las `key` de React. */
    id: string;
    /** Quién lo escribió. */
    rol: ChatRoleEnum;
    /**
     * Texto del mensaje.
     *
     * ⚠️ En los mensajes del asistente es **conversación, no inventario**. Se ha
     * visto al agente afirmar que una balata de Nissan Frontier «también le queda»
     * a un Chevy 2005. La verdad son las tarjetas, y por eso el hilo pinta un
     * aviso debajo del texto cuando lo acompañan productos.
     */
    texto: string;
    /**
     * Productos recomendados, ya hidratados, listos para `ProductCard`.
     * Vienen recortados a `CHAT_MAX_PRODUCT_CARDS`.
     */
    productos?: IProduct[];
    /** Cuántos resultados hay en total, para el enlace al catálogo. */
    total?: number;
    /** Lo que el usuario escribió en el turno. */
    consulta?: string;
    /**
     * Con qué abrir el catálogo, ya comprobado contra el índice.
     *
     * ⚠️ **No es `consulta`.** El agente entiende «qué tipo de cintas tienes» y
     * devuelve 66; el catálogo busca literal y esa misma frase le da **cero**
     * —medido contra producción—. Aquí va la frase que sí encuentra algo, con su
     * total propio. `undefined` significa que ninguna encontró nada, y entonces el
     * hilo no ofrece el botón: mejor no dar salida que llevar a una pantalla vacía.
     */
    catalogo?: IConsultaCatalogo;
    /** `true` si el turno terminó en error del servicio. */
    error?: boolean;

    /**
     * `true` si no se pudieron traer precios ni existencias de este cliente.
     *
     * El buscador **no devuelve precio ni existencia** —llegan en `null` y el mapeo
     * los vuelve 0—, así que los pone la hidratación. Cuando falla entera, las
     * tarjetas salían a «$0.00 · No disponible» y el chat no decía nada, mientras
     * el catálogo sí avisa. Visto en producción.
     */
    hidratacionFallida?: boolean;
    /** El motivo que dio el gateway. Un aviso sin motivo no se puede accionar. */
    hidratacionError?: string;

    // ── Lo que el servicio ya decía de cada turno y hasta ahora se tiraba.

    /** Marca que el servicio reconoció dentro de la consulta. */
    marcaDetectada?: string | null;
    /** El motor corrigió erratas, plurales o sinónimos para encontrar algo. */
    aproximada?: boolean;
    /** Qué se buscó realmente. Puede ser `null` aunque `aproximada` sea `true`. */
    terminoCorregido?: string | null;
    /**
     * Con qué cliente y sucursal se hidrataron los `productos`.
     *
     * ⚠️ **Opcional a la fuerza**: los hilos que ya están en `sessionStorage`
     * vuelven por `REHYDRATE` sin él. `undefined` significa «no se sabe», y con
     * eso no se puede pintar ningún aviso: afirmar que unos precios son de otro
     * cliente sin saberlo es exactamente el error que este campo evita.
     *
     * ⚠️ **Todo mensaje que lleve `productos` tiene que llevarlo**, y con el valor
     * del cierre que hidrató, no releído al despachar: entre la hidratación y el
     * `dispatch` pasan unos cinco segundos en los que el vendedor puede cambiar de
     * caja, y un sello releído mentiría. Vale también para quien implemente
     * `getSearchConversation`, que hidratará por código y tendrá que sellar ahí
     * mismo.
     */
    contextoPrecios?: IContextoPrecios;

    // ── Rescate del dictado.

    /**
     * La palabra que el usuario dijo como marca y el servicio no reconoció.
     *
     * Es el aviso que faltaba: sin él, «focos de la marca QH» devolvía focos de
     * cualquier marca —o ninguno— y nada en la pantalla decía que la marca se
     * había perdido.
     */
    marcaNoReconocida?: string;
    /**
     * Corrección aprobada por el índice y pendiente de que el usuario la acepte.
     *
     * Nunca se aplica sola: se pinta como un botón, y el turno solo se reenvía si
     * el usuario lo toca o dice «sí».
     */
    oferta?: IOfertaRescate;
    /**
     * Lo que se había dictado antes de aceptar una corrección.
     *
     * Va en la burbuja del usuario para que el hilo siga siendo un registro fiel
     * de lo que pidió el cliente: ninguna burbuja de usuario lleva palabras que el
     * usuario no aprobó, pero se ve de dónde salieron.
     */
    corregidoDe?: string;
    /**
     * El texto exacto que se dictó, para poder devolverlo al compositor y que el
     * usuario lo corrija a mano.
     */
    dictado?: string;
}

/**
 * Posición del botón flotante, en píxeles desde el borde derecho e inferior de
 * la ventana.
 *
 * Se guarda **en distancias a las esquinas** y no en coordenadas absolutas: así
 * la posición sigue teniendo sentido al girar el teléfono o al cambiar el tamaño
 * de la ventana, que es exactamente cuando unas coordenadas absolutas dejarían el
 * robot fuera de la pantalla.
 *
 * @interface IAniaPosition
 */
export interface IAniaPosition {
    right: number;
    bottom: number;
}

/**
 * Estado del asistente.
 *
 * Vive en `sessionState`, así que se cifra y caduca con la sesión. Por eso el
 * texto que el usuario está escribiendo **no** está aquí: es estado local del
 * compositor, y meterlo obligaría a cifrar el árbol entero en cada tecla.
 *
 * @interface IAiSearchState
 */
export interface IAiSearchState {
    /** Panel abierto. */
    isOpen: boolean;
    /** Esperando respuesta del servicio. */
    isLoading: boolean;
    /**
     * Conversación en curso. Hay que reenviarlo en cada turno o el servicio
     * empieza una conversación nueva. El historial vive en Redis 20 minutos.
     */
    sessionId: string | null;
    /** Hilo completo, del más antiguo al más reciente. */
    messages: IChatMessage[];
    /** El usuario ya vio el saludo en esta sesión. */
    greetingDismissed: boolean;
    /** Dónde dejó el robot el usuario. */
    position: IAniaPosition | null;
    /**
     * Nombre que el servicio da al asistente. Se guarda en cuanto llega una
     * respuesta, para no dejarlo escrito a mano en la interfaz.
     */
    assistantName: string | null;
    /**
     * Ania contesta en voz alta. **Encendida por defecto.**
     *
     * Se decidió dejarla con las voces del navegador —Dalia donde exista, Sabina
     * si no— en vez de sintetizar en servidor, que era lo único capaz de dar una
     * sola voz a todos: unos 660 USD al mes con Amazon Polly a la escala real del
     * despliegue (400-600 personas), encima de lo que ya cuestan los turnos del
     * agente, y Polly no tiene descuentos por volumen.
     *
     * La contrapartida asumida, para que no sorprenda: **la voz no es la misma en
     * todos los equipos**. En Android y en iOS no existe ninguna de las dos y suena
     * la que traiga el dispositivo. Quien no la quiera la apaga con el interruptor
     * de la cabecera, y la elección se recuerda.
     *
     * Se persiste: vivía en estado local del componente, así que salir del
     * catálogo y volver hacía que la aplicación empezara a hablar sola otra vez
     * aunque el usuario la hubiera callado.
     */
    vozActiva: boolean;
}
