import { ModoDictadoEnum, MotivoOfertaEnum } from "@/features/aiSearch/domain/enums/DictadoEnums";

/**
 * Contratos del rescate del dictado. Sin dependencias de React ni de APIs del
 * navegador, como manda la capa de dominio.
 */

/**
 * Lo que el reconocedor entregó al terminar de escuchar.
 *
 * @interface IDictado
 */
export interface IDictado {
    /**
     * La hipótesis principal: **exactamente** lo que se envía. Se compone de la
     * alternativa `[0]` de cada segmento, igual que antes de que existiera este
     * mecanismo.
     */
    texto: string;
    /**
     * Las otras frases que el reconocedor consideró, ya compuestas y sin
     * repetidas, en su orden de preferencia.
     *
     * ⚠️ Puede venir vacío, y a menudo viene vacío. `maxAlternatives` es un techo
     * **pedido**: Chromium lo manda al servicio de reconocimiento pero no fabrica
     * hipótesis, así que cuántas llegan lo decide el servicio. Y en la ruta de
     * reconocimiento en dispositivo siempre llega una sola. Con la lista vacía
     * todo el mecanismo de oferta queda inerte, a coste cero.
     */
    alternativas: string[];
    /** Habla libre o deletreo pedido. */
    modo: ModoDictadoEnum;
}

/**
 * La palabra que el usuario dijo como nombre de marca.
 *
 * @interface IMarcaDicha
 */
export interface IMarcaDicha {
    /** La palabra, tal como se transcribió. */
    palabra: string;
    /** Índice del token dentro de la frase, contando desde cero. */
    indice: number;
}

/**
 * Una frase alternativa que merece que se le pregunte al servicio.
 *
 * @interface ICandidataDictado
 */
export interface ICandidataDictado {
    /** La frase completa, lista para enviar. */
    texto: string;
    /** La palabra que estaba en la frase enviada. */
    palabraAntes: string;
    /** La palabra que la sustituye en esta candidata. */
    palabraDespues: string;
}

/**
 * Lo que devolvió una sonda al servicio.
 *
 * @interface ISondeo
 */
export interface ISondeo {
    /** El texto que se sondeó. */
    texto: string;
    /** `false` si el servicio no pudo servir la consulta. */
    ok: boolean;
    /** Cuántos productos casan. */
    total: number;
    /** La marca que el servicio reconoció dentro del texto, si reconoció alguna. */
    marcaDetectada: string | null;
}

/**
 * Lo que hay que hacer antes de poder ofrecer nada.
 *
 * @interface IPlanRescate
 */
export interface IPlanRescate {
    /** Por qué se está rescatando. */
    motivo: MotivoOfertaEnum;
    /** La marca que el usuario nombró y el servicio no reconoció. */
    marca: IMarcaDicha;
    /**
     * Las frases que hay que sondear. **Puede venir vacío**: entonces no se gasta
     * ninguna petición y lo único que queda es pedirle al usuario que la deletree
     * o que la escriba.
     */
    candidatas: ICandidataDictado[];
}

/**
 * Una corrección aprobada por el servicio y pendiente de que el usuario la
 * acepte.
 *
 * Vive en una `ref`, **no** en Redux: caduca a los veinte segundos y al enviar
 * cualquier turno. Persistirla obligaría a cifrar el árbol de sesión completo, y
 * dejaría rastro en una tableta compartida sin ninguna pantalla para verlo ni
 * borrarlo.
 *
 * @interface IOfertaRescate
 */
export interface IOfertaRescate {
    /** El texto que se envió y no funcionó. */
    textoAnterior: string;
    /** El texto que se enviaría si el usuario acepta. */
    textoNuevo: string;
    /** La palabra que se sustituye. */
    palabraAntes: string;
    /** La palabra que entra. */
    palabraDespues: string;
    /** Cuántas piezas encontró la sonda con la palabra nueva. */
    total: number;
    /** Por qué se ofrece. */
    motivo: MotivoOfertaEnum;
    /** Cuándo se creó, para poder caducarla. */
    creada: number;
}
