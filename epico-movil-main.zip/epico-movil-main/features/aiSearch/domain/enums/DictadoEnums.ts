/**
 * Enums del rescate del dictado.
 *
 * El problema que resuelven: el reconocedor de voz del navegador no conoce los
 * nombres de marca del catálogo. Dictar «focos de la marca QBH» se transcribe
 * como «focos de la marca QH» —se come una letra— o como «focos de la marca
 * Kuhn» —sustituye lo que no conoce por una palabra que sí—, y el servicio de
 * búsqueda no corrige ninguna de las dos: devuelve cero resultados y el agente
 * contesta «eso no lo encontré en el catálogo».
 *
 * ⚠️ **La regla de oro de todo este mecanismo: nunca se corrige la consulta que
 * se envía.** El primer turno sale con lo que el reconocedor entendió, palabra
 * por palabra. La corrección existe, pero solo como **oferta**, y solo después de
 * que el turno ya fracasara. El motivo es la asimetría del daño: hoy el error es
 * visible —el usuario lee «QH» en el compositor y en la burbuja— y cuesta una
 * búsqueda mala; una corrección automática lo convertiría en un error invisible
 * que la aplicación confirma en voz alta, y en un mostrador de refacciones eso se
 * materializa en una pieza equivocada pedida al proveedor.
 */

/**
 * De qué tipo es el dictado que se está escuchando.
 *
 * @enum {string}
 */
export enum ModoDictadoEnum {
    /** Habla normal: una frase de mostrador. */
    Libre = "libre",
    /**
     * El usuario está deletreando una marca porque el asistente se lo pidió.
     *
     * Es una **puerta**, no una preferencia. Los nombres de letra del español
     * («de», «te», «ce», «ese», «que», «ve», «be», «a», «e», «i», «o», «u») y los
     * de dígito («uno», «dos», «tres») solo se interpretan como letras dentro de
     * este modo. En habla libre, cualquier par de palabras funcionales fabricaría
     * un acrónimo falso: «focos de ese lado» se convertiría en «DS».
     */
    Deletreo = "deletreo",
}

/**
 * Lo que el usuario contestó a una oferta de corrección.
 *
 * @enum {string}
 */
export enum ConfirmacionEnum {
    /** Aceptó: se reenvía el turno con la marca sustituida. */
    Si = "si",
    /** Rechazó: la oferta se descarta y no se pide nada más. */
    No = "no",
    /**
     * Dijo otra cosa: la oferta se descarta **en silencio** y lo dictado se trata
     * como un turno nuevo. Nunca se deja al usuario atrapado en un diálogo de
     * confirmación.
     */
    Nada = "nada",
}

/**
 * Por qué se está ofreciendo una corrección.
 *
 * Viaja hasta la interfaz para que el texto del botón y la frase hablada puedan
 * ser distintos sin que la interfaz tenga que reinferir el motivo.
 *
 * @enum {string}
 */
export enum MotivoOfertaEnum {
    /** El turno no devolvió nada. */
    SinResultados = "sinResultados",
    /**
     * El turno devolvió cosas, pero el servicio no reconoció la marca que el
     * usuario nombró: son resultados de cualquier marca, que es peor que ninguno
     * porque parecen buenos.
     */
    MarcaNoReconocida = "marcaNoReconocida",
    /** La candidata viene de un deletreo que el usuario aceptó dar. */
    Deletreo = "deletreo",
}
