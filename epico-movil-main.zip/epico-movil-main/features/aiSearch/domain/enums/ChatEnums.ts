/**
 * Quién escribió un mensaje del hilo.
 *
 * Los valores coinciden con los que devuelve
 * `GET /api/v1/BusquedaProductos/Conversaciones/{sesionId}` (`user` /
 * `assistant`), para poder retomar una conversación sin traducir nada.
 *
 * @enum {string}
 */
export enum ChatRoleEnum {
    User = "user",
    Assistant = "assistant",
}

/**
 * Qué está haciendo el asistente. Manda la animación del robot y lo que se
 * pinta en el hilo.
 *
 * El orden de precedencia cuando varios podrían aplicar está en
 * `AniaLauncher`: escuchando > hablando > pensando > mareada > saludando >
 * reposo.
 *
 * @enum {string}
 */
export enum AniaStatusEnum {
    /** Saludando al entrar; enseña el globo de presentación. */
    Greeting = "greeting",
    /** Flotando, sin nada que hacer. */
    Idle = "idle",
    /** Esperando al servicio. Un turno tarda unos 5 segundos. */
    Thinking = "thinking",
    /** El usuario la está arrastrando. */
    Dragging = "dragging",
    /**
     * La agitaron. Dura unos segundos y se le pasa.
     *
     * No es un adorno gratuito: le da respuesta a un gesto que el usuario va a
     * probar en cuanto descubra que se puede arrastrar, y un elemento que se
     * deja zarandear sin reaccionar se siente muerto.
     */
    Dizzy = "dizzy",
    /** Con el micrófono abierto, oyendo al usuario. */
    Listening = "listening",
    /** Leyendo su respuesta en voz alta. */
    Speaking = "speaking",
}

/**
 * Cómo entró el turno del usuario.
 *
 * Decide si la respuesta se lee en voz alta: si el usuario habló, se le
 * contesta hablando; si escribió, no se le interrumpe con audio.
 *
 * @enum {string}
 */
export enum ChatInputModeEnum {
    Texto = "texto",
    Voz = "voz",
}

/**
 * Si las tarjetas de un turno siguen valiendo para el pedido de ahora.
 *
 * Son dos ejes y no uno: el **precio**, el precio tachado y la «P» de promoción
 * salen de la llamada por cliente, y la **existencia** —«Disponible», «No
 * disponible», «Hasta agotar existencias»— sale del `SucursalId` con el que se
 * pidió. El reparto está escrito en `hydrateSearchProducts`, líneas 102-103.
 *
 * `Vigente` quiere decir «no hay nada que avisar», y por eso lo devuelven también
 * los turnos sin tarjetas y las burbujas del vendedor: no afirman ningún precio.
 * `Desconocido` es el mensaje sin sello —un hilo de antes de este cambio— y
 * tampoco avisa: no se puede decir de quién eran unos precios que nadie fechó.
 *
 * @enum {string}
 */
export enum ContextoPreciosEnum {
    Vigente = "vigente",
    OtroCliente = "otroCliente",
    OtraSucursal = "otraSucursal",
    Desconocido = "desconocido",
}
