import { PRE_RECONCILIATION_VALIDATION_SCHEMA } from "@/features/billing/application/actions/validators/schemas/PreReconciliation.schema";
import { PreReconciliationFormState } from "@/features/billing/application/actions/validators/states/preReconciliationFormState";

/**
 * Submits the pre-reconciliation validation form and returns the updated state.
 *
 * @param {PreReconciliationFormState} _state - The current state of the pre-reconciliation form.
 * @param {FormData} formData - The form data to be submitted.
 * @returns {Promise<PreReconciliationFormState>} A promise that resolves to the updated form state after submission.
 */
export const submitPreReconciliation = async (_state: PreReconciliationFormState, formData: FormData): Promise<PreReconciliationFormState> => {
    const preReconciliationData = {
        amount: Number(formData.get("amount")),
        date: formData.get("date"),
        file: formData.get("file") as File,
        reference: formData.get("reference")?.toString().trim(),
        paymentMethod: Number(formData.get("paymentMethod")),
        bank: Number(formData.get("bank")),
        observations: formData.get("observations")?.toString().trim()
    };

    const validatedFields = PRE_RECONCILIATION_VALIDATION_SCHEMA.safeParse(preReconciliationData);

    if (!validatedFields.success) {
        return {
            values: preReconciliationData,
            errors: validatedFields.error.flatten().fieldErrors
        };
    }

    return {
        values: preReconciliationData,
        errors: undefined,
        responses: { success: true },
        message: "Pre-cuadre enviado exitosamente"
    };
}; 