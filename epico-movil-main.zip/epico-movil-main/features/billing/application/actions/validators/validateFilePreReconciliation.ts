import { FILE_VALIDATION_SCHEMA } from "@/features/billing/application/actions/validators/schemas/PreReconciliationFile.schema";

/**
 * Helper function to validate a file using the file validation schema
 * @param file - The file to validate
 * @returns Object with success status and error message if any
 */
export const validateFileWithZod = (file: File | null) => {
    const validationResult = FILE_VALIDATION_SCHEMA.safeParse({ file });

    if (!validationResult.success) {
        const errorMessage = validationResult.error.errors[0]?.message;
        return {
            isValid: false,
            error: errorMessage || 'Error de validación del archivo'
        };
    }

    return {
        isValid: true,
        error: null
    };
};
