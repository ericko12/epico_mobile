/**
 * Represents the state of the form for pre-reconciliation.
 * It includes form values, errors, a message, and response status. 
 * 
 * @property {object} values - The values of the invoice.
 * @property {number} values.amount - The amount of the invoice.
 * @property {any} values.date - The date of the invoice.
 * @property {File | null} values.file - The file of the invoice.
 * @property {string} values.reference - The reference of the invoice.
 * @property {number} values.paymentMethod - The payment method of the invoice.
 * @property {number} values.bank - The bank of the invoice.
 * @property {string} values.observations - The observations of the invoice.
 * @property {object} errors - The errors of the invoice.
 * @property {string} errors.amount - The error of the amount of the invoice.
 * @property {string} errors.date - The error of the date of the invoice.
 * @property {string} errors.file - The error of the file of the invoice.
 * @property {string} errors.reference - The error of the reference of the invoice.
 * @property {string} errors.paymentMethod - The error of the payment method of the invoice.
 * @property {string} errors.bank - The error of the bank of the invoice.
 * @property {string} message - The message of the invoice.
 * @property {object} responses - The responses of the invoice.
 * @property {boolean} responses.success - The success of the invoice.
 * @property {boolean} initialState - The initial state of the invoice.  
 */
export type PreReconciliationFormState =
    | {
        values?: {
            amount?: number
            date?: any
            file?: File | null
            reference?: string
            paymentMethod?: number
            bank?: number
            observations?: string
        }
        errors?: {
            amount?: string[]
            date?: string[]
            file?: string[]
            reference?: string[]
            paymentMethod?: string[]
            bank?: string[]
            observations?: string[]
        }
        message?: string
        responses?: {
            success: boolean
        }
        initialState?: boolean
    }
    | undefined 