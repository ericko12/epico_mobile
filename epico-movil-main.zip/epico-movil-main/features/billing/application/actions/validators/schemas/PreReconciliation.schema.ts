import dayjs from "dayjs";
import { z } from "zod";

/**
 * Validation schema using `zod` for pre-reconciliation form fields.
 * This schema validates all the required fields for the pre-reconciliation process.
 */
export const PRE_RECONCILIATION_VALIDATION_SCHEMA = z.object({
    amount: z
        .number({
            required_error: "Campo requerido",
            invalid_type_error: "El monto debe ser un número"
        })
        .min(5, "El monto debe ser igual o mayor a 5")
        .max(999999999.99, "El monto no puede exceder 999,999,999.99"),

    file: z
        .any()
        .refine((value) => value !== null, {
            message: "Campo requerido"
        })
        .refine((value) => {
            if (!value) return false;           
            const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
            return allowedTypes.includes(value.type);
        }, {
            message: "Formato no válido, selecciona jpg, png o pdf"
        })
        .refine((value) => {
            if (!value) return false;
            const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB
            return value.size <= MAX_FILE_SIZE;
        }, {
            message: "El peso máximo es de 25 MB"
        }),

    paymentMethod: z
        .number({
            required_error: "Campo requerido",
            invalid_type_error: "Selecciona una forma de pago válida"
        })
        .min(1, "Campo requerido"),

    date: z
        .string({
            required_error: "Campo requerido",
            invalid_type_error: "Campo requerido"
        })
        .min(1, "Campo requerido")
        .refine((val) => {
            if (val === "") return true;
            return dayjs(val, 'YYYY-MM-DD', true).isValid()
        }, {
            message: 'Formato inválido',
        })
        .refine((val) => {
            if (val === "") return true;
            const inputDate = dayjs(val, 'YYYY-MM-DD', true);
            const today = dayjs().endOf('day');
            return inputDate.isSame(today, 'day') || inputDate.isBefore(today);
        }, {
            message: 'Fecha superior a la permitida',
        }),

    bank: z
        .number({
            required_error: "Campo requerido",
            invalid_type_error: "Selecciona un banco válido"
        })
        .min(1, "Campo requerido"),
});

/**
 * Type inference from the validation schema
 */
export type PreReconciliationSchema = z.infer<typeof PRE_RECONCILIATION_VALIDATION_SCHEMA>;