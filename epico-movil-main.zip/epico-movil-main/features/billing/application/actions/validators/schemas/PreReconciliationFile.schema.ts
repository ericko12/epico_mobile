import dayjs from "dayjs";
import { z } from "zod";

/**
 * Schema for file validation
 */
export const FILE_VALIDATION_SCHEMA = z.object({
    file: z
        .any()
        .refine((value) => value !== null, {
            message: "Campo requerido"
        })
        .refine((value) => {
            if (!value) return false;
            const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
            return allowedTypes.includes(value.type);
        }, {
            message: "Formato no válido, selecciona jpg, png o pdf"
        })
        .refine((value) => {
            if (!value) return false;
            const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25MB
            return value.size <= MAX_FILE_SIZE;
        }, {
            message: "El peso máximo es de 25 MB"
        })
});