import { EPICO_API } from "@/axios/axios_helper";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { IDetailInvoice } from "@/features/billing/domain/interfaces/IDetailInvoice";
import { UrlEmailInvoice, UrlGetInvoicesPendingPayment, UrlInvoiceCFDI } from "@/features/billing/infrastructure/api/billingUrl";
import { IBodySendDocumentsEmail } from "@/features/billing/domain/interfaces/IBodySendDocumentsEmail";
import { handleRequest, handleRequestString } from "@/features/common/infrastructure/api/handleRequest";


/**
 * Billing service functional component
 * @returns Service for consumption of FacturacionInfo
 */
export const billingService = () => ({

    /**
     * Function to retrieve the outstanding invoices of a seller client.
     *
     * @async
     * @param {number} customerSellerId - The ID of the customer seller.
     * @returns {IResponseAxiosDto<IResponseDto<IDetailInvoice[]>>} 
     */
    GetInvoicesPendingPayment: (customerSellerId: number) => handleRequest<IDetailInvoice[]>(EPICO_API.get(UrlGetInvoicesPendingPayment(customerSellerId))),


    /**
     * Sends an invoice quotation email with the provided document details.
     *
     * @async
     * @function sendInvoiceQuotation
     * @param {IBodySendDocumentsEmail} bodySendDocumentsEmail - The payload containing the document details to send via email.
     * @returns {Promise<IResponseDto<boolean | null>>} A promise that resolves to the response containing a boolean indicating success, or null in case of failure.
     * @throws Will call `catchResponse` to handle any errors and return an appropriate response.
     */
    sendInvoiceQuotation: (bodySendDocumentsEmail: IBodySendDocumentsEmail): Promise<IResponseDto<boolean | null>> => handleRequest<boolean>(EPICO_API.post(UrlEmailInvoice(), bodySendDocumentsEmail)),

    /**
     * Retrieves the PDF of a CFDI invoice based on the document ID and series.
     * @param {number | string} documentId - The ID of the document.
     * @param {string} serie - The series of the document.
     * @returns {Promise<<string | null>>} - A promise that resolves to the response containing the PDF URL or null in case of failure.
     */
    getInvoiceCFDI: (documentId: number | string, serie: string): Promise<IResponseDto<string | null>> =>
        handleRequestString(EPICO_API.get(UrlInvoiceCFDI(documentId, serie)))
});

// Define the type for the API
export type ApiTypeDownload = ReturnType<typeof billingService>;