/**
 * Generates the URL to get pending payment invoices for a customer seller.
 * 
 * @param {number} customerSellerId - The ID of the customer seller.
 * @returns {string}
 */
export const UrlGetInvoicesPendingPayment = (customerSellerId: number): string => {
    return `/api/v2/ClienteVendedor/${customerSellerId}/FacturasPendientesDePago`;
}

/**
 * @returns {string} The URL to send CFDI documents via email.
 */
export const UrlEmailInvoice = (): string => `/api/CFDI/SendDocumentsEmail`;

/**
 * @param {number | string} documentId - The CFDI document's ID
 * @param {string} serie - The CFDI document's serial code
 * @returns {string} The URL to retrieve the CFDI document in PDF format.
 */
export const UrlInvoiceCFDI = (documentId: number | string, serie: string): string => {
    return `/api/CFDI/${documentId}/${serie}`;
}