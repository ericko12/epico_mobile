import { StatusOrderNameEnum } from "@/features/checkout/domain/enums/StatusOrderNameEnum";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { BadgeGeneric } from "@/features/common/infrastructure/ui/badge/BadgeGeneric";
import { NumberFormatCurrency } from "@/features/common/infrastructure/utils/numeric";
import { Launch } from "@mui/icons-material";
import { Box, Button } from "@mui/material";
import { GridColDef } from "@mui/x-data-grid";
import { IPaymentProcessingFilters } from "@/features/billing/infrastructure/ui/paymentProcessing/PaymentProcessing.types";
import { PaymentProcessStatusEnum } from "@/features/billing/domain/enum/PaymentProcessStatuEnum";
import { PaymentProcessStatusNameEnum } from "@/features/billing/domain/enum/PaymentProcessStatusNameEnum";
import dayjs from "dayjs";
import { IPoolListPreReconciliation } from "@/features/pool/domain/interface/pool/IPoolListPreReconciliationResponse";
import { getOrigenName } from "@/features/pool/infrastructure/api/utils/getOrigenName";

/**
 * Breadcrumbs for the payment processing page
 *
 * @function BREAD_CRUMBS_PAYMENT_PROCESSING
 * @returns {Array<{title: string}>} An array of breadcrumb items
 */
export const BREAD_CRUMBS_PAYMENT_PROCESSING = () => {
    return [
        { title: "Históricos" },
        { title: "Cobranza" },
    ];
}

/**
 * Defines the color of the outline and background and text according to the status of the order
 *
 * @param {StatusOrderEnum} status - The status of the order.
 * @returns {{ color: ColorsEpico; bg: ColorsEpico; status: StatusOrderNameEnum }}
 * An object containing:
 *  - `color`: The text or border color associated with the status.
 *  - `bg`: The background color associated with the status.
 *  - `status`: A human-readable status name from `StatusOrderNameEnum`. 
 */
const definedColorStatusId = (status: PaymentProcessStatusEnum) => {
    switch (status) {
        case PaymentProcessStatusEnum.Esperando:
            return { color: ColorsEpico.ColorBlueStatusOrders, bg: ColorsEpico.ColorBlueStatusOrdersBg, status: StatusOrderNameEnum.Activo };
        case PaymentProcessStatusEnum.EnProceso:
            return { color: ColorsEpico.ColorRedStatusOrders, bg: ColorsEpico.ColorRedStatusOrdersBg, status: StatusOrderNameEnum.Cancelado };
        case PaymentProcessStatusEnum.RespuestaAutomatica:
            return { color: ColorsEpico.ColorGreenStatusOrders, bg: ColorsEpico.ColorGreenStatusOrdersBg, status: StatusOrderNameEnum.Facturado };
        case PaymentProcessStatusEnum.Aceptado:
            return { color: ColorsEpico.ColorOrangeStatusOrders, bg: ColorsEpico.ColorOrangeStatusOrdersBg, status: StatusOrderNameEnum.Retenido };
        default:
            return { color: ColorsEpico.ColorGreenStatusOrders, bg: ColorsEpico.ColorGreenStatusOrdersBg, status: StatusOrderNameEnum.Activo };
    }
}

/**
 * Defines the color of the outline and background according to the status of the order
 *
 * @param {StatusOrderNameEnum} status - The status of the order.
 * @returns {{ color: ColorsEpico; bg: ColorsEpico }} 
 * An object containing:
 *  - `color`: The primary color associated with the status (used for text or borders).
 *  - `bg`: The background color associated with the status.
 */
const definedColorStatus = (status: PaymentProcessStatusNameEnum) => {
    switch (status) {
        case PaymentProcessStatusNameEnum.Aceptado:
            return { color: ColorsEpico.ColorGreenStatusOrders, bg: ColorsEpico.ColorGreenStatusOrdersBg, status: StatusOrderNameEnum.Facturado };
        case PaymentProcessStatusNameEnum.Rechazado:
        case PaymentProcessStatusNameEnum.Cancelado:
            return { color: ColorsEpico.ColorRedStatusOrders, bg: ColorsEpico.ColorRedStatusOrdersBg, status: StatusOrderNameEnum.Cancelado };
        case PaymentProcessStatusNameEnum.EnProceso:
        case PaymentProcessStatusNameEnum.Modificar:
        case PaymentProcessStatusNameEnum.Pendiente:
            return { color: ColorsEpico.ColorOrangeStatusOrders, bg: ColorsEpico.ColorOrangeStatusOrdersBg, status: StatusOrderNameEnum.Retenido };
        case PaymentProcessStatusNameEnum.RespuestaAutomatica:
            return { color: ColorsEpico.ColorGreenStatusOrders, bg: ColorsEpico.ColorGreenStatusOrdersBg, status: StatusOrderNameEnum.Facturado };
        case PaymentProcessStatusNameEnum.Esperando:
        case PaymentProcessStatusNameEnum.Otro:
            return { color: ColorsEpico.ColorBlueStatusOrders, bg: ColorsEpico.ColorBlueStatusOrdersBg, status: StatusOrderNameEnum.Activo };
        default:
            return { color: ColorsEpico.ColorGreenStatusOrders, bg: ColorsEpico.ColorGreenStatusOrdersBg };
    }
}


export const COLUMNS_PAYMENT_PROCESSING = (
    viewPreReconciliation: (preReconciliation: {
        folio: number;
        urlSolicitudPrecuadrePdf: string;
    },
        clienteVendedorId: number,
    ) => void,
    largeStatus: boolean
): GridColDef<IPoolListPreReconciliation>[] => [
        {
            headerName: 'ID Pre Cuadre',
            field: 'idPreCuadre',
            minWidth: 125,
            align: 'center',
            headerAlign: 'center',
            sortable: true,
        },
        {
            headerName: 'ID Cliente',
            field: 'idCliente',
            minWidth: 125,
            align: 'center',
            headerAlign: 'center',
            sortable: true,
        },
        {
            headerName: 'Nombre del cliente',
            field: 'nombreCliente',
            minWidth: 258,
            sortable: false,
            align: 'left',
            headerAlign: 'center',
        },
        {
            field: 'origenId',
            headerName: 'Origen',
            minWidth: 100,
            headerAlign: 'center',
            align: 'center',
            sortable: false,
            flex: 1,
            renderCell: (params) => getOrigenName(params.row.origenId)
        },
        {
            headerName: 'Fecha solicitud',
            field: 'fechaSolicitud',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => dayjs(row.fechaSolicitud).format('DD/MM/YYYY hh:mm a')
        },
        {
            headerName: 'Forma de pago',
            field: 'formaPago',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => row.formaPago ? row.formaPago : '-'
        },
        {
            headerName: 'Estatus',
            field: 'estatus',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => {
                const { color, bg } = definedColorStatus(row.estatus as PaymentProcessStatusNameEnum);
                return (
                    // Mismo caso que el estatus del listado de pedidos: en la celda del
                    // grid el distintivo llena el ancho, pero en la card ese 100% es el
                    // de la columna de valores y el distintivo se vuelve un bloque de
                    // color enorme. En móvil se ajusta al texto.
                    <Box title={PaymentProcessStatusNameEnum[row.estatus as keyof typeof PaymentProcessStatusNameEnum]} sx={{ width: { xs: 'fit-content', md: '100%' }, justifyItems: 'center' }}>
                        <Box sx={{ width: { xs: 'fit-content', md: '100%' } }}>
                            <BadgeGeneric
                                label={PaymentProcessStatusNameEnum[row.estatus as keyof typeof PaymentProcessStatusNameEnum]}
                                borderRadius="2px"
                                color={bg}
                                borderColor={`1px solid ${color}`}
                                textColor={color}
                                sxBadgeParam={{
                                    width: '100%',
                                    overflow: 'hidden',
                                    whiteSpace: 'nowrap',
                                    textOverflow: 'ellipsis',
                                    display: 'block',
                                }}
                            />
                        </Box>
                    </Box>
                )
            },
        },
        {
            headerName: 'Monto pagado',
            field: 'monto',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => NumberFormatCurrency(row.monto),
        },
        {
            headerName: '',
            field: 'actions',
            minWidth: 25,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => (
                <Button
                    sx={{
                        minWidth: '30px',
                    }
                    }
                    onClick={() => viewPreReconciliation({
                        folio: row.idPreCuadre,
                        urlSolicitudPrecuadrePdf: row.urlPrecuadre
                    }, row.clienteVendedorId)}
                >
                    <Launch sx={{ color: ColorsEpico.ColorBlack, width: 20, height: 20 }} />
                </Button>
            )
            ,
        },
    ];


export const InitPaymentProcessingFilters: IPaymentProcessingFilters = {
    search: '',
    startDate: null,
    endDate: null,
    status: null,
    methodPayment: null,
    used: false,
}