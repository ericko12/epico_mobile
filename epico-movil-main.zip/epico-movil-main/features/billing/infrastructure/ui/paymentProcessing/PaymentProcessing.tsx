import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { useBreadcrumb } from "@/features/common/infrastructure/hooks/useBreadcrumb";
import { Box, SelectChangeEvent, Typography } from "@mui/material"
import { ChangeEvent, useEffect, useState, useTransition } from "react";
import { BREAD_CRUMBS_PAYMENT_PROCESSING, COLUMNS_PAYMENT_PROCESSING, InitPaymentProcessingFilters } from "@/features/billing/infrastructure/ui/paymentProcessing/PaymentProcessing.data";
import { PaymentProcessingFilter } from "@/features/billing/infrastructure/ui/paymentProcessing/filters/PaymentProcessingFilter";
import { PaymentProcessingFilterSkeleton } from "@/features/billing/infrastructure/ui/paymentProcessing/filters/PaymentProcessingFilter.skeleton";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { AdaptiveDataGrid } from "@/features/common/infrastructure/ui/tables/adaptiveDataGrid/AdaptiveDataGrid";
import { PreReconciliationPDF } from "@/features/billing/infrastructure/ui/preReconciliation/PreReconciliationPDF";
import { PickerChangeHandlerContext, DateValidationError } from "@mui/x-date-pickers";
import { Dayjs } from "dayjs";
import { IPaymentProcessingFilters } from "@/features/billing/infrastructure/ui/paymentProcessing/PaymentProcessing.types";
import { PoolService } from "@/features/pool/application/services/pool.services";
import { IPoolListPreReconciliation, IPoolListPreReconciliationResponse } from "@/features/pool/domain/interface/pool/IPoolListPreReconciliationResponse";
import { GridCallbackDetails, GridPaginationModel, GridSortModel } from "@mui/x-data-grid";
import { IPoolListPreReconciliationRequest } from "@/features/pool/domain/interface/pool/IPoolListPreReconciliationRequest";
import { useAppSelector } from "@/features/common/application/redux/hooks";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { InitPoolListPreReconciliationResponse } from "@/features/pool/domain/data/InitPoolListPreReconciliationResponse.data";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { NotFoundData } from "@/features/common/infrastructure/ui/tables/NotFoundData";
import { EmptyData } from "@/features/common/infrastructure/ui/tables/EmptyData";
import { regexTextNumbers, regexNumber, regexConsecutiveSpaces } from "@/features/common/infrastructure/utils/regexGlobal";
import { PaymentProcessStatusNameEnum } from "@/features/billing/domain/enum/PaymentProcessStatusNameEnum";
import { ServiciosEnum } from "@/features/pool/domain/enums/ServiciosEnum";

/**
 * Main component for payment processing.
 *
 * This component handles the display and filtering of pre-reconciliation orders,
 * manages interactions with related services, and presents the data in a paginated table.
 *
 * @function
 * @returns {JSX.Element} The PaymentProcessing component.
 */
const PaymentProcessing = () => {
    //#region services
    const { getListPreReconciliation } = PoolService();
    //#endregion services

    //#region Redux
    const { sellersList } = useAppSelector(state => state.localState.sellersState);
    //#endregion Redux

    //#region hooks
    const { showSnackbar } = useSnackbar();
    const { setBreadcrumb } = useBreadcrumb();
    const [pendigData, startPendigData] = useTransition();
    //#endregion hooks

    //#region states
    const [loading, setLoading] = useState(false);
    const [openPreReconciliationPDF, setOpenPreReconciliationPDF] = useState(false);
    const [infoPreReconciliation, setInfoPreReconciliation] = useState<{ folio: number, urlSolicitudPrecuadrePdf: string } | null>(null);
    const [Cvid, setCvid] = useState(0);
    const [filters, setFilters] = useState<IPaymentProcessingFilters>(InitPaymentProcessingFilters);
    const [preReconciliations, setPreReconciliations] = useState<IPoolListPreReconciliationResponse>(InitPoolListPreReconciliationResponse);
    const [dateMissing, setDateMissing] = useState(false);
    const [applyFilters, setApplyFilters] = useState(false);
    const [activeReset, setActiveReset] = useState(false);
    const [helperText, setHelperText] = useState('');
    const [largeStatus, setLargeStatus] = useState(false);
    //pagination
    const [paginationModel, setPaginationModel] = useState<GridPaginationModel>({ page: 0, pageSize: 10 });
    const [sortModel, setSortModel] = useState<GridSortModel>([]);
    //#endregion states

    //#region useEffects
    useEffect(() => {
        setBreadcrumb(BREAD_CRUMBS_PAYMENT_PROCESSING());
        init();
    }, [])

    useEffect(() => {
        if (activeReset) fetchAllOrders();
    }, [activeReset])
    //#endregion useEffects

    //#region functions
    const init = async () => {
        setLoading(true);
        await fetchAllOrders();
        setLoading(false);
    }

    /**
     * Validates the current filter settings.
     *
     * @returns {boolean} - Returns true if the filters are valid, false otherwise.
     */
    const validationFilters = (): boolean => {
        const isNumberValid = regexNumber.test(filters.search);
        if (filters.search.length >= 1 && filters.search.length < 3 && !isNumberValid) {
            setHelperText('El nombre del cliente debe ser mayor a 3 caracteres');
            return false
        }
        if (/^0+$/.test(filters.search)) {
            setHelperText('La búsqueda no puede contener solo ceros');
            return false;
        }
        if (/^\s+$/.test(filters.search)) {
            setHelperText('No debe contener solamente espacios en blanco');
            return false;
        }
        if (!!filters.startDate && !filters.endDate) {
            setDateMissing(true);
            return false;
        }
        return true;
    }

    /**
     * Fetches all orders based on the provided pagination, sorting, and filter parameters.
     *
     * This function will perform an asynchronous API call to retrieve a list of orders.
     * It handles pagination, sorting, and filters such as date range and status.
     *
     * @async
     * @param {GridPaginationModel} [pagination] - The pagination model specifying the current page and page size.
     * @param {GridSortModel} [sorted] - The sorting model specifying the column field and sort direction.
     * 
     * @returns {Promise<void>} - Returns a promise that resolves when the fetch operation is complete.
     */
    const fetchAllOrders = async (pagination?: GridPaginationModel, sorted?: GridSortModel): Promise<void> => {

        if (!validationFilters()) return

        startPendigData(async () => {
            setDateMissing(false);
            setActiveReset(false);
            setHelperText('');

            const currentPagination = pagination || paginationModel;
            const currentSort = sorted !== undefined ? sorted : sortModel;
            const isNumberValid = filters.search.length > 0 && regexNumber.test(filters.search);

            const params: IPoolListPreReconciliationRequest = {
                pagina: currentPagination.page + 1,
                tamPagina: currentPagination.pageSize,
                fechaInicio: filters.startDate ?? undefined,
                fechaFin: filters.endDate ?? undefined,
                estatusId: filters.status ?? undefined,
                formaPago: filters.methodPayment ? +filters.methodPayment : undefined,
                cliente: filters.search && !isNumberValid ? filters.search : undefined,
                folio: isNumberValid ? +filters.search : undefined,
                servicioIds: [ServiciosEnum.SolicitudPrecuadreEpico, ServiciosEnum.SolicitudPrecuadreWeb],
                vendedoresIds: sellersList.map(seller => seller.vendedorID),
                ordenPor: currentSort[0]?.field ?? 'idPreCuadre',
                ordenTipo: currentSort[0]?.sort ?? 'desc'
            }

            const response = await getListPreReconciliation(params);

            await handleRequestDto({
                snackBar: showSnackbar,
                response,
                onSuccess: () => {
                    if (response.data) {
                        setLargeStatus(response.data.folios.some(folio => folio.estatus.trim() === 'RespuestaAutomatica'));
                        setPreReconciliations(response.data);
                    }
                    setApplyFilters(filters.used);
                },
                onInvalid: () => {
                    setPreReconciliations(InitPoolListPreReconciliationResponse);
                    setApplyFilters(filters.used);
                },
                onError: () => {
                    setPreReconciliations(InitPoolListPreReconciliationResponse);
                    setApplyFilters(filters.used);
                },
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE
                }
            })
        });
    }

    /**
     * Handles changes to the input text for the search field.
     * 
     * @param {ChangeEvent<HTMLInputElement>} e - The change event from the input element.
     * @returns {void} - This function does not return a value.
     */
    const hanldeChangeInputText = (e: ChangeEvent<HTMLInputElement>) => {
        const newValue = e.target.value
        if (regexTextNumbers.test(newValue) || regexNumber.test(newValue)) {
            if (regexNumber.test(newValue) && newValue.length >= 10) {
                setHelperText('El ID de la solicitud debe ser menor a 10 dígitos');
                return;
            }
            setHelperText('');
        }
        if (e.target.value === '')
            setFilters({ ...filters, search: e.target.value, used: !!filters.status || !!filters.endDate || !!filters.methodPayment });
        if (e.target.value !== '')
            setFilters({ ...filters, search: e.target.value, used: true });
    }

    //functions filters
    /**
     * Handles changes to the status selection.
     * 
     * @param {SelectChangeEvent<string>} e - The change event from the select element.
     * @returns {void} - This function does not return a value.
     */
    const handleChangeStatus = (e: SelectChangeEvent<string>) => setFilters({ ...filters, status: +e.target.value, used: true });

    /**
     * Handles changes to the method of payment selection.
     * 
     * @param {SelectChangeEvent<string>} e - The change event from the select element.
     * @returns {void} - This function does not return a value.
     */
    const handleChangeMethodPayment = (e: SelectChangeEvent<string>) => setFilters({ ...filters, methodPayment: e.target.value, used: true });

    /**
     * Handles the change of the start date filter.
     * @param {dayjs.Dayjs | null} value - Selected date value.
     * @param {PickerChangeHandlerContext<DateValidationError>} context - Date change context.
     */
    const onChangeStartDateFilter = (value: Dayjs | null, _context: PickerChangeHandlerContext<DateValidationError>) => {
        setFilters({ ...filters, startDate: value!, endDate: null, used: !!filters.status || !!filters.search });
    };

    /**
     * Handles the change of the end date filter.
     * @param {dayjs.Dayjs | null} value - Selected date value.
     * @param {PickerChangeHandlerContext<DateValidationError>} context - Date change context.
     */
    const onChangeEndDateFilter = (value: Dayjs | null, _context: PickerChangeHandlerContext<DateValidationError>) => {
        setDateMissing(false);
        setFilters({ ...filters, endDate: value!, used: true });
    };


    /**
     * Opens the pre-reconciliation modal and sets the pre-reconciliation information.
     * 
     * @param {Object} preReconciliation - The pre-reconciliation information containing the folio and URL.
     * @param {number} preReconciliation.folio - The folio number of the pre-reconciliation.
     * @param {string} preReconciliation.urlSolicitudPrecuadrePdf - The URL of the pre-reconciliation PDF.
     */
    const viewPreReconciliation = (preReconciliation: { folio: number, urlSolicitudPrecuadrePdf: string }, clienteVendedorId: number) => {
        setCvid(clienteVendedorId);
        setInfoPreReconciliation(preReconciliation);
        setOpenPreReconciliationPDF(true);
    }

    /**
     * Handles the search action.
     *
     * This function validates filters, resets sorting and pagination, 
     * and then fetches all orders based on the current search criteria.
     * 
     *  @returns {Promise<void>} - Returns a promise that resolves when the fetch operation is complete.
     */
    const handleSearch = async () => {
        const pagination = { page: 0, pageSize: 10 };
        const sort: GridSortModel = [];
        setPaginationModel(pagination);
        setSortModel(sort);
        await fetchAllOrders(pagination, sort);
    }

    /**
     * Resets the filters, sorting, and pagination of the table.
     *
     * @returns {void} - This function does not return a value.
     */
    const handleResetFilters = () => {
        resetFilters();
        resetSortAndPage();
        setActiveReset(true);
    }

    /**
     * Resets the filters to their initial state.
     *
     * @returns {void} - This function does not return a value.
     */
    const resetFilters = () => setFilters({ ...InitPaymentProcessingFilters });

    /**
     * Resets the sorting and pagination of the table.
     *      
     * @returns {void} - This function does not return a value.
     */
    const resetSortAndPage = () => {
        setPaginationModel({ page: 0, pageSize: 10 });
        setSortModel([]);
    }


    /**
     * Handles pagination of the table.
     *
     * @param {GridPaginationModel} model - The pagination model with updated page and size.
     * @param {GridCallbackDetails} details - Additional details related to the pagination action.
     * 
     * @returns {void} - This function does not return a value.
     */
    const handlePaginationTable = (model: GridPaginationModel, _details: GridCallbackDetails) => {
        if (!validationFilters()) return
        setPaginationModel(model);
        fetchAllOrders(model, sortModel);
    }

    /**
     * Handles the sorting of the table based on the provided sorting model.
     *
     * @param {GridSortModel} model - The sorting model containing the column field and sort direction.
     * @param {GridCallbackDetails} details - Additional details related to the sorting action.
     * 
     * @returns {void} - This function does not return a value.
     */
    const handleSortTable = (model: GridSortModel, _details: GridCallbackDetails) => {
        if (!validationFilters()) return
        setSortModel(model);
        fetchAllOrders(paginationModel, model);
    }
    //#endregion functions
    return (
        <Box px={{ xs: 2, md: 4 }} mt={2.5}>

            {loading ? <PaymentProcessingFilterSkeleton /> : <PaymentProcessingFilter
                filters={filters}
                loadingTable={loading || pendigData}
                onChangeInputText={hanldeChangeInputText}
                onChangeStartDate={onChangeStartDateFilter}
                onChangeEndDate={onChangeEndDateFilter}
                handleResetFilters={handleResetFilters}
                handleChangeStatus={handleChangeStatus}
                handleChangeMethodPayment={handleChangeMethodPayment}
                onSubmitSearch={handleSearch}
                dateMissing={dateMissing}
                helperText={helperText}
            />}
            <Typography mt={5} mb={2} textTransform="uppercase" fontSize={FontSizesEnum.Alpha} fontWeight={FontWeightEnum.Medium}>cobranza</Typography>
            <Box sx={{
                minHeight: '35.2rem',
                maxHeight: '35.2rem',
                display: 'grid',
            }}>
                <AdaptiveDataGrid
                    sx={{ height: { xs: 'auto', md: '35.1rem' } }}
                    columns={COLUMNS_PAYMENT_PROCESSING(viewPreReconciliation, largeStatus)}
                    rowCount={preReconciliations?.cantidadRegistros ?? 0}
                    rows={preReconciliations?.folios}
                    getRowId={(row: IPoolListPreReconciliation) => row.idPreCuadre}
                    disableRowSelectionOnClick
                    loading={loading || pendigData}
                    paginationModel={paginationModel}
                    onPaginationModelChange={loading || pendigData ? () => { } : handlePaginationTable}
                    sortingMode="server"
                    sortModel={sortModel}
                    onSortModelChange={loading || pendigData ? () => { } : handleSortTable}
                    slots={{
                        noRowsOverlay: () => applyFilters ? <NotFoundData msg="No obtuvimos resultados para la busqueda o filtros seleccionados, intenta utilizar parámetros distintos" /> : <EmptyData msg="No se encontraron resultados" />,
                    }}
                />
            </Box>

            <PreReconciliationPDF
                openModal={openPreReconciliationPDF}
                onClose={() => setOpenPreReconciliationPDF(false)}
                infoPreReconciliation={infoPreReconciliation}
                cvId={Cvid}
            />
        </Box>
    )
}

export default PaymentProcessing