import { SelectChangeEvent } from "@mui/material";
import { PickerChangeHandlerContext, DateValidationError } from "@mui/x-date-pickers";
import { Dayjs } from "dayjs";
import { ReactNode, ChangeEvent } from "react";
import { IPaymentProcessingFilters } from "@/features/billing/infrastructure/ui/paymentProcessing/PaymentProcessing.types";


/**
 * Props para el componente PaymentProcessingFilter.
 *
 * @interface IPaymentProcessingFilterProps
 * @property {boolean} loadingTable - Indica si la tabla está cargando.
 * @property {?boolean} [disableButton] - Determina si el botón debe estar deshabilitado.
 * @property {?*} [enter] - Función o valor para manejar el evento de presionar Enter.
 * @property {?ReactNode} [helperText] - Texto de ayuda o mensaje de error para el input.
 * @property {?boolean} [dateMissing] - Indica si falta seleccionar la fecha de fin.
 * @property {(e: ChangeEvent<HTMLInputElement>) => void | undefined} onChangeInputText - Función para manejar cambios en el input de búsqueda.
 * @property {(value: Dayjs | null, context: PickerChangeHandlerContext<DateValidationError>) => void} onChangeStartDate - Función para manejar el cambio de la fecha de inicio.
 * @property {(value: Dayjs | null, context: PickerChangeHandlerContext<DateValidationError>) => void} onChangeEndDate - Función para manejar el cambio de la fecha de fin.
 * @property {() => void} handleResetFilters - Función para resetear todos los filtros.
 * @property {(event: SelectChangeEvent<string>) => void} handleChangeStatus - Función para manejar el cambio de estatus.
 * @property {(event: SelectChangeEvent<string>) => void} handleChangeMethodPayment - Función para manejar el cambio de forma de pago.
 * @property {() => Promise<void>} onSubmitSearch - Función que se ejecuta al enviar la búsqueda.
 */
export interface IPaymentProcessingFilterProps {
    filters: IPaymentProcessingFilters;
    loadingTable: boolean;
    disableButton?: boolean;
    helperText?: ReactNode;
    dateMissing?: boolean;
    onChangeInputText: ((e: ChangeEvent<HTMLInputElement>) => void) | undefined;
    onChangeStartDate: (value: Dayjs | null, context: PickerChangeHandlerContext<DateValidationError>) => void;
    onChangeEndDate: (value: Dayjs | null, context: PickerChangeHandlerContext<DateValidationError>) => void;
    handleResetFilters: () => void;
    handleChangeStatus: (event: SelectChangeEvent<string>) => void;
    handleChangeMethodPayment: (event: SelectChangeEvent<string>) => void;
    onSubmitSearch: () => Promise<void>;
}
