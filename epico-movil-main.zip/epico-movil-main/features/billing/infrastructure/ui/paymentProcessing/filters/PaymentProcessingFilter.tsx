import { MethodPaymentEnum } from "@/features/billing/domain/enum/MethodPaymentEnum"
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum"
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { DatePickerGeneric } from "@/features/common/infrastructure/ui/datePicker/DatePickerGeneric"
import { CleanFilterIcon } from "@/features/common/infrastructure/ui/icons/CleanFilterIcon"
import { InputSearch } from "@/features/common/infrastructure/ui/inputs/InputSearch"
import { Stack, Button, Typography, FormControl, InputLabel, Select, MenuItem } from "@mui/material"
import { IPaymentProcessingFilterProps } from "@/features/billing/infrastructure/ui/paymentProcessing/filters/PaymentProcessingFilter.types"
import { PaymentProcessStatusNameEnum } from "@/features/billing/domain/enum/PaymentProcessStatusNameEnum"
import { PaymentProcessStatusEnum } from "@/features/billing/domain/enum/PaymentProcessStatuEnum"

/**
 * PaymentProcessingFilter component
 *
 * This component renders the filter controls for searching and filtering payment processing records.
 * It allows filtering by client, date range, status, and payment method, as well as resetting filters and executing the search.
 *
 * @component
 *
 * @param {IPaymentProcessingFilterProps} props - The properties for the PaymentProcessingFilter component.
 * @param {object} props.filters - The current values of the applied filters.
 * @param {boolean} [props.disableButton] - Whether the action buttons should be disabled.
 * @param {boolean} [props.loadingTable] - Whether the results table is in a loading state.
 * @param {string} [props.helperText] - Helper or error text for the client search field.
 * @param {boolean} [props.dateMissing] - Whether a required date is missing in the date filter.
 * @param {(event: React.ChangeEvent<HTMLInputElement>) => void} props.onChangeInputText - Handler for changes in the client search input.
 * @param {(date: Date | null) => void} props.onChangeStartDate - Handler for changes in the start date filter.
 * @param {(date: Date | null) => void} props.onChangeEndDate - Handler for changes in the end date filter.
 * @param {() => void} props.handleResetFilters - Handler to reset all filters to their initial state.
 * @param {(event: React.ChangeEvent<{ value: unknown }>) => void} props.handleChangeStatus - Handler for changes in the status filter.
 * @param {(event: React.ChangeEvent<{ value: unknown }>) => void} props.handleChangeMethodPayment - Handler for changes in the payment method filter.
 * @param {() => void} props.onSubmitSearch - Handler to execute the search with the applied filters.
 *
 * @returns {React.ReactElement} The rendered PaymentProcessingFilter component.
 */
export const PaymentProcessingFilter: React.FC<IPaymentProcessingFilterProps> = ({
    filters,
    disableButton,
    loadingTable,
    helperText,
    dateMissing,
    onChangeInputText,
    onChangeStartDate,
    onChangeEndDate,
    handleResetFilters,
    handleChangeStatus,
    handleChangeMethodPayment,
    onSubmitSearch
}) => {
    return (
        <Stack
            direction={'column'}
            spacing={1.5}
            id="main-filters"
        >
            {/* Add filters here */}
            <Stack direction={{ xs: 'column', sm: 'row' }} gap={1.5} sx={{ width: { xs: '100%', md: '464px' }, maxWidth: '100%' }} id="filters-search">
                <InputSearch
                    value={filters.search}
                    helperText={helperText}
                    error={!!helperText}
                    enter={(e: any) => e.key === 'Enter' && onSubmitSearch()}
                    placeholder={'Buscar por Solicitud o Cliente'}
                    onChange={onChangeInputText}
                    disabled={disableButton || loadingTable}
                />
                <div>
                    <Button
                        size="small"
                        type="submit"
                        variant="contained"
                        onClick={onSubmitSearch}
                        disabled={loadingTable}
                        sx={{
                            width: { xs: '100%', md: '90px' },
                            height: '2.4rem',
                            boxShadow: 'none',
                            borderRadius: '.4rem',
                            bgcolor: ColorsEpico.ColorDodgerBlue
                        }}
                    >
                        <Typography
                            sx={{
                                size: FontSizesEnum.Beta,
                                color: ColorsEpico.ColorWhite,
                                fontWeight: FontWeightEnum.Medium
                            }}
                        >
                            {"Buscar"}
                        </Typography>
                    </Button>
                </div>
            </Stack>
            <Stack
                direction={{ xs: 'column', sm: 'row' }}
                spacing={1.5}
                alignItems={{ xs: 'stretch', sm: 'start' }}
                sx={{ width: '100%', flexWrap: { sm: 'wrap' } }}
                id="filters-date-status-method-payment"
            >
                <Stack spacing={1.5} sx={{ width: { xs: '100%', sm: 'auto' }, '& .MuiFormControl-root': { width: { xs: '100%', sm: 'auto' } } }}>
                    <DatePickerGeneric
                        size={'small'}
                        value={filters.startDate}
                        onChange={onChangeStartDate}
                        disableFuture={true}
                        readOnly={loadingTable}
                        textComponent="Fecha de Inicio"
                    />
                </Stack>
                <Stack direction={"column"} sx={{ position: 'relative', width: { xs: '100%', sm: 'auto' }, '& .MuiFormControl-root': { width: { xs: '100%', sm: 'auto' } } }}>
                    <DatePickerGeneric
                        size={'small'}
                        value={filters.endDate}
                        readOnly={!filters.startDate}
                        minDate={filters.startDate!}
                        onChange={onChangeEndDate}
                        disableFuture={true}
                        textComponent="Fecha de Fin"
                        errorMessageControlled={dateMissing ? 'Debe seleccionar la fecha de fin' : undefined}
                        errorControlled={dateMissing}
                    />
                </Stack>

                <FormControl sx={{ width: { xs: "100%", sm: "137px" } }} size="small">
                    <InputLabel>Estatus</InputLabel>
                    <Select
                        key='estatus'
                        value={filters.status as string | undefined | null ?? ''}
                        onChange={handleChangeStatus}
                        disabled={loadingTable}
                        sx={{
                            textAlign: "left",
                        }}
                        label="Estatus"
                    >
                        {Object.entries(PaymentProcessStatusEnum)
                            .filter(([key, value]) => typeof value === 'number')
                            .map(([key, value]) => (
                                <MenuItem key={value} value={value}>
                                    {PaymentProcessStatusNameEnum[key as keyof typeof PaymentProcessStatusNameEnum]}
                                </MenuItem>
                            ))}
                    </Select>
                </FormControl>
                <FormControl sx={{ width: { xs: "100%", sm: "160px" } }} size="small">
                    <InputLabel>Forma de pago</InputLabel>
                    <Select
                        key='Forma de pago'
                        value={filters.methodPayment as string | undefined | null ?? ''}
                        onChange={handleChangeMethodPayment}
                        disabled={loadingTable}
                        sx={{
                            textAlign: "left",
                        }}
                        label="Forma de pago"
                    >
                        <MenuItem value={MethodPaymentEnum.EFECTIVO}>EFECTIVO</MenuItem>
                        <MenuItem value={MethodPaymentEnum.CHEQUE}>CHEQUE</MenuItem>
                        <MenuItem value={MethodPaymentEnum.TRANSFERENCIA}>TRANSFERENCIA</MenuItem>

                    </Select>
                </FormControl>
                <Button
                    onClick={handleResetFilters}
                    disabled={!filters.used || loadingTable}
                    style={{
                        backgroundColor: filters.used ? ColorsEpico.ColorsDarkBlue : ColorsEpico.ColorGrayDisabled,
                        color: ColorsEpico.ColorWhite,
                        marginLeft: '12px',
                        padding: '5px 15px',
                        border: 'none',
                        borderRadius: '4px',
                        width: '50px',
                        height: '37px',
                    }}
                >
                    <CleanFilterIcon />
                </Button>
            </Stack >
        </Stack >
    )
}
