import { Stack, Skeleton } from "@mui/material"

export const PaymentProcessingFilterSkeleton = () => {
    return (
        <Stack
            direction={'column'}
            spacing={1.5}
        >
            {/* Add filters here */}
            <Stack direction={'row'} spacing={1.5}>
                <Skeleton variant="rectangular" width={365} height={40} />
                <div>
                    <Skeleton variant="rectangular" width={90} height={40} sx={{ borderRadius: '.4rem' }} />
                </div>
            </Stack>

            <Stack
                direction={'row'}
                spacing={1.5}
                alignItems={'center'}
            >
                <Skeleton variant="rounded" width={185} height={40} />
                <Skeleton variant="rounded" width={185} height={40} />
                <Skeleton variant="rounded" width={135} height={40} />
                <Skeleton variant="rounded" width={165} height={40} />

                <Skeleton variant="rectangular" width={70} height={37} sx={{ borderRadius: '4px', marginLeft: '12px' }} />
            </Stack>
        </Stack>
    )
}
