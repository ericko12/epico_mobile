
import { PaymentProcessStatusEnum } from "@/features/billing/domain/enum/PaymentProcessStatuEnum";
import { PaymentProcessStatusNameEnum } from "@/features/billing/domain/enum/PaymentProcessStatusNameEnum";
import { Dayjs } from "dayjs";

export interface IPaymentProcessingResponse {
    idPreCuadre: number;
    idCliente: number;
    nombreCliente: string;
    fechaSolicitud: string;
    formaPago: string;
    estatus: PaymentProcessStatusNameEnum;
    montoPagado: number;
}


export interface IPaymentProcessingFilters {
    search: string;
    startDate: Dayjs | null;
    endDate: Dayjs | null;
    status: PaymentProcessStatusEnum | null;
    methodPayment: string | null;
    used: boolean;
}

