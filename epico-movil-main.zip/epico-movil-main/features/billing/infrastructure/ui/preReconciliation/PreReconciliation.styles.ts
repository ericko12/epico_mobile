import { SxProps } from "@mui/material";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
/**
 * Returns the custom styles for the Alert component.
 *
 * @type {SxProps}
 * @returns {{ [key: string]: any }} 
 * An object containing the styles for the Alert component, including background color,
 * text color, borders, and icon/action alignment.
 */
export const AlertSx: SxProps = {
    wbgcolor: ColorsEpico.ColorNeutralYellow,
    color: '#000',
    border: `1px solid ${ColorsEpico.ColorNeutralYellow}`,
    borderRadius: '4px',
    mb: 2,
    textTransform: 'upperCase',
    '& .MuiAlert-icon': { color: ColorsEpico.ColorNeutralYellow },
    '& .MuiAlert-action': {
        marginRight: '8px', 
        alignItems: 'center' 
    }
}