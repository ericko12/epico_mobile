import { IDetailInvoice } from "@/features/billing/domain/interfaces/IDetailInvoice";
import { ICustomerData } from "@/features/customer/domain/interface/ICustomerData";
import dayjs from "dayjs";

/**
 * Represents an early payment discount applied to an invoice.
 * @property {number} invoiceId - The unique identifier of the invoice.
 * @property {number} discount - The discount percentage or amount applied for early payment.
 * @property {number} balance - The balance amount of the invoice.
 * @property {number} amount - The resulting amount after applying the early payment discount.
 */
export interface IEarlyPaymentApplied {
    invoiceId: number;
    discount: number;
    balance: number;
    amount: number;
}

/**
 * Represents the properties required for the Pre Reconciliation Modal.
 * @property {boolean} openModal - Whether the modal is open or not.
 * @property {() => void} onClose - Function to close the modal.
 * @property {() => void} onSave - Function to save the data.
 * @property {IDetailInvoice[]} invoicesSelected - The invoices selected for the pre reconciliation.
 * @property {ICustomerData} customerInfo - The customer information.
 * @property {string} contactInfo - The contact information of the customer.
 * @property {number} cvId - The client-vendor ID.
 */
export interface IPreReconciliationModalProps {
    openModal: boolean;
    onClose: (reloadInvoices?: boolean) => void;
    onSave: () => void;
    invoicesSelected: IDetailInvoice[];
    customerInfo: ICustomerData;
    contactInfo: string;
    cvId: number;
}

/**
 * Represents the form data for the Pre Reconciliation Modal.
 * @property {number} amount - The amount of the early payment discount.
 * @property {dayjs.Dayjs | null | undefined} date - The date of the early payment discount.
 * @property {File | null} file - The file containing the early payment discount.
 * @property {string} reference - The reference of the early payment discount.
 * @property {string} paymentMethod - The payment method of the early payment discount.
 * @property {string} bank - The bank of the early payment discount.
 * @property {string} observations - The observations of the early payment discount.
 */
export interface IFormDataPreReconciliation {
    amount: number;
    date: dayjs.Dayjs | null | undefined;
    file: File | null;
    reference: string;
    paymentMethod: number | '';
    bank: number | '';
    observations: string;
}