/**
 * Props for the PreReconciliationPDF component.
 * @interface IPreReconciliationPDFProps
 * @property {boolean} openModal - Whether the modal is open.
 * @property {() => void} onClose - Function to close the modal.
 * @property {number} cvId - The ID of the customer.
 * @property {{ folio: number, urlSolicitudPrecuadrePdf: string }} infoPreReconciliation - The information of the pre-reconciliation.
 */
export interface IPreReconciliationPDFProps {
    openModal: boolean;
    onClose: () => void;
    cvId: number;
    infoPreReconciliation: { folio: number, urlSolicitudPrecuadrePdf: string } | null;
}
