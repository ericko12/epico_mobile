import { Box, Stack, Typography } from "@mui/material";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { GridColDef } from "@mui/x-data-grid";
import { Fragment } from "react";
import { SelectGeneric } from "@/features/common/infrastructure/ui/select/selectGeneric/SelectGeneric";
import { NumberFormatCurrency } from "@/features/common/infrastructure/utils/numeric";
import { ICustomerData } from "@/features/customer/domain/interface/ICustomerData";
import { IEarlyPaymentApplied, IFormDataPreReconciliation } from "@/features/billing/infrastructure/ui/preReconciliation/PreReconciliationModal.types";
import { IDetailInvoice } from "@/features/billing/domain/interfaces/IDetailInvoice";
import { Delete } from "@mui/icons-material";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { ICreditNoteResponse } from "@/features/credit/domain/interfaces/creditNote/ICreditNoteResponse";

export const COLUMNS_CREDIT_NOTES: GridColDef<ICreditNoteResponse>[] = [
    {
        headerName: 'ID Nota de crédito',
        field: 'noDocumento',
        flex: 1,
        sortable: false,
        align: 'center',
        headerAlign: 'center',
        valueGetter: (value) => value ?? '-'
    },
    {
        headerName: 'Monto',
        field: 'saldo',
        flex: 1,
        sortable: false,
        align: 'center',
        headerAlign: 'center',
        valueGetter: (value) => NumberFormatCurrency(value)
    }
]


export const COLUMNS_INVOICES = (
    customerInfo: ICustomerData,
    earlyPaymentApplied: Record<number, IEarlyPaymentApplied>,
    handleEarlyPaymentApplied: (invoice: IDetailInvoice, discount: number) => void,
    handleDeleteInvoice: (invoice: IDetailInvoice) => void
): GridColDef<IDetailInvoice>[] => [
        {
            headerName: 'ID Factura',
            field: 'facturaId',
            flex: .6,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
        },
        {
            headerName: 'Descuento P.P.',
            field: 'discount',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => {
                return (
                    <Fragment>
                        {/* En la tarjeta de móvil esta celda se queda con ~185px y el
                            selector pide 160: la etiqueta se partía por los puntos y
                            "P.P." salía en vertical, una letra por renglón. Con nowrap
                            no se parte, y si no caben juntos el selector baja (solo en móvil:
                            en escritorio la celda del DataGrid mantiene un renglón, como el original). */}
                        <Stack direction="row" spacing={1} justifyContent="center" alignItems="center" useFlexGap flexWrap={{ xs: 'wrap', md: 'nowrap' }}>
                            <Typography component="label" htmlFor="SELECT_PP_CUSTOMER" fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Gamma} textTransform="uppercase" sx={{ whiteSpace: 'nowrap' }}>P.P.</Typography>
                            <Box sx={{ width: { xs: '100%', md: '160px' }, maxWidth: '160px', height: '30px', alignItems: 'center', display: 'flex' }}>
                                <SelectGeneric
                                    name="SELECT_PP_CUSTOMER"
                                    sxSelected={{
                                        textAlign: 'left',
                                    }}
                                    width={160}
                                    height={30}
                                    disabled={customerInfo.tipoDescuentoProntoPagoNombre === 'Precio' || row.descuentoProntoPago !== 0 || customerInfo.tipoDescuentoProntoPagoNombre === 'S/I' || customerInfo.descuentoProntoPago === 0}
                                    defaultValue={0}
                                    value={earlyPaymentApplied[row.facturaId]?.discount ?? 0}
                                    onChange={e => handleEarlyPaymentApplied(row, e.target.value)}
                                    options={[
                                        { label: 'Sin pronto pago', value: 0 },
                                        { label: `${customerInfo.descuentoProntoPago} %`, value: customerInfo.descuentoProntoPago },
                                    ]}
                                />
                            </Box>
                        </Stack>
                    </Fragment>
                )
            }
        },
        {
            headerName: 'Descuento P.P. en $',
            field: 'discountAmount',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => {
                const amount = earlyPaymentApplied[row.facturaId]?.amount ?? 0;
                return NumberFormatCurrency(amount);
            },
        },
        {
            headerName: 'Saldo de factura',
            field: 'saldo',
            flex: 1,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            valueGetter: (value) => NumberFormatCurrency(value)
        },
        {
            headerName: '',
            field: 'actions',
            flex: .2,
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            renderCell: ({ row }) => (
                <Delete
                    onClick={() => handleDeleteInvoice(row)}
                    sx={{
                        cursor: 'pointer',
                        '&:hover': {
                            color: ColorsEpico.ColorRed,
                        },
                        fontSize: '16px',
                    }}
                />
            )
        }
    ]


export const InitFormDataPreReconciliation: IFormDataPreReconciliation = {
    amount: 0,
    date: null,
    file: null,
    reference: '',
    paymentMethod: '',
    bank: '',
    observations: '',
}