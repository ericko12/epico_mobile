import { Fragment, useState, useTransition } from "react";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric"
import { SharedModalGeneric } from "@/features/common/infrastructure/ui/modal/modalShared/SharedModalGeneric";
import { IShareOptions } from "@/features/common/infrastructure/ui/modal/modalShared/SharedModalGeneric.type";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { customerService } from "@/features/customer/application/service/customer.services";
import { IContact } from "@/features/customer/domain/interface/contact/IContact";
import { PoolService } from "@/features/pool/application/services/pool.services";
import { IPreReconciliationPDFProps } from "@/features/billing/infrastructure/ui/preReconciliation/PreReconciliationPDF.types";
import { Typography } from '@mui/material';
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";

/**
 * PreReconciliationPDF component.
 * @param {IPreReconciliationPDFProps} props - The props for the component.
 * @returns {React.FC<IPreReconciliationPDFProps>} The PreReconciliationPDF component.
 */
export const PreReconciliationPDF: React.FC<IPreReconciliationPDFProps> = ({
    openModal,
    onClose,
    cvId,
    infoPreReconciliation
}) => {
    //#region Hooks
    const { showSnackbar } = useSnackbar();
    const [pendingGetContacts, startPendingGetContacts] = useTransition();
    const [pendingShared, startPendingShared] = useTransition();
    //#endregion Hooks

    //#region Services
    const { getContactsInfo } = customerService();
    const { postSendPreReconciliation } = PoolService();
    //#endregion Services

    //#region States
    const [openModalShared, setOpenModalShared] = useState(false);
    const [infoShared, setInfoShared] = useState<IContact | null>(null);
    //#endregion States

    //#region Functions
    const sharePreReconciliation = () => {
        startPendingGetContacts(async () => {
            const responseContacts = await getContactsInfo(cvId);
            const firstContact = await handleRequestDto<IContact[] | null, IContact>({
                snackBar: showSnackbar,
                response: responseContacts,
                onSuccess: () => {
                    return responseContacts.data?.find(contact => contact.principal);
                },
            }) || null;
            setInfoShared(firstContact);
            setOpenModalShared(true);
        })
    }

    /**
         * Sends a pre-reconciliation to the email or whatsapp.
         * @param {IShareOptions} shareOptions - The share options.
         * @returns {Promise<void>}
         */
    const sendPreReconciliation = async (shareOptions: IShareOptions) => {
        startPendingShared(async () => {
            // email
            if (shareOptions.emailChecked) {
                const responseSendPreReconciliation = await postSendPreReconciliation({
                    correo: shareOptions.email,
                    folio: infoPreReconciliation?.folio ?? 0
                });

                handleRequestDto({
                    snackBar: showSnackbar,
                    response: responseSendPreReconciliation,
                    onSuccess: () => {
                        setOpenModalShared(false);
                    },
                    onInvalid: () => {
                        const errores = responseSendPreReconciliation.error.erroresValidaciones;

                        errores.forEach((error) => {
                            error.errores.forEach((mensaje) => {
                                showSnackbar(mensaje.includes('El correo') ? mensaje : GENERIC_ERROR_MESSAGE_CAE, "warning");
                            });
                        });
                    },
                    messages: {
                        error: GENERIC_ERROR_MESSAGE_CAE,
                        success: 'Correo enviado correctamente',
                    }
                });
            }

            // whatsapp
            if (shareOptions.whatsappChecked) {
                const whatsapp = shareOptions.whatsapp;
                const mensaje = `APYMSA Envío de Solicitud de Pago:\n ${infoPreReconciliation?.urlSolicitudPrecuadrePdf}`;
                const url = `https://wa.me/${whatsapp}?text=${encodeURIComponent(mensaje)}`;
                window.open(url, '_blank');
                if (shareOptions.whatsapp && !shareOptions.emailChecked) setOpenModalShared(false);
            }
        });
    }
    //#endregion Functions
    return (
        <Fragment>
            <ModalGeneric
                openModal={openModal}
                onClose={pendingGetContacts ? () => { } : onClose}
                titulo="Pre cuadre"
                width="800px"
                saveNotRequired
            >
                <ButtonLoading
                    sx={{
                        textTransform: "none",
                        backgroundColor: ColorsEpico.ColorsDarkBlue,
                        height: '30px',
                        width: '115px',
                        padding: '0 15px',
                        float: 'right',
                        mb: 2
                    }}
                    variant="contained"
                    loading={pendingGetContacts}
                    onClick={sharePreReconciliation}
                >Compartir</ButtonLoading>
                <iframe
                    src={`https://docs.google.com/gview?url=${encodeURIComponent(infoPreReconciliation?.urlSolicitudPrecuadrePdf ?? '')}&embedded=true`}
                    width="100%"
                    height="608px"
                    style={{ border: "none", minHeight: 500 }}
                    title="Nota de crédito PDF"
                />
                <Typography fontSize={FontSizesEnum.Sigma} mt={3}>
                    Este documento no constituye un comprobante de pago; se emite únicamente como una solicitud de validación del mismo. La aplicación o no del pago dependerá del resultado del proceso de validación efectuado por el área correspondiente.
                </Typography>
            </ModalGeneric>
            {openModalShared && <SharedModalGeneric
                open={openModalShared}
                onClose={() => setOpenModalShared(false)}
                onSend={sendPreReconciliation}
                isLoading={pendingShared}
                infoShared={infoShared}
            />}
        </Fragment>
    )
}
