'use client'

import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric"
import { InputLabel } from "@/features/common/infrastructure/ui/inputs/inputLabel/InputLabel"
import { SelectLabel } from "@/features/common/infrastructure/ui/select/selectLabel/SelectLabel"
import { AdaptiveDataGrid } from "@/features/common/infrastructure/ui/tables/adaptiveDataGrid/AdaptiveDataGrid"
import { Stack, Typography, Box, Grid2, Button } from "@mui/material"
import { COLUMNS_CREDIT_NOTES, COLUMNS_INVOICES, InitFormDataPreReconciliation } from "@/features/billing/infrastructure/ui/preReconciliation/PreReconciliationModal.data"
import { NumberFormatCurrency } from '@/features/common/infrastructure/utils/numeric';
import { InputFile } from "@/features/common/infrastructure/ui/inputs/inputFile/InputFile"
import { ChangeEvent, Fragment, useEffect, useState, useTransition, useActionState, startTransition } from "react"
import { IDetailInvoice } from "@/features/billing/domain/interfaces/IDetailInvoice"
import { IEarlyPaymentApplied, IFormDataPreReconciliation, IPreReconciliationModalProps } from "@/features/billing/infrastructure/ui/preReconciliation/PreReconciliationModal.types"
import { InputCash } from "@/features/common/infrastructure/ui/inputs/inputCash/InputCash";
import { DatePickerGeneric } from "@/features/common/infrastructure/ui/datePicker/DatePickerGeneric"
import { ModalWithoutButtons } from "@/features/common/infrastructure/ui/modal/modalWithoutButton/ModalWithoutButtons"
import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading"
import { useSnackbar } from "@/context/snackBar/SnackBarContext"
import { PreReconciliationFormState } from "@/features/billing/application/actions/validators/states/preReconciliationFormState"
import { submitPreReconciliation } from "@/features/billing/application/actions/validators/submitPreReconciliation"
import { validateFileWithZod } from "@/features/billing/application/actions/validators/validateFilePreReconciliation"
import { ModalDelete } from "@/features/common/infrastructure/ui/modal/ModalDelete";
import { catalogueService } from "@/features/catalogue/application/service/catalogueService"
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto"
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic"
import { ISelect } from "@/features/common/domain/interfaces/select/ISelect"
import { IBankResponse } from "@/features/catalogue/domain/interface/IBankResponse"
import { creditService } from "@/features/credit/application/service/credit.services"
import { ICreditNoteResponse } from "@/features/credit/domain/interfaces/creditNote/ICreditNoteResponse"
import { ApplicationApprovedIcon } from "@/features/common/infrastructure/ui/icons/ApplicationApprovedIcon"
import { useAppSelector } from "@/features/common/application/redux/hooks"
import dayjs from "dayjs"
import { SharedModalGeneric } from "@/features/common/infrastructure/ui/modal/modalShared/SharedModalGeneric"
import { PoolService } from "@/features/pool/application/services/pool.services"
import { IPoolResponse } from "@/features/pool/domain/interface/pool/IPoolResponse"
import { customerService } from "@/features/customer/application/service/customer.services"
import { IContact } from "@/features/customer/domain/interface/contact"
import { IShareOptions } from "@/features/common/infrastructure/ui/modal/modalShared/SharedModalGeneric.type"
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto"
import { hasGeolocationPermission } from "@/features/common/infrastructure/utils/permissions/geolocationPermission"
import { Alert } from '@mui/material';
import { upperCase } from "lodash"
import { AlertSx } from "@/features/billing/infrastructure/ui/preReconciliation/PreReconciliation.styles";
/**
 * PreReconciliationModal component
 *
 * This component is used to display the pre reconciliation modal.
 * 
 * @param {Object} props - Props for PreReconciliationModal.
 * @param {boolean} props.openModal - Controls whether the modal is open or closed.
 * @param {() => void} props.onClose - Function to call when closing the modal.
 * @param {() => void} props.onSave - Function to call when saving the pre-reconciliation.
 * @param {IDetailInvoice[]} props.invoicesSelected - Array of selected invoices to be included in the pre-reconciliation.
 * @param {Object} props.customerInfo - Information about the customer, including reference and other details.
 * @param {string} props.contactInfo - Contact information of the customer.
 * @param {number} props.cvId - The client-vendor ID.
 * @returns {JSX.Element} 
 */
export const PreReconciliationModal = ({
    openModal,
    onClose,
    onSave,
    invoicesSelected,
    customerInfo,
    contactInfo,
    cvId
}: IPreReconciliationModalProps) => {
    //#region Redux
    const { userAuth } = useAppSelector(state => state.localState.authState);
    //#endregion Redux

    //#region Services
    const { getBanks } = catalogueService();
    const { getCreditNotes } = creditService();
    const { getContactsInfo } = customerService();
    const { postPool, postSendPreReconciliation } = PoolService();
    //#endregion Services

    //#region Constants
    const PAYMENT_METHODS = {
        1: 'Efectivo',
        2: 'Cheque',
        3: 'Transferencia'
    } as const;
    //#endregion Constants

    //#region Hooks
    const [pendingInvoices, startPendingInvoices] = useTransition();
    const [pendingCreditNotes, startPendingCreditNotes] = useTransition();
    const [pendingBanks, startPendingBanks] = useTransition();
    const [pendingPreReconciliation, startPendingPreReconciliation] = useTransition();
    const [pendingGetContacts, startPendingGetContacts] = useTransition();
    const [pendingShared, startPendingShared] = useTransition();
    const { showSnackbar } = useSnackbar();
    const [state, action, pending] = useActionState<PreReconciliationFormState, FormData>(submitPreReconciliation, undefined);
    //#endregion Hooks

    //#region State
    const [fileError, setFileError] = useState<string | null>(null);
    const [selectedRows, setSelectedRows] = useState<ICreditNoteResponse[]>([]);
    const [selectedInvoices, setSelectedInvoices] = useState<IDetailInvoice[]>([...invoicesSelected]);
    const [formData, setFormData] = useState<IFormDataPreReconciliation>({ ...InitFormDataPreReconciliation, reference: customerInfo.referenciaBancaria, amount: selectedInvoices.reduce((acc, invoice) => acc + invoice.saldo, 0) });
    const [earlyPaymentApplied, setEarlyPaymentApplied] = useState<Record<number, IEarlyPaymentApplied>>({});
    const [openModalExit, setOpenModalExit] = useState(false);
    const [openModalConfirm, setOpenModalConfirm] = useState(false);
    const [openModalDelete, setOpenModalDelete] = useState(false);
    const [openModalSuccess, setOpenModalSuccess] = useState(false);
    const [openModalShared, setOpenModalShared] = useState(false);
    const [invoiceToDelete, setInvoiceToDelete] = useState<IDetailInvoice | null>(null);
    const [infoShared, setInfoShared] = useState<IContact | null>(null);
    const [banks, setBanks] = useState<ISelect[]>([]);
    const [allBanks, setAllBanks] = useState<IBankResponse[]>([]);
    const [creditNotes, setCreditNotes] = useState<ICreditNoteResponse[]>([]);
    const [responsePool, setResponsePool] = useState<IPoolResponse | null>(null);
    const [totalAmounts, setTotalAmounts] = useState({
        totalAmount: 0,
        totalNotesCredit: 0,
        totalPP: 0,
        totalInvoices: 0
    });
    const [openModalGeolocation, setOpenModalGeolocation] = useState(false);
    const [loadingPermissionGeolocation, setLoadingPermissionGeolocation] = useState(false);
    //#endregion
    //Alert -- totalCents
    const toCents = (n?: number) => Math.round((((n ?? 0)) + Number.EPSILON) * 100);
    const amountCents = toCents(formData?.amount);
    const totalCents  = toCents(totalAmounts?.totalAmount);
    const isOverpay   = amountCents > totalCents;
    const [overpayDismissed, setOverpayDismissed] = useState(false);
    useEffect(() => {
        if (isOverpay) setOverpayDismissed(false);
    }, [isOverpay]);


    //#region Effects
    useEffect(() => {
        handleGetBanks();
        handleGetCreditNotes();
    }, []);

    useEffect(() => {
        const ppAmount = Number((Object.values(earlyPaymentApplied).reduce((acc, earlyPayment) => acc + earlyPayment.amount, 0)).toFixed(2));
        const totalNotesCredit = selectedRows.reduce((acc, row) => acc + row.saldo, 0);
        const totalInvoices = selectedInvoices.reduce((acc, invoice) => acc + invoice.saldo, 0);
        const totalAmount = totalInvoices - ppAmount - totalNotesCredit;
        const safeTotal = Math.max(0, Number(totalAmount.toFixed(2)));
        setTotalAmounts({
            totalAmount: safeTotal,
            totalPP: ppAmount,
            totalNotesCredit,
            totalInvoices
        });
        // setFormData({ ...formData, amount: totalAmount < 0 ? 0 : totalAmount });
    }, [selectedInvoices, earlyPaymentApplied, selectedRows, formData.amount]);

    /**
     * Effect to handle form validation state changes
     */
    useEffect(() => {
        if (state?.responses && state.responses.success && !pending) {
            setOpenModalConfirm(true);
        } else if (state?.errors && !pending) {
            if (state.errors.file) {
                setFormData({ ...formData, file: null });
                return setFileError(`${state.errors.file?.[0]}`);
            }
        }
    }, [state]);
    //#endregion Effects

    //#region Functions
    /**
     * Function to get the payment method name
     * @param {number | string} methodId - The payment method ID.
     * @returns {string} The payment method name.
     */
    const getPaymentMethodName = (methodId: number | string): string => {
        const id = typeof methodId === 'string' ? parseInt(methodId) || 0 : methodId;
        return PAYMENT_METHODS[id as keyof typeof PAYMENT_METHODS] || 'Transferencia';
    };

    /**
     * Function to get the credit notes
     */
    const handleGetCreditNotes = async () => {
        startPendingCreditNotes(async () => {
            const res = await getCreditNotes(cvId, customerInfo.sucursalId);
            handleRequestDto({
                snackBar: showSnackbar,
                response: res,
                onSuccess: () => {
                    setCreditNotes(res?.data ?? []);
                },
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE,
                }
            });
        })
    }

    /**
     * Function to get the banks
     */
    const handleGetBanks = async () => {
        startPendingBanks(async () => {
            const res = await getBanks();
            handleRequestDto({
                snackBar: showSnackbar,
                response: res,
                onSuccess: () => {
                    setAllBanks(res?.data ?? []);
                    setBanks(res?.data?.map((bank: IBankResponse) => ({
                        label: bank.banco.toUpperCase(),
                        value: bank.bancoId,
                        disabled: !bank.status
                    })) ?? []);
                },
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE,
                },
            });
        });
    }


    /**
     * Function to handle the file upload event.
     * @param {React.ChangeEvent<HTMLInputElement>} event
     * @returns 
     */
    const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = event.target.files?.[0];
        if (!selectedFile) return setFormData({ ...formData, file: null });

        // Validate file using Zod
        const validationResult = validateFileWithZod(selectedFile);

        if (!validationResult.isValid) {
            setFormData({ ...formData, file: null });
            setFileError(validationResult.error || 'Error de validación del archivo');
            return;
        }

        setFormData({ ...formData, file: selectedFile });
        setFileError(null);
    };

    /**
    * Validates if the row is checked
    * 
    * This function:
    * - Checks if the row is in the selectedRows array
    * 
    * @param {IDetailInvoice} row - The table row to check
    * @returns {boolean} True if the row is checked, false otherwise
    */
    const isChecked = (row: ICreditNoteResponse): boolean => selectedRows.findIndex((selected: ICreditNoteResponse) => selected?.notaCreditoId === row.notaCreditoId) !== -1;

    /**
     * Handles checkbox selection logic for table rows
     * 
     * When a row is selected:
     * - For Revista/Default type promotions: Only selects/deselects the specific row
     * - For other promotion types: Selects/deselects all rows related to the same promotion
     * 
     * When no row is provided (header checkbox):
     * - Toggles selection of all rows
     *
     * @param {ChangeEvent<HTMLInputElement>} event - The checkbox change event
     * @param {IDetailInvoice | null} row - The row being selected, or null for header checkbox
     */
    const handleCheckboxChange = (event: ChangeEvent<HTMLInputElement>, row: ICreditNoteResponse | null) => {
        if (row) {
            const isSelected = selectedRows.findIndex((selected: ICreditNoteResponse) => selected?.notaCreditoId === row.notaCreditoId) !== -1;
            let newSelectedRows: ICreditNoteResponse[];
            isSelected ? newSelectedRows = selectedRows.filter((currentRow: ICreditNoteResponse) => currentRow.notaCreditoId !== row.notaCreditoId) : newSelectedRows = [...selectedRows, row];

            setSelectedRows(newSelectedRows);
        } else {
            // Selects or deselects all rows
            setSelectedRows(event.target.checked ? [] : []);
        }
    }

    /**
     * Handles the application of early payment discounts to invoices.
     * @param {IDetailInvoice} invoice - The invoice to apply the discount to.
     * @param {number} discount - The discount percentage to apply.
     */
    const handleEarlyPaymentApplied = (invoice: IDetailInvoice, discount: number) => {
        setEarlyPaymentApplied(prev => ({
            ...prev,
            [invoice.facturaId]: {
                invoiceId: invoice.facturaId,
                discount,
                balance: invoice.saldo,
                amount: Math.trunc(((discount / 100) * invoice.saldo) * 100) / 100
            }
        }));
    }

    /**
     * Handles the deletion of an invoice from the selected invoices list.
     * @param {IDetailInvoice} invoice - The invoice to delete.
     */
    const handleDeleteInvoice = (invoice: IDetailInvoice) => {
        setInvoiceToDelete(invoice);
        setOpenModalDelete(true);
    }

    /**
     * Function to handle the deletion of an invoice from the selected invoices list.
     */
    const handleDeleteInvoiceConfirm = () => {
        startPendingInvoices(() => {
            if (invoiceToDelete) {
                setEarlyPaymentApplied(prev => {
                    const { [invoiceToDelete.facturaId]: _, ...rest } = prev;
                    return rest;
                });
                const updatedInvoices = selectedInvoices.filter(i => i.facturaId !== invoiceToDelete.facturaId);
                setSelectedInvoices(updatedInvoices);
                setOpenModalDelete(false);
                if (selectedInvoices.length === 1) {
                    onClose(false);
                }
            }
        })
    }

    /**
     * Function to handle the saving of the pre-reconciliation.
     * @param {React.FormEvent<HTMLFormElement>} e - The form event.
     */
    const handleSavePreReconciliation = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        startTransition(async () => {
            // Create FormData object with all form values
            const formDataObj = new FormData();
            formDataObj.append("amount", formData.amount.toString());
            formDataObj.append("date", formData.date ? formData.date.format('YYYY-MM-DD') : "");
            if (formData.file) {
                formDataObj.append("file", formData.file);
            }
            formDataObj.append("reference", formData.reference);
            formDataObj.append("paymentMethod", formData.paymentMethod.toString());
            formDataObj.append("bank", formData.bank.toString());
            formDataObj.append("observations", formData.observations);
            // Submit the form using useActionState
            action(formDataObj);
        })
    }

    /**
     * Function to handle the change of the amount
     * @param {React.ChangeEvent<HTMLInputElement>} e - The event.
     */
    const handleChangeAmount = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = Number(e.target.value);
        setFormData(value ? { ...formData, amount: value } : { ...InitFormDataPreReconciliation, amount: value, observations: formData.observations, reference: customerInfo.referenciaBancaria });
    }

    /**
     * Function to handle the geolocation permission
     * @returns {Promise<void>}
     */
    const handleGeolocationPermission = async () => {
        const geolocationPermited = await hasGeolocationPermission();
        if (!geolocationPermited) {
            setOpenModalGeolocation(true);
            return;
        }

        handleConfirmPreReconciliation();
    }

    /**
     * Function to handle the confirmation of the pre-reconciliation
     */
    const handleConfirmPreReconciliation = () => {
        startPendingPreReconciliation(async () => {
            const position = await new Promise<GeolocationPosition>((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0,
                });
            });

            const xmlPreReconciliation = `<PoolServicios>
<Servicio ID="120" Descripcion="Solicitud para Pre-cuadre de Pagos de Epico">
<Cliente ID="${customerInfo.clienteId}" ClienteVendedorID="${cvId}" Nombre="${customerInfo.nombreEmpresa}" ReferenciaBancaria="${customerInfo.referenciaBancaria ?? ''}" />
<Empleado ID="${userAuth?.employeeId ?? 0}" />
<Sucursal ID="${customerInfo.sucursalId}" />
<Ubicacion Latitud="${position.coords.latitude}" Longitud="${position.coords.longitude}" />
<FechaHora Fecha="${dayjs().locale('es').format('dddd, D [de] MMMM [de] YYYY')}" />
 <Pago FechaPago="${formData.date ? formData.date.format('DD/MM/YYYY') : ''}" Importe="${Number(formData.amount).toFixed(2)}" CampoReferencia="${customerInfo.referenciaBancaria ?? ''}" ImporteFacturas="${selectedInvoices.reduce((acc, invoice) => {
                const discount = earlyPaymentApplied[invoice.facturaId]?.amount ?? 0;
                return acc + (invoice.saldo - discount);
            }, 0).toFixed(2)}">
            ${formData.amount > 0 ? `<FormaPago Nombre="${getPaymentMethodName(formData.paymentMethod)}" ID="${formData.paymentMethod}" />` : ''}
            <Banco CuentaID="${allBanks.find(bank => bank.bancoId === formData.bank)?.cuentaId}" Nombre="${allBanks.find(bank => bank.bancoId === formData.bank)?.banco.toUpperCase()}" />
            </Pago>
            <Notificacion>
<TipoEnvio>Correo</TipoEnvio>
<Telefono />
<Correo>${contactInfo}</Correo>
</Notificacion>
${selectedRows.length > 0 ? `<Anticipos>
    ${selectedRows.map((row) => `<Anticipo AnticipoID="${row.noDocumento}" Serie="${row.serie}" Saldo="${row.saldo}" />`).join('\n')}
    </Anticipos>
    ` : ''}
        <Facturas>
        ${selectedInvoices.map((invoice) => {
                const discount = earlyPaymentApplied[invoice.facturaId]?.amount ?? 0;
                const paymentAmount = (invoice.saldo - discount).toFixed(2);
                return `<Factura FacturaID="${invoice.facturaId}" Serie="${invoice.serie}" Saldo="${invoice.saldo}" Descuento="${discount}" PorcentajeDescuento="${discount > 0 ? customerInfo.descuentoProntoPago : 0}" ImportePago="${paymentAmount}" />`
            }).join('\n')}
        </Facturas>
        <Observaciones Observacion="${formData.observations}" />
        </Servicio>
        </PoolServicios>
        `.split('\n')
                .filter(linea => linea.trim() !== '')
                .join('\n');

            const responePool = await postPool({
                solicitudPrecuadreXML: xmlPreReconciliation,
                comprobanteDePago: formData.file ?? undefined,
                usuarioId: userAuth?.userId ?? 0,
                clienteVendedorId: cvId
            });

            handleRequestDto({
                snackBar: showSnackbar,
                response: responePool,
                onSuccess: () => {
                    setResponsePool(responePool.data ?? null);
                    setOpenModalConfirm(false);
                    setOpenModalSuccess(true);
                },
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE,
                },
            });
        })
    }

    /**
     * Shared a pre-reconciliation to the email or whatsapp.
     * @returns {Promise<void>}
     */
    const sharedPreReconciliation = async () => {
        startPendingGetContacts(async () => {
            const responseContacts = await getContactsInfo(cvId);
            const firstContact = await handleRequestDto<IContact[] | null, IContact>({
                snackBar: showSnackbar,
                response: responseContacts,
                onSuccess: () => {
                    return responseContacts.data?.find(contact => contact.principal);
                },
            }) || null;
            setInfoShared(firstContact);
            setOpenModalShared(true);
        })
    }

    /**
     * Sends a pre-reconciliation to the email or whatsapp.
     * @param {IShareOptions} shareOptions - The share options.
     * @returns {Promise<void>}
     */
    const sendPreReconciliation = async (shareOptions: IShareOptions) => {
        startPendingShared(async () => {
            // email
            if (shareOptions.emailChecked) {
                const responseSendPreReconciliation = await postSendPreReconciliation({
                    correo: shareOptions.email,
                    folio: responsePool?.folioPrecuadre ?? 0
                });

                handleRequestDto({
                    snackBar: showSnackbar,
                    response: responseSendPreReconciliation,
                    onSuccess: () => {
                        setOpenModalShared(false);
                    },
                    onInvalid: () => {
                        const errores = responseSendPreReconciliation.error.erroresValidaciones;

                        errores.forEach((error) => {
                            error.errores.forEach((mensaje) => {
                                showSnackbar(mensaje.includes('El correo') ? mensaje : GENERIC_ERROR_MESSAGE_CAE, "warning");
                            });
                        });
                    },
                    messages: {
                        error: GENERIC_ERROR_MESSAGE_CAE,
                        success: 'Correo enviado correctamente',
                    }
                });
            }

            // whatsapp
            if (shareOptions.whatsappChecked) {
                const whatsapp = shareOptions.whatsapp;
                const mensaje = `APYMSA Envío de Solicitud de Pago:\n ${responsePool?.urlSolicitudPrecuadre}`;
                const url = `https://wa.me/${whatsapp}?text=${encodeURIComponent(mensaje)}`;
                window.open(url, '_blank');
                if (shareOptions.whatsapp && !shareOptions.emailChecked) setOpenModalShared(false);
            }
        });
    }

    /**
     * Requests geolocation permission from the user and updates the permission state accordingly.
     *
     * @function
     */
    const geolocationPermissionActived = () => {
        setLoadingPermissionGeolocation(true);
        navigator.geolocation.getCurrentPosition(
            () => {
                setOpenModalGeolocation(false);
                handleConfirmPreReconciliation();
                setLoadingPermissionGeolocation(false);
            },
            () => {
                setOpenModalGeolocation(false);
                setLoadingPermissionGeolocation(false);
            },
            {
                enableHighAccuracy: false,
                timeout: 5000,
                maximumAge: 0
            }
        );
    }

    //#endregion Functions
    return (
        <Fragment>
            <ModalWithoutButtons
                openModal={openModal && !openModalConfirm && !openModalSuccess}
                onClose={() => setOpenModalExit(true)}
                titulo="pre cuadre de facturas"
                width="1515px"
                paddingModal=".5rem 1rem 0rem 1.3rem !important"
            >
                <Stack mb={2}>
                    <Typography>ID {customerInfo.clienteId}</Typography>
                    <Typography textTransform="uppercase" fontWeight={FontWeightEnum.Medium}>{customerInfo.nombreEmpresa}</Typography>
                </Stack>
                <Box component="form" onSubmit={handleSavePreReconciliation}>
                    {isOverpay && !overpayDismissed && (
                    <Alert
                        severity="warning"
                        onClose={() => setOverpayDismissed(true)}
                        sx={AlertSx}
                    >
                        El monto de pago es mayor al monto total a pagar, ajusta el monto de pago, si decides continuar se generará una nota de crédito a favor del cliente
                    </Alert>
                    )}
                    {/* Monto, forma de pago y fecha en una fila que no envolvía: el
                        select trae 265px fijos y la fecha otros 190, así que en el modal
                        de un teléfono los tres se aplastaban —la etiqueta "MONTO DEL
                        PAGO" quedaba encimada sobre sí misma y el select cortado—. */}
                    <Stack direction={{ xs: "column", md: "row" }} spacing={2}>
                        <Stack spacing={.6}>
                            <Box component="label" htmlFor="montoTotal">
                                <Stack direction="row" flexWrap="nowrap" height={'24px'}>
                                    <span style={{ color: 'red', marginRight: '5px' }}>*</span>
                                    <Typography color={ColorsEpico.ColorDarkCharcoal} fontSize={FontSizesEnum.Delta} fontWeight={FontWeightEnum.Bold} sx={{ textTransform: 'uppercase' }}>
                                        monto del pago
                                    </Typography>
                                </Stack>
                            </Box>
                            <InputCash
                             sx={{
                                    '& .MuiOutlinedInput-root': {
                                    '& fieldset': { borderColor: isOverpay ? ColorsEpico.ColorBrightOrange : undefined },
                                    '&:hover fieldset': { borderColor: isOverpay ? ColorsEpico.ColorBrightOrange : undefined },
                                    '&.Mui-focused fieldset': { borderColor: isOverpay ? ColorsEpico.ColorBrightOrange : undefined },
                                    },
                                    '& .MuiInputLabel-root': {
                                        color: isOverpay ? ColorsEpico.ColorBrightOrange : undefined
                                    }
                                }}
                                value={formData.amount}
                                onChange={handleChangeAmount}
                                minValue={0}
                                denyNegatives={true}
                                size="small"
                                error={!!state?.errors?.amount}
                                errorMessage={state?.errors?.amount?.[0]}
                            />
                        </Stack>
                        <SelectLabel
                            required
                            label="forma de pago"
                            value={formData.paymentMethod}
                            onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                            error={!!state?.errors?.paymentMethod}
                            errorMessage={state?.errors?.paymentMethod?.[0]}
                            selectProps={{
                                name: "select-paymentMethod",
                                placeHolder: "Seleccionar forma de pago",
                                width: 265,
                                options: [
                                    { label: 'EFECTIVO', value: 1 },
                                    { label: 'CHEQUE', value: 2 },
                                    { label: 'TRANSFERENCIA', value: 3 },
                                ]
                            }}
                        />
                        <Stack spacing={.6}>
                            <Box component="label" htmlFor="datePayment">
                                <Stack direction="row" flexWrap="nowrap" height={'24px'}>
                                    <span style={{ color: 'red', marginRight: '5px' }}>*</span>
                                    <Typography color={ColorsEpico.ColorDarkCharcoal} fontSize={FontSizesEnum.Delta} fontWeight={FontWeightEnum.Bold} sx={{ textTransform: 'uppercase' }}>
                                        fecha de deposito
                                    </Typography>
                                </Stack>
                            </Box>
                            <DatePickerGeneric
                                id="datePayment"
                                sxDatePicker={{
                                    "& .MuiOutlinedInput-root": {
                                        // Mismo caso que Estado de cuenta: 190px fijos
                                        // dejan el campo a media pantalla en un teléfono.
                                        width: { xs: '100%', md: '190px' },
                                    }
                                }}
                                validateAfter={false}
                                value={formData.date}
                                onChange={(value) => setFormData({ ...formData, date: value })}
                                textComponent={""}
                                disableFuture={true}
                                errorControlled={!!state?.errors?.date}
                                errorMessageControlled={state?.errors?.date?.[0]}
                            />
                        </Stack>
                        <SelectLabel
                            required
                            label="Banco"
                            value={formData.bank}
                            onChange={(e) => setFormData({ ...formData, bank: e.target.value })}
                            error={!!state?.errors?.bank}
                            errorMessage={state?.errors?.bank?.[0]}
                            selectProps={{
                                name: "select-bankPreCuadre",
                                disabled: banks.length === 0,
                                loading: pendingBanks,
                                width: 265,
                                placeHolder: "Seleccionar banco",
                                options: banks
                            }}
                        />
                        <InputLabel label="referencia" value={formData.reference} readOnly />
                    </Stack>
                    <Stack direction={{ xs: "column", md: "row" }} spacing={2} mt={3} sx={{ minWidth: 0 }}>
                        {/* minWidth 0 solo en movil: en escritorio la columna debe quedarse en 575px junto a facturas */}
                        <Stack direction="column" spacing={1} sx={{ width: { xs: "100%", md: "575px" }, minWidth: { xs: 0, md: 'auto' } }}>
                            <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Delta} textTransform="uppercase">notas de crédito</Typography>
                            <Box
                                sx={{
                                    // En movil el AdaptiveDataGrid pinta tarjetas, que ocupan
                                    // mucho mas que estos 288px: con la altura dura el contenido
                                    // desbordaba la caja y se pintaba ENCIMA de las observaciones,
                                    // los totales y los botones. Es el patron que ya usan
                                    // PaymentProcessing, TableDirectoryUDN y AccountStatementInvoice.
                                    height: { xs: 'auto', md: '18rem' },
                                    width: { xs: '100%', md: '575px' },
                                    display: 'grid',
                                    gridTemplateColumns: '100%',
                                    mt: 4,
                                }}
                            >
                                <AdaptiveDataGrid
                                    columns={COLUMNS_CREDIT_NOTES}
                                    rows={creditNotes}
                                    getRowId={(row: ICreditNoteResponse) => row.notaCreditoId}
                                    rowCount={creditNotes.length}
                                    hideFooter
                                    loading={pendingCreditNotes}
                                    checkboxSelected={true}
                                    allSelectedDisabled={true}
                                    checkboxField={""}
                                    checkboxDirection="start"
                                    isChecked={isChecked}
                                    handleCheckboxChange={handleCheckboxChange}
                                    emptyMsg="Información no disponible"
                                />
                            </Box>
                            <Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ pr: '5px !important' }}>
                                <Typography fontWeight={FontWeightEnum.Regular} fontSize={FontSizesEnum.Delta} textTransform="uppercase" color={ColorsEpico.ColorGray}>({creditNotes.length} nota{creditNotes.length > 1 ? 's' : ''} de crédito)</Typography>
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Gamma} textTransform="uppercase">Monto total</Typography>
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Gamma} textTransform="uppercase">{NumberFormatCurrency(totalAmounts.totalNotesCredit)}</Typography>
                            </Stack>
                        </Stack>
                        <Stack direction="column" spacing={1} width="100%">
                            <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Delta} textTransform="uppercase">facturas</Typography>
                            <Box
                                sx={{
                                    // En movil el AdaptiveDataGrid pinta tarjetas, que ocupan
                                    // mucho mas que estos 288px: con la altura dura el contenido
                                    // desbordaba la caja y se pintaba ENCIMA de las observaciones,
                                    // los totales y los botones. Es el patron que ya usan
                                    // PaymentProcessing, TableDirectoryUDN y AccountStatementInvoice.
                                    height: { xs: 'auto', md: '18rem' },
                                    width: '100%',
                                    display: 'grid',
                                    gridTemplateColumns: '100%',
                                    mt: 4,
                                }}
                            >
                                <AdaptiveDataGrid
                                    columns={COLUMNS_INVOICES(customerInfo, earlyPaymentApplied, handleEarlyPaymentApplied, handleDeleteInvoice)}
                                    rows={selectedInvoices}
                                    getRowId={(row: IDetailInvoice) => row.facturaId}
                                    rowCount={selectedInvoices.length}
                                    loading={pendingInvoices}
                                    hideFooter
                                />
                            </Box>
                            <Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ pr: '5px !important' }}>
                                <Typography fontWeight={FontWeightEnum.Regular} fontSize={FontSizesEnum.Delta} textTransform="uppercase" color={ColorsEpico.ColorGray}>({selectedInvoices.length} factura{selectedInvoices.length > 1 ? 's' : ''})</Typography>
                                <Stack direction="column" spacing={0}>
                                    <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Gamma} textTransform="uppercase">Monto total</Typography>
                                    <Typography fontWeight={FontWeightEnum.Regular} fontSize={FontSizesEnum.Delta} textTransform="uppercase" color={ColorsEpico.ColorGray} textAlign="right">Incluye I.V.A.</Typography>
                                </Stack>
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Gamma} textTransform="uppercase">{NumberFormatCurrency(totalAmounts.totalInvoices)}</Typography>
                            </Stack>
                        </Stack>
                    </Stack>
                    {/* En escritorio no envuelve (los totales van a la derecha) y el Grid2 de totales va sin margen, como el original */}
                    <Stack direction={{ xs: "column", md: "row" }} spacing={3} mt={3} justifyContent="space-between" useFlexGap flexWrap={{ xs: 'wrap', md: 'nowrap' }} sx={{ minWidth: 0 }}>
                        <Box sx={{ width: { xs: "100%", md: "455px" }, height: "auto" }}>
                            <InputFile
                                required
                                label="evidencia"
                                placeholder="Subir evidencia de pago (jpg, png o pdf)"
                                file={formData.file}
                                onChange={handleFileUpload}
                                fileError={fileError}
                                accept=".jpg, .pdf, .png"
                            />
                        </Box>
                        <Box sx={{ width: { xs: "100%", md: "600px" } }}>
                            <InputLabel
                                label="Observaciones"
                                TextFieldProps={{
                                    sx: {
                                        width: { xs: '100%', md: '600px' },
                                    },
                                    multiline: true,
                                    rows: 3,
                                }}
                                max={500}
                                value={formData.observations}
                                onChange={(e) => setFormData({ ...formData, observations: e.target.value })}
                            />
                        </Box>
                        <Grid2 container spacing={1} mr={{ xs: 1, md: 0 }} sx={{ width: "auto", minWidth: { xs: 0, md: "300px" } }}>
                            <Grid2 direction="row" spacing={2} size={7} textAlign="right" textTransform="uppercase">
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Beta} color={ColorsEpico.ColorPrimary} sx={{ textWrap: "nowrap" }}>P.P.</Typography>
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Beta} color={ColorsEpico.ColorPrimary} sx={{ textWrap: "nowrap" }}>notas de crédito</Typography>
                                <Stack direction="column" spacing={0}>
                                    <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Beta} color={ColorsEpico.ColorPrimary} sx={{ textWrap: "nowrap" }}>Monto total</Typography>
                                    <Typography fontWeight={FontWeightEnum.Regular} fontSize={FontSizesEnum.Delta} color={ColorsEpico.ColorGray} >Incluye I.V.A.</Typography>
                                </Stack>
                            </Grid2>
                            <Grid2 direction="row" spacing={2} size={5} textAlign="right" textTransform="uppercase">
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Beta} color={ColorsEpico.ColorPrimary}>{NumberFormatCurrency(totalAmounts.totalPP)}</Typography>
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Beta} color={ColorsEpico.ColorPrimary}>{NumberFormatCurrency(totalAmounts.totalNotesCredit)}</Typography>
                                <Typography fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Beta} color={ColorsEpico.ColorPrimary}>{NumberFormatCurrency(totalAmounts.totalAmount)}</Typography>
                            </Grid2>
                        </Grid2>
                    </Stack>

                    <Stack
                        // Apilados en movil: dos botones al ancho de la pantalla no
                        // caben en una fila de 320px.
                        direction={{ xs: "column", md: "row" }}
                        spacing={2}
                        alignItems={{ xs: "stretch", md: "center" }}
                        justifyContent="end"
                        mt={2}
                        sx={{
                            position: 'sticky',
                            bottom: 0,
                            right: 0,
                            backgroundColor: 'white',
                            padding: '1rem'
                        }}
                    >
                        <Button
                            variant='outlined'
                            onClick={() => setOpenModalExit(true)}
                            disabled={pending}
                            sx={{
                                mr: { xs: 0, md: 1 },
                                // 214px fijos por boton son 428px entre los dos: desbordan
                                // una pantalla de 320px. Y 40px queda por debajo del
                                // objetivo tactil de 44px.
                                width: { xs: '100%', md: '214px' },
                                height: { xs: 44, md: '40px' },
                                borderRadius: '4px',
                                fontWeight: FontWeightEnum.Medium,
                                color: ColorsEpico.ColorDarkCharcoal,
                                borderColor: ColorsEpico.ColorGrayNeutral,
                                '&.Mui-disabled': {
                                    opacity: .5,
                                }
                            }}
                        >
                            <Typography
                                fontSize={FontSizesEnum.Gamma}
                                fontWeight={FontWeightEnum.Medium}
                            >Cancelar</Typography>
                        </Button>

                        <ButtonLoading
                            sx={{
                                width: { xs: '100%', md: '214px' },
                                background: ColorsEpico.ColorPrimary,
                                borderRadius: '4px',
                                height: { xs: 44, md: '40px' },
                                '&.Mui-disabled': {
                                    backgroundColor: ColorsEpico.ColorBlueView,
                                    color: ColorsEpico.ColorWhite,
                                    opacity: 1,
                                }
                            }}
                            type="submit"
                            disabled={pending}
                            loading={pending}
                            variant='contained'
                        >
                            <Typography fontWeight={FontWeightEnum.Medium}
                                color={ColorsEpico.ColorWhite}
                                fontSize={FontSizesEnum.Gamma}
                            >
                                Mandar Pre cuadre
                            </Typography>
                        </ButtonLoading>
                    </Stack>
                </Box>
            </ModalWithoutButtons>

            <ModalDelete
                openModal={openModalDelete}
                loading={pendingInvoices}
                titulo="Eliminar factura"
                onClose={() => setOpenModalDelete(false)}
                onOk={handleDeleteInvoiceConfirm}
                description={selectedInvoices.length === 1 ? 'El pre cuadre debe contener por lo menos una factura, si eliminas esta factura se cancelará la solicitud de pre cuadre actual.' : 'Si eliminas esta factura se descontará del pre cuadre actual'}
                question={"¿Estas seguro de querer eliminarla?"}
            />

            <ModalGeneric
                openModal={openModalExit}
                onClose={() => setOpenModalExit(false)}
                onSave={() => onClose(false)}
                titulo="Salir del pre cuadre"
                btnTextSave="Aceptar"
                btnTextClose="Cancelar"
                borderModal={`2px solid ${ColorsEpico.ColorVibrantYellow} !important`}
            >
                <Typography>Aun no has enviado la solicitud de Pre cuadre, al salir perderás la información que hayas ingresado.</Typography>
                <Typography fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Gamma}>¿Estas seguro de salir?</Typography>
            </ModalGeneric>

            <ModalGeneric
                openModal={openModalConfirm && !openModalGeolocation}
                onClose={pendingPreReconciliation ? () => { } : () => setOpenModalConfirm(false)}
                onSave={handleGeolocationPermission}
                titulo="confirmar pre cuadre"
                btnTextSave="Aceptar"
                btnTextClose="Cancelar"
                isLoading={pendingPreReconciliation}
            >
                <Typography fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Gamma}>¿Esta seguro que deseas confirmar el envío del Pre cuadre?</Typography>
                <Typography>Verifica notas de crédito, pronto pago y en observaciones anotar la dispersión correcta del monto a pagar en las facturas</Typography>
            </ModalGeneric>

            <ModalWithoutButtons
                openModal={openModalSuccess}
                titulo={""}
                onClose={pendingGetContacts ? () => { } : () => onClose(true)}
                width="800px"
            >
                <Stack alignItems="center" justifyContent="center" spacing={3.5} p={10}>
                    <ApplicationApprovedIcon />
                    <Stack direction="column" alignItems="center" justifyContent="center" spacing={1}>
                        <Typography fontSize={FontSizesEnum.Alpha} fontWeight={FontWeightEnum.Medium} color={ColorsEpico.ColorGray}>La solicitud de Pre Cuadre se ha registrado correctamente</Typography>
                        <Stack direction="row" alignItems="center" justifyContent="center" spacing={1}>
                            <Typography fontSize={FontSizesEnum.Alpha} fontWeight={FontWeightEnum.Medium} color={ColorsEpico.ColorGray}>con el folio</Typography>
                            <Typography fontSize={FontSizesEnum.Lambda} fontWeight={FontWeightEnum.Bold} color={ColorsEpico.ColorPrimary}>{responsePool?.folioPrecuadre}</Typography>
                        </Stack>
                    </Stack>
                    <Stack direction="row" alignItems="center" justifyContent="center" spacing={1}>
                        <Button
                            variant="outlined"
                            sx={{
                                fontWeight: FontWeightEnum.Medium,
                                color: ColorsEpico.ColorDarkCharcoal,
                                borderColor: ColorsEpico.ColorGrayNeutral,
                                width: '150px',
                            }}
                            disabled={pendingGetContacts}
                            onClick={pendingGetContacts ? undefined : () => onClose(true)}
                        >Cerrar</Button>
                        <ButtonLoading
                            variant="contained"
                            sx={{ background: ColorsEpico.ColorsDarkBlue, width: '214px' }}
                            onClick={sharedPreReconciliation}
                            loading={pendingGetContacts}
                        >Compartir</ButtonLoading>
                    </Stack>
                </Stack>
            </ModalWithoutButtons>

            {openModalShared && <SharedModalGeneric
                open={openModalShared}
                onClose={() => setOpenModalShared(false)}
                onSend={sendPreReconciliation}
                isLoading={pendingShared}
                infoShared={infoShared}
            />}


            {openModalGeolocation && <ModalGeneric
                titulo="Sin acceso a la Ubicación"
                btnTextSave="Aceptar"
                openModal={openModalGeolocation}
                onSave={geolocationPermissionActived}
                isLoading={loadingPermissionGeolocation}
                onClose={() => {
                    setOpenModalGeolocation(false);
                }}
                borderModal={`2px solid ${ColorsEpico.ColorVibrantYellow} !important`}
            >
                <Typography>Para realizar el pre cuadre es necesario permitir el uso de la ubicación</Typography>
            </ModalGeneric>}

        </Fragment >
    )
}