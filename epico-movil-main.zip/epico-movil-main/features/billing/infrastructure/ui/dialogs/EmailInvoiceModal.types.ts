/**
 * Props for the `EmailInvoiceModal` component.
 * 
 * @interface EmailInvoiceModalProps
 * @property {string} title - The title displayed in the modal header.
 * @property {number | string} documentId - The ID of the CFDI document to be sent via email.
 * @property {string} serie - The series of the CFDI document.
 * @property {boolean} isOpen - Determines whether the modal is open.
 * @property {() => void} onClose - Function to handle modal closure.
 * @property {number | undefined} sucursalId - The ID of the branch associated with the invoice, optional.
 * @property {string} mainContact - Email the main contact.
 */
export interface EmailInvoiceModalProps {
    title: string;
    documentId: number | string;
    serie: number | string;
    isOpen: boolean;
    onClose: () => void;
    sucursalId: number | undefined;
    mainContact?: string;
}