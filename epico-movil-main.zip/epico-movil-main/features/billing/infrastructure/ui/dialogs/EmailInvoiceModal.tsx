'use client'

import { FC, JSX, useEffect, useState } from "react";
import { Box, TextField, Typography } from "@mui/material";
import { EmailInvoiceModalProps } from "@/features/billing/infrastructure/ui/dialogs/EmailInvoiceModal.types";
import { billingService } from "@/features/billing/application/services/billing.services";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { regexMail } from "@/features/common/infrastructure/utils/regexGlobal";
import { IBodySendDocumentsEmail } from "@/features/billing/domain/interfaces/IBodySendDocumentsEmail";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";


/**
 * EmailInvoiceModal Component.
 * 
 * @component
 * @param {EmailInvoiceModalProps} props - The props for the component.
 * @property {string} title - The title displayed in the modal header.
 * @property {number | string} documentId - The ID of the CFDI document to be sent via email.
 * @property {string} serie - The series of the CFDI document.
 * @property {boolean} isOpen - Determines whether the modal is open.
 * @property {() => void} onClose - Function to handle modal closure.
 * @property {number} sucursalId - Get the sucursalId.
 * @property {string} mainContact - Get the email main contact.
 * 
 * @returns {JSX.Element} The rendered `EmailInvoiceModal` component.
 */
const EmailInvoiceModal: FC<EmailInvoiceModalProps> = ({
    title,
    documentId,
    serie,
    isOpen,
    onClose,
    sucursalId,
    mainContact
}): JSX.Element => {
    //#region Services
    const { sendInvoiceQuotation } = billingService();
    //#endregion Services
    //#region Hooks
    const { showSnackbar } = useSnackbar();
    //#endregion Hooks

    //#region States
    const [email, setEmail] = useState("");
    const [emailError, setEmailError] = useState(false);
    const [isSending, setIsSending] = useState(false);
    //#endregion States

    useEffect(() => {
        setEmail(mainContact || "");
    }, [])

    /**
    * Validates the email format.
    * 
    * This function checks the email input against a regular expression 
    * to ensure it adheres to a standard email format.
    * 
    * @param {string} value - The email address to validate.
    */
    const validateEmail = (value: string) => setEmailError(!regexMail.test(value));

    /**
     * Handles the email submission process.
     * 
     * This function validates the email, shows a loading state, and 
     * calls the service to send the email. If successful, it closes the modal.
     */
    const handleSendEmail = async () => {
        if (!email || emailError) {
            validateEmail(email);
            return;
        }
        await sendEmail();
    };

    /**
     * Sends an email with the invoice details.
     *
     * @async
     * @function sendEmail
     * @returns {Promise<void>} A promise that resolves when the email operation is complete.
     */
    const sendEmail = async () => {
        setIsSending(true);
        const body: IBodySendDocumentsEmail = {
            sucursalId: sucursalId!,
            documentoId: documentId,
            serie: serie,
            email: email,
        }
        const response = await sendInvoiceQuotation(body);
        handleRequestDto({
            snackBar: showSnackbar,
            response: response,
            onSuccess() {
                onClose();
            },
            messages: {
                invalid: 'Error al enviar el correo, favor de volver a intentarlo',
                success: 'El correo se envió con éxito'
            },
            onError: () => {
                showSnackbar(NOTIFICATIONS_CHECKOUT.GENERAL.ERROR, 'error');
                onClose();
            }
        })
        setIsSending(false);
    }

    return (
        <ModalGeneric
            openModal={isOpen}
            onClose={onClose}
            onSave={handleSendEmail}
            btnTextSave={"Enviar"}
            btnTextClose="Cancelar"
            titulo={title}
            isLoading={isSending}
        >
            <Box
                component="form"
                onSubmit={(e) => {
                    e.preventDefault();
                    handleSendEmail();
                }}
            >
                <Typography component="label" fontWeight={FontWeightEnum.Bold} fontSize={FontSizesEnum.Gamma} textTransform="uppercase" htmlFor="textFiled-email">correo</Typography>
                <TextField
                    id="textFiled-email"
                    name="textFiled-email"
                    variant="outlined"
                    defaultValue={email}
                    placeholder='Correo electronico'
                    fullWidth
                    error={emailError}
                    color={emailError ? "error" : "primary"}
                    helperText={emailError ? (
                        <Typography fontSize={FontSizesEnum.Epsilon} fontWeight={FontWeightEnum.Regular} color={ColorsEpico.ColorRed}>El correo ingresado no es válido</Typography>
                    ) : ""}
                    onChange={(e) => {
                        setEmail(e.target.value);
                        validateEmail(e.target.value);
                    }}
                    slotProps={{
                        input: {
                            sx: {
                                height: '30px',
                                fontSize: FontSizesEnum.Delta,
                                fontWeight: FontWeightEnum.Regular
                            },
                        },
                        formHelperText: {
                            sx: {
                                margin: '0px',
                                height: '0px',
                                fontSize: FontSizesEnum.Epsilon,
                                fontWeight: FontWeightEnum.Regular,
                                color: `${ColorsEpico.ColorRed} !important`
                            }
                        }
                    }}
                    sx={{
                        '& .MuiInputBase-input': {
                            padding: '0 10px !important',
                            height: '100%'
                        },
                        m: '16px 0px 8px',
                        p: '0 !important'
                    }}
                />
            </Box>
        </ModalGeneric>
    );
};

export default EmailInvoiceModal;
