import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import dayjs from "dayjs";

/**
 * Interface for filtering statement invoices
 *
 * @export
 * @interface InitStatementInvoiceFilters
 * @property {number | string} [IdBusqueda] - Optional identifier for specific search criteria
 * @property {dayjs.Dayjs | null} [FechaInicio] - Optional start date for filtering invoices
 * @property {dayjs.Dayjs | null} [FechaFin] - Optional end date for filtering invoices  
 * @property {StatusOrderEnum | null} [EstatusId] - Optional status identifier for filtering by invoice status
 * @property {number} [ClienteVendedorId] - Optional identifier for the client or seller associated with the invoice
 * @property {number} [UsuarioId] - Optional identifier for the user associated with the invoice
 * @property {string} OrdenPor - Field by which to order the results (e.g., 'pedidoid')
 * @property {string} OrdenTipo - Type of ordering ('asc' for ascending, 'desc' for descending)
 * @property {OrigenEnum} OrigenId - Identifier for the invoice origin (e.g., Epico)
 * @property {boolean} used - Indicates whether the filter has been used or applied
 * @property {number} Pagina - Pagination parameters
 * @property {number} TamañoPagina - Pagination parameters
 */
export interface IStatementInvoiceFilters {
    Pagina: number;
    TamañoPagina: number;
    IdBusqueda?: number | string;
    FechaInicio?: dayjs.Dayjs | null;
    FechaFin?: dayjs.Dayjs | null;
    EstatusId?: StatusOrderEnum | null;
    ClienteVendedorId?: number;
    UsuarioId?: number;
    OrdenPor: string;
    OrdenTipo: string;
    OrigenId: OrigenEnum;
    used: boolean;
}