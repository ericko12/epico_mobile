/**
* Interface representing the details of a product in an invoice.
*
* @export
* @interface IProductDetailInvoice
* @property {number} productoId - Unique identifier for the product.
* @property {string} producto - Name of the product.
* @property {string} imagen - URL of the product image.
* @property {string} descripcion - Detailed description of the product.
* @property {number} cantidad - Quantity of the product included in the invoice.
* @property {number} precio - Unit price of the product.
* @property {number} descuento - Discount applied to the product.
* @property {string} precioEspecial - Special price applied to the product, if any.
* @property {number} importe - Total amount for the product (calculated as `Cantidad * Precio` minus any discounts).
*/
export interface IProductDetailInvoice {
    productoId: number
    producto: string
    imagen: string
    descripcion: string
    cantidad: number
    precio: number
    descuento: number
    precioEspecial: string
    importe: number
}