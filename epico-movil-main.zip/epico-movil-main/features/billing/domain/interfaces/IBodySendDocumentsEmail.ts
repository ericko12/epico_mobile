/**
 * Interface representing the payload for sending document emails.
 *
 * @interface IBodySendDocumentsEmail
 * @property {number} sucursalId - The ID of the branch associated with the document.
 * @property {string | number} documentoId - The ID of the document to be sent.
 * @property {string | number} serie - The series of the document.
 * @property {string} email - The recipient's email address.
 */
export interface IBodySendDocumentsEmail {
    sucursalId: number,
    documentoId: string | number,
    serie: string | number,
    email: string,
}