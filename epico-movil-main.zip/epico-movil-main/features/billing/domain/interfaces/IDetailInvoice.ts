import { InvoiceStatusEnum } from "@/features/billing/domain/enum/InvoiceStatusEnum";

/**
 * Interface for detailed invoice information.
 *
 * @export
 * @interface IDetailInvoice
 * @property {number} facturaId - Unique identifier for the invoice.
 * @property {string} serie - Series code or prefix for grouping invoices.
 * @property {number} sucursalId - Identifier for the branch associated with the invoice.
 * @property {string} sucursal - Name or description of the associated branch.
 * @property {number} pedidoId - Identifier for the associated order.
 * @property {string} fecha - Date the invoice was issued (format: YYYY-MM-DD).
 * @property {string} fechaVencimiento - Due date for the invoice payment (format: YYYY-MM-DD).
 * @property {number} diasVencimiento - Number of days until the invoice expires.
 * @property {number} monto - Total amount of the invoice.
 * @property {number} saldo - Remaining balance on the invoice.
 * @property {boolean} timbrado - Indicates if the invoice has been digitally stamped or certified.
 * @property {number} clienteVendedorId - Identifier for the client or vendor associated with the invoice.
 * @property {string} estatus - Current status of the invoice (e.g., "Paid", "Pending").
 * @property {InvoiceStatusEnum} vigencia - Validity status of the invoice (e.g., "Vencida", "Vigente").
 * @property {boolean} digitalizada - Indicates if the invoice has been digitally digitized.
 * @property {number} descuentoProntoPago - Discount for early payment (e.g., 10% of the invoice amount).
 * @property {ISolicitudPrecuadre[]} solicitudesPrecuadres - Array of solicitudes of precuadres.
 */
export interface IDetailInvoice {
    facturaId: number;
    serie: string;
    sucursalId: number;
    sucursal: string;
    pedidoId: number;
    fecha: string;
    fechaVencimiento: string;
    diasVencimiento: number;
    monto: number;
    saldo: number;
    timbrado: boolean;
    clienteVendedorId: number;
    estatus: string;
    vigencia: InvoiceStatusEnum;
    digitalizada: boolean;
    descuentoProntoPago: number;
    solicitudesPrecuadres: {
        folio: number;
        urlSolicitudPrecuadrePdf: string;
    }[];
}