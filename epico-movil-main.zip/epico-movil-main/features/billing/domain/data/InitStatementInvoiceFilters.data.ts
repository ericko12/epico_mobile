import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { IStatementInvoiceFilters } from "@/features/billing/domain/interfaces/IStatementInvoiceFilters";


/**
 * Auxiliary to have an initial state of the filters in the view
 *
 * @type {IStatementInvoiceFilters}
 */
export const InitStatementInvoiceFilters: IStatementInvoiceFilters = {
    IdBusqueda: '',
    Pagina: 0,
    TamañoPagina: 10,
    OrdenPor: "pedidoid",
    OrdenTipo: "desc",
    OrigenId: OrigenEnum.Epico,
    FechaInicio: null,
    FechaFin: null,
    used: false
}