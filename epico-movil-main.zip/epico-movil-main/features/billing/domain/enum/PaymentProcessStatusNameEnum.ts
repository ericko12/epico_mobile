/**
 * Enum for payment process status
 *
 * @export
 * @enum {number}
 */
export enum PaymentProcessStatusNameEnum {
    Esperando = "Esperando",
    EnProceso = "En Proceso",
    RespuestaAutomatica = "Respuesta Automática",
    Aceptado = "Aceptado",
    Rechazado = "Rechazado",
    Otro = "Otro",
    Cancelado = "Cancelado",
    Modificar = "Modificar",
    Pendiente = "Pendiente",
}