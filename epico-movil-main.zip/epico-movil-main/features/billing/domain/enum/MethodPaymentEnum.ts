/**
 * Enum for the method of payment
 *
 * @enum {number} MethodPaymentEnum
 */
export enum MethodPaymentEnum {
    EFECTIVO = 1,
    CHEQUE = 2,
    TRANSFERENCIA = 3,
}