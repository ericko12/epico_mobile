/**
 * Enum for payment process status
 *
 * @export
 * @enum {number}
 */
export enum PaymentProcessStatusEnum {
    Esperando = 1,
    EnProceso = 2,
    RespuestaAutomatica = 3,
    Aceptado = 4,
    Rechazado = 5,
    Otro = 6,
    Cancelado = 7,
    Modificadar = 8,
    Pendiente = 9,
}