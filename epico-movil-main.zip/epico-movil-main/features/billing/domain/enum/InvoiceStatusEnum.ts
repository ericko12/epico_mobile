
/**
 * Identify invoice status
 *
 * @export
 * @enum {number}
 */
export enum InvoiceStatusEnum {
    Vencida = "Vencida",
    Vigente = "Vigente"
}