import { IPagination } from "@/features/common/domain/interfaces/pagination/IPagination";
import { UserPedidosSucursalesSortColumns } from "@/features/orders/domain/types/Orders.types";

/**
 * Interface for Torre de Control webhook request
 * 
 * @export
 * @interface ITorreDeControlPayload
 * @property {number | null} [pedidoHijoId] - Optional identifier for child order in case of split orders.
 * @property {number} sucursalOrigen - Identifier of the originating branch/sucursal.
 * @property {number | null} [clienteId] - Optional identifier of the client associated with the order.
 * @property {string | null} [fechaHora] - Optional timestamp of the event (ISO 8601 format).
 * @property {string | null} [tipoEnvio] - Optional shipping type (e.g., "DOMICILIO", "RECOGE").
 * @property {string | null} [tipoFlujo] - Optional flow type (e.g., "ESTANDAR", "EXPRESS").
 * @property {number | null} [paqueteria] - Optional identifier of the shipping carrier/company.
 * @property {number | null} [subtotalPedido] - Optional subtotal amount of the order.
 * @property {string | null} [noFactura] - Optional invoice number associated with the order.
 * @property {string | null} [estadoInicial] - Optional initial status of the order.
 * @property {string | null} [guiaRastreo] - Optional tracking guide number for shipment.
 * @property {string | null} [telefono] - Optional contact phone number for the order.
 * @property {string | null} [fechaEstimadaReparto] - Optional estimated delivery date (ISO 8601 format).
 * @property {boolean | null} [envioAHh] - Optional flag indicating if shipment is to a Home Hub (HH).
 * @property {number | null} [pedidoIdPadre] - Optional identifier of the parent order in case of order hierarchy.
 * @property {number | null} [pedidoIdPrincipal] - Optional identifier of the main/principal order.
 * @property {number | null} [userId] - Optional identifier of the user who performed the action.
 * @property {string | null} [motivo] - Optional cancellation reason, required when eventType is "order.cancel".
 */
export interface ITorreDeControlPayload {
  PedidoHijoId?: number | null;
  SucursalOrigen: number;
  ClienteId?: number | null;
  FechaHora?: string | null;
  TipoEnvio?: string | null;
  TipoFlujo?: string | null;
  Paqueteria?: number | null;
  SubtotalPedido?: number | null;
  NoFactura?: string | null;
  EstadoInicial?: string | null;
  GuiaRastreo?: string | null;
  Telefono?: string | null;
  FechaEstimadaReparto?: string | null;
  EnvioAHh?: boolean | null;
  PedidoIdPadre?: number | null;
  PedidoIdPrincipal?: number | null;
  UserId?: number | null;
  Motivo?: string | null;
  SistemaOrigenId: number | null;
}