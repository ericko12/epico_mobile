/**
 * Interface for Torre de Control webhook request
 * 
 * @export
 * @interface ICorrelationResolverResponse
 * @property {string} correlationId - unique identifier to track request across multiple systems (UUID format).
 * @property {number} currentStateId - the Id of the state of the correlation event in control tower.
 * @property {string} currentState - current state of the correlation event in control tower.
 * @property {string?} message - message in case of any observation.
 * @property {number} occurrence - the number of times of the event.
 * @property {boolean} isRepeatable - check if the event has been repeated.
 */
export interface ICorrelationResolverResponse {
  correlationId: string;
  currentStateId: number;
  currentState: string;
  message: string;
  occurrence: number;
  isRepeatable: boolean;
}