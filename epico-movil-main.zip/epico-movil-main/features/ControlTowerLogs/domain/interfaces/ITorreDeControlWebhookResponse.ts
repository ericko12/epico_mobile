/**
 * Response interface for Torre de Control webhook operations
 * 
 * @export
 * @interface ITorreDeControlWebhookResponse
 * @property {string} eventId - Unique GUID identifier generated when the operation is successful. 
 *                               Format: "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
 * @property {string} message - Server response message describing the result of the operation.
 *                               Examples: "Evento registrado exitosamente", "Evento duplicado ignorado"
 * @property {string} receivedAt - ISO 8601 UTC timestamp confirming when the event was received and processed.
 *                                  Format: "YYYY-MM-DDTHH:mm:ss.fffffffZ"
 */
export interface ITorreDeControlWebhookResponse {
    eventId: string;
    message: string;
    receivedAt: string;
}