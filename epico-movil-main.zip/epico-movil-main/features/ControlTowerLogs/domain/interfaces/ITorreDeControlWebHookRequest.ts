import { ITorreDeControlPayload } from "@/features/ControlTowerLogs/domain/interfaces/ITorreDeControlPayload";

/**
 * Interface for Torre de Control webhook request
 * 
 * @export
 * @interface ITorreDeControlWebhookRequest
 * @property {number} sourceSystemId - Identifier of the source system that originated the event.
 * @property {string} eventType - Type of event being sent (e.g., "order.created", "order.cancelled").
 * @property {string} eventVersion - Version of the event schema (default: "1.0").
 * @property {string?} occurredAt - Timestamp of when the event occurred (ISO 8601 format in UTC, e.g., "2026-04-13T18:25:08.1525308Z").
 * @property {string} idempotencyKey - Unique key to ensure idempotency of the request, prevents duplicate processing.
 * @property {string} correlationId - Optional unique identifier to track request across multiple systems (UUID format).
 * @property {string} entityType - Type of entity being modified (e.g., "pedido").
 * @property {string} entityId - Unique identifier of the entity (order ID).
 * @property {string} branchId - Identifier of the originating branch/sucursal.
 * @property {ITorreDeControlPayload} payload - Event-specific payload data containing order details.
 */
export interface ITorreDeControlWebhookRequest {
  sourceSystemId: number;
  eventType: string;
  eventVersion?: string;
  occurredAt?: string;
  idempotencyKey: string;
  correlationId?: string; 
  entityType: string;
  entityId: string;
  branchId: string;
  payload: ITorreDeControlPayload;
}