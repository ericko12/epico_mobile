import { UrlControlTowerWebhook, UrlCorrelationResolver } from "@/features/ControlTowerLogs/infraestructure/api/controlTowerUrl"
import { ITorreDeControlWebhookRequest } from "@/features/ControlTowerLogs/domain/interfaces/ITorreDeControlWebHookRequest"
import { ITorreDeControlWebhookResponse } from "@/features/ControlTowerLogs/domain/interfaces/ITorreDeControlWebhookResponse"
import { ICorrelationResolverResponse } from "@/features/ControlTowerLogs/domain/interfaces/ICorrelationResolverResponse"
import { TORRECONTROL_API } from "@/axios/axios_helper";
import { handleRequest } from "@/features/common/infrastructure/api/handleRequest";

export const controlTowerService = () => ({
  /**
   * Service to register a log in control tower
   * @param {ItorreDeControlWebHookRequest} body - Data to register
   * @returns {Promise<IResponseDto<null>>} -returns the data of the customer
   */
  createNewLogControlTower: (body: ITorreDeControlWebhookRequest) =>
    handleRequest<ITorreDeControlWebhookResponse>(TORRECONTROL_API.post(UrlControlTowerWebhook(), body)),
  /**
   * Service to obtain the correlationId in control Tower.
   * @param {number} orderId - Order number
   * @param {number} branchId - Branch number
   * @returns {Promise<IResponseDto<null>>} -returns the data of the customer
   */
  findCorrelationId: (orderId: number, branchId: number) =>
    handleRequest<ICorrelationResolverResponse>(TORRECONTROL_API.get(UrlCorrelationResolver(orderId,branchId)))
});