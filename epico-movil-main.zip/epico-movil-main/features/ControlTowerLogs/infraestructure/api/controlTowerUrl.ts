/**
 * The URL to consult to send events to control tower api log
 *
 * @param {string} id - the clienteId of the customer
 * @returns {string} 
 */

export const UrlControlTowerWebhook = (): string =>
`/Webhook`;
/**
 * The URL to consult the Correlation ID in control tower api log
 *
 * @param {number} orderId - the Order id of the customer.
 * @param {number} branchId - the branch origin of the order.
 * @returns {string} 
 */

export const UrlCorrelationResolver = (orderId: number, branchId: number): string =>
`/CorrelationResolver/${orderId}/${branchId}`;