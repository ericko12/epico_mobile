import { IBranch } from "@/features/branch/domain/interfaces/branch";

/**
 * Interface for the state of the branches
 *
 * @interface IBranchesState
 * @property {IBranch[]} branchesList - List of branches
 */
export interface IBranchesState {
    branchesList: IBranch[];
}