import { IBranchOrdersFilters } from "@/features/branch/domain/interfaces/branch";
import dayjs from "dayjs";

/**
 * Interface for branch orders request
 *
 * @export
 * @interface IBranchOrdersRequest
 * @extends {Omit<IBranchOrdersFilters, 'used' | 'applyFilters'>}
 * @property {number[]} OrigenIds - A list of numeric origin IDs that are associated with the branch orders.
 * @property {?string} [TipoKMS] - An optional string representing the type of KMS for the branch orders.
 * @property {?dayjs.Dayjs} [FechaInicioAlta] - An optional dayjs object representing the start date for filtering branch orders based on their creation date.
 * @property {?dayjs.Dayjs} [FechaFinAlta] - An optional dayjs object representing the end date for filtering branch orders based on their creation date.
 * @description This interface represents a request for branch orders, excluding the 'used', 'applyFilters', 'OrigenId' and 'OrigenIds' properties from the IBranchOrdersFilters interface.
 */
export interface IBranchOrdersRequest extends Omit<IBranchOrdersFilters, 'used' | 'applyFilters' | 'OrigenId' | 'OrigenIds'> {
    OrigenIds: number[];
    TipoKMS?: string;
    FechaInicioAlta?: dayjs.Dayjs | null;
    FechaFinAlta?: dayjs.Dayjs | null;
}