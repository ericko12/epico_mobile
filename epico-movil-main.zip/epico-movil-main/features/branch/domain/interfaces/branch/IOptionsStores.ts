/**
 * Interface representing store options/details
 * 
 * @interface IOptionsStores
 * @property {number} id - Unique identifier for the store
 * @property {string} name - Name of the store
 * @property {string} description - Description of the store
 * @property {string} time - Time information related to the store (e.g. operating hours)
 */
export interface IOptionsStores {
    id: number;
    name: string;
    description: string;
    time: string;
}