/**
 * Interface for branch order details
 *
 * @export
 * @interface IBranchOrderDetails
 * @property {number} pedidoIdSucursal - Identifier for the order at the specific branch.
 * @property {number} facturaId - Unique identifier for the invoice associated with the order.
 * @property {string} serie - Series code assigned to the order or invoice.
* @property {number} sucursalId - Unique identifier for the branch.
 * @property {string} sucursal - Name of the branch.
 * @property {string | undefined} [fechaEntrega] - Optional delivery date for the order (format: YYYY-MM-DD).
 * @property {string} tipoEntrega - Type of delivery (e.g., 'in-store', 'delivery').
 * @property {number} totalPedido - Total amount for the order.
 * @property {number} estatusId - Identifier for the current status of the order.
 * @property {string} estatus - Description of the current status of the order.
 * @property {number} origenId - Identifier for the origin related to the order.
 * @property {string} origen - Description or name of the origin related to the order.
 * @property {string} fechaHora - The date when the order was captured (format: YYYY-MM-DD).
 * @property {string} rastreo - Url tranking order.
 * @property {string} estatusAdicional - Status of the url traking order.
 */
export interface IBranchOrderDetails {
    pedidoIdSucursal: number;
    facturaId: number;
    serie: string;
    sucursalId: number;
    sucursal: string;
    fechaEntrega?: string;
    tipoEntrega: string;
    totalPedido: number;
    estatusId: number;
    estatus: string;
    origenId: number;
    origen: string;
    fechaHora: string;
    rastreo: string;
    estatusAdicional: string;
}