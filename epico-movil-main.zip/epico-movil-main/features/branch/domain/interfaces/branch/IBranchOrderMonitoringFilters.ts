import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import dayjs from "dayjs";

/**
 * Interface for filtering branch orders
 *
 * @export
 * @interface IBranchOrdersFilters
 * @property {number} Pagina - Page number
 * @property {number} TamañoPagina - Page size
 * @property {number | string} [IdBusqueda] - Optional identifier for specific search criteria.
 * @property {number | null} [SucursalId] - Optional identifier for the branch related to the order.
 * @property {string | null} [FechaInicio] - Optional start date for filtering orders (format: YYYY-MM-DD).
 * @property {string | null} [FechaFin] - Optional end date for filtering orders (format: YYYY-MM-DD).
 * @property {StatusOrderEnum | null} [EstatusId] - Optional status identifier for filtering by order status.
 * @property {number} [ClienteVendedorId] - Optional identifier for the client or seller associated with the order.
 * @property {number} [UsuarioId] - Optional identifier for the user associated with the order.
 * @property {OrigenEnum} OrigenId - Identifier for the order origin (required).
 * @property {?OrigenEnum[]} OrigenIds - List of orders systems sources.
 * @property {boolean} used - Indicates whether the filter has been used or applied.
 */
export interface IBranchOrdersMonitoringFilters {
    Pagina: number;
    TamañoPagina: number;
    IdBusqueda?: number | string;
    SucursalId?: number | null;
    FechaInicio?: dayjs.Dayjs | null;
    FechaFin?: dayjs.Dayjs | null;
    EstatusId?: StatusOrderEnum | null;
    ClienteVendedorId?: number;
    UsuarioId?: number;
    OrigenId: OrigenEnum;
    OrigenIds?: OrigenEnum[];
    used: boolean;
    StatusId?: number;
}