/**
 * Interface: IBranchesIds
 * 
 * Defines the structure of the request body when sending a list of branch IDs
 * to endpoints that require filtering or generating data for specific branches.
 *
 * @property {number[]} branchesIds - An array of branch IDs to be processed by the API.
 */
export interface IBranchesIds {
    SucursalIds: number[]
}