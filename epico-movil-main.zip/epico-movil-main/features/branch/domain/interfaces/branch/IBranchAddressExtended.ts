import { IBranchAddress } from "@/features/branch/domain/interfaces/branch/IBranchAddress";

/**
 * Extended interface that represents a branch address with additional properties.
 *
 * @export
 * @interface IBranchAddressExtended
 * @extends IBranchAddress
 * @property {boolean} [autex] - Indicates if the branch is an Autex branch (optional).
 * @property {string} calle - The street name where the branch is located.
 * @property {string} codigoPostal - The postal code of the branch address.
 * @property {string} colonia - The neighborhood or district where the branch is located.
 * @property {string} descripcion - The description or name of the branch.
 * @property {string} estado - The name of the state where the branch is located.
 * @property {number} estadoID - The ID of the state where the branch is located.
 * @property {number} ciudadId - The unique identifier of the city where the branch is located.
 * @property {string} ciudad - The name of the city where the branch is located.
 * @property {{ apertura: string; cierre: string; dia: string; diaSemana: number; infoSucursalId: number; }[]} [horarios] - The schedules of the branch (optional).
 * @property {number} infoSucursalID - The unique identifier for the branch information.
 * @property {number} lat - The latitude coordinate of the branch.
 * @property {number} lng - The longitude coordinate of the branch.
 * @property {string} municipio - The municipality or city where the branch is located.
 * @property {string} noExterior - The exterior number of the branch address.
 * @property {string | null} [noInterior] - The interior number of the branch address (optional).
 * @property {string} pais - The country where the branch is located.
 * @property {string} [tel1] - The primary phone number of the branch (optional).
 * @property {string} [tel2] - The secondary phone number of the branch (optional).
 * @property {string} [tel3] - The tertiary phone number of the branch (optional).
 * @property {string} nombreGRUN - The name of the GRUN (regional management unit) associated with the branch.
 * @property {string} nombreGUN - The name of the GUN (operational management unit) associated with the branch.
 * @property {string} telefonoGRUN - The contact phone number of the GRUN associated with the branch.
 * @property {string} telefonoGUN - The contact phone number of the GUN associated with the branch.
 
 */
export interface IBranchAddressExtended extends IBranchAddress {
  autex: boolean;
  calle: string;
  codigoPostal: string;
  colonia: string;
  descripcion: string;
  estado: string;
  estadoID: number;
  ciudadId: number;
  ciudad: string;
  horarios: {
    apertura: string;
    cierre: string;
    dia: string;
    diaSemana: number;
    infoSucursalId: number;
  }[];
  infoSucursalID: number;
  lat: number;
  lng: number;
  municipio: string;
  noExterior: string;
  noInterior?: string | null;
  pais: string;
  tel1: string;
  tel2: string;
  tel3: string;
  nombreGRUN: string;
  nombreGUN: string;
  telefonoGRUN: string;
  telefonoGUN: string;

}