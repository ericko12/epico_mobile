/**
 * Represents the relationship between a branch office and a region.
 * 
 * @interface IBranchRegion
 * @property {number} id - The unique identifier for the branch-region association.
 * @property {number} branchOfficeId - The unique identifier of the branch office.
 * @property {string} branchOfficeName - The name of the branch office.
 * @property {number} regionId - The unique identifier of the region.
 * @property {string} regionName - The name of the region.
 */
export interface IBranchRegion {
    id: number;
    branchOfficeId: number;
    branchOfficeName: string;
    regionId: number;
    regionName: string;
}