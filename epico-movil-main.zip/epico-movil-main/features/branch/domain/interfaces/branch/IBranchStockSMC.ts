/**
 * Interface that defines the properties related to the stock of a branch.
 * @export
 * @interface IBranchStockSMC
 * @property {string} descripcion - Description of the branch.
 * @property {number} distancia - Distance in numeric format (e.g. kilometers).
 * @property {string} distanciaTexto - Description of the distance in text format (e.g. "9.25 km").
 * @property {number} infoSucursalID - Unique identifier of the branch.
 * @property {string} tiempo - Estimated delivery time at the branch (e.g. "02:05:00").
 * @property {string} tiempoTexto - Description of the estimated time in text format (e.g. "125 min").
 * @property {string} tipoServicio - Type of service offered at the branch (e.g. "Local extended").
 * @property {number} tipoServicioSucursalID - Unique identifier of the service type in the branch.
 */
export interface IBranchStockSMC {
    descripcion: string;
    distancia: number;
    distanciaTexto: string;
    infoSucursalID: number;
    tiempo: string;
    tiempoTexto: string;
    tipoServicio: string;
    tipoServicioSucursalID: number;
}
