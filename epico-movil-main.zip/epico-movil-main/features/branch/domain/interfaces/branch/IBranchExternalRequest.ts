/**
 * Interface that defines the request body for the branch external order.
 * 
 * @interface IBranchExternalRequest
 * @property {number} userId - The ID of the user who is making the request.
 * @property {number[]} branchesIds - The IDs of the branches that the user is assigning to the external order.
 */
export interface IBranchExternalRequest {
    userId: number;
    branchesIds: number[];
}