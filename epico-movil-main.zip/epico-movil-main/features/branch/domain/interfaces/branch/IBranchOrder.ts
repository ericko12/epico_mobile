import { IDepartureBranch } from "@/features/branch/domain/interfaces/branch/IDepartureBranch";
import { ShippingMethodEnum } from "@/features/shipment/domain/enum/ShippingMethodEnum";

/**
 * Interface representing a branch order.
 *
 * @interface IBranchOrder
 * @property {number} pedidoSucursalId - Identifier for the branch order.
 * @property {number} sucursalId - Identifier for the branch.
 * @property {string} sucursal - Name of the branch.
 * @property {number} statusId - Current status of the order.
 * @property {Date} fecha - Date when the branch order was placed.
 * @property {Date} fechaEntrega - Date when the order was delivered.
 * @property {number} totalArticulos - Total number of articles in the branch order.
 * @property {ShippingMethodEnum} metodoEnvio - Shipping method used.
 * @property {number} concesionId - Identifier for the concession.
 * @property {string} concesion - Name of the concession.
 * @property {number} plazo - Deadline for the order.
 * @property {number} direccionId - Identifier for the address.
 * @property {string} direccion - Address of the client.
 * @property {string} direccionSucursal - Address of the branch.
 * @property {string} direccionPaqueteria - Address of the shipping service.
 * @property {number} metodoPagoId - Identifier for the payment method.
 * @property {string} metodoPago - Name of the payment method.
 * @property {number} montoTotal - Total amount of the branch order.
 * @property {number} descuentos - Discounts applied to the branch order.
 * @property {number} impuestos - Taxes applied to the branch order.
 * @property {number} prontoPago - Discount for early payment.
 * @property {number} total - Final total amount after discounts and taxes.
 * @property {string} observaciones - comments about order.
 * @property {IDepartureBranch[]} partidas - List of articles in the branch order.
 * @property {Date} ETA - Date of the Estimated Time Of Arrivale (optional)
 * @property {Date} FechaMonitoreoSurtido -(Optional) date of the assortmant
 */
export interface IBranchOrder {
    pedidoSucursalId: number;
    sucursalId: number;
    sucursal: string;
    statusId: number;
    fecha: Date;
    fechaEntrega: Date;
    totalArticulos: number;
    metodoEnvio: ShippingMethodEnum;
    concesionId: number;
    concesion: string;
    plazo: number;
    direccionId: number;
    direccion: string;
    direccionSucursal: string;
    direccionPaqueteria: string;
    metodoPagoId: number;
    metodoPago: string;
    montoTotal: number;
    descuentos: number;
    impuestos: number;
    prontoPago: number;
    total: number;
    observaciones: string;
    partidas: IDepartureBranch[];
    kmsAplicados?: number | string;
    eta?: Date;
    fechaMonitoreoSurtido?: Date;
}