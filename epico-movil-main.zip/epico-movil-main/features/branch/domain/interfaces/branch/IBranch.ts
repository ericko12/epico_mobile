/**
 * Represents the information of a branch.
 * 
 * @export
 * @interface IBranch
 * 
 * @property {number} id - Unique identifier for the branch.
 * @property {number} ivaId - Identifier associated with the branch's VAT (Value Added Tax).
 * @property {number} iva - VAT rate applied to the branch.
 * @property {string} sucursal - Name or description of the branch.
 * @property {string} identificador - Unique code or identifier for the branch.
 */
export interface IBranch {
    id: number;
    ivaId: number;
    iva: number;
    sucursal: string;
    identificador: string;
}