/**
 * Interface that represents a branch address with its properties.
 *
 * @export
 * @interface IBranchAddress
 * @property {string} sucursal - The name of the branch
 * @property {number} sucursalId - The unique identifier of the branch
 * @property {string} calle - The street name where the branch is located
 * @property {string} noExterior - The exterior number of the branch address
 * @property {string | null} noInterior - The interior number of the branch address (optional)
 * @property {string} colonia - The neighborhood or district where the branch is located
 * @property {string} municipio - The municipality or city where the branch is located
 * @property {number} estadoId - The ID of the state where the branch is located
 * @property {string} estado - The name of the state where the branch is located
 * @property {string} codigoPostal - The postal code of the branch address
 */
export interface IBranchAddress {
  sucursal: string;
  sucursalId: number;
  calle: string;
  noExterior: string;
  noInterior?: string | null;
  colonia: string;
  municipio: string;
  estadoId: number;
  estado: string;
  codigoPostal: string;
}