/**
 * Interface representing an article in a branch order.
 *
 * @interface IDepartureBranch
 * @property {number} productoId - Identifier for the product.
 * @property {string} producto - Name of the product.
 * @property {string} imagen - Image URL of the product.
 * @property {string} descripcion - Description of the product.
 * @property {number} marcaId - Identifier for the product brand.
 * @property {string} marca - Name of the product brand.
 * @property {number} cantidad - Quantity of the product ordered.
 * @property {number} precio - Final line amount for the product, already discounted.
 * @property {?number | null} kmsPagados - Optional. the amount of kms that the customer payed.
 * @property {?number | null} precioUnitario - Optional. Price of a single piece with discounts already applied, so precioUnitario * cantidad matches precio.
 */
export interface IDepartureBranch {
    productoId: number;
    producto: string;
    imagen: string;
    descripcion: string;
    marcaId: number;
    marca: string;
    cantidad: number;
    precio: number;
    kmsAplicados?: number | null;
    precioUnitario?: number | null;
}