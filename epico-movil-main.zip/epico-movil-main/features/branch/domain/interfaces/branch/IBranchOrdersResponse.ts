import { IExternalOrder } from "@/features/orders/domain/interfaces/externalOrder";
import { IBranchOrderDetails } from "@/features/branch/domain/interfaces/branch/IBranchOrderDetails";
import { IPagination } from "@/features/common/domain/interfaces/pagination/IPagination";

/**
 * Interface for the response of branch orders
 *
 * @export
 * @interface IBranchOrdersResponse
 * @property {number} cantidadRegistros - Total number of records returned in the response.
 * @property {number} cantidadPaginas - Total number of pages available for pagination.
 * @property {number} paginaActual - Current page number being viewed.
 * @property {number} tamPagina - Number of items per page in the response.
 * @property {IBranchOrderDetails[]} pedidosSucursal - Array of branch orders included in the response.
 * @property {number} totalPedidosTomados - Initial number of orders already taken by users.
 * @property {IExternalOrder[]?} pedidosExternos - Array of external orders included in the response.
 */
export interface IBranchOrdersResponse extends IPagination {
    pedidosSucursal: IBranchOrderDetails[];
    totalPedidosTomados: number
    pedidosExternos?: IExternalOrder[];
}