import { AutocompleteProps, SxProps, TextFieldProps } from "@mui/material";
import { IBranch } from "@/features/branch/domain/interfaces/branch";

/**
 * Properties for the Autocomplete component, excluding `renderInput`.
 * @type {Omit<AutocompleteProps<IBranch, false, false, false>, 'renderInput'>} AutocompletePropsType
 */
type AutocompletePropsType = Omit<AutocompleteProps<IBranch, false, false, false>, 'renderInput'>;

/**
 * Interface for the properties of the Autocomplete branch selection component.
 * @interface IAutocompleteSelectSucursal
 * 
 * @property {?IBranch | null} [branch] - The currently selected branch, or `null` if no branch is selected.
 * @property {?ReadonlyArray<IBranch>} [optionBranches] - List of available branch options to choose from.
 * @property {?TextFieldProps} [propsTextField] - Custom properties for the `TextField` component.
 * @property {?Partial<AutocompletePropsType>} [propsAutocomplete] - Additional custom properties for the `Autocomplete` component, excluding `renderInput`.
 * @property {(option: IBranch | null) => void} handleBranch - Callback function executed when the selected branch changes.
 * @property {?boolean} [disabledBranch] - A flag to disable the branch selection (if `true`).
 * @property {?number} [width] - Custom width for the component in pixels.
 */
export interface IAutocompleteSelectSucursal {
    branch?: IBranch | null,
    optionBranches?: ReadonlyArray<IBranch>,
    propsTextField?: TextFieldProps,
    propsAutocomplete?: Partial<AutocompletePropsType>,
    handleBranch: (option: IBranch | null) => void,
    disabledBranch?: boolean,
    /** Ancho del componente. Acepta px (número), string o valores responsivos por breakpoint. */
    width?: number | string | Partial<Record<'xs' | 'sm' | 'md' | 'lg' | 'xl', number | string>>
}