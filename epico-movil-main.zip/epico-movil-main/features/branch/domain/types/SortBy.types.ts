/**
 * Type: SortBy
 * 
 * Defines the available fields that can be used to sort branch data in API requests.
 * 
 * @typedef {"EstadoID" | "Sucursal"} SortBy
 * 
 * @property {"EstadoID"} EstadoID - Sort results by the state ID.
 * @property {"Sucursal"} Sucursal - Sort results by the branch name.
 */
export type SortBy =
    | "EstadoID"
    | "Sucursal";