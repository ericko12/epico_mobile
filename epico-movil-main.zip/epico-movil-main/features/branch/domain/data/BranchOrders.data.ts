import { IBranchOrdersResponse } from "@/features/branch/domain/interfaces/branch";

/**
 * Initial state for branch orders response
 *
 * @export
 * @constant {IBranchOrdersResponse} InitBranchOrders
 * @description This constant represents the initial state for the branch orders response, with default values.
 * @property {number} cantidadRegistros - The initial total number of records (default is 0).
 * @property {number} cantidadPaginas - The initial total number of pages (default is 0).
 * @property {number} paginaActual - The initial current page number (default is 0).
 * @property {number} tamPagina - The default number of items per page (default is 10).
 * @property {number} totalPedidosTomados - Initial number of orders already taken by users (default is 0).
 * @property {BranchOrder[]} pedidosSucursal - An empty array to hold branch orders.
 */
export const InitBranchOrders: IBranchOrdersResponse = {
    cantidadRegistros: 0,
    cantidadPaginas: 0,
    paginaActual: 0,
    tamPagina: 10,
    totalPedidosTomados: 0,
    pedidosSucursal: [],
}