import { EPICO_API } from "@/axios/axios_helper";
import { configHeaders } from "@/features/common/application/service/ConfigHeaders";
import { catchResponse } from "@/features/common/domain/axios/catchResponse";
import { IResponseAxiosDto, IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { UrlSecurityProjectInStore, UrlSecurityProjectInOrigin } from "@/features/branch/infrastructure/api/branchUrl";
import { ISecurityOrigin } from "@/features/common/domain/interfaces/security/IOrigin";

/**
 * Service for consuming the SecurityProjectService.
 * Provides functions to validate if a project is active in a specific branch.
 * 
 * @returns {Object} An object containing the ProjectActiveInSucursal function
 * @property {function} ProjectActiveInSucursal - Function that checks if a project is active for a branch
 * 
 * @example
 * const { ProjectActiveInSucursal } = SecurityProjectService();
 * const isActive = await ProjectActiveInSucursal(projectId, branchId);
 */
export const SecurityProjectService = () => {
    /**
     * Validates if a project is active for a specific branch.
     * Makes a request to check the project status in the given branch.
     * 
     * @param {number} ObjetoId - The project ID to validate
     * @param {number} SucursalId - The branch ID where to check the project status
     * @returns {Promise<IResponseDto<boolean | null>>} Response object containing:
     *   - success: true if request was successful
     *   - data: true if project is active, false if inactive, null if not found
     *   - message: Optional status message
     * @throws {Error} If the request fails
     */
    const ProjectActiveInSucursal = async (ObjetoId: number, SucursalId: number) => {
        try {
            const res: IResponseAxiosDto<IResponseDto<boolean | null>> = (await EPICO_API.get(UrlSecurityProjectInStore(ObjetoId, SucursalId), configHeaders()))
            return res.data as IResponseDto<boolean | null>;
        } catch (e: any) {
            return catchResponse(e);
        }
    };

    const ProjectActiveInOrigin = async (ObjetoId: number) => {
        try {
            const res: IResponseAxiosDto<IResponseDto<ISecurityOrigin | null>> = (await EPICO_API.get(UrlSecurityProjectInOrigin(ObjetoId, 16), configHeaders()))
            return res.data as IResponseDto<ISecurityOrigin | null>;
        } catch (e: any) {
            return catchResponse(e);
        }
    }
    return {
        ProjectActiveInSucursal,
        ProjectActiveInOrigin
    }

}