import { branchService } from "@/features/branch/application/services/branch.services";
import { IBranch } from "@/features/branch/domain/interfaces/branch";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { AlertColor } from "@mui/material";

/**
 * Petición para obtener sucursales
 *
 * @async
 * @param {(message: string, type?: AlertColor) => void} showSnackbar
 * @returns {Promise<IBranch[]>}
 */
export const fetchBranchesAction = async (showSnackbar: (message: string, type?: AlertColor) => void): Promise<IBranch[]> => {
    const { getBranches } = branchService();


    const resBranches: IResponseDto<IBranch[] | null> = await getBranches();



    const branches = await handleRequestDto<IBranch[] | null, IBranch[]>({
        snackBar: showSnackbar,
        response: resBranches,
        onSuccess: () => {
            return resBranches.data?.sort((a, b) => a.sucursal.localeCompare(b.sucursal)) ?? [];
        },
        messages: {
            error: 'Error al obtener las sucursales',
            invalid: 'Petición invalida de sucursales, revise los datos'
        }
    }) || [];

    return branches;
};
