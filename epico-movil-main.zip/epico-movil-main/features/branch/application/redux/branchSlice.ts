import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { IBranchesState } from "@/features/branch/domain/interfaces/branch/IBranchState";
import { IBranch } from "@/features/branch/domain/interfaces/branch";

// Define the initial state using that type
const branchesInitialState: IBranchesState = {
    branchesList: []
}

const branchesSlice = createSlice({
    // key
    name: "branches",
    // state
    initialState: branchesInitialState,
    // reducers
    reducers: {

        /**
         * Method to set the list of branches
         * @param state - The current state of the slice
         * @param action - Receives the list of branches to set
         */
        setBranches: (state: IBranchesState, action: PayloadAction<IBranch[]>) => {
            // 'action.payload' must contain the new list of branches
            state.branchesList = action.payload;
        }
    },
});

export const { setBranches } = branchesSlice.actions;
export default branchesSlice.reducer;