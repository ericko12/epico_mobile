import { IBranch } from "@/features/branch/domain/interfaces/branch"
import { setBranches } from "@/features/branch/application/redux/branchSlice"

/**
 * Method that queries the branches and stores them in redux
 *
 * @param {IBranch[]} branches
 * @returns {Promise<(dispatch: Function) => Promise<void>>}
 */
export const fetchBranchesThunk = async (branches: IBranch[]) => {
    return async (dispatch: Function) => {
        const sortedBranchs = branches.sort((a, b) => a.sucursal.localeCompare(b.sucursal)) ?? []
        await dispatch(setBranches(sortedBranchs))
    }
}
