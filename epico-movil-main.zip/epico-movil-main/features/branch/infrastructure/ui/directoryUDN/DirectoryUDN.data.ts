export const BREAD_CRUMBS_DIRECTORY_UDN = [
    { title: "Directorio de UDN" },
]
