"use client";

import { useEffect, useState, useTransition } from "react";
import { branchService } from "@/features/branch/application/services/branch.services";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { useBreadcrumb } from "@/features/common/infrastructure/hooks/useBreadcrumb";
import { BREAD_CRUMBS_DIRECTORY_UDN } from "@/features/branch/infrastructure/ui/directoryUDN/DirectoryUDN.data";
import { TableDirectoryUDN } from "@/features/branch/infrastructure/ui/directoryUDN/table/TableDirectoryUDN";
import { IBranchAddressExtended } from "@/features/branch/domain/interfaces/branch/IBranchAddressExtended";
import { Box, Divider, Typography } from "@mui/material";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { sxPaddingContainer } from "@/features/branch/infrastructure/ui/directoryUDN/DirectoryUDN.style";
import { FiltersDirectoryUDN } from "@/features/branch/infrastructure/ui/directoryUDN/filtersDirectoryUDN/FiltersDirectoryUDN";
import { IFiltersDirectoryUDN } from "@/features/branch/infrastructure/ui/directoryUDN/filtersDirectoryUDN/FiltersDirectoryUDN.type";
import { InitFiltersDirectoryUDN } from "@/features/branch/infrastructure/ui/directoryUDN/filtersDirectoryUDN/FiltersDirectoryUDN.data";
import { ContriesEnum } from "@/features/shipment/domain/enum/CountriesEnum";
import { OrderTypeEnum } from "@/features/common/domain/enums/OrderTypeEmun";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { IBranchesIds } from "@/features/branch/domain/interfaces/branch/IBranchesIds";

export const DirectoryUDN = () => {
    //#region services
    const { getBranchAddress, getPdfAddresses } = branchService();

    //#endregion services

    //#region hooks
    const { showSnackbar } = useSnackbar();
    const { setBreadcrumb } = useBreadcrumb();
    //#endregion hooks

    //#region state
    const [branchAddress, setBranchAddress] = useState<IBranchAddressExtended[]>([]);
    const [branchAddressFiltered, setBranchAddressFiltered] = useState<IBranchAddressExtended[]>([]);
    const [filters, setFilters] = useState<IFiltersDirectoryUDN>(InitFiltersDirectoryUDN);
    const [isSearched, startSearched] = useTransition();
    const [loadingPdf, setLoadingPdf] = useState<boolean>(false);
    const [disabledPdf, setDisabledPdf] = useState<boolean>(false);
    //#endregion state

    useEffect(() => {
        init()
    }, []);

    useEffect(() => {
        setDisabledPdf(branchAddressFiltered.length === 0);
    }, [branchAddressFiltered]);

    const init = async () => {
        setBreadcrumb(BREAD_CRUMBS_DIRECTORY_UDN)
        fetchAllBranchAddress();
    }


    const fetchAllBranchAddress = async () => {
        startSearched(async () => {
            const response = await getBranchAddress(true, ContriesEnum.Mexico, OrderTypeEnum.asc, 'Sucursal');
            if (response.data) {

                setBranchAddress(response.data ?? []);
                setBranchAddressFiltered(response.data ?? []);

            } else {
                showSnackbar(GENERIC_ERROR_MESSAGE_CAE, 'error');
            }

        })
    }

    /**
     * Normalizes a string by removing diacritics and converting it to lowercase.
     * @param {string} str - The string to normalize.
     * @returns {string} The normalized string.
     */
    const normalize = (str: string) => str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trimStart().trimEnd();


    const handleSearch = () => {
        startSearched(async () => {
            let dataBranche: IBranchAddressExtended[] = []
            let appliedFilters = false;
            const searchTrim = filters.search.trimStart().trimEnd();
            if (filters.state !== '') {
                const filteredBranches = branchAddress.filter(({ estadoID }) => estadoID === +filters.state);
                dataBranche.push(...filteredBranches);
                appliedFilters = true;
            }
            if (filters.search.length > 0) {
                const search = normalize(filters.search);
                const filteredBranches = filterBranches(search, filters.state !== '' ? dataBranche : branchAddress);
                dataBranche = filteredBranches;
                appliedFilters = true;
            }

            const uniqueDataBranche = Array.from(
                new Map(dataBranche.map(branch => [branch.infoSucursalID, branch])).values()
            )

            uniqueDataBranche.sort((a, b) => a.descripcion.localeCompare(b.descripcion));

            setFilters({ ...filters, used: appliedFilters, search: searchTrim });
            setBranchAddressFiltered(appliedFilters ? uniqueDataBranche : branchAddress);
        })
    }

    const filterBranches = (value: string, branchAddressSearch: IBranchAddressExtended[]): IBranchAddressExtended[] => {
        const normalizedValue = normalize(value);
        return branchAddressSearch.filter(({ infoSucursalID, descripcion }) =>
            infoSucursalID.toString().includes(normalizedValue) ||
            normalize(descripcion).includes(normalizedValue)
        );
    }

    const handleResetFilters = () => {
        startSearched(async () => {
            setFilters(InitFiltersDirectoryUDN);
            setBranchAddressFiltered(branchAddress);
        })
    }

    const downloadPdf = async () => {
        try {
            setLoadingPdf(true);
            const branchIds: IBranchesIds = {
                SucursalIds: branchAddressFiltered.map(branch => branch.infoSucursalID)
            };
            const response = await getPdfAddresses('Sucursal', OrderTypeEnum.asc, branchIds);
            await handleRequestDto({
                snackBar: showSnackbar,
                response: response,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE
                },
                onSuccess: () => {
                    if (response.data) {
                        const binaryString = atob(response.data);
                        const len = binaryString.length;
                        const bytes = new Uint8Array(len);
                        for (let i = 0; i < len; i++) {
                            bytes[i] = binaryString.charCodeAt(i);
                        }

                        const blob = new Blob([bytes], { type: 'application/pdf' });
                        const url = URL.createObjectURL(blob);

                        const link = document.createElement('a');
                        link.href = url;
                        link.download = 'Directorio.pdf';
                        link.click();

                        URL.revokeObjectURL(url);
                        showSnackbar('El PDF se descargo correctamente.', 'success');
                    }
                },
            });
        } catch (error) {
            console.log('error', error)
            showSnackbar(GENERIC_ERROR_MESSAGE_CAE, 'error');
        } finally {
            setLoadingPdf(false);
        }
    };

    return (
        <Box>
            <Box sx={sxPaddingContainer}>
                <FiltersDirectoryUDN
                    filters={filters}
                    setFilters={setFilters}
                    loading={isSearched}
                    handleSearch={handleSearch}
                    handleResetFilters={handleResetFilters}
                    downloadPdf={downloadPdf}
                    loadingPdf={loadingPdf}
                    disabledPdf={disabledPdf}
                />

                <Typography
                    fontSize={FontSizesEnum.Alpha}
                    fontWeight={FontWeightEnum.Bold}
                    textTransform={'uppercase'}
                >directorio de udn</Typography>
            </Box>
            <Divider />
            <Box sx={{
                ...sxPaddingContainer,
                pb: '80px'
            }}>
                <TableDirectoryUDN
                    branchAddress={branchAddressFiltered}
                    loading={isSearched}
                    usedFilter={filters.used}
                />
            </Box>
        </Box>

    )
}


