import { IBranchAddressExtended } from "@/features/branch/domain/interfaces/branch/IBranchAddressExtended";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { formatInternationalMXPhone } from "@/features/common/infrastructure/utils/formatInternationalMXPhone";
import { Room } from "@mui/icons-material";
import { GridColDef } from "@mui/x-data-grid";

const handleValidateCell = (cell: string | number | null) => {
    return cell !== "" && cell !== null && cell !== undefined ? cell : '-';
}

export const COLUMNS_DIRECTORY_UDN = (
): GridColDef<IBranchAddressExtended>[] => [
        {
            headerName: 'Sucursal ID',
            field: 'infoSucursalID',
            width: 120,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
        },
        {
            headerName: 'Sucursal',
            field: 'descripcion',
            minWidth: 130,
            maxWidth: 220,
            flex: 1,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
        },
        {
            headerName: 'Dirección',
            field: 'calle',
            minWidth: 147,
            flex: 1,
            align: 'left',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                return <div
                    title={`${row.calle} #${row.noExterior} ${row.noInterior ? `Int. ${row.noInterior}` : ''} Col. ${row.colonia}, ${row.codigoPostal} ${row.municipio}, ${row.estado}`}
                    style={{
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        width: '100%',
                    }}
                >
                    {`${row.calle} #${row.noExterior} ${row.noInterior ? `Int. ${row.noInterior}` : ''} Col. ${row.colonia}, ${row.codigoPostal} ${row.municipio}, ${row.estado}`}
                </div>
            },
        },
        {
            headerName: 'Teléfonos de la sucursal',
            field: 'tel1',
            minWidth: 147,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                return <div
                    title={`${formatInternationalMXPhone(row.tel1)} - ${formatInternationalMXPhone(row.tel2)} - ${formatInternationalMXPhone(row.tel3)}`}
                    style={{
                        overflow: 'hidden',
                        whiteSpace: 'pre-line',
                        textOverflow: 'ellipsis',
                        width: '100%',
                        wordBreak: 'break-word',
                    }}
                >
                    {`${formatInternationalMXPhone(row.tel1)} - ${formatInternationalMXPhone(row.tel2)} - ${formatInternationalMXPhone(row.tel3)}`}
                </div>
            },
        },
        {
            headerName: 'Nombre del GRUN',
            field: 'nombreGRUN',
            minWidth: 147,
            maxWidth: 220,
            flex: 1,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                return <div
                    title={row.nombreGRUN ?? '-'}
                    style={{
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        width: '100%',
                    }}
                >
                    {row.nombreGRUN ?? '-'}
                </div>
            },
        },
        {
            headerName: 'Teléfono GRUN',
            field: 'telefonoGRUN',
            minWidth: 147,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                const cell = handleValidateCell(row.telefonoGRUN) as string;
                return <div
                    title={cell}
                    style={{
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        width: '100%',
                    }}
                >
                    {cell}
                </div>
            },
        },
        {
            headerName: 'Nombre del GUN',
            field: 'nombreGUN',
            minWidth: 147,
            maxWidth: 220,
            flex: 1,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                const cell = handleValidateCell(row.nombreGUN) as string;
                return <div
                    title={cell}
                    style={{
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        width: '100%',
                    }}
                >
                    {cell}
                </div>
            },
        },
        {
            headerName: 'Teléfono GUN',
            field: 'telefonoGUN',
            minWidth: 147,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                const cell = handleValidateCell(row.telefonoGUN) as string;
                return <div
                    title={cell}
                    style={{
                        overflow: 'hidden',
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        width: '100%',
                    }}
                >
                    {cell}
                </div>
            },
        },
        {
            headerName: '',
            field: 'actions',
            minWidth: 50,
            maxWidth: 50,
            flex: 1,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {

                return <Room
                    onClick={() => window.open('https://www.google.com/maps/search/' + row.lat + ',' + row.lng, '_blank')}
                    sx={{
                        size: FontSizesEnum.Eta,
                        color: ColorsEpico.ColorBlack,
                        cursor: 'pointer',
                    }}
                />
            }
        },
    ]