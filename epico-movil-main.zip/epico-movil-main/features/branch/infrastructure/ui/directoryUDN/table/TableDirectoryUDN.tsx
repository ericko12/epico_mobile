import { Fragment, useState } from "react"
import { AdaptiveDataGrid } from "@/features/common/infrastructure/ui/tables/adaptiveDataGrid/AdaptiveDataGrid"
import { ITableDirectoryUDNProp } from "@/features/branch/infrastructure/ui/directoryUDN/table/TableDirectoryUDN.type"
import { IBranchAddressExtended } from "@/features/branch/domain/interfaces/branch/IBranchAddressExtended"
import { SxDataGridServerPagination } from "@/features/common/infrastructure/ui/tables/DataGridServerPagination.styles"
import { COLUMNS_DIRECTORY_UDN } from "@/features/branch/infrastructure/ui/directoryUDN/table/TableDirectoryUDN.data"
import { Box } from "@mui/material"
import { GridPaginationModel } from "@mui/x-data-grid"
import { NotFoundData } from "@/features/common/infrastructure/ui/tables/NotFoundData"
import { EmptyData } from "@/features/common/infrastructure/ui/tables/EmptyData"

export const TableDirectoryUDN: React.FC<ITableDirectoryUDNProp> = ({
    branchAddress,
    loading,
    usedFilter
}) => {

    //#region States
    const [paginationModel, setPaginationModel] = useState<GridPaginationModel>({ pageSize: 10, page: 0 });
    //#endregion States

    return (
        <Fragment>
            <Box sx={{ display: "grid", height: { xs: 'auto', md: '35.1rem' } }}>
                <AdaptiveDataGrid
                    sx={SxDataGridServerPagination}
                    cardOptions={{ titleField: 'descripcion' }}
                    columns={COLUMNS_DIRECTORY_UDN()}
                    rows={branchAddress}
                    getRowId={(row: IBranchAddressExtended) => row.infoSucursalID}
                    disableRowSelectionOnClick
                    paginationMode="client"
                    paginationModel={paginationModel}
                    onPaginationModelChange={setPaginationModel}
                    loading={loading}
                    slots={{
                        noRowsOverlay: () => {
                            if (loading) return null;
                            return usedFilter ? <NotFoundData msg="No se encontraron resultados con los criterios seleccionados" /> : <EmptyData msg="No hay UDN por mostrar" />;
                        },
                    }}
                />
            </Box>
        </Fragment>
    )
}
