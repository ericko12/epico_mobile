import { IBranchAddressExtended } from "@/features/branch/domain/interfaces/branch/IBranchAddressExtended";

/**
 * Props for the TableDirectoryUDN component.
 * @interface ITableDirectoryUDNProp
 * @property {IBranchAddressExtended[]} branchAddress - Array of branch address objects to be displayed in the table.
 */
export interface ITableDirectoryUDNProp {
    branchAddress: IBranchAddressExtended[];
    loading: boolean;
    usedFilter: boolean;
}

