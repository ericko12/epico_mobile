import { SxProps } from "@mui/system";

export const sxPaddingContainer: SxProps = {
    px: { xs: "12px", md: "32px" },
    pt: { xs: "16px", md: "24px" },
}