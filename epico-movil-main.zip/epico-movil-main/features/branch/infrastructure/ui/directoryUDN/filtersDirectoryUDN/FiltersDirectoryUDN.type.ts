import { Dispatch, SetStateAction } from "react";

/**
 * Props for the FiltersDirectoryUDN component.
 * @interface IFiltersDirectoryUDNProps
 * @property {IFiltersDirectoryUDN} filters - The current filter values for the UDN directory.
 * @property {Dispatch<SetStateAction<IFiltersDirectoryUDN>>} setFilters - Function to update the filter values.
 * @property {boolean} loading - Indicates if the filter/search operation is in progress.
 * @property {() => void} handleSearch - Function to execute when the search is triggered.
 * @property {() => void} handleResetFilters - Function to reset all filters to their initial state.
 * @property {() =>void} downloadPdf - Function to download the branch directory in PDF.
 * @property {boolean} loadingPdf - Indicates whether the PDF download process is currently in progress.
 * @property {boolean} disabledPdf - Indicates whether the PDF download button should be disabled.
 */
export interface IFiltersDirectoryUDNProps {
    filters: IFiltersDirectoryUDN;
    setFilters: Dispatch<SetStateAction<IFiltersDirectoryUDN>>;
    loading: boolean;
    handleSearch: () => void;
    handleResetFilters: () => void;
    downloadPdf: () => void;
    loadingPdf: boolean;
    disabledPdf: boolean;
}

/**
 * Interface representing the filters used in the UDN directory.
 * @interface IFiltersDirectoryUDN
 * @property {string} search - The search term for filtering branches.
 * @property {string} state - The selected state for filtering branches.
 * @property {boolean} used - Indicates if filters are currently applied.
 */
export interface IFiltersDirectoryUDN {
    search: string;
    state: string;
    used: boolean;
}

