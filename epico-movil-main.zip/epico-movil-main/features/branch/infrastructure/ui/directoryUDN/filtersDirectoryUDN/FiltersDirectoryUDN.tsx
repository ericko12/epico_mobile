import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { addressService } from "@/features/address/application/service/AddressService";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { ISelect } from "@/features/common/domain/interfaces/select/ISelect";
import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading";
import { CleanFilterIcon } from "@/features/common/infrastructure/ui/icons/CleanFilterIcon";
import { InputSearch } from "@/features/common/infrastructure/ui/inputs/InputSearch";
import { SelectGeneric } from "@/features/common/infrastructure/ui/select/selectGeneric/SelectGeneric";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { ContriesEnum } from "@/features/shipment/domain/enum/CountriesEnum";
import { FileDownload } from "@mui/icons-material";
import { Stack, Button } from "@mui/material";
import { ChangeEvent, useEffect, useState } from "react";
import { IFiltersDirectoryUDNProps } from "@/features/branch/infrastructure/ui/directoryUDN/filtersDirectoryUDN/FiltersDirectoryUDN.type";
import { regexTextNumbers } from "@/features/common/infrastructure/utils/regexGlobal";

export const FiltersDirectoryUDN: React.FC<IFiltersDirectoryUDNProps> = ({
    filters,
    setFilters,
    loading,
    handleSearch,
    handleResetFilters,
    downloadPdf,
    loadingPdf,
    disabledPdf
}) => {
    //#region services
    const { getStates } = addressService();
    //#endregion services
    //#region state
    const [states, setStates] = useState<ISelect[]>([]);
    const [loadingStates, setLoadingStates] = useState(true);
    //#endregion state
    //#region hooks
    const { showSnackbar } = useSnackbar();
    //#endregion hooks

    useEffect(() => {
        fetchStates();
    }, []);

    const fetchStates = async () => {
        setLoadingStates(true);
        const response = await getStates(ContriesEnum.Mexico);
        await handleRequestDto({
            snackBar: showSnackbar,
            response: response,
            messages: {
                error: GENERIC_ERROR_MESSAGE_CAE,
                invalid: GENERIC_ERROR_MESSAGE_CAE
            },
            onSuccess: () => {
                const removeAccents = (str: string) =>
                    str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');

                const normalizeStateName = (state: string) =>
                    removeAccents(state).toLowerCase().trim();

                const uniqueStatesMap = new Map<string, any>();
                (response.data ?? []).forEach(state => {
                    const normalizedKey = normalizeStateName(state.estado);
                    if (!uniqueStatesMap.has(normalizedKey)) {
                        uniqueStatesMap.set(normalizedKey, state);
                    }
                });
                const uniqueStates = Array.from(uniqueStatesMap.values());
                setStates(uniqueStates?.sort((a, b) => a.estado.localeCompare(b.estado)).map(state => ({
                    value: state.estadoId,
                    label: state.estado
                })) ?? []);
            },
            onError: () => {
                setStates([]);
            },
            onInvalid: () => {
                setStates([]);
            }
        })
        setLoadingStates(false);
    }

    const handleSearchText = (e: ChangeEvent<HTMLInputElement>) => {
        const text = e.target.value;
        if (text.length === 1 && text === ' ' || text.length === 1 && !regexTextNumbers.test(text)) return;
        if (text.length > 0 && text.replace(/\s/g, '').length === 0) {
            setFilters({ ...filters, search: '' })
            return;
        }
        if (text.length === 0 || regexTextNumbers.test(text) || (text.length === 1 && text !== ' ')) {
            setFilters({ ...filters, search: text })
        }
    }

    return (
        <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" alignItems={{ xs: 'stretch', md: 'center' }} gap={{ xs: 2, md: 0 }} mb={3}>
            <Stack direction={{ xs: 'column', sm: 'row' }} gap={2}>
                <SelectGeneric
                    placeHolder="Estado"
                    options={states}
                    sxSelect={{ width: { xs: '100%', sm: '270px' } }}
                    sizeFont={FontSizesEnum.Gamma}
                    loading={loadingStates || loading}
                    disabled={loading || states.length === 0}
                    onChange={e => setFilters({ ...filters, state: e.target.value })}
                    value={filters.state}
                />
                <InputSearch
                    value={filters.search}
                    onChange={handleSearchText}
                    placeholder="Buscar por Sucursal o Sucursal ID"
                    sxTextFieldProps={{ width: { xs: '100%', sm: '361px' } }}
                    enter={handleSearch}
                    disabled={loadingStates || loading}
                />
                <Stack direction="row">
                    <ButtonLoading
                        size="small"
                        variant="contained"
                        onClick={handleSearch}
                        disabled={loadingStates || loading || (filters.state === '' && filters.search === '')}
                        loading={loadingStates || loading}
                        sx={{
                            width: { xs: '100%', md: '90px' },
                            height: '2.4rem',
                            boxShadow: 'none',
                            borderRadius: '.4rem',
                            bgcolor: ColorsEpico.ColorDodgerBlue,
                            color: ColorsEpico.ColorWhite,
                            fontSize: FontSizesEnum.Beta,
                            fontWeight: FontWeightEnum.Medium
                        }}
                    >
                        Buscar
                    </ButtonLoading>
                    <Button
                        onClick={handleResetFilters}
                        disabled={loadingStates || loading || !filters.used}
                        style={{
                            backgroundColor: filters.used ? ColorsEpico.ColorsDarkBlue : ColorsEpico.ColorGrayDisabled,
                            color: ColorsEpico.ColorWhite,
                            marginLeft: '12px',
                            padding: '5px 15px',
                            border: 'none',
                            borderRadius: '4px',
                            width: '50px',
                            height: '37px',
                        }}
                    >
                        <CleanFilterIcon />
                    </Button>
                </Stack>
            </Stack>
            <ButtonLoading
                loading={loadingPdf}
                disabled={disabledPdf || loadingPdf}
                onClick={downloadPdf}
                variant="outlined"
                sx={{
                    width: { xs: '100%', md: '166px' },
                    color: ColorsEpico.ColorBlack,
                    borderColor: ColorsEpico.ColorLightBlueishGray,
                }}
            >
                Descargar PDF <FileDownload sx={{ fontSize: '20px' }} />
            </ButtonLoading>
        </Stack>
    )
}
