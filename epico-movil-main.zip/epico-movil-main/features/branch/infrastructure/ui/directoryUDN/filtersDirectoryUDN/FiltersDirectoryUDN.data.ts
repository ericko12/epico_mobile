import { IFiltersDirectoryUDN } from "@/features/branch/infrastructure/ui/directoryUDN/filtersDirectoryUDN/FiltersDirectoryUDN.type";

/**
 * Initial value for the filters used in the UDN directory.
 * @type {IFiltersDirectoryUDN}
 * @property {string} search - Search term for filtering branches.
 * @property {string} state - Selected state for filtering branches.
 * @property {boolean} used - Indicates if filters are currently applied.
 */
export const InitFiltersDirectoryUDN: IFiltersDirectoryUDN = {
    search: '',
    state: '',
    used: false
}
