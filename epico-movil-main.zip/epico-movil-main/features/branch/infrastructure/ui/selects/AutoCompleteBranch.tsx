
import { FC, useEffect, useRef, useState } from "react";

import { Autocomplete, Box, CircularProgress, Paper, TextField, Tooltip } from "@mui/material";

import { IAutocompleteSelectSucursal } from "@/features/branch/domain/interfaces/IAutocompleteSelectSucursal";
import { IBranch } from "@/features/branch/domain/interfaces/branch";

import { TruncatedAutocompleteMenuItem } from "@/features/common/infrastructure/ui/AutoComplete/TruncatedAutocompleteMenuItem";

/**
 * Enum imports.
 */
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";

/**
 * Component that renders a branch (sucursal) select dropdown.
 * 
 * @param {IBranch | null} [branch] - The currently selected branch.
 * @param {ReadonlyArray<IBranch>} [optionBranches] - Array of available branches to select from.
 * @param {Partial<AutocompletePropsType>} [propsAutocomplete] - Additional props for the Autocomplete component.
 * @param {TextFieldProps} [propsTextField] - Additional props for the TextField component.
 * @param {(option: IBranch | null) => void} [handleBranch] - Function to handle branch selection.
 * @param {boolean} [disabledBranch] - Whether the select should be disabled and appear greyed out.
 * @property {number} [width] - Custom width for the component in pixels.
 */
export const AutoCompleteBranch: FC<IAutocompleteSelectSucursal> = ({
    optionBranches = [], branch = null, propsTextField, propsAutocomplete, handleBranch, disabledBranch, width }) => {
    // states
    const [openSelect, setOpenSelect] = useState<boolean>(false);
    const [isTruncated, setIsTruncated] = useState(false);
    const [isPlaceholderTruncated, setIsPlaceholderTruncated] = useState(false);
    const textRef = useRef<HTMLInputElement>(null);
    const placeholderRef = useRef<HTMLSpanElement>(null);

    // constant
    const loading: boolean = openSelect && optionBranches.length === 0;

    /**
     * Effect hook to check if the selected option text or the placeholder text is truncated (i.e., larger than the container).
     * It sets the `isTruncated` and `isPlaceholderTruncated` state variables accordingly, which can be used to conditionally show tooltips.
     * The effect runs whenever the `branch` changes, ensuring that it checks for truncation whenever a new option is selected.
     */
    useEffect(() => {
        if (!textRef.current && !placeholderRef.current) return;

        /**
         * Check if the option text is larger than the
         * container and set truncate for that option.
         */
        const checkTruncation = () => {
            if (textRef.current)
                setIsTruncated(textRef.current.scrollWidth > textRef.current.clientWidth);
        };

        /**
         * Check if the placeholder text is larger than the
         * container and set truncate for the placeholder.
         */
        const checkPlaceholderTruncation = () => {
            if (placeholderRef.current)
                setIsPlaceholderTruncated(placeholderRef.current.scrollWidth > placeholderRef.current.clientWidth);
        };

        checkTruncation();
        checkPlaceholderTruncation();

        const observer = new ResizeObserver(() => {
            checkTruncation();
            checkPlaceholderTruncation();
        });

        if (textRef.current) observer.observe(textRef.current);
        if (placeholderRef.current) observer.observe(placeholderRef.current);

        return () => {
            observer.disconnect();
        };
    }, [branch]);

    return (
        <Box sx={{ position: 'relative', display: 'inline-block', width: width ?? 200 }}>
            {/* Hidden span to measure placeholder truncation */}
            <span
                ref={placeholderRef}
                style={{
                    position: 'absolute',
                    visibility: 'hidden',
                    pointerEvents: 'none',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    fontSize: FontSizesEnum.Delta,
                    maxWidth: 'calc(100% - 56px)',
                }}
            >
                Sucursal
            </span>
            <Autocomplete
                disabled={disabledBranch}
                id="atc-sucursales"
                size="small"
                open={openSelect}
                value={branch}
                onChange={(_, option: IBranch | null) => handleBranch(option)}
                onOpen={() => { setOpenSelect(true) }}
                onClose={() => { setOpenSelect(false) }}
                options={optionBranches}
                isOptionEqualToValue={(option, value) => option.id === value.id}
                getOptionLabel={(option) => option.sucursal}
                loading={loading}
                renderOption={(props, option) => (
                    <TruncatedAutocompleteMenuItem
                        key={option.id}
                        label={option.sucursal}
                        liProps={props}
                    />
                )}
                slots={{
                    paper: (props) => (
                        <Paper {...props}>
                            {props.children}
                        </Paper>
                    ),
                }}
                renderInput={(params) => (
                    <Tooltip
                        title={
                            isTruncated && branch
                                ? branch.sucursal
                                : isPlaceholderTruncated && !branch
                                    ? 'Sucursal'
                                    : ''
                        }
                    >
                        <TextField
                            {...params}
                            {...propsTextField}
                            inputRef={textRef}
                            label="Sucursal"
                            placeholder={!branch ? 'Sucursal' : ''}
                            slotProps={{
                                input: {
                                    ...params.InputProps,
                                    style: {
                                        color: branch ? ColorsEpico.ColorGreenLush : ColorsEpico.ColorBlack,
                                        fontSize: FontSizesEnum.Delta,
                                        fontWeight: branch ? FontWeightEnum.Bold : FontWeightEnum.Lite,
                                    },
                                    endAdornment: (
                                        <>
                                            {loading ? <CircularProgress color="inherit" size={10} /> : null}
                                            {params.InputProps.endAdornment}
                                        </>
                                    ),
                                },
                                htmlInput: {
                                    ...params.inputProps,
                                    style: { textOverflow: 'ellipsis' },
                                },
                                inputLabel: {
                                    style: {
                                        fontWeight: FontWeightEnum.Regular,
                                        color: ColorsEpico.ColorGray,
                                    }
                                }
                            }}
                            sx={{
                                '& fieldset': {
                                    borderRadius: '.5rem',
                                    backgroundColor: disabledBranch ? ColorsEpico.ColorLightBlueishGray : 'inherit',
                                },
                                "& .MuiOutlinedInput-root": {
                                    "&.MuiInputBase-root fieldset": {
                                        borderColor: ColorsEpico.ColorLightBlueishGray,
                                    },
                                },
                                width: '100%',
                                '& input::placeholder': {
                                    fontSize: FontSizesEnum.Delta,
                                    color: 'black',
                                },
                            }}
                        />
                    </Tooltip>
                )}
                {...propsAutocomplete}
            />
        </Box>
    )
}