import { FC, useEffect, useState } from "react"
import { Checkbox, CircularProgress, FormControlLabel, SelectChangeEvent, Stack, Typography } from "@mui/material";
import _ from "lodash";
import { SelectBranchesProps } from "@/features/branch/infrastructure/ui/selectBranches/SelectBranches.type";
import { StockService } from "@/features/common/application/service/StockService";
import { useAppSelector } from "@/features/common/application/redux/hooks";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { useFormContext } from "@/features/shipment/infrastructure/ui/formShippingProvider/FormShippingProvider";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { IOrderShipmentShippingForm } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipmentShippingForm";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { handleRequestStockDto } from "@/features/common/infrastructure/utils/handleRequestStockDto/handleRequestStockDto";
import { handleCathError } from "@/features/common/infrastructure/utils/handleCathError";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { sxLabelStyle, sxSelectStyle } from "@/features/shipment/infrastructure/ui/deliveryAddress/DeliveryAddress.styles";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { sxCheckBoxStyle } from "@/features/shipment/infrastructure/ui/deliveryAddress/DeliveryAddress.styles";
import { SelectGeneric } from "@/features/common/infrastructure/ui/select/selectGeneric/SelectGeneric";
import { ShippingMethodEnum } from "@/features/shipment/domain/enum/ShippingMethodEnum";
/**
 * A component that displays a list of branch options for selection.
 * Allows selecting a branch and handles stock availability checks.
 * 
 * @component
 * @param {Object} props - Component props
 * @param {string} props.message - Message to display
 * @param {readonly IProfileSelectDate[]} props.branches - Array of available branch options
 * @param {number | undefined} props.branchId - Currently selected branch ID
 * @param {number | null} props.addressId - Selected address ID
 * @param {Dispatch<SetStateAction<number | undefined>>} props.setBranchId - Function to update selected branch
 * @param {string} props.title - Title text to display
 * @param {boolean} [props.availablePickUp] - Whether pickup is available
 * @param {ICustomer | undefined} props.customer - Customer information
 * @param {IOrderShipment | undefined} props.shipment - Shipment information
 * @param {boolean} [props.noStock] - Whether there is no stock available
 * @param {(noStock: boolean) => void} [props.onNoStockChange] - Callback when stock availability changes
 */
export const SelectBranches: FC<SelectBranchesProps> = ({
    message,
    branches,
    addressId,
    setBranchId,
    branchId,
    title,
    availablePickUp = false,
    customer, shipment,
    noStock = false,
    onNoStockChange
}) => {
    // api
    const { getStockProductByBranchId } = StockService();

    // hooks
    const { showSnackbar } = useSnackbar();
    const { updateFields } = useFormContext();

    // redux
    const { selectedOrderSummary: orderSummary }: ICheckOutState = useAppSelector(state => state.sessionState.checkOutsState);

    // states
    const [hasPickUp, setHasPickUp] = useState<boolean>(shipment?.PickUp === true ? true : false);
    const [errorStock, setErrorStock] = useState<boolean>(false);
    const [loadingStock, setLoadingStock] = useState<boolean>(false);
    const [abortController, setAbortController] = useState<AbortController | null>(null);

    // contants
    const CEDIS_ID: number = +process.env.NEXT_PUBLIC_SUCURSAL_CEDIS!;
    const TESISTAN_ID: number = +process.env.NEXT_PUBLIC_SUCURSAL_TESISTAN!;
    const NoStockForSMC: boolean = noStock && (customer?.AplicaClienteSMC ?? false);

    /**
     * Updates the form values with the current loading state, stock availability,
     * and selected branch ID. This comment is used to track form field updates
     * that happen in response to state changes.
     * 
     * The form fields that get updated are:
     * - Loading: Whether stock check is in progress
     * - NoStock: Whether there is no stock available
     * - SucursalEnviaId: The ID of the selected branch
     */
    useEffect(() => {
        const fieldsToUpdate: IOrderShipmentShippingForm = {
            Loading: loadingStock,
            NoStock: noStock,
            SucursalEnviaId: branchId,
        };

        updateFields(fieldsToUpdate);
    }, [loadingStock, noStock]);

    /**
     * Effect to update the branch ID in the form when the branch ID is undefined or the customer does not apply to SMC.
     * This effect updates the branch ID in the form with the current branch ID.
     * 
     * The form fields that get updated are:
     * - SucursalEnviaId: The ID of the selected branch
     */
    useEffect(() => {
        if (branchId === undefined || !customer?.AplicaClienteSMC) {
            const fieldsToUpdate = {
                SucursalEnviaId: branchId
            };
            updateFields(fieldsToUpdate);
            return;
        };

        // Reset states
        setErrorStock(false);
        setLoadingStock(true);

        if (abortController)
            abortController.abort(); // Cancel the previous request

        const newController = new AbortController(); // Create a new controller
        setAbortController(newController);

        // Start the stock request with the new branchId
        fetchStock(branchId, newController);

        return () => {
            if (abortController)
                abortController.abort();  // Abort the previous request when the component unmounts or selectedOrderSummary.pedidoID changes
        };
    }, [branchId]);

    /**
     * Effect to update the branch ID if it is CEDIS.
     * This effect updates the branch ID in the form with the current branch ID.
     * 
     * The form fields that get updated are:
     * - SucursalEnviaId: The ID of the selected branch
     */
    useEffect(() => {
        if (branchId === CEDIS_ID && customer && shipment?.MetodoEnvio === ShippingMethodEnum.Sucursal) {
            let newBranchId = customer?.sucursalId === CEDIS_ID
                ? TESISTAN_ID // If the customer's branch is CEDIS, change to Tesistán
                : customer.sucursalId;

            setBranchId(newBranchId);

            // Show warning message
            showSnackbar("No puedes seleccionar CEDIS al recoger en sucursal. Cambiando a otra sucursal.", 'warning');
        }
    }, [branchId, customer, shipment?.MetodoEnvio]);

    /**
     * Event handler that updates the pickup status and form fields when the pickup checkbox changes.
     * 
     * This handler:
     * 1. Updates the local pickup state via setHasPickUp
     * 2. Updates the form fields with the new pickup value
     *
     * @param {React.ChangeEvent<HTMLInputElement>} event - The change event from the checkbox input
     * @property {boolean} event.target.checked - The new checked state of the pickup checkbox
     */
    const handleChangePickUp = (event: React.ChangeEvent<HTMLInputElement>) => {
        setHasPickUp(event.target.checked);
        const fieldsToUpdate: IOrderShipmentShippingForm = {
            PickUp: event.target.checked,
        };
        updateFields(fieldsToUpdate);
    };

    /**
     * Event handler that updates the selected branch when a new branch is chosen from the dropdown.
     * 
     * This handler:
     * 1. Parses the selected value from string to number
     * 2. Validates if CEDIS can be selected based on shipment concession term
     * 3. Updates the branch ID state if validation passes
     * 
     * @param {SelectChangeEvent<string>} event - The change event from the select input
     * @property {string} event.target.value - The ID of the selected branch as a string
     * @throws {void} Shows warning snackbar if CEDIS selection is invalid
     */
    const handlechangeBranch = (event: SelectChangeEvent<string>) => {
        const value = parseInt(event.target.value);

        if (shipment?.consecion?.plazo === 0 && value == CEDIS_ID)
            return showSnackbar(message, 'warning');

        setBranchId(value);
    };


    /**
     * Fetches stock information for products based on a branch ID.
     * 
     * This function:
     * 1. Gets product details from order summary
     * 2. Extracts product IDs
     * 3. Makes API call to get stock levels
     * 4. Updates stock status and address fields based on availability
     * 
     * @param {number} branchId - ID of the branch to check stock for
     * @param {AbortController} controller - Controller to abort the fetch request if needed
     * @throws {Error} Shows error snackbar if product details are missing
     * @fires onNoStockChange - Callback when stock status changes
     * @fires updateFields - Updates form fields based on stock availability
     */
    const fetchStock = async (branchId: number, controller: AbortController) => {
        try {
            const detalles: IOrderSummaryDetail[] | undefined = orderSummary?.detalles;

            if (!detalles)
                return showSnackbar(GENERIC_ERROR_MESSAGE_CAE, 'error');

            const ids: string[] = detalles.reduce<string[]>((acc, item) => {
                if (item.producto !== undefined) acc.push(item.producto);
                return acc;
            }, []);

            const stockResponse = await getStockProductByBranchId(branchId, ids, { signal: controller.signal });

            handleRequestStockDto({
                response: stockResponse,
                onSuccess: async () => {
                    const stockData = stockResponse.data || [];

                    // Create a map for better product search in stock
                    const stockMap: Map<string, number> = new Map(stockData.map(stock => [stock.producto, stock.existencia]));

                    const productosSinStock = _.chain(detalles)
                        .groupBy('producto')
                        .map((group, key) => {
                            const stock = stockMap.get(key) ?? 0;
                            return _.sumBy(group, 'cantidad') > stock;
                        })
                        .filter(Boolean)
                        .value();

                    const fieldsToUpdate = {
                        DireccionEntregaId: !!productosSinStock.length ? shipment?.DireccionEntregaId ?? addressId : undefined
                    };
                    onNoStockChange && onNoStockChange(productosSinStock.length > 0);
                    updateFields(fieldsToUpdate);
                },
                onError: () => {
                    if (controller.signal.aborted) return;  // Avoid errors if aborted

                    const fieldsToUpdate = {
                        DireccionEntregaId: undefined
                    };
                    onNoStockChange && onNoStockChange(true);
                    updateFields(fieldsToUpdate);
                    setErrorStock(true);
                },
            });
        } catch (error) {
            if (!controller.signal.aborted)  // Avoid handling errors if aborted
                handleCathError(error, showSnackbar);

            setErrorStock(true);
        } finally {
            if (!controller.signal.aborted)
                setLoadingStock(false);
        }
    };

    return (
        <>
            <Stack direction={"row"} alignItems={'center'} justifyContent={'space-between'} sx={{ mb: -1 }}>
                <Typography
                    fontWeight={FontWeightEnum.Medium}
                    color={ColorsEpico.ColorDarkCharcoal}
                    fontSize={FontSizesEnum.Gamma}
                    sx={{ textTransform: 'uppercase', alignSelf: 'end' }}
                >
                    {NoStockForSMC ? 'Sucursal' : title}
                </Typography>

                {availablePickUp && (
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={hasPickUp}
                                onChange={handleChangePickUp}
                                sx={sxCheckBoxStyle}
                            />}
                        label={
                            <Typography
                                fontWeight={FontWeightEnum.Medium}
                                color={ColorsEpico.ColorDarkCharcoal}
                                fontSize={FontSizesEnum.Gamma}
                                sx={sxLabelStyle}
                            >
                                Pedido Pick Up
                            </Typography>
                        }
                        sx={{ mb: -1 }}
                    />
                )}

            </Stack>

            <SelectGeneric
                onChange={handlechangeBranch}
                options={branches}
                defaultValue={branchId}
                sizeFont={FontSizesEnum.Delta}
                sxSelect={sxSelectStyle}
            />

            {loadingStock &&
                <Stack direction="row" alignItems="center" justifyContent="left" sx={{ width: "100%" }}>
                    <CircularProgress size={20} color="primary" />
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                        color={ColorsEpico.ColorPrimary}
                        fontSize={FontSizesEnum.Delta}
                        sx={{
                            ml: 1,
                            textAlign: "left"
                        }}
                    >
                        Verificando existencias...
                    </Typography>
                </Stack>
            }

            {
                errorStock &&
                <Typography
                    fontWeight={FontWeightEnum.Medium}
                    color={ColorsEpico.ColorRed}
                    fontSize={FontSizesEnum.Delta}
                    sx={{
                        width: "100%",
                        textAlign: "left"
                    }}
                >
                    No se pudieron recuperar las existencias de la sucursal, ingresa una dirección para el envio de los productos
                </Typography>
            }

            {!loadingStock && (
                NoStockForSMC && !errorStock ?
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                        color={ColorsEpico.ColorRed}
                        fontSize={FontSizesEnum.Delta}
                        sx={{
                            width: "100%",
                            textAlign: "left"
                        }}
                    >
                        La sucursal no cuenta con la existencia total del pedido, ingresa una dirección para los productos restantes
                    </Typography>
                    : customer?.sucursalId !== branchId && !errorStock &&
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                        color={ColorsEpico.ColorDarkCharcoal}
                        fontSize={FontSizesEnum.Delta}
                        sx={{
                            width: "100%",
                            textAlign: "left"
                        }}
                    >
                        El cliente está asignado a la cartera de "{customer?.sucursal}", pero su principal ubicación de surtido está asignada a "{branches.find(branch => branch.value === branchId)?.label}"
                    </Typography>
            )}
        </>

    )
}