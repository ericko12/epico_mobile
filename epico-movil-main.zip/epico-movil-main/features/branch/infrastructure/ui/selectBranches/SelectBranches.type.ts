import { Dispatch, SetStateAction } from "react";
import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";
import { ICustomer } from "@/features/customer/domain/interface/ICustomer";
import { IProfileSelectDate } from "@/features/users/domain/interfaces/IProfileSelectDate";

/**
 * Props for the SelectBranches component.
 * 
 * @interface SelectBranchesProps
 * @property {string} message - Message to display
 * @property {readonly IProfileSelectDate[]} branches - Array of available branch options
 * @property {number | undefined} branchId - Currently selected branch ID
 * @property {number | null} addressId - Selected address ID
 * @property {Dispatch<SetStateAction<number | undefined>>} setBranchId - Function to update selected branch
 * @property {string} title - Title text to display
 * @property {boolean} [availablePickUp] - Whether pickup is available
 * @property {ICustomer | undefined} customer - Customer information
 * @property {IOrderShipment | undefined} shipment - Shipment information
 * @property {boolean} [noStock] - Whether there is no stock available
 * @property {(noStock: boolean) => void} [onNoStockChange] - Callback when stock availability changes
 */
export interface SelectBranchesProps {
    message: string
    branches: readonly IProfileSelectDate[]
    branchId: number | undefined,
    addressId: number | null;
    setBranchId: Dispatch<SetStateAction<number | undefined>>;
    title: string,
    availablePickUp?: boolean
    customer: ICustomer | undefined
    shipment?: IOrderShipment | undefined
    noStock?: boolean
    onNoStockChange?: (noStock: boolean) => void;
}