import { useCallback, useEffect, useMemo, useRef, useState, useTransition } from "react";
// mui
import { Button, Stack, Typography } from "@mui/material";
import { useRouter } from "next/navigation";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import {
  useAppDispatch,
  useAppSelector,
} from "@/features/common/application/redux/hooks";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { ICustomerInfo } from "@/features/customer/domain/interface/ICustomerInfo";
import { IBranch } from "@/features/branch/domain/interfaces/branch";
import { IClienteVendedorCompletoDto } from "@/features/customer/domain/interface/db/IClienteVendedorCompletoDto";
import { getClienteVendedorCompleto } from "@/features/customer/application/actions/db/CustomersRepository";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { handleRequestStockDto } from "@/features/common/infrastructure/utils/handleRequestStockDto/handleRequestStockDto";
import {
  GENERIC_ERROR_MESSAGE,
  GENERIC_ERROR_MESSAGE_CAE,
} from "@/features/common/infrastructure/utils/messages/generic";
import { switchLoadingThunk, updateOrderSummaryDetail, updateOrderSummaryThunk } from "@/features/checkout/application/redux/checkOutThunks";
import { ICustomerAddresses } from "@/features/address/domain/interface/ICustomerAddresses";
import { NOTIFICATIONS_SHIPMENT } from "@/features/common/infrastructure/utils/messages/notificationShipment";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { handleCathError } from "@/features/common/infrastructure/utils/handleCathError";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading";
import { AutoCompleteBranch } from "@/features/branch/infrastructure/ui/selects/AutoCompleteBranch";
import { branchService } from "@/features/branch/application/services/branch.services";
import { StockService } from "@/features/common/application/service/StockService";
import { SMCService } from "@/features/checkout/application/service/smc.services";
import { ordersService } from "@/features/orders/application/services/order.services";
import { setBranches as setBranchesRedux } from "@/features/branch/application/redux/branchSlice";
import { addressService } from "@/features/address/application/service/AddressService";
import { setEvaluateOrderRequest } from "@/features/orders/application/actions/setEvaluateOrderRequest";
import { updateOrder } from "@/features/orders/application/actions/updateOrder";
import { PatchOrderSummaryEnum } from "@/features/checkout/domain/enums/PatchCheckoutEnum";
import { NOTIFICATIONS_CUSTOMER } from "@/features/customer/infrastructure/utils/messages/NotificationCustomer";
import { ModalMassiveUpload } from "@/features/products/infrastructure/ui/modalMassiveUpload/ModalMassiveUpload";
import { ModalDelete } from "@/features/common/infrastructure/ui/modal/ModalDelete";
import { updateOrderDetail } from "@/features/orders/application/actions/updateOrderDetail";
import { PatchOrderSummaryDetailsEnum } from "@/features/checkout/domain/enums/OrderSummaryDetailsEnum";
import { actionsCheckout } from "@/features/checkout/application/redux/checkOutSlice";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { sendUpdateArticulePromotion } from "@/features/checkout/infrastructure/utils/channel/sendUpdateArticulePromotion";
import { openChannel } from "@/features/common/infrastructure/adapters/BroadcastChannelAdapter";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { store } from "@/features/common/application/redux/store";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { EstatusCreditoEnum } from "@/features/common/domain/enums/EstatusCreditoEnum";
import { ProductService } from "@/features/products/application/service/product.services";
import { updateOrderDetailList } from "@/features/orders/application/actions/updateOrderDetailList";
import { IPatchOrderDetailListItem } from "@/features/orders/domain/interfaces/IPatchOrderDetailListItem";
import { PatchActionsEnum } from "@/features/common/domain/enums/PatchActionsEnum";
import { IStockParam } from "@/features/checkout/domain/interfaces/IStockParam";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { ICustomerPriceList } from "@/features/checkout/domain/interfaces/ICustomerPriceList";

// api
const { getBranches } = branchService();
const { getStockProductByBranchId } = StockService();
const { PostGetCheckOutStockSMC } = SMCService();
const { getProductsByCodes } = ProductService();

/**
 * Component that handles branch selection in the checkout header.
 * Allows selecting a destination branch, checking product stock,
 * performing bulk product uploads and navigating to the catalog.
 *
 * @component
 * @example
 * ```tsx
 * <HeadBranch />
 * ```
 *
 * @remarks
 * - Manages branch selection through an AutoComplete component
 * - Allows checking product stock in the selected branch
 * - For SMC customers, enables stock checking in the SMC system
 * - Includes buttons for bulk upload and product search
 * - Validates permissions and displays notifications accordingly
 */
export const HeadBranch = () => {
  // hooks
  const { showSnackbar } = useSnackbar();
  const channelCheckoutsRef = useRef<BroadcastChannel | null>(
    openChannel("checkouts")
  );
  const dispatch = useAppDispatch();
  const router = useRouter();
  const { tabId } = useAppSelector((state) => state.sessionState.windowState);


  const { getCustomerAddresses } = addressService();

  //redux
  const { userAuth } = useAppSelector(state => state.localState.authState);
  const { selectedOrderSummary, quotationState }: ICheckOutState = useAppSelector(
    (state) => state.sessionState.checkOutsState
  );
  const { customer }: ICustomerInfo = useAppSelector(
    (state) => state.sessionState.customerInfoState
  );
  const isBlocked = selectedOrderSummary?.estatusInternoId === StatusOrderEnum.OpenPay && selectedOrderSummary?.origenExternoId === OrigenEnum.Web;

  // states
  const [branches, setBranches] = useState<readonly IBranch[]>([]);
  const [fetchStockLoading, setFetchStockLoading] = useState<boolean>(false);
  const [fetchStockSMCLoading, setFetchStockSMCLoading] =
    useState<boolean>(false);
  const [customerInfo, setCustomerInfo] =
    useState<IClienteVendedorCompletoDto | null>(null);
  const [abortController, setAbortController] =
    useState<AbortController | null>(null);
  const [abortControllerSMC, setAbortControllerSMC] =
    useState<AbortController | null>(null);
  const [modalMU, setModalMU] = useState<boolean>(false);
  const [buttonLoading, setButtonLoading] = useState<boolean>(false);
  const [isRemoveDiscountModalOpen, setIsRemoveDiscountModalOpen] = useState<boolean>(false);
  const [pendingDeletePromotion, startPendingDeletePromotion] = useTransition();
  const [isUpdateCustomPricesModalOpen, setIsUpdateCustomPricesModalOpen] = useState<boolean>(false);
  const [pendingUpdateCustomPrices, startPendingUpdateCustomPrices] = useTransition();
  const [customerPriceList, setCustomerPriceList] = useState<ICustomerPriceList | null>(null);

  const { productosActualizables, productosExcluidos } = useMemo(() => {
    const todosPersonalizados = selectedOrderSummary?.detalles?.filter(
      d => d.esPrecioDePreciosPersonalizadas && d.producto
    ) ?? [];

    const excluidos = todosPersonalizados.filter(
      d => d.estatusPrecioEspecialId === SpecialPriceStates.Solicitado.index ||
        d.estatusPrecioEspecialId === SpecialPriceStates.Aceptado.index
    );

    const actualizables = todosPersonalizados.filter(
      d => d.estatusPrecioEspecialId !== SpecialPriceStates.Solicitado.index &&
        d.estatusPrecioEspecialId !== SpecialPriceStates.Aceptado.index
    );

    return { productosActualizables: actualizables, productosExcluidos: excluidos };
  }, [selectedOrderSummary?.detalles]);

  const belongsToCustomPriceList = (customerPriceList?.listaPrecioPersonalizadaId ?? 0) !== 0;

  // memoized branches
  const memoizedBranches = useMemo(() => branches, [branches]);
  const branch: IBranch =
    branches.find(
      (branch) => branch.id === selectedOrderSummary?.sucursalIdDestino
    ) ?? branches[0];

  // constants
  const disableBtn: boolean =
    selectedOrderSummary?.detalles === undefined ||
    selectedOrderSummary?.detalles?.length === 0 ||
    memoizedBranches?.length === 0 ||
    selectedOrderSummary?.sucursalIdDestino === null;

  /**
   * React hook that fetches the list of branches when the component mounts.
   * This ensures the branch data is available for the AutoComplete component.
   */
  useEffect(() => {
    fetchBranches();
  }, []);

  /**
   * React hook that fetches customer information whenever the selected order's
   * client-vendor ID changes.
   *
   * This effect will:
   * - Check if there is a selected order summary with a valid client ID
   * - Fetch the complete client-vendor information for that customer
   * - Update the customerInfo state with the fetched data
   */
  useEffect(() => {
    const customerInfo = async () => {
      if (selectedOrderSummary && selectedOrderSummary.clienteId !== 0) {
        setCustomerInfo(
          await getClienteVendedorCompleto(selectedOrderSummary.clienteId)
        );
      }
    };
    customerInfo();
  }, [selectedOrderSummary?.clienteVendedorId]);

  useEffect(() => {
    const fetchCustomerPriceList = async () => {
      if (selectedOrderSummary && selectedOrderSummary.clienteId !== 0) {
        const { getCustomerPriceList } = checkoutServices();
        const res = await getCustomerPriceList(selectedOrderSummary.clienteId);
        if (res.data && res.data.length > 0) {
          setCustomerPriceList(res.data[0]);
        } else {
          setCustomerPriceList(null);
        }
      }
    };
    fetchCustomerPriceList();
  }, [selectedOrderSummary?.clienteId]);

  // fetch branches
  /**
   * Fetches and processes the list of branches from the API.
   *
   * This callback function:
   * 1. Makes an API call to get all branches
   * 2. Handles the response using handleRequestDto utility
   * 3. On success:
   *    - Sorts branches alphabetically by name
   *    - Updates local state with sorted branches
   *    - Dispatches sorted branches to Redux store
   * 4. Shows error messages via snackbar if request fails
   *
   * @returns {Promise<void>} A promise that resolves when branches are fetched and processed
   */
  const fetchBranches = useCallback(async () => {
    const resBranches: IResponseDto<IBranch[] | null> = await getBranches();

    handleRequestDto({
      snackBar: showSnackbar,
      response: resBranches,
      onSuccess: () => {
        const branchesSorted =
          resBranches.data?.sort((a, b) =>
            a.sucursal.localeCompare(b.sucursal)
          ) ?? [];
        setBranches(branchesSorted);
        dispatch(setBranchesRedux(branchesSorted));
      },
      messages: {
        error: "Error al obtener las sucursales",
        invalid: "Petición invalida de sucursales revise los datos",
      },
    });
  }, []);

  /**
   * React effect hook that manages abort controllers for API requests.
   *
   * This effect creates and manages two AbortController instances:
   * - One for general API requests (controller)
   * - One specifically for SMC API requests (controllerSMC)
   *
   * The controllers are stored in state via setAbortController and setAbortControllerSMC.
   * When the component unmounts or when selectedOrderSummary.pedidoID changes,
   * both controllers are aborted to cancel any pending requests.
   *
   * This prevents memory leaks and handles cleanup of pending API calls.
   *
   * @dependency selectedOrderSummary?.pedidoID - Effect runs when order ID changes
   */
  useEffect(() => {
    const controller = new AbortController();
    const controllerSMC = new AbortController();
    setAbortController(controller);
    setAbortControllerSMC(controllerSMC);

    return () => {
      controller.abort();
      controllerSMC.abort();
    };
  }, [selectedOrderSummary?.pedidoID]);

  /**
   * Fetches and updates stock information for products in the selected order summary.
   *
   * This async function performs the following:
   * 1. Validates the abort controller and order details exist
   * 2. Gets stock data for products from the specified branch
   * 3. Updates order details with stock information
   * 4. Shows warnings for products without stock data
   * 5. Handles errors and loading states
   *
   * @async
   * @function fetchStock
   * @returns {Promise<void>} A promise that resolves when stock data is fetched and processed
   */
  const fetchStock = async () => {
    if (!abortController) return;

    const detalles = selectedOrderSummary?.detalles;

    if (!detalles) {
      showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
      return;
    }

    setFetchStockLoading(true);
    const ids = detalles
      .map((item) => item.producto)
      .filter((producto): producto is string => producto !== undefined);
    const stockResponse = await getStockProductByBranchId(branch.id, ids, {
      signal: abortController.signal,
    });

    handleRequestStockDto({
      response: stockResponse,
      onSuccess: async () => {
        const stockData = stockResponse.data || [];

        const updatedDetails = detalles.map((orderDetail) => ({
          ...orderDetail,
          stockEnSucursal:
            stockData.find(
              (stock: { producto: string | undefined }) =>
                stock.producto === orderDetail.producto
            )?.existencia ?? orderDetail.stockEnSucursal,
        }));

        const productosSinStock = detalles
          .map((orderDetail) => orderDetail.producto)
          .filter(
            (producto) =>
              !stockData.some(
                (stock: { producto: string | undefined }) =>
                  stock.producto === producto
              )
          );

        if (productosSinStock.length > 0) {
          showSnackbar(
            `Los siguientes productos no tienen stock relacionado: ${productosSinStock.join(
              ", "
            )}`,
            "warning"
          );
        }

        await dispatch(updateOrderSummaryDetail(updatedDetails));
        setFetchStockLoading(false);
      },
      onError: () => {
        setFetchStockLoading(false);
        abortController.signal.aborted
          ? showSnackbar("Se canceló la consulta de existencias.", "warning")
          : stockResponse.message !== GENERIC_ERROR_MESSAGE &&
            stockResponse.message
            ? showSnackbar(stockResponse.message, "error")
            : showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
      },
    });
  };

  /**
   * Fetches stock information from SMC (Sistema de Manejo de Clientes).
   * This function retrieves stock data for products in the selected order summary from the SMC system.
   * It first gets the customer's fiscal address, then uses it to query SMC stock levels.
   * The stock information is then used to update the order details with SMC stock quantities.
   *
   * @async
   * @function fetchStockSMC
   * @returns {Promise<void>} A promise that resolves when SMC stock data is fetched and processed
   * @throws {Error} If there is an error fetching stock information or customer addresses
   */
  const fetchStockSMC = async () => {
    if (!abortControllerSMC) return;

    try {
      const detalles = selectedOrderSummary?.detalles;

      if (!detalles) {
        showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
        return;
      }
      setFetchStockSMCLoading(true);

      const resCustomerAddresses: IResponseDto<ICustomerAddresses[] | null> =
        await getCustomerAddresses(selectedOrderSummary.clienteId);

      const fiscalDireccionId = await handleRequestDto<
        ICustomerAddresses[] | null,
        number | undefined
      >({
        snackBar: showSnackbar,
        response: resCustomerAddresses,
        onSuccess: () => {
          return resCustomerAddresses.data?.find((a) => a.fiscal)?.direccionId;
        },
        onInvalid: () => {
          showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
        },
        messages: {
          error: GENERIC_ERROR_MESSAGE_CAE,
        },
      });

      if (typeof fiscalDireccionId === "number") {
        const stockResponseSMC = await PostGetCheckOutStockSMC(
          setEvaluateOrderRequest(selectedOrderSummary, fiscalDireccionId, 1)
        );

        handleRequestDto({
          snackBar: showSnackbar,
          response: stockResponseSMC,
          onSuccess: async () => {
            const stockData = stockResponseSMC.data || [];
            const updatedDetails = detalles.map((orderDetail) => ({
              ...orderDetail,
              stockEnSMC:
                stockData.find(
                  (stock: { producto: string | undefined }) =>
                    stock.producto === orderDetail.producto
                )?.existencias ?? orderDetail.stockEnSMC,
            }));

            const productosSinStockSMC = detalles
              .map((orderDetail) => orderDetail.producto)
              .filter(
                (producto) =>
                  !stockData.some(
                    (stock: { producto: string | undefined }) =>
                      stock.producto === producto
                  )
              );

            if (productosSinStockSMC.length > 0) {
              showSnackbar(
                `${NOTIFICATIONS_SHIPMENT.SMC.SMC_STOCK.INCOMPLETE_STOCK
                } ${productosSinStockSMC.join(", ")}`,
                "warning"
              );
            }

            await dispatch(updateOrderSummaryDetail(updatedDetails));
          },
          onError: () => {
            setFetchStockLoading(false);
            abortControllerSMC.signal.aborted
              ? showSnackbar(
                NOTIFICATIONS_SHIPMENT.SMC.SMC_STOCK.CANCELLED,
                "warning"
              )
              : stockResponseSMC.error.mensaje !== GENERIC_ERROR_MESSAGE &&
                stockResponseSMC.error.mensaje
                ? showSnackbar(
                  NOTIFICATIONS_SHIPMENT.SMC.SMC_STOCK.NO_STOCK,
                  "error"
                )
                : showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
          },
          onInvalid: () => {
            setFetchStockLoading(false);
            showSnackbar(
              NOTIFICATIONS_SHIPMENT.SMC.SMC_STOCK.NO_STOCK,
              "error"
            );
          },
        });
      }
    } finally {
      setFetchStockSMCLoading(false);
    }
  };

  /**
   * Changes the branch of the order.
   *
   * @async
   * @param {(IBranch | null)} branch - The branch to change to
   */
  const handleBranch = async (branch: IBranch | null) => {
    try {
      if (branch === null || selectedOrderSummary === null) return;

      await updateOrder(
        PatchOrderSummaryEnum.sucursalDestino,
        branch.id,
        selectedOrderSummary,
        showSnackbar,
        dispatch
      );
      showSnackbar(NOTIFICATIONS_CHECKOUT.GENERAL.BRANCH_WARNING, "warning");
    } catch (e) {
      handleCathError(e, showSnackbar);
    }
  };

  /**
   * Validates the state of the massive upload modal (ModalMU) based on the assigned salesperson for the customer.
   *
   * @async
   * @returns {Promise<void>} Resolves with no value after completing the validation process.
   */
  const validateModalMU = async () => {
    if (
      customer?.vendedorId === +process.env.NEXT_PUBLIC_VENDEDOR_ID_SIN_VENTA!
    ) {
      showSnackbar(NOTIFICATIONS_CUSTOMER.CUSTOMER.NO_SALE, "warning");
      setModalMU(false);
    } else {
      setModalMU(true);
    }
  };


  /**
   * Updates the price for a given order detail that has a custom price (esPrecioDePreciosPersonalizadas).
   * Fetches the current list price from the API (same as when adding a product) and resets the price.
   *
   * @param {IOrderSummaryDetail} detail - The order detail to update.
   * @param {IOrderSummary} orderSummary - The current order summary.
   * @returns {Promise<void>}
   */
  const handleUpdateCustomPrice = async (
    orderSummary: IOrderSummary
  ): Promise<void> => {
    try {
      await dispatch(switchLoadingThunk(true));
      const todosPersonalizados = orderSummary.detalles?.filter(
        d => d.esPrecioDePreciosPersonalizadas && d.producto &&
        d.estatusPrecioEspecialId !== SpecialPriceStates.Solicitado.index &&
        d.estatusPrecioEspecialId !== SpecialPriceStates.Aceptado.index
      ) ?? [];

      if (todosPersonalizados.length === 0) {
        return;
      }

      const historialId = orderSummary.estatusID == 4 ? quotationState.historialId : 0;
      const productCodes = todosPersonalizados.map(d => d.producto!);
      const stockParams: IStockParam = {
              RecuperarExistencia: false,
              SucursalId: 0
      };
      // Fetch all products at once
      const resProducts = await getProductsByCodes(orderSummary.clienteId, productCodes, stockParams, 0);
      const productsData = resProducts.data ?? [];
      // Build detail items array for bulk update
      const detailItems: IPatchOrderDetailListItem[] = todosPersonalizados.map(detail => {
        const matchedProduct = productsData.find(p => p.producto === detail.producto);
        const freshPrice = matchedProduct?.precio ?? detail.precio;

        const newDetail = {
          ...detail,
          precio: freshPrice,
          precioLista: freshPrice
        } as IOrderSummaryDetail;
        dispatch(
          actionsCheckout.setDetailById({ id: detail.pedidoDetalleId, newDetail })
        );

        return {
          pedidoDetalleId: detail.pedidoDetalleId,
          patch: [{
            op: PatchActionsEnum.REPLACE,
            path: `/${PatchOrderSummaryDetailsEnum.precio}`,
            value: freshPrice,
          }],
          incrementoPaquete: false
        };
      });
      // Update all details with the new prices in a single request
      await updateOrderDetailList(
        detailItems,
        orderSummary,
        showSnackbar,
        dispatch,
        historialId,
        0
      );
    } catch (e) {
    } finally {
      await dispatch(switchLoadingThunk(false));  
    }
  };

  /**
   * Sets, deletes, or changes a discount for a given order detail.
   *
   * @param {number} id - The ID of the order.
   * @param {IOrderSummaryDetail} detail - The order detail object containing the discount information.
   * @returns {Promise<void>} A promise that resolves when the operation is complete.
   */
  const handleQuitDiscount = async (
    id: number,
    detail: IOrderSummaryDetail,
    selectedOrderSummary?: IOrderSummary
  ): Promise<void> => {
    try {
      let pedidoDetalleIdEvaluado = selectedOrderSummary?.detalles?.find(d => d.pedidoDetalleId === detail.pedidoDetalleId)?.promocionID;
      if (!pedidoDetalleIdEvaluado) {
        return;
      }
      await dispatch(switchLoadingThunk(true));
      // create a new detail with the id of the detail and the id of the promotion
      const newDetail = { ...detail, promocionID: id } as IOrderSummaryDetail;

      // update the detail order on the store
      dispatch(
        actionsCheckout.setDetailById({ id: detail.pedidoDetalleId, newDetail })
      );

      // update the detail order on the indexDb
      await updateOrderDetail(
        detail.pedidoDetalleId,
        selectedOrderSummary!,
        [
          {
            name: PatchOrderSummaryDetailsEnum.PromocionID,
            data: id,
          },
        ],
        showSnackbar,
        dispatch,
        false,
        selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
      );
    } catch (e) {
    } finally {
      sendUpdateArticulePromotion(
        channelCheckoutsRef,
        selectedOrderSummary!,
        tabId
      );
      await dispatch(switchLoadingThunk(false));
    }
  };

  return (
    <>
      <Stack
        spacing={2}
        direction={{ xs: "column", md: "row" }}
        alignItems={{ xs: "left", md: "center" }}
        justifyContent={"space-between"}
      >
        {!userAuth?.engineSMC4 && (
          <Stack direction={{ xs: "column", sm: "row" }} spacing={2} alignItems={{ xs: "stretch", sm: "center", md: "stretch" }}>
            <AutoCompleteBranch
              branch={branch}
              handleBranch={handleBranch}
              optionBranches={memoizedBranches}
              width={{ xs: "100%", sm: 200 }}
              propsAutocomplete={{
                disabled: selectedOrderSummary?.detalles?.length === 0,
              }}
            />
            {/* En escritorio replica el <div> original: sin gap, botones alineados por la línea base y mx 2 en el SMC */}
            <Stack direction={{ xs: "column", sm: "row" }} spacing={{ xs: 1, md: 0 }} useFlexGap flexWrap="wrap" alignItems={{ md: "baseline" }}>
              <ButtonLoading
                variant="outlined"
                sx={{
                  color: ColorsEpico.ColorDarkCharcoal,
                  fontSize: FontSizesEnum.Delta,
                  fontWeight: FontWeightEnum.Medium,
                  borderColor: ColorsEpico.ColorLightBlueishGray,
                  width: { xs: "100%", sm: "140px" },
                  borderRadius: 2,
                }}
                disabled={disableBtn || fetchStockLoading}
                onClick={fetchStock}
                loading={fetchStockLoading}
                children="Ver existencias"
              />
              {customerInfo?.AplicaClienteSMC === true && (
                <ButtonLoading
                  variant="outlined"
                  sx={{
                    color: ColorsEpico.ColorDarkCharcoal,
                    fontSize: FontSizesEnum.Delta,
                    fontWeight: FontWeightEnum.Medium,
                    borderColor: ColorsEpico.ColorLightBlueishGray,
                    width: { xs: "100%", sm: "170px" },
                    borderRadius: 2,
                    mx: { xs: 0, md: 2 },
                  }}
                  disabled={disableBtn || fetchStockSMCLoading}
                  onClick={fetchStockSMC}
                  loading={fetchStockSMCLoading}
                  children="Ver existencias SMC"
                />
              )}
            </Stack>
          </Stack>
        )}
        <Stack
          direction={{ xs: "column", sm: "row" }}
          spacing={2}
          useFlexGap
          flexWrap={{ xs: "wrap", md: "nowrap" }}
          alignItems={{ xs: "stretch", sm: "center" }}
          sx={userAuth?.engineSMC4 ? {
            justifyContent: "flex-end",
            width: "100%",
          } : {}}
        >
          <Button
            variant="contained"
            size="small"
            sx={{
              px: 2,
              height: "2rem",
              fontSize: FontSizesEnum.Delta,
              borderRadius: 2,
              background: ColorsEpico.ColorRedOpaque,
            }}
            disabled={isBlocked}
            onClick={() => setIsRemoveDiscountModalOpen(true)}
          >
            Eliminar Promociones
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={{
              px: 2,
              height: "2rem",
              fontSize: FontSizesEnum.Delta,
              borderRadius: 2,
              background: ColorsEpico.ColorsDarkBlue,
            }}
            disabled={isBlocked}
            onClick={() => setIsUpdateCustomPricesModalOpen(true)}
          >
            Actualizar Precios Personalizados
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={{
              px: 2,
              height: "2rem",
              fontSize: FontSizesEnum.Delta,
              borderRadius: 2,
              background: ColorsEpico.ColorsDarkBlue,
            }}
            onClick={() => validateModalMU()}
          >
            Carga masiva
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={{
              px: 2,
              height: "2rem",
              fontSize: FontSizesEnum.Delta,
              borderRadius: 2,
            }}
            disabled={isBlocked}
            onClick={() => {
              router.push(`/Catalogo`);
            }}
          >
            Búsqueda de producto
          </Button>
        </Stack>
      </Stack>
      <ModalMassiveUpload
        createOrder={() => { }}
        clientSellerId={selectedOrderSummary?.clienteVendedorId}
        open={modalMU}
        handleClose={() => setModalMU(false)}
        loading={buttonLoading}
        setLoading={setButtonLoading}
      />
      <ModalDelete
        titulo={"QUITAR TODAS LAS PROMOCIONES"}
        openModal={isRemoveDiscountModalOpen}
        onOk={async () => {
          startPendingDeletePromotion(async () => {
            const detallesConPromo = selectedOrderSummary?.detalles?.filter(
              (detail) => detail.promocionID !== null && detail.promocionID !== undefined && detail.promocionID !== 0
            );

            if (!detallesConPromo || detallesConPromo.length === 0) {
              showSnackbar("No hay promociones aplicadas en los productos para eliminar.", "info");
              setIsRemoveDiscountModalOpen(false);
              return;
            }

            for await (const detail of detallesConPromo) {
              const current = store.getState().sessionState?.checkOutsState?.selectedOrderSummary;
              await handleQuitDiscount(NaN, detail, current!);
            }

            setIsRemoveDiscountModalOpen(false);
          });
        }}
        onClose={() => setIsRemoveDiscountModalOpen(false)}
        description={"Se retirarán todas las promociones y se conservarán los productos"}
        question={"¿Estás seguro de querer eliminar todas las promociones?"}
        loading={pendingDeletePromotion}
      />
      <ModalDelete
        titulo={"ACTUALIZAR PRECIOS PERSONALIZADOS"}
        openModal={isUpdateCustomPricesModalOpen}
        btnTextConfirm={"Actualizar"}
        onOk={async () => {
          startPendingUpdateCustomPrices(async () => {
            const current = store.getState().sessionState?.checkOutsState?.selectedOrderSummary;
            await handleUpdateCustomPrice(current!);
            setIsUpdateCustomPricesModalOpen(false);
          });
        }}
        onClose={() => setIsUpdateCustomPricesModalOpen(false)}
        loading={pendingUpdateCustomPrices}
      >
        <Typography variant="body2" sx={{ mb: 1 }}>
          Se actualizarán los precios de los productos con precios personalizados.
        </Typography>
        {productosActualizables.length > 0 && (
          <>
            <Typography variant="body2" sx={{ fontWeight: "bold", mt: 1 }}>
              Productos con precio personalizado ({productosActualizables.length}):
            </Typography>
            <Typography variant="body2">
              {productosActualizables.map(d => d.producto).join(", ")}
            </Typography>
          </>
        )}
        {productosExcluidos.length > 0 && (
          <>
            <Typography variant="body2" sx={{ fontWeight: "bold", mt: 1, color: "warning.main" }}>
              Productos excluidos por precio especial solicitado o aprobado ({productosExcluidos.length}):
            </Typography>
            <Typography variant="body2" sx={{ color: "warning.main" }}>
              {productosExcluidos.map(d => d.producto).join(", ")}
            </Typography>
          </>
        )}
        <Typography variant="body1" sx={{ mt: 1.5, fontWeight: "medium" }}>
          ¿Estás seguro de querer actualizar los precios personalizados?
        </Typography>
      </ModalDelete>
    </>
  );
};
