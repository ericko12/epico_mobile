import { ICustomer } from "@/features/customer/domain/interface/ICustomer";
import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";

/**
 * Interface that defines the props for the BranchPickUp component.
 * Used to configure branch pickup shipping method options.
 * 
 * @interface IBranchPickUp
 * @property {IOrderShipment} [shipment] - Optional shipment details including selected branch, bearing and pickup timing
 * @property {ICustomer} [customer] - Optional customer information including eligibility for SMC service
 */
export interface IBranchPickUp {
    shipment?: IOrderShipment,
    customer?: ICustomer
}