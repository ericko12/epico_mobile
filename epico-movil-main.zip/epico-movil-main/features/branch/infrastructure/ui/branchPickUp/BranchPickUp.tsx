import { ChangeEvent, FC, useCallback, useEffect, useState } from 'react';
import { Checkbox, FormControlLabel, SelectChangeEvent, Stack, TextField, Typography } from "@mui/material";
import { IBranchPickUp } from '@/features/branch/infrastructure/ui/branchPickUp/BranchPickUp.type';
import { useAppDispatch, useAppSelector } from '@/features/common/application/redux/hooks';
import { useSnackbar } from '@/context/snackBar/SnackBarContext';
import { useFormContext } from '@/features/shipment/infrastructure/ui/formShippingProvider/FormShippingProvider';
import { ShippingParcelForm } from '@/features/shipment/infrastructure/ui/shippingParcelForm/ShippingParcelForms';
import { ICheckOutState } from '@/features/checkout/domain/interfaces/checkOut/ICheckOutState';
import { IProfileSelectDate } from '@/features/users/domain/interfaces/IProfileSelectDate';
import { fetchCustomerAddressesAction } from '@/features/shipment/application/actions/fetchCustomerAddressesAction';
import { PatchOrderSummaryEnum } from '@/features/checkout/domain/enums/PatchCheckoutEnum';
import { CreateOrUpdateCustomerAddress } from '@/features/shipment/application/actions/CustomerAddressesQueries';
import { UpdateOrderService } from '@/features/orders/application/actions/fetchOrdersAction';
import { UpdateOrderShipment } from '@/features/checkout/infrastructure/db/OrdersShipmentRepository';
import { IOrderShipmentShippingForm } from '@/features/checkout/domain/interfaces/checkOut/IOrderShipmentShippingForm';
import { IOrderShipment } from '@/features/checkout/domain/interfaces/checkOut/IOrderShipment';
import { IResponseDB } from '@/features/common/domain/interfaces/dbStore/IResponseDB';
import { IBranch } from '@/features/branch/domain/interfaces/branch/IBranch';
import { IFreight } from '@/features/common/domain/interfaces/catalogs/IFreight';
import { INITIAL_VALUES } from '@/features/shipment/infrastructure/ui/shippingParcelForm/ShippingParcelForms.data';
import { SelectBranches } from '@/features/branch/infrastructure/ui/selectBranches/SelectBranches';
import { SkeletonDeliveryAdress } from '@/features/address/infrastructure/ui/skeletonDeliveryAdress/SkeletonDeliveryAdress';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import { inputMianSx, inputSx, sxCheckBoxStyle, sxLabelStyle } from '@/features/shipment/infrastructure/ui/deliveryAddress/DeliveryAddress.styles';
import { sxSelectStyle } from '@/features/shipment/infrastructure/ui/deliveryAddress/DeliveryAddress.styles';
import { SelectGeneric } from '@/features/common/infrastructure/ui/select/selectGeneric/SelectGeneric';
import { FontWeightEnum } from '@/features/common/domain/enums/FontWeight';
import { PersonWhoCollects } from '@/features/shipment/infrastructure/ui/personWhoCollects/PersonWhoCollects';

/**
 * Component that contains the form for branch pickup shipping method.
 * Allows customers to select a branch location for order pickup and configure shipping details.
 *
 * @param {Object} props - Component props
 * @param {ICustomer} props.customer - Customer information including eligibility for SMC service
 * @param {IOrderShipment} props.shipment - Shipment details including selected branch, bearing and pickup timing
 * @returns {JSX.Element} Branch pickup form component
 */
export const BranchPickUp: FC<IBranchPickUp> = ({ customer, shipment }) => {

    // hooks
    const dispatch = useAppDispatch();
    const { showSnackbar } = useSnackbar();
    const { updateFields } = useFormContext();
    const EfectivoMetodoPagoId = +process.env.NEXT_PUBLIC_METODOPAGO_EFECTIVO!;


    const { formik: formParcel, component: ParcelForm } = ShippingParcelForm((shipment?.EnviarPaqueteria && shipment?.FormaPagoId !== EfectivoMetodoPagoId) ? {
        stateId: shipment.EnviarPaqueteria.EstadoId || NaN,
        parcelId: shipment.EnviarPaqueteria.PaqueteriaId || NaN,
        addressId: shipment.EnviarPaqueteria.DireccionPaqueteriaId || NaN,
    } : undefined);

    // redux
    const { selectedOrderSummary: orderSummary }: ICheckOutState = useAppSelector(state => state.sessionState.checkOutsState);
    const { branches: listBranches, bearing } = useAppSelector(state => state.sessionState.shipmentState);

    // SELECT LISTS
    const [noStock, setNoStock] = useState(false);
    const [branches, setBranches] = useState<readonly IProfileSelectDate[]>([]);
    const [addressId, setAddressId] = useState<number | null>(shipment?.DireccionEntregaId ?? null);
    const [ListBearing, setListBearing] = useState<readonly IProfileSelectDate[]>([]);
    const [customerAddresses, setCustomerAddresses] = useState<readonly IProfileSelectDate[]>([]);
    const [isCheckedDelivery, setIsCheckedDelivery] = useState<boolean>(false);

    // FORM VALUES
    const [branchId, setBranchId] = useState(shipment?.SucursalEnviaId ?? orderSummary!.sucursalIdDestino);
    const [bearingValue, setBearingValue] = useState(shipment?.PorteId ?? 1);
    const [tiempoRecogeraValue, setTiempoRecogeraValue] = useState<string>(shipment?.TiempoRecogera ?? '');
    const [loading, setLoading] = useState(true);
    const [isCash, setIsCash] = useState(false);

    useEffect(() => {
        setShipmentValues();
    }, [loading]);

    useEffect(() => {
        handleUpdateOrderService();
    }, [addressId, noStock]);

    useEffect(() => {
        if (!customer?.AplicaClienteSMC)
            handleUpdateOrderService();
    }, [branchId]);

    // init
    useEffect(() => {
        Promise.all([
            fetchBranches(),
            fetchBearing(),
            fetchCustomerAddresses(),
        ])
            .then(() => setLoading(false))
            .catch((error) => showSnackbar("Problema al cargar parte de la información", 'error'));
    }, []);

    useEffect(() => {
        /** 
         * The 400 millisecond delay (setTimeout) is used to:
         * 1. Debounce form updates to reduce unnecessary API calls when user makes rapid changes
         * 2. Allow the form state to stabilize before updating data
         * 3. Improve performance by batching multiple changes into a single update
         * 
         * This implements a debouncing pattern to optimize form updates and prevent
         * excessive server requests while maintaining a responsive user experience.
         */
        const handler = setTimeout(() => {
            update();
        }, 400);

        return () => {
            clearTimeout(handler);
        };
    }, [formParcel.values, isCheckedDelivery]);

    /**
     * Fetches customer addresses and sets up the address selection options.
     * 
     * This function:
     * 1. Retrieves customer addresses from the backend
     * 2. Sets a default address ID if none is selected, prioritizing fiscal address
     * 3. Maps addresses to profile select options format
     * 4. Updates customer addresses in state and storage
     * 
     * @async
     * @returns {Promise<void>} Promise that resolves when addresses are fetched and processed
     * @throws Will show error snackbar if address fetch fails
     */
    const fetchCustomerAddresses = async () => {
        const resCustomerAddresses = await fetchCustomerAddressesAction(showSnackbar, orderSummary!);
        if (!addressId) {
            const fiscalAddress = resCustomerAddresses.find(direccion => direccion.fiscal);
            if (fiscalAddress) {
                setAddressId(fiscalAddress.direccionId);
            } else {
                if (resCustomerAddresses.length > 0) {
                    setAddressId(resCustomerAddresses[0].direccionId);
                }
            }
        }

        const profileSelectDates: IProfileSelectDate[] = resCustomerAddresses.map(branch => ({
            value: branch.direccionId,
            label: `${branch.fiscal ? '(Fiscal) ' : ''}${branch.calle} ${branch.noExterior} Col. ${branch.colonia} ${branch.ciudad}, ${branch.estado}`,
            disabled: false
        }));
        setCustomerAddresses(profileSelectDates);
        CreateOrUpdateCustomerAddress(resCustomerAddresses)
    };


    /**
     * Updates the order with the new branch information and optionally updates the delivery address.
     * 
     * This function:
     * 1. Checks if the customer is eligible for SMC service and has no stock
     * 2. Creates an array of patches to update the order
     * 3. Always includes the destination branch update
     * 4. Conditionally includes address update if customer qualifies
     * 5. Dispatches the update service call
     * 
     * @returns {void} Nothing
     */
    const handleUpdateOrderService = () => {
        const ApplyDirectionId = customer!.AplicaClienteSMC && noStock;
        const patches = [
            { name: PatchOrderSummaryEnum.sucursalDestino, data: branchId }
        ];
        if (ApplyDirectionId) patches.push({ name: PatchOrderSummaryEnum.direccionId, data: addressId! });

        UpdateOrderService(orderSummary!, patches, showSnackbar, dispatch)
    }

    /**
     * event handler to set value noStock
     *
     * @param {boolean} noStock - setea el valor para verificar el estado del stock
     */
    const handleNoStockChange = (noStock: boolean) => {
        setNoStock(noStock);
    };

    /**
     * Updates the parcel shipping data in the order shipment.
     * 
     * This function:
     * 1. Gets the form values for address, parcel service and state
     * 2. Creates an updated shipment object with the parcel delivery details
     * 3. Calls the UpdateOrderShipment service to persist the changes
     * 4. Updates the form fields with the new values if successful
     * 
     * @async
     * @returns {Promise<void>} Nothing
     * @throws {Error} If there is an error saving the parcel shipping data
     */
    const update = useCallback(async () => {
        const { addressId, parcelId, stateId } = formParcel.values;

        const updatedShipment: IOrderShipmentShippingForm = {
            EnviarPaqueteria: {
                active: isCheckedDelivery,
                EstadoId: stateId,
                PaqueteriaId: parcelId,
                DireccionPaqueteriaId: addressId,
            }
        };

        const res: IResponseDB<IOrderShipment> = await UpdateOrderShipment(updatedShipment, orderSummary!.pedidoID);

        if (res.hasError || res.error)
            return console.error('error al guardar los datos de paqueteria de envío');

        updateFields(updatedShipment);
    }, [formParcel.values, isCheckedDelivery, orderSummary]);

    /**
     * Event handler for when a customer changes their selected delivery address.
     * Updates the address ID state and form fields with the newly selected address.
     * 
     * @param {SelectChangeEvent<string>} event - The select change event containing the new address ID value
     * @returns {void} Nothing
     */
    const handlechangeCustomerAddress = (event: SelectChangeEvent<string>) => {
        const value = parseInt(event.target.value)
        setAddressId(value)
        const fieldsToUpdate: IOrderShipmentShippingForm = {
            DireccionEntregaId: value
        };
        updateFields(fieldsToUpdate);
    };

    /**
     * Sets initial form values from the shipment data stored in jsStore.
     * 
     * This function:
     * 1. Checks if there is shipment data available
     * 2. Handles cash payment method by disabling delivery
     * 3. Validates and updates branch selection, preventing CEDIS selection
     * 4. Updates form fields with branch and bearing values
     *
     * @async
     * @returns {Promise<void>} Nothing
     */
    const setShipmentValues = async () => {
        if (shipment) {
            let branchValue = branchId;
            const valueCash = shipment.FormaPagoId === EfectivoMetodoPagoId;
            if (valueCash) {
                setIsCash(true)
                setIsCheckedDelivery(false)
            }
            if (branchValue === process.env.NEXT_PUBLIC_SUCURSAL_CEDIS) {
                if (customer?.sucursalId !== undefined) {
                    branchValue = customer?.sucursalId !== Number(process.env.NEXT_PUBLIC_SUCURSAL_CEDIS)
                        ? customer.sucursalId
                        : Number(process.env.NEXT_PUBLIC_SUCURSAL_TESISTAN);
                }
                setBranchId(branchValue);
                showSnackbar("No puedes enviar a CEDIS al recoger en sucursal", 'warning');
            }

            const fieldsToUpdate = {
                SucursalEnviaId: branchValue,
                PorteId: shipment.PorteId ?? bearingValue,
            };
            await updateFields(fieldsToUpdate);
        }
    };

    /**
     * Fetches branch data and filters out CEDIS branches.
     * 
     * This function:
     * 1. Retrieves all branches from the list
     * 2. Filters out CEDIS branches
     * 3. Maps branches to profile select options format
     * 4. Updates the branches state with the filtered list
     *
     * @async
     * @returns {Promise<void>} Nothing
     */
    const fetchBranches = async () => {
        const resBranches: IBranch[] = listBranches
        const filteredBranches = resBranches.filter(branch => branch.id !== Number(process.env.NEXT_PUBLIC_SUCURSAL_CEDIS));
        const fetchesBranches: IProfileSelectDate[] = filteredBranches.map(branch => ({
            value: branch.id,
            label: branch.sucursal,
            disabled: false
        }));

        setBranches(fetchesBranches);
    };

    /**
     * Fetches bearing data and maps it to profile select options.
     * 
     * This function:
     * 1. Retrieves all bearing data from the list
     * 2. Maps bearing data to profile select options format
     * 3. Updates the bearing state with the fetched list
     *
     * @async
     * @returns {Promise<void>} Nothing
     */
    const fetchBearing = async () => {
        const resBearing: IFreight[] = bearing
        const fetchedListBearing: IProfileSelectDate[] = resBearing.map(bearing => ({
            value: bearing.porteId,
            label: bearing.porte,
            disabled: false
        }));
        setListBearing(fetchedListBearing)
    };

    /**
     * Event handler to set the bearing value and update the form fields.
     * 
     * This function:
     * 1. Parses the selected bearing value from the event target
     * 2. Updates the bearing value state
     * 3. Creates an updated shipment object with the new bearing value
     * event handler to set value to the bearing
     *
     * @param {SelectChangeEvent<string>} event
     */
    const handlechangeBearing = (event: SelectChangeEvent<string>) => {
        const value = parseInt(event.target.value)
        setBearingValue(value)
        const fieldsToUpdate: IOrderShipmentShippingForm = {
            PorteId: value,
        };
        updateFields(fieldsToUpdate);
    };

    /**
     * Event handler to update the time when the customer will collect their order.
     * 
     * This function:
     * 1. Gets the input value from the event target
     * 2. Updates the time to collect state
     * 3. Creates an updated shipment object with the new collection time
     * 4. Updates the form fields with the new collection time
     *
     * @param {React.ChangeEvent<HTMLInputElement>} event - The change event from the input field
     */
    const handlechangeTimeToCollect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const value = event.target.value
        setTiempoRecogeraValue(value)
        const fieldsToUpdate: IOrderShipmentShippingForm = {
            TiempoRecogera: value,
        };
        updateFields(fieldsToUpdate);
    };

    /**
     * Event handler for toggling parcel delivery checkbox.
     * 
     * This function:
     * 1. Updates the delivery checkbox checked state
     * 2. Resets the parcel form values to initial state when toggled
     * 3. Allows enabling/disabling parcel delivery option
     *
     * @param {React.ChangeEvent<HTMLInputElement>} event - The checkbox change event
     * @returns {void} Nothing
     */
    const handleCheckDelivery = (event: ChangeEvent<HTMLInputElement>) => {
        setIsCheckedDelivery(event.target.checked);
        formParcel.setValues(INITIAL_VALUES, false);
    }

    return loading ? <SkeletonDeliveryAdress /> : (
        <>
            <SelectBranches
                title={'Sucursal que envía'}
                branches={branches}
                branchId={branchId}
                addressId={addressId}
                setBranchId={setBranchId}
                message={"No puedes enviar a CEDIS al recoger en sucursal"}
                customer={customer}
                shipment={shipment}
                noStock={noStock}
                availablePickUp={true}
                onNoStockChange={handleNoStockChange}
            />

            {noStock && customer?.AplicaClienteSMC &&
                <>
                    <Stack direction={'column'} textAlign={'left'} spacing={1} sx={{ mt: '1rem !important' }}>
                        <Typography
                            fontWeight={FontWeightEnum.Medium}
                            color={ColorsEpico.ColorDarkCharcoal}
                            fontSize={FontSizesEnum.Gamma}
                            sx={{ textTransform: 'uppercase' }}
                        >
                            Dirección del cliente
                        </Typography>
                        <SelectGeneric
                            onChange={handlechangeCustomerAddress}
                            options={customerAddresses}
                            defaultValue={addressId}
                            sizeFont={FontSizesEnum.Delta}
                            sxSelect={sxSelectStyle}
                        />
                    </Stack>

                    <Stack mt={1.5} rowGap={.5}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={isCheckedDelivery}
                                    onChange={handleCheckDelivery}
                                    sx={sxCheckBoxStyle}
                                    disabled={isCash}
                                />
                            }
                            label={
                                <Typography
                                    fontWeight={FontWeightEnum.Medium}
                                    color={isCash ? ColorsEpico.ColorGrayNeutral : ColorsEpico.ColorDarkCharcoal}
                                    fontSize={FontSizesEnum.Gamma}
                                >
                                    Enviar a paquetería
                                </Typography>
                            }
                        />
                        {
                            isCheckedDelivery && ParcelForm
                        }
                    </Stack>
                </>
            }

            <PersonWhoCollects
                showSnackbar={showSnackbar}
                shipment={shipment}
                orderSummary={orderSummary!}
                customer={customer}
            />

            <Stack direction={{ xs: "column", sm: "row" }} spacing={2} width="100%">
                <Stack direction={"column"} spacing={1} width="100%">
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                        color={ColorsEpico.ColorDarkCharcoal}
                        fontSize={FontSizesEnum.Gamma}
                        sx={sxLabelStyle}
                    >
                        Porte
                    </Typography>
                    <SelectGeneric
                        onChange={handlechangeBearing}
                        options={ListBearing}
                        defaultValue={bearingValue}
                        sizeFont={FontSizesEnum.Delta}
                        sxSelect={sxSelectStyle}
                    />
                </Stack>
                <Stack direction={"column"} spacing={1} width="100%">
                    <Typography
                        sx={{ ...sxLabelStyle, mb: 1 }}
                        fontWeight={FontWeightEnum.Medium}
                        color={ColorsEpico.ColorDarkCharcoal}
                        fontSize={FontSizesEnum.Gamma}
                    >
                        TIEMPO EN QUE RECOGERÁS
                    </Typography>
                    <TextField
                        onChange={handlechangeTimeToCollect}
                        value={tiempoRecogeraValue}
                        placeholder=''
                        name='inputName'
                        size='small'
                        sx={inputMianSx}
                        slotProps={{
                            input: {
                                sx: {
                                    ...inputSx,
                                    maxLength: 50,
                                }
                            }
                        }}
                    />
                </Stack>
            </Stack>

        </>
    );
};