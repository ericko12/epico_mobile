import { useBreadcrumb } from "@/features/common/infrastructure/hooks/useBreadcrumb";
import { ChangeEvent, Fragment, useEffect, useState, useTransition } from "react";
import { BREAD_CRUMBS_BRANCH_EXTERNAL_ORDERS } from "@/features/branch/infrastructure/ui/branchExternalOrders/BranchExternalOrder.data";
import { Avatar, Box, Button, Checkbox, CircularProgress, Fade, Grid2, InputAdornment, Skeleton, Stack, TextField, Typography } from "@mui/material";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { sxAvatarEmployeer, sxBtnCancel, sxBtnSave, sxBtnSearch, sxContainerBranch, sxContainerEmployeer, sxContainerEmptyBranch, sxContainerFooter, sxLoadersBranchExternalOrder, sxSearchEmployee, sxTypographyCancel } from "@/features/branch/infrastructure/ui/branchExternalOrders/BranchExternalOrder.styles";
import { NoSearchMessage } from "@/features/customer/infrastructure/ui/customerlist/table/nosearchmessage/NoSearchMessage";
import SearchIcon from '@mui/icons-material/Search';
import { usersService } from "@/features/users/application/service/users.services";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { IEmployeeBranch } from "@/features/users/domain/interfaces/employee/IEmployeeBranch";
import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading";
import { regexNumber, regexTextNumbers } from "@/features/common/infrastructure/utils/regexGlobal";
import { IBranch } from "@/features/branch/domain/interfaces/branch";
import { branchService } from "@/features/branch/application/services/branch.services";
import { IBranchExternalRequest } from "@/features/branch/domain/interfaces/branch/IBranchExternalRequest";
import { Close } from "@mui/icons-material";
import { TruncatedTextWithTooltip } from "@/features/common/infrastructure/ui/labels/truncatedTextWithTooltip/TruncatedTextWithTooltip";
import { EmptyData } from "@/features/common/infrastructure/ui/tables/EmptyData";
import { NotFoundData } from "@/features/common/infrastructure/ui/tables/NotFoundData";

// Constants
const imageBucket = process.env.NEXT_PUBLIC_IMAGE_BUCKET;

const BranchExternalOrder = () => {
    // Services
    const { getEmployeeBranchByEmployee, putUserBranch } = usersService();
    const { getBranchesByStatus } = branchService();

    // Hooks
    const { setBreadcrumb } = useBreadcrumb();
    const { showSnackbar } = useSnackbar();
    const [pendingEmployee, startPendingEmployee] = useTransition();
    const [pendingPutUserBranch, startPendingPutUserBranch] = useTransition();
    const [pendingGetBranches, startPendingGetBranches] = useTransition();

    // States
    const [searchEmployee, setSearchEmployee] = useState<string>('');
    const [searchBranch, setSearchBranch] = useState<string>('');
    const [employees, setEmployees] = useState<IEmployeeBranch[]>([]);
    const [selectedEmployee, setSelectedEmployee] = useState<IEmployeeBranch | null>(null);
    const [selectedBranches, setSelectedBranches] = useState<number[]>([]);
    const [branches, setBranches] = useState<IBranch[]>([]);
    const [branchesFiltered, setBranchesFiltered] = useState<IBranch[]>([]);
    const [hasSearchError, setHasSearchError] = useState('');
    const [isChanged, setIsChanged] = useState(false);
    const [isSearchedEmployee, setIsSearchedEmployee] = useState(false);

    // UseEffect
    useEffect(() => {
        init();
    }, []);

    // Functions
    /**
     * Initializes the component by setting the breadcrumb.
     */
    const init = () => {
        setBreadcrumb(BREAD_CRUMBS_BRANCH_EXTERNAL_ORDERS);
    }

    /**
     * Normalizes a string by removing diacritics and converting it to lowercase.
     * @param {string} str - The string to normalize.
     * @returns {string} The normalized string.
     */
    const normalize = (str: string) =>
        str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();

    /**
     * Handles the search for employees based on the input value.
     */
    const handleSearchEmployee = async () => {
        setHasSearchError('');
        const searchEmployeeTrim = searchEmployee.trimEnd().trimStart();
        const isTextValid = regexTextNumbers.test(searchEmployeeTrim);
        const isNumberValid = regexNumber.test(searchEmployeeTrim);

        if (searchEmployeeTrim.length === 0) {
            setHasSearchError("Campo requerido");
            return;
        }

        if (isTextValid && !isNumberValid && searchEmployeeTrim.length < 3) {
            setHasSearchError("Ingrese al menos 3 caracteres");
            return;
        }
        if (!isTextValid && !isNumberValid) {
            setHasSearchError("Ingrese un nombre o ID válido");
            return;
        }
        if (isNumberValid && +searchEmployeeTrim === 0) {
            setHasSearchError("El ID no puede ser 0");
            return;
        }

        handleCancelSelectedEmployee();
        startPendingEmployee(async () => {
            const employeeId = isNumberValid ? +searchEmployeeTrim : undefined;
            const employeeName = (isTextValid && !isNumberValid) ? searchEmployeeTrim : undefined;

            const response = await getEmployeeBranchByEmployee(employeeId, employeeName)

            await handleRequestDto({
                snackBar: showSnackbar,
                response: response,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE
                },
                onSuccess: () => {
                    setEmployees(response?.data ?? []);
                    setIsSearchedEmployee(true);
                },
                onInvalid: () => {
                    setEmployees([]);
                    setIsSearchedEmployee(true);
                },
                onError: () => {
                    setEmployees([]);
                }
            })
        })
    }

    /**
     * Handles the search for branches based on the input value.
     * @param {ChangeEvent<HTMLInputElement>} e - The change event.
     */
    const handleSearchBranch = (e: ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value.toLowerCase();
        setSearchBranch(value);
        const filteredBranches = filterBranches(normalize(value));
        setBranchesFiltered(filteredBranches.sort((a, b) => a.sucursal.localeCompare(b.sucursal)));
    };

    /**
     * Filters the branches based on the search value.
     * @param {string} value - The search value.
     * @returns {IBranch[]} The filtered branches.
     */
    const filterBranches = (value: string): IBranch[] => {
        const normalizedValue = normalize(value);
        return branches.filter(({ id, sucursal }) =>
            id.toString().includes(normalizedValue) ||
            normalize(sucursal).includes(normalizedValue)
        );
    }

    /**
     * Handles the selection of an employee and fetches their branches.
     * @param {IEmployeeBranch} employee - The employee to select.
     */
    const handleSelectEmployee = async (employee: IEmployeeBranch) => {
        startPendingGetBranches(async () => {
            handleCancelSelectedEmployee();
            setSelectedEmployee(employee);
            setSelectedBranches(employee.assignedBranches.map(branch => branch.id));
            const response = await getBranchesByStatus(true);
            await handleRequestDto({
                snackBar: showSnackbar,
                response: response,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE
                },
                onSuccess: () => {
                    setBranches(response?.data?.sort((a, b) => a.sucursal.localeCompare(b.sucursal)) ?? []);
                    setBranchesFiltered(response?.data?.sort((a, b) => a.sucursal.localeCompare(b.sucursal)) ?? []);
                },
                onInvalid: () => {
                    setBranches([]);
                    setBranchesFiltered([]);
                },
                onError: () => {
                    setBranches([]);
                    setBranchesFiltered([]);
                }
            })
        })
    }

    /**
     * Handles the toggling of a branch in the selected branches list.
     * @param {number} branchId - The ID of the branch to toggle.
     */
    const handleToggleBranch = (branchId: number) => {
        setIsChanged(true);
        setSelectedBranches(prevSelected => {
            if (prevSelected.includes(branchId)) {
                return prevSelected.filter(id => id !== branchId);
            } else {
                return [...prevSelected, branchId];
            }
        });
    };

    /**
     * Handles the cancellation of the selected employee.
     */
    const handleCancelSelectedEmployee = () => {
        setIsChanged(false);
        setSelectedEmployee(null);
        setSelectedBranches([]);
        setSearchBranch('');
    }

    /**
     * Handles the saving of changes to the selected employee's branches.
     */
    const handleSaveChanges = async () => {
        startPendingPutUserBranch(async () => {
            const request: IBranchExternalRequest = {
                userId: selectedEmployee?.userId ?? 0,
                branchesIds: selectedBranches
            }

            const response = await putUserBranch(request);
            await handleRequestDto({
                snackBar: showSnackbar,
                response: response,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE
                },
                onSuccess: () => {
                    const branchesUpdated = selectedBranches.map(branchId => {
                        const branch = branches.find(branch => branch.id === branchId);
                        return {
                            id: branch?.id,
                            description: branch?.sucursal
                        }
                    })

                    const employeeUpdated: IEmployeeBranch = {
                        employeeId: selectedEmployee?.employeeId ?? 0,
                        userId: selectedEmployee?.userId ?? 0,
                        name: selectedEmployee?.name ?? '',
                        assignedBranches: branchesUpdated as { id: number; description: string }[]
                    }

                    setSelectedEmployee(employeeUpdated);
                    setEmployees(employees.map(employee => employee.employeeId === selectedEmployee?.employeeId ? employeeUpdated : employee));
                    setIsChanged(false);
                    showSnackbar('configuración guardada exitosamente', 'success');
                }
            })
        })
    }

    return (
        <Fragment>
            <Grid2 container spacing={{ xs: 2, md: 6 }} mb={2}>
                <Grid2 size={{ xs: 12, md: 6 }}>
                    <Stack direction="column" gap={1}>
                        <Typography fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Lambda} color={ColorsEpico.ColorPrimary} textTransform="uppercase">colaboradores</Typography>
                        <Typography fontWeight={FontWeightEnum.Regular} fontSize={FontSizesEnum.Gamma} color={ColorsEpico.ColorBlack}>Miembros disponibles para recibir notificaciones de pedidos externos por sucursal</Typography>
                    </Stack>
                </Grid2>
                {/* En móvil las columnas se apilan: el título iría muy lejos de su
                    lista, así que se reubica dentro de la columna de sucursales. */}
                <Grid2 size={{ xs: 12, md: 6 }} sx={{ display: { xs: 'none', md: 'block' } }}>
                    <Box mt={{ xs: 0, md: 5 }}>
                        <Typography fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Alpha} color={ColorsEpico.ColorBlack}>Sucursales</Typography>
                    </Box>
                </Grid2>
            </Grid2>
            <Grid2 container spacing={{ xs: 2, md: 4 }} mb={isChanged ? '80px' : '0px'}>
                <Grid2 size={{ xs: 12, md: 6 }}>
                    <Stack direction="row" gap={2}>
                        <TextField
                            fullWidth
                            placeholder="Buscar por Nombre o ID"
                            onChange={(e) => setSearchEmployee(e.target.value)}
                            error={!!hasSearchError}
                            helperText={hasSearchError}
                            sx={sxSearchEmployee}
                            onKeyDown={(e) => e.key === 'Enter' && handleSearchEmployee()}
                            slotProps={{
                                input: {
                                    startAdornment: (
                                        <InputAdornment position="start">
                                            <SearchIcon sx={{ color: ColorsEpico.ColorBlack }} fontSize="small" />
                                        </InputAdornment>
                                    ),
                                    sx: {
                                        height: '30px',
                                        fontSize: FontSizesEnum.Delta
                                    }
                                }
                            }}
                        />
                        <ButtonLoading
                            size="small"
                            type="submit"
                            variant="contained"
                            onClick={handleSearchEmployee}
                            loading={pendingEmployee}
                            disabled={pendingEmployee || pendingPutUserBranch || pendingGetBranches}
                            sx={sxBtnSearch}
                        >Buscar</ButtonLoading>
                    </Stack>

                    <Box sx={sxContainerEmployeer}>
                        {pendingEmployee ? (
                            <Box sx={sxLoadersBranchExternalOrder}>
                                <CircularProgress color="inherit" />
                            </Box>
                        ) : !employees.length ? (
                            isSearchedEmployee ? <NotFoundData msg="No se encontraron resultados" /> : <NoSearchMessage title="Selecciona colaborador" description="Realiza una búsqueda de colaborador para continuar" />
                        ) : (
                            employees.map(employee => (
                                <Stack
                                    key={employee.employeeId}
                                    direction={{ xs: "column", md: "row" }}
                                    justifyContent="space-between"
                                    alignContent="center"
                                    alignItems={{ xs: "flex-start", md: "center" }}
                                    p="16px"
                                    height={{ xs: "auto", md: "68px" }}
                                    gap={{ xs: 1, md: 0 }}
                                    sx={{
                                        borderBottom: `1px solid ${ColorsEpico.ColorGrayDull}`,
                                        cursor: 'pointer',
                                        backgroundColor: selectedEmployee?.employeeId === employee.employeeId ? ColorsEpico.ColorLightBlueSelected : 'transparent',
                                        transition: 'background-color 0.2s',
                                        '&:hover': {
                                            backgroundColor: `${ColorsEpico.ColorGrayDull}59`,
                                            cursor: pendingPutUserBranch || pendingGetBranches ? 'not-allowed' : 'pointer',
                                        }
                                    }}
                                    onClick={() => (pendingPutUserBranch || pendingGetBranches) ? null : handleSelectEmployee(employee)}
                                >
                                    <Stack direction="row" gap={2} alignContent="center" alignItems="center" width={{ xs: "100%", md: "59%" }} sx={{ minWidth: 0 }}>
                                        <Avatar
                                            src={`${imageBucket!}/${employee.employeeId}.jpg`}
                                            alt=""
                                            sx={sxAvatarEmployeer}
                                            onError={e => {
                                                const target = e.target as HTMLImageElement;
                                                target.onerror = null;
                                                target.src = "";
                                            }}
                                        >
                                            {
                                                (() => {
                                                    const names = employee.name?.split(" ").filter(Boolean) || [];
                                                    let initials = "";
                                                    if (names.length > 0) {
                                                        initials += names[0][0] || "";
                                                        if (names.length > 1) {
                                                            initials += names[names.length - 1][0] || "";
                                                        }
                                                    }
                                                    return initials.toUpperCase();
                                                })()
                                            }
                                        </Avatar>
                                        <Stack direction="column" width={{ xs: "auto", md: "81%" }} sx={{ minWidth: 0, flex: { xs: 1, md: "none" } }}>
                                            <TruncatedTextWithTooltip text={employee.name} />
                                            <Typography
                                                fontWeight={FontWeightEnum.Normal}
                                                fontSize={FontSizesEnum.Delta}
                                                color={ColorsEpico.ColorBlack}
                                                sx={{ opacity: 0.6 }}
                                            >
                                                #{employee.employeeId}
                                            </Typography>
                                        </Stack>
                                    </Stack>
                                    <Typography fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Gamma} color={ColorsEpico.ColorBlack} textTransform="uppercase" sx={{ textWrap: { xs: 'wrap', md: 'nowrap' }, pl: { xs: '56px', md: 0 } }}>sucursales asignadas: {employee.assignedBranches.length}</Typography>
                                </Stack>
                            ))
                        )}
                    </Box>
                </Grid2>
                <Grid2 size={{ xs: 12, md: 6 }}>
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                        fontSize={FontSizesEnum.Alpha}
                        color={ColorsEpico.ColorBlack}
                        sx={{ display: { xs: 'block', md: 'none' }, mb: 1 }}
                    >
                        Sucursales
                    </Typography>
                    {!selectedEmployee ? (
                        <Box sx={sxContainerEmptyBranch}>
                            <Box style={{ height: '100%', display: 'grid', placeContent: 'center' }}>
                                <Box style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                                    <Typography sx={{ fontSize: '1.2rem', fontWeight: 'bold', textTransform: 'uppercase' }} color={ColorsEpico.ColorDarkCharcoal}>
                                        No hay colaborador seleccionado
                                    </Typography>
                                    <Typography sx={{ fontSize: '0.9rem', mt: .5 }} color={ColorsEpico.ColorDarkCharcoal}>
                                        Para asignar sucursales elige primero un colaborador
                                    </Typography>
                                </Box>
                            </Box>
                        </Box>
                    ) : (
                        <Box>
                            <TextField
                                fullWidth
                                size="small"
                                label="Buscar sucursal"
                                value={searchBranch}
                                onChange={handleSearchBranch}
                                slotProps={{
                                    input: {
                                        endAdornment: (
                                            <>
                                                {searchBranch ? (
                                                    <InputAdornment
                                                        position="start"
                                                        sx={{ cursor: 'pointer' }}
                                                        onClick={() => {
                                                            setSearchBranch('')
                                                            setBranchesFiltered(filterBranches(''))
                                                        }}
                                                    >
                                                        <Close sx={{ color: ColorsEpico.ColorBlack }} fontSize="small" />
                                                    </InputAdornment>
                                                ) :
                                                    <InputAdornment position="start">
                                                        <SearchIcon sx={{ color: ColorsEpico.ColorBlack }} fontSize="small" />
                                                    </InputAdornment>
                                                }
                                            </>
                                        ),
                                    }
                                }}
                            />

                            {pendingGetBranches ? (
                                <Skeleton variant="text" width={180} height={28} sx={{ my: 1 }} />
                            ) : (
                                <Typography fontWeight={FontWeightEnum.Regular} fontSize={FontSizesEnum.Gamma} my={1}>
                                    {selectedBranches.length} de {branches.length} seleccionados
                                </Typography>
                            )}

                            <Box sx={sxContainerBranch} >
                                {pendingGetBranches ? (
                                    <Box sx={sxLoadersBranchExternalOrder}>
                                        <CircularProgress color="inherit" />
                                    </Box>
                                ) : branchesFiltered.length === 0 ? <NotFoundData msg="No se encontraron resultados" /> :
                                    branchesFiltered.map(branch => (
                                        <Fragment key={branch.id}>
                                            <Stack
                                                direction="row"
                                                alignContent="center"
                                                alignItems="center"
                                                p="16px"
                                                minHeight="68px"
                                                height={{ xs: "auto", md: "68px" }}
                                                spacing={2}
                                                sx={{
                                                    borderBottom: `1px solid ${ColorsEpico.ColorGrayDull}`,
                                                }}
                                            >
                                                <Checkbox
                                                    checked={selectedBranches.includes(branch.id)}
                                                    onChange={() => handleToggleBranch(branch.id)}
                                                    disabled={pendingPutUserBranch}
                                                    sx={{
                                                        color: ColorsEpico.ColorPrimary,
                                                        '&.Mui-checked': {
                                                            color: ColorsEpico.ColorPrimary,
                                                        },
                                                    }}
                                                />
                                                <Stack direction="column" sx={{ minWidth: 0 }}>
                                                    <Typography fontWeight={FontWeightEnum.Medium} fontSize={FontSizesEnum.Gamma} color={ColorsEpico.ColorDarkCharcoal}>{branch.sucursal}</Typography>
                                                    <Typography fontWeight={FontWeightEnum.Normal} fontSize={FontSizesEnum.Delta} color={ColorsEpico.ColorGray}>ID: {branch.id}</Typography>
                                                </Stack>
                                            </Stack>
                                        </Fragment>
                                    ))}
                            </Box>
                        </Box>
                    )}
                </Grid2>
            </Grid2>
            <Fade in={isChanged} timeout={150} unmountOnExit>
                <Box sx={{ ...sxContainerFooter, bottom: { xs: 'calc(70px + env(safe-area-inset-bottom))', md: 0 } }}>
                    <Button
                        onClick={handleCancelSelectedEmployee}
                        disabled={pendingEmployee || pendingPutUserBranch || pendingGetBranches}
                        variant="outlined"
                        size="small"
                        sx={sxBtnCancel}
                    >
                        <Typography sx={sxTypographyCancel}>Cancelar</Typography>
                    </Button>
                    <Button
                        disabled={pendingEmployee || pendingPutUserBranch || pendingGetBranches}
                        variant="contained"
                        color="primary"
                        size="small"
                        sx={sxBtnSave}
                        onClick={handleSaveChanges}
                        loading={pendingPutUserBranch}
                    >
                        {pendingPutUserBranch ?
                            <Box sx={{ height: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                <CircularProgress size={15} color='inherit' />
                            </Box>
                            : 'Guardar cambios'
                        }
                    </Button>
                </Box>
            </Fade>
        </Fragment >
    )
}

export default BranchExternalOrder;