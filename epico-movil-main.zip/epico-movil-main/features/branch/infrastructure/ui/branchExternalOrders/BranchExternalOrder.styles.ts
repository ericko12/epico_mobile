import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { SxProps } from "@mui/material";

export const sxLoadersBranchExternalOrder: SxProps = { 
    position: 'relative', 
    display: 'grid',
    placeContent: 'center',
    height: '100%'
}

export const sxSearchEmployee: SxProps = {
    height: '30px',
    '& .MuiOutlinedInput-input': {
        paddingY: '3px',
    }
}

// Las alturas fijas dejaban cajas casi vacías de 674/640/720px en móvil.
export const sxContainerEmployeer: SxProps = {
    height: { xs: 'auto', md: "674px" },
    maxHeight: { xs: '55vh', md: "674px" },
    mt: 2,
    border: `1px solid ${ColorsEpico.ColorGrayDull}`,
    borderRadius: '4px',
    overflow: 'auto',
}

export const sxContainerBranch: SxProps = {
    height: { xs: 'auto', md: "640px" },
    maxHeight: { xs: '55vh', md: "640px" },
    border: `1px solid ${ColorsEpico.ColorGrayDull}`,
    borderRadius: '4px',
    overflow: 'auto',
}

export const sxContainerEmptyBranch: SxProps = {
    height: { xs: '180px', md: "720px" },
    border: `1px solid ${ColorsEpico.ColorGrayDull}`,
    borderRadius: '4px',
    overflow: 'auto',
}

export const sxContainerFooter: SxProps = {
    position: 'fixed',
    bottom: 0,
    left: 0,
    right: { xs: 0, md: 11 },
    width: { xs: '100%', md: '-webkit-fill-available' },
    backgroundColor: ColorsEpico.ColorWhite,
    padding: '16px',
    borderTop: `1px solid ${ColorsEpico.ColorGrayDull}`,
    display: 'flex',
    justifyContent: 'flex-end',
    alignItems: 'center',
}

export const sxBtnCancel: SxProps = {
    marginRight: '8px',
    fontWeight: FontWeightEnum.Medium,
    color: ColorsEpico.ColorDarkCharcoal,
    borderColor: ColorsEpico.ColorGrayNeutral,
    minWidth: "105px",
    borderRadius: '4px',
    height: '40px',
    '&.Mui-disabled': {
        opacity: .5,
    },
}

export const sxBtnSave: SxProps = {
    width: "214px",
    borderRadius: '4px',
    height: '40px',
    fontWeight: FontWeightEnum.Medium,
    fontSize: FontSizesEnum.Gamma,
}

export const sxBtnSearch: SxProps = {
    width: '88px',
    height: '30px',
    boxShadow: 'none',
    borderRadius: '.4rem',
    bgcolor: ColorsEpico.ColorDodgerBlue,
    transition: 'background-color 0.3s ease',
    '&:hover': {
        backgroundColor: ColorsEpico.ColorBlueMarine
    }
}

export const sxTypographyCancel: SxProps = {
    lineHeight: 1.5,
    fontWeight: FontWeightEnum.Medium,
    fontSize: FontSizesEnum.Gamma,
}

export const sxAvatarEmployeer: SxProps = {
    width: 40,
    height: 40,
    backgroundColor: ColorsEpico.ColorAvatarBackground,
    color: ColorsEpico.ColorAvatarText
}