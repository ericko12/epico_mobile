export const BREAD_CRUMBS_BRANCH_EXTERNAL_ORDERS = [
    { title: "Configuración" },
    { title: "Sucursales para pedidos externos" },
]