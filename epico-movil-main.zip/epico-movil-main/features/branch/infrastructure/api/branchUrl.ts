import { OrderTypeEnum } from "@/features/common/domain/enums/OrderTypeEmun";
import { SortBy } from '@/features/branch/domain/types/SortBy.types';

/**
 * Function: Constructs the URL to fetch the branches.
 * 
 * @returns {string} - The URL string to access the endpoint for retrieving the branches (`/api/v1/Sucursales`).
 */
export const UrlGetBranches = (): string => '/api/v1/Sucursales';

/**
 * Function: Constructs the URL to fetch the branches by status.
 * 
 * @param {boolean} status - The status of the branches to fetch
 * @returns {string} - The URL string to access the endpoint for retrieving the branches by status (`/api/v1/Sucursales?activas={status}`).
 */
export const UrlGetBranchesByStatus = (status: boolean): string => `/api/v1/Sucursales?activas=${status}`;

/**
 * Constructs the URL to validate if a project is active in a specific branch.
 * Used by SecurityProjectService to check project status in branches.
 * 
 * @param {number} ObjectId - The project ID to validate
 * @param {number} BranchId - The branch ID where to check the project status
 * @returns {string} The URL string to access the endpoint for validating project status
 */
export const UrlSecurityProjectInStore = (ObjectId: number, BranchId: number) => {
    return `/api/v1/Objeto/Sucursal?ObjetoId=${ObjectId}&InfoSucursalId=${BranchId}`;
};

/**
 * Function: Constructs the URL to fetch the address details for a specific branch.
 *
 * Always returns the endpoint for a single branch based on its ID.
 *
 * @param {number} branchId - The unique identifier of the branch to retrieve address details for.
 * @returns {string} The URL string to access the endpoint for retrieving branch address information
*/
export const UrlGetBranchAddressByBranchId = (branchId: number) => {
    return `/api/v1/Sucursales/Direcciones/${branchId}`;
};

/**
 * Function: Constructs the URL to fetch branch addresses with filtering and sorting options.
 *
 * Builds the full endpoint URL including all required query parameters:
 * - `incluirCedis`: whether to include CEDIS branches in the response.
 * - `país`: the numeric country identifier.
 * - `ordenPor`: the field by which to sort the results.
 * - `ordenTipo`: the sort order (ascending or descending).
 *
 * @param {boolean} includeCedis - Indicates whether to include CEDIS branches.
 * @param {number} country - The country ID used to filter branches.
 * @param {OrderTypeEnum} orderType - The sorting order (`ASC` or `DESC`).
 * @param {SortBy} sortBy - The field to order the results by (e.g., `EstadoID`).
 * @param {?number[]} [branchsId] - Optional array of branch IDs to filter the results.
 * @returns {string} The complete URL string for the endpoint
 */
export const UrlGetBranchAddress = (includeCedis: boolean, country: number, orderType: OrderTypeEnum, sortBy: SortBy, branchsId?: number[]) => {
    const branchIdsParam = [...new Set(branchsId)]?.map(id => `SucursalId=${id}`).join('&');
    return `/api/v1/Sucursales/Direcciones?incluirCedis=${includeCedis}&país=${country}&ordenPor=${sortBy}&ordenTipo=${orderType}${branchIdsParam ? `&${branchIdsParam}` : ''}`;
};

/**
 * Function: Constructs the URL to fetch the directory of branches with sorting parameters.
 *
 * Builds the endpoint URL including query parameters:
 * - `ordenPor`: field to sort results by.
 * - `ordenTipo`: sorting order (`ASC` or `DESC`).
 *
 * @param {OrderTypeEnum} orderType - The sorting order (`ASC` or `DESC`).
 * @param {SortBy} sortBy - The field to sort results by (e.g., `EstadoID`).
 * @returns {string} The URL string for the endpoint.
 */
export const UrlGetDirectory = (sortBy: SortBy, orderType: OrderTypeEnum) => {
    return `/api/v2/Sucursales/Directorio?ordenPor=${sortBy}&ordenTipo=${orderType}`;
}

/**
 * Generates the API endpoint URL to retrieve branches by region for a specific customer.
 * @param {number} customerId - The unique identifier of the customer
 * @returns {string} The API endpoint URL for fetching branches filtered by customer ID
 */
export const UrlGetBranchOnRegionByCustomerId = (customerId: number) => `/api/v1/regions/Sucursales?ClientId=${customerId}`;

export const UrlSecurityProjectInOrigin = (ObjectId: number, OriginId: number) => `/api/v1/Origen/${OriginId}/Objeto/${ObjectId}`;