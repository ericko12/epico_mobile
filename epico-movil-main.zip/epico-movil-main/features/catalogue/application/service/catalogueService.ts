import { EPICO_API } from "@/axios/axios_helper";
import { IConcession } from "@/features/common/domain/interfaces/catalogs/IConcession";
import { IPaymentMethod } from "@/features/common/domain/interfaces/catalogs/IPaymentMethod";
import { UrlGetBanks, UrlGetConcesiones, UrlGetSpeciality } from "@/features/catalogue/infrastructure/api/CatalogueUrls";
import { UrlGetPaymentMethods } from "@/features/openPay/infrastructure/api/OpenPayUrls";
import { handleRequest } from "@/features/common/infrastructure/api/handleRequest";
import { configHeaders } from "@/features/common/application/service/ConfigHeaders";
import { ISpecialityFilter } from "@/features/products/domain/interfaces/ISpecialityFilter";
import { IBankResponse } from "@/features/catalogue/domain/interface/IBankResponse";

/**
 * Service for handling catalog operations.
 * Provides functions to manage concessions and payment methods.
 */
export const catalogueService = () => {
    /**
     * Get all concessions
     * @returns {Promise<IResponseDto<IConcession[] | null>>} - A promise that returns the list of concessions
     */
    const getConcesiones = () =>
        handleRequest<IConcession[] | null>(
            EPICO_API.get(UrlGetConcesiones(), configHeaders())
        );

    /**
     * Get all payment methods
     * @returns {Promise<IResponseDto<IPaymentMethod[] | null>>} - A promise that returns the list of payment methods
     */
    const getPaymentMethods = () =>
        handleRequest<IPaymentMethod[] | null>(
            EPICO_API.get(UrlGetPaymentMethods(), configHeaders())
        );
    /**
     * Function to get speciality for the catalog filters
     * @returns {Promise<IResponseDto<ISpecialityFilter[] | null>>}
     */
    const getSpeciality = () =>
        handleRequest<ISpecialityFilter[] | null>(
            EPICO_API.get(UrlGetSpeciality(), configHeaders())
        );

    const getBanks = () =>
        handleRequest<IBankResponse[] | null>(
            EPICO_API.get(UrlGetBanks(), configHeaders())
        );

    return {
        getConcesiones,
        getPaymentMethods,
        getSpeciality,
        getBanks
    };
};