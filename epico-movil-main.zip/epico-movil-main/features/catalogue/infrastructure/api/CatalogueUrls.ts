/**
 * Function to get concessions from the API.
 * Returns a URL string with query parameters for filtering concessions.
 * 
 * @param {boolean} [status=true] - Filter concessions by active status. Defaults to true to get only active concessions.
 * @returns {string} URL string for concessions endpoint with query parameters
 */
export const UrlGetConcesiones = (status: boolean = true) => {
    return `/api/v1/Ventas/Concesiones?Status=${status}`;
}

/**
 * Generates the URL to retrieve the light service Speciality.
 *
 * @function UrlLightServiceSpeciality
 * @returns {string} The API endpoint URL for obtaining light service Speciality.
 */
export const UrlGetSpeciality = () => {
    return `/api/v2/ServicioLigero/Categoria`;
}

/**
 * Generates the URL to retrieve the banks.
 *
 * @function UrlGetBanks
 * @returns {string} The API endpoint URL for obtaining banks.
 */
export const UrlGetBanks = () => '/api/v1/Bancos?Status=true'