export const BREAD_CRUMBS = [
    { title: "Catálogo" },
];