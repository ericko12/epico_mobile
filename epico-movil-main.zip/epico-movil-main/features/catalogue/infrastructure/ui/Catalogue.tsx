import { setOnSelectCheckOutThunk, setDisableCheckOutThunk } from "@/features/checkout/application/redux/checkOutThunks";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { BREAD_CRUMBS } from "@/features/catalogue/infrastructure/ui/Catalogue.data";
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks";
import { RootState } from "@/features/common/application/redux/store";
import { useBreadcrumb } from "@/features/common/infrastructure/hooks/useBreadcrumb";
import { ModalConfirm } from "@/features/common/infrastructure/ui/dialog/ModalConfirm/ModalConfirm";
import FamilyCatalogue from "@/features/family/infrastructure/ui/FamilyCatalogue/FamilyCatalogue";
import { resetFiltersThunks, resetProductSearchParameters, setIsFamilyThunks, setIsSaveSearchedThunks, setProductFilter } from "@/features/products/application/redux/ProductThunks";
import { IProductState } from "@/features/products/domain/interfaces/IProductState";
import { PATH_PAGE } from "@/routes/paths";
import { Typography } from "@mui/material";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect } from "react";
import { ProductCatalogue } from "@/features/products/infrastructure/ui/productCatalogue/ProductCatalogue";

/**
 * Functional component that returns the template for the catalogue page.
 *
 * @export
 * @returns {JSX.Element}
 */
export default function Catalogue() {
    //#region - hooks
    const dispatch = useAppDispatch();
    const { productSearchParameters, isSaveSearched, isFamily } = useAppSelector<IProductState>((state: RootState) => state.sessionState.productState);
    const { setBreadcrumb } = useBreadcrumb();
    const { checkOutList,selectedOrderSummary, loading } = useAppSelector<ICheckOutState>((state: RootState) => state.sessionState.checkOutsState);
    const router = useRouter();
    const searchParams = useSearchParams();
    // Identificador para saber si se accedió desde el menú usando sessionStorage
    const sourceFromMenu = typeof window !== 'undefined' && sessionStorage.getItem('catalogSourceFromMenu') === 'true';
    //#endregion - hooks
    
    // #region functions  
    const setFamily = async () => {
        // Validates if there is an active search
        if (isSaveSearched ) {
            await dispatch(await setIsSaveSearchedThunks(false));
        } else {
            await dispatch(await setIsFamilyThunks(true));
            await dispatch(await resetFiltersThunks());
            await dispatch(await resetProductSearchParameters({ ...productSearchParameters, FamilySelectedFromCatalogue: false }));
            await dispatch(await setProductFilter());
        }
    };

    useEffect(() => {
        setBreadcrumb(BREAD_CRUMBS);
        dispatch(setOnSelectCheckOutThunk(() => { }))
        setFamily();
        return () => {
            resetSearchParameters();        
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const resetSearchParameters = async () => {
            await dispatch(await setIsSaveSearchedThunks(false));
    }

  useEffect(() => {
        if (sourceFromMenu) {            
            if (selectedOrderSummary != null) {
                const activeCheckout = checkOutList.find(co => co.active);
                dispatch(setDisableCheckOutThunk(activeCheckout?.pedidoID ?? ''));
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    
    // Limpiar sessionStorage y preventAutoActivation cuando se salga de /Catalogo
    useEffect(() => {
        return () => {
            // Esta función se ejecuta cuando el componente se desmonta
            if (typeof window !== 'undefined' && !window.location.pathname.startsWith('/Catalogo')) {
                sessionStorage.removeItem('catalogSourceFromMenu');
            }
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    /**
     * Redirect to the clients page if there are no clients selected.
     */
    useEffect(() => {
        if (checkOutList.length === 0 && !loading && sourceFromMenu !== true) {
            const idTimeOut = setTimeout(() => {
                router.push(PATH_PAGE.clientes.root);
            }, 5000);

            return () => {
                clearTimeout(idTimeOut);
            }
        }

    }, [loading, checkOutList])
    //#endregion - functions

    return (
        <>
            {/* Modal to select a client */}
            {
                (checkOutList.length === 0 && !loading && sourceFromMenu !== true) &&
                <ModalConfirm
                    openModal={true}
                    titulo="SELECCIONA UN CLIENTE"
                    onSave={() => router.push(PATH_PAGE.clientes.root)}
                    btnTextSave='Aceptar'>
                    <Typography>
                        No hay clientes seleccionados, realiza una búsqueda de clientes para abrir una caja.
                    </Typography>
                    <Typography sx={{ marginTop: '20px' }}>
                        Serás redirigido a Clientes para seleccionar un cliente.
                    </Typography>
                </ModalConfirm>
            }
            {/* Catalogue */}
            {
                isFamily
                    ? <FamilyCatalogue />
                    : <ProductCatalogue sourceFromMenu={sourceFromMenu} />
            }
        </>
    )
}
