/**
 * Interface for bank response
 * @interface IBankResponse
 * @property {number} bancoId - The bank ID
 * @property {string} banco - The bank name
 * @property {string} razonSocial - The bank's legal name
 * @property {boolean} status - The status of the bank
 * @property {string} codigo - The bank's code
 * @property {number} cuentaId - The account ID
 */
export interface IBankResponse {
    bancoId: number;
    banco: string;
    razonSocial: string;
    status: boolean;
    codigo: string;
    cuentaId: number;
}