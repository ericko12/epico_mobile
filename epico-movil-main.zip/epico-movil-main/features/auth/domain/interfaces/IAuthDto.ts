/**
* interface: Respresentación de credenciales del usuario.
* @property user?: string;
* @property password?: string;
*/
export interface IAuthDto {
    user?: string;
    password?: string;
}
