import { INotification } from "@/features/common/domain/interfaces/notification/INotification";
import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";

/**
 * Interface: Represents the authentication object containing user credentials and session details.
 * @property userAuth?: IUserDto; - Optional, information about the authenticated user.
 * @property token: string; - The user's authentication token.
 * @property isLoggedIn: boolean; - Indicates whether the user is currently logged in.
 * @property adminThird: boolean; - Identifies if the user acts as a third-party administrator.
 * @property adminTemporal: number; - Stores the ID of a temporary administrator, if applicable.
 * @property addProducts: boolean; - Stores the permission to add products.
 * @property subscriptionId:string | undefined; - Subscription identifier for push notifications.
* @property  notifications: INotification[] - List of notifications associated with the user session.
 * @property timePostpone: number - Timestamp representing the postpone time for notifications.
 */
export interface IAuth {
    userAuth?: IUserDto,
    token: string;
    isLoggedIn: boolean,
    adminThird: boolean,
    adminTemporal: number,
    addProducts: boolean,
    subscriptionId: string | undefined
    notifications: INotification[];
    timePostpone: number;
}
