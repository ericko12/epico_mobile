/**
 * Represents the response object containing security project object information.
 * 
 * @interface ObjectResponse
 * 
 * @property {number} objetoId - The unique identifier of the object.
 * @property {string} objeto - The object code or key.
 * @property {string} objetoNombre - The display name of the object.
 * @property {number} subModuloId - The identifier of the submodule this object belongs to.
 * @property {boolean} predeterminado - Indicates whether this object is set as default.
 */
export interface ObjectResponse {
    objetoId: number;
    objeto: string;
    objetoNombre: string;
    subModuloId: number;
    predeterminado: boolean;
}