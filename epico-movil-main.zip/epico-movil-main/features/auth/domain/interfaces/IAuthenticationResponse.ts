/**
 * Interface: Represents the structure of the authentication response.
 * Returned by the backend after a successful login attempt.
 *
 * @property {number} userId - The authenticated user id extracted from the token.
 * @property {number} expires_in - The validity period of the token, in seconds.
 */
export interface IAuthenticationResponse {
    userId: number;
    expires_in: number;
}