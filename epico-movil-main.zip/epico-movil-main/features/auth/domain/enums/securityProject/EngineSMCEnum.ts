/**
 * Enum representing the available versions of the SMC (Security Management Console) engine.
 * 
 * @enum {string}
 * @readonly
 */
export enum EngineSMCEnum {
    SMC3 = "SMC3.0",
    SMC4 = "SMC4.0",
}