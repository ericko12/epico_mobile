import { SxProps } from "@mui/material"

export const checkBoxSx: SxProps = {
    padding: "0px 9px",
    color: '#1b3892',
    '&.Mui-checked': {
        color: '#1b3892',
    },
}

export const selectProfileSx: SxProps = {
    '& .MuiOutlinedInput-root': { height: '32px' },
    '& .MuiInputBase-input': {
        padding: '7.5px'
    },
}