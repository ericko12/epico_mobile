"use client"

import { useSnackbar } from '@/context/snackBar/SnackBarContext';
import React, { useEffect, useState, useTransition } from 'react'
import { useDispatch } from 'react-redux';
import {
    Checkbox,
    Button,
    CircularProgress,
    Box,
    Typography,
    FormControlLabel,
    Autocomplete,
    TextField
} from '@mui/material';
import { buttonSx } from '@/features/auth/infrastructure/ui/form/loginForm/LoginForm.styles';
import { IUserDto } from '@/features/users/domain/interfaces/IUserDto';
import { TypeRoleEnum } from '@/features/roles/domain/enum/TypeRoleEnum';
import { encodeBase64WithKey } from '@/features/common/infrastructure/utils/encodeAndDecode';
import getSellersData from '@/features/seller/application/actions/getSellersData';
import dayjs from 'dayjs';
import { setExpirationDate, setSellers } from '@/features/seller/application/redux/sellerSlice';
import { actionsAuth } from '@/features/auth/application/redux/authSlice';
import { PATH_PAGE } from '@/routes/paths';
import { checkBoxSx, selectProfileSx } from '@/features/auth/infrastructure/ui/form/selectProfile/LoginSelectProfile.styles';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';
import { rolesServices } from '@/features/roles/application/service/roles.services';
import { authService } from '@/features/auth/application/service/auth.services';
import { useAppSelector } from '@/features/common/application/redux/hooks';
import { IModulesAndFunctionalities } from '@/features/roles/domain/interfaces/IModulesAndFunctionalities';
import { securityProjectService } from '@/features/auth/application/service/securityProject.services';
import { OrigenEnum } from '@/features/common/domain/enums/OrigenEnum';
import { handleRequestDto } from '@/features/common/application/handleRequestDto/handleRequestDto';
import { EngineSMCEnum } from '@/features/auth/domain/enums/securityProject/EngineSMCEnum';
import { getSMC4Preference } from '@/features/common/infrastructure/utils/smc4Preference';

const LoginSelectProfile = () => {
    // #region services
    const { getObject } = securityProjectService();
    // #region services
    // #region states
    const { adminTemporal } = useAppSelector(state => state.localState.authState)
    const [users, setUser] = useState<IUserDto[]>();
    const [message, setMessage] = useState<boolean>(false);
    const [selectedUser, setSelectedUser] = useState<string | null>(null);
    const [isAdminSelected, setIsAdminSelected] = useState<boolean>(true);
    const dispatch = useDispatch();
    const { showSnackbar } = useSnackbar();
    const { getAuthSessionByUser, getAllEmployeesEpico } = authService();
    const { getModulesAndFunctionalitiesByIdRole } = rolesServices();
    const [pending, startPending] = useTransition();
    const [loadingRedirect, setLoadingRedirect] = useState(false);
    // #endregion states
    // #region functions
    const recuperarEmpleados = async () => {
        const response = await getAllEmployeesEpico();
        if (response.statusCode === 200) setUser(response.data?.filter((item) => item.roleTypeId !== TypeRoleEnum.Administrador))
    }

    /**
     * Handles the change of the admin role selection.
     * 
     * @param {boolean} isAdmin - A boolean indicating whether the admin role is selected (true) or not (false).
     * 
     * @returns {void}
     */
    const handleRoleChange = (isAdmin: boolean): void => {
        setMessage(false);
        setIsAdminSelected(isAdmin);
    };

    /**
     * Handles the change of the selected user in the dropdown.
     *
     * @param {React.SyntheticEvent} _event 
     * @param {(IUserDto | null)} value 
     */
    const handleSelectChange = (
        _event: React.SyntheticEvent,
        value: IUserDto | null
    ): void => {
        setMessage(false);
        setSelectedUser(value ? value.userId.toString() : null);
    };


    /**
    * RECUPERA EL LOGIN VALIDANDO EL USANDO EL USUARIO_ID.
    * @returns : () => Promise<IResponseDto<IUserAuthDto>>
    */
    const loginProgress = async () => {
        const userId = isAdminSelected ? adminTemporal : parseInt(selectedUser!.toString());
        return (await getAuthSessionByUser(userId));
    }

    /**
     * RECUPERA LOS MÓDULOS A LOS QUE TIENE ACCESO EL USUARIO;
     * @param rolId:number
     * @param roleTypeId:number
     * @returns : () => Promise<void>
     */
    const getModuleRole = async (rolId: number, roleTypeId: number) => {
        let addProductsPermission = false;
        const response = await getModulesAndFunctionalitiesByIdRole(rolId);
        if (response.data !== null && response.huboError === false) {
            // Set AddProduct permission in localStorage and redux store
            var modules = response.data.find(module => module.name.toUpperCase() === "CATÁLOGO");
            var functionalities = modules?.functions.find(func => func.name.toUpperCase() === "AGREGAR PRODUCTOS A PEDIDO");

            await setSmcEngine(response.data);

            if (modules && functionalities) {
                addProductsPermission = functionalities.isActive && modules.isActive;
            }

            dispatch(actionsAuth.setAddProducts(addProductsPermission))
            localStorage.setItem('AddProPermission', encodeBase64WithKey(JSON.stringify(addProductsPermission)))
            localStorage.setItem('Epico_MR', encodeBase64WithKey(JSON.stringify({ moduleRole: response.data, rolId, roleTypeId })))
        }
    }

    /**
     * Sets the SMC (Sucursal Más Cercana) engine configuration based on user permissions.
     * 
     * This function checks if the user has access to the "SMC 4.0" functionality within the
     * "MOTOR DE SUCURSAL MÁS CERCANA" module. If the module exists, the functionality is found,
     * and SMC 4.0 objects are present in the state, it activates the latest SMC engine version.
     * 
     * @param {IModulesAndFunctionalities[]} permissions - Array of modules and their associated functionalities
     * @returns {void}
     */
    const setSmcEngine = async (permissions: IModulesAndFunctionalities[]) => {
        let engineSMC4Active = false;
        let permissionsSMC4 = false;
        const modules = permissions.find(module => module.name.toUpperCase() === "MOTOR DE SUCURSAL MÁS CERCANA");
        const functionalities = modules?.functions.find(func => func.name.toUpperCase() === "USAR MOTOR SMC 4.0");
        const response = await getObject(OrigenEnum.Epico);

        await handleRequestDto({
            response,
            onSuccess: () => {
                const objectSMC4 = response.data?.filter(obj => obj.objeto.includes(EngineSMCEnum.SMC4)) || [];

                if (modules && functionalities && !!objectSMC4.length) {
                    engineSMC4Active = functionalities.isActive && modules.isActive;
                    permissionsSMC4 = functionalities.isActive && modules.isActive;
                }

                if (!!objectSMC4.length && getSMC4Preference()) {
                    engineSMC4Active = true;
                }

                dispatch(actionsAuth.setEngineSMC4(engineSMC4Active));
                dispatch(actionsAuth.setPermissionSMC4(permissionsSMC4));
            },
            onInvalid: () => {
                dispatch(actionsAuth.setEngineSMC4(false));
                dispatch(actionsAuth.setPermissionSMC4(false));
            },
            onError: () => {
                dispatch(actionsAuth.setEngineSMC4(false));
                dispatch(actionsAuth.setPermissionSMC4(false));
            }
        });
    }

    /**
     * Handles the onClick event for login or admin redirection. 
     * @async
     * @function
     * @returns {Promise<void>} - A promise that resolves when the login process or redirection is complete.
     */
    const onClick = async (): Promise<void> => {

        startPending(async () => {
            try {
                if (!isAdminSelected && selectedUser === null) {
                    setMessage(true);
                    return;
                }
                if (!isAdminSelected) {
                    const response = await loginProgress();
                    if (response?.data) {

                        const { roleId, roleTypeId, userTypeId, employeeId }: IUserDto = response.data;
                        const sellersList = await getSellersData(userTypeId, employeeId);

                        if (sellersList.length > 0) {
                            const expirationDate = dayjs().add(5, 'minutes').toDate();
                            dispatch(setExpirationDate(expirationDate.toISOString()));
                            dispatch(setSellers(sellersList));
                        }
                        dispatch(actionsAuth.setThirdAdmin(true));

                        dispatch(actionsAuth.loginUser(response.data));
                        await getModuleRole(roleId, roleTypeId);
                        dispatch(actionsAuth.setLogged(true));

                        // Get redirect URL from URL parameters
                        const urlParams = new URLSearchParams(window.location.search);
                        const redirectUrl = urlParams.get('p');

                        // Redirect to the original URL or default to clientes page
                        const targetUrl = redirectUrl ? decodeURIComponent(redirectUrl) : PATH_PAGE.clientes.root;

                        setLoadingRedirect(true);
                        window.location.href = targetUrl; // Se mantiene sin router para que se instale freshchat con los datos del usuario
                    } else {
                        showSnackbar(response.error.mensaje || "Hubo un error al intentar iniciar sesión", 'error');
                    }
                } else {
                    await new Promise((resolve) => setTimeout(resolve, 100));
                    dispatch(actionsAuth.setLogged(true));

                    // Get redirect URL from URL parameters
                    const urlParams = new URLSearchParams(window.location.search);
                    const redirectUrl = urlParams.get('p');

                    // Redirect to the original URL or default to clientes page
                    const targetUrl = redirectUrl ? decodeURIComponent(redirectUrl) : PATH_PAGE.clientes.root;

                    setLoadingRedirect(true);
                    window.location.href = targetUrl; // Se mantiene sin router para que se instale freshchat con los datos del usuario
                }
            } catch (_error) {
                showSnackbar("Hubo un error al intentar iniciar sesión", 'error');
            }

        });

    }

    /**
     * Capitalizes the first letter of a string and converts the rest to lowercase.
     * @function
     * @param {string} str - The string to be capitalized.
     * @returns {string} The capitalized string.
     */
    const capitalize = (str: string): string =>
        str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
    // #endregion functions

    useEffect(() => {
        recuperarEmpleados()
    }, []);


    return (
        <Box>
            <Box mb={2} mt={3}>
                <div className="block">
                    <Typography>Ingresar como:</Typography>
                    <div>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={isAdminSelected}
                                    onChange={() => handleRoleChange(true)}
                                    sx={checkBoxSx}
                                    size="small"
                                />
                            }
                            label={<Typography>Administrador</Typography>}
                        />
                    </div>
                    <Box mb={3}>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={!isAdminSelected}
                                    onChange={() => handleRoleChange(false)}
                                    sx={checkBoxSx}
                                    size="small"
                                />
                            }
                            label={<Typography>Otro perfil</Typography>}
                        />
                        <Typography
                            variant="body2"
                            color={ColorsEpico.ColorRed}
                        >
                            {message ? "Debes seleccionar un perfil para ingresar" : <br />}
                        </Typography>
                    </Box>
                </div>

            </Box>
            <Box mb={3}>
                <Typography>Selecciona el Usuario/Perfil</Typography>
                <Autocomplete
                    disablePortal
                    options={users || []}
                    getOptionLabel={(user) =>
                        user
                            ? `${user.employeeId} - ${capitalize(user.name)} ${capitalize(user.lastName)} ${capitalize(user.position)}`
                            : ''
                    }
                    isOptionEqualToValue={(option, value) => option.employeeId === value.employeeId}
                    value={
                        users?.find((user) => user.userId.toString() === selectedUser) || null
                    }
                    onChange={handleSelectChange}
                    disabled={isAdminSelected}
                    sx={selectProfileSx}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            size="small"
                            placeholder="Ingresa ID Empleado/Perfil/Nombre/Usuario/Puesto..."
                        />
                    )}
                />
            </Box>

            <Button
                variant="contained"
                type="submit"
                fullWidth
                sx={buttonSx}
                onClick={onClick}
                disabled={pending || loadingRedirect}
            >
                {pending || loadingRedirect ? (
                    <CircularProgress size={24} color="inherit" />
                ) : (
                    "Iniciar sesión"
                )}
            </Button>
        </Box >
    );
};

export default LoginSelectProfile