import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { SxProps } from "@mui/material";

export const boxSx: SxProps = {
    display: 'flex',
    flexDirection: 'column',
    gap: 1,
    width: '100%'
};

export const boxTextField: SxProps = {
    display: 'flex',
    flexDirection: 'column',
    width: '100%'
};

export const textFieldSx: SxProps = {
    '& .MuiOutlinedInput-root': { height: '32px' },
    '& .MuiInputBase-input': {
        height: '32px',
        padding: '0 14px'
    },
    '& .MuiFormHelperText-root': {
        marginTop: '2px',
        fontSize: '11px',
    },
}

export const linkSx: SxProps = {
    margin: "0  0 15px 0",
    color: '#000000',
    textDecoration: 'underline',
    textDecorationColor: '#000000'
}

export const buttonSx: SxProps = {
    backgroundColor: '#1b3892',
    color: 'white',
    mb: 2,
    fontSize: FontSizesEnum.Gamma,
}

export const inputLabelSx: SxProps = {
    fontWeight: FontWeightEnum.Medium,
    fontSize: FontSizesEnum.Delta,
}

export const helperTextSx: SxProps = {
    fontSize: FontSizesEnum.Delta + " !important",
    fontWeight: FontWeightEnum.Regular,
    marginX: 0,
}