"use client"

import { useActionState, useEffect, useState } from 'react'
import {
    Box,
    Button,
    CircularProgress,
    IconButton,
    InputAdornment,
    Link,
    TextField,
    Typography,
} from '@mui/material'
import PasswordRecoveryDialog from '@/features/auth/infrastructure/ui/dialogs/PasswordRecoveryDialog'
import {
    boxSx,
    boxTextField,
    buttonSx,
    helperTextSx,
    inputLabelSx,
    linkSx,
    textFieldSx
} from '@/features/auth/infrastructure/ui/form/loginForm/LoginForm.styles'
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico'
import { FormLoginState } from '@/features/auth/application/loginSchema'
import { useDispatch } from 'react-redux'
import { actionsAuth } from '@/features/auth/application/redux/authSlice'
import { setExpirationDate, setSellers } from '@/features/seller/application/redux/sellerSlice'
import { PATH_PAGE } from '@/routes/paths'
import FadeOutTypography from '@/features/common/infrastructure/ui/typography/FadeOutTypography'
import { signup } from '@/features/auth/application/actions/validators/auth'
import { encodeBase64WithKey } from '@/features/common/infrastructure/utils/encodeAndDecode'
import { FirefoxWarningModal, detectFirefox } from '@/features/auth/infrastructure/ui/modal/FirefoxWarningModal';
import { IModulesAndFunctionalities } from '@/features/roles/domain/interfaces/IModulesAndFunctionalities'
import { getSMC4Preference } from '@/features/common/infrastructure/utils/smc4Preference'


const LoginForm = () => {
    //redux
    const dispatch = useDispatch();
    //#region states
    const [open, setOpen] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [showFirefoxModal, setShowFirefoxModal] = useState(false);
    const [state, action, pending] = useActionState<FormLoginState, FormData>(signup, undefined);
    //#endregion states

    useEffect(() => {
        if (detectFirefox()) {
            setShowFirefoxModal(true);
            return;
        }

        const run = async () => {
            let addProductsPermission = false;
            if (!state?.message && state?.responses && !pending) {
                // Token is stored in an httpOnly cookie by the backend.
                dispatch(actionsAuth.loginUser(state.responses.userAuth))
                // Set AddProduct permission in localStorage and redux store
                var modules = state.responses.permissions.find(module => module.name.toUpperCase() === "CATÁLOGO");
                var functionalities = modules?.functions.find(func => func.name.toUpperCase() === "AGREGAR PRODUCTOS A PEDIDO");

                await setSmcEngine(state.responses.permissions);

                if (modules && functionalities) {
                    addProductsPermission = functionalities.isActive && modules.isActive;
                }

                dispatch(actionsAuth.setAddProducts(addProductsPermission))

                localStorage.setItem('AddProPermission', encodeBase64WithKey(JSON.stringify(addProductsPermission)))

                if (state.responses.sellerList && state.responses.expirationDate) {
                    dispatch(setExpirationDate(state.responses.expirationDate.toISOString()));
                    dispatch(setSellers(state.responses.sellerList));
                }

                if (state.responses.adminTemporal) {
                    dispatch(actionsAuth.setAdminTemporal(state.responses.adminTemporal));
                } else {
                    dispatch(actionsAuth.setLogged(true));
                    window.location.href = PATH_PAGE.clientes.root; // Se mantiene sin router para que se instale freshchat con los datos del usuario
                }
            }
        };

        run();
    }, [state, pending, dispatch])

    /**
     * Sets the SMC (Sucursal Más Cercana) engine configuration based on user permissions.
     * 
     * This function checks if the user has access to the "SMC 4.0" functionality within the
     * "MOTOR DE SUCURSAL MÁS CERCANA" module. If the module exists, the functionality is found,
     * and SMC 4.0 objects are present in the state, it activates the latest SMC engine version.
     * 
     * @param {IModulesAndFunctionalities[]} permissions - Array of modules and their associated functionalities
     * @returns {void}
     */
    const setSmcEngine = async (permissions: IModulesAndFunctionalities[]) => {
        let engineSMC4Active = false;
        let permissionsSMC4 = false;
        const modules = permissions.find(module => module.name.toUpperCase() === "MOTOR DE SUCURSAL MÁS CERCANA");
        const functionalities = modules?.functions.find(func => func.name.toUpperCase() === "USAR MOTOR SMC 4.0");
        const objectSMC4Exist = (state?.objects?.length ?? 0) > 0;
        if (modules && functionalities && objectSMC4Exist) {
            engineSMC4Active = functionalities.isActive && modules.isActive;
            permissionsSMC4 = functionalities.isActive && modules.isActive;
        }

        if (objectSMC4Exist && getSMC4Preference()) {
            engineSMC4Active = true;
        }

        dispatch(actionsAuth.setEngineSMC4(engineSMC4Active));
        dispatch(actionsAuth.setPermissionSMC4(permissionsSMC4));
    }

    /**
     * Toggles the state of the dialog by inverting the current open state.
     *
     * @function
     * @returns {void}
     */
    const handleDialog = (): void => setOpen(prev => !prev);

    /**
     * Closes the current dialog and opens the FreshChat widget.
     *
     * @function
     * @returns {void}
     */
    const freshOnClick = (): void => {
        handleDialog();
        if (window.fcWidget) {
            window.fcWidget.open();
        }
    }

    /**
     * Toggles the visibility of the password.
     * @function
     */
    const handleTogglePasswordVisibility = () => setShowPassword((prev) => !prev);
    // #endregion functions

    return (
        <>
            <Box
                component="form"
                action={action}
                onSubmit={(e) => {
                    if (detectFirefox()) {
                        e.preventDefault();
                        setShowFirefoxModal(true);
                    }
                }}
                autoComplete="on"
                sx={boxSx}
            >
                {state?.message &&
                    <FadeOutTypography
                        key={state?.messageKey}
                        variant="body2"
                        color={ColorsEpico.ColorRed}
                    >
                        {state?.message}
                    </FadeOutTypography>
                }
                <Box
                    sx={boxTextField}
                >
                    <Typography sx={inputLabelSx}>USUARIO</Typography>
                    <TextField
                        id="user"
                        name='user'
                        variant="outlined"
                        size="small"
                        fullWidth
                        sx={textFieldSx}
                        defaultValue={state?.values?.user}
                        slotProps={{
                            formHelperText: {
                                sx: helperTextSx
                            }
                        }}
                        error={!!state?.errors?.user}
                        helperText={state?.errors?.user?.[0] || " "}
                    />
                    <Typography sx={inputLabelSx}>CONTRASEÑA</Typography>
                    <TextField
                        id="password"
                        name='password'
                        variant="outlined"
                        size="small"
                        fullWidth
                        sx={textFieldSx}
                        type={showPassword ? "text" : "password"}
                        defaultValue={state?.values?.password}
                        slotProps={{
                            input: {
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <IconButton onClick={handleTogglePasswordVisibility} edge="end">
                                            {!showPassword ? <VisibilityOff /> : <Visibility />}
                                        </IconButton>
                                    </InputAdornment>
                                ),
                            },
                            formHelperText: {
                                sx: helperTextSx
                            }
                        }}
                        error={!!state?.errors?.password}
                        helperText={state?.errors?.password?.[0] || " "}
                    />
                </Box>
                <Link
                    href="#"
                    onClick={() => setOpen(true)}
                    variant="body2"
                    sx={linkSx}>
                    Olvidé mi contraseña
                </Link>
                <Button
                    color="primary"
                    variant="contained"
                    type="submit"
                    fullWidth
                    sx={buttonSx}
                    disabled={pending}
                >
                    {pending ? (
                        <CircularProgress size={24} color="inherit" />
                    ) : (
                        "Iniciar sesión"
                    )}
                </Button>
            </Box>
            <PasswordRecoveryDialog
                open={open}
                onClose={handleDialog}
                freshOnClick={freshOnClick}
            />
            <FirefoxWarningModal
                open={showFirefoxModal}
                onClose={() => setShowFirefoxModal(false)}
            />

        </>
    );
};

export default LoginForm
