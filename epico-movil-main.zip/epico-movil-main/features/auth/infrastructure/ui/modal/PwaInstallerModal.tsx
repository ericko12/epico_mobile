import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';
import { ModalGeneric } from '@/features/common/infrastructure/ui/dialog/ModalGeneric'
import { Box, Card, CardContent, CardMedia, Grid } from '@mui/material';
import Typography from '@mui/material/Typography'
import React, { useEffect, useState } from 'react'
/**
 * PwaInstallerModal
 *
 * React functional component that listens for the browser's `beforeinstallprompt` event
 * and, when appropriate, displays a modal prompting the user to install the Progressive Web App (PWA).
 *
 * Example:
 * <PwaInstallerModal />
 *
 * @returns JSX.Element — a modal component that can trigger the PWA installation flow when available.
 */
export const PwaInstallerModal = () => {
    const [showModal, setShowModal] = useState(false);

    const isAppPwa = (): boolean => {
        const isStandalone =
            window.matchMedia("(display-mode: standalone)").matches ||
            window.matchMedia("(display-mode: minimal-ui)").matches ||
            (navigator as any).standalone === true ||
            (navigator as any).userAgentData?.brands?.some((b: any) => b.brand.includes("WebApp"));
        // Si NO está en modo PWA, entonces está en navegador
        return isStandalone;
    };

    useEffect(() => {
        // No ejecutar en SSR
        if (typeof window === 'undefined') return;

        let idleId: any = null;
        let timeoutId: number | null = null;
        let cancelled = false;

        const runCheck = () => {
            if (cancelled) return;
            try {
                const isPwa = isAppPwa();
                if (!cancelled) {
                    setShowModal(!isPwa);
                }
            } catch {
                // Silenciar errores en navegadores inesperados
            }
        };

        // Ejecutar la comprobación fuera del hilo principal cuando sea posible
        if ('requestIdleCallback' in window) {
            idleId = (window as any).requestIdleCallback(runCheck, { timeout: 500 });
        } else {
            // Fallback no bloqueante: programar en siguiente tick
            timeoutId = (window as any).setTimeout(runCheck, 0);
        }

        // Si la app se instala, ocultar modal inmediatamente
        const onAppInstalled = () => {
            cancelled = true;
            setShowModal(false);
        };
        window.addEventListener('appinstalled', onAppInstalled);

        return () => {
            cancelled = true;
            if (idleId !== null && (window as any).cancelIdleCallback) {
                (window as any).cancelIdleCallback(idleId);
            }
            if (timeoutId !== null) {
                clearTimeout(timeoutId);
            }
            window.removeEventListener('appinstalled', onAppInstalled);
        };
    }, []);

    return (
        <ModalGeneric
            showCloseButton={false}
            btndisabledClose={true}
            saveNotRequired={true}
            openModal={showModal}
            btndisabledSave={false}
            onSave={() => { }}
            titulo="DISPONIBLE SOLO EN LA APP EPICO"
            btnTextSave={""}
            borderModal={`2px solid ${ColorsEpico.ColorVibrantYellow} !important`}
            btnWidthSave={`200px !important`}
        >

            <>
                <Typography>
                    Para una mejor experiencia y seguridad, el acceso al sistema se realiza únicamente desde App.
                </Typography>
                <Typography>
                    Accede a la App de EPICO desde el acceso directo que ya tienes instalado en tu equipo o, si aún no la has instalado, utiliza el botón de instalación que aparece en la parte superior derecha de tu navegador.
                </Typography>

                {/* 🔹 Cards con imagen debajo del texto */}
                <Box sx={{ mt: 2 }}>
                    <Grid container spacing={2}>
                        {/* Card Chrome/Edge - instalación */}
                        <Grid item xs={12} sm={6}>
                            <Card
                                sx={{
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    border: '1px solid #e0e0e0',
                                    borderRadius: 2,
                                }}
                                variant="outlined"
                            >
                                <CardMedia
                                    component="img"
                                    image="/img/InstalarChrome.png" //  ruta de tu imagen
                                    alt="Instalar en Chrome: botón de la parte superior derecha"
                                    sx={{ height: 160, objectFit: 'cover' }}
                                />
                                <CardContent>
                                    <Typography variant="subtitle1" fontWeight={600}>
                                        Instalar en Chrome/Edge
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Haz clic en el botón <strong>Instalar</strong> en la parte superior derecha del navegador.
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Grid>

                        {/* Card Chrome/Edge - abrir en la App */}
                        <Grid item xs={12} sm={6}>
                            <Card
                                sx={{
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    border: '1px solid #e0e0e0',
                                    borderRadius: 2,
                                }}
                                variant="outlined"
                            >
                                <CardMedia
                                    component="img"
                                    image="/img/AbrirEnApp.png" //ruta de tu imagen
                                    alt="Abrir en App en Chrome: botón de la parte superior derecha"
                                    sx={{ height: 160, objectFit: 'cover' }}
                                />
                                <CardContent>
                                    <Typography variant="subtitle1" fontWeight={600}>
                                        Abrir en App en Chrome/Edge
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Haz clic en el botón <strong>Abrir en App</strong> en la parte superior derecha del navegador.
                                        para abrir la aplicación de EPICO.
                                    </Typography>
                                </CardContent>
                            </Card>
                        </Grid>
                    </Grid>
                </Box>
            </>

        </ModalGeneric>
    )
}



