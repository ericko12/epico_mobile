import { FC, useEffect, useState } from 'react';
import { ModalGeneric } from '@/features/common/infrastructure/ui/dialog/ModalGeneric';
import { Typography, Box } from '@mui/material';
import { FontWeightEnum } from '@/features/common/domain/enums/FontWeight';
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';
import WarningIcon from '@mui/icons-material/Warning';
import Chrome_icon from '@/public/img/Chrome_icon.svg';
import Edge_icon from '@/public/img/Edge_icon.svg';
import Brave_icon from '@/public/img/brave-icon.svg';
/**
 * Detects if the current browser is Firefox
 * @returns {boolean} True if browser is Firefox
 */
export const detectFirefox = (): boolean => {
    const userAgent = navigator.userAgent.toLowerCase();
    return userAgent.includes('firefox');
};

/**
 * Modal component that shows a warning for Firefox users
 * 
 * @component
 * @param {Object} props - Component props
 * @param {boolean} props.open - Controls modal visibility
 * @param {() => void} props.onClose - Function to close the modal
 * @returns {JSX.Element} The Firefox warning modal component.
 */
export const FirefoxWarningModal: FC<{ open: boolean; onClose: () => void }> = ({ open, onClose }) => {
    return (
        <ModalGeneric
            openModal={open}
            titulo="Navegador no compatible"
            onClose={onClose}
            saveNotRequired={true}
            btnTextClose="Cerrar"
            maxWidth="sm"
            regularTitle={false}
            btndisabledClose={false}
        >
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'center', textAlign: 'center' }}>
                <WarningIcon sx={{ color: ColorsEpico.ColorRedOpaque, fontSize: '3rem', mb: 1 }} />
                
                <Typography
                    fontWeight={FontWeightEnum.Bold}
                    fontSize={FontSizesEnum.Beta}
                    color={ColorsEpico.ColorDarkCharcoal}
                >
                    Estás usando Firefox
                </Typography>

                <Typography
                    fontWeight={FontWeightEnum.Regular}
                    fontSize={FontSizesEnum.Gamma}
                    color={ColorsEpico.ColorDarkCharcoal}
                >
                    Este navegador puede presentar problemas.
                </Typography>

                <Typography
                    fontWeight={FontWeightEnum.Medium}
                    fontSize={FontSizesEnum.Gamma}
                    color={ColorsEpico.ColorDarkCharcoal}
                >
                    Se recomienda usar Chrome, Edge o Brave para una mejor experiencia.
                </Typography>

                <Box sx={{ display: 'flex', gap: 3, justifyContent: 'center', alignItems: 'center', mt: 2 }}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                       <img
                            src={Chrome_icon.src}
                            alt="Chrome icon"
                            style={{ width: 22, height: 22, marginBottom: '2px' }}
                        />
                        <Typography
                            fontWeight={FontWeightEnum.Medium}
                            fontSize={FontSizesEnum.Delta}
                            color={ColorsEpico.ColorDarkCharcoal}
                        >
                            Chrome
                        </Typography>
                    </Box>
                    
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                        <img
                            src={Edge_icon.src}
                            alt="Edge icon"
                            style={{ width: 22, height: 22, marginBottom: '2px' }}
                        />
                        <Typography
                            fontWeight={FontWeightEnum.Medium}
                            fontSize={FontSizesEnum.Delta}
                            color={ColorsEpico.ColorDarkCharcoal}
                        >
                            Edge
                        </Typography>
                    </Box>

                        <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                        <img
                            src={Brave_icon.src}
                            alt="Brave icon"
                            style={{ width: 22, height: 22, marginBottom: '2px' }}
                        />
                        <Typography
                            fontWeight={FontWeightEnum.Medium}
                            fontSize={FontSizesEnum.Delta}
                            color={ColorsEpico.ColorDarkCharcoal}
                        >
                            Brave
                        </Typography>
                    </Box>
                </Box>
            </Box>
        </ModalGeneric>
    );
};