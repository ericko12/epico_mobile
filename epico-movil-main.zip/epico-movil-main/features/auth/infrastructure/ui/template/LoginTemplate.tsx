/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, { useEffect } from "react";
import { useAppSelector } from "@/features/common/application/redux/hooks";
import { TypeRoleEnum } from "@/features/roles/domain/enum/TypeRoleEnum";
import LoginSelectProfile from "@/features/auth/infrastructure/ui/form/selectProfile/LoginSelectProfile";
import LoginForm from "@/features/auth/infrastructure/ui/form/loginForm/LoginForm";
import { Card } from "@mui/material";
import FreshchatLogin from "@/features/auth/infrastructure/ui/freshChatWidget/FreshchatLogin";
import logoApymsa from "@/public/img/Apymsa2020.webp";
import { validateToken } from "@/features/common/infrastructure/utils/validateToken";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import Image from "next/image";
import { PATH_PAGE } from "@/routes/paths";
import { closeSession } from "@/features/auth/application/closeSesion";
import { useDispatch } from "react-redux";
import { actionsAuth } from "@/features/auth/application/redux/authSlice";
import { InitUser } from "@/features/users/domain/data/InitUser.data";

/**
 * Main component for handling the login template.
 * Displays either the `LoginForm` or `LoginSelectProfile` based on user authentication.
 */
const LoginTemplate = () => {
    //#region redux
    const { userAuth, isLoggedIn, adminThird } = useAppSelector(state => state.localState.authState);
    //#endregion redux
    //#region hooks
    const dispatch = useDispatch();
    //#endregion hooks
    //#region constants
    const version = process.env.NEXT_PUBLIC_VERSION;
    //#endregion constants

    useEffect(() => {
        const run = async () => {
            const isValid = await validateToken();
            if (isValid && isLoggedIn) {
                // Get redirect URL from URL parameters
                const urlParams = new URLSearchParams(window.location.search);
                const redirectUrl = urlParams.get('p');

                // Redirect to the original URL or default to clientes page
                const targetUrl = redirectUrl ? decodeURIComponent(redirectUrl) : PATH_PAGE.clientes.root;
                window.location.href = targetUrl;
            } else {
                closeSession();
                dispatch(actionsAuth.setLogged(false));
                dispatch(actionsAuth.loginUser(InitUser));
            }
        };

        run();
    }, []);

    const year = new Date().getFullYear();
    const isAdmin = userAuth?.roleTypeId === TypeRoleEnum.Administrador;
    const showProfileSelection = isAdmin || adminThird;

    return (
        <div className="min-h-screen bg-[url('/img/BgLogin.svg')] min-w-full absolute">
            <FreshchatLogin />
            <div className="min-h-screen min-w-full absolute bg-[#0e0171]/85 flex justify-center items-center">
                <Card className="w-full max-w-[380px] mx-4 h-auto p-7 rounded-lg">
                    <div className="flex justify-center items-center mb-2.5">
                        <Image src={logoApymsa.src} width={200} height={32} alt="Apymsa" />
                    </div>
                    <div className="text-center">
                        <p className="text-lg font-medium">Te damos la bienvenida a</p>
                        <p className="text-lg font-medium">EPICO</p>
                    </div>
                    {showProfileSelection ? <LoginSelectProfile /> : <LoginForm />}
                </Card>
                <footer className="absolute bottom-0 p-4 text-center text-sm font-medium" style={{ color: ColorsEpico.ColorWhite }}>
                    APYMSA TODOS LOS DERECHOS RESERVADOS ©{year}
                    <div className="text-xs font-normal mt-1">V{version}</div>
                </footer>
            </div>
        </div>
    );
};

export default LoginTemplate;
