'use client'
import freshchatConfig from '@/freshchatConfig';
import { useEffect } from 'react';

/**
 * Se declara fcWidget como parte global del objeto window
 */
declare global {
    interface Window {
        fcWidget: any;
        fcSettings: any;
        webkitSpeechRecognition: any;
        SpeechRecognition: any;
    }
}

/**
 * Organismo: Retorna el widget de Freshchat al iniciar la aplicacion ya sea mobile o desktop
 *
 * @param {{ isMobile?: boolean; }} [isMobile=false] 
 * @returns {FreshchatWidget} 
 */
export const FreshchatLogin = ({ isMobile = false }) => {
    // #region functions
    /**
     * Initializes the Freshchat widget by dynamically injecting the required script tags
     * into the DOM if they are not already present. The widget is configured based on
     * whether the user is on a mobile or desktop device.
     *
     * @async
     * @function iniciarFreshchat
     * @returns {Promise<void>} Resolves once the scripts are appended to the DOM.
     */
    const iniciarFreshchat = async (): Promise<void> => {
        if (!document.querySelector('#freshchat-widget-script')) {
            const script = document.createElement('script');
            script.id = 'freshchat-settings';
            script.innerHTML = `
                window.fcSettings = {
                token: "${freshchatConfig.token}",
                host: "${freshchatConfig.host}",
                locale: "es-LA",
                tags: ["exodus-cae"],
                externalId: "0",
                config:{
                    fullscreen: ${isMobile}
                   },
                
                }        
                `;
            document.body.appendChild(script);
            let freshchatScript = document.createElement('script');
            freshchatScript.id = 'freshchat-widget-script';
            freshchatScript.src = 'https://apymsa.freshchat.com/js/widget.js';
            freshchatScript.async = true;
            document.body.appendChild(freshchatScript);
        }
    }
    // #endregion functions

    useEffect(() => {

        iniciarFreshchat();
    }, []);
    return <></>
};

export default FreshchatLogin;
