'use client';
import { useEffect } from 'react';
import { useAppSelector } from '@/features/common/application/redux/hooks';
import freshchatConfig from '@/freshchatConfig';

/**
 * Organism: Returns the Freshchat widget when the application starts, 
 * whether it's on mobile or desktop.
 *
 * @param {{ isMobile?: boolean; }} [isMobile=false] - Indicates if the platform is mobile.
 * @returns {FreshchatWidget} - The initialized Freshchat widget.
 */

export const FreshchatWidget = ({ isMobile = false }) => {
  const { userAuth } = useAppSelector(state => state.localState.authState);

  const iniciarFreshchat = async (): Promise<void> => {
    const name = userAuth ? `${userAuth.name} ${userAuth.lastName}` : '';
    const empleadoid = userAuth?.employeeId?.toString() || '';
    const email = userAuth?.email || '';
    const storedRestoreId = localStorage.getItem('freshchat_restoreId');
    const fcSettingsObj: any = {
      token: freshchatConfig.token,
      host: freshchatConfig.host,
      locale: 'es-LA',
      tags: ['exodus-cae'],
      externalId: empleadoid,
      firstName: name,
      email: email,
      config: {
        fullscreen: isMobile,
        headerProperty: {
          hideChatButton: true
        }
      },
      onInit: function () {
        window.fcWidget.user.setProperties({
          EmpleadoId: empleadoid,
          Origen: 'Epico'
        }).catch(console.log);
      }
    };

    if (storedRestoreId) {
      fcSettingsObj.restoreId = storedRestoreId;
    }
    const settingsScript = document.createElement('script');
    settingsScript.id = 'freshchat-settings';
    settingsScript.innerHTML = `window.fcSettings = ${JSON.stringify(fcSettingsObj)};`;
    document.body.appendChild(settingsScript);
    const widgetScript = document.createElement('script');
    widgetScript.id = 'freshchat-widget-script';
    widgetScript.src = 'https://apymsa.freshchat.com/js/widget.js';
    widgetScript.async = true;
    widgetScript.onload = () => {
      if (window.fcWidget) {
        window.fcWidget.on('user:created', (event: { data?: { restoreId?: string } }) => {
          if (event?.data?.restoreId) {
            localStorage.setItem('freshchat_restoreId', event.data.restoreId);
          }
        });
      }
    };
    document.body.appendChild(widgetScript);
  };

  useEffect(() => {
    if (!document.querySelector('#freshchat-widget-script')) {
      iniciarFreshchat();
    }
  }, []);

  return <></>;
};
