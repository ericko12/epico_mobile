import { FreshchatInitOptions } from '@/features/auth/infrastructure/ui/freshChatWidget/freshchat.types';
    
/**
 * Initializes and configures the Freshchat widget for a user session.
 *
 * This function sets user properties and opens the Freshchat widget with a predefined message,
 * including user identification and a product search context.
 *
 * @param {FreshchatInitOptions} options - Configuration object to initialize Freshchat.
 * @param {string} options.name - Full name of the employee.
 * @param {number} options.employeeid - Unique numeric identifier for the employee.
 * @param {string} options.email - Email address of the employee.
 * @param {boolean} [options.isMobile=false] - Whether the user is on a mobile device.
 * @param {string} [options.origin] - Origin or app name from where the chat is initiated.
 * @param {string} [options.topicName] - Topic name to preselect in the chat.
 * @param {string} [options.searchQuery] - Product search query to prefill in the message.
 *
 * @returns {Promise<void>} A promise that resolves once Freshchat is configured and opened.
 */
export const startFreshchat = async ({
  name,
  employeeid,
  email,
  isMobile = false,
  origin,
  topicName,
  searchQuery
}: FreshchatInitOptions): Promise<void> => {
const loadWidget = () => {
  if (!window.fcWidget) return;

  const DefaultMessage = `${employeeid}. ${name}\nAplicación: ${origin}\n\nNecesito ayuda con un producto que estoy buscando:\n${searchQuery}`;
  window.fcWidget.user.setProperties({
    EmpleadoId: employeeid,    
    nombre: name,
    origen: origin,
    email: email
  }).then(() => {
    window.fcWidget.open({ name: topicName, replyText: DefaultMessage});
  }).catch(console.error);
};
    loadWidget();
};
