/**
 * Configuration options for initializing the Freshchat widget.
 *
 * @property {string} name - Full name of the employee starting the chat session.
 * @property {number} employeeid - Unique numeric identifier of the employee.
 * @property {string} email - Email address of the employee.
 * @property {boolean} [isMobile] - Whether the session is from a mobile device. Optional.
 * @property {string} [origin] - Source or application from which the chat is initiated. Optional.
 * @property {string} [topicName] - Topic or category name to preselect in the chat. Optional.
 * @property {string} [searchQuery] - Product search query or context message for the initial chat. Optional.
 */
export interface FreshchatInitOptions {
  name: string;
  employeeid: number;
  email: string;
  isMobile?: boolean;
  origin?: string;       
  topicName?: string;
  searchQuery?: string;
}