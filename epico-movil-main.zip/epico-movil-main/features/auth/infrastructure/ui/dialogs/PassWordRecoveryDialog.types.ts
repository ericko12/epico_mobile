/**
 * Interface for the properties of the PasswordRecoveryDialog component.
 *
 * @interface PasswordRecoveryDialogProps
 * @property {boolean} open - Determines whether the dialog is visible or not.
 * @property {() => void} onClose - Callback function triggered to close the dialog.
 * @property {() => void} freshOnClick - Callback function executed to open the FreshChat widget.
 */
export interface PasswordRecoveryDialogProps {
    open: boolean;
    onClose: () => void;
    freshOnClick: () => void;
}