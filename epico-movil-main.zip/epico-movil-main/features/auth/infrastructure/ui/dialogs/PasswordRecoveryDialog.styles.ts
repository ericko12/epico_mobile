import { SxProps } from "@mui/material";

export const centerSX: SxProps = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
}