import {
    Dialog,
    DialogTitle,
    DialogContent,
    Typography,
    Divider,
    DialogActions,
    Button,
    IconButton,
    Box,
} from '@mui/material';
import freschChat from '@/public/img/FreschChat_L-04-04.png';
import CloseIcon from '@mui/icons-material/Close'
import { PasswordRecoveryDialogProps } from './PassWordRecoveryDialog.types';
import { JSX } from 'react';
import { FontWeightEnum } from '@/features/common/domain/enums/FontWeight';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';
import { centerSX } from '@/features/auth/infrastructure/ui/dialogs/PasswordRecoveryDialog.styles';

/**
 * Displays a password recovery dialog with instructions and an option to contact support.
 *
 * @function PasswordRecoveryDialog
 * @param {PasswordRecoveryDialogProps} props - Component properties.
 * @param {boolean} props.open - Whether the dialog is open.
 * @param {function} props.onClose - Callback function to close the dialog.
 * @param {function} props.freshOnClick - Callback function triggered by the "Da clic aquí" button.
 * @returns {JSX.Element} The rendered password recovery dialog component.
 */
const PasswordRecoveryDialog = ({ open, onClose, freshOnClick }: PasswordRecoveryDialogProps): JSX.Element => {
    return (
        <Dialog
            open={open}
            onClose={onClose}
            className="py-5"
            sx={{
                '& .MuiDialog-paper': {
                    width: { xs: 'calc(100% - 32px)', md: '520px' },
                    maxWidth: '100%',
                    height: { xs: 'auto', md: '432px' },
                    borderRadius: '8px',
                    padding: '20px',
                },
            }} >
            <DialogTitle sx={{
                display: 'flex',
                justifyContent: 'space-between',
                alignContent: 'center',
                alignItems: 'center'
            }}>
                <Typography fontWeight={FontWeightEnum.Medium}>RECUPERAR CONTRASEÑA</Typography>
                <IconButton onClick={onClose} size="small">
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <Divider sx={{ my: 2 }} />
                <Typography variant="body2">
                    Antes de que solicites recuperar tu contraseña recuerda que:
                </Typography>
                <Typography variant="body2">
                    El usuario y contraseña es el mismo con el que inicias sesión en los sistemas Exodus
                </Typography>
                <Divider sx={{ my: 2 }} />
                <Typography variant="body2">
                    Para recuperar tu contraseña es necesario levantar un ticket por medio del servicio de soporte Freshchat
                </Typography>
            </DialogContent>
            <Box sx={centerSX}>
                <img alt="FreshChat" src={freschChat.src} height="50px" width="200px" />
            </Box>
            <DialogActions sx={centerSX}>
                <Button size="large" onClick={freshOnClick} sx={{ color: ColorsEpico.ColorGreenLush }}>Da clic aquí</Button>
            </DialogActions>
        </Dialog>
    );
};

export default PasswordRecoveryDialog;
