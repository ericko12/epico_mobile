import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";

/**
 * Genera la URL para obtener objetos de seguridad de un proyecto.
 * 
 * @param {OrigenEnum} originId - El identificador del origen del objeto de seguridad
 * @returns {string} La URL del endpoint con el parámetro originId
 */
export const UrlObjectSecurityProject = (originId: OrigenEnum): string => `/api/v3/Objeto?origenId=${originId}`;