/**
 * Returns the URL to fetch all employees from the Epico API.
 * 
 * @returns {string} The URL for the API endpoint to fetch the list of employees.
 */
export const UrlGetEmployees = (): string => {
    return `/api/v1/user/employees`
}

/**
 * Generates the URL to fetch all subordinates (employees) of a specific user.
 *
 * @function UrlGetSubordinates
 * @param {number} userId - The ID of the user whose subordinates are to be fetched.
 * @returns {string} The API endpoint URL for retrieving the user's subordinates.
 */
export const UrlGetSubordinates = (userId: number): string => {
    return `/api/v1/User/${userId}/employees`;
};

/**
 * Generates the URL to retrieve the authentication token.
 *
 * @function UrlGetAuthentication
 * @returns {string} The API endpoint URL for obtaining the authentication token.
 */
export const UrlGetAuthentication = (): string => {
    return `/api/v1/connect/token`;
};

/**
 * Generates the URL to authenticate an admin user with a third-party system.
 *
 * @function UrlAuthAdminThird
 * @param {number} userId - The ID of the user to authenticate.
 * @returns {string} The API endpoint URL for admin authentication.
 */
export const UrlAuthAdminThird = (userId: number): string => {
    return `/api/v1/user/${userId}/authenticate`;
};