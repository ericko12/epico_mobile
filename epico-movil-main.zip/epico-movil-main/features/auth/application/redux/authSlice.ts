import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { IAuth } from "@/features/auth/domain/interfaces/IAuth";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { INotification } from "@/features/common/domain/interfaces/notification/INotification";
import { TypesNotificationsEnum } from "@/features/common/domain/enums/TypesNotificationsEnum";

// Define the initial state using that type
const initialState: IAuth & { notifications: INotification[] } = {
    userAuth: undefined,
    token: "",
    isLoggedIn: false,
    adminThird: false,
    adminTemporal: 0,
    addProducts: false,
    subscriptionId: undefined,
    notifications: [],
    timePostpone: 0
}

const authSlice = createSlice({
    // key
    name: 'auth',
    // state
    initialState,
    // reducer
    reducers: {
        /**
         * Metodo para almacenar la sesion en un state global y colocar el isLogging en true
         * @param token: string
         */
        setToken: (state: IAuth, action: PayloadAction<string>) => {
            state.token = action.payload;
        },

        /**
         * Metodo para almacenar si se termino el login
         * @param token: string
         */
        setLogged: (state: IAuth, action: PayloadAction<boolean>) => {
            state.isLoggedIn = action.payload;
        },

        /**
        * Metodo para almacenar la sesion en un state global y colocar el isLogging en true
        * @param userSession: IUserDto
        */
        loginUser: (state: IAuth, action: PayloadAction<IUserDto>) => {
            state.userAuth = action.payload;
        },

        /**
         * Metodo para eliminar la sesion del state global y colocar el isLogging en false
         */
        logoutUser: (state: IAuth) => {
            state.isLoggedIn = false;
        },

        /**
        * Metodo para cambiar al modelo tercer persona usando una cuenta. 
        * @param adminThird: boolean
        */
        setThirdAdmin: (state: IAuth, action: PayloadAction<boolean>) => {
            state.adminThird = action.payload;
        },

        /**
        * Metodo para mantener el usuario del admin/third user id
        * @param adminTemporal: number
        */
        setAdminTemporal: (state: IAuth, action: PayloadAction<number>) => {
            state.adminTemporal = action.payload;
        },

        /**
        * Method to set the addProducts permission state
        * @param addProducts: boolean
        */
        setAddProducts: (state: IAuth, action: PayloadAction<boolean>) => {
            state.addProducts = action.payload;
        },

        /**
         * Method to set the engineSMC4 state (profile flag from login).
         * Also activates permissionSMC4 when engineSMC4 is true, to signal the engine was enabled from login.
         * @param engineSMC4: boolean
         */
        setEngineSMC4: (state: IAuth, action: PayloadAction<boolean>) => {
            state.userAuth!.engineSMC4 = action.payload;
        },

        /**
         * Method to set the permissionSMC4 state (user manual toggle preference).
         * @param permissionSMC4: boolean
         */
        setPermissionSMC4: (state: IAuth, action: PayloadAction<boolean>) => {
            state.userAuth!.permissionSMC4 = action.payload;
        },

        /**
         * 
         * method to store the user's subscriptionId
         * @param subscriptionId: string | undefine
         */
        setSubscription: (state: IAuth, action: PayloadAction<string>) => {
            state.subscriptionId = action.payload;
        },

        /**
         * Add or update a notification in the state.
         * If a notification with the same "tipo" already exists, replace it.
         */
        addOrUpdateNotification: (state: IAuth, action: PayloadAction<INotification>) => {
            const index = state.notifications.findIndex(n => n.tipo === action.payload.tipo);
            if (index !== -1) {
                state.notifications[index] = action.payload; // update
            } else {
                state.notifications.push(action.payload); // add new
            }
        },

        /**
         * Sets the postpone time in milliseconds.
         * Calculates a future timestamp by adding the given minutes 
         * to the current time (`Date.now()`).
         */
        setTimePostpone: (state: IAuth, action: PayloadAction<number>) => {
            state.timePostpone = Date.now() + action.payload * 60 * 1000;
        },

        /**
         * Update only the "cuerpo" (payload number) of an existing notification by type.
        */
        updateNotificationBody: (
            state: IAuth,
            action: PayloadAction<{ tipo: string; cuerpo: number }>
        ) => {
            const notif = state.notifications.find(n => n.tipo === action.payload.tipo);
            if (notif) {
                notif.cuerpo = action.payload.cuerpo;
            }
        },

        /**
         * Decreases the notification body count by 1 (min 0) 
         * for the given notification type.
         */
        decrementNotificationBody: (state, action: PayloadAction<{ tipo: TypesNotificationsEnum }>) => {
            const index = state.notifications.findIndex(n => n.tipo === action.payload.tipo);
            if (index !== -1) {

                state.notifications[index].cuerpo = Math.max(0, (state.notifications[index].cuerpo ?? 0) - 1);
            }
        },

    },
});

export const actionsAuth = authSlice.actions;
export default authSlice.reducer;
