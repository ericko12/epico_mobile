import { EPICO_API } from "@/axios/axios_helper";
import { IResponseAxiosDto, IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { UrlAuthAdminThird, UrlGetEmployees, UrlGetSubordinates } from "@/features/auth/infrastructure/api/authUrl";
import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { catchResponse } from "@/features/common/domain/axios/catchResponse";
import { IAuthenticationResponse } from "@/features/auth/domain/interfaces/IAuthenticationResponse";
import { IAuthDto } from "@/features/auth/domain/interfaces/IAuthDto";
import { IEmployeerDto } from "@/features/users/domain/interfaces/IEmployeerDto";


/**
 * System user authentication service
 *
 */
export const authService = () => {
    /**
    * Fetches all employees from the Epico API.
    * 
    * Micro service userEpicoService
    * 
    * @returns {Promise<IResponseDto<IUserDto[] | null>>} A promise that resolves to a response object containing
    * either an array of user data (IUserDto[]) or null in case of an error.
    * 
    * @throws {Error} Throws an error if the API request fails, and the `catchResponse` function handles the error.
    */
    const getAllEmployeesEpico = async (): Promise<IResponseDto<IUserDto[] | null>> => {
        try {
            const response: IResponseAxiosDto<IResponseDto<IUserDto[] | null>> = await EPICO_API.get(UrlGetEmployees());
            return response.data as IResponseDto<IUserDto[] | null>;
        } catch (error) {
            return catchResponse(error);
        }
    }

    /**
     * Fetches all subordinates (employees) of a specific user from the Epico API.
     * 
     * Micro service userEpicoService
     * 
     * @param {number} userId - The ID of the user whose subordinates are to be fetched.
     * @returns {Promise<IResponseDto<IEmployeerDto[] | null>>} A promise that resolves to a response object containing
     * either an array of user data (IEmployeerDto[]) or null in case of an error.
     * 
     * @throws {Error} Throws an error if the API request fails, and the `catchResponse` function handles the error.
     */
    const getAllSubordinatesEpico = async (userId: number): Promise<IResponseDto<IEmployeerDto[] | null>> => {
        try {
            const response: IResponseAxiosDto<IResponseDto<IEmployeerDto[] | null>> = await EPICO_API.get(UrlGetSubordinates(userId));
            return response.data as IResponseDto<IEmployeerDto[] | null>;
        } catch (error) {
            return catchResponse(error);
        }
    }


    /**
     * Metodo para autenticar un usuario mediante el IDS4
     * 
     * Micro service userEpicoService
     * 
     * @param auth: IAuthDto
     * @returns IResponseDTO
     */
    const getAuthentication = async (auth: IAuthDto): Promise<IResponseDto<IAuthenticationResponse | null>> => {
        try {
            const response = await fetch("/api/auth/ids4", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                credentials: "include",
                body: JSON.stringify({
                    user: auth.user || "",
                    password: auth.password || "",
                }),
            });

            const data = await response.json();
            return data as IResponseDto<IAuthenticationResponse | null>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
         * Funcion que valida si el usuario y contraseña son correctos y te retorna los datos de session
         * 
         * Micro service userEpicoService
         *
         * @param IAuthDto
         * @returns  {Promise<IResponseDto<IUserDto|null>>}
         */
    const getAuthSessionByUser = async (userId: number): Promise<IResponseDto<IUserDto | null>> => {

        const response: IResponseDto<IUserDto> = await EPICO_API.get(UrlAuthAdminThird(userId)).then(({ data }) => {
            return data
        }).catch(error => catchResponse(error));

        return response
    }

    return {
        getAllEmployeesEpico,
        getAllSubordinatesEpico,
        getAuthentication,
        getAuthSessionByUser
    }
}
