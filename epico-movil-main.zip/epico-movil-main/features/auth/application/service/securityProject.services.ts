import { EPICO_API } from "@/axios/axios_helper";
import { handleRequest } from "@/features/common/infrastructure/api/handleRequest";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { UrlObjectSecurityProject } from "@/features/auth/infrastructure/api/securityProjectUrl";
import { ObjectResponse } from "@/features/auth/domain/interfaces/securityProject/objectResponse";


/**
 * Service for managing security-related operations for projects.
 * 
 * @returns {Object} An object containing methods for project security operations.
 */
export const securityProjectService = () => ({
    /**
     * Retrieves the list of project security objects based on the given origin.
     *
     * @param {OrigenEnum} originId - Identifier of the origin from which the objects are retrieved.
     * @returns {Promise<ObjectResponse[]>} A promise that resolves with the list of retrieved objects.
     */
    getObject: (originId: OrigenEnum) => {
        return handleRequest<ObjectResponse[]>(EPICO_API.get(UrlObjectSecurityProject(originId)))
    }
})


export type ApiTypeSecurityProject = ReturnType<typeof securityProjectService>;