"use client";

import { ISeller } from "@/features/seller/domain/interface/ISeller";
import getSellersData from "@/features/seller/application/actions/getSellersData";
import dayjs from "dayjs";
import { TypeRoleEnum } from "@/features/roles/domain/enum/TypeRoleEnum";
import { encodeBase64WithKey } from "@/features/common/infrastructure/utils/encodeAndDecode";
import { rolesServices } from '@/features/roles/application/service/roles.services';
import { IAuthDto } from "@/features/auth/domain/interfaces/IAuthDto";
import { authService } from "@/features/auth/application/service/auth.services";
import { FormLoginState, loginSchema } from "@/features/auth/application/loginSchema";
import { securityProjectService } from "@/features/auth/application/service/securityProject.services";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { ObjectResponse } from "@/features/auth/domain/interfaces/securityProject/objectResponse";
import { EngineSMCEnum } from "@/features/auth/domain/enums/securityProject/EngineSMCEnum";

/**
 * Authenticate a user using their credentials.
 *
 * @async
 * @function handleAuthentication
 * @param {IAuthDto} auth - Object containing authentication credentials (username and password).
 * @returns {Promise<{ success: boolean; message?: string; userAuth?: unknown }>}
 * An object indicating whether authentication was successful, an error message if applicable, and information about the authenticated user.
 */
const handleAuthentication = async (auth: IAuthDto) => {
    const { getAuthentication, getAuthSessionByUser } = authService();

    const response = await getAuthentication(auth);
    if (response.data === null || response.huboError) {
        return { success: false, message: response.error.mensaje };
    }

    const userId: number = response.data.userId || 0;

    const responseAuth = await getAuthSessionByUser(userId);
    if (responseAuth.data === null || responseAuth.huboError) {
        return { success: false, message: responseAuth.error.mensaje };
    }

    return { success: true, userAuth: responseAuth.data };
};

/**
 * Gets the modules and functionalities associated with a specific role and stores them in localStorage.
 *
 * @async
 * @function handleRoleModules
 * @param {number} roleId - User role identifier.
 * @param {number} roleTypeId - User role type.
 * @returns {Promise<{ success: boolean; message?: string }>} 
 * An object indicating whether the operation was successful and an error message if applicable.
 */
const handleRoleModules = async (roleId: number, roleTypeId: number) => {

    const { getModulesAndFunctionalitiesByIdRole } = rolesServices();
    const responseRole = await getModulesAndFunctionalitiesByIdRole(roleId);

    if (responseRole.data !== null && responseRole.huboError === false) {
        localStorage.setItem(
            "Epico_MR",
            encodeBase64WithKey(JSON.stringify({ moduleRole: responseRole.data, roleId, roleTypeId }))
        );
    } else {
        return { success: false, message: responseRole.error.mensaje };
    }

    return { success: true, data: responseRole.data };
};

/**
 * Retrieves security objects from the project and filters for SMC4 engine objects.
 * 
 * @returns {Promise<ResponseObject>} A promise that resolves to an object
 */
const handleGetObjects = async () => {
    const { getObject } = securityProjectService();
    const response = await getObject(OrigenEnum.Epico);

    interface ResponseObject {
        success: boolean;
        message: string;
        data?: ObjectResponse;
    }

    const responseObject = await handleRequestDto<ObjectResponse[] | null, ResponseObject>({
        response,
        onSuccess: () => {
            const objectSMC4 = response.data?.filter(obj => obj.objeto.includes(EngineSMCEnum.SMC4)) || [];
            return { success: !!objectSMC4.length, data: !!objectSMC4.length ? objectSMC4 : undefined };
        },
        onInvalid: () => ({ success: false, message: "Error al obtener los objetos de seguridad del proyecto." }),
        onError: () => ({ success: false, message: "Error al obtener los objetos de seguridad del proyecto." }),
    }) || { success: false, message: "Error al obtener los objetos de seguridad del proyecto." };
    return responseObject;
}

/**
 * Handles the process of logging in a user, validating credentials, authenticating, obtaining user data, and configuring roles.
 *
 * @async
 * @function signup
 * @param {FormLoginState} state - Initial state of the login form.
 * @param {FormData} formData - Form data submitted by the user.
 * @returns {Promise<FormLoginState>} 
 * Updated status of the form with the corresponding responses, errors and messages.
 */
export const signup = async (_state: FormLoginState, formData: FormData): Promise<FormLoginState> => {
    const auth: IAuthDto = {
        user: formData.get("user")?.toString(),
        password: formData.get("password")?.toString(),
    };

    const validatedFields = loginSchema.safeParse(auth);
    if (!validatedFields.success) {
        return { values: auth, errors: validatedFields.error.flatten().fieldErrors };
    }

    try {
        const authResult = await handleAuthentication(auth);
        const ObjectResult = await handleGetObjects();

        if (!authResult.success) {
            return { values: auth, message: authResult.message, messageKey: (_state?.messageKey ?? 0) + 1 };
        }

        const userAuth = authResult.userAuth;

        const sellersList: ISeller[] = await getSellersData(userAuth!.userTypeId, userAuth!.employeeId);
        const expirationDate = dayjs().add(5, "minutes");

        const { roleId, roleTypeId } = userAuth!;
        const roleModulesResult = await handleRoleModules(roleId, roleTypeId);


        if (!roleModulesResult.success) {
            return { values: auth, message: roleModulesResult.message, messageKey: (_state?.messageKey ?? 0) + 1 };
        }

        const newState: FormLoginState = { responses: { userAuth: userAuth!, permissions: roleModulesResult.data! } };
        newState.values = auth;
        newState.responses!.expirationDate = expirationDate.toDate();
        newState.responses!.sellerList = sellersList;
        newState.objects = ObjectResult.success ? [ObjectResult!.data!] : [];


        if (roleTypeId === TypeRoleEnum.Administrador) {
            newState.responses!.adminTemporal = userAuth!.userId;
        }
        return newState;
    } catch (_error) {
        return { values: auth, message: "Error al iniciar sesión", messageKey: (_state?.messageKey ?? 0) + 1 };
    }
};
