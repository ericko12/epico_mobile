import { IModulesAndFunctionalities } from "@/features/roles/domain/interfaces/IModulesAndFunctionalities";
import { ISeller } from "@/features/seller/domain/interface/ISeller";
import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { z } from "zod";
import { ObjectResponse } from "@/features/auth/domain/interfaces/securityProject/objectResponse";

export const loginSchema = z.object({
  user: z.string().nonempty("Ingrese su usuario por favor."),
  password: z.string().nonempty("Ingrese su contraseña por favor."),
});

export type FormLoginState =
  | {
    values?: {
      user?: string
      password?: string
    }
    errors?: {
      user?: string[]
      password?: string[]
    }
    message?: string
    messageKey?: number
    responses?: {
      userAuth: IUserDto
      sellerList?: ISeller[]
      expirationDate?: Date
      adminTemporal?: number
      permissions: IModulesAndFunctionalities[];
    },
    objects?: ObjectResponse[];
  }
  | undefined