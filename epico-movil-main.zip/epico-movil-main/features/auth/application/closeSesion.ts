
import { unsubscribeUserFromPushNotification } from '@/features/common/infrastructure/hooks/unsubscribeUserFromPushNotification';
import Cookies from 'js-cookie';

/**
 * Función para remover cookies y datos de la sessión
 */
export const closeSession = async (validToken = true) => {
    try {
        await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
        if (validToken) {
            const subscriptionId = Cookies.get('subscriptionId');
            await unsubscribeUserFromPushNotification(subscriptionId);
        }
    } catch (error) {
        console.error("❌ Error closing session (unsubscribe):", error);
    } finally {
        Cookies.remove('subscriptionId');
        localStorage.clear();
        sessionStorage.clear();

    }


}
