import { EngineDivisionEnum } from "@/features/checkout/domain/enums/EngineDivisionEnum";
import { getCustomerByCustomerSellerIdRow } from "@/features/customer/application/actions/db/CustomersRepository";
import { customerService } from "@/features/customer/application/service/customer.services";

/**
 * Determines the engine division for a customer based on their seller ID and engine configuration.
 * 
 * @param customerSellerId - The unique identifier of the customer seller
 * @param engineSMC4 - Boolean flag indicating if SMC4 engine is enabled
 * @returns A promise that resolves to the appropriate EngineDivisionEnum value
 */
export const determineEngineDivision = async (customerSellerId: number, engineSMC4: boolean): Promise<EngineDivisionEnum> => {
    const { getCustomerApplySMC } = customerService();
    let flagEngineUP = EngineDivisionEnum.SMC4;

    if (!engineSMC4) {
        let applieSMC = false;
        let customer = await getCustomerByCustomerSellerIdRow(customerSellerId);
        if (!customer) {
            const response = await getCustomerApplySMC(customerSellerId);
            if (response && response.data) {
                applieSMC = response.data.aplica;
            }
        }

        if (customer && customer.AplicaClienteSMC) {
            applieSMC = true
        }
        flagEngineUP = applieSMC ? EngineDivisionEnum.SMC3 : EngineDivisionEnum.NOT_DIVISION;
    }

    return flagEngineUP;
}