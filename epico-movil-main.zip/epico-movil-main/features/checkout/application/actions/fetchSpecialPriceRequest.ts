
import { AlertColor } from "@mui/material";
import { AnyAction, Dispatch, ThunkDispatch } from "@reduxjs/toolkit";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { ICustomer } from "@/features/customer/domain/interface/ICustomer";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { SpecialPriceService } from "@/features/checkout/application/service/specialPrice.services";
import { ISpecialPriceRequest } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceRequest";
import { fetchCustomerIndexDB } from "@/features/customer/application/actions/db/CustomersRepository";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { IRequestForSpecialPriceResponse } from "@/features/checkout/domain/interfaces/specialPrice/IRequestForSpecialPriceResponse";
import { updateOrderSummaryThunk } from "@/features/checkout/application/redux/checkOutThunks";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { fetchAndUpdateOrderSummary } from "@/features/orders/application/actions/fetchAndUpdateOrderSummary";
/**
 * Requests a special price for an order detail and updates the order summary.
 * This function handles the process of requesting a special price for a product in an order.
 * It validates the user authentication and current special price status before proceeding.
 * If valid, it creates a special price request with the customer and product details,
 * sends it to the backend service, and updates the order summary with the new special price status.
 *
 * @async
 * @function fetchSpecialPriceRequest
 * @param {IOrderSummaryDetail} pedidoDetalle - The order detail for which the special price is being requested
 * @param {number} price - The requested special price for the product
 * @param {string} comment - Comments or justification for the special price request
 * @param {IOrderSummary} orderSummary - The order summary containing the order details
 * @param {IUserDto} userAuth - The authenticated user's information
 * @param {function(string, AlertColor=): void} showSnackbar - Function to display snackbar notifications
 * @param {ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>} dispatch - Redux dispatch function
 * @param {number} [historyId] - (Optional) ID referencing the order history for tracking changes or previous requests
 * @returns {Promise<void>} Promise that resolves when the special price request is complete
 * @throws Will throw an error if the request fails or validation checks don't pass
 */


export const fetchSpecialPriceRequest = async (
    pedidoDetalle: IOrderSummaryDetail,
    price: number,
    comment: string,
    orderSummary: IOrderSummary,
    userAuth: IUserDto,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>,
    historyId?: number,
    nameCompetitor?: string,
    brandCompetitor?: string
): Promise<void> => {

    const { postSpecialPriceRequest } = SpecialPriceService();
    if (userAuth?.userId === undefined) return;

    if (pedidoDetalle.estatusPrecioEspecialId !== SpecialPriceStates.SinSolicitud.index) return;

    if (orderSummary?.detalles && orderSummary.detalles.length > 0) {
        const customerIndexDB: ICustomer = await fetchCustomerIndexDB(orderSummary.clienteId);

        const reqData: ISpecialPriceRequest = {
            clienteId: orderSummary.clienteId,
            infoSucursalId: customerIndexDB.sucursalId || 0,
            precioLista: pedidoDetalle.precio,
            precioSolicitado: +price,
            cantidadPiezas: pedidoDetalle.cantidad,
            empleadoIdSolicitante: userAuth.employeeId,
            comentarioSolicitud: comment,
            producto: pedidoDetalle?.producto || "",
            pedidoId: pedidoDetalle.pedidoID,
            pedidoDetalleId: pedidoDetalle.pedidoDetalleId,
            origenId: OrigenEnum.Epico,
            historialId: historyId,
            nombreCompetidor: nameCompetitor?.trim() === '' ? undefined :  nameCompetitor?.trim(),
            marcaCompetidor: brandCompetitor?.trim() === '' ? undefined :  brandCompetitor?.trim()
        };

        const resSpecialPrice: IResponseDto<IRequestForSpecialPriceResponse | null> = await postSpecialPriceRequest(reqData);

        if (resSpecialPrice.data) {
            const updatedOrderSummary: IOrderSummary = {
                ...orderSummary,
                detalles: orderSummary.detalles.map(detalle =>
                    detalle.pedidoDetalleId === pedidoDetalle.pedidoDetalleId
                        ? {
                            ...detalle,
                            estatusPrecioEspecialId: SpecialPriceStates.Solicitado.index,
                            precioEspecialId: resSpecialPrice.data!.precioEspecialId,
                            cantidadPrecioEspecial: pedidoDetalle.cantidad,
                            cantidad: pedidoDetalle.cantidad,
                            tieneToken: true
                        }
                        : detalle
                ),
            };

            await dispatch(updateOrderSummaryThunk(updatedOrderSummary));
            await fetchAndUpdateOrderSummary(false, updatedOrderSummary, showSnackbar, dispatch, historyId);
            showSnackbar(NOTIFICATIONS_CHECKOUT.SPECIAL_PRICE.REQUEST_SUCCESS, "success");

        } else {
            showSnackbar(NOTIFICATIONS_CHECKOUT.GENERAL.ERROR, "error");
        }
    }
};
