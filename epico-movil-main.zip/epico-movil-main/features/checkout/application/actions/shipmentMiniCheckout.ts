import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";

/**
 * Check if the order status indicates it has been shipped.
 *
 * @param {StatusOrderEnum} statusOrder - The status of the order to check.
 * @returns {boolean} True if the order status is 'EnviadoSMC', false otherwise.
 */
export const shipmentMiniCheckout = (statusOrder: StatusOrderEnum): boolean => statusOrder === StatusOrderEnum.EnviadoSMC;

/**
 * Determines if the mini checkout shipment process should end based on the order status.
 * 
 * @param {StatusOrderEnum} statusOrder - The current status of the order.
 * @returns {boolean} Returns true if the order status is "Retenido" (Retained), false otherwise.
 */
export const shipmentEndMiniCheckout = (statusOrder: StatusOrderEnum): boolean => statusOrder === StatusOrderEnum.Retenido;
