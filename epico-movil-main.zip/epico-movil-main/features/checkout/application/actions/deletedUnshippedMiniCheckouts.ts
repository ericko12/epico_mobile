import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { AlertColor } from "@mui/material";
import { SMCService } from "@/features/checkout/application/service/smc.services";


/**
 * Handle unshipped minicheckouts.
 *
 * @async
 * @param {number} pedidoID - The ID of the order to delete unshipped checkouts for.
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Function to display notifications.
 * @param {() => Promise<void>} onSuccess - Callback to run on successful deletion.
 * @param {?boolean | null} kmsApplied - Boolean indicating if the order contains any kms points (optional)
 * @returns {Promise<void>} Resolves when the operation completes.
 */
export const DeleteUnshippedMiniCheckouts = async (
    pedidoID: number,
    showSnackbar: (message: string, type?: AlertColor) => void,
    onSuccess: () => Promise<void>,
    kmsApplied?: boolean | null,
) => {
    const { DeleteUnshippedCheckouts } = SMCService();
     const responseUnshipped = await DeleteUnshippedCheckouts(pedidoID,kmsApplied);
    await handleRequestDto({
        snackBar: showSnackbar,
        response: responseUnshipped,
        messages: {
            error: 'Error al eliminar las mini cajas',
            invalid: 'Error al eliminar las mini cajas'
        },
        onSuccess: onSuccess,
    });
}