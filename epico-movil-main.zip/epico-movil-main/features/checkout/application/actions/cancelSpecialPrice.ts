import { PatchOrderSummaryDetailsEnum } from "@/features/checkout/domain/enums/OrderSummaryDetailsEnum";
import { updateSpecialPrice } from '@/features/checkout/application/actions/updateSpecialPrice';
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { AlertColor } from "@mui/material";
import { AnyAction, Dispatch, ThunkDispatch } from "@reduxjs/toolkit";
import { updateOrderDetail } from "@/features/orders/application/actions/updateOrderDetail";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";

/**
 * Cancels a special price in the database and updates the Redux store.
 * 
 * This function handles the cancellation of special prices by:
 * - Updating the special price status in the database to 'Cancelled'
 * - Updating the order detail in Redux to remove special price references
 * - Resetting price-related fields to their default/list values
 * - Maintaining proper state synchronization between DB and Redux
 *
 * @async
 * @function cancelSpecialPrice
 * @param {IOrderSummary} orderSummary - The current order summary containing all order details
 * @param {MutableRefObject<IOrderSummary | null>} newOrderSummaryRef - Mutable reference to the new order summary
 * @param {number} employeeId - ID of the employee executing the cancellation
 * @param {IOrderSummaryDetail} newDetailState - New state for the order summary detail
 * @param {number} newCount - New quantity for the order detail
 * @param {function(string, AlertColor=): void} showSnackbar - Function to display snackbar notifications
 * @param {ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>} dispatch - Redux dispatch function
 * @param {number} [historyId] - (Optional) ID referencing the order history for tracking changes or previous requests
 * @returns {Promise<{ pedidoDetalleId: number, newDetail: IOrderSummaryDetail }>} Object containing the updated order detail ID and new detail state
 * @throws Will throw an error if the special price cancellation or order detail update fails
 */
export const cancelSpecialPrice = async (
    orderSummary: IOrderSummary,
    employeeId: number,
    newDetailState: IOrderSummaryDetail,
    newCount: number,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>,
    historyId?: number
): Promise<{ pedidoDetalleId: number, newDetail: IOrderSummaryDetail }> => {
    // Updates the special price status in the database
    await updateSpecialPrice(
        newDetailState.precioEspecialId,
        orderSummary,
        [
            { name: PatchOrderSummaryDetailsEnum.empleadoIDEjecuto, data: employeeId },
            { name: PatchOrderSummaryDetailsEnum.estatusPreciosEspecialesId, data: SpecialPriceStates.Cancelado.index },
        ],
        showSnackbar
    );

    // Updates the order detail in Redux store and database by:
    // - Removing special price ID reference (set to null)
    // - Disabling token flag since special price is cancelled
    // - Resetting price back to original list price
    await updateOrderDetail(
        newDetailState.pedidoDetalleId, // ID of order detail to update
        orderSummary, // Current order summary containing all details
        [
            { name: PatchOrderSummaryDetailsEnum.precioEspecialId, data: null }, // Remove special price reference
            { name: PatchOrderSummaryDetailsEnum.tieneToken, data: false }, // Disable token flag
            { name: PatchOrderSummaryDetailsEnum.precio, data: newDetailState.precioLista }, // Reset to list price
        ],
        showSnackbar, // Function to display status notifications
        dispatch, // Redux dispatch to update store
        false, // Flag to indicate this is not a package update
        historyId
    );

    // Prepares the new detail state with updated values
    const { pedidoDetalleId } = newDetailState;
    const newDetail: IOrderSummaryDetail = {
        ...newDetailState,
        cantidad: newCount,
        estatusPrecioEspecialId: SpecialPriceStates.SinSolicitud.index,
        precioMinimoSugeridoParaToken: 0,
        precioSolicitado: 0,
        comentarioEjecuto: "",
        cantidadPrecioEspecial: 0,
        precio: newDetailState.precioLista,
    };

    return { pedidoDetalleId, newDetail };
};
