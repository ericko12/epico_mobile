import { IMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckout";
import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";
import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { IGetPayment } from "@/features/checkout/domain/interfaces/IGetPayment";
import { ISendMiniCheckoutRequest } from "@/features/checkout/domain/interfaces/smc/ISendMiniCheckoutRequest";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { ShippingTypeEnum } from "@/features/checkout/domain/enums/ShippingTypeEnum";
import { ShippingMethodEnum } from "@/features/shipment/domain/enum/ShippingMethodEnum";
import { SplitBill } from "@/features/common/domain/enums/SplitBill";
import { DeliveryServiceEnum } from "@/features/shipment/domain/enum/DeliveryServiceEnum";
import { IShippingPreferenceRequest } from "@/features/shipment/domain/interfaces/IShippingPreferenceRequest";
import { IShippingPreference } from "@/features/shipment/domain/interfaces/IShippingPreference";


/**
 * Concatenates order comments, retention comments and shipping type with specific length limits.
 * 
 * @param {string} pedido - Order comments or observations
 * @param {string} retenciones - Retention comments or notes
 * @param {string} auxEnvio - Shipping type (complete or partial)
 * @param {number} [maxLength=250] - Maximum allowed characters (defaults to 250)
 * @param {string} [separator=' | '] - Character(s) used to separate text segments
 * 
 * @returns {string} The concatenated comment string respecting the max length
 * 
 * @throws {Error} If the resulting concatenated comment exceeds maxLength
 */
export const concatenateComments = (
    pedido: string,
    retenciones: string,
    auxEnvio: string,
    maxLength: number = 250,
    separator: string = ' | '
): string => {
    const commentAux = `${(retenciones.length && (pedido.length || auxEnvio.length)) ? separator : ''}${retenciones}`
    const newMaxLength = (maxLength - (commentAux.length + auxEnvio.length + 29)) >= 0 ? (maxLength - (commentAux.length + auxEnvio.length + 28)) : 0
    let finalComment = `${auxEnvio}${pedido.trimEnd().slice(0, newMaxLength)}${commentAux}`

    finalComment = finalComment.slice(0, maxLength);

    if (finalComment.length > maxLength)
        throw new Error("El comentario es demasiado largo. Intenta resumirlo para poder guardarlo.");

    return finalComment;
}

/**
 * Maps the provided order shipment details to a mini checkout request for shipment processing.
 * This function handles the construction of the request payload using order shipment information,
 * checkout details, user authentication, and optional purchase order information.
 * 
 * @param {IOrderShipment} orderShipment - Order shipment data containing:
 * - pedidoID: Order ID
 * - DireccionEntregaId: Delivery address ID
 * - MetodoEnvio: Shipping method (home delivery or other)
 * - PaqueteriaId: Courier service ID for home delivery
 * - consecion.plazo: Payment term in days
 * - Retenciones.observacion: Tax retention notes
 * 
 * @param {IOrderShipment} ord - Additional order shipment details including:
 * - Comentarios: Order comments
 * - TipoEnvio: Shipping type (partial/complete)
 * - PorteId: Shipping type ID
 * - EnviarPaqueteria.DireccionPaqueteriaId: Courier address ID
 * - PaqueteriaId: Courier service ID (if not home delivery)
 * - ServicioEntrega: Delivery service ID
 * - HandHeld: Whether to use handheld device
 * - Split: Split billing configuration
 * - cantidad: Payment amount (for cash payments)
 * - PersonaRecogera: Pickup person name (for in-store pickup)
 * 
 * @param {Readonly<IMiniCheckout>} checkoutInfo - Mini checkout details:
 * - miniCajaID: Mini checkout box ID
 * - total: Total order amount
 * - infoSucursalID: Branch ID
 * - tipoServicioSucursalID: Branch service type ID
 * 
 * @param {IOrderSummary} selectedOrderSummary - Order summary containing:
 * - clienteVendedorId: Customer vendor ID
 * 
 * @param {IUserDto} userAuth - User authentication data:
 * - userId: Authenticated user ID
 * 
 * @param {string} purchaseOrder - Purchase order number
 * 
 * @param {IGetPayment} paymentMethodId - Payment method details:
 * - id: Payment method ID
 * - concessionId: Concession ID
 * - forcePue: Whether to force single exhibition payment
 * 
 * @returns {ISendMiniCheckoutRequest} Mini checkout request object containing all the mapped fields
 * from the input parameters, including order details, shipping preferences, payment information,
 * and any conditional fields based on payment method or delivery service.
 */
export const mapToAddressRequest = (
    orderShipment: IOrderShipment,
    ord: IOrderShipment,
    checkoutInfo: Readonly<IMiniCheckout>,
    selectedOrderSummary: IOrderSummary,
    userAuth: IUserDto,
    purchaseOrder: string,
    paymentMethodId: IGetPayment,
    hasFormat: boolean
): ISendMiniCheckoutRequest => {
    const finalComment: string = concatenateComments(
        ord.Comentarios ?? '',
        orderShipment?.Retenciones?.observacion ?? '',
        ord.TipoEnvio === ShippingTypeEnum.Parcial ? `#${ShippingTypeEnum.Parcial}# ` : ''
    );
    const newRequest: ISendMiniCheckoutRequest = {
        pedidoLlamadaId: orderShipment?.pedidoID ?? 0,
        miniCajaId: checkoutInfo.miniCajaID,
        concesionId: paymentMethodId.concessionId,
        clienteVendedorId: selectedOrderSummary?.clienteVendedorId ?? 0,
        origenId: OrigenEnum.Epico,
        origenIDSMC: OrigenEnum.Epico,
        importeTotalPedido: checkoutInfo.total,
        usuarioId: userAuth?.userId ?? 0,
        porteId: ord?.PorteId ?? 0,
        direccionPaqueteriaId: ord?.EnviarPaqueteria?.DireccionPaqueteriaId ?? undefined,
        sucursalId: checkoutInfo?.infoSucursalID ?? 0,
        paqueteriaId: orderShipment?.MetodoEnvio === ShippingMethodEnum.Domicilio ? orderShipment.PaqueteriaId : ord.PaqueteriaId,
        servicioEntregaId: ord.ServicioEntrega,
        observaciones: finalComment,
        envioHandHeld: ord?.HandHeld ?? false,
        dividirPedido: ord?.Split ?? SplitBill.none,
        direccionid: orderShipment.DireccionEntregaId,
        metodoPagoId: paymentMethodId.id,
        pue: paymentMethodId.forcePue,
        plazo: orderShipment.consecion?.plazo ?? 0,
        TipoServicioEntregaId: checkoutInfo.tipoServicioSucursalID,
        ...(!!purchaseOrder && { ordenCompra: purchaseOrder }),
        ...((paymentMethodId.id === 1 && ord.cantidad) && {
            cantidadPagara: ord?.cantidad ?? undefined,
        }),
        ...(ord.ServicioEntrega === DeliveryServiceEnum.Ocurre && {
            personaRecogera: ord?.PersonaRecogera ?? undefined
        }),
        HasFormat: hasFormat
    }
    return newRequest;
}

/**
 * Maps the provided order shipment details to a mini checkout request for branch shipment processing.
 * This function constructs the request payload for branch-specific shipment handling, 
 * including order shipment details, checkout information, user authentication, and optional purchase order details.
 *
 * @param {IOrderShipment} orderShipment - The main order shipment data, including details about 
 *                                         the shipment, packaging, and delivery.
 * @param {IOrderShipment} ord - A second order shipment, typically used to fetch additional 
 *                               details such as comments, delivery type, and other attributes.
 * @param {Readonly<IMiniCheckout>} checkoutInfo - Information related to the mini checkout process,
 *                                                 such as total amounts, mini box ID, and branch information.
 * @param {IOrderSummary} selectedOrderSummary - The summary data for the selected order, including 
 *                                              customer vendor ID and other order-related information.
 * @param {IUserDto} userAuth - The authenticated user data, used to capture the user ID for the request.
 * @param {string} purchaseOrder - The purchase order identifier. If provided, this will be included 
 *                                 in the request, otherwise the field may be left empty or omitted.
 * @param {IGetPayment} paymentMethodId - customer payment method
 *
 * @returns {ISendMiniCheckoutRequest} Returns an object that represents the structured mini checkout 
 *                                    request for branch shipment processing, including order shipment details,
 *                                    checkout information, and additional fields based on the input parameters.
 */
export const mapToBranchRequest = (
    orderShipment: IOrderShipment,
    ord: IOrderShipment,
    checkoutInfo: Readonly<IMiniCheckout>,
    selectedOrderSummary: IOrderSummary,
    userAuth: IUserDto,
    purchaseOrder: string,
    paymentMethodId: IGetPayment,
    hasFormat: boolean
): ISendMiniCheckoutRequest => {
    const finalComment: string = concatenateComments(
        ord.Comentarios ?? '',
        orderShipment?.Retenciones?.observacion ?? '',
        ord.TipoEnvio === ShippingTypeEnum.Parcial ? `#${ShippingTypeEnum.Parcial}# ` : ''
    );

    const newRequest: ISendMiniCheckoutRequest = {
        pedidoLlamadaId: orderShipment?.pedidoID ?? 0,
        miniCajaId: checkoutInfo.miniCajaID,
        concesionId: paymentMethodId.concessionId,
        clienteVendedorId: selectedOrderSummary?.clienteVendedorId ?? 0,
        origenId: OrigenEnum.Epico,
        origenIDSMC: OrigenEnum.Epico,
        importeTotalPedido: checkoutInfo.total,
        usuarioId: userAuth?.userId ?? 0,
        porteId: ord?.PorteId ?? 0,
        sucursalId: checkoutInfo?.infoSucursalID ?? 0,
        observaciones: finalComment,
        dividirPedido: ord?.Split ?? SplitBill.none,
        tiempoRecogera: ord?.TiempoRecogera,
        pickUp: paymentMethodId.forcePickup ? true : ord?.PickUp ?? false,
        personaRecogera: ord?.PersonaRecogera,
        metodoPagoId: paymentMethodId.id,
        pue: paymentMethodId.forcePue,
        plazo: orderShipment.consecion?.plazo ?? 0,
        ...(!!purchaseOrder && { ordenCompra: purchaseOrder }),
        HasFormat: hasFormat
    }
    return newRequest;
}

/**
 * Maps the provided order shipment details to a shipping preference request for branch shipment processing.
 * This function constructs the request payload for the shipping preference, including the order shipment details, 
 * payment information, delivery address, and other relevant order attributes.
 *
 * @param {IOrderShipment} orderShipment - The main order shipment data, including details about the shipment, 
 *                                         payment, and delivery.
 * @param {string} purchaseOrder - The purchase order identifier. If provided, it will be included in the request; 
 *                                 otherwise, the field may be left empty.
 * 
 * @returns {shippingPreferenceRequest} Returns an object representing the shipping preference request, 
 *                                      structured with order shipment details, payment information, 
 *                                      and other fields based on the input parameters.
 */
export const mapOrderShipmentToRequest = (
    orderShipment: IOrderShipment,
    purchaseOrder: string
) => {
    const newRequest: IShippingPreferenceRequest = {
        concesionId: orderShipment?.consecion?.concesionId,
        concesion: orderShipment?.consecion?.concesion!,
        plazo: orderShipment?.consecion?.plazo!,
        metodoPagoId: orderShipment.FormaPago?.metodoPagoId,
        metodoPago: orderShipment.FormaPago?.metodoPago ?? '',
        pue: orderShipment.PUE,
        observaciones: orderShipment?.Comentarios ?? '',
        porteId: orderShipment.PorteId,
        cantidadPagara: orderShipment.cantidad ?? '',
        personaRecogera: orderShipment.PersonaRecogera ?? '',
        tipoPersonaRecogera: orderShipment.TipoPersonaRecogera ?? '',
        tiempoRecogera: orderShipment.TiempoRecogera ?? '',
        pickup: orderShipment.PickUp,
        direccionId: orderShipment.DireccionEntregaId,
        paqueteriaId: orderShipment.PaqueteriaId,
        surtidoHandheld: orderShipment.HandHeld,
        servicioEntregaId: orderShipment.ServicioEntrega,
        dividirPedido: orderShipment.Split,
        ordenCompra: purchaseOrder,
        envioDireccion: orderShipment.MetodoEnvio === ShippingMethodEnum.Domicilio,
        sucursalEnviaId: orderShipment.SucursalEnviaId,
        tipoEnvio: orderShipment.TipoEnvio ?? ShippingTypeEnum.Completo,
        direccionPaqueteriaId: orderShipment?.EnviarPaqueteria?.DireccionPaqueteriaId,
        retencion: orderShipment.Retenciones?.observacion ?? ''
    }
    return newRequest;
}

/**
 * Maps the provided shipping preference to an order shipment object.
 * This function converts the shipping preference data into the corresponding order shipment details,
 * including payment method, shipping method, delivery address, and additional shipment information.
 *
 * @param {shippingPreference} shippingPreference - The shipping preference data containing various attributes 
 *                                                such as payment method, shipping details, and delivery preferences.
 * 
 * @returns {IOrderShipment} Returns an object representing the structured order shipment, 
 *                           with the fields derived from the provided shipping preference.
 */
export const mapPreferenceToOrderShipment = (
    shippingPreference: IShippingPreference
) => {
    const newRequest: IOrderShipment = {
        pedidoID: shippingPreference.pedidoId,
        consecion: {
            concesionId: shippingPreference.concesionId ?? 0,
            concesion: shippingPreference.concesion,
            plazo: shippingPreference.plazo ?? 0,
            status: true,
        },
        PUE: shippingPreference.pue,
        FormaPagoId: shippingPreference.metodoPagoId,
        FormaPago: {
            metodoPagoId: shippingPreference.metodoPagoId ?? 0,
            metodoPago: shippingPreference.metodoPago,
            status: true
        },
        MetodoEnvio: shippingPreference.envioDireccion ? ShippingMethodEnum.Domicilio : ShippingMethodEnum.Sucursal,
        DireccionEntregaId: shippingPreference.direccionId,
        SucursalEnviaId: shippingPreference.sucursalEnviaId,
        PorteId: shippingPreference.porteId,
        ServicioEntrega: shippingPreference.servicioEntregaId,
        cantidad: shippingPreference.cantidadPagara,
        PersonaRecogera: shippingPreference.personaRecogera,
        HandHeld: shippingPreference.surtidoHandheld,
        TipoEnvio: shippingPreference.tipoEnvio === ShippingTypeEnum.Completo ? ShippingTypeEnum.Completo : ShippingTypeEnum.Parcial,
        PaqueteriaId: shippingPreference.paqueteriaId,
        EnviarPaqueteria: {
            active: !!shippingPreference.direccionPaqueteriaId,
            DireccionPaqueteriaId: shippingPreference.direccionPaqueteriaId ? shippingPreference.direccionPaqueteriaId : undefined
        },
        PickUp: shippingPreference.pickup,
        TiempoRecogera: shippingPreference.tiempoRecogera ? shippingPreference.tiempoRecogera : undefined,
        Retenciones: {
            motivos: "",
            observacion: shippingPreference.retencion
        },
        Comentarios: shippingPreference.observaciones,
        Split: shippingPreference.dividirPedido,
    };
    return newRequest;
}