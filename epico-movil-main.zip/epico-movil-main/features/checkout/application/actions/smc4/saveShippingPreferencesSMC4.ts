import { IOrderShipmentSMC4 } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipmentSMC4";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { ShippingService } from "@/features/shipment/application/services/ShippingService";
import { AlertColor } from "@mui/material";
import { mapPreferenceShipmentToRequest } from "@/features/checkout/application/actions/mappers/mapPreferenceShipmentToRequest";

/**
 * Saves shipping preferences for SMC4 orders.
 * 
 * @param orderShipment - The order shipment information for SMC4
 * @param purchaseOrder - The purchase order identifier
 * @param showSnackbar - Callback function to display notifications with optional alert color
 * @returns A promise that resolves when the shipping preferences are saved
 */
export const saveShippingPreferencesSMC4 = async (
    orderShipment: IOrderShipmentSMC4,
    purchaseOrder: string,
    showSnackbar: (message: string, type?: AlertColor) => void
) => {
    const { putShippingPreference } = ShippingService();
    const requestBody = mapPreferenceShipmentToRequest(orderShipment, purchaseOrder);
    const responsePreference = await putShippingPreference(orderShipment.pedidoID, requestBody);

    await handleRequestDto({
        snackBar: showSnackbar,
        response: responsePreference,
        onError: () => {
            showSnackbar(NOTIFICATIONS_CHECKOUT.PREFERENCE.SAVE_ERROR, 'error');
        }
    })
}