import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { setMiniCheckoutDivision, setLoadingDivision, setSummaryMiniCheckoutSMC4, setLoadingSummarySMC4 } from "@/features/shipment/application/redux/ShipmentSlice";
import { updateDivisionThunk } from "@/features/shipment/application/redux/ShipmentThunks";
import { divisionServices } from "@/features/shipment/application/services/divisionServices";
import { normalizeDivision } from "@/features/shipment/application/utils/mapDivisionToBranchOption";
import { AlertColor } from "@mui/material";
import { Dispatch, ThunkDispatch, UnknownAction } from "@reduxjs/toolkit";

/**
 * Fetches division SMC (Shopping Cart) data by order ID and updates the Redux store accordingly.
 * 
 * This function retrieves division order information, processes the response, calculates totals
 * (subtotal, VAT, total amount, and promotional savings), and dispatches the results to the Redux store.
 * It handles success, error, and invalid response scenarios.
 * 
 * @param {IOrderSummary} orderSummary - The order summary object containing the order ID
 * @param {number} divisionId - The ID of the division to fetch (currently unused in implementation)
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Callback function to display snackbar notifications with optional alert type
 * @param {ThunkDispatch<any, undefined, UnknownAction> & Dispatch<UnknownAction>} dispatch - Redux Thunk dispatch function for triggering actions
 * 
 * @returns A promise that resolves when the fetch operation and state updates are complete
 */
export const fetchDivisionSMCById = async (
    orderSummary: IOrderSummary,
    divisionId: number,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, UnknownAction> & Dispatch<UnknownAction>,
) => {
    const { getDivisionOrder } = divisionServices();
    dispatch(setLoadingDivision(true));

    const response = await getDivisionOrder(orderSummary.pedidoID, OrigenEnum.Epico, divisionId);

    await handleRequestDto({
        response,
        snackBar: showSnackbar,
        messages: {
            error: GENERIC_ERROR_MESSAGE_CAE,
            invalid: GENERIC_ERROR_MESSAGE_CAE
        },
        onSuccess: () => {
            if (response.data && response.data.divisiones) {
                const divisions = response.data.divisiones.map(normalizeDivision);
                dispatch(updateDivisionThunk(divisions[0]));
                dispatch(setLoadingDivision(false));
            } else {
                dispatch(setLoadingDivision(false));
            }
        },
        onError: () => {
            dispatch(setLoadingDivision(false));
        },
        onInvalid: () => {
            dispatch(setLoadingDivision(false));
        }
    })
};