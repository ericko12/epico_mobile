import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { setMiniCheckoutDivision, setLoadingDivision, setSummaryMiniCheckoutSMC4, setLoadingSummarySMC4 } from "@/features/shipment/application/redux/ShipmentSlice";
import { setArticleOutStockThunk, setInitiDivisionThunk } from "@/features/shipment/application/redux/ShipmentThunks";
import { divisionServices } from "@/features/shipment/application/services/divisionServices";
import { IArticle } from "@/features/shipment/domain/interfaces/evaluatorSMC4/IArticle";
import { normalizeDivision } from "@/features/shipment/application/utils/mapDivisionToBranchOption";
import { AlertColor } from "@mui/material";
import { Dispatch, ThunkDispatch, UnknownAction } from "@reduxjs/toolkit";


/**
 * Fetches division data for SMC4 checkout process and updates the store accordingly.
 * 
 * This function retrieves division order information, processes the response, and dispatches
 * multiple actions to update the application state with the division data and calculated totals.
 * 
 * @param {IOrderSummary} orderSummary - The order summary object containing the order ID and other order details
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Callback function to display notification messages to the user
 * @param {ThunkDispatch<any, undefined, UnknownAction> & Dispatch<UnknownAction>} dispatch - Redux Thunk dispatch function for dispatching actions to the store
 * 
 * @returns A promise that resolves when the division data has been fetched and processed
 */
export const fetchDivisionSMC = async (
    orderSummary: IOrderSummary,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, UnknownAction> & Dispatch<UnknownAction>,
) => {
    const { getDivisionOrder } = divisionServices();
    dispatch(setLoadingDivision(true));
    dispatch(setLoadingSummarySMC4(true));

    const response = await getDivisionOrder(orderSummary.pedidoID, OrigenEnum.Epico);

    await handleRequestDto({
        response,
        snackBar: showSnackbar,
        messages: {
            error: GENERIC_ERROR_MESSAGE_CAE,
            invalid: GENERIC_ERROR_MESSAGE_CAE
        },
        onSuccess: () => {
            if (response.data && response.data.divisiones) {
                const divisions = response.data.divisiones.map(normalizeDivision);
                const miniCheckouts = divisions.filter(mc => mc.infoSucursalId !== null);
                const miniCheckoutsOutStock: IArticle[] = divisions.find(mc => mc.infoSucursalId === null)?.detalles?.map(detail => ({
                    productoId: detail.productoId,
                    sku: detail.producto,
                    cantidad: detail.cantidad,
                    gratis: detail.gratis,
                    precio: detail.precio,
                    promocionId: 0,
                    tipoPromocionId: 0,
                    existencias: detail.cantidad,
                    descripcion: detail.descripcion,
                    precioEspecialId: 0,
                    tieneToken: false,
                    cantidadOriginal: 0,
                    cantidadPrecioEspecial: 0,
                    cantidadTraspasos: 0
                })) ?? [];
                dispatch(setInitiDivisionThunk(miniCheckouts, miniCheckoutsOutStock, response.data.editado));
                // We get quantities from the mini checkout
                const { subTotal, ivaCalculado, total, ahorroPromociones, puntosAplicadosPlanLealtad } = divisions.reduce((acc, { subTotal = 0, ivaTotal = 0, total = 0, ahorroPromocion = 0, puntosAplicadosPlanLealtad = 0 }) => {
                    acc.subTotal += subTotal;
                    acc.ivaCalculado += ivaTotal;
                    acc.total += total;
                    acc.ahorroPromociones += ahorroPromocion;
                    acc.puntosAplicadosPlanLealtad += puntosAplicadosPlanLealtad;
                    return acc;
                }, { subTotal: 0, ivaCalculado: 0, total: 0, ahorroPromociones: 0, puntosAplicadosPlanLealtad: 0 });
                dispatch(setSummaryMiniCheckoutSMC4({ apply: true, loadingSummary: false, subTotal, ivaCalculado, total, ahorroPromociones, kmsAplicados: puntosAplicadosPlanLealtad }));
                dispatch(setLoadingDivision(false));
            } else {
                dispatch(setArticleOutStockThunk([]));
                dispatch(setMiniCheckoutDivision([]));
                dispatch(setSummaryMiniCheckoutSMC4({ apply: false, loadingSummary: false, subTotal: 0, ivaCalculado: 0, total: 0, ahorroPromociones: 0, kmsAplicados: 0, valorKms:0 }));
                dispatch(setLoadingDivision(false));
            }
        },
        onError: () => {
            dispatch(setArticleOutStockThunk([]));
            dispatch(setMiniCheckoutDivision([]));
            dispatch(setSummaryMiniCheckoutSMC4({ apply: false, loadingSummary: false, subTotal: 0, ivaCalculado: 0, total: 0, ahorroPromociones: 0, kmsAplicados: 0, valorKms:0 }));
            dispatch(setLoadingDivision(false));
        },
        onInvalid: () => {
            dispatch(setArticleOutStockThunk([]));
            dispatch(setMiniCheckoutDivision([]));
            dispatch(setSummaryMiniCheckoutSMC4({ apply: false, loadingSummary: false, subTotal: 0, ivaCalculado: 0, total: 0, ahorroPromociones: 0, kmsAplicados: 0, valorKms:0 }));
            dispatch(setLoadingDivision(false));
        }
    })
};