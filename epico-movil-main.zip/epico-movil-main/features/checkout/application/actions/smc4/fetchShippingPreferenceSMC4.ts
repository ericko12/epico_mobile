import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { AlertColor } from "@mui/material";
import { ShippingService } from "@/features/shipment/application/services/ShippingService";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { setFormPendingFields, setOrderShipmentSMC4 } from "@/features/shipment/application/redux/ShipmentSlice";
import { AnyAction } from "@reduxjs/toolkit";
import { Dispatch } from "react";
import { ThunkDispatch } from "@reduxjs/toolkit";
import { SetStateAction } from "react";
import { setPurchaseOrder } from "@/features/shipment/application/redux/ShipmentSlice";
import { fetchCustomerAddressesAction } from "@/features/shipment/application/actions/fetchCustomerAddressesAction";
import { CreateOrUpdateCustomerAddress } from "@/features/shipment/application/actions/CustomerAddressesQueries";
import { mapPreferenceToOrderShipmentSMC4 } from "@/features/checkout/application/actions/mapRequestSendMiniCheckoutSMC4";
import { IProfileSelectDate } from "@/features/users/domain/interfaces/IProfileSelectDate";

/**
 * Retrieves the shipping preference for a given order and dispatches the necessary actions to update the state.
 *
 * @param {IOrderSummary} selectedOrderSummary - The order summary containing the details of the selected order, 
 *                                               including the order ID (`pedidoID`).
 * @param {ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>} dispatch - A function that dispatches 
 *                                                                                   actions to the Redux store.
 * @param {function} setPurchaseOrderIp - A function to set the purchase order state in the component.
 * @param {function} showSnackbar - A callback function to display a snackbar message to the user. 
 *                                  It accepts a message and an optional alert type (e.g., 'error', 'success').
 *
 * @returns {Promise<IOrderShipment>} A promise that resolves to the order shipment details (IOrderShipment) 
 *                                     after successfully retrieving and processing the shipping preference.
 */
export const getShippingPreferenceSMC4 = async (
    selectedOrderSummary: IOrderSummary,
    dispatch: ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>,
    setPurchaseOrderIp: (value: SetStateAction<string>) => void,
    showSnackbar: (message: string, type?: AlertColor) => void
) => {
    const { getShippingPreference } = ShippingService();
    const responsePreference = await getShippingPreference(selectedOrderSummary.pedidoID);

    await handleRequestDto({
        snackBar: showSnackbar,
        response: responsePreference,
        onSuccess: async () => {
            const resCustomerAddresses = await fetchCustomerAddressesAction(showSnackbar, selectedOrderSummary!);
            await CreateOrUpdateCustomerAddress(resCustomerAddresses)
            const profileSelectDates: IProfileSelectDate[] = resCustomerAddresses.map((branch) => ({
                value: branch.direccionId,
                label: `${branch.fiscal ? "(Fiscal) " : ""}${branch.calle} ${branch.noExterior} Col. ${branch.colonia} ${branch.ciudad}, ${branch.estado}`,
                disabled: false,
            }));
            const mapIOrderShipment = mapPreferenceToOrderShipmentSMC4(responsePreference.data!, profileSelectDates);
            dispatch(setOrderShipmentSMC4(mapIOrderShipment));
            dispatch(setPurchaseOrder(responsePreference.data?.ordenCompra ?? ''));
            setPurchaseOrderIp(responsePreference.data?.ordenCompra ?? '');
        },
        onError: () => {
            showSnackbar('Hubo un error al guardar la preferencia del envio', 'error');
        }
    });
}