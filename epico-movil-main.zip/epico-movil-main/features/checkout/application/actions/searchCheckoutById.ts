import { getCheckOutByOrderId } from "@/features/checkout/infrastructure/db/CheckOutsRepository";


/**
 * Retrieves checkout information by order ID.
 *
 * @async
 * @function searchCheckoutById
 * @param {string} orderId - The order ID as a string, which may contain non-numeric characters.
 * @returns {Promise<Object>} The first item of the checkout information retrieved.
 */
export const searchCheckoutById = async (
    orderId: string
) => {
    const order = orderId.match(/\d+/);
    const infoOrder = await getCheckOutByOrderId(+order![0]);
    return infoOrder.data[0];
}