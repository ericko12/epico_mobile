import { PatchActionsEnum } from "@/features/common/domain/enums/PatchActionsEnum";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { AlertColor } from "@mui/material";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { SpecialPriceService } from "@/features/checkout/application/service/specialPrice.services";
import { ISpecialPriceResponse } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceResponse";

/**
 * Updates special prices in the database for a successful special price request.
 *
 * This function takes a special price ID and updates its associated fields in the database.
 * It uses patch operations to modify only the specified fields while keeping others unchanged.
 * When `updateProduct` is true, additional parameters are sent to include order-specific information.
 * The function handles both successful and failed updates through snackbar notifications.
 *
 * @async
 * @template T - Generic type parameter for flexibility in data handling
 * @param {number} precioEspecialId - The ID of the special price to update
 * @param {IOrderSummary} orderSummary - The order summary containing details to update
 * @param {{ name: string; data: any }[]} params - Array of fields to update with their new values
 * @param {function(string, AlertColor=): void} showSnackbar - Function to display snackbar notifications
 * @param {?number} [orderId] - (Optional) The order ID, used when `updateProduct` is true
 * @param {?number} [orderDetailId] - (Optional) The order detail ID, used when `updateProduct` is true
 * @param {?number} [historyId] - (Optional) The record ID (HistorialId), used when `updateProduct` is true
 * @param {?boolean} [updateProduct] - (Optional) If true, includes all relevant query parameters in the request
 * @returns {Promise<void>} Promise that resolves when special price update is complete
 * @throws {Error} Propagates any errors that occur during the update process
 */
export const updateSpecialPrice = async <T>(
    precioEspecialId: number,
    orderSummary: IOrderSummary,
    params: { name: string; data: any }[],
    showSnackbar: (message: string, type?: AlertColor) => void,
    orderId?: number,
    orderDetailId?: number,
    historyId?: number,
    updateProduct?: boolean
): Promise<IResponseDto<ISpecialPriceResponse | null> | undefined> => {
    const { patchSpecialPriceById } = SpecialPriceService();

    try {
        if (!orderSummary) return;

        const patchOperations = params.map(param => ({
            op: PatchActionsEnum.REPLACE,
            path: `/${param.name}`,
            value: param.data
        }));

        let res: IResponseDto<ISpecialPriceResponse | null>;

        if (updateProduct) {
            res = await patchSpecialPriceById(
                precioEspecialId,
                patchOperations,
                orderId ?? undefined,
                orderDetailId ?? undefined,
                historyId ?? undefined,
                updateProduct ?? undefined
            );
        } else {
            res = await patchSpecialPriceById(
                precioEspecialId,
                patchOperations
            );
        }

        handleRequestDto({
            response: res,
            snackBar: showSnackbar,
            messages: {
                error: NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_ERROR,
                invalid: NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_INVALID,
                success: NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_SUCCESS
            }
        });
        return res;
    } catch (e) {
        throw e;
    }
};
