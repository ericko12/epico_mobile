import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { IBranchTransferPetition, ISendMiniCheckoutRequestSMC4, ITransferRequestDetail } from "@/features/checkout/domain/interfaces/smc4/ISendMiniCheckoutRequestSMC4";
import { IFormSendOrderSMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/IModalSendOrderSMC4.types";
import { IMiniCheckoutDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision";
import { IOrderShipmentSMC4 } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipmentSMC4";
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum";
import { ICustomerPriceList } from "@/features/checkout/domain/interfaces/ICustomerPriceList";
import { IShippingPreference } from "@/features/shipment/domain/interfaces/IShippingPreference";
import { IProfileSelectDate } from "@/features/users/domain/interfaces/IProfileSelectDate";
import { TipoPersonaRecogera } from "@/features/checkout/domain/enums/TipoPersonaRecogera";
import { IGetPayment } from '@/features/checkout/domain/interfaces/IGetPayment';
import { IBranchTransferNode } from "@/features/shipment/domain/interfaces/evaluatorSMC4/IBranchTransferNode";
import { IMiniCheckoutTransferRequest } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCheckoutDivisionRequest";

type TransferNode = IBranchTransferNode | IMiniCheckoutTransferRequest;

/**
 * Maps an array of transfer articles to the corresponding transfer request details for SMC4.
 * 
 * @param {Array<{ productoId: number; cantidad: number; precio?: number }>} articles - The array of transfer articles to be mapped
 * @returns {ITransferRequestDetail[]} The mapped array of transfer request details for SMC4
 */
const mapTransferDetails = (
    articles: Array<{ productoId: number; cantidad: number; precio: number }>
): ITransferRequestDetail[] => {
    return articles.map(article => ({
        productoId: article.productoId,
        cantidad: article.cantidad,
        precioUnitario: article.precio,
    }));
};

/**
 * Maps a transfer branch node to the corresponding branch petition structure for SMC4.
 * 
 * @param {TransferNode} branch - The transfer branch node to be mapped
 * @returns {IBranchTransferPetition} The mapped branch petition structure for SMC4
 */
const mapTransferBranch = (
    branch: TransferNode
): IBranchTransferPetition => {
    const branchId = branch.infoSucursalId ?? 0;
    const branchRequestDetails = mapTransferDetails(
        (branch.articulos ?? []) as Array<{ productoId: number; cantidad: number; precio: number }>
    );
    const children = (branch.traspasos ?? []) as TransferNode[];

    const result: IBranchTransferPetition = {
        branchOfficeId: branchId,
        requestDetails: branchRequestDetails,
    };

    if (children.length > 0) {
        const childrenMapped = children.map(child => mapTransferBranch(child));
        const foraneaRequestDetails = aggregateChildrenQuantities(childrenMapped);

        result.foraneaLocalSolicitudes = {
            branchOfficeId: branchId,
            requestDetails: foraneaRequestDetails,
            branchesPetitions: childrenMapped,
        };
    }

    return result;
};

/**
 * Aggregates the quantities of transfer request details from child branches.
 * 
 * @param {IBranchTransferPetition[]} children - The array of child branch petitions
 * @returns {ITransferRequestDetail[]} The aggregated transfer request details for the parent branch
 */
const aggregateChildrenQuantities = (children: IBranchTransferPetition[]): ITransferRequestDetail[] => {
    const productMap = new Map<number, { productoId: number; cantidad: number; precio: number }>();

    for (const child of children) {
        for (const detail of child.requestDetails) {
            const existing = productMap.get(detail.productoId);
            if (existing) {
                existing.cantidad += detail.cantidad;
            } else {
                productMap.set(detail.productoId, {
                    productoId: detail.productoId,
                    cantidad: detail.cantidad,
                    precio: detail.precioUnitario,
                });
            }
        }

        if (child.foraneaLocalSolicitudes) {
            for (const detail of child.foraneaLocalSolicitudes.requestDetails) {
                const existing = productMap.get(detail.productoId);
                if (existing) {
                    existing.cantidad += detail.cantidad;
                } else {
                    productMap.set(detail.productoId, {
                        productoId: detail.productoId,
                        cantidad: detail.cantidad,
                        precio: detail.precioUnitario,
                    });
                }
            }
        }
    }

    return Array.from(productMap.values()).map(d => ({
        productoId: d.productoId,
        cantidad: d.cantidad,
        precioUnitario: d.precio,
    }));
};


/**
 * Concatenates order comments, retention comments and shipping type with specific length limits.
 * 
 * @param {string} pedido - Order comments or observations
 * @param {string} retenciones - Retention comments or notes
 * @param {string} auxEnvio - Shipping type (complete or partial)
 * @param {number} [maxLength=250] - Maximum allowed characters (defaults to 250)
 * @param {string} [separator=' | '] - Character(s) used to separate text segments
 * 
 * @returns {string} The concatenated comment string respecting the max length
 * 
 * @throws {Error} If the resulting concatenated comment exceeds maxLength
 */
export const concatenateComments = (
    pedido: string,
    retenciones: string,
    maxLength: number = 250,
    separator: string = ' | '
): string => {
    const commentAux = `${((retenciones.length && pedido.length) && (retenciones.length < (maxLength - 3))) ? separator : ''}${retenciones}`
    const newMaxLength = ((maxLength - commentAux.length) >= 0 && retenciones.length < (maxLength - 3)) ? (maxLength - commentAux.length) : 0
    let finalComment = `${pedido.trimEnd().slice(0, newMaxLength)}${commentAux}`

    finalComment = finalComment.slice(0, maxLength);

    if (finalComment.length > maxLength)
        throw new Error("El comentario es demasiado largo. Intenta resumirlo para poder guardarlo.");

    return finalComment;
}

/**
 * Maps form data and checkout information to a mini checkout request for SMC4.
 * 
 * @param {string} purchaseOrder - The purchase order number
 * @param {IFormSendOrderSMC4} formData - Form data containing order submission information
 * @param {IMiniCheckoutDivision} checkoutInfo - Checkout information including shipping method and division details
 * @param {IOrderSummary} selectedOrderSummary - Summary of the selected order
 * @param {IUserDto} userAuth - Authenticated user information
 * @param {IOrderShipmentSMC4} currentShippingOrder - Current shipping order details
 * @param {ICustomerPriceList} customerPriceList - Customer's price list information
 * @param {IGetPayment} paymentMethodSMC4 - Information about the selected payment method for SMC4
 * @returns {ISendMiniCheckoutRequestSMC4} The mapped mini checkout request object ready to be sent to SMC4
 */
export const mapToRequestMiniCheckout = (
    purchaseOrder: string,
    formData: IFormSendOrderSMC4,
    checkoutInfo: IMiniCheckoutDivision,
    selectedOrderSummary: IOrderSummary,
    userAuth: IUserDto,
    currentShippingOrder: IOrderShipmentSMC4,
    customerPriceList: ICustomerPriceList,
    paymentMethodSMC4: IGetPayment
) => {
    const finalComment: string = concatenateComments(
        formData.comment ?? '',
        currentShippingOrder?.Retenciones?.observacion ?? ''
    );

    const newRequest: ISendMiniCheckoutRequestSMC4 = {
        metodoEntrega: checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup ? 0 : 1,
        clienteVendedorId: selectedOrderSummary.clienteVendedorId,
        pedidoOrigenId: checkoutInfo.pedidoOrigenId,
        origenId: OrigenEnum.Epico,
        usuarioId: userAuth.userId,
        prontoPago: selectedOrderSummary.prontoPago,
        sucursalIdDestino: checkoutInfo.infoSucursalId,
        motorDivisionId: checkoutInfo.motorDivisionId,
        KmsAplicados: checkoutInfo.puntosAplicadosPlanLealtad,
        divisionPedidoId: checkoutInfo.pedidoDivididoId,
        esTransitorio: checkoutInfo.esTransitorio ?? false,
        pcid: 3,
        tipoProntoPagoId: selectedOrderSummary.tipoProntoPagoId ?? 0,
        preferenciasPedido: {
            concesionId: paymentMethodSMC4.concessionId,
            plazo: paymentMethodSMC4.openPay ? 0 : currentShippingOrder.consecion?.plazo ?? 0,
            metodoPagoId: paymentMethodSMC4.id,
            pagadoConOpenpay: paymentMethodSMC4.openPay,
            pue: paymentMethodSMC4.openPay ? false : currentShippingOrder?.PUE ?? false,
            observaciones: finalComment,
            porteId: Number(process.env.NEXT_PUBLIC_PORTE_PAID),
            surtidoHandHeld: checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Delivery ? true : false,
            dividirPedido: formData.split,
            correoElectronicoContacto: currentShippingOrder?.Email ?? '',
            telefonoContacto: currentShippingOrder?.Phone ?? '',
            ...(checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup && { pickup: paymentMethodSMC4.forcePickup ? true : checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup }),
            ...(checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Delivery && {
                direccionId: currentShippingOrder.DireccionEntregaId,
                tipoServicioEntregaID: checkoutInfo.tipoServicioEnvioId || undefined,
                paqueteriaId: Number(process.env.NEXT_PUBLIC_INTERNAL_PARCEL_DELIVERY),
                servicioEntregaId: Number(process.env.NEXT_PUBLIC_DELIVERY_SERVICE),
                distancia: checkoutInfo.distancia.split(' ')[0] ? Number(checkoutInfo.distancia.split(' ')[0]) : 0,
            }),
            ...(!!purchaseOrder && { ordenCompra: purchaseOrder }),
            ...(currentShippingOrder?.PersonaRecogera && { personaRecogera: currentShippingOrder.PersonaRecogera }),
        },
        pedidoDetalles: checkoutInfo?.detalles?.map(product => ({
            productoId: product.productoId,
            precio: product.precio,
            cantidad: product.cantidad,
            pcListaPrecioId: customerPriceList.listaPrecioId,
            descuentoAdicional: 0,
            gratis: product.gratis,
            KmsAplicados: product.puntosAplicadosPlanLealtad,
            tieneToken: product.precioEspecialId > 0,
            ...((product?.promocionId ?? 0) > 0 && { pcPromocionId: product.promocionId }),
            ...(product.precioEspecialId > 0 && { precioEspecialId: product.precioEspecialId }),
        })) ?? [],
        ...((checkoutInfo.traspasos ?? []).length > 0 && {
            solicitudTraspasoAutomatica: {
                branchOfficeId: checkoutInfo.infoSucursalId ?? 0,
                userId: userAuth.userId ?? 0,
                requestDetails: mapTransferDetails(
                    (checkoutInfo.detalles ?? []).map(product => ({
                        productoId: product.productoId,
                        cantidad: product.cantidad,
                        precio: product.precio,
                    }))
                ),
                branchesPetitions: ((checkoutInfo.traspasos ?? []) as TransferNode[]).map(mapTransferBranch),
            }
        }),
        ...(selectedOrderSummary.origenExternoId !== null && {
            pedidoExterno: {
                pedidoId: selectedOrderSummary.pedidoIdExterno ?? 0,
                origenId: selectedOrderSummary.origenExternoId ?? 0
            }
        })
    }

    return newRequest;
}

/**
 * Maps shipping preference data to an order shipment object for SMC4.
 * 
 * @param {IShippingPreference} shippingPreference - The shipping preference data containing order and delivery information
 * @param {IProfileSelectDate[]} profileSelectDates - Array of profile select dates used to find the delivery address label
 * @returns {IOrderShipmentSMC4} The mapped order shipment object formatted for SMC4
 */
export const mapPreferenceToOrderShipmentSMC4 = (
    shippingPreference: IShippingPreference,
    profileSelectDates: IProfileSelectDate[]
): IOrderShipmentSMC4 => {
    const newResponse: IOrderShipmentSMC4 = {
        pedidoID: shippingPreference.pedidoId,
        consecion: {
            concesionId: shippingPreference.concesionId ?? 0,
            concesion: shippingPreference.concesion,
            plazo: shippingPreference.plazo ?? 0,
            status: true,
        },
        PUE: shippingPreference.pue,
        FormaPagoId: shippingPreference.metodoPagoId,
        FormaPago: {
            metodoPagoId: shippingPreference.metodoPagoId ?? 0,
            metodoPago: shippingPreference.metodoPago,
            status: true
        },
        MetodoEnvio: shippingPreference.envioDireccion ? ShippingMethodSMC4Enum.Delivery : ShippingMethodSMC4Enum.Pickup,
        DireccionEntregaId: shippingPreference.direccionId,
        DireccionEntrega: profileSelectDates.find(date => date.value === shippingPreference.direccionId)?.label ?? '',
        Email: shippingPreference.emailContacto,
        Phone: shippingPreference.telefonoContacto,
        PersonaRecogera: shippingPreference.personaRecogera,
        TipoPersonaRecogera: shippingPreference.tipoPersonaRecogera === '' ? undefined : shippingPreference.tipoPersonaRecogera as TipoPersonaRecogera,
        Retenciones: {
            motivos: "",
            observacion: shippingPreference.retencion
        },
        optionChecked: shippingPreference.opcionSeleccionada ?? 0,
        isPreviewMiniCheckouts: false,
    }
    return newResponse;
}