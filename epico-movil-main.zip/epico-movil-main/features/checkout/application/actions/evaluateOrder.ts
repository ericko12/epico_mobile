import { SMCService } from "@/features/checkout/application/service/smc.services";
import { GetOrderShipmentById } from "@/features/checkout/infrastructure/db/OrdersShipmentRepository";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { setEvaluateOrderRequest } from "@/features/orders/application/actions/setEvaluateOrderRequest";
import { IEvaluateOrder } from "@/features/checkout/domain/interfaces/smc/IEvaluateOrder";

/**
 * Validates and determines the correct delivery address ID to use for an order shipment.
 * 
 * This function checks the shipping method and available addresses to determine which address ID
 * should be used for the order. It follows this logic:
 * 1. If shipping via courier is active, use the courier address ID
 * 2. Otherwise, if a delivery address ID exists, use that
 * 3. If no valid address is found, return 0
 *
 * @param {IOrderShipment} orderShipment - The order shipment object containing address and shipping details
 * @returns {number} The ID of the address to use, or 0 if no valid address is found
 */
const validateDirectionId = (orderShipment: IOrderShipment): number => (orderShipment.EnviarPaqueteria?.active && orderShipment.EnviarPaqueteria.DireccionPaqueteriaId!) ? orderShipment.EnviarPaqueteria.DireccionPaqueteriaId! : orderShipment.DireccionEntregaId ? orderShipment.DireccionEntregaId : 0;


/**
 * Evaluates the order according to the shipping method and priority on SMC (Stock Management and Consolidation).
 * This function takes an order and its priority level, then evaluates how it should be processed and shipped.
 * 
 * The evaluation considers:
 * - The order's shipping method (pickup or delivery)
 * - The priority level assigned to the order
 * - The delivery address if applicable
 * - Stock availability and distribution
 * 
 * Based on these factors, it determines:
 * - How to split or consolidate the order into mini-checkouts
 * - Which branches should fulfill each part
 * - The optimal shipping route and method
 *
 * @async
 * @param {IOrderSummary} orderSummary - Object containing the order details and summary information
 * @param {number} prioridad - Priority level assigned to the order (higher number = higher priority)
 * @param {?boolean | null} kmsApplied - boolean indicating if the order contains any kms points (Optional)
 * @returns {Promise<IResponseDto<IEvaluateOrder> | IResponseDto<null>>} Response containing the evaluated order details, 
 * including mini-checkout assignments and shipping plans. Returns null response if evaluation fails.
 */
export const evaluateOrder = async (
    orderSummary: IOrderSummary,
    prioridad: number,
    kmsApplied?: boolean | null,
): Promise<IResponseDto<IEvaluateOrder> | IResponseDto<null>> => {
    const { PostEvaluateOrder } = SMCService();
    const { data: shipmentData } = await GetOrderShipmentById(orderSummary.pedidoID);
    const directionId = validateDirectionId(shipmentData[0]);
    const dataRequest = setEvaluateOrderRequest(orderSummary, directionId, prioridad, shipmentData[0],kmsApplied)

    return await PostEvaluateOrder(dataRequest);
}