import { IProduct } from "@/features/products/domain/interfaces/IProduct";
import { IStockParam } from "@/features/checkout/domain/interfaces/IStockParam";
import { ProductService } from "@/features/products/application/service/product.services";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";


/**
 * Function to retrieve a product by its code for a specific client ID.
 * 
 * @async
 * @param {number} clienteId - The ID of the client to search for the product.
 * @param {string} productCode - The code of the product to search for.
 * 
 * @returns {Promise<IProduct>} Promise that resolves to the product details.
 * 
 * @throws {Error} If the product is not found or if there is an error in fetching the product details.
 */
export const getProductBySearch = async (clienteId: number, productCode: string): Promise<IProduct> => {
    const stockParams: IStockParam = {
        RecuperarExistencia: false,
        SucursalId: 0,
    };

    const { getProduct } = ProductService();

    const resProduct = await getProduct(clienteId, productCode, stockParams);

    return new Promise<IProduct>((resolve, reject) => {
        try {
            handleRequestDto({
                response: resProduct,
                onError: () => { throw new Error(NOTIFICATIONS_CHECKOUT.PRODUCT.FETCH_ERROR); },
                onInvalid: () => {
                    throw new Error(
                        resProduct.statusCode === 404
                            ? NOTIFICATIONS_CHECKOUT.PRODUCT.NOT_FOUND
                            : resProduct.error?.mensaje || NOTIFICATIONS_CHECKOUT.PRODUCT.FETCH_INVALID
                    );
                },
                onSuccess: () => {
                    if (resProduct.data === null) {
                        throw new Error(NOTIFICATIONS_CHECKOUT.PRODUCT.FETCH_ERROR);
                    }

                    resolve(resProduct.data);
                }
            });
        } catch (error) {
            reject(error);
        }
    });
};
