
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { IMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckout";
import { AlertColor } from "@mui/material";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { PromotionService } from "@/features/promotions/application/service/PromotionService";

/**
 * Consult the promotions applied to the order and obtain the rate to update the items
 *
 * @async
 * @param {IMiniCheckout[]} miniCheckouts the miniCheckouts
 * @param {(message: string, type?: AlertColor) => void} showSnackbar show snackbar function
 * @returns {Promise<IMiniCheckout[]>}
 */
export const handlePromotionsMiniCheckouts = async (miniCheckouts: IMiniCheckout[], showSnackbar: (message: string, type?: AlertColor) => void, originId?: number): Promise<IMiniCheckout[]> => {
    const { GetPromotionsByIds } = PromotionService();
    const promocionIDs = miniCheckouts.flatMap(miniCheckout =>
        miniCheckout.detalle
            .map(detalle => detalle.promocionID)
            .filter(promocionID => promocionID > 0)
    );
    const uniquePromocionIDs = Array.from(new Set(promocionIDs));

    const resPromotions = await GetPromotionsByIds(uniquePromocionIDs, originId);

    const updateMiniCheckout: IMiniCheckout[] = await handleRequestDto({
        snackBar: showSnackbar,
        response: resPromotions,
        onSuccess: () => {
            // Add typePromotionId to each promotion
            const updatedMiniCheckouts: IMiniCheckout[] = miniCheckouts.map(miniCheckout => {
                // Get the updated detail with typePromotionId
                const updatedDetalle = miniCheckout.detalle.map(detalle => {
                    const matchingPromotion = resPromotions!.data!.find(promotion => promotion.id === detalle.promocionID);
                    return {
                        ...detalle,
                        tipoPromocionId: matchingPromotion ? matchingPromotion.tipoPromocionId : 0,
                    };
                });

                return {
                    ...miniCheckout,
                    detalle: updatedDetalle, // Update the detail with typePromotionId
                };
            });
            return updatedMiniCheckouts;
        },
        messages: {
            error: NOTIFICATIONS_CHECKOUT.PROMOTION.NOT_FOUND_PROMOTION,
        }
    }) || [];

    return updateMiniCheckout;
}