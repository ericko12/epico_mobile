import { IEstadoCiudad } from "@/features/address/domain/interface/IEstadoCiudad";
import { ICity } from "@/features/address/domain/interface/ICity";
import { branchService } from "@/features/branch/application/services/branch.services";
import { OrderTypeEnum } from '@/features/common/domain/enums/OrderTypeEmun';
import { ContriesEnum } from '@/features/shipment/domain/enum/CountriesEnum';

/**
 * Fetches branch addresses, processes them into a list of states with cities, and returns the result.
 * @returns Promise<IEstadoCiudad[] | null> Processed list of states with cities, or null on error.
 */
export const fetchProcessBranchAddressesToStateCity = async (): Promise<IEstadoCiudad[] | null> => {
    try {
        const { getBranchAddress } = branchService();
        const response = await getBranchAddress(true, ContriesEnum.Mexico, OrderTypeEnum.asc, 'Sucursal');
        if (response.data) {

            const estadoMap = new Map<number, { stateId: number; state: string; cities: Map<number, ICity> }>();
            response.data.forEach(branch => {
                if (!estadoMap.has(branch.estadoID)) {
                    estadoMap.set(branch.estadoID, {
                        stateId: branch.estadoID,
                        state: branch.estado,
                        cities: new Map()
                    });
                }

                const estado = estadoMap.get(branch.estadoID)!;
                if (!estado.cities.has(branch.ciudadId)) {
                    estado.cities.set(branch.ciudadId, {
                        ciudadId: branch.ciudadId,
                        municipioId: 0,
                        ciudad: branch.ciudad
                    });
                }
            });

            return Array.from(estadoMap.values()).map(estado => ({
                estadoId: estado.stateId,
                estado: estado.state,
                cuidades: Array.from(estado.cities.values())
            }));


        } else {
            return null;
        }
    } catch (error) {
        console.error('Error fetching branch addresses:', error);
        return null;
    }
};