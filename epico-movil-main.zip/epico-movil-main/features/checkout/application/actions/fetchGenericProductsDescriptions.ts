import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { ProductService } from "@/features/products/application/service/product.services";
import { GenericProduct } from "@/features/products/domain/interfaces/IGenericProductList";
import { AlertColor } from "@mui/material";

/**
 * Fetches generic product descriptions for transitory mini checkouts.
 * Only performs the fetch when at least one division/branch option is marked as transitory
 * and a valid order or quotation ID exists.
 *
 * @async
 * @param {boolean} hasTransitoryDivision - Whether any division/branch option is marked as transitory (`esTransitorio`).
 * @param {number | undefined} pedidoID - The order ID from the selected order summary.
 * @param {number | undefined} cotizacionIdOrigen - The quotation origin ID from the selected order summary.
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Function to display snackbar notifications.
 * @returns {Promise<GenericProduct[]>} Resolves to an array of generic products, or an empty array if conditions are not met or an error occurs.
 */
export const fetchGenericProductsDescriptions = async (
    hasTransitoryDivision: boolean,
    pedidoID: number | undefined,
    cotizacionIdOrigen: number | undefined,
    showSnackbar: (message: string, type?: AlertColor) => void
): Promise<GenericProduct[]> => {
    if (!hasTransitoryDivision || (!pedidoID && !cotizacionIdOrigen)) return [];

    const { GetGenericsProductsTlcIds } = ProductService();
    const response = await GetGenericsProductsTlcIds(cotizacionIdOrigen ?? pedidoID!);

    return await handleRequestDto<GenericProduct[] | null, GenericProduct[]>({
        response,
        onSuccess: () => response.data ?? [],
        onError: () => {
            showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
            return [];
        },
        onInvalid: () => []
    }) ?? [];
};
