import { MutableRefObject } from "react";
import { AlertColor } from "@mui/material";
import { AnyAction, Dispatch, ThunkDispatch } from "@reduxjs/toolkit";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { PatchOrderSummaryDetailsEnum } from "@/features/checkout/domain/enums/OrderSummaryDetailsEnum";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { updateOrderSummaryThunk } from "@/features/checkout/application/redux/checkOutThunks";
import { updateSpecialPrice } from "@/features/checkout/application/actions/updateSpecialPrice";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";

/**
 * Updates the status of a special price in an order detail and in the order summary.
 * This function handles updating the special price status for a product in an order.
 * If the new status is "Accepted", it also updates the product price to the suggested special price.
 * The function updates both the order detail and the overall order summary with the new status.
 *
 * @async
 * @param {IOrderSummaryDetail} pedidoDetalle - Order detail containing the special price information
 * @param {number} suggestedPrice - The suggested special price for the product
 * @param {number} specialPriceState - The new status for the special price
 * @param {IOrderSummary} orderSummary - Order summary containing the details to update
 * @param {function(string, AlertColor=): void} showSnackbar - Function to display snackbar notifications
 * @param {ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>} dispatch - Redux dispatch function
 * @param {number} [historyId] - (Optional) ID referencing the order history for tracking changes or previous requests
 * @returns {Promise<void>} Promise that resolves when the update is successful
 * @throws {Error} Will throw an error if the update process fails
 */
export const fetchUpdateSpecialPrice = async (
    pedidoDetalle: IOrderSummaryDetail,
    suggestedPrice: number,
    specialPriceState: number,
    orderSummary: IOrderSummary,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>,
    historyId?: number
): Promise<void> => {
    try {
        if (orderSummary?.detalles) {

            let updatedOrderSummary = {
                ...orderSummary,
                detalles: orderSummary.detalles.map(detalle =>
                    detalle.pedidoDetalleId === pedidoDetalle.pedidoDetalleId
                        ? {
                            ...detalle,
                            estatusPrecioEspecialId: specialPriceState
                        }
                        : detalle
                ),
            };

            if (specialPriceState === SpecialPriceStates.Aceptado.index) {
                const orderUpdating = await updateSpecialPrice(
                    pedidoDetalle.precioEspecialId,
                    orderSummary,
                    [
                        { name: PatchOrderSummaryDetailsEnum.estatusPreciosEspecialesId, data: specialPriceState }
                    ],
                    showSnackbar,
                    pedidoDetalle.pedidoID,
                    pedidoDetalle.pedidoDetalleId,
                    historyId,
                    true
                );

                if (orderUpdating && !orderUpdating.huboError && orderUpdating.data) {

                    const { getOrderSummaryByOrderIds } = checkoutServices();

                    const responseResumen = await getOrderSummaryByOrderIds([updatedOrderSummary.pedidoID], [updatedOrderSummary.estatusID]);
                    handleRequestDto<IOrderSummary[] | null, IOrderSummary[] | null>({
                        response: responseResumen,
                        snackBar: showSnackbar,
                        messages: { error: GENERIC_ERROR_MESSAGE_CAE },
                        onSuccess: async () => {

                            const firstSummary = responseResumen.data?.[0];
                            if (firstSummary) {
                                await dispatch(updateOrderSummaryThunk(firstSummary));
                            }
                        },
                    })

                }
            }
            else {
                await updateSpecialPrice(
                    pedidoDetalle.precioEspecialId,
                    orderSummary,
                    [
                        { name: PatchOrderSummaryDetailsEnum.estatusPreciosEspecialesId, data: specialPriceState }
                    ],
                    showSnackbar
                );
                await dispatch(updateOrderSummaryThunk(updatedOrderSummary));

            }

        }
    } catch (error) {
        showSnackbar(NOTIFICATIONS_CHECKOUT.GENERAL.ERROR, "error");
        throw error;
    }
}
