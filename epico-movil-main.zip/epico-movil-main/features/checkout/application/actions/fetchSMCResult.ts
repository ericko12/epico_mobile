import { AlertColor } from "@mui/material";
import { AnyAction, Dispatch, ThunkDispatch } from "@reduxjs/toolkit";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { setApplyDivision, setloadingEvaluatedSMC, setLogCheckout, setMiniCheckouts, setSummaryMiniCheckout } from "@/features/shipment/application/redux/ShipmentSlice";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { SMCService } from "@/features/checkout/application/service/smc.services";
import { fetchOrdeOpenPayStatusThunk } from "@/features/shipment/application/redux/ShipmentThunks";
import { NOTIFICATIONS_SHIPMENT } from "@/features/common/infrastructure/utils/messages/notificationShipment";
import { TypeConsolidatedEnum } from "@/features/checkout/domain/enums/TypeConsolidatedEnum";
import { handlePromotionsMiniCheckouts } from "@/features/checkout/application/actions/handlePromotionsMiniCheckouts";

/**
 * Handles the response of the SMC (Stock Management and Consolidation) algorithm and recovers the log.
 * This function fetches the results of the SMC algorithm for a given order, processes the mini-checkouts,
 * updates the order status, and manages the consolidation state.
 *
 * @async
 * @param {number} pedidoID - The unique identifier of the order to fetch results for
 * @param {IOrderSummary} orderSummary - Object containing summary information about the order
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Function to display notification messages
 * @param {(ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>)} dispatch - Redux dispatch function to update state
 * @param {boolean} firstPetition - Flag indicating if this is the first request, defaults to false. Controls whether to fetch OpenPay status
 * @returns {Promise<number>} - Returns a promise that resolves to the branch ID (infoSucursalID) of the main mini-checkout, or 0 if not found
 */
export const fetchSMCResult = async (
    pedidoID: number,
    orderSummary: IOrderSummary,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>,
    firstPetition: boolean = false,
): Promise<number> => {
    dispatch(setloadingEvaluatedSMC(true));
    const { GetResultsSMC, GetRecoverLogCheckout } = SMCService();
    const responseSMC = await GetResultsSMC(pedidoID)
    const branchId = await handleRequestDto({
        snackBar: showSnackbar,
        response: responseSMC,
        onSuccess: async () => {
            const miniCheckout = await handlePromotionsMiniCheckouts(responseSMC.data!.miniCajas, showSnackbar, orderSummary!.origenExternoId!);
            dispatch(setMiniCheckouts(miniCheckout))
            // Updates the current order status by fetching the latest OpenPay payment status
            // Only executed on first petition to avoid unnecessary API calls
            if (firstPetition) dispatch(await fetchOrdeOpenPayStatusThunk(miniCheckout, showSnackbar, orderSummary.pedidoID));
            const responseLogCheckout = await GetRecoverLogCheckout(orderSummary!.pedidoID)
            await handleRequestDto({
                snackBar: showSnackbar,
                response: responseLogCheckout,
                onSuccess: async () => {
                    dispatch(setApplyDivision(responseLogCheckout.data!.tipoConsolidadoID === TypeConsolidatedEnum.ConsolidadoUsuario || responseLogCheckout.data!.tipoConsolidadoID === TypeConsolidatedEnum.PedidoDividido ? true : false))
                    dispatch(setLogCheckout(responseLogCheckout.data!))
                },
                messages: {
                    error: NOTIFICATIONS_SHIPMENT.SMC.LOG_ERROR
                }
            });

            // We get quantities from the mini checkout
            const { subTotal, ivaCalculado, total, ahorroPromociones } = responseSMC.data!.miniCajas.reduce((acc, { subtotal = 0, ivaTotal = 0, total = 0, ahorroPromociones = 0, }) => {
                acc.subTotal += subtotal;
                acc.ivaCalculado += ivaTotal;
                acc.total += total;
                acc.ahorroPromociones += ahorroPromociones;
                return acc;
            }, { subTotal: 0, ivaCalculado: 0, total: 0, ahorroPromociones: 0, });
            dispatch(setSummaryMiniCheckout({ apply: true, loadingSummary: false, subTotal, ivaCalculado, total, ahorroPromociones }))

            return responseSMC.data!.miniCajas.find(mc => mc.principal === true)?.infoSucursalID ?? 0;
        },
        messages: {
            error: NOTIFICATIONS_SHIPMENT.SMC.RESULT_ERROR
        }
    }) || 0;

    dispatch(setloadingEvaluatedSMC(false));
    return +branchId;
}