import { AlertColor } from "@mui/material";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { SpecialPriceService } from "@/features/checkout/application/service/specialPrice.services";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { PatchActionsEnum } from "@/features/common/domain/enums/PatchActionsEnum";
import { PatchOrderSummaryDetailsEnum } from "@/features/checkout/domain/enums/OrderSummaryDetailsEnum";
import { ISpecialPriceResponse } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceResponse";

/**
 * Updates the details of a special price and makes the corresponding changes in the database.
 * 
 * This function prepares an array of operations to update the special price details, 
 * including the employee ID executing the update and the special price status.
 * It then sends a request to update the special price in the database.
 * 
 * @param {number} precioEspecialId - The ID of the special price to be updated.
 * @param {IOrderSummary} orderSummary - The order summary containing the order details to update.
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Function used to show snackbar notification messages.
 * @param {ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>} dispatch - Redux `dispatch` function used to send actions.
 * @param {number} [employeeId] - The ID of the employee executing the special price update (optional).
 * @returns {Promise<void>} - A promise that resolves when the update operation is complete.
 */
export const updateSpecialPriceReset = async <T>(
    precioEspecialId: number,
    orderSummary: IOrderSummary,
    showSnackbar: (message: string, type?: AlertColor) => void,
    employeeId: number,
): Promise<void> => {
    const { patchSpecialPriceById } = SpecialPriceService();

    try {
        if (!orderSummary) return;

        // Create an array of operations to update the special price
        const patchOperations: { op: string, path: string, value: any }[] = [];

        if (employeeId) {
            patchOperations.push({
                op: PatchActionsEnum.REPLACE,
                path: `/${PatchOrderSummaryDetailsEnum.empleadoIDEjecuto}`,
                value: employeeId
            });
        }
        patchOperations.push({
            op: PatchActionsEnum.REPLACE,
            path: `/${PatchOrderSummaryDetailsEnum.estatusPreciosEspecialesId}`,
            value: SpecialPriceStates.Cancelado.index
        });

        // Make the request to update the special price
        const res: IResponseDto<ISpecialPriceResponse | null> = await patchSpecialPriceById(
            precioEspecialId,
            patchOperations
        );

    } catch (e) {
        throw e;
    }
};