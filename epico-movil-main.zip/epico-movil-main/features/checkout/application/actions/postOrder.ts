import { AlertColor } from "@mui/material";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { IUserDto } from "@/features/users/domain/interfaces/IUserDto";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { IOrder } from "@/features/checkout/domain/interfaces/IOrder";
import { PromptTypePaymentId } from "@/features/common/domain/enums/PromptTypePaymentId";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { PoliticaComercialEnum } from "@/features/common/domain/enums/PoliticaComercialEnum";

/**
 * Sends a request to create an order and returns the order ID.
 * 
 * @param {IOrderSummary | null} orderSummary - Summary of the order to create. Must not be null and must contain the required properties.
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Function to display notifications.
 * @param {?IUserDto | undefined} [userAuth] - User authentication data (optional).
 * @param {?boolean} [IsQuotation] - Indicates if the order comes from a quotation.
 * 
 * @throws {Error} Throws an error if `orderSummary` is null, any required property is missing, or `userAuth` is undefined.
 * 
 * @returns {Promise<string>} Promise that resolves with the ID of the new order.
 */
export const PostOrder = async (
    orderSummary: IOrderSummary | null,
    showSnackbar: (message: string, type?: AlertColor) => void,
    userAuth?: IUserDto,
    IsQuotation?: boolean
): Promise<string> => {
    const { postOrder } = checkoutServices();
    if (orderSummary === null || orderSummary.sucursalIdDestino === undefined || userAuth === undefined) {
        throw new Error(NOTIFICATIONS_CHECKOUT.CHECKOUT.CREATE_ERROR);
    }

    const newOrder: IOrder = {
        Pcid: PoliticaComercialEnum.PC2020,
        Plazo: orderSummary.plazo,
        OrigenId: OrigenEnum.Epico,
        clienteId: orderSummary.clienteId,
        UsuarioId: userAuth.userId,
        SucursalId: orderSummary.sucursalIdDestino,
        ContactoId: orderSummary.contactoId,
        ProntoPago: orderSummary.tipoProntoPagoId !== PromptTypePaymentId.Factura ?
            PromptTypePaymentId.TipoProntoPago : orderSummary.prontoPago,
        DireccionId: orderSummary.direccionId,
        MetodoPagoId: orderSummary.metodoPagoId,
        EsCotizacion: false,
        TipoProntoPagoId: orderSummary.tipoProntoPagoId!,
        SucursalIdDestino: orderSummary.sucursalIdDestino,
        ClienteVendedorId: orderSummary.clienteVendedorId,
        motorDivisionId: orderSummary.motorDivisionId,
        ...(IsQuotation && { CotizacionIdOrigen: orderSummary.pedidoID })
    };

    const res = await postOrder(newOrder);
    return new Promise<string>((resolve, reject) => {
        try {
            handleRequestDto({
                response: res,
                snackBar: showSnackbar,
                messages: {
                    success: NOTIFICATIONS_CHECKOUT.PRODUCT.POST_SUCCESS,
                },
                onError: () => { throw new Error(NOTIFICATIONS_CHECKOUT.CHECKOUT.CREATE_ERROR); },
                onInvalid: () => { throw new Error(NOTIFICATIONS_CHECKOUT.CHECKOUT.CREATE_INVALID); },
                // eslint-disable-next-line @typescript-eslint/no-unused-expressions
                onSuccess: () => { res.data && resolve(res.data.pedidoId); }
            });
        } catch (error) {
            reject(error);
        }
    });
};
