import { AlertColor } from "@mui/material";
import { UnknownAction, Dispatch, ThunkDispatch } from "@reduxjs/toolkit";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { ordersService } from "@/features/orders/application/services/order.services";
import { IOrderDetail } from "@/features/checkout/domain/interfaces/IOrderDetail";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { actionsCheckout } from "@/features/checkout/application/redux/checkOutSlice";
import { IOrderDetailRequest } from "@/features/checkout/domain/interfaces/IOrderDetailRequest";
import { InitOrderDetail } from "@/features/checkout/domain/data/InitOrderDetail.data";
import { InitCheckoutState } from "@/features/checkout/domain/data/InitCheckoutState.data";
import { PriceType } from "@/features/common/infrastructure/utils/priceUtils";

/**
 * Allows adding multiple products to an order.
 *
 * @async
 * @function addOrderDetail
 * @param {string | number} orderId - The identifier of the order.
 * @param {IOrderSummaryDetail[]} products - Array of products to be added to the order.
 * @param {number} priceListId - The ID of the price list.
 * @param {function(string, AlertColor=): void} showSnackbar - Function to display snackbar notifications.
 * @param {ThunkDispatch<any, undefined, UnknownAction> & Dispatch<UnknownAction>} dispatch - Redux dispatch function.
 * @returns {Promise<IOrderSummary>} A promise that resolves with the updated order summary.
 * @throws Error if the request to update the order fails.
 */
export const addOrderDetails = async (
    pedido: string | number,
    products: IOrderSummaryDetail[],
    priceListId: number,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, UnknownAction> & Dispatch<UnknownAction>
): Promise<IOrderSummary> => {
    const { postOrderDetail } = ordersService();

    try {
        const details: IOrderDetail[] = products.map((product) => ({
            ...InitOrderDetail,
            Precio: product.precio,
            Cantidad: product.cantidad,
            ProductoId: product.productoID,
            PrecioLista: product.precio,
            TipoPrecio: product.tipoPrecio?? PriceType.Lista,
        }));

        const newOrderDetail: IOrderDetailRequest = {
            PcListaPrecioId: priceListId,
            PedidoDetalle: details,
        };

        const res: IResponseDto<IOrderSummary | null> = await postOrderDetail(pedido, newOrderDetail);

        handleRequestDto({
            response: res,
            snackBar: showSnackbar,
            messages: {
                error: NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_ERROR,
                invalid: NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_INVALID,
            },
            onSuccess: () => {
                dispatch(actionsCheckout.setPageAuxiliarStates(InitCheckoutState.pageAuxiliarStates));
            },
        });

        if (res.data === null) throw new Error(NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_ERROR);

        return res.data;
    } catch (e) {
        throw e;
    }
};
