import { addOrdersSummaryAsCheckOutsThunk, clearCheckOutsThunk, switchLoadingThunk } from "@/features/checkout/application/redux/checkOutThunks";
import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { methods } from "@/features/common/domain/enums/CRUD";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { ICustomerPriceList } from "@/features/checkout/domain/interfaces/ICustomerPriceList";
import { IClienteVendedorCompletoDto } from "@/features/customer/domain/interface/db/IClienteVendedorCompletoDto";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";
import { IAuth } from "@/features/auth/domain/interfaces/IAuth";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { customerService } from "@/features/customer/application/service/customer.services";
import { getCustomerByCustomerId } from "@/features/customer/application/actions/db/CustomersRepository";
import {setProductInOrder,} from "@/features/loyaltyPlan/application/redux/loyaltyPlanSlice";
import { setMiniCheckoutsAll } from "@/features/shipment/application/redux/ShipmentSlice";
import { IStatusOpenPay } from "@/features/openPay/domain/interfaces/IStatusOpenPay";
/**
 * Retrieves the orders from the server and refreshes them in the checkout bar.
 *
 * @async
 * @param {*} dispatch the component's dispatcher
 * @param {number | undefined} selectedOrderSummaryId
 * @param {IAuth} userAuthState the user state of the component
 */
export const fetchOrderSummariesAction = async (dispatch: any, userAuthState: IAuth, selectedOrderSummaryId?: number) => {
    const { getOrderSummaryByUserLastDay, getPriceListByListOfCustomers, getLinkStatus } = checkoutServices();

    if (!userAuthState.userAuth || !userAuthState.userAuth.userId) return;

    await dispatch(switchLoadingThunk(true));

    try {
        const status: Array<number> = [
            StatusOrderEnum.Activo,
            StatusOrderEnum.EnviadoSMC,
            StatusOrderEnum.OpenPay
        ];

        const response = await getOrderSummaryByUserLastDay(userAuthState.userAuth.userId, status);

        if (response.statusCode === 204 || !response.data) {
            await dispatch(clearCheckOutsThunk());
            return;
        }
        if (!response || response.statusCode !== 200) {
            throw new Error("Error fetching order summaries");
        }
        const checkOuts = response.data?.filter(orderSummary =>
            orderSummary.estatusID === StatusOrderEnum.Activo || orderSummary.estatusID === StatusOrderEnum.EnviadoSMC || orderSummary.estatusID === StatusOrderEnum.OpenPay
        );

        const checkOutsOpenpay = response.data?.filter(orderSummary => orderSummary.estatusID === StatusOrderEnum.OpenPay);        
        if(userAuthState.userAuth?.engineSMC4){
            if (checkOutsOpenpay && checkOutsOpenpay.length > 0) {
                const openpayStatus = await getLinkStatus(checkOutsOpenpay.map(co => co.pedidoID));
                const map = checkOutsOpenpay.reduce<Record<number, IStatusOpenPay[]>>((acc, curr) => {
                    const status = openpayStatus.data?.filter(op => op.pedidoId === curr.pedidoID);
                    if (!acc[curr.pedidoID]) {
                        acc[curr.pedidoID] = [];
                    }
                    acc[curr.pedidoID].push(...(status || []));
                    return acc;
                }, {});
                dispatch(setMiniCheckoutsAll(map));
            }
        }

        await dispatch(clearCheckOutsThunk());
        if (!checkOuts || checkOuts.length === 0) {
            return;
        }
        const { customerIds, customerSellersIds } = checkOuts.reduce((acc, item) => {
            acc.customerIds.push(item.clienteId);
            acc.customerSellersIds.push(item.clienteVendedorId);
            return acc;
        }, {
            customerIds: [] as number[],
            customerSellersIds: [] as number[]
        });
                

        // Fetch getOpenPaystatus 
        await fetchStatusOrders(checkOuts);
        await fetchCustomersData(customerSellersIds, checkOuts);
        await dispatch(addOrdersSummaryAsCheckOutsThunk(checkOuts, selectedOrderSummaryId));
        const responsePriceList = await getPriceListByListOfCustomers(customerIds);
        

        await dbStoreMessage<ICustomerPriceList>({
            db: true,
            table: DBtablesEnum.CustomersPriceList,
            upsert: true,
            method: methods.create,
            dataCreate: responsePriceList.data || [],
        });

    } catch (error) {
        console.error("Error fetching order summaries", error);
    } finally {
        await dispatch(switchLoadingThunk(false));
    }
}

/**
 * Asynchronous function that retrieves and processes customer data related to the checkouts.
 * 
 * @async
 * @param {number[]} customerSellersIds Array of customer seller IDs.
 * @param {IOrderSummary[]} checkOuts Array of order summaries.
 */
const fetchCustomersData = async (customerSellersIds: number[], checkOuts: IOrderSummary[]) => {
    const { getCustomersInfoByIds, getCustomerApplySMC, GetcustomerSellerById } = customerService();

    try {
        const responseCustomersCheckouts = await getCustomersInfoByIds(customerSellersIds);
        if (!responseCustomersCheckouts || !responseCustomersCheckouts.data) {
            throw new Error("Error fetching customer data");
        }

        const dataCustomers: IClienteVendedorCompletoDto[] = [];
        for (const cliente of responseCustomersCheckouts.data) {
            if (cliente.clienteVendedorId) {
                const responseCustomer = await getCustomerApplySMC(cliente.clienteVendedorId);
                const responseCustomerSeller = await GetcustomerSellerById(cliente.clienteVendedorId);

                let AplicaClienteSMC = responseCustomer.data?.aplica;
                if (AplicaClienteSMC === undefined) {
                    const LastInfoCustomer: IClienteVendedorCompletoDto | null = await getCustomerByCustomerId(cliente.clienteId);
                    AplicaClienteSMC = LastInfoCustomer?.AplicaClienteSMC ?? undefined;
                }
                dataCustomers.push({
                    clienteID: cliente.clienteId,
                    clienteVendedorId: cliente.clienteVendedorId,
                    vendedorId: cliente.vendedorId,
                    empleadoId: cliente.empleadoId,
                    nombre: cliente.nombre,
                    nombreVendedor: cliente.vendedor,
                    apellidoPaterno: cliente.apellidoPaterno,
                    apellidoMaterno: cliente.apellidoMaterno,
                    clasificacion: cliente.clasificacion,
                    subClasificacion: cliente.subclasificacion,
                    fechaAlta: cliente.fechaAlta,
                    sucursalId: cliente.sucursalId,
                    sucursal: cliente.sucursal,
                    rfc: cliente.rfc,
                    handheld: cliente.handheld,
                    listaNegraSMC: cliente.listaNegraSMC,
                    esCorporativo: cliente.esCorporativo,
                    AplicaClienteSMC,
                    facturarMenos2000: responseCustomerSeller.data?.facturarMenos2000
                });
            }
        }

        if (dataCustomers.length > 0) {
            await dbStoreMessage<IClienteVendedorCompletoDto>({
                db: true,
                table: DBtablesEnum.Customers,
                upsert: true,
                method: methods.create,
                dataCreate: dataCustomers
            });
        }

        checkOuts.forEach(checkOut => {
            checkOut.detalles?.forEach(detail => {
                detail.stockEnSucursal = '-';
                detail.stockEnSMC = '-';
                detail.stockNacional = '-';
                detail.productoNegado = false;
            });
            const matchingCliente = responseCustomersCheckouts.data?.find(cliente => cliente.clienteId === checkOut.clienteId);
            if (matchingCliente) {
                checkOut.cliente = matchingCliente.nombreEmpresa;
            }
        });

    } catch (error) {
        console.error("Error fetching customer data", error);
    }
}

/**
 * Asynchronous function that retrieves the OpenPay status and validity.
 * @param {IOrderSummary[]} checkOuts Array of order summaries.
 */
const fetchStatusOrders = async (checkOuts: IOrderSummary[]): Promise<IOrderSummary[]> => {
    const { getLinkStatus } = checkoutServices();

    const ordersIds: number[] = checkOuts
        .map(checkOut => (checkOut.estatusID === StatusOrderEnum.OpenPay ? checkOut.pedidoID : null))
        .filter((pedidoID): pedidoID is number => typeof pedidoID === 'number' && pedidoID > 0);
    const miniCheckoutIds: number[] = checkOuts
        .map(checkOut => (checkOut.estatusID === StatusOrderEnum.OpenPay ? checkOut.miniCajaId : null))
        .filter((miniCajaId): miniCajaId is number => typeof miniCajaId === 'number' && miniCajaId > 0);

    if (ordersIds.length === 0 && miniCheckoutIds.length === 0)
        return checkOuts;

    const orderResponse = await getLinkStatus([...ordersIds, ...miniCheckoutIds]);
    if (orderResponse.statusCode !== 200) {
        return checkOuts;
    }
    checkOuts.forEach(order => {
        const status = orderResponse.data?.find((status) => order.miniCajaId === status.pedidoId || order.pedidoID === status.pedidoId);
        order.openPayStatusId = 0;
        order.openPayStatus = false;
        if (status) {
            order.openPayStatusId = status.estatusId;
            order.openPayStatus = true;
            order.openPayVigencia = status.tieneVigencia;
            order.pagados = status.pagados;
        }
    });

    return checkOuts;

}