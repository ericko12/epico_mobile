import { IOrderShipmentSMC4 } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipmentSMC4";
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum";
import { IShippingPreferenceRequest } from "@/features/shipment/domain/interfaces/IShippingPreferenceRequest";

/**
 * Maps order shipment data and purchase order information to a shipping preference request object.
 * 
 * @param orderShipment - The order shipment object containing delivery and payment information from SMC4
 * @param purchaseOrder - The purchase order identifier string
 * @returns An object conforming to IShippingPreferenceRequest interface with mapped shipping preferences
 */
export const mapPreferenceShipmentToRequest = (
    orderShipment: IOrderShipmentSMC4,
    purchaseOrder: string
): IShippingPreferenceRequest => ({
    concesionId: orderShipment?.consecion?.concesionId,
    concesion: orderShipment?.consecion?.concesion!,
    plazo: orderShipment?.consecion?.plazo!,
    metodoPagoId: orderShipment.FormaPago?.metodoPagoId,
    metodoPago: orderShipment.FormaPago?.metodoPago ?? '',
    pue: orderShipment.PUE,
    porteId: orderShipment.PorteId,
    personaRecogera: orderShipment.PersonaRecogera ?? '',
    tipoPersonaRecogera: orderShipment.TipoPersonaRecogera ?? '',
    direccionId: orderShipment.DireccionEntregaId,
    ordenCompra: purchaseOrder,
    envioDireccion: orderShipment.MetodoEnvio === ShippingMethodSMC4Enum.Delivery,
    retencion: orderShipment.Retenciones?.observacion ?? '',
    emailContacto: orderShipment.Email,
    telefonoContacto: orderShipment.Phone,
    opcionSeleccionada: orderShipment.optionChecked
})