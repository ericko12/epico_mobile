import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";

/**
 * Check if the order status indicates it has been payment open pay.
 *
 * @param {StatusOrderEnum} statusOrder - The status of the order to check.
 * @returns {boolean} True if the order status is 'EnviadoSMC', false otherwise.
 */
export const openPayCheckout = (statusOrder: StatusOrderEnum): boolean => statusOrder === StatusOrderEnum.OpenPay;