import { AlertColor } from "@mui/material";
import { AnyAction, ThunkDispatch } from "@reduxjs/toolkit";
import { Dispatch } from "react";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { IMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckout";
import { ILogMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/ILogMiniCheckout";
import { GetOrderShipmentById } from "@/features/checkout/infrastructure/db/OrdersShipmentRepository";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { setloadingEvaluatedSMC } from "@/features/shipment/application/redux/ShipmentSlice";
import { NOTIFICATIONS_SHIPMENT } from "@/features/common/infrastructure/utils/messages/notificationShipment";
import { SMCService } from "@/features/checkout/application/service/smc.services";
import { IConsolidateMiniCheckoutsRequest } from "@/features/checkout/domain/interfaces/smc/IConsolidateMiniCheckoutsRequest";
import { fetchSMCResult } from "@/features/checkout/application/actions/fetchSMCResult";


/**
 * Consolidates mini checkouts based on the provided parameters and updates the application state accordingly.
 * This function handles the consolidation of multiple mini checkouts into a single order, managing the 
 * consolidation request to the SMC service and updating the application state with the results.
 * 
 * The consolidation process includes:
 * 1. Finding the main mini checkout to use as the base
 * 2. Building the consolidation request with shipping/delivery info
 * 3. Sending the request to consolidate the mini checkouts
 * 4. Updating the application state with the consolidated results
 * 5. Showing success/error notifications to the user
 *
 * @async
 * @param {IOrderSummary} orderSummary - Summary information about the order to consolidate
 * @param {boolean} includeMiniCheckout - Whether to include the new mini checkout in consolidation
 * @param {IMiniCheckout[]} miniCheckouts - Array of mini checkouts to be consolidated
 * @param {ILogMiniCheckout} logCheckout - Log information about the current checkout state
 * @param {(message: string, type?: AlertColor) => void} showSnackbar - Function to display notifications
 * @param {(ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>)} dispatch - Redux dispatch function
 * @param {boolean | null} kmsApplied - boolean value that indicates if a product contains kms points (optional if there is no points)
 * @returns {Promise<number>} Promise resolving to the consolidated order ID or original order ID on failure
 */
export const ConsolidateMiniCheckouts = async (
    orderSummary: IOrderSummary,
    includeMiniCheckout: boolean,
    miniCheckouts: IMiniCheckout[],
    logCheckout: ILogMiniCheckout,
    showSnackbar: (message: string, type?: AlertColor) => void,
    dispatch: ThunkDispatch<any, undefined, AnyAction> & Dispatch<AnyAction>,
    kmsApplied?: boolean | null,
): Promise<number> => {
    const { PostConsolidateMiniCheckouts } = SMCService();
    const { data: shipmentData } = await GetOrderShipmentById(orderSummary!.pedidoID);
    const OrigenId = +process.env.NEXT_PUBLIC_ORIGEN_ID!

    const mainMiniCheckout = miniCheckouts.find(mc => mc.principal === true);
    const requestConolidate: IConsolidateMiniCheckoutsRequest = {
        cajaID: mainMiniCheckout!.cajaID,
        OrigenId: OrigenId,
        OrigenIdSMC: OrigenId,
        infoSucursalID: mainMiniCheckout!.infoSucursalID,
        incluirNuevaCaja: includeMiniCheckout,
        prioridad: logCheckout.prioridad,
        aplicoKms: kmsApplied,
        direccionId: shipmentData[0].EnviarPaqueteria?.active
            ? shipmentData[0].EnviarPaqueteria.DireccionPaqueteriaId!
            : shipmentData[0].DireccionEntregaId ?? 0,
    }

    return await handleRequestDto({
        snackBar: showSnackbar,
        response: await PostConsolidateMiniCheckouts(requestConolidate),
        onSuccess: async () => {
            dispatch(setloadingEvaluatedSMC(true))
            showSnackbar("El pedido se ha consolidado Exitosamente", 'success')
            return await fetchSMCResult(orderSummary.pedidoID, orderSummary, showSnackbar, dispatch);
        },
        messages: {
            error: NOTIFICATIONS_SHIPMENT.SMC.CONSOLIDATE_ERROR
        }
    }) || orderSummary.pedidoID
}