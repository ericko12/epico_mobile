import { ICheckOut } from "@/features/checkout/domain/interfaces/checkOut/ICheckOut";
import { InitCheckoutState } from "@/features/checkout/domain/data/InitCheckoutState.data";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { IStatusOpenPay } from "@/features/checkout/domain/interfaces/openpay/IStatusOpenPay";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import {
    createSlice,
    PayloadAction
} from "@reduxjs/toolkit";

/**
 * Slice para manejar el estado de las cajas y sus detalles
 */
const checkOutSlice = createSlice({
    name: 'checkOuts',
    initialState: InitCheckoutState,
    reducers: {
        /**
         * Establece la lista de checkouts en el estado.
         * @param state - El estado actual del slice.
         * @param action - La acción con la lista de checkouts.
         */
        setCheckOutList: (state, action: PayloadAction<ICheckOut[]>) => {
            state.checkOutList = action.payload;
        },

        /**
         * Establece el estado de carga del slice.
         * @param state - El estado actual del slice.
         * @param action - La acción con el estado de carga.
         */
        setLoading: (state, action: PayloadAction<boolean>) => {
            state.loading = action.payload;
        },

        /**
         * Establece el estado de error del slice.
         * @param state - El estado actual del slice.
         * @param action - La acción con el mensaje de error.
         */
        setError: (state, action: PayloadAction<string | null>) => {
            state.error = action.payload;
        },

        /**
         * Establece el resumen del pedido seleccionado.
         * @param state - El estado actual del slice.
         * @param action - La acción con el resumen del pedido.
         */
        setSelectedOrderSummary: (state, action: PayloadAction<IOrderSummary | null>) => {
            state.selectedOrderSummary = action.payload;
        },

        /**
         * pageAuxiliarStates.
         * @param {WritableDraft<ICheckOutState>} state - El estado actual del slice.
         * @param {PayloadAction<{ productCode: string, countProduct: number }>} action - La acción con el resumen del pedido.
         */
        setPageAuxiliarStates: (state, action: PayloadAction<{ productCode: string, countProduct: number }>) => {
            state.pageAuxiliarStates = action.payload;
        },

        /**
         * Actualiza un detalle específico en el resumen del pedido seleccionado por su ID.
         * @param state - El estado actual del slice.
         * @param action - La acción con el ID del detalle y el nuevo detalle.
         */
        setDetailById: (state, action: PayloadAction<{ id: number, newDetail: IOrderSummaryDetail }>) => {
            const { id, newDetail } = action.payload;
            const detalles: IOrderSummaryDetail[] | undefined = state.selectedOrderSummary?.detalles;

            if (detalles === undefined || detalles.length === 0) return;

            const index: number = detalles.findIndex(d => d.pedidoDetalleId === id);

            if (index !== -1) detalles[index] = {
                ...newDetail,
                stockEnSucursal: detalles[index].stockEnSucursal,
                stockEnSMC: detalles[index].stockEnSMC,
                stockNacional: detalles[index].stockNacional,
                productoNegado: detalles[index].productoNegado,
                tipoPrecio: detalles[index].tipoPrecio,
            };
        },

        /**
         * Actualiza el estado de open pay del pedido seleccionado.
         * @param state - El estado actual del slice.
         * @param action - La acción con el ID del detalle y el nuevo detalle.
         */
        setOpenPay: (state, action: PayloadAction<{ status: boolean | undefined, id: number | undefined, openPay: IStatusOpenPay | undefined }>) => {
            const { status, id, openPay } = action.payload;

            if (state.selectedOrderSummary === null) return;

            state.selectedOrderSummary.openPayStatus = status;
            state.selectedOrderSummary.openPayStatusId = id;
            state.selectedOrderSummary.openPay = openPay;
            state.selectedOrderSummary.pagados = openPay?.pagados;
        },

        /**
        * Updates the quotation state with a new historial ID and read-only flag.
        *
        * @param state - The current Redux state slice for quotations.
        * @param action - The dispatched action containing:
        *   - historialId: The ID of the quotation history to be set.
        *   - readOnlyQuotation: A boolean flag indicating if the quotation is in read-only mode.
        */
        setQuotationState: (state, action: PayloadAction<{ historialId: number, readOnlyQuotation: boolean }>) => {
            state.quotationState = action.payload
        }
    },
});

export const actionsCheckout = checkOutSlice.actions;
export default checkOutSlice.reducer;