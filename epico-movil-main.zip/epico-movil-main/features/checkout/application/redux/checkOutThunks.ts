import { ICheckOut } from "@/features/checkout/domain/interfaces/checkOut/ICheckOut";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import {
    Action,
    ThunkAction,
    ThunkDispatch
} from "@reduxjs/toolkit";
import { actionsCheckout } from "@/features/checkout/application/redux/checkOutSlice";
import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { methods } from "@/features/common/domain/enums/CRUD";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { AlertColor } from "@mui/material";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { isExpired } from "@/features/common/infrastructure/actions/isExpired";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";
import { createOrUpdateCheckOut, createOrUpdateCheckOutDetail, deleteCheckOut, deleteOrderDetailPedidoIdDB } from "@/features/checkout/infrastructure/db/CheckOutsRepository";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { searchCheckoutById } from "@/features/checkout/application/actions/searchCheckoutById";



// constants
export let onSelectCheckOut = () => { }
const { patchOrderById } = checkoutServices();
const ACTION_PATCH: string = 'replace';


/**
 * Thunk for validations of setCheckOutList.
 *
 * @param {ICheckOut[]} CheckOuts - List of checkouts to be validated.
 * @param {IOrderSummary | null | undefined} oldOrderSummary - Optional parameter for the previous order summary.
 * @returns {(dispatch: (action: any) => void) => void} - A thunk that dispatches actions after validation.
 */
const setCheckOutListThunk = (CheckOuts: ICheckOut[], oldOrderSummary?: IOrderSummary | null): (dispatch: (action: any) => void) => void => async (dispatch) => {
    const uniqueCheckOuts = Array.from(new Map(CheckOuts.map(item => [item.pedidoID, item])).values());
    const lastActiveIndex = uniqueCheckOuts.findLastIndex(checkOut => checkOut.active);
    const nextValidIndex = uniqueCheckOuts.findLastIndex(checkOut => !checkOut.origenExternoId);
    const updatedCheckOutList: ICheckOut[] = uniqueCheckOuts.map((checkOut, index) => ({
        ...checkOut,
        active: (index === (lastActiveIndex === -1 ? nextValidIndex : lastActiveIndex))
    }));
    const activeCheckOut = updatedCheckOutList.find(checkOut => checkOut.active) || updatedCheckOutList.find(checkOut => !checkOut.origenExternoId);
    if (activeCheckOut) {
        dispatch(setActiveCheckOutThunk(activeCheckOut.pedidoID, oldOrderSummary));
    } else {
        dispatch(actionsCheckout.setSelectedOrderSummary(null));
    }
    dispatch(actionsCheckout.setCheckOutList(updatedCheckOutList));
};

/**
 * Thunk function to set the selected order summary.
 * @param {IOrderSummary | null} orderSummary 
 * @returns {(dispatch: (action: any) => void) => void}
 */
export const setSelectedOrderSummaryThunk = (orderSummary: IOrderSummary | null): (dispatch: (action: any) => void) => void => async (dispatch) => {
    dispatch(actionsCheckout.setSelectedOrderSummary(orderSummary));
};

/**
 * Changes the active status of a checkout by its ID.
 * @param {string} pedidoID - The ID of the checkout to activate.
 * @param {IOrderSummary | null} oldOrderSummary - The previous order information, used to determine if only the order detail changed.
 * @returns {(dispatch: (action: any) => void, getState: () => void) => void} - Thunk function.
 */
export const setActiveCheckOutThunk = (pedidoID: string, oldOrderSummary?: IOrderSummary | null): (dispatch: (action: any) => void) => void => (dispatch) => {
    const numericPedidoID = parseInt(pedidoID.split("-")[1]);
    Promise.all([
        dbStoreMessage<IOrderSummary>({
            db: true,
            table: DBtablesEnum.Checkouts,
            method: methods.read,
            querySelect: { from: DBtablesEnum.Checkouts, where: { pedidoID: numericPedidoID } }
        }),
        dbStoreMessage<IOrderSummaryDetail>({
            db: true,
            table: DBtablesEnum.CheckoutsDetails,
            method: methods.read,
            querySelect: { from: DBtablesEnum.CheckoutsDetails, where: { pedidoID: numericPedidoID } }
        })
    ]).then(([resOrderSummary, resOrderSummaryDetails]) => {
        if (resOrderSummary.hasError || resOrderSummaryDetails.hasError || !resOrderSummary.data.length) {
            throw new Error("Ocurrió un error en index DB");
        }

        let details = resOrderSummaryDetails.data;
        if (numericPedidoID === oldOrderSummary?.pedidoID) {
            details = resOrderSummary.data[0].detalles!.map(detail => {
                const currenProduct = oldOrderSummary!.detalles!.find(detailLine => detailLine.pedidoDetalleId === detail.pedidoDetalleId)
                return {
                    ...detail,
                    productoNegado: currenProduct?.productoNegado,
                    stockEnSucursal: currenProduct?.stockEnSucursal ?? '-',
                    stockEnSMC: currenProduct?.stockEnSMC ?? '-',
                    stockNacional: currenProduct?.stockNacional ?? '-'
                }
            })
        }
        const orderSummary = resOrderSummary.data[0];

        orderSummary.detalles = details;
        dispatch(actionsCheckout.setSelectedOrderSummary(orderSummary));
    }).catch((_error: Error) => {
        dispatch(actionsCheckout.setError("Error al seleccionar la caja activa"));
    });
};

/**
 * Toggles the active status of a checkout by its ID.
 * @param {string} pedidoID - The ID of the checkout to activate or deactivate.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => void} - A thunk function.
 */
export const toggleActiveCheckOutThunk = (pedidoID: string) => async (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => {
    const { checkOutList } = getState().sessionState.checkOutsState;
    const updatedCheckOutList: ICheckOut[] = checkOutList.map(c => ({ ...c, active: c.pedidoID === pedidoID }));
    dispatch(setCheckOutListThunk(updatedCheckOutList));
};

/**
 * Removes a checkout from the list of checkouts by its ID.
 * @param {string} pedidoID - The ID of the checkout to remove.
 * @param {ICheckOut[]} checkOutList - List of checkouts.
 * @param {IOrderSummary | null} oldOrderSummary - The previous order information, used to determine if only the order detail changed.
 * @returns {(dispatch: (action: any) => void) => any} - Thunk function.
 */
export const removeCheckOutThunk = (pedidoID: string, checkOutList: ICheckOut[], oldOrderSummary?: IOrderSummary | null): (dispatch: (action: any) => void) => any => {
    return async (dispatch: (action: any) => void) => {
        await deleteCheckOut(pedidoID);
        const newCheckOutList = checkOutList.filter(
            checkout => checkout.pedidoID !== pedidoID
        );

        const nexCheckoutValid = newCheckOutList.findLast(checkout => !checkout.origenExternoId)
        if (nexCheckoutValid?.pedidoID.startsWith("VTL")) {
            const orderEvaluated = await searchCheckoutById(nexCheckoutValid.pedidoID);
            if (!orderEvaluated) {
                await deleteCheckOut(nexCheckoutValid.pedidoID);
                newCheckOutList.splice(newCheckOutList.findIndex(checkout => checkout.pedidoID === nexCheckoutValid.pedidoID), 1);
            }
        }
        dispatch(setCheckOutListThunk(newCheckOutList, oldOrderSummary));
    };
};

/**
 * Clears the checkouts that start with "ORD" from the list of checkouts.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void>} - Thunk function.
 */
export const clearCheckOutsThunk = (): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void> => {
    return async (dispatch, getState) => {
        const state = getState().sessionState.checkOutsState;

        const filteredCheckOutList = await Promise.all(
            state.checkOutList.map(async (checkOut) => {
                if (checkOut.pedidoID.startsWith("ORD") || (checkOut.pedidoID.startsWith("VTL") && isExpired(checkOut.ts))) {
                    await deleteCheckOut(checkOut.pedidoID);
                    return null;
                }
                return checkOut;
            })
        ).then((list) => list.filter((checkOut): checkOut is ICheckOut => checkOut !== null));

        dispatch(setCheckOutListThunk(filteredCheckOutList));
    };
};

/**
 * Toggles the loading state.
 * @param {boolean} isLoading - Indicates whether it is loading.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any} - Thunk function.
 */
export const switchLoadingThunk = (isLoading: boolean): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any => {
    return async (dispatch: (action: any) => void) => {
        dispatch(actionsCheckout.setLoading(isLoading));
    };
};

/**
 * Sets the onSelectCheckOutNew function.
 *
 * @param {() => void} onSelectCheckOutNew - Function to be called when a new checkout is selected.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any} - Thunk function.
 */
export const setOnSelectCheckOutThunk = (onSelectCheckOutNew: () => void): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any => {
    return async (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => {
        onSelectCheckOut = onSelectCheckOutNew
    }
}


/**
 * Adds an order summary as checkouts.
 * @param {IOrderSummary[]} orderSummaries - The list of order summaries.
 * @param {number | undefined} selectedOrderSummaryId - The ID of the selected order summary.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void>} - Thunk function.
 */
export const addOrdersSummaryAsCheckOutsThunk = (orderSummaries: IOrderSummary[], selectedOrderSummaryId?: number): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void> => {
    return async (dispatch, getState) => {
        const state = getState().sessionState.checkOutsState;
        const newCheckOuts = orderSummaries.map((orderSummary) => ({
            pedidoID: `ORD-${orderSummary.pedidoID}`,
            clienteVendedorId: orderSummary.clienteVendedorId,
            clienteId: orderSummary.clienteId,
            cliente: orderSummary.cliente ?? "",
            ts: `${orderSummary.fecha.split("T")[0]}T${orderSummary.hora || "00:00:00"}`,
            active: (selectedOrderSummaryId || state.selectedOrderSummary?.pedidoID) === orderSummary.pedidoID,
            openPayStatusId: orderSummary.openPayStatusId,
            openPayStatus: orderSummary.openPayStatus,
            origenExternoId: orderSummary.origenExternoId,
            motorDivisionId: orderSummary.motorDivisionId,
            pagados: orderSummary.pagados
        }));
        const checkOutsDetails = orderSummaries.flatMap((item) => item.detalles || []);

        await Promise.all([
            createOrUpdateCheckOut(orderSummaries),
            createOrUpdateCheckOutDetail(checkOutsDetails),
        ]).catch((error) => console.error("Error fetching order summaries", error));

        dispatch(setCheckOutListThunk([...state.checkOutList, ...newCheckOuts]));
        dispatch(actionsCheckout.setLoading(false));
    };
};

/**
 * Adds an order summary as a virtual checkout.
 * @param {IOrderSummary} orderSummary - The order summary.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any} - Thunk function.
 */
export const addOrderSummaryAsVirtualCheckOutThunk = (orderSummary: IOrderSummary): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any => {
    return async (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => {
        const state = getState().sessionState.checkOutsState;

        const virtualCheckOut: ICheckOut = {
            pedidoID: `VTL-${orderSummary.pedidoID}`,
            clienteVendedorId: orderSummary.clienteVendedorId,
            clienteId: orderSummary.clienteId,
            cliente: orderSummary.cliente ?? "",
            ts: `${orderSummary.fecha.split("T")[0]}T${orderSummary.hora || "00:00:00"}`,
            active: true,
        };
        await createOrUpdateCheckOut([orderSummary]);
        dispatch(setCheckOutListThunk([...state.checkOutList, virtualCheckOut]));
    };
};

/**
 * Edits the details of an order.
 *
 * @param {IOrderSummaryDetail[]} details - The details of the order summary to be updated.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any} - Thunk function.
 */
export const updateOrderSummaryDetail = (details: IOrderSummaryDetail[]): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any => {
    return async (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => {
        const { selectedOrderSummary } = getState().sessionState.checkOutsState;

        if (selectedOrderSummary) {

            const updatedDetails = selectedOrderSummary?.detalles?.map(orderDetail => {
                const updatedDetail = details.find(detail => detail.pedidoDetalleId === orderDetail.pedidoDetalleId);
                return updatedDetail ? updatedDetail : orderDetail
            });
            dispatch(actionsCheckout.setSelectedOrderSummary({ ...selectedOrderSummary, detalles: updatedDetails }));
        }
    }
};

/**
 * Thunk to reset the SMC4 stock values ("-") for all details in the selected order summary.
 * Reads the current detalles from state — no stale closure risk.
 */
export const resetStockSMC4Thunk = () => {
    return async (dispatch: Function, getState: Function) => {
        const { selectedOrderSummary } = (getState() as { sessionState: { checkOutsState: ICheckOutState } }).sessionState.checkOutsState;
        if (!selectedOrderSummary?.detalles) return;
        const resetDetails = selectedOrderSummary.detalles.map(detail => ({
            ...detail,
            stockNacional: "-" as const,
            stockEnSucursal: "-" as const,
            stockEnSMC: "-" as const,
        }));
        await dispatch(updateOrderSummaryDetail(resetDetails));
    };
};

/**
 * Thunk to update the summary and details of an order.
 * @param {IOrderSummary} orderSummary - The order summary.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any} - Thunk function.
 */
export const updateOrderSummaryThunk = (orderSummary: IOrderSummary): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any => {
    return async (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => {
        const { selectedOrderSummary, checkOutList } = getState().sessionState.checkOutsState;
        await deleteOrderDetailPedidoIdDB(orderSummary.pedidoID);
        await Promise.all([
            createOrUpdateCheckOut([orderSummary]),
            orderSummary.detalles && orderSummary.detalles.length > 0 && createOrUpdateCheckOutDetail(orderSummary.detalles),
        ]).catch((error) => {
            console.error("Error al actualizar el pedido", error);
        });

        if (selectedOrderSummary?.pedidoID === orderSummary.pedidoID && selectedOrderSummary?.sucursalIdDestino === orderSummary.sucursalIdDestino) {
            orderSummary.cliente = selectedOrderSummary.cliente
            orderSummary.detalles = orderSummary.detalles?.map((detail) => {
                const oldDetail = selectedOrderSummary.detalles?.find((oldDetail) => oldDetail?.pedidoDetalleId === detail.pedidoDetalleId)
                return {
                    ...detail,
                    stockEnSucursal: oldDetail?.stockEnSucursal,
                    stockEnSMC: oldDetail?.stockEnSMC,
                    stockNacional: oldDetail?.stockNacional,
                    productoNegado: oldDetail?.productoNegado
                }
            })
        }

        if (selectedOrderSummary?.pedidoID === orderSummary.pedidoID
            && selectedOrderSummary?.openPayStatus !== orderSummary.openPayStatus
            && selectedOrderSummary?.openPayStatusId !== orderSummary.openPayStatusId) {
            const updatedCheckOutList = checkOutList.map(checkOut =>
                checkOut.pedidoID === `ORD-${selectedOrderSummary.pedidoID}` ?
                    { ...checkOut, openPayStatusId: orderSummary.openPayStatusId, openPayStatus: orderSummary.openPayStatus, pagados: orderSummary.pagados }
                    : checkOut
            )
            dispatch(setCheckOutListThunk(updatedCheckOutList, selectedOrderSummary));
        }
        dispatch(actionsCheckout.setSelectedOrderSummary(orderSummary));
    };
};

/**
 * Thunk to delete the order and update the order details.
 * @param {IOrderSummary} orderSummary - The order summary.
 * @param {number | string} orderDetailId - The ID of the order detail.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void>} - Thunk function.
 */
export const deleteOrderSummaryDetailThunk = (orderSummary: IOrderSummary, pedidoDetalleId: number | string): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void> => {
    return async (dispatch) => {
        try {
            // Replace all order details in local DB with backend-calculated details
            // to avoid stale promotions when switching between checkouts.
            await deleteOrderDetailPedidoIdDB(orderSummary.pedidoID);
            await Promise.all([
                createOrUpdateCheckOut([orderSummary]),
                orderSummary.detalles && orderSummary.detalles.length > 0 && createOrUpdateCheckOutDetail(orderSummary.detalles),
            ]);
            dispatch(actionsCheckout.setSelectedOrderSummary(orderSummary));
        } catch (error) {
            dispatch(actionsCheckout.setError("Error actualizando el pedido"));
        }
    };
};

/**
 * Updates via patch in the database and state.
 *
 * @template T
 * @param {string} nameParam - The name of the parameter to update.
 * @param {IOrderSummary} orderSummary - The order summary to be updated.
 * @param {T} data - The data to update the order summary with.
 * @param {?(message: string, type: AlertColor) => void} [snackBar] - Optional callback to show a snackbar message.
 * @param {?(updatedOrderSummary: IOrderSummary | null) => void} [callback] - Optional callback for the updated order summary.
 * @returns {ThunkAction<Promise<void>, { checkOutsState: ICheckOutState }, unknown, Action>} - Thunk function.
 */
export const updatePatchByParamThunk = <T>(
    nameParam: string,
    orderSummary: IOrderSummary,
    data: T,
    snackBar?: (message: string, type: AlertColor) => void,
    callback?: (updatedOrderSummary: IOrderSummary | null) => void
): ThunkAction<Promise<void>, { checkOutsState: ICheckOutState }, unknown, Action> => {
    return async (dispatch: ThunkDispatch<{ checkOutsState: ICheckOutState }, unknown, Action>) => {
        // call patch
        const res: IResponseDto<IOrderSummary | null> = await patchOrderById(
            orderSummary.pedidoID,
            [{
                op: ACTION_PATCH,
                path: `/${nameParam}`,
                value: data
            }]
        );

        handleRequestDto({
            response: res,
            snackBar: snackBar,
            messages: {
                invalid: 'Actualización invalida revise los datos',
                error: 'Hubo un error al actualizar la orden'
            },
            onSuccess: async () => {
                if (res.data?.pedidoID === undefined)
                    throw new Error('Error al actualizar los datos');

                updateOrderSummaryThunk({
                    ...res.data,
                    cliente: orderSummary.cliente
                });
            }
        });
    }
}

/**
 * Adds an order summary as a checkout in the database.
 * 
 * @param {number} vtlPedidoId - The ID of the VTL order.
 * @param {IOrderSummary} order - The order summary.
 * @returns {(dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void>} - Thunk function.
 */
export const addOrdersSummaryVtlAsCheckOutThunk = (vtlPedidoId: number, order: IOrderSummary): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => Promise<void> => {
    return async (dispatch, getState) => {
        const state = getState().sessionState.checkOutsState;

        const newCheckOut: ICheckOut = {
            pedidoID: `ORD-${order.pedidoID}`,
            clienteId: order.clienteId,
            cliente: order.cliente ?? 'N/A',
            clienteVendedorId: order.clienteVendedorId,
            ts: `${order.fecha.split("T")[0]}T${order.hora || "00:00:00"}`,
            active: true,
            motorDivisionId: order.motorDivisionId
        };

        const checkOutsDetails = order.detalles;

        Promise.all([
            createOrUpdateCheckOut([order]),
            createOrUpdateCheckOutDetail(checkOutsDetails || []),
            deleteCheckOut(`VTL-${vtlPedidoId}`),
        ])
            .then(() => {
                const checkOutList = state.checkOutList.filter(
                    checkout => checkout.pedidoID !== `VTL-${vtlPedidoId}`
                );
                dispatch(setCheckOutListThunk([...checkOutList, newCheckOut]));
            })
            .catch((error) => {
                console.error("Error fetching order summaries", error);
            });
    };
};

/**
 * Adds an order summary as a checkout in the database.
 * 
 * @param {IOrderSummary} order - The order summary.
 * @returns {(dispatch: (action: any) => void) => Promise<void>} - Thunk function.
 */
export const addOrderSummaryDetailThunk = (order: IOrderSummary): (dispatch: (action: any) => void) => Promise<void> => {
    return async (dispatch) => {
        const checkOutsDetails: IOrderSummaryDetail[] = order.detalles ?? [];

        try {
            await createOrUpdateCheckOutDetail(checkOutsDetails)
        } catch (error) {
            console.error("Error fetching order summaries", error);
        }
        dispatch(actionsCheckout.setSelectedOrderSummary(order));
    };
};
/**
 * Thunk action to set the quotation state in the Redux store.
 *
 * Dispatches the `setQuotationState` action with the provided `historyId` and 
 * `readOnlyQuotation` flag to update the quotation-related checkout state.
 *
 * @param {Object} param - Object containing parameters.
 * @param {number} param.historyId - The ID referencing the quotation history.
 * @param {boolean} param.readOnlyQuotation - Whether the quotation should be read-only.
 * @returns {(dispatch: Function, getState: Function) => any} Thunk function that updates the quotation state.
 */
export const setQuotationStateThunk = ({ historialId, readOnlyQuotation }: { historialId: number, readOnlyQuotation: boolean }): (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => any => {
    return async (dispatch: (action: any) => void) => {
        dispatch(actionsCheckout.setQuotationState({ historialId, readOnlyQuotation }));
    };
};



export const setDisableCheckOutThunk = (pedidoID: string) => async (dispatch: (action: any) => void, getState: () => { sessionState: { checkOutsState: ICheckOutState } }) => {
    const { checkOutList } = getState().sessionState.checkOutsState;
    const updatedCheckOutList: ICheckOut[] = checkOutList.map(c => ({ ...c, active: c.pedidoID === pedidoID ? false : c.active }));
    dispatch(actionsCheckout.setSelectedOrderSummary(null));
    dispatch(actionsCheckout.setCheckOutList(updatedCheckOutList));
};
