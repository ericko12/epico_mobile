import { EPICO_API } from "@/axios/axios_helper";
import { handleRequest } from "@/features/common/infrastructure/api/handleRequest";
import { IPatchOp } from "@/features/common/domain/axios/IPatchOp";
import { ISpecialPriceRequest } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceRequest";
import { IRequestForSpecialPriceResponse } from "@/features/checkout/domain/interfaces/specialPrice/IRequestForSpecialPriceResponse";
import { ISpecialPriceResponse } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceResponse";
import { UrlSpecialPriceGet, UrlRequestSpecialPrice, UrlUpdateSpecialPrice } from "@/features/checkout/infrastructure/api/specialPriceUrl";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";


/**
 * Service to handle special price related operations
 * @returns Object containing special price service methods
 */
export const SpecialPriceService = () => {

    /**
      * Function to configure the headers for the request
      * @returns headers
      */
    const configHeaders = () => {
        return { headers: { 'X-OrigenId': OrigenEnum.Epico } };
    }

    /**
     * Creates a new special price request
     * @param reqBody - Request body containing:
     * @returns Response containing the created special price ID
     */
    const postSpecialPriceRequest = (reqBody: ISpecialPriceRequest) =>
        handleRequest<IRequestForSpecialPriceResponse>(
            EPICO_API.post(UrlRequestSpecialPrice(), reqBody)
        );

    /**
     * Gets special price details for multiple products
     * @param specialPriceIds - Array of special price IDs to retrieve
     * @returns Array of special price responses
     */
    const getSpecialPriceRequest = (specialPriceIds: number[]) =>
        handleRequest<ISpecialPriceResponse[]>(
            EPICO_API.get(UrlSpecialPriceGet(specialPriceIds))
        );

    /**
  * Updates a special price request by ID
  * @param specialPriceId - ID of the special price to update
  * @param reqData - Array of patch operations to apply
  * @param orderId - (Optional) The order ID, used when `updateProduct` is true
  * @param orderDetailId - (Optional) The order detail ID, used when `updateProduct` is true
  * @param recordId - (Optional) The record ID (HistorialId), used when `updateProduct` is true
  * @param updateProduct - (Optional) If true, includes all relevant query parameters in the URL
  * @returns Updated special price response
  */
    const patchSpecialPriceById = (specialPriceId: number, reqData: IPatchOp[], orderId?: number, orderDetailId?: number, recordId?: number, updateProduct?: boolean) =>
        handleRequest<ISpecialPriceResponse>(
            EPICO_API.patch(UrlUpdateSpecialPrice(specialPriceId, orderId, orderDetailId, recordId, updateProduct), reqData)
        );

    return {
        postSpecialPriceRequest,
        getSpecialPriceRequest,
        patchSpecialPriceById
    };
};

export type ApiTypePriceList = ReturnType<typeof SpecialPriceService>;