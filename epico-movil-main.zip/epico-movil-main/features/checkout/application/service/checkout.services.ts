import { IResponseAxiosDto, IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { catchResponse } from "@/features/common/domain/axios/catchResponse";
import { EPICO_API } from "@/axios/axios_helper";
import { IPatchOp } from "@/features/common/domain/axios/IPatchOp";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { configHeaders } from "@/features/common/application/service/ConfigHeaders";
import { IStatusOpenPay } from "@/features/checkout/domain/interfaces/openpay/IStatusOpenPay";
import { ISendOrderStatus } from "@/features/checkout/domain/interfaces/ISendOrderStatus";
import { ICustomerPriceList } from "@/features/checkout/domain/interfaces/ICustomerPriceList";
import { urlEmailBankAccounts, UrlGetOrderSummaryByOrderIds, UrlGetOrderSummaryByUser, UrlGetPriceListByListOfCustomers, UrlGetPriceListValidationByCustomer, UrlLStatusOrders, UrlLastInvoicedPrice, UrlPatchOrderById, UrlPostOrder, UrlPostOrderBranch, UrlGetValidarFormatoOrdenCompra, UrlGetGrupoByOrdenCompra  } from "@/features/checkout/infrastructure/api/checkoutUrl";
import { ILastInvoicedPriceData, ILastInvoicedPriceRequest } from "@/features/checkout/domain/interfaces/ILastInvoicedPrice";
import { IOrder } from "@/features/checkout/domain/interfaces/IOrder";
import { IResponseOrder } from "@/features/checkout/domain/interfaces/IResponseOrder";
import { IResponseDB } from "@/features/common/domain/interfaces/dbStore/IResponseDB";
import { methods } from "@/features/common/domain/enums/CRUD";
import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";
import { UrlSmc4Log, UrlSmc4SwitchToSMC3Log, UrlSmc4SwitchToSMC3Reasons } from '@/features/checkout/infrastructure/api/smcUrl';
import { ISmc4Log } from '@/features/checkout/domain/interfaces/smc/Ismc4Log';
import { ISendMiniCheckoutRequestSMC4 } from "@/features/checkout/domain/interfaces/smc4/ISendMiniCheckoutRequestSMC4";
import { IFormatoOrdenCompra } from "@/features/checkout/domain/interfaces/IFormatoOrdenCompra";
import { ISwitchToSMC3LogRequest } from "@/features/checkout/domain/interfaces/smc4/ISwitchToSMC3LogRequest";
import { ISwitchToSMC3Reason } from "@/features/checkout/domain/interfaces/smc4/ISwitchToSMC3Reason";

/**
 * Service to handle the checkout operations.
 * @returns {Object} - The service object containing the checkout operations.
 */
export const checkoutServices = () => {

    /**
     * Sends a request to the API to email a PDF containing bank account details.
     *
     * @async
     * @function SendPDFtoEmailService
     * @param {string} email - The recipient's email address.
     * @returns {Promise<IResponseDto<boolean>>} A promise resolving to the response containing the success status.
     * @throws {any} Returns a handled response in case of an error.
     */
    const sendPdfToEmailService = async (email: string) => {
        try {
            const res: IResponseAxiosDto<IResponseDto<boolean>> = await EPICO_API.post(urlEmailBankAccounts(), email);
            return res.data as IResponseDto<boolean>;
        } catch (error) {
            return catchResponse(error);
        }
    }

    /**
     * Updates the header of an order.
     * @param {string | number} pedidoId - The ID of the order.
     * @param {IPatchOp[]} reqData - Data to be sent for the patch request.
     * @returns {Promise<IResponseDto<{ pedidoId: number } | null>>} - A promise that resolves to an IResponseDto object with the order summary.
     */
    const patchOrderById = async (pedidoId: string | number, reqData: IPatchOp[], historyId?: number) => {
        try {
            const res: IResponseAxiosDto<IResponseDto<IOrderSummary | null>> = await EPICO_API.patch(UrlPatchOrderById(pedidoId, historyId), reqData);
            return res.data as IResponseDto<IOrderSummary | null>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Retrieves the order summary for a user from the previous day.
     * @param {number} userId - The user ID.
     * @param {Array<number>} status - The status of the orders to search for.
     * @returns {Promise<IResponseDto<IOrderSummary[] | null>>} - A promise that resolves to an IResponseDto object containing the order summaries.
     */
    const getOrderSummaryByUserLastDay = async (userId: number, status: Array<number>) => {
        try {
            const res: IResponseAxiosDto<IResponseDto<IOrderSummary[]>> = await EPICO_API.get(UrlGetOrderSummaryByUser(userId, status), configHeaders());
            if (res.status === 204) return catchResponse({ message: "No se encontró contenido" })
            return res.data as IResponseDto<IOrderSummary[] | null>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Retrieves the order summary for a list of order IDs.
     * @param {number[]} ordersIds - Array of order IDs to retrieve summaries for
     * @param {number[]} status - Array of status codes to filter orders by
     * @returns {Promise<IResponseDto<IOrderSummary[] | null>>} - A promise that resolves to an IResponseDto object containing the order summaries
     */
    const getOrderSummaryByOrderIds = async (ordersIds: number[], status: number[]) => {
        try {
            const res: IResponseAxiosDto<IResponseDto<IOrderSummary[]>> = await EPICO_API.get(UrlGetOrderSummaryByOrderIds(ordersIds, status), configHeaders());
            return res.data as IResponseDto<IOrderSummary[] | null>;
        } catch (error) {
            return catchResponse(error);
        }
    };


    /**
     * Function to get the status of the orders with openpay
     * @async
     * @param {ISendLink} sendLink - Datos enviar la liga
     * @returns {Promise<IResponseDto<{ IStatusOpenPay: | null}>>} - Una promesa que devuelve si fue insertado o no.
     */
    const getLinkStatus = async (orders: number[]) => {
        const data: ISendOrderStatus = {
            pedidosIds: orders,
            origenId: 16

        }
        try {
            const res: IResponseAxiosDto<IResponseDto<IStatusOpenPay[] | null>> = (await EPICO_API.post(UrlLStatusOrders(), data, configHeaders()))
            return res.data as IResponseDto<IStatusOpenPay[] | null>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Method to get the price list details for a list of customers.
     * @param customersIds
     * @returns IResponseDto<ICustomerPriceList[]>
     */
    const getPriceListByListOfCustomers = async (customersIds: number[]): Promise<IResponseDto<ICustomerPriceList[] | null>> => {
        try {
            const response: IResponseAxiosDto<IResponseDto<ICustomerPriceList[]>> = await EPICO_API.post(UrlGetPriceListByListOfCustomers(), customersIds);
            return response.data as IResponseDto<ICustomerPriceList[]>;
        } catch (error) {
            return catchResponse(error);
        }
    }

    /**
     * Method to get the price list details for a list of customers.
     * @param customersIds
     * @returns IResponseDto<ICustomerPriceList>
     */
    const getPriceListValidationByCustomer = async (customerId: number): Promise<IResponseDto<ICustomerPriceList | null>> => {
        try {
            const response: IResponseAxiosDto<IResponseDto<ICustomerPriceList>> = await EPICO_API.get(UrlGetPriceListValidationByCustomer(customerId));
            return response.data as IResponseDto<ICustomerPriceList>;
        } catch (error) {
            return catchResponse(error);
        }
    }

    /**
     * Builds the order and sends it to the API.
     *
     * @async
     * @param {IOrder} pedido
     * @returns {IResponseDto<IResponseOrder>}
     */
    const postOrder = async (pedido: IOrder): Promise<IResponseDto<IResponseOrder | null>> => {
        try {
            const res: IResponseAxiosDto<IResponseDto<IResponseOrder>> = await EPICO_API.post(UrlPostOrder(), pedido)
            return res.data as IResponseDto<IResponseOrder>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Gets the customer's price list data from the database.
     * 
     * @param {string | number} customerId - The customer ID to look up
     * @returns {Promise<IResponseDB<ICustomerPriceList>>} A promise that resolves to the customer's price list data
     */
    const getCustomerPriceList = async (customerId: string | number): Promise<IResponseDB<ICustomerPriceList>> => {
        return await dbStoreMessage<ICustomerPriceList>({
            db: true,
            table: DBtablesEnum.CustomersPriceList,
            method: methods.read,
            querySelect: {
                from: DBtablesEnum.CustomersPriceList,
                where: { clienteId: customerId }
            }
        });
    };

    /**
     * Sends a log entry to the SMC4 logging service.
     *
     * @async
     * @param {ISmc4Log} Log - The log entry to send.
     * @returns {Promise<IResponseDto<boolean>>} A promise resolving to the response from the logging service.
     * @throws {any} Returns a handled response in case of an error.
     */
    const postLogSmc4 = async (Log: ISmc4Log): Promise<IResponseDto<boolean | null>> => {
        try {
            const res: IResponseAxiosDto<IResponseDto<boolean>> = await EPICO_API.post(UrlSmc4Log, Log)
            return res.data as IResponseDto<boolean>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Gets the active reasons the user can select to switch the order from SMC 4.0 to SMC 3.
     * A 204 (empty catalog) is returned as a successful response with an empty list.
     *
     * @async
     * @returns {Promise<IResponseDto<ISwitchToSMC3Reason[] | null>>} A promise resolving to the catalog of reasons.
     */
    const getSwitchToSMC3Reasons = async (): Promise<IResponseDto<ISwitchToSMC3Reason[] | null>> => {
        try {
            const res: IResponseAxiosDto<IResponseDto<ISwitchToSMC3Reason[]>> = await EPICO_API.get(UrlSmc4SwitchToSMC3Reasons, configHeaders());
            if (res.status === 204) return { statusCode: 204, data: [], huboError: false, error: { mensaje: '', erroresValidaciones: [] } };
            return res.data as IResponseDto<ISwitchToSMC3Reason[]>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Registers why the user left the SMC 4.0 delivery options to continue the order with SMC 3.
     *
     * @async
     * @param {ISwitchToSMC3LogRequest} body - Reason, observation and SMC 4.0 evaluation trace.
     * @returns {Promise<IResponseDto<number | null>>} A promise resolving to the generated CambioFlujoId.
     */
    const postSwitchToSMC3Log = async (body: ISwitchToSMC3LogRequest): Promise<IResponseDto<number | null>> => {
        try {
            const res: IResponseAxiosDto<IResponseDto<number>> = await EPICO_API.post(UrlSmc4SwitchToSMC3Log, body)
            return res.data as IResponseDto<number>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    /**
     * Posts an order to the branch endpoint.
     * 
     * @async
     * @param {ISendMiniCheckoutRequestSMC4} body - The order object to be submitted to the branch
     * @returns A promise that resolves to a response DTO containing either the order response or null
     * @throws Returns a caught error response if the API call fails
     */
    const postOrderBranch = async (body: ISendMiniCheckoutRequestSMC4): Promise<IResponseDto<number[] | null>> => {
        try {
            const res: IResponseAxiosDto<IResponseDto<number[]>> = await EPICO_API.post(UrlPostOrderBranch(), body)
            return res.data as IResponseDto<number[]>;
        } catch (error) {
            return catchResponse(error);
        }
    };

    const getLastInvoicedPrice = async (body: ILastInvoicedPriceRequest): Promise<IResponseDto<ILastInvoicedPriceData | null>> => {
        try {
            const res: IResponseAxiosDto<IResponseDto<ILastInvoicedPriceData>> = await EPICO_API.post(UrlLastInvoicedPrice(), body);
            return res.data as IResponseDto<ILastInvoicedPriceData | null>;
        } catch (error) {
            return catchResponse(error);
        }
    };

        /**
     * Validates the purchase order format for a customer.
     * @param {number} clienteId - Customer ID.
     * @param {string} ordenCompra - Purchase order value to validate.
     * @param {number} clienteVendedorId - Customer-seller ID.
     * @returns {Promise<any>} A promise resolving to the validation response.
     */
    const getValidarFormatoOrdenCompra = async (clienteId: number, ordenCompra: string, clienteVendedorId: number) => {
        try {
            const res = await EPICO_API.get(UrlGetValidarFormatoOrdenCompra(clienteId, ordenCompra, clienteVendedorId));
            return res.data;
        } catch (error) {
            return catchResponse(error);
        }
    };

    const getGrupoByOrdenCompra = async (clienteId: number, ordenCompra: string, clienteVendedorId: number) => {
        try {
            const res = await EPICO_API.get(UrlGetGrupoByOrdenCompra(clienteId, ordenCompra, clienteVendedorId));
            return res.data;
        } catch (error) {
            return catchResponse(error);
        }
    };
    return {
        sendPdfToEmailService,
        patchOrderById,
        getOrderSummaryByUserLastDay,
        getOrderSummaryByOrderIds,
        getLinkStatus,
        getPriceListByListOfCustomers,
        getPriceListValidationByCustomer,
        postOrder,
        getCustomerPriceList,
        postLogSmc4,
        getSwitchToSMC3Reasons,
        postSwitchToSMC3Log,
        postOrderBranch,
        getLastInvoicedPrice,
        getValidarFormatoOrdenCompra,
        getGrupoByOrdenCompra
    };
}



