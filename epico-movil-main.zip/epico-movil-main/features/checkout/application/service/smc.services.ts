import { IRetentionsRequest } from "@/features/checkout/domain/interfaces/retetion/IRetentionsRequest";
import { IRetentionsResponse } from "@/features/checkout/domain/interfaces/retetion/IRetentionsResponse";
import { EPICO_API } from "@/axios/axios_helper";
import { handleRequest } from "@/features/common/infrastructure/api/handleRequest";
import { configHeadersSMC } from "@/features/common/application/service/ConfigHeaders";
import { UrlDeleteMiniBoxById, UrlEvaluateOrder, UrlGetBranchesInStock, UrlGetResult, UrlPostChangeBranchMiniBoxes, UrlPostConsolidateCheckouts, UrlPostGetCheckOutStockSMC, UrlPostSendMiniCheckout, UrlRecoverLogCheckout, UrlTransferBoxItems, UrlUnshippedCheckouts, UrlValidateRetentions } from "@/features/checkout/infrastructure/api/smcUrl";
import { IEvaluateOrderRequest } from "@/features/checkout/domain/interfaces/smc/IEvaluateOrderRequest";
import { IEvaluateOrder } from "@/features/checkout/domain/interfaces/smc/IEvaluateOrder";
import { IMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckout";
import { IMiniCheckoutResponse } from "@/features/checkout/domain/interfaces/smc/IMiniCheckoutResponse";
import { ItemsEvaluateOrder } from "@/features/checkout/domain/interfaces/smc/ItemsEvaluateOrder";
import { IConsolidateMiniCheckoutsRequest } from "@/features/checkout/domain/interfaces/smc/IConsolidateMiniCheckoutsRequest";
import { IReqUpdateBranch } from "@/features/checkout/domain/interfaces/smc/IReqUpdateBranch";
import { IBranchStockSMC } from "@/features/branch/domain/interfaces/branch/IBranchStockSMC";
import { IStockSMC } from "@/features/products/domain/interfaces/IStockSMC";
import { ISendMiniCheckoutRequest } from "@/features/checkout/domain/interfaces/smc/ISendMiniCheckoutRequest";
import { ISendMiniCheckoutResponse } from "@/features/checkout/domain/interfaces/smc/ISendMiniCheckoutResponse";
import { ILogMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/ILogMiniCheckout";

/**
 *
 * @returns Servicio para consumo de microservice SMCService
 */
export const SMCService = () => {

    /**
     * Función para validar la retenciones del cliente
     * @param body: IRetentionsRequest
     * @returns IResponseDto<IRetentionsResponse>
     */
    const validateRetentions = (body: IRetentionsRequest) =>
        handleRequest<IRetentionsResponse>(
            EPICO_API.post(UrlValidateRetentions, body)
        );

    /**
     * Response to evaluate smc order
     *
     * @param {IEvaluateOrderRequest} requestBody
     * @returns {IResponseDto<IEvaluateOrder>}
     */
    const PostEvaluateOrder = (requestBody: IEvaluateOrderRequest) =>
        handleRequest<IEvaluateOrder>(
            EPICO_API.post(UrlEvaluateOrder, requestBody)
        );

    /**
     * SMC algorithm result detail
     *
     * @param {number} PedidoID
     * @returns {IResponseDto<IMiniCheckoutResponse>}
     */
    const GetResultsSMC = (PedidoID: number) =>
        handleRequest<IMiniCheckoutResponse>(
            EPICO_API.get(UrlGetResult(PedidoID), configHeadersSMC())
        );

    /**
     * Mini checkout status record log
     *
     * @param {number} PedidoID
     * @returns {IResponseDto<ILogMiniCheckout>}
     */
    const GetRecoverLogCheckout = (PedidoID: number) =>
        handleRequest<ILogMiniCheckout>(
            EPICO_API.get(UrlRecoverLogCheckout(PedidoID), configHeadersSMC())
        );

    /**
     * Remove the SMC mini checkouts
     *
     * @param {number} PedidoID
     * @returns {IResponseDto<boolean | {}>}
     */
    const DeleteUnshippedCheckouts = (PedidoID: number, AplicoKms?: boolean | null) =>
        handleRequest<boolean | {}>(
            EPICO_API.delete(UrlUnshippedCheckouts(PedidoID, AplicoKms), configHeadersSMC()));

    /**
     * Consolidate the mini checkouts
     *
     * @param {IConsolidateMiniCheckoutsRequest} requestBody
     * @returns {IResponseDto<IMiniCheckout>}
     */
    const PostConsolidateMiniCheckouts = (requestBody: IConsolidateMiniCheckoutsRequest) =>
        handleRequest<IMiniCheckout>(
            EPICO_API.post(UrlPostConsolidateCheckouts, requestBody)
        );

    /**
     * update the branch on miniBox
     *
     * @param {IReqUpdateBranch} requestBody
     * @returns {IResponseDto<boolean>}
     */
    const PostChangeBranchMiniBoxes = (requestBody: IReqUpdateBranch) =>
        handleRequest<boolean>(
            EPICO_API.post(UrlPostChangeBranchMiniBoxes, requestBody, configHeadersSMC())
        );

    /**
     * Get branches to change the miniBox
     *
     * @param {number} MiniCajaID
     * @param {number} DireccionID
     * @param {number} InfoSucursalID
     * @param {boolean} EsPaqueteria
     * @param {boolean} EsPrincipal
     * @returns {IResponseDto<IBranchStockSMC[]>}
     */
    const GetSucursalesConExistencia = (
        MiniCajaID: number,
        DireccionID: number,
        EsPaqueteria: boolean,
        EsPrincipal: boolean,
        InfoSucursalID?: number
    ) =>
        handleRequest<IBranchStockSMC[]>(
            EPICO_API.get(
                UrlGetBranchesInStock(MiniCajaID, DireccionID, EsPaqueteria, EsPrincipal, InfoSucursalID),
                configHeadersSMC()
            )
        );

    /**
      * Transfiere los productos a otra caja activa
      *
      * @param {number} sourceBoxId - caja origen que transferira los productos (emisor)
      * @param {number} destinationBoxId - caja que recibira la transferencia (receptor)
      * @param {ItemsEvaluateOrder[]} items - productos a transferir
      * @returns {IResponseDto<boolean>}
      */
    const postTransferProducts = (sourceBoxId: number, destinationBoxId: number, items: ItemsEvaluateOrder[], kmsApplied?:boolean | null) => {        
        const data = {
            miniCajaOrigenId: sourceBoxId,
            miniCajaDestinoId: destinationBoxId,
            productos: items,
            aplicoKms:kmsApplied

        };

        return handleRequest<boolean>(
            EPICO_API.post(UrlTransferBoxItems, data, configHeadersSMC())
        );
    };

    /**
      * Elimina la minicaja del pedido
      *
      * @param {number} miniBoxId - caja a eliminar
      * @returns {IResponseDto<boolean>}
      */
    const deleteBoxMiniBoxId = (miniBoxId: number, kmsApplied?: boolean) =>
        handleRequest<boolean>(
            EPICO_API.delete(UrlDeleteMiniBoxById(miniBoxId,kmsApplied), configHeadersSMC())
        );

    /**
     * Response to evaluate smc order
     *
     * @param {IEvaluateOrderRequest} requestBody
     * @returns {IResponseDto<IStockSMC[]>}
     */
    const PostGetCheckOutStockSMC = (requestBody: IEvaluateOrderRequest) =>
        handleRequest<IStockSMC[]>(
            EPICO_API.post(UrlPostGetCheckOutStockSMC, requestBody)
        );

    /**
     * shipping of minicheckouts
     *
     * @param {ISendMiniCheckoutRequest} requestBody
     * @returns {IResponseDto<ISendMiniCheckoutResponse>}
     */
    const PostSendMiniCheckout = (requestBody: ISendMiniCheckoutRequest) =>
        handleRequest<ISendMiniCheckoutResponse>(
            EPICO_API.post(UrlPostSendMiniCheckout, requestBody)
        );

    return {
        validateRetentions,
        PostEvaluateOrder,
        GetResultsSMC,
        GetRecoverLogCheckout,
        DeleteUnshippedCheckouts,
        postTransferProducts,
        PostConsolidateMiniCheckouts,
        GetSucursalesConExistencia,
        PostChangeBranchMiniBoxes,
        deleteBoxMiniBoxId,
        PostGetCheckOutStockSMC,
        PostSendMiniCheckout
    };
}
