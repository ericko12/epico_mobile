import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { IResponseDB } from "@/features/common/domain/interfaces/dbStore/IResponseDB";
import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { methods } from "@/features/common/domain/enums/CRUD";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";

/**
 * Create or update an OrderSummaryDetail in the database.
 * @param {IOrderSummaryDetail[]} dataDetails - List of IOrderSummaryDetail to create or update.
 * @returns {Promise<IResponseDB<IOrderSummaryDetail>>} - A promise that resolves to an IResponseDB object with the result of the create or update operation.
 */
export async function CreateOrUpdateOrderSummaryDetail<T>(dataDetails: IOrderSummaryDetail[]): Promise<IResponseDB<IOrderSummaryDetail>> {
    const response = await dbStoreMessage<IOrderSummaryDetail>({
        db: true,
        table: DBtablesEnum.CheckoutsDetails,
        upsert: true,
        method: methods.create,
        dataCreate: dataDetails,
    });
    return response;
}