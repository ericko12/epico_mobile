import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { methods } from "@/features/common/domain/enums/CRUD";
import { IResponseDB } from "@/features/common/domain/interfaces/dbStore/IResponseDB";
import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";
import { IOrderShipmentShippingForm } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipmentShippingForm";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";

/**
 * Create or update an OrderShipment in the database.
 *
 * @async
 * @param {IOrderShipment[]} orderShipment
 * @returns {Promise<IResponseDB<IOrderShipment>>}
 */
export const CreateOrUpdateOrderShipment = async (orderShipment: IOrderShipment[]): Promise<IResponseDB<IOrderShipment>> => {
    const response = await dbStoreMessage<IOrderShipment>({
        db: true,
        table: DBtablesEnum.Shipments,
        upsert: true,
        method: methods.create,
        dataCreate: orderShipment,
    });
    return response;
}


/**
 * Update an OrderShipment in the database.
 *
 * @async
 * @param {IOrderShipmentShippingForm} orderShipment 
 * @param {number} pedidoID 
 * @returns {Promise<IResponseDB<IOrderShipment>>} 
 */
export const UpdateOrderShipment = async (orderShipment: IOrderShipmentShippingForm, pedidoID: number): Promise<IResponseDB<IOrderShipment>> => {
    const response = await dbStoreMessage<IOrderShipment>({
        db: true,
        table: DBtablesEnum.Shipments,
        method: methods.update,
        queryUpdate: {
            in: DBtablesEnum.CheckoutsDetails,
            set: orderShipment,
            where: { pedidoID: pedidoID }
        }
    });
    return response;
}

/**
 * Updates an OrderShipment in the database by id.
 *
 * @async
 * @param {IOrderShipmentShippingForm} orderShipment
 * @param {number} pedidoID
 * @returns {Promise<IResponseDB<IOrderShipment>>}
 */
export const UpdateOrderShipmentForm = async (orderShipment: IOrderShipment, pedidoID: number): Promise<IResponseDB<IOrderShipment>> => {
    const response = await dbStoreMessage<IOrderShipment>({
        db: true,
        table: DBtablesEnum.Shipments,
        method: methods.update,
        queryUpdate: {
            in: DBtablesEnum.CheckoutsDetails,
            set: orderShipment,
            where: { pedidoID: pedidoID }
        }
    });
    return response;
}

/**
 * Gets all the order data in the database.
 * @param {number} orderId -The ID of the order.
 * @returns {Promise<IResponseDB<IOrderShipment>>} - A promise that resolves to an `IResponseDB` object with the result of the get operation.
 */
export const GetOrderShipmentById = async (orderId: number): Promise<IResponseDB<IOrderShipment>> => {
    const response = await dbStoreMessage<IOrderShipment>({
        db: true,
        table: DBtablesEnum.Shipments,
        upsert: true,
        method: methods.read,
        querySelect: {
            from: DBtablesEnum.Shipments,
            where: { pedidoID: orderId }
        }
    });
    return response;
}

/**
 * Delete a shipment associated with an order in the database.
 * @param {number} pedidoID - The ID of the order.
 * @returns {Promise<IResponseDB<boolean>>} - A promise that resolves to an `IResponseDB` object with the result of the delete operation.
 */
export const deleteOrderShipmentById = async (pedidoID: number): Promise<IResponseDB<boolean>> => {
    return await dbStoreMessage<boolean>({
        db: true,
        table: DBtablesEnum.Shipments,
        method: methods.delete,
        deleteWhere: { pedidoID }
    });
};
