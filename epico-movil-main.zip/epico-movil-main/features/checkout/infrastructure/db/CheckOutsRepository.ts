
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { IResponseDB } from "@/features/common/domain/interfaces/dbStore/IResponseDB";
import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { methods } from "@/features/common/domain/enums/CRUD";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";

/**
 * Creates or updates a checkout in the database.
 * @param {IOrderSummary[]} checkOut - List of order summaries to create or update.
 * @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves to an IResponseDB object with the result of the create or update operation.
 */
export const createOrUpdateCheckOut = async (checkOut: IOrderSummary[]): Promise<IResponseDB<IOrderSummary>> => {
    const data = checkOut.map((item) => ({
        ...item,
        detalles: item.detalles ?? undefined,
    }));
    const response = await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        upsert: true,
        method: methods.create,
        dataCreate: data,
    });
    return response;
};

/**
 * Creates or updates a checkout detail in the database.
 * @param {IOrderSummaryDetail[]} checkOutDetail - List of order details to create or update.
 * @returns {Promise<IResponseDB<IOrderSummaryDetail>>} - A promise that resolves to an IResponseDB object with the result of the create or update operation.
 */
export const createOrUpdateCheckOutDetail = async (checkOutDetail: IOrderSummaryDetail[]): Promise<IResponseDB<IOrderSummaryDetail>> => {
    const response = await dbStoreMessage<IOrderSummaryDetail>({
        db: true,
        table: DBtablesEnum.CheckoutsDetails,
        upsert: true,
        method: methods.create,
        dataCreate: checkOutDetail,
    });
    return response;
};

/**
 * Reads the checkouts of a specific seller and customer.
 * @param {number} cvId - The ID of the seller and customer.
 * @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves to an IResponseDB object with the result of the read operation.
 */
export const readCheckOutBySellerCustomer = async (cvId: number): Promise<IResponseDB<IOrderSummary>> => {
    const response = await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        method: methods.read,
        querySelect: {
            from: DBtablesEnum.Checkouts,
            where: { clienteVendedorId: cvId },
        },
    });
    return response;
};

/**
 * Deletes a checkout by its ID.
 * @param {string} pedidoID - The ID of the order to delete.
 */
export const deleteCheckOut = async (pedidoID: string) => {
    const numericPedidoID = parseInt(pedidoID.split("-")[1]);
    await Promise.all([
        dbStoreMessage({
            db: true,
            table: DBtablesEnum.Checkouts,
            method: methods.delete,
            deleteWhere: { pedidoID: numericPedidoID },
        }),
        dbStoreMessage({
            db: true,
            table: DBtablesEnum.CheckoutsDetails,
            method: methods.delete,
            deleteWhere: { pedidoID: numericPedidoID },
        }),
    ]);
};

/**
 * Deletes an order detail from the database.
 * @param {number} id - The order ID.
 * @param {number | string} pedidoDetalleId - The order detail ID.
 * @returns {Promise<IResponseDB<boolean>>} - A promise that resolves to an IResponseDB object with the result of the delete operation.
 */
export const deleteOrderDetailDB = async (id: number, pedidoDetalleId: number | string): Promise<IResponseDB<boolean>> => {
    return await dbStoreMessage<boolean>({
        db: true,
        table: DBtablesEnum.CheckoutsDetails,
        method: methods.delete,
        deleteWhere: { pedidoID: id, pedidoDetalleId: pedidoDetalleId }
    });
};

/**
 * Deletes the order details from the database.
 * @param {number} id - The order ID.
 * @returns {Promise<IResponseDB<boolean>>} - A promise that resolves to an IResponseDB object with the result of the delete operation.
 */
export const deleteOrderDetailPedidoIdDB = async (id: number): Promise<IResponseDB<boolean>> => {
    return await dbStoreMessage<boolean>({
        db: true,
        table: DBtablesEnum.CheckoutsDetails,
        method: methods.delete,
        deleteWhere: { pedidoID: id, }
    });
};

/**
 * Reads the checkout of an orderId.
 * @param {number} orderId - The order ID.
 * @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves to an IResponseDB object with the result of the read operation.
 */
export const getCheckOutByOrderId = async (orderId: number): Promise<IResponseDB<IOrderSummary>> => {
    const response = await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        method: methods.read,
        querySelect: {
            from: DBtablesEnum.Checkouts,
            where: { pedidoID: orderId },
        },
    });
    return response;
};

/**
 * Gets a checkout by status and cvi.
 * @param {boolean} status - The status of the checkout.
 * @param {number} cvi - The cvi of the checkout.
 * @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves to an IResponseDB object with the result of the read operation.
 */
export const getCheckoutByStatusAndCvid = async (status: StatusOrderEnum, cvid: number) => {
    return await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        method: methods.read,
        querySelect: {
            from: DBtablesEnum.Checkouts,
            where: { estatusID: status, clienteVendedorId: cvid }
        }
    });
};  