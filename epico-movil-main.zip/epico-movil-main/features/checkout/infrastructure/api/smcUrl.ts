// Url para validar retenciones
export const UrlValidateRetentions = `/api/v1/SMCPedido/ValidarRetencion`;
/**
 * Evaluate order in SMC
 *
 * @returns {string}
 */
export const UrlEvaluateOrder = `/api/v1/SMCPedido/EvaluarPedido`;
/**
 * SMC algorithm result detail 
 *
 * @param {number} PedidoID
 * @returns {string}
 */
export const UrlGetResult = (PedidoID: number) => {
    return `/api/v1/SMCPedido/${PedidoID}/ObtenerResultado`;
}
/**
 * Mini checkout status record log
 *
 * @param {number} PedidoID
 * @returns {string}
 */
export const UrlRecoverLogCheckout = (PedidoID: number) => {
    return `/api/v1/SMCPedido/${PedidoID}/RecuperarLogCaja`;
}
/**
 * Remove the SMC mini checkouts
 *
 * @returns {string}
 */
export const UrlUnshippedCheckouts = (PedidoID: number, AplicaKms?:boolean | null) => {
    return `/api/v1/SMCPedido/${PedidoID}/CajasNoEnviadas${AplicaKms ? `?AplicoKms=${AplicaKms}` : ''}`;
}

/**
 * Transfer products to other box
 *
 * @returns {string}
 */
export const UrlTransferBoxItems = `/api/v1/SMCPedido/MoverPartidasDeMiniCajas`;

/**
 * Consolidate the mini checkouts
 *
 * @returns {string}
 */
export const UrlPostConsolidateCheckouts = `/api/v1/SMCPedido/Consolidar`;

/**
 * Url Post Change Branch MiniBoxes
 *
 * @returns {string}
 */
export const UrlPostChangeBranchMiniBoxes = `/api/v1/SMCPedido/CambiarSucursalMiniCajas`;

/**
 * Deltes minibox by id
 * 
 * @param {number} miniBoxId - caja a eliminar
 * @param {boolean?} appliesKms - bandera de si aplico kms
 * @returns {string}
 */
export const UrlDeleteMiniBoxById = (miniBoxId: number, appliesKms?: boolean) => {
    return `/api/v1/SMCPedido/EliminarMiniCaja/${miniBoxId}${appliesKms ? `?AplicoKms=${appliesKms}` : ''}`;
}

/**
 * Url Get Sucursales Con Existencia
 *
 * @param {number} MiniCajaID
 * @param {number} DireccionID
 * @param {number} InfoSucursalID
 * @param {boolean} EsPaqueteria
 * @param {boolean} EsPrincipal
 * @returns {string}
 */
export const UrlGetBranchesInStock = (
    MiniCajaID: number,
    DireccionID: number,
    EsPaqueteria: boolean,
    EsPrincipal: boolean,
    InfoSucursalID?: number
) => {
    return `/api/v1/SMCPedido/ObtenerSucursalesConExistencia?MiniCajaID=${MiniCajaID}${DireccionID ? `&DireccionID=${DireccionID}` : ''}${!DireccionID && InfoSucursalID ? `&InfoSucursalID=${InfoSucursalID}` : ''
        }&EsPaqueteria=${EsPaqueteria}&EsPrincipal=${EsPrincipal}`;
};

/**
 * Url Post To get The Checkout stock in SMC
 *
 * @returns {string}
 */
export const UrlPostGetCheckOutStockSMC = `/api/v1/SMCPedido/RecuperarExistencias`


/**
 * URL shipping of minicheckouts
 *
 * @returns {string}
 */
export const UrlPostSendMiniCheckout = "/api/v1/SMCPedido/EnviarPedido"

/**
 * URL get template massive load
 *
 * @returns {string}
 */
export const UrlTemplateMassiveLoad = `/api/v3/Pedidos/PlantillaCargaMasiva`

/**
 * API endpoint URL for SMC4 logging service.
 * @returns {string}
 */
export const UrlSmc4Log = `/api/v3/SMC4/log`;

/**
 * API endpoint URL to register why the user switched from SMC 4.0 to SMC 3.
 * @returns {string}
 */
export const UrlSmc4SwitchToSMC3Log = `/api/v4/SMC4/CambioFlujoSMC3`;

/**
 * API endpoint URL to get the active reasons to switch from SMC 4.0 to SMC 3.
 * @returns {string}
 */
export const UrlSmc4SwitchToSMC3Reasons = `/api/v4/SMC4/MotivosCambioFlujo?soloActivos=true`;