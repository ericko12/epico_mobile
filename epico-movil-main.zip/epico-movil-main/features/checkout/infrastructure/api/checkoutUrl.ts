/**
 * Constructs the API endpoint for sending bank account details via email.
 *
 * @function UrlEmailBankAccounts
 * @returns {string} The URL endpoint for the email bank accounts API.
 */
export const urlEmailBankAccounts = () => {
    return `/api/v3/Correo/CuentasBancarias`;
}

export const UrlLastInvoicedPrice = () => {
    return `/api/v1/Ventas/producto`;
}

/**
 * Update order by id
 *
 * @param {(number | string)} pedidoId 
 * @returns {string} 
 */
export const UrlPatchOrderById = (pedidoId: number | string, historyId?: number) => {
    return `/api/v3/Pedidos/${pedidoId}${historyId ? `?HistorialId=${historyId}` : ''}`;
}

/**
 * Get orders by id
 *
 * @param {number} userId 
 * @param {Array<number>} status 
 * @returns {string} 
 */
export const UrlGetOrderSummaryByUser = (userId: number, status: Array<number>) => {
    let url = `/api/v3/Pedidos/Resumen?usuarioId=${userId}`;
    if (status.length > 0) {
        const statusParams = status.map(s => `&estatus=${s}`).join('');
        url += statusParams;
    }
    return url;
}

export const UrlGetOrderSummaryByOrderIds = (ordersIds: number[], status: number[]) => {
    let url = '/api/v3/Pedidos/Resumen'

    if (ordersIds.length > 0) {
        const orderIdsParams = ordersIds.map((id, index) => `${index === 0 ? '?' : '&'}ids=${id}`).join('');
        url += orderIdsParams;
    }

    if (status.length > 0) {
        const statusParams = status.map((s, index) => `${(index === 0 && ordersIds.length === 0) ? '?' : '&'}estatus=${s}`).join('');
        url += statusParams;
    }

    return url;
}

/**
 * Function to get the status of an order in OpenPay.
 * @returns {string}
 */
export const UrlLStatusOrders = () => {
    return `/api/v1/Pasarela/Pedidos/Estatus`;
};

/**
 * Generates the URL to fetch the price list details for a list of customers.
 * 
 * @returns {string} The API endpoint URL for retrieving the price list of clients.
 */
export const UrlGetPriceListByListOfCustomers = () => {
    return `/api/v2/Clients/PriceLists`;
}

/**
 * Generates the URL to fetch the price list validation for a specific customer.
 * 
 * @param {number} ClientId - The ID of the customer for whom the price list validation is requested.
 * @returns {string} The API endpoint URL for retrieving the price list validation of the specified client.
 */
export const UrlGetPriceListValidationByCustomer = (ClientId: number) => {
    return `/api/v2/Clients/${ClientId}/PriceListValidation`;
}
/**
 * Returns the URL to post an order.
 * @returns 
 */
export const UrlPostOrder = () => {
    return `/api/v3/Pedidos`;
}

/**
 * Returns the API endpoint URL for posting an order to a branch.
 * 
 * @returns {string} The API v4 endpoint path for branch orders ('/api/v4/PedidoSucursal').
 */
export const UrlPostOrderBranch = () => '/api/v4/PedidoSucursal';

/**
 * Validates the purchase order format for a given customer.
 * @param {number} clienteId - Customer ID.
 * @param {string} ordenCompra - Purchase order value.
 * @param {number} clienteVendedorId - Customer-seller ID.
 * @returns {string} The URL for validating purchase order format.
 */
export const UrlGetValidarFormatoOrdenCompra = (clienteId: number, ordenCompra: string, clienteVendedorId: number): string =>
    `/api/v1/FormatosOrdenCompra/Validar?clienteId=${clienteId}&ordenCompra=${ordenCompra}&clienteVendedorId=${clienteVendedorId}`;

export const UrlGetGrupoByOrdenCompra = (clienteId: number, ordenCompra: string, clienteVendedorId: number): string =>
    `/api/v1/FormatosOrdenCompra/Info?ordenCompra=${ordenCompra}&ClienteVendedorID=${clienteVendedorId}&clienteId=${clienteId}`;