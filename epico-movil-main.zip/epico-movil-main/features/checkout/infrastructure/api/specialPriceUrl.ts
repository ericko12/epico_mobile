
/**
 * Generates the URL for retrieving special price records.
 *
 * - If a single ID is provided, the URL will point directly to that record.
 * - If an array of IDs is provided, the URL will include them as query parameters.
 *
 * @param specialPriceIds - A single special price ID or an array of special price IDs
 * @returns URL string for the GET special price endpoint
 */
export const UrlSpecialPriceGet = (specialPriceIds: number[] | number) => {
    if (typeof specialPriceIds === "number") {
        return `/api/v1/PrecioEspecial/${specialPriceIds}`;
    }

    const queryParams = specialPriceIds.map(id => `precioEspecialIds=${id}`).join('&');
    return `/api/v1/PrecioEspecial?${queryParams}`;
};

/**
 * Generates the URL for updating a special price record.
 *
 * Always includes the `ActualizarProducto` query parameter (`true` or `false`).
 * Optionally includes order-related parameters if provided.
 *
 * @param specialPriceId - The ID of the special price to update
 * @param orderId - (Optional) The order ID
 * @param orderDetailId - (Optional) The order detail ID
 * @param recordId - (Optional) The history record ID (HistorialId)
 * @param updateProduct - (optional)Flag indicating if the product price should be updated
 * @returns URL string for the PATCH special price endpoint
 */
export const UrlUpdateSpecialPrice = (specialPriceId: number, orderId?: number, orderDetailId?: number, recordId?: number, updateProduct?: boolean,) => {

    const queryParams = new URLSearchParams();
    if (orderId) queryParams.append("PedidoId", orderId.toString());
    if (orderDetailId) queryParams.append("PedidoDetalle", orderDetailId.toString());
    if (recordId) queryParams.append("HistorialId", recordId.toString());
    queryParams.append("ActualizarProducto", (updateProduct ?? false).toString());

    const queryString = queryParams.toString();

    return `/api/v2/PrecioEspecial/${specialPriceId}/Epico?${queryString}`;

}

/**
 * Generates the URL for creating a new special price request.
 *
 * @returns URL string for the POST special price endpoint
 */
export const UrlRequestSpecialPrice = () => {
    return `/api/v2/Precioespecial/Epico`;
}