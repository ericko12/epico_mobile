import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { Accordion, AccordionDetails, AccordionSummary, Box, Chip, Stack, Typography } from "@mui/material"
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { BadgeGeneric } from "@/features/common/infrastructure/ui/badge/BadgeGeneric";
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";
import { ArticleCard } from "@/features/common/infrastructure/ui/cards/ArticleCard";
import { ImageCell } from "@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell";
import { IconPromo } from "@/features/common/infrastructure/ui/icons/IconPromo";
import GiftIcon from "@/features/common/infrastructure/ui/icons/GiftIcon";
import { fetchImageProducts } from "@/features/products/application/actions/fetchImageProducts";
import { PromotionTypesEnum } from "@/features/promotions/domain/enums/PromotionTypesEnum";
import { IAccordionDetailMiniCheckoutsSMC4Props } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4.types";
import { AccordionSubSummary } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/accordionSubSummary/AccordionSubSummary";
import { sxChipContainer, sxChipNumberOrder, sxCointAccordionDetail, sxContainerAccordionDetail, sxDecimalAccordionDetail } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4.styles";
import { DataGridServerPagination } from "@/features/common/infrastructure/ui/tables/DataGridServerPagination";
import { COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4.data";
import { sxDataGrid } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.style";
import { CoinFormatter } from "@/features/common/infrastructure/utils/models/CoinFormatter";
import { MiniCheckoutSummarySMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/miniCheckoutSummarySMC4/MiniCheckoutSummarySMC4";
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks";
import { Smc4TypeEventEnum } from "@/features/checkout/domain/enums/Smc4TipoEventoEnum";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { selectOrderShipmentById } from "@/features/shipment/application/redux/ShipmentSelectors";
import { IAuth } from "@/features/auth/domain/interfaces/IAuth";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { NOTIFICATIONS_ORDERS } from "@/features/common/infrastructure/utils/messages/orders";
import { setPurchaseOrderErrorMsj, setPurchaseOrderError, setGrupoOrdenCompra } from "@/features/shipment/application/redux/ShipmentSlice";
import { ordersService } from "@/features/orders/application/services/order.services";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { Fragment, useState, useEffect, useRef, useMemo } from "react";
import { CHECKOUT_MESSAGES } from "@/features/checkout/domain/data/checkoutMessages.data";
import { ModalPurchaseOrder } from "@/features/orders/infraestructure/ui/modalPurchaseOrders/ModalPurchaseOrder";
import { ModalSendOrderSMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/ModalSendOrderSMC4";
import OrderPlacedCorrectly from "@/features/orders/infraestructure/ui/orderPlaced/OrderPlacedCorrectly";
import ModalEndedOrder from "@/features/orders/infraestructure/ui/modalEndedOrder/ModalEndedOrder";
import OrderPlacedError from "@/features/orders/infraestructure/ui/orderPlaced/OrderPlacedError";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { setTelemarketingLeadsList, setTelemarketingLeadsModal } from "@/features/teleMarketingLead/application/redux/telemarketingLeadSlice";
import { InitTeleMarketingLeadSlice } from "@/features/teleMarketingLead/domain/data/redux/InitTeleMarketingLeadSlice";
import { saveShippingPreferencesSMC4 } from "@/features/checkout/application/actions/smc4/saveShippingPreferencesSMC4";
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum";
import { IMiniCheckoutDetailDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDetailDivision";
import { ModalConfirmSMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/ModalConfirmSMC4";
import { IFormSendOrderSMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/IModalSendOrderSMC4.types";
import { SplitBill } from "@/features/common/domain/enums/SplitBill";
import { mapToRequestMiniCheckout } from "@/features/checkout/application/actions/mapRequestSendMiniCheckoutSMC4";
import { PatchOrderSummaryEnum } from "@/features/checkout/domain/enums/PatchCheckoutEnum";
import { UpdateOrderService } from "@/features/orders/application/actions/fetchOrdersAction";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { fetchDivisionSMCById } from "@/features/checkout/application/actions/smc4/fetchDivisionSMCById";
import { loyaltyPlanService } from "@/features/loyaltyPlan/application/service/loyaltyPlanService";
import { customRound } from "@/features/common/infrastructure/utils/numeric";
import { setOrderClosed } from "@/features/loyaltyPlan/application/redux/loyaltyPlanSlice";
import { StatusOrderOpenPayEnum } from "@/features/checkout/domain/enums/StatusOrderOpenPayEnum";
import { IStatusOpenPay } from "@/features/checkout/domain/interfaces/openpay/IStatusOpenPay";
import { IGetPayment } from "@/features/checkout/domain/interfaces/IGetPayment";
import { IOrderShipmentSMC4 } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipmentSMC4";
import { guestCustomers } from "@/features/common/domain/data/guestCustomers";
import { paymentGatewayService } from "@/features/openPay/application/services/paymentGateway.services";
import { BadgePriceSpecial } from "@/features/products/infrastructure/ui/badge/BadgePriceSpecial";
import { ProductService } from "@/features/products/application/service/product.services";
import { divisionServices } from "@/features/shipment/application/services/divisionServices";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { IMiniCheckoutDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision";
import { updateDivisionThunk } from "@/features/shipment/application/redux/ShipmentThunks";
import { AccordionDetailsTransfer } from "@/features/common/infrastructure/ui/accordion/accordionDetailsTransfer/AccordionDetailsTransfer";
import { mapDivisionToBranchOption } from "@/features/shipment/application/utils/mapDivisionToBranchOption";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric";

/**
 * Accordion component that displays detailed mini checkout information for SMC4.
 * 
 * This component renders an expandable accordion that shows branch-specific checkout details,
 * including articles, totals, and delivery method (pickup or home delivery).
 * 
 * @component
 * @param {IAccordionDetailMiniCheckoutsSMC4Props} props - The component props
 * @param {Object} props.checkoutInfo - Information about the checkout including branch and articles
 * @param {Object} props.branchInfo - Information about the branch (currently unused)
 * @param {Object} props.customerInfo - Information about the customer
 * @param {Object} props.customerPriceList - Customer's price list information
 * @param {GenericProduct[]} props.genericProductsDescriptions - List of generic product descriptions for the products in the checkout
 * 
 * @returns {JSX.Element} An accordion component displaying checkout details with expandable content
 */
export const AccordionDetailMiniCheckoutsSMC4: React.FC<IAccordionDetailMiniCheckoutsSMC4Props> = ({
    checkoutInfo,
    branchInfo,
    customerInfo,
    customerPriceList,
    genericProductsDescriptions
}) => {
    //#region Services
    const { postLogSmc4, postOrderBranch, getLinkStatus } = checkoutServices();
    const { getPurchaseOrderRelation } = ordersService();
    const { getKmsConversion } = loyaltyPlanService();
    const { sendWebPay } = paymentGatewayService();
    const { InsertSpecialOrderTlc, GetGenericsProductsTlcIds } = ProductService();
    //#endregion Services

    //#region Hooks
    const { showSnackbar } = useSnackbar();
    const dispatch = useAppDispatch();
    const { isMobileExperience } = useWindowDimensions();
    //#endregion Hooks

    //#region Redux
    const { selectedOrderSummary } = useAppSelector(state => state.sessionState.checkOutsState);
    const { purchaseOrder, purchaseOrderError, formatoOrden, openPay } = useAppSelector(state => state.sessionState.shipmentState);
    const { division } = useAppSelector(state => state.sessionState.shipmentState.miniCheckoutDivision);
    const { customers } = useAppSelector(state => state.sessionState.loyaltyPlanState);
    const currentShippingOrder = useAppSelector(selectOrderShipmentById(selectedOrderSummary?.pedidoID ?? 0));
    const userAuthState: IAuth = useAppSelector(state => state.localState.authState);
    const { telemarketingLeads } = useAppSelector(state => state.localState.telemarketingLeadState);
    //#endregion Redux

    //#region States
    //Order placement
    const [formData, setFormData] = useState<IFormSendOrderSMC4>({
        split: SplitBill.none,
        comment: ''
    })
    //Dialogs
    const [isConfirm, setIsconfirm] = useState(false);
    const [modalPartial, setModalPartial] = useState<boolean>(false);
    const [openModalSend, setOpenModalSend] = useState<boolean>(false);
    const [showSuccessModal, setShowSuccessModal] = useState(false);
    const [orderIdsResponse, setOrderIdsResponse] = useState<number[]>([]);
    const [loadingConfirm, setLoadingConfirm] = useState<boolean>(false);
    const [orderResponse, setOrderResponse] = useState<IResponseDto<number[] | null>>();
    const [moneyValue, setMoneyValue] = useState<number>();
    const [moneyValueWithoutRound, setMoneyValueWithoutRound] = useState<number>();
    const [expanded, setExpanded] = useState<boolean>(false);
    const [updateDivision, setUpdateDivision] = useState<IMiniCheckoutDivision | null>(null);
    const [modalConfirmFormato, setModalConfirmFormato] = useState<boolean>(false);
    const [formatoConfirmMsg, setFormatoConfirmMsg] = useState<string>('');
    const [formatoConfirmTitle, setFormatoConfirmTitle] = useState<string>('');
    const skipFormatValidation = useRef<boolean>(false);
    //#endregion States

    //#region Constants
    const quantity: number = checkoutInfo.enviado ? checkoutInfo.pedidosSucursales?.reduce((acc, pedidoSucursal) => acc + (pedidoSucursal.detalles?.reduce((accDetalle, detalle) => accDetalle + (detalle.cantidad ?? 0), 0) ?? 0), 0) ?? 0 : checkoutInfo.detalles?.reduce((acc, detalle) => acc + (detalle.cantidad ?? 0), 0) ?? 0;
    const formattedSubtotal = new CoinFormatter(checkoutInfo.total);
    const isDelivery = checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Delivery;
    const transferBranch = useMemo(() => mapDivisionToBranchOption(checkoutInfo), [checkoutInfo]);
    //#endregion Constants

    /**
     * Validates the purchase order before processing the checkout.
     * 
     * @async
     * @function handleValidatePurchaseOrder
     * @returns {Promise<void>} A promise that resolves when validation is complete
     */
    const handleValidatePurchaseOrder = async () => {
        if (!skipFormatValidation.current) {
            if (formatoOrden?.obligatorio && purchaseOrder.trim() === '' && formatoOrden.mascara) {
                dispatch(setPurchaseOrderErrorMsj('Orden obligatoria para este cliente'));
                dispatch(setPurchaseOrderError(true));
                showSnackbar('La orden de compra es obligatoria para este cliente', 'warning');
                return;
            }

            if (formatoOrden?.obligatorio && purchaseOrderError && formatoOrden.mascara) {
                showSnackbar('El formato de la orden de compra es incorrecto', 'warning');
                return;
            }

            if (formatoOrden && !formatoOrden.obligatorio && purchaseOrder.trim() === '' && formatoOrden.mascara) {
                setFormatoConfirmTitle('SALIR SIN CAPTURAR ORDEN DE COMPRA')
                setFormatoConfirmMsg('Aún no has capturado la orden de compra. Es posible que en el futuro tengas problemas para relacionar la factura con la orden de compra del cliente.  ¿Está seguro de salir sin capturar la orden de compra? ');
                setModalConfirmFormato(true);
                return;
            }

            if (formatoOrden && !formatoOrden.obligatorio && purchaseOrderError && formatoOrden.mascara) {
                setFormatoConfirmTitle('FORMATO DE ORDEN DE COMPRA INCORRECTO')
                setFormatoConfirmMsg(`El Formato de la orden de compra capturado no corresponde con el formato esperado: ${formatoOrden?.formatoPredefinido}. ¿Desea continuar sin capturar el formato correcto?`);
                setModalConfirmFormato(true);
                return;
            }

            if (!customerInfo?.esCorporativo && purchaseOrderError) {
                showSnackbar(NOTIFICATIONS_ORDERS.PURCHASEORDER.ERROR_PURCHASE_ORDER, "warning");
                return;
            }
            if (
                customerInfo!.esCorporativo &&
                (purchaseOrder === "" || purchaseOrderError)
            ) {
                showSnackbar(NOTIFICATIONS_ORDERS.PURCHASEORDER.NOT_PURCHASE_ORDER, "warning");
                if (purchaseOrder === "")
                    dispatch(setPurchaseOrderErrorMsj("La orden de compra es requerida"));
                return;
            }

            if (
                !customerInfo!.esCorporativo &&
                purchaseOrder === "" &&
                !purchaseOrderError
            ) {
                setOpenModalSend(true);
                return;
            }

            if (division.some(d => d.enviado)) {
                setOpenModalSend(true);
                return;
            }
        }
        skipFormatValidation.current = false;

        if (!purchaseOrder || purchaseOrder.trim() === '') {
            setOpenModalSend(true);
            return;
        }

        // Fetch to validate relation in another order
        const responseOrderRelation = await getPurchaseOrderRelation(purchaseOrder);
        await handleRequestDto<boolean | null, boolean>({
            snackBar: showSnackbar,
            response: responseOrderRelation,
            messages: {
                error: "Error al obtener la relacion de pedidos",
            },
            onSuccess: async () => {
                if (responseOrderRelation.data) {
                    setModalPartial(true);
                    return;
                }
                setOpenModalSend(true);
            },
        });

    }
    useEffect(() => {
        const convertKmsToMoney = async () => {
            try {
                const response = await getKmsConversion(
                    String(selectedOrderSummary?.clienteId ?? 0),
                    checkoutInfo.puntosAplicadosPlanLealtad
                );

                await handleRequestDto({
                    response,
                    messages: {
                        error: "No se pudo recuperar la información del cliente.",
                        invalid: response.error?.mensaje,
                    },
                    onSuccess: async () => {
                        setMoneyValue(customRound(response.data?.data.montoEnPesos || 0));
                        setMoneyValueWithoutRound(response.data?.data.montoEnPesos || 0)
                    },
                    onInvalid: async () => {
                        setMoneyValue(0);
                    },
                    onError: async () => {
                        setMoneyValue(0);
                    },
                });
            } catch (err: any) {
                setMoneyValue(0);
            }
        }
        if (selectedOrderSummary?.clienteId && checkoutInfo?.puntosAplicadosPlanLealtad > 0) {
            convertKmsToMoney();
        } else {
            setMoneyValue(0);
        }
    }, [selectedOrderSummary, checkoutInfo]);

    /**
     * Logs an SMC4 event by sending shipping and order selection data to the analytics endpoint.
    */
    const logEventSmc4 = async (orderIdsResponseLog: number[]) => {
        await postLogSmc4({
            pedidoId: selectedOrderSummary?.pedidoID ?? 0,
            sucursalesIncluidas: division?.map(s => s.infoSucursalId).join(",") || "",
            sucursalId: checkoutInfo.infoSucursalId,
            estadoFincado: orderIdsResponseLog.length === 0 ? "Error" : "Exito",
            PedidoSucursalId: orderIdsResponseLog.join(","),
            tipoEvento: Smc4TypeEventEnum.FINCADO_SUCURSAL,
            usuarioId: userAuthState.userAuth?.userId ?? 0,
            ...((currentShippingOrder?.optionChecked ?? 0) > 0 && { opcionId: currentShippingOrder?.optionChecked ?? 0 })
        })
    }

    /**
     * Handles the confirmation quest for an order.
     * Sets the confirmation state to true when called.
     * 
     * @param {IFormSendOrderSMC4} formModal - The observation string associated with the order confirmation (currently unused)
     * @returns void
     */
    const questConfirmOrder = (formModal: IFormSendOrderSMC4) => {
        setFormData(formModal);
        setIsconfirm(true);
        setOpenModalSend(false);
    }

    /**
     * Handles the order confirmation by simulating backend call with dummy data.
     * Generates random order IDs and shows success modal.
     * 
     * @async
     * @function handleConfirmOrder
     * @returns {Promise<void>}
     */
    const handleConfirmOrder = async () => {
        setLoadingConfirm(true);
        setOrderIdsResponse([]);

        const miniCheckoutNoSends = division.filter(mc => !mc.enviado && mc.pedidoDivididoId !== checkoutInfo.pedidoDivididoId)

        const checkoutOpenPay = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID ?? 0];
        const pendingCheckoutOpenPay = miniCheckoutNoSends.filter(mc => checkoutOpenPay?.some(op => op.pedidoIdDivision === mc.pedidoDivididoId));


        const paymentMethod = await getPaymentMethodSMC4(currentShippingOrder!);
        const request = mapToRequestMiniCheckout(purchaseOrder, formData, checkoutInfo, selectedOrderSummary!, userAuthState.userAuth!, currentShippingOrder!, customerPriceList, paymentMethod);

        const responseSendCheckout = await postOrderBranch(request);

        const setErrorValues = () => {
            setIsconfirm(false);
            setLoadingConfirm(false);
            setOrderResponse(responseSendCheckout);
            logEventSmc4(responseSendCheckout.data ?? []);
            setShowSuccessModal(true)
        }

        await handleRequestDto({
            response: responseSendCheckout,
            onSuccess: async () => {
                if (responseSendCheckout.data == null) {
                    setErrorValues();
                    return;
                }
                //Add the generated IDs
                setOrderIdsResponse(responseSendCheckout.data);

                // Si es origen externo se manda el pago de openpay a sucursal
                if (selectedOrderSummary?.origenExternoId === OrigenEnum.Web) {
                    try {
                        const pedidosGenerados = responseSendCheckout.data ?? [];


                        const webPayRequests = pedidosGenerados.map((pedidoSucursalId) =>
                            sendWebPay({
                                pedidoExternoId: Number(selectedOrderSummary?.pedidoIdExterno),
                                origenId: request.origenId,
                                pedidoSucursalId,
                                sucursalId: request.sucursalIdDestino,
                                clienteVendedorId: request.clienteVendedorId,
                                usuarioId: request.usuarioId
                            })
                        );
                        await Promise.all(webPayRequests);
                    } catch (error) {
                        console.error("Error enviando WebPay SMC4", error);
                    }
                }

                if (selectedOrderSummary === null) {
                    showSnackbar('No fue posible obtener los datos del pedido', 'error');
                    setLoadingConfirm(false);
                    return;
                }

                //Close telemarketing modal if the order is from a walk-in customer
                if (guestCustomers.includes(selectedOrderSummary!.clienteId)) {
                    const newLeadsList = telemarketingLeads.filter(lead => Number(lead.checkoutId?.split('-')[1]) !== selectedOrderSummary.pedidoID);
                    dispatch(setTelemarketingLeadsList(newLeadsList ?? []));
                    dispatch(setTelemarketingLeadsModal(InitTeleMarketingLeadSlice.telemarketingLeadsModal));
                }

                //Update the order status if necessary
                if (miniCheckoutNoSends.length === 0 ||
                    selectedOrderSummary.estatusID !== StatusOrderEnum.OpenPay ||
                    (selectedOrderSummary.estatusID === StatusOrderEnum.OpenPay && !pendingCheckoutOpenPay.length)
                )
                    await UpdateOrderService(selectedOrderSummary, [{ name: PatchOrderSummaryEnum.estatusInternoId, data: miniCheckoutNoSends.length > 0 ? StatusOrderEnum.EnviadoSMC : StatusOrderEnum.Retenido }], showSnackbar, dispatch);

                //save orderShipment, if there are pending mini checkouts
                if (miniCheckoutNoSends.length) {
                    await saveShippingPreferencesSMC4(currentShippingOrder!, purchaseOrder, showSnackbar);
                }
                await logEventSmc4(responseSendCheckout.data ?? []);

                // If the checkout is a TLC (transitory) order, register the generic products for each generated branch order.
                // Resolve the TLC order ID — use the quote origin ID if available, otherwise use the current order ID.
                // Fetch the generic products linked to that TLC order.
                // If generic products exist, retrieve the latest division state to get the real branch order IDs.
                //    - If the division call succeeds and contains branch orders, use those IDs and update local division state.
                //    - Otherwise, fall back to the IDs returned by the checkout response.
                //For each branch order ID, insert a special TLC order record associating it with the branch and its generic products.
                if (checkoutInfo.esTransitorio) {
                    const tlcPedidoId = selectedOrderSummary!.cotizacionIdOrigen ?? selectedOrderSummary!.pedidoID;
                    const genericProducts = await GetGenericsProductsTlcIds(tlcPedidoId);

                    if (genericProducts.data != null && genericProducts.data.length > 0) {
                        const { getDivisionOrder } = divisionServices();
                        const divisionResponse = await getDivisionOrder(
                            selectedOrderSummary!.pedidoID,
                            OrigenEnum.Epico,
                            checkoutInfo.pedidoDivididoId
                        );

                        const insertFallbackTlc = async () => {
                            const allGenericIds = genericProducts.data!.map(item => item.id);
                            await Promise.all(
                                (responseSendCheckout.data ?? []).map(pedidoId =>
                                    InsertSpecialOrderTlc(pedidoId, checkoutInfo.infoSucursalId, allGenericIds)
                                )
                            );
                        };

                        await handleRequestDto({
                            response: divisionResponse,
                            onSuccess: async () => {
                                if (divisionResponse.data?.divisiones?.[0]?.pedidosSucursales?.length) {
                                    const updatedDiv = divisionResponse.data.divisiones[0];
                                    setUpdateDivision(updatedDiv);
                                    await Promise.all(
                                        updatedDiv.pedidosSucursales!.map(pedidoSucursal => {
                                            const productCodesInBranch = new Set(pedidoSucursal.detalles.map(d => d.producto));
                                            const filteredProductIds = genericProducts.data!
                                                .filter(item => productCodesInBranch.has(item.producto))
                                                .map(item => item.id);
                                            return InsertSpecialOrderTlc(
                                                pedidoSucursal.pedidoId,
                                                checkoutInfo.infoSucursalId,
                                                filteredProductIds
                                            );
                                        })
                                    );
                                } else {
                                    await insertFallbackTlc();
                                }
                            },
                            onInvalid: insertFallbackTlc,
                            onError: insertFallbackTlc,
                        });
                    }
                }

                const customer = customers?.[selectedOrderSummary.clienteId!];
                const order = customer?.ordersKms?.[selectedOrderSummary.pedidoID];

                if (order?.kmsInUsePerOrder > 0) {
                    dispatch(
                        setOrderClosed({
                            clientId: String(selectedOrderSummary.clienteId!),
                            orderClosed: true,
                            orderId: String(selectedOrderSummary.pedidoID),
                        })
                    );
                }
                setLoadingConfirm(false);
                setIsconfirm(false);
                setOpenModalSend(false);
                setShowSuccessModal(true);

            },
            onError: () => {
                setErrorValues();
            },
            onInvalid: () => {
                setErrorValues();
            }

        })
    };
    /**
     * Retrieves the payment method information for SMC4 checkout based on order shipment details.
     * 
     * Fetches the current link status for the selected order and determines whether to use OpenPay
     * or the original payment method. If the order status is "Pagado" (Paid), it returns OpenPay
     * configuration with forced pickup enabled; otherwise, returns the original payment method.
     * 
     * @param {IOrderShipmentSMC4} ord - The order shipment details for which to retrieve the payment method
     * @returns A promise that resolves to the payment method configuration object
     * 
     */
    const getPaymentMethodSMC4 = async (ord: IOrderShipmentSMC4): Promise<IGetPayment> => {
        const orderIds: number[] = [selectedOrderSummary!.pedidoID!];
        const linkStatus = await getLinkStatus(orderIds);
        const originalMethod = {
            openPay: false,
            id: ord!.FormaPago!.metodoPagoId!,
            forcePickup: false,
            concessionId: ord.consecion!.concesionId!,
            forcePue: ord!.PUE!
        }
        const id = await handleRequestDto<IStatusOpenPay[] | null, IGetPayment>({
            snackBar: showSnackbar,
            response: linkStatus,
            onSuccess: async () => {
                if (linkStatus.data) {
                    const statusFilter = linkStatus.data.filter(s => (s.pedidoIdDivision === checkoutInfo.pedidoDivididoId))[0];
                    if (statusFilter && statusFilter.estatusId === StatusOrderOpenPayEnum.Pagado) {
                        return {
                            openPay: true,
                            id: statusFilter.esDebito ? 5 : 4,
                            forcePickup: true,
                            concessionId: 15,
                            forcePue: true
                        };
                    } else {
                        return originalMethod;
                    }
                }
            },
        }) || originalMethod;
        return id;
    }
    /**
     * Returns the modal content based on the order response.
     * Shows success or error modal depending on orderIdsResponse.
     * 
     * @returns {JSX.Element} Modal content component
     */
    /**
     * Returns the modal content based on the order response.
     * Shows success or error modal depending on orderIdsResponse.
     * 
     * @returns {JSX.Element} Modal content component
     */
    const getBodyEndedModal = () => {
        const orderId = selectedOrderSummary?.pedidoID ?? 0;

        return orderIdsResponse.length > 0 ?
            <OrderPlacedCorrectly
                orderId={orderId}
                sucursal={checkoutInfo.sucursal}
                ordersGenerated={orderIdsResponse}
                finished={false}
                notFinished={async () => {
                    if (updateDivision) {
                        dispatch(updateDivisionThunk(updateDivision));
                    } else {
                        await fetchDivisionSMCById(selectedOrderSummary!, checkoutInfo.pedidoDivididoId, showSnackbar, dispatch);
                    }
                    setShowSuccessModal(false);
                }}
            />
            :
            <OrderPlacedError
                orderId={orderId}
                sucursal={checkoutInfo.sucursal}
                response={orderResponse}
                isLoading={loadingConfirm}
                handleClick={handleConfirmOrder}
            />
    }
    /**
     * Renderiza un artículo de la mini caja como tarjeta en la experiencia móvil,
     * con los mismos datos que las columnas del DataGrid (imagen, promo/regalo,
     * código, descripción, cantidad e importe con IVA).
     *
     * La columna de descripción de escritorio se recorta a un renglón con puntos
     * suspensivos y deja el texto completo en `title` (un tooltip, que en táctil no
     * existe). Aquí no hace falta: `ArticleCard` envuelve la descripción completa.
     *
     * ⚠️ Esta derivación está duplicada con la de
     * `AccordionDetailMiniCheckoutsSMC4.data.tsx`. El acuerdo entre ambas rutas está
     * fijado en `__tests__/app/features/checkout/miniCheckoutArticleParity.test.tsx`:
     * al cambiar aquí, cambiar allá.
     */
    const renderArticleCard = (row: IMiniCheckoutDetailDivision) => {
        // La columna de imagen compara con `==` y la de descripción con `===` (así
        // quedó en el original): cada una con su regla.
        const generic = genericProductsDescriptions?.find((product) => product.producto == row.producto);
        const genericDescription = genericProductsDescriptions?.find((product) => product.producto === row.producto)?.descripcion;
        const description = genericDescription || row.descripcion;
        const imageNode = (generic && generic.imagenUrl)
            ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={generic.imagenUrl} width={34} height={28} alt={row.descripcion} />
            )
            : (
                <ImageCell producto={row.producto ?? ""} alt={row.descripcion} width={34} height={28} onError={fetchImageProducts} />
            );
        // Misma precedencia que la columna: regalo, promoción y —desde el 3.29.0 del
        // proyecto original— precio especial.
        const badge = (row.gratis && PromotionTypesEnum.ProductoRegalo === row.tipoPromocionId)
            ? <GiftIcon />
            : row.promocionId
                ? <IconPromo />
                : (row.precioEspecialId ?? 0) > 0
                    ? <BadgePriceSpecial />
                    : undefined;
        return (
            <ArticleCard
                key={row.id}
                imageNode={imageNode}
                badge={badge}
                code={row.producto}
                description={description}
                quantity={row.cantidad}
                amount={new CoinFormatter(row.importeConIva).coin}
            />
        );
    };

    return (
        <Fragment>
            < Accordion
                disableGutters
                elevation={0}
                expanded={expanded}
                onChange={(_, isExpanded) => setExpanded(isExpanded)}
                sx={sxContainerAccordionDetail}
            >
                <Box>
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls={"panel-content-" + checkoutInfo.pedidoDivididoId}
                        id={"panel-header-" + checkoutInfo.pedidoDivididoId}
                    >
                        <Stack
                            direction={{ xs: "column", md: "row" }}
                            justifyContent="space-between"
                            useFlexGap
                            rowGap={1}
                            pr={{ xs: 0, md: 5.5 }}
                            width='100%'
                        >
                            <Stack direction="column" spacing={1} sx={{ minWidth: { xs: 0, md: "auto" } }}>
                                {/* Móvil: `useFlexGap` para que la separación sea `gap` y no
                                    `margin-left`. Con el chip de traspasos la fila envuelve, y
                                    el que baja de renglón arrastraba sus 8px de margen: con
                                    `max-width: 100%` se salía justo esa cantidad. */}
                                <Stack alignItems="center" alignContent="center" spacing={{ xs: "8px", md: "20px" }} useFlexGap={isMobileExperience} direction="row" sx={{ flexWrap: { xs: "wrap", md: "nowrap" }, minWidth: { xs: 0, md: "auto" } }}>
                                    <Typography fontSize={FontSizesEnum.Lambda} fontWeight={FontWeightEnum.Bold} color={ColorsEpico.ColorPrimary}>
                                        {checkoutInfo.sucursal}
                                    </Typography>
                                    {checkoutInfo.esTransitorio && (
                                        <BadgeGeneric
                                            label="TLC"
                                            color={ColorsEpico.ColorPurple}
                                            minWidth={isMobileExperience ? "auto" : "192px"}
                                        />
                                    )}
                                    <BadgeGeneric
                                        label={checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup ? 'Pickup' : "Domicilio"}
                                        color={checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup ? ColorsEpico.ColorSecondary : ColorsEpico.ColorPrimary}
                                        minWidth={isMobileExperience ? "auto" : "192px"}
                                    />
                                    {checkoutInfo?.concentrarPedido && (
                                        <Chip
                                            label={CHECKOUT_MESSAGES.includesTransfersWarning}
                                            sx={{
                                                fontSize: FontSizesEnum.Theta,
                                                color: ColorsEpico.ColorRedOpaque,
                                                backgroundColor: ColorsEpico.ColorRed15,
                                                fontWeight: FontWeightEnum.Medium,
                                                borderRadius: '4px',
                                                // Móvil: MUI deja la etiqueta del Chip en un renglón con
                                                // puntos suspensivos, y a 320px el aviso no cabe: se
                                                // leería "Incluye traspasos por falta de ex…". Aquí envuelve.
                                                ...(isMobileExperience && { height: 'auto', maxWidth: '100%' }),
                                                "& .MuiChip-label": {
                                                    fontWeight: FontWeightEnum.Medium,
                                                    ...(isMobileExperience && {
                                                        whiteSpace: 'normal',
                                                        paddingTop: '4px',
                                                        paddingBottom: '4px',
                                                    }),
                                                },
                                            }}
                                        />
                                    )}
                                </Stack>
                                <Typography fontSize={FontSizesEnum.Epsilon}>{branchInfo ? `${branchInfo.calle} ${branchInfo.noExterior} ${branchInfo.noInterior ? `Int. ${branchInfo.noInterior}` : ''}, ${branchInfo.codigoPostal} ${branchInfo.colonia}, ${branchInfo.municipio}, ${branchInfo.estado}, ${branchInfo.pais}` : 'N/D'}</Typography>
                            </Stack>
                            {/* Móvil: a 320px al contenido de la cabecera le quedan ~229px, y
                                "(12 ARTÍCULOS)" más un total de cinco cifras a 24px piden ~243:
                                la flecha del acordeón se salía del borde. Aquí el total baja de
                                renglón (con `gap`, sin arrastrar margen) y se queda a la derecha. */}
                            <Stack direction={"row"} spacing={{ xs: 2, md: 6 }} useFlexGap={isMobileExperience} alignItems="center" justifyContent={{ xs: "space-between", md: "flex-start" }} sx={{ whiteSpace: { xs: "nowrap", md: "inherit" }, ...(isMobileExperience && { flexWrap: "wrap", rowGap: 0.5 }) }}>
                                <Typography
                                    fontWeight={FontWeightEnum.Regular}
                                    color={ColorsEpico.ColorGray}
                                >
                                    {`(${quantity} ${quantity === 1 ? 'ARTÍCULO' : 'ARTÍCULOS'})`}
                                </Typography>
                                <Stack direction='row' sx={isMobileExperience ? { ml: 'auto' } : undefined}>
                                    <Typography
                                        fontWeight={FontWeightEnum.Regular}
                                        color={ColorsEpico.ColorDarkCharcoal}
                                        fontSize={FontSizesEnum.Lambda}
                                        sx={sxCointAccordionDetail}
                                    >
                                        {formattedSubtotal.intCoin}
                                    </Typography>
                                    <Typography
                                        fontWeight={FontWeightEnum.Regular}
                                        color={ColorsEpico.ColorDarkCharcoal}
                                        fontSize={FontSizesEnum.Alpha}
                                        sx={sxDecimalAccordionDetail}
                                    >
                                        {formattedSubtotal.decimal}
                                    </Typography>
                                </Stack>
                            </Stack>
                        </Stack>
                    </AccordionSummary>
                    <Box sx={{ width: "100%" }}>
                        {checkoutInfo.enviado && (
                            <Stack
                                direction="row"
                                gap="5px"
                                flexWrap="wrap"
                                width="98%"
                                onClick={() => setExpanded(prev => !prev)}
                                sx={sxChipContainer}
                            >
                                {checkoutInfo.pedidosSucursales?.map(({ pedidoId }) => (
                                    <Chip
                                        key={pedidoId}
                                        label={`# ${pedidoId}`}
                                        variant="outlined"
                                        clickable={false}
                                        sx={sxChipNumberOrder}
                                    />
                                ))}
                            </Stack>
                        )}
                    </Box>
                    {/* SUB SUMMARY */}
                    <AccordionSubSummary customerId={selectedOrderSummary?.clienteId ?? 0} checkoutInfo={checkoutInfo} totalBranch={checkoutInfo.total} shippingMethod={currentShippingOrder?.MetodoEnvio ?? ShippingMethodSMC4Enum.Delivery} onClick={handleValidatePurchaseOrder} />
                </Box>
                <AccordionDetails>
                    <Box sx={{ height: 'auto' }}>
                        {isMobileExperience ? (
                            !checkoutInfo.enviado ? (
                                <Stack spacing={1} sx={{ px: 0.5, py: 0.5 }}>
                                    {checkoutInfo.detalles?.map(renderArticleCard)}
                                </Stack>
                            ) : (
                                checkoutInfo.pedidosSucursales?.map((pedidoSucursal) => (
                                    <Stack key={pedidoSucursal.pedidoId} spacing={1} mb={1.5} sx={{ minWidth: 0, width: '100%' }}>
                                        <Typography fontSize={FontSizesEnum.Beta} fontWeight={FontWeightEnum.Bold}>ID Pedido #{pedidoSucursal.pedidoId}</Typography>
                                        {pedidoSucursal.detalles?.map(renderArticleCard)}
                                    </Stack>
                                ))
                            )
                        ) : (
                            <Box sx={{
                                height: 'auto',
                                display: 'grid',
                                gridTemplateColumns: '100%',
                                overflow: 'hidden',
                            }}>
                                {!checkoutInfo.enviado ? (
                                    <DataGridServerPagination
                                        columns={COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(genericProductsDescriptions)}
                                        rows={checkoutInfo.detalles}
                                        rowCount={checkoutInfo.detalles?.length}
                                        getRowId={(row: IMiniCheckoutDetailDivision) => `${row.id}`}
                                        hideFooter
                                        sx={{
                                            ...sxDataGrid,
                                            maxWidth: '100%',
                                        }}
                                    />
                                )
                                    : (
                                        checkoutInfo.pedidosSucursales?.map((pedidoSucursal) => (
                                            <Stack key={pedidoSucursal.pedidoId} spacing={1} mb={1} sx={{ minWidth: 0, width: '100%', overflow: 'hidden' }}>
                                                <Typography fontSize={FontSizesEnum.Beta} fontWeight={FontWeightEnum.Bold}>ID Pedido #{pedidoSucursal.pedidoId}</Typography>
                                                <DataGridServerPagination
                                                    columns={COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(genericProductsDescriptions)}
                                                    rows={pedidoSucursal.detalles}
                                                    rowCount={pedidoSucursal.detalles?.length}
                                                    getRowId={(row: IMiniCheckoutDetailDivision) => `${row.id}`}
                                                    hideFooter
                                                    sx={{
                                                        ...sxDataGrid,
                                                        maxWidth: '100%',
                                                    }}
                                                />
                                            </Stack>
                                        )))}

                                {isDelivery && (transferBranch.traspasos?.length ?? 0) > 0 && (
                                    <AccordionDetailsTransfer
                                        transferBranch={transferBranch}
                                        hideStockColumn={true}
                                    />
                                )}
                            </Box>
                        )}
                        {/* Móvil: los traspasos van debajo de las tarjetas. En escritorio
                            viven dentro del grid, como en el original. */}
                        {isMobileExperience && isDelivery && (transferBranch.traspasos?.length ?? 0) > 0 && (
                            <AccordionDetailsTransfer
                                transferBranch={transferBranch}
                                hideStockColumn={true}
                            />
                        )}
                        <MiniCheckoutSummarySMC4
                            subtotal={checkoutInfo.subTotal}
                            ivaTotal={checkoutInfo.ivaTotal}
                            ahorroPromociones={checkoutInfo.ahorroPromocion}
                            ivaBranch={checkoutInfo.iva ? (checkoutInfo.iva * 100) : 0}
                            isWorkshop={!!customers?.[selectedOrderSummary?.clienteId ?? 0]?.customerLoyaltyPlan}
                            total={checkoutInfo.total}
                            kmsApplied={moneyValueWithoutRound}
                        />
                    </Box>
                </AccordionDetails>
            </Accordion>

            {
                modalPartial && (
                    <ModalPurchaseOrder
                        open={modalPartial}
                        onClose={() => setModalPartial(false)}
                        onSave={() => {
                            setModalPartial(false)
                            setOpenModalSend(true);
                        }}
                    />
                )
            }

            {modalConfirmFormato && (
                <ModalGeneric
                    openModal={modalConfirmFormato}
                    titulo={formatoConfirmTitle}
                    regularTitle={false}
                    btnTextSave="Si"
                    btnTextClose="No"
                    onSave={() => {
                        setModalConfirmFormato(false);
                        skipFormatValidation.current = true;
                        handleValidatePurchaseOrder();
                    }}
                    onClose={() => setModalConfirmFormato(false)}
                >
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                    >
                        {formatoConfirmMsg}
                    </Typography>
                </ModalGeneric>
            )}

            {
                openModalSend && (
                    <ModalSendOrderSMC4
                        open={openModalSend}
                        onClose={() => setOpenModalSend(false)}
                        onSave={questConfirmOrder}
                        customerInfo={customerInfo!}
                        checkoutInfo={checkoutInfo}
                    />
                )
            }
            {
                showSuccessModal && (
                    <ModalEndedOrder
                        openModal={showSuccessModal}
                        onClose={async () => {
                            if (updateDivision) {
                                dispatch(updateDivisionThunk(updateDivision));
                            } else {
                                await fetchDivisionSMCById(selectedOrderSummary!, checkoutInfo.pedidoDivididoId, showSnackbar, dispatch);
                            }
                            setShowSuccessModal(false);
                        }}
                    >
                        {getBodyEndedModal()}
                    </ModalEndedOrder>
                )
            }

            {
                isConfirm && <ModalConfirmSMC4
                    open={isConfirm}
                    onSave={handleConfirmOrder}
                    onClose={() => {
                        setIsconfirm(false)
                    }}
                    loading={loadingConfirm}
                    warningMessage={checkoutInfo?.concentrarPedido ? CHECKOUT_MESSAGES.autoTransferWarning : undefined}
                />
            }
        </Fragment >
    )
}