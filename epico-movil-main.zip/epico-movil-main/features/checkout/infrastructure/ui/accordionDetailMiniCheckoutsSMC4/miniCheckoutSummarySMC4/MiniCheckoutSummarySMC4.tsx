import { Box, Stack, Typography } from "@mui/material"
import { IMiniCheckoutSummaryProps } from "@/features/checkout/infrastructure/ui/miniCheckout/miniCheckoutSummary/MiniCheckoutSummary.types";
import { CoinFormatter } from "@/features/common/infrastructure/utils/models/CoinFormatter";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { customRound } from "@/features/common/infrastructure/utils/numeric";

/**
 * MiniCheckoutSummary component
 * 
 * Component that displays the summary section of the mini checkout view.
 * It shows subtotal, discounts, VAT and total amounts.
 * 
 * @param {IMiniCheckoutSummaryProps} props - Component props
 * @param {number} props.subtotal - Total amount before taxes and discounts
 * @param {number} props.ivaTotal - Total VAT (Value Added Tax) amount
 * @param {number} props.ahorroPromociones - Total discounts applied to the order
 * @param {?number} props.ivaBranch - VAT percentage specific to the branch
 * @param {?boolean} props.isWorkshop - Indicates if the checkout is for a workshop
 * @param {?kmsApplied} props.kmsApplied - The ammount of kms applied
 * @returns {JSX.Element} MiniCheckoutSummary component
 */
export const MiniCheckoutSummarySMC4 = ({ subtotal, ivaTotal, ahorroPromociones, ivaBranch, isWorkshop, total = 0,kmsApplied }: IMiniCheckoutSummaryProps) => {
    return (
        <Box sx={{
            paddingX: '32px',
            textAlign: 'right',
            mt: 1,
        }}>
            <Stack direction="row" spacing={5} justifyContent="end">
                <Stack direction="column">
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}

                    >
                        Subtotal
                    </Typography>
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}
                    >
                        Descuentos
                    </Typography>
                    <Typography
                        fontWeight={FontWeightEnum.Bold}
                        fontSize={FontSizesEnum.Delta}
                    >
                        {`I.V.A ${ivaBranch}%`}
                    </Typography>
                    {isWorkshop && <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}
                    >
                        Kms aplicados
                    </Typography>}
                    <Typography
                        fontWeight={FontWeightEnum.Bold}
                        color={ColorsEpico.ColorPrimary}
                        fontSize={FontSizesEnum.Gamma}
                    >
                        TOTAL
                    </Typography>
                </Stack>
                <Stack direction="column">
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}
                    >
                        {new CoinFormatter(subtotal).coin}
                    </Typography>
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}
                    >
                        {(ahorroPromociones > 0 ? "-" : "") + new CoinFormatter(ahorroPromociones).coin}
                    </Typography>
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}
                    >
                        {new CoinFormatter(ivaTotal).coin}
                    </Typography>
                    {isWorkshop && <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Delta}
                    >
                        ${kmsApplied?.toFixed(2) ?? 0.00}
                    </Typography>}
                    <Typography
                        fontWeight={FontWeightEnum.Bold}
                        color={ColorsEpico.ColorPrimary}
                        fontSize={FontSizesEnum.Gamma}
                    >
                        {new CoinFormatter(total -(kmsApplied ?? 0)).coin}
                    </Typography>
                </Stack>
            </Stack>
        </Box>
    )
}
