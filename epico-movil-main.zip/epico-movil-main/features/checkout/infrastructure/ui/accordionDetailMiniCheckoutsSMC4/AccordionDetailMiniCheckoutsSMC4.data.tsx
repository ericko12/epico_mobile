import GiftIcon from "@/features/common/infrastructure/ui/icons/GiftIcon";
import { IconPromo } from "@/features/common/infrastructure/ui/icons/IconPromo";
import { ImageCell } from "@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell";
import { CoinFormatter } from "@/features/common/infrastructure/utils/models/CoinFormatter";
import { fetchImageProducts } from "@/features/products/application/actions/fetchImageProducts";
import { GenericProduct } from "@/features/products/domain/interfaces/IGenericProductList";
import { BadgePriceSpecial } from "@/features/products/infrastructure/ui/badge/BadgePriceSpecial";
import { PromotionTypesEnum } from "@/features/promotions/domain/enums/PromotionTypesEnum";
import { IMiniCheckoutDetailDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDetailDivision";
import { Stack } from "@mui/material";
import { GridColDef } from "@mui/x-data-grid";

/**
 * Generates column definitions for the mini checkouts SMC4 accordion detail grid.
 * 
 * 
 * @param {GenericProduct} genericProductsDescriptions - List of generic product descriptions to be used for rendering product details in the grid.
 * 
 * @returns {GridColDef<IMiniCheckoutDetailDivision>[]} Array of column definitions for the data grid, including:
 * - Image column: Displays product image using ImageCell component
 * - Promotion column: Shows gift or promotion icons based on product promotion type
 * - SKU column: Displays product code
 * - Description column: Shows product description (flexible width)
 * - Quantity column: Displays product quantity
 * - Import with IVA column: Shows formatted price including VAT
 */
// ⚠️ `renderArticleCard` en AccordionDetailMiniCheckoutsSMC4.tsx resuelve estos mismos
// datos por su cuenta. El acuerdo entre ambas rutas está fijado en
// __tests__/app/features/checkout/miniCheckoutArticleParity.test.tsx: al cambiar aquí,
// cambiar allá.
export const COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4 = (
    genericProductsDescriptions: GenericProduct[]
): GridColDef<IMiniCheckoutDetailDivision>[] => [
        {
            headerName: '',
            field: 'imagen',
            sortable: false,
            align: 'center',
            headerAlign: 'center',
            maxWidth: .5,
            renderCell: (({ row }) => {

                let genericProduct: GenericProduct | undefined = genericProductsDescriptions?.find(product => product.producto == row.producto);

                return (
                    (genericProduct && genericProduct.imagenUrl) ?
                        (<img src={genericProduct.imagenUrl} width={34} height={28} />)
                        : (
                            <ImageCell
                                producto={row.producto ?? ""}
                                alt={row.descripcion}
                                width={34}
                                height={28}
                                onError={fetchImageProducts}
                            />
                        )
                )
            })
        },
        {
            headerName: '',
            field: 'promocionId',
            maxWidth: 70,
            align: 'center',
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                if (row.gratis && PromotionTypesEnum.ProductoRegalo === row.tipoPromocionId)
                    return <Stack alignItems="center"><GiftIcon /></Stack>;
                if (row.promocionId)
                    return <Stack alignItems="center"><IconPromo /></Stack>;
                if (row.precioEspecialId > 0)
                    return <BadgePriceSpecial />;
                return null;
            },
        },
        {
            headerName: 'Código',
            field: 'producto',
            minWidth: 10,
            align: 'center',
            headerAlign: 'center',
            sortable: false
        },
        {
            headerName: 'Descripción',
            field: 'descripcion',
            flex: 1,
            minWidth: 500,
            sortable: false,
            renderCell: ({ row }) => {
                const genericProduct = genericProductsDescriptions?.find(product => product.producto === row.producto);
                const description = !genericProduct?.descripcion ? row.descripcion : genericProduct.descripcion;
                return (
                    <div
                        title={description}
                        style={{
                            overflow: 'hidden',
                            whiteSpace: 'nowrap',
                            textOverflow: 'ellipsis',
                            width: '100%',
                        }}
                    >
                        {description}
                    </div>
                );
            }
        },
        {
            headerName: 'Cantidad',
            field: 'cantidad',
            cellClassName: 'actions',
            align: 'center',
            minWidth: 10,
            headerAlign: 'center',
            sortable: false
        },
        {
            headerName: 'Importe con IVA',
            field: 'importeConIva',
            cellClassName: 'actions',
            align: 'center',
            minWidth: 160,
            headerAlign: 'center',
            sortable: false,
            renderCell: ({ row }) => {
                const formattedImporteConIVA = new CoinFormatter(row.importeConIva).coin;
                return (
                    <span>{`${formattedImporteConIVA}`}</span>
                );
            }
        }
    ];
