import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum";
import { IMiniCheckoutDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision";

/**
 * Props for the AccordionSubSummary component.
 * 
 * @interface IAccordionSubSummaryProps
 * @property {number} customerId - The unique identifier of the customer.
 * @property {IMiniCheckoutDivision} checkoutInfo - The branch option information containing checkout details.
 * @property {?number} [totalBranch] - Optional total amount for the branch.
 * @property {ShippingMethodSMC4Enum} shippingMethod - Shipping method selected for the checkout.
 * @property {?function} [onClick] - Optional click handler for the "Enviar mini caja" button.
 */
export interface IAccordionSubSummaryProps {
  customerId: number;
  checkoutInfo: IMiniCheckoutDivision;
  totalBranch?: number;
  shippingMethod: ShippingMethodSMC4Enum;
  onClick?: () => void;
}
