import { Button, Stack } from "@mui/material"
import { sxButtonSendMiniBox, sxContainerAccordionSubHeader, sxLabelsAccordionSubHeader } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/accordionSubSummary/AccordionSubSummary.styles"
import MiniCheckoutDetailPreviewLabel from "@/features/checkout/infrastructure/ui/miniCheckoutsPreview/miniCheckoutDetailPreview/labels/MiniCheckoutDetailPreviewLabel"
import { MapFillIconSVG } from "@/features/common/infrastructure/ui/icons/MapFillIconSVG"
import { IAccordionSubSummaryProps } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/accordionSubSummary/AccordionSubSummary.types"
import { AccessTimeFilled, ContentCopy, LocalShipping } from "@mui/icons-material"
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum"
import { BadgeGeneric } from "@/features/common/infrastructure/ui/badge/BadgeGeneric"
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { guestCustomers } from "@/features/common/domain/data/guestCustomers"
import { formatDistance } from "@/features/common/infrastructure/utils/formatDistance"

/**
 * AccordionSubSummary component displays a summary of checkout information including
 * delivery time, distance, and shipping type when applicable.
 * 
 * @component
 * @param {IAccordionSubSummaryProps} props - The component props
 * @param {number} props.customerId - The unique identifier of the customer.
 * @param {Object} props.checkoutInfo - Object containing checkout details
 * @param {boolean} props.checkoutInfo.pickup - Indicates if the order is for pickup
 * @param {string} [props.checkoutInfo.tiempoEntrega] - Estimated delivery time
 * @param {string} [props.checkoutInfo.distancia] - Distance in kilometers
 * @param {string} [props.checkoutInfo.nombreServicio] - Name of the shipping service
 * @param {number} [props.totalBranch] - Total amount for the branch
 * @param {ShippingMethodSMC4Enum} props.shippingMethod - Shipping method selected for the checkout
 * @param {function} [props.onClick] - Click handler for the "Enviar mini caja" button
 * @returns {React.FC<IAccordionSubSummaryProps>} A React functional component that renders
 * checkout information labels and a submit button for sending the mini box
 */
export const AccordionSubSummary: React.FC<IAccordionSubSummaryProps> = ({
  customerId,
  checkoutInfo,
  totalBranch,
  shippingMethod,
  onClick
}) => (
  <Stack
    direction={{ xs: 'column', md: 'row' }}
    alignItems={{ xs: 'stretch', md: 'center' }}
    justifyContent='space-between'
    gap={{ xs: 1, md: 0 }}
    sx={sxContainerAccordionSubHeader}
  >
    <Stack direction="row" useFlexGap flexWrap="wrap" gap={{ xs: "12px", md: "30px" }} sx={{ minWidth: 0 }}>
      {(checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Delivery) && <MiniCheckoutDetailPreviewLabel
        title={"Entrega estimada:"}
        subtitle={checkoutInfo.tiempoEntrega || "No disponible"}
        icon={<AccessTimeFilled sx={sxLabelsAccordionSubHeader} />}
      />}

      {(checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Delivery
        || (shippingMethod === ShippingMethodSMC4Enum.Delivery && checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup)
        || (shippingMethod === ShippingMethodSMC4Enum.Pickup && checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup && !guestCustomers.includes(customerId) && Number(checkoutInfo.distancia ?? 0) > 0)
      ) && <MiniCheckoutDetailPreviewLabel
          title={"Distancia:"}
          subtitle={formatDistance(checkoutInfo.distancia)}
          icon={<MapFillIconSVG sx={sxLabelsAccordionSubHeader} />}
        />}

      {(checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Delivery) && <MiniCheckoutDetailPreviewLabel
        title={"Tipo de envío:"}
        subtitle={checkoutInfo.tipoServicioEnvio || "No disponible"}
        icon={<LocalShipping sx={sxLabelsAccordionSubHeader} />}
      />}
    </Stack>
    {checkoutInfo.enviado ? (
      < BadgeGeneric
        label={"Enviado"}
        icon={<ContentCopy
          sx={{ fontSize: FontSizesEnum.Gamma, cursor: 'pointer' }}
          onClick={() => {
            const orders = checkoutInfo?.pedidosSucursales?.map(ps => `#${ps.pedidoId}`).join(', ') ?? '';
            navigator.clipboard.writeText(orders);
          }}
        />}
        color={ColorsEpico.ColorGreenLush}
        iconPosition="right"
        minWidth="160px"
      />) : (
      <Button
        variant="contained"
        size="small"
        type="submit"
        disabled={totalBranch === 0}
        sx={sxButtonSendMiniBox}
        onClick={onClick}
      >
        Enviar mini caja
      </Button>
    )}

  </Stack>
);
