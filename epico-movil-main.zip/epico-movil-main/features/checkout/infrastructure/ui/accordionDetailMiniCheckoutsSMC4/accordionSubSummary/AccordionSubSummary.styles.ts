import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { SxProps } from "@mui/material"

export const sxContainerAccordionSubHeader: SxProps = {
  backgroundColor: ColorsEpico.ColorSkyBlue,
  minHeight: '46px',
  height: { xs: 'auto', md: '46px' },
  marginX: '16px',
  paddingX: { xs: '12px', md: '20px' },
  paddingY: { xs: '10px', md: 0 },
  marginBottom: '5px',
  borderRadius: '10px'
}

export const sxLabelsAccordionSubHeader: SxProps = {
  color: ColorsEpico.ColorPrimary,
  fontSize: FontSizesEnum.Beta
}

export const sxButtonSendMiniBox: SxProps = {
  margin: 0,
  borderRadius: 1,
  fontSize: FontSizesEnum.Gamma,
  fontWeight: FontWeightEnum.Medium,
  background: ColorsEpico.ColorPrimary,
  color: ColorsEpico.ColorWhite,
  width: { xs: "100%", md: "13rem" },
  '&.Mui-disabled': {
    backgroundColor: ColorsEpico.ColorPrimaryDisabled,
    color: ColorsEpico.ColorWhite
  },
}