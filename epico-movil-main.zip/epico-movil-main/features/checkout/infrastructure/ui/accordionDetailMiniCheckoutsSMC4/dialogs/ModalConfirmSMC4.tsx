import { IModalConfirmSMC4Props } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/ModalConfirmSMC4.types"
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric"
import { Stack, Typography } from "@mui/material"

/**
 * A modal dialog component for confirming mini checkout actions in SMC4.
 * 
 * @component
 * @param {IModalConfirmSMC4Props} props - The component props
 * @param {boolean} props.open - Controls the visibility of the modal dialog
 * @param {Function} props.onSave - Callback function triggered when the save action is performed
 * @param {Function} props.onClose - Callback function triggered when the modal is closed
 * @param {boolean} [props.loading] - Optional prop to indicate if a loading state should be displayed
 * @param {string} [props.warningMessage] - Optional prop to display a warning message in the modal
 * @returns {JSX.Element} A generic modal component configured for mini checkout confirmation
 */
export const ModalConfirmSMC4: React.FC<IModalConfirmSMC4Props> = ({
  open,
  onSave,
  onClose,
  loading,
  warningMessage
}) => {
  return (
    <ModalGeneric
      openModal={open}
      titulo="confirmar pedido"
      onSave={onSave}
      onClose={loading ? () => { } : onClose}
      btnTextClose="Cancelar"
      btnTextSave="Aceptar"
      isLoading={loading}
    >
      <Stack direction="column" mb={3}>
        <Typography
          fontWeight={FontWeightEnum.Medium}
        >
          Verifica los artículos, método de pago  y envío para una mejor experiencia para el cliente.
        </Typography>
        {warningMessage && (
          <Typography
            fontWeight={FontWeightEnum.Medium}
            color={ColorsEpico.ColorRedOpaque}
          >
            {warningMessage}
          </Typography>
        )}
      </Stack>
      <Typography
        fontWeight={FontWeightEnum.Bold}
      >
        ¿Estas seguro que deseas confirmar el pedido?
      </Typography>
    </ModalGeneric>
  )
}
