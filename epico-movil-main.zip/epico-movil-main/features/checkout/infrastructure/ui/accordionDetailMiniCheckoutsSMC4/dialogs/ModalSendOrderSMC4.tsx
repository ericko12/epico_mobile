'use client'

import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric"
import { IFormSendOrderSMC4, IModalSendOrderSMC4Props } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/IModalSendOrderSMC4.types"
import { FormSendOrder } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/forms/FormSendOrder"
import { ChangeEvent, useEffect, useState } from "react"
import { SplitBill } from "@/features/common/domain/enums/SplitBill"
import { StatusOrderOpenPayEnum } from "@/features/checkout/domain/enums/StatusOrderOpenPayEnum"
import { IStatusOpenPay } from "@/features/openPay/domain/interfaces/IStatusOpenPay"
import { IShipmentState } from "@/features/shipment/domain/interfaces/IShipmentState"
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks"
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState"
import { updateOrderSummaryThunk } from "@/features/checkout/application/redux/checkOutThunks"
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum"
import { checkoutServices } from "@/features/checkout/application/service/checkout.services"
import { IPatchOp } from "@/features/common/domain/axios/IPatchOp"
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout"
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto"
import { paymentGatewayService } from "@/features/openPay/application/services/paymentGateway.services"
import { useSnackbar } from "@/context/snackBar/SnackBarContext"
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic"
import { setMiniCheckoutsAllMerge } from "@/features/shipment/application/redux/ShipmentSlice"

/**
 * Modal component for sending an order in SMC4 checkout flow.
 * Displays order information preview and allows users to confirm or cancel the order submission.
 * 
 * @param {Object} props - Component props
 * @param {boolean} props.open - Controls the visibility of the modal
 * @param {() => void} props.onClose - Callback function triggered when the modal is closed or cancelled
 * @param {() => void} props.onSave - Callback function triggered when the order is confirmed
 * @param {ICheckoutInfo} props.checkoutInfo - Information about the checkout including order details
 * @param {ICalculateTotalsBranch} props.totalsBranch - Calculated totals for the branch associated with the checkout
 * @param {ICustomer} props.customerInfo - Information about the customer placing the order
 * 
 * @returns {JSX.Element} A modal dialog with order information form and confirmation controls
 */
export const ModalSendOrderSMC4: React.FC<IModalSendOrderSMC4Props> = ({
    checkoutInfo,
    open,
    onClose,
    onSave,
    customerInfo
}) => {
    //#region Hooks
    const { showSnackbar } = useSnackbar();
    //#endregion Hooks
    //#region Redux
    const dispatch = useAppDispatch();
    const { selectedOrderSummary }: ICheckOutState = useAppSelector(state => state.sessionState.checkOutsState);
    const { openPay }: IShipmentState = useAppSelector(state => state.sessionState.shipmentState);
    const divisiones = useAppSelector(state => state.sessionState.shipmentState.miniCheckoutDivision.division);
    
    //#endregion Redux
    //#region constants
    const miniCheckoutOpenPay: IStatusOpenPay | undefined = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID!]?.find(op => op.pedidoIdDivision === checkoutInfo.pedidoDivididoId);
    //#endregion constants
    //#region services
    const { patchOrderById } = checkoutServices();
    const { deletePaymentLink } = paymentGatewayService();
    //#endregion services
    //#region States
    const [formData, setFormData] = useState<IFormSendOrderSMC4>({
        split: SplitBill.none,
        comment: ''
    })
    const [openPayPendingDisabled, setOpenPayPendingDisabled] = useState<boolean>(miniCheckoutOpenPay?.estatusId === StatusOrderOpenPayEnum.Pendiente && miniCheckoutOpenPay.tieneVigencia)
    const [checked, setChecked] = useState<boolean>(false);
    const [isExternalPaid, setIsExternalPaid] = useState<boolean>(false);

    //#endregion States
    /**
     * Handles checkbox state changes and updates order status accordingly.
     * 
     * When the checkbox is unchecked and the selected order has OpenPay status,
     * determines the appropriate new status based on OpenPay payment status and 
     * division shipment status, then patches the order with the new status.
     * 
     * @param  {ChangeEvent<HTMLInputElement>} event  - The change event from the checkbox input element
     * @returns {Promise<void>} A promise that resolves after the order update is processed
     */
    const handleChange = async (event: ChangeEvent<HTMLInputElement>) => {
        setChecked(event.target.checked);

        if (selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay && !event.target.checked) {
            const isOpenPay = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID!]?.find(op => op.pedidoIdDivision === checkoutInfo.pedidoDivididoId);

            if (!isOpenPay) return;

            const someStatusOpenPayPaid = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID!]?.filter(op => op.pedidoIdDivision !== checkoutInfo.pedidoDivididoId && (op.estatusId === StatusOrderOpenPayEnum.Pagado || op.estatusId === StatusOrderOpenPayEnum.Pendiente));
            const finalStatus = someStatusOpenPayPaid.length ? StatusOrderEnum.OpenPay : divisiones?.some(d => d.enviado === true) ? StatusOrderEnum.EnviadoSMC : StatusOrderEnum.Activo;

            const responseDelete = await deletePaymentLink(isOpenPay.ligaId);

            await handleRequestDto({
                response: responseDelete,
                snackBar: showSnackbar,
                messages: {
                    error: GENERIC_ERROR_MESSAGE_CAE,
                    invalid: GENERIC_ERROR_MESSAGE_CAE
                },
                onSuccess: async () => {
                    const bodyOrder: IPatchOp[] = [{ path: 'EstatusInternoId', op: 'replace', value: finalStatus.toString() }];
                    const res = await patchOrderById(selectedOrderSummary.pedidoID, bodyOrder);
                    handleRequestDto({
                        response: res,
                        onSuccess: () => {
                            if (res.data?.pedidoID === undefined)
                                throw new Error(NOTIFICATIONS_CHECKOUT.ORDER.UPDATE_ERROR);
                            dispatch(setMiniCheckoutsAllMerge({ [isOpenPay.pedidoId]: someStatusOpenPayPaid }));
                            dispatch(updateOrderSummaryThunk({ ...res.data, cliente: selectedOrderSummary.cliente, openPayStatus: finalStatus === StatusOrderEnum.OpenPay }));
                            setChecked(false);
                        }
                    });
                },
            });
        }
    }


    useEffect(() => {
        init();
    }, [])

    useEffect(() => {
        const currentOpenMiniCheckout: IStatusOpenPay | undefined = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID!]?.find(op => op.pedidoIdDivision === checkoutInfo.pedidoDivididoId);

        if (selectedOrderSummary?.openPayStatus === undefined && selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay) {
            setOpenPayPendingDisabled(true);
            return;
        }
        if (isExternalPaid) {
            setOpenPayPendingDisabled(false);
            return;
        }
        if (checked) {
            setOpenPayPendingDisabled(currentOpenMiniCheckout ? (currentOpenMiniCheckout?.estatusId !== StatusOrderOpenPayEnum.Pagado) : false);
        } else if (!checked) {
            setOpenPayPendingDisabled(checked)
        }
    }, [openPay.MiniCheckoutsAll, checked, selectedOrderSummary?.openPayStatus])

    /**
     * Initializes the form data by determining the appropriate split billing option.
     */
    const init = () => {
        const newSplit = customerInfo.facturarMenos2000 && checkoutInfo.total > 2000 ? SplitBill.dosMil : formData.split || SplitBill.none;
        setFormData({ ...formData, split: newSplit });
    }
    return (
        <ModalGeneric
            titulo="información previa del pedido"
            btnTextClose="Cancelar"
            btnTextSave="Confirmar pedido"
            btndisabledSave={isExternalPaid ? false : openPayPendingDisabled}
            btnWidthSave="214px"
            width="800px"
            openModal={open}
            onClose={onClose}
            onSave={() => onSave(formData)}
        >
            <FormSendOrder
                checkoutInfo={checkoutInfo}
                formData={formData}
                setFormData={setFormData}
                handleChange={handleChange}
                checked={checked}
                setChecked={setChecked}
                setIsExternalPaidGlobal={setIsExternalPaid}
            />
        </ModalGeneric>
    )
}