import { Fragment, useEffect, useRef, useState } from "react"
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { sxCheckBoxStyle, sxLabelStyle, inputSx } from "@/features/shipment/infrastructure/ui/deliveryAddress/DeliveryAddress.styles"
import { Stack, Typography, FormControlLabel, Checkbox, TextField, Radio, RadioGroup, Button, Tooltip } from "@mui/material"
import { SplitBill } from "@/features/common/domain/enums/SplitBill"
import { useAppSelector } from "@/features/common/application/redux/hooks"
import { selectOrderShipmentById } from "@/features/shipment/application/redux/ShipmentSelectors"
import { FormSendOrderProps } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/forms/FormSendOrder.types"
import { initialRadioOptionsSMC4 } from "@/features/shipment/infrastructure/ui/formShippingProviderSMC4/forms/FormShippingContactDetails.data"
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum"
import { StatusOrderOpenPayEnum } from "@/features/checkout/domain/enums/StatusOrderOpenPayEnum"
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto"
import { IStatusOpenPay } from "@/features/openPay/domain/interfaces/IStatusOpenPay"
import { SecurityProjectService } from "@/features/branch/application/actions/securityProjectService"
import { useSnackbar } from "@/context/snackBar/SnackBarContext"
import { SendLinkOpenPayMiniCheckOutSMC4 } from "@/features/checkout/infrastructure/ui/sendCheckout/SendLinkOpenPayMiniCheckOutSMC4/SendLinkOpenPayMiniCheckOutSMC4"
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum"
import { ConcessionsEnum } from "@/features/common/domain/enums/ConcessionsEnum"
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum"
import { paymentGatewayService } from "@/features/openPay/application/services/paymentGateway.services";
import { CHECKOUT_MESSAGES } from "@/features/checkout/domain/data/checkoutMessages.data";
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";

/**
 * FormSendOrder Component
 * 
 * A form component that displays order shipping and payment details for the checkout process.
 * This component renders information about concession, payment method, delivery method, branch office,
 * and invoice splitting options.
 * 
 * @component
 * @param {FormSendOrderProps} props - The component props
 * @param {IFormSendOrderSMC4} props.formData - The current state of the form data for sending the order
 * @param {Dispatch<SetStateAction<IFormSendOrderSMC4>>} props.setFormData - State setter function to update the form data
 * 
 * @returns {JSX.Element} A form fragment containing order details and configuration options
 */
export const FormSendOrder: React.FC<FormSendOrderProps> = ({
    checkoutInfo,
    formData,
    setFormData,
    handleChange,
    checked,
    setChecked,
    setIsExternalPaidGlobal
}) => {
    //#region Redux
    const { selectedOrderSummary } = useAppSelector(state => state.sessionState.checkOutsState);
    const { purchaseOrder } = useAppSelector(state => state.sessionState.shipmentState);
    const { openPay } = useAppSelector(state => state.sessionState.shipmentState);
    const { showSnackbar } = useSnackbar();
    const { getLinkStatus } = paymentGatewayService();
    const currentShippingOrder = useAppSelector(selectOrderShipmentById(selectedOrderSummary?.pedidoID ?? 0));
    const isExternalOriginPaid = (selectedOrderSummary?.estatusInternoId === StatusOrderEnum.OpenPay || selectedOrderSummary?.estatusInternoId === StatusOrderEnum.EnviadoSMC) &&
        selectedOrderSummary?.origenExternoId === OrigenEnum.Web;

    //#endregion Redux

    // #region services
    const { ProjectActiveInSucursal } = SecurityProjectService();
    // #endregion services

    //#region Hooks
    const radioOptionsRef = useRef(initialRadioOptionsSMC4);
    const { isMobileExperience } = useWindowDimensions();
    //#endregion Hooks

    //#region States
    const [onModal, setOnModal] = useState<boolean>(false);
    const [disableCheckOpenPay, setDisableCheckOpenPay] = useState<boolean>(true);
    const [isPayedWithOpenPay, setIsPayedWithOpenPay] = useState({
        status: false,
        methodPayment: ConcessionsEnum.debito
    });
    const [isExternalPaid, setIsExternalPaid] = useState<boolean>(false);
    const [loadingExternal, setLoadingExternal] = useState<boolean>(false);

    //#endregion States

    //#region Constants
    const totalCheckout = checkoutInfo?.total ?? 0;
    const canSplit2000 = totalCheckout > 2000;
    const canSplit5000 = totalCheckout > 5000;
    const miniCheckoutOpenPay: IStatusOpenPay | undefined = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID!]?.find((op: IStatusOpenPay) => op.pedidoIdDivision === checkoutInfo.pedidoDivididoId);
    const hasTransfers = (checkoutInfo.traspasos?.length ?? 0) > 0;

    //#endregion Constants

    /**
     * Initializes the form by checking OpenPay branch activation and mini checkout payment status.
     * Sets the checkbox state and disables the OpenPay option based on branch availability and order payment status.
     * 
     * @returns {Promise<void>} A promise that resolves when initialization is complete.
     */
    const init = async (): Promise<void> => {

        if (isExternalPaid) {
            setDisableCheckOpenPay(true);
            setChecked(true);
            return;
        }

        if (selectedOrderSummary?.openPayStatus === undefined && selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay) {
            setDisableCheckOpenPay(true)
            return
        }
        const openPayBranch = await onOpenPayActive(+checkoutInfo.infoSucursalId!);
        const currentMiniCheckoutOpenPay: IStatusOpenPay | undefined = openPay.MiniCheckoutsAll[selectedOrderSummary?.pedidoID!]?.find((op: IStatusOpenPay) => op.pedidoIdDivision === checkoutInfo.pedidoDivididoId);
        if (!isExternalPaid) {
            setChecked((openPayBranch && currentMiniCheckoutOpenPay?.estatusId ? true : false));
        }

        setIsPayedWithOpenPay({
            status: currentMiniCheckoutOpenPay?.estatusId === StatusOrderOpenPayEnum.Pagado,
            methodPayment: currentMiniCheckoutOpenPay?.estatusId === StatusOrderOpenPayEnum.Pagado ? currentMiniCheckoutOpenPay.esDebito ? ConcessionsEnum.debito : ConcessionsEnum.credito : ConcessionsEnum.debito
        });
        setDisableCheckOpenPay(
            !openPayBranch
            || currentMiniCheckoutOpenPay?.estatusId === StatusOrderOpenPayEnum.Pagado
            || (currentMiniCheckoutOpenPay?.estatusId === StatusOrderOpenPayEnum.Pendiente && currentMiniCheckoutOpenPay.tieneVigencia || currentShippingOrder?.consecion?.concesionId !== 15)
        );
    };

    /**
     * Validates if OpenPay payment method is active for a given branch.
     * Makes a request to check if the OpenPay project is enabled for the specified branch ID.
     * CEDIS branch (distribution center) is always excluded from OpenPay payments.
     *
     * @async
     * @param {number} branchId - ID of the branch to validate OpenPay availability
     * @returns {Promise<boolean>} True if OpenPay is active for the branch, false otherwise
     */
    const onOpenPayActive = async (branchId: number): Promise<boolean> => {
        if (branchId === (+process.env.NEXT_PUBLIC_SUCURSAL_CEDIS!)) return false;

        const response = await ProjectActiveInSucursal(parseInt(process.env.NEXT_PUBLIC_OPENPAY_OBJETOID!), branchId);

        return ((await handleRequestDto({
            snackBar: showSnackbar,
            response: response,
            onSuccess: () => {
                return response.data || false;
            },
            messages: {
                error: 'Hubo un problema al validar si la sucursal admite pagos mediante Open Pay',
                invalid: 'La sucursal seleccionada no admite pagos mediante Open Pay',
            },
        })) || false);
    };

    useEffect(() => {
        init();
    }, [openPay.MiniCheckoutsAll, selectedOrderSummary?.openPayStatus, isExternalPaid]);

    useEffect(() => {
        const validateExternalPayment = async () => {
            if (!isExternalOriginPaid) return;
            try {
                setLoadingExternal(true);
                const res = await getLinkStatus([
                    Number(selectedOrderSummary?.pedidoIdExterno)
                ]);
                if (res.data && res.data.length > 0) {
                    const found = res.data[0];
                    if (found?.estatusId === StatusOrderOpenPayEnum.Pagado) {
                        setIsExternalPaid(true);
                        setChecked(true);
                        setIsExternalPaidGlobal?.(true);
                    }
                }

            } catch (error) {
                console.error("Error validando OpenPay externo", error);
            } finally {
                setLoadingExternal(false);
            }
        };
        validateExternalPayment();
    }, []);

    useEffect(() => {
        if (hasTransfers && formData.split !== SplitBill.none) {
            setFormData(prev => ({ ...prev, split: SplitBill.none }));
        }
    }, [hasTransfers, formData.split, setFormData]);

    return (
        <Fragment>
            {/* Las tres filas del formulario eran de dos columnas en cualquier ancho:
                en un teléfono cada campo se quedaba con la mitad de 336px y la etiqueta
                se partía en tres renglones al lado del control. En móvil se apilan. */}
            <Stack direction={{ xs: 'column', md: 'row' }} justifyContent="space-between" spacing={2}>
                <Stack sx={{ width: '100%' }}>
                    <Typography
                        sx={{ textTransform: "uppercase", mb: 1 }}
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Gamma}
                    >
                        CONCESIÓN
                    </Typography>
                    <TextField
                        disabled
                        fullWidth
                        name="inputConcession"
                        id="inputConcession"
                        value={isPayedWithOpenPay.status ? 'Contado 0' : `${currentShippingOrder?.consecion?.concesion} - ${currentShippingOrder?.consecion?.plazo}`}
                        variant="outlined"
                        sx={{
                            width: '100%',
                        }}
                        slotProps={{
                            input: {
                                sx: inputSx,
                            }
                        }}
                    />
                </Stack>
                <Stack sx={{ width: '100%' }}>
                    <Typography
                        sx={{ textTransform: "uppercase", mb: 1 }}
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Gamma}
                    >
                        FORMA DE PAGO
                    </Typography>
                    <TextField
                        disabled
                        fullWidth
                        name="inputPaymentMethod"
                        value={isPayedWithOpenPay.status ? isPayedWithOpenPay.methodPayment : currentShippingOrder?.FormaPago?.metodoPago}
                        variant="outlined"
                        sx={{
                            width: '100%',
                        }}
                        slotProps={{
                            input: {
                                sx: inputSx,
                            }
                        }}
                    />
                </Stack>
            </Stack>
            <FormControlLabel
                control={<Checkbox
                    disabled
                    checked={isPayedWithOpenPay.status ? false : !!currentShippingOrder?.PUE}
                    sx={sxCheckBoxStyle}
                />}
                label={
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        fontSize={FontSizesEnum.Gamma}
                        color={ColorsEpico.ColorDarkCharcoal}
                    >
                        Método de pago PUE (Pago en una sola exhibición)
                    </Typography>
                }
            />
            <Stack sx={{ width: '100%' }}>
                <Typography
                    sx={{ textTransform: "uppercase", mb: 1 }}
                    fontWeight={FontWeightEnum.Regular}
                    fontSize={FontSizesEnum.Gamma}
                >
                    Método de entrega
                </Typography>
                <TextField
                    disabled
                    fullWidth
                    name="inputPaymentMethod"
                    value={checkoutInfo.metodoEnvio === ShippingMethodSMC4Enum.Pickup ? "Pickup" : "Envío a domicilio"}
                    variant="outlined"
                    sx={{
                        width: '100%',
                    }}
                    slotProps={{
                        input: {
                            sx: inputSx,
                        }
                    }}
                />

                <Stack direction={"column"} spacing={1} width="100%" mt={1}>
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        color={ColorsEpico.ColorDarkCharcoal}
                        fontSize={FontSizesEnum.Gamma}
                        sx={{ ...sxLabelStyle, height: '100%' }}
                    >
                        Sucursal
                    </Typography>

                    <TextField
                        disabled
                        fullWidth
                        name="inputName"
                        value={checkoutInfo.sucursal}
                        variant="outlined"
                        sx={{
                            width: '100%',
                        }}
                        slotProps={{
                            input: {
                                sx: inputSx,
                            }
                        }}
                    />
                </Stack>

                {currentShippingOrder?.TipoPersonaRecogera && <Stack direction={"column"} spacing={1} width="100%" mt={1}>
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        color={ColorsEpico.ColorDarkCharcoal}
                        fontSize={FontSizesEnum.Gamma}
                        sx={{ ...sxLabelStyle, height: '100%' }}
                    >
                        Persona que recogerá
                    </Typography>
                    <RadioGroup
                        name="person-who-collects"
                        sx={{
                            display: "flex",
                            flexDirection: "row",
                            alignItems: "center",
                        }}
                        value={currentShippingOrder.TipoPersonaRecogera}
                    >
                        {radioOptionsRef.current.map((option) => (
                            <FormControlLabel
                                disabled
                                key={option.value}
                                value={option.value}
                                control={<Radio />}
                                label={option.label}
                                sx={{ marginRight: "5%" }}
                            />
                        ))}
                    </RadioGroup>
                    <TextField
                        disabled
                        fullWidth
                        name="inputName"
                        value={currentShippingOrder.PersonaRecogera}
                        variant="outlined"
                        sx={{
                            width: '100%',
                        }}
                        slotProps={{
                            input: {
                                sx: inputSx,
                            }
                        }}
                    />
                </Stack>}

                <Stack direction={{ xs: 'column', md: 'row' }} sx={{ width: '100%' }} alignItems={{ xs: 'flex-start', md: 'center' }} spacing={{ xs: 1, md: 4 }} mt={1}>
                    <Typography
                        fontWeight={FontWeightEnum.Regular}
                        sx={{ textTransform: "uppercase", alignSelf: { xs: 'flex-start', md: 'center' } }}
                        fontSize={FontSizesEnum.Gamma}
                    >
                        Dividir facturas
                    </Typography>
                    <Tooltip
                        arrow
                        title={hasTransfers ? CHECKOUT_MESSAGES.cannotSplitWithTransfers : ""}
                        disableHoverListener={!hasTransfers}
                    >
                        <span>
                            <RadioGroup
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                }}
                                value={hasTransfers ? SplitBill.none : formData.split}
                                onChange={event => {
                                    if (hasTransfers) {
                                        return;
                                    }
                                    setFormData({ ...formData, split: Number(event.target.value) });
                                }}
                                row
                            >
                                <FormControlLabel
                                    value={SplitBill.none}
                                    control={<Radio sx={{ p: { xs: 1.25, md: "9px" } }} />}
                                    label="No dividir"
                                    disabled={hasTransfers || totalCheckout <= 2000 || !canSplit2000}
                                />
                                <FormControlLabel
                                    value={SplitBill.dosMil}
                                    control={<Radio sx={{ p: { xs: 1.25, md: "9px" } }} />}
                                    label="Montos de $2,000.00"
                                    disabled={hasTransfers || totalCheckout <= 2000 || !canSplit2000}
                                />
                                <FormControlLabel
                                    value={SplitBill.cincoMil}
                                    control={<Radio sx={{ p: { xs: 1.25, md: "9px" } }} />}
                                    label="Montos de $5,000.00"
                                    disabled={hasTransfers || totalCheckout <= 5000 || !canSplit5000}
                                />
                            </RadioGroup>
                        </span>
                    </Tooltip>
                    {/* En escritorio el motivo del bloqueo es un tooltip; en táctil no hay
                        hover y se verían las tres opciones apagadas sin explicación. En
                        móvil se pinta a la vista, con el mismo texto. */}
                    {isMobileExperience && hasTransfers && (
                        <Typography
                            fontSize={FontSizesEnum.Epsilon}
                            color={ColorsEpico.ColorGrayDisabled}
                        >
                            {CHECKOUT_MESSAGES.cannotSplitWithTransfers}
                        </Typography>
                    )}
                </Stack>

                <Stack direction={{ xs: 'column', md: 'row' }} spacing={1.5} sx={{ width: '100%' }} mt={1}>
                    <Stack direction="column" sx={{ width: '100%' }}>
                        <Typography
                            fontWeight={FontWeightEnum.Regular}
                            sx={{ textTransform: "uppercase" }}
                            fontSize={FontSizesEnum.Gamma}
                        >
                            Orden de compra
                        </Typography>
                        <TextField
                            defaultValue={purchaseOrder}
                            disabled
                            sx={{
                                width: '100%',
                            }}
                            slotProps={{
                                input: {
                                    sx: inputSx,
                                }
                            }}
                        />
                        {/* Móvil: el botón sube a 44px (objetivo táctil; en escritorio mide
                            24) y deja su ancho fijo de 144px. Si con la etiqueta del check no
                            cabe en el renglón, baja al siguiente en vez de desbordar. */}
                        <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ flexWrap: { xs: 'wrap', md: 'nowrap' }, rowGap: { xs: 1, md: 0 } }}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={checked}
                                        onChange={handleChange}
                                        sx={{
                                            p: { xs: 1.25, md: "9px" },
                                            color: (disableCheckOpenPay || isExternalPaid) ? ColorsEpico.ColorGrayNeutral : ColorsEpico.ColorPrimary,
                                            '&.Mui-checked': {
                                                color: (disableCheckOpenPay || isExternalPaid) ? ColorsEpico.ColorGrayNeutral : ColorsEpico.ColorPrimary,
                                            },
                                        }}
                                        disabled={disableCheckOpenPay || isExternalPaid}
                                    />
                                }
                                label={
                                    <Typography
                                        fontWeight={FontWeightEnum.Regular}
                                        sx={{ color: ColorsEpico.ColorDarkCharcoal, opacity: disableCheckOpenPay ? 0.4 : 1 }}
                                        fontSize={FontSizesEnum.Gamma}
                                    >
                                        Pago con OpenPay
                                    </Typography>
                                }
                            />
                            <Button
                                variant="contained"
                                size="small"
                                disabled={isExternalPaid || loadingExternal || !checked || miniCheckoutOpenPay?.estatusId === StatusOrderOpenPayEnum.Pagado}
                                sx={{
                                    height: { xs: 44, md: '1.5rem' },
                                    width: { xs: 'auto', md: '9rem' }
                                }}
                                onClick={() => setOnModal(true)}
                            >Liga de pago</Button>
                        </Stack>
                    </Stack>
                    <Stack direction="column" sx={{ width: '100%' }}>
                        <Typography
                            fontWeight={FontWeightEnum.Regular}
                            sx={{ textTransform: "uppercase" }}
                            fontSize={FontSizesEnum.Gamma}
                        >
                            Observaciones
                        </Typography>
                        <TextField
                            size="small"
                            placeholder="Escribe tus observaciones"
                            variant="outlined"
                            value={formData.comment}
                            onChange={e => setFormData({ ...formData, comment: e.target.value })}
                            fullWidth
                            multiline
                            rows={3}
                            slotProps={{
                                htmlInput: {
                                    maxLength: 250
                                },
                                formHelperText: {
                                    sx: {
                                        textAlign: "right",
                                    }
                                }
                            }}
                            helperText={`${formData?.comment?.length}/250`}
                        />
                    </Stack>
                </Stack>
            </Stack>
            <SendLinkOpenPayMiniCheckOutSMC4
                miniCheckout={checkoutInfo}
                openSendMail={onModal}
                onSend={() => Promise.resolve()}
                onCloseSendMail={() => setOnModal(false)}
            />
        </Fragment>
    )
}