import { SplitBill } from "@/features/common/domain/enums/SplitBill";
import { ICustomer } from "@/features/customer/domain/interface/ICustomer";
import { ICalculateTotalsBranch } from "@/features/orders/domain/interfaces/ICalculateTotalsBranch";
import { IMiniCheckoutDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision";

/**
 * Props for the ModalSendOrderSMC4 component.
 * 
 * @interface ModalSendOrderSMC4Props
 * @property {boolean} open - Controls the visibility state of the modal dialog.
 * @property {() => void} onClose - Callback function invoked when the modal is closed or dismissed.
 * @property {() => void} onSave - Callback function invoked when the user confirms and saves the order.
 * @property {ICalculateTotalsBranch} totalsBranch - Calculated totals for the branch associated with the checkout.
 * @property {ICustomer} customerInfo - Information about the customer placing the order.
 * @property {IMiniCheckoutDivision} checkoutInfo - Information about the checkout including shipping method and branch.
 */
export interface IModalSendOrderSMC4Props {
    open: boolean;
    onClose: () => void;
    onSave: (formModal: IFormSendOrderSMC4) => void;
    customerInfo: ICustomer;
    checkoutInfo: IMiniCheckoutDivision;
}

/**
 * Props for the SMC4 send order form.
 * 
 * @interface IFormSendOrderSMC4Props
 * @property {SplitBill} split - Information about the bill split.
 * @property {string} comment - Comment associated with sending the order.
 */
export interface IFormSendOrderSMC4 {
    split: SplitBill;
    comment: string;
}