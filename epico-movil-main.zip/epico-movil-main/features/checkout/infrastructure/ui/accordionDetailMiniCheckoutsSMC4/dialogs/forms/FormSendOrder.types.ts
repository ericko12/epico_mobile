import { ICalculateTotalsBranch } from "@/features/orders/domain/interfaces/ICalculateTotalsBranch";
import { IFormSendOrderSMC4 } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/IModalSendOrderSMC4.types";
import { ChangeEvent, Dispatch, SetStateAction } from "react";
import { IMiniCheckoutDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision";

/**
 * Props for the FormSendOrder component.
 * 
 * @interface FormSendOrderProps
 * @property {IFormSendOrderSMC4} formData - The current state of the form data for sending the order.
 * @property {Dispatch<SetStateAction<IFormSendOrderSMC4>>} setFormData - State setter function to update the form data.
 * @property {IMiniCheckoutDivisionSMC4} checkoutInfo - Information about the checkout including shipping method and branch.
 * @property {(e: ChangeEvent<HTMLInputElement>) => void} handleChange - Event handler for handling changes in form inputs.
 * @property {boolean} checked - Indicates whether a specific checkbox is checked.
 * @property {Dispatch<SetStateAction<boolean>>} setChecked - State setter function to update the checked state.
*/
export interface FormSendOrderProps {
    formData: IFormSendOrderSMC4;
    setFormData: Dispatch<SetStateAction<IFormSendOrderSMC4>>;
    checkoutInfo: IMiniCheckoutDivision;
    handleChange: (e: ChangeEvent<HTMLInputElement>) => void;
    checked: boolean;
    setChecked: Dispatch<SetStateAction<boolean>>;
    setIsExternalPaidGlobal?: (value: boolean) => void;
}