/**
 * Props interface for the ModalConfirmSMC4 component.
 * 
 * @interface IModalConfirmSMC4Props
 * @property {boolean} open - Determines whether the modal is visible or hidden.
 * @property {() => void} onSave - Callback function triggered when the user confirms or saves the modal action.
 * @property {() => void} onClose - Callback function triggered when the user closes or cancels the modal.
 * @property {?boolean} [loading] - Optional prop to indicate if a loading state should be displayed, typically used during asynchronous operations.
 * @property {?string} [warningMessage] - Optional prop to display a warning message in the modal.
 */
export interface IModalConfirmSMC4Props {
  open: boolean;
  onSave: () => void;
  onClose: () => void;
  loading?: boolean;
  warningMessage?: string;
}
