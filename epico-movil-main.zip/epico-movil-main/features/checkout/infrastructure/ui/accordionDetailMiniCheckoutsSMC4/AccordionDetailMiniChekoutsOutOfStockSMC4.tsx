import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { Accordion, AccordionDetails, AccordionSummary, Box, Stack, Typography } from "@mui/material"
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { sxContainerAccordionDetail } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4.styles";
import { AdaptiveDataGrid } from "@/features/common/infrastructure/ui/tables/adaptiveDataGrid/AdaptiveDataGrid";
import { sxDataGrid } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.style";
import { IArticle } from "@/features/shipment/domain/interfaces/evaluatorSMC4/IArticle";
import { useAppSelector } from "@/features/common/application/redux/hooks";
import { OUT_OF_STOCK_ORDER_REVIEW_COLUMNS } from "@/features/checkout/infrastructure/ui/miniCheckoutsPreview/miniCheckoutDetailPreview/OutOfStockPanelOrderReview.data";
import { IAccordionDetailMiniChekoutsOutOfStockSMC4Props } from '@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniChekoutsOutOfStockSMC4.types';

/**
 * Accordion component that displays out-of-stock articles in a mini checkout for SMC4.
 * 
 * @component
 * @param {IAccordionDetailMiniChekoutsOutOfStockSMC4Props} props - Component props
 * @param {IArticle[]} props.articulosSinStock - Array of articles that are out of stock
 * 
 * @returns {React.FC<IAccordionDetailMiniChekoutsOutOfStockSMC4Props>} An accordion component showing out-of-stock products with their details,
 * including quantity count. Displays products in a data grid table.
 */
export const AccordionDetailMiniChekoutsOutOfStockSMC4: React.FC<IAccordionDetailMiniChekoutsOutOfStockSMC4Props> = ({
    articulosSinStock,
}) => {
    //#region Constants
    const quantity: number = articulosSinStock.reduce((acc, detalle) => acc + (detalle.cantidad ?? 0), 0);

    //#endregion Constants
    const { selectedOrderSummary } = useAppSelector((state) => state.sessionState.checkOutsState);
    articulosSinStock = articulosSinStock.map(article => {
    const detalle = selectedOrderSummary?.detalles?.find(det => det.productoID === article.productoId);
    return {
        ...article,
        descripcion: detalle?.descripcion || '',
      }
      });
    return (
        < Accordion
            defaultExpanded
            disableGutters
            elevation={0}
            sx={sxContainerAccordionDetail}
        >
            <Box>
                <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls={"panel-content-" + "outOfStock"}
                    id={"panel-header-" + "outOfStock"}
                >
                    <Stack
                        direction="row"
                        justifyContent="space-between"
                        pr={5.5}
                        width='100%'
                    >
                        <Stack alignItems="center" alignContent="center" spacing="20px" direction="row">
                            <Typography fontSize={FontSizesEnum.Lambda} fontWeight={FontWeightEnum.Bold} color={ColorsEpico.ColorPrimary}>
                               PRODUCTOS NO ENCONTRADOS 
                            </Typography>
                        </Stack>                        
                        <Stack direction={"row"} spacing={6} alignItems="center">
                            <Typography
                                fontWeight={FontWeightEnum.Regular}
                                color={ColorsEpico.ColorGray}
                            >
                                {`(${quantity} ${quantity === 1 ? 'ARTÍCULO' : 'ARTÍCULOS'})`}
                            </Typography>
                        </Stack>
                    </Stack>
                </AccordionSummary>
            </Box>
            <AccordionDetails>
                <Box sx={{ height: 'auto' }}>
                    <Box sx={{
                        height: 'auto',
                        display: 'grid',
                        gridTemplateColumns: '100%',
                    }}>
                        <AdaptiveDataGrid
                            columns={OUT_OF_STOCK_ORDER_REVIEW_COLUMNS()}
                            rows={articulosSinStock}
                            rowCount={articulosSinStock.length}
                            getRowId={(row: IArticle) => `${row.productoId}-${row.promocionId}`}
                            hideFooter
                            sx={{
                                ...sxDataGrid,
                                paddingX: '32px'
                            }}
                        />
                    </Box>
                </Box>
            </AccordionDetails>
        </Accordion>
    )
}