import { IBranchAddressExtended } from "@/features/branch/domain/interfaces/branch/IBranchAddressExtended";
import { ICustomerPriceList } from "@/features/checkout/domain/interfaces/ICustomerPriceList";
import { ICustomer } from "@/features/customer/domain/interface/ICustomer";
import { GenericProduct } from "@/features/products/domain/interfaces/IGenericProductList";
import { IMiniCheckoutDivision } from "@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision";
/**
 * Props for the AccordionDetailMiniCheckoutsSMC4 component.
 * 
 * @interface IAccordionDetailMiniCheckoutsSMC4Props
 * @property {IMiniCheckoutDivision} checkoutInfo - Information about the selected branch option for checkout.
 * @property {?IBranchAddressExtended} branchInfo - Extended address information for the branch.
 * @property {?ICustomer} customerInfo - Information about the customer.
 * @property {ICustomerPriceList} customerPriceList - Customer's price list information.
 * @property {GenericProduct[]} genericProductsDescriptions - List of generic product descriptions for the products in the checkout.
 */
export interface IAccordionDetailMiniCheckoutsSMC4Props {
    checkoutInfo: IMiniCheckoutDivision;
    branchInfo?: IBranchAddressExtended;
    customerInfo?: ICustomer;
    customerPriceList: ICustomerPriceList;
    genericProductsDescriptions: GenericProduct[];
};