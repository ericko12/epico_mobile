import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { SxProps } from "@mui/material"

export const sxContainerAccordionDetail: SxProps = {
    "&:before": { display: 'none' },
    border: "1.5px solid",
    boxShadow: "rgb(194 196 198 / 20%) 0px 3px 4px",
    borderRadius: "10px !important",
    borderColor: ColorsEpico.ColorLightBlueishGray,
    marginBottom: '20px'
};
export const sxCointAccordionDetail: SxProps = {
    textTransform: 'uppercase',
    textAlign: 'left',
    letterSpacing: '1.28px'
}
export const sxDecimalAccordionDetail: SxProps = {
    display: 'flex',
    fontSize: '1rem',
    alignItems: 'center',
}
export const sxChipContainer: SxProps = {
    paddingTop: "5px !important",
    paddingBottom: "10px !important",
    paddingX: "16px",
    cursor: "pointer"
}
export const sxChipNumberOrder: SxProps = {
    borderRadius: "3px",
    height: "auto",
    minWidth: "80px",
    border: `1px solid ${ColorsEpico.ColorGray}`,
    color: ColorsEpico.ColorNeutralGray,
    fontSize: FontSizesEnum.Delta,
    fontWeight: FontWeightEnum.Medium,
    "& .MuiChip-label": {
        paddingX: "5px",
    }
}