import { IArticle } from "@/features/shipment/domain/interfaces/evaluatorSMC4/IArticle";
/**
 * Props for the AccordionDetailMiniChekoutsOutOfStockSMC4 component.
 * 
 * @property {IArticle[]} articulosSinStock - Array of articles that are currently out of stock.
 */
export type IAccordionDetailMiniChekoutsOutOfStockSMC4Props = {
  articulosSinStock: IArticle[];
};