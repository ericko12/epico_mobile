import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { SxProps } from "@mui/material";

// style datagrid
export const sxDataGrid: SxProps = {
    [`&`]: {
        border: `1.5px ${ColorsEpico.ColorWhite} solid`,
        boxShadow: 'none',
        borderRadius: '0rem',
    },
}