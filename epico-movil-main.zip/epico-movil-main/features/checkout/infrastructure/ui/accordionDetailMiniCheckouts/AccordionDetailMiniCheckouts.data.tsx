import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import GiftIcon from "@/features/common/infrastructure/ui/icons/GiftIcon";
import { IconPromo } from "@/features/common/infrastructure/ui/icons/IconPromo";
import { ImageCell } from "@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell";
import { extraerCodigoProducto } from "@/features/common/infrastructure/utils/extractPrductoCode";
import { fetchImageProducts } from "@/features/products/application/actions/fetchImageProducts";
import { PromotionTypesEnum } from "@/features/promotions/domain/enums/PromotionTypesEnum";
import { IMiniCheckoutDetail } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckoutDetail";
import { GridColDef } from "@mui/x-data-grid";
import { GenericProduct } from "@/features/products/domain/interfaces/IGenericProductList";

/**
 * Defines the column configuration for the mini checkout details data grid.
 * Each column represents a field in the mini checkout item display.
 * 
 * The columns include:
 * - Product image
 * - Promotion icon (gift or promo)
 * - Product code
 * - Product description 
 * - Quantity
 *
 * @param {IOrderSummary} orderSummary - The order summary containing product details and images
 * @returns {GridColDef[]} Array of column definitions for the data grid
 */
// ⚠️ La rama móvil de AccordionDetailMiniCheckouts.tsx resuelve estos mismos datos por
// su cuenta (descripción del genérico, distintivo de promo/regalo, imagen con respaldo).
// El acuerdo entre ambas rutas está fijado en
// __tests__/app/features/checkout/miniCheckoutArticleParity.test.tsx: al cambiar aquí,
// cambiar allá.
export const COLUMNS = (orderSummary: IOrderSummary, genericProductsDescriptions: GenericProduct[] | null): GridColDef[] => [
    {
        headerName: '',
        field: 'imagen',
        sortable: false,
        align: 'center',
        headerAlign: 'center',
        minWidth: 68,
        renderCell: (({ row }) => {

            let genericProduct: GenericProduct | undefined = genericProductsDescriptions?.find(product => product.producto == row.producto);

            return (
                (genericProduct && genericProduct.imagenUrl) ?
                (<img src={genericProduct.imagenUrl} width={34} height={28} />)
                : (
                    <ImageCell
                        producto={row.producto ?? ""}
                        alt={row.descripcion}
                        width={34}
                        height={28}
                        onError={fetchImageProducts}
                    />
                )
            )
        })
    },
    {
        headerName: '',
        field: 'promocionID',
        maxWidth: .5,
        align: 'center',
        headerAlign: 'center',
        sortable: false,
        renderCell: ({ row }) => {
            if (row.gratis && PromotionTypesEnum.ProductoRegalo === row.tipoPromocionId)
                return <GiftIcon />
            if (row.promocionID)
                return <IconPromo />
            return null;
        },
    },
    {
        headerName: 'Código',
        field: 'producto',
        minWidth: 10,
        align: 'left',
        headerAlign: 'left',
    },
    {
        headerName: 'Descripción',
        field: 'descripcion',
        flex: 1,
        minWidth: 500,
        renderCell: ({row}) => {

            let genericProduct: GenericProduct | undefined = genericProductsDescriptions?.find(product => product.producto == row.producto);

            return (!genericProduct?.descripcion) ? row.descripcion : genericProduct.descripcion;

        }
    },
    {
        headerName: 'Cantidad',
        field: 'cantidad',
        cellClassName: 'actions',
        align: 'center',
        minWidth: 10,
        headerAlign: 'center',
    },
];

/**
 * Default record representing an empty mini checkout detail item.
 * Used as initial/default state for mini checkout details.
 * 
 * @type {IMiniCheckoutDetail[]} Array containing a single empty mini checkout detail object
 * @property {number} miniCajaDetalleID - ID of the mini checkout detail, defaults to 0
 * @property {number} miniCajaID - ID of the mini checkout, defaults to 0
 * @property {number} productoID - ID of the product, defaults to 0
 * @property {string} producto - Product code/SKU, defaults to empty string
 * @property {string} descripcion - Product description, defaults to empty string
 * @property {number|null} cantidad - Quantity of the product, defaults to null
 * @property {boolean} gratis - Whether the product is free, defaults to false
 * @property {number} promocionID - ID of the promotion if applicable, defaults to 0
 * @property {number} tipoPromocionId - Type of promotion if applicable, defaults to 0
 * @property {number} precio - Base price of the product, defaults to 0
 * @property {number} precioIVA - Price with VAT included, defaults to 0
 * @property {number} porcentajeDescuento - Discount percentage, defaults to 0
 * @property {number} subtotal - Subtotal amount, defaults to 0
 * @property {boolean} retail - Whether it's a retail item, defaults to false
 * @property {number|null} precioEspecialID - Special price ID if applicable, defaults to null
 * @property {number|null} tipoPrecio - Indicates the type of the price (TKN, UPA, DIN, etc)., defaults to null
 */
export const DEFAULT_RECORD: IMiniCheckoutDetail[] = [
    {
        miniCajaDetalleID: 0,
        miniCajaID: 0,
        productoID: 0,
        producto: '',
        descripcion: '',
        cantidad: null,
        gratis: false,
        promocionID: 0,
        tipoPromocionId: 0,
        precio: 0,
        precioIVA: 0,
        porcentajeDescuento: 0,
        subtotal: 0,
        retail: false,
        precioEspecialID: null,
        tipoPrecio: null
    }
];