import { IBranch } from "@/features/branch/domain/interfaces/branch/IBranch";
import { TypeMiniCheckoutEnum } from "@/features/checkout/domain/enums/TypeMiniCheckoutEnum";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { IMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckout";
import { GenericProduct } from "@/features/products/domain/interfaces/IGenericProductList";
import { SxProps } from "@mui/material";

/**
 * Interface representing the structure and styling of an accordion detail component.
 * This interface defines the props used to configure the appearance and behavior 
 * of an accordion, including its title, styling options, and content.
 *
 * @property {title} string - The title displayed on the accordion header.
 * @property {sxTitle} SxProps | undefined - The styling properties to customize the appearance of the title.
 * @property {sxDetail} SxProps | undefined - The styling properties to customize the detailed content section of the accordion.
 * @property {sxSummary} SxProps | undefined - The styling properties to customize the summary section of the accordion.
 * @property {summary} React.ReactNode | undefined - The content displayed in the summary section of the accordion.
 * @property {children} React.ReactNode - The main content to be displayed when the accordion is expanded.
 * @interface data - {rows. orderId, subTotalIVA, branch}.
 */
export interface IAccordionDetail {
    title: string;
    sxTitle?: SxProps;
    sxDetail?: SxProps;
    sxSummary?: SxProps;
    summary?: React.ReactNode;
    children?: React.ReactNode;
    defaultExpanded?: boolean;
    data: {
        rows: ReadonlyArray<IOrderSummaryDetail>;
        orderId: number;
        branch?: IBranch;
        subTotalIVA: number;
    }
}


/**
 * Interface Minicheckouts Accordion Component
 *
 * @export
 * @interface IAccordionDetailMiniCheckout
 * @property {string} title - Title of the accordion section.
 * @property {TypeMiniCheckoutEnum} typeCheckout - Type of the mini checkout.
 * @property {SxProps} [sxTitle] - (Optional) Custom styles for the title.
 * @property {SxProps} [sxDetail] - (Optional) Custom styles for the detail section.
 * @property {SxProps} [sxSummary] - (Optional) Custom styles for the summary section.
 * @property {React.ReactNode} [summary] - (Optional) Content for the summary section.
 * @property {React.ReactNode} [children] - (Optional) Child components to render inside the accordion.
 * @property {boolean} [defaultExpanded] - (Optional) Indicates if the accordion should be expanded by default.
 * @property {Readonly<IMiniCheckout>} checkoutInfo - Checkout information for the mini checkout.
 * @property {number} orderId - Unique identifier for the order.
 */
export interface IAccordionDetailMiniCheckout {
    title: string;
    typeCheckout: TypeMiniCheckoutEnum;
    sxTitle?: SxProps;
    sxDetail?: SxProps;
    sxSummary?: SxProps;
    summary?: React.ReactNode;
    children?: React.ReactNode;
    defaultExpanded?: boolean;
    checkoutInfo: Readonly<IMiniCheckout>;
    orderId: number;
    genericProductsDescriptions: GenericProduct[] | null;
}