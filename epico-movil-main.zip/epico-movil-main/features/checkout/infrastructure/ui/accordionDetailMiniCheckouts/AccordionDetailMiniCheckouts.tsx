import { ChangeEvent, FC, useEffect, useRef, useState } from "react";
import { IAccordionDetailMiniCheckout } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.type";
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { useRouter } from "next/navigation";
import { IShipmentState } from "@/features/shipment/domain/interfaces/IShipmentState";
import { Accordion, AccordionDetails, Checkbox, Divider, SelectChangeEvent, Stack, Typography } from "@mui/material";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { setMiniCheckouts, setPurchaseOrderErrorMsj, setFormatoOrden, setPurchaseOrderError } from "@/features/shipment/application/redux/ShipmentSlice";
import { fetchSMCResult } from "@/features/checkout/application/actions/fetchSMCResult";
import { handleCathError } from "@/features/common/infrastructure/utils/handleCathError";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { NOTIFICATIONS_SHIPMENT } from "@/features/common/infrastructure/utils/messages/notificationShipment";
import { GetOrderShipmentById } from "@/features/checkout/infrastructure/db/OrdersShipmentRepository";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric";
import { ModalPurchaseOrder } from "@/features/orders/infraestructure/ui/modalPurchaseOrders/ModalPurchaseOrder";
import { Box } from "@mui/material";
import { AccordionSummary } from "@mui/material";
import { BadgeGeneric } from "@/features/common/infrastructure/ui/badge/BadgeGeneric";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { TypeMiniCheckoutEnum } from "@/features/checkout/domain/enums/TypeMiniCheckoutEnum";
import { TypeConsolidatedEnum } from "@/features/checkout/domain/enums/TypeConsolidatedEnum";
import { DEFAULT_RECORD } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.data";
import { COLUMNS } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.data";
import { sxDataGrid } from "@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.style";
import { NOTIFICATIONS_ORDERS } from "@/features/common/infrastructure/utils/messages/orders";
import { UpdateOrderService } from "@/features/orders/application/actions/fetchOrdersAction";
import { PatchOrderSummaryEnum } from "@/features/checkout/domain/enums/PatchCheckoutEnum";
import { StatusOrderOpenPayEnum } from "@/features/checkout/domain/enums/StatusOrderOpenPayEnum";
import { IStatusOpenPay } from "@/features/checkout/domain/interfaces/openpay/IStatusOpenPay";
import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";
import { PATH_PAGE } from "@/routes/paths";
import { TypeConsolidatedNameEnum } from "@/features/checkout/domain/enums/TypeConsolidatedNameEnum";
import { IMiniCheckoutDetail } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckoutDetail";
import { GENERIC_ERROR_MESSAGE } from "@/features/common/infrastructure/utils/messages/generic";
import { PromotionTypesEnum } from "@/features/promotions/domain/enums/PromotionTypesEnum";
import { ICustomer } from "@/features/customer/domain/interface/ICustomer";
import { fetchCustomerIndexDB } from "@/features/customer/application/actions/db/CustomersRepository";
import { IBranchStockSMC } from "@/features/branch/domain/interfaces/branch/IBranchStockSMC";
import { ISendMiniCheckoutResponse } from "@/features/checkout/domain/interfaces/smc/ISendMiniCheckoutResponse";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { IAuth } from "@/features/auth/domain/interfaces/IAuth";
import { SMCService } from "@/features/checkout/application/service/smc.services";
import { CoinFormatter } from "@/features/common/infrastructure/utils/models/CoinFormatter";
import { ordersService } from "@/features/orders/application/services/order.services";
import { paymentGatewayService } from "@/features/openPay/application/services/paymentGateway.services";
import { ISendMiniCheckoutRequest } from "@/features/checkout/domain/interfaces/smc/ISendMiniCheckoutRequest";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { IOptionsStores } from "@/features/branch/domain/interfaces/branch/IOptionsStores";
import { initialOrderShipment } from "@/features/orders/domain/data/initOrderShipment.data";
import { ShippingMethodEnum } from "@/features/shipment/domain/enum/ShippingMethodEnum";
import { IGetPayment } from "@/features/checkout/domain/interfaces/IGetPayment";
import { mapToBranchRequest } from "@/features/checkout/application/actions/mapRequestSendMiniCheckout";
import { mapToAddressRequest } from "@/features/checkout/application/actions/mapRequestSendMiniCheckout";
import { saveShippingPreference } from "@/features/shipment/application/actions/fetchShippingPreference";
import { DataGridServerPagination } from "@/features/common/infrastructure/ui/tables/DataGridServerPagination";
import OrderPlacedError from "@/features/orders/infraestructure/ui/orderPlaced/OrderPlacedError";
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";
import { ArticleCard } from "@/features/common/infrastructure/ui/cards/ArticleCard";
import { ImageCell } from "@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell";
import { IconPromo } from "@/features/common/infrastructure/ui/icons/IconPromo";
import GiftIcon from "@/features/common/infrastructure/ui/icons/GiftIcon";
import { fetchImageProducts } from "@/features/products/application/actions/fetchImageProducts";
import OrderPlacedCorrectly from "@/features/orders/infraestructure/ui/orderPlaced/OrderPlacedCorrectly";
import ModalEndedOrder from "@/features/orders/infraestructure/ui/modalEndedOrder/ModalEndedOrder";
import { MinicheckoutSubHeader } from "@/features/checkout/infrastructure/ui/miniCheckout/minicheckoutSubHeader/MinicheckoutSubHeader";
import { ModalSendForm } from "@/features/shipment/infrastructure/ui/modalSendForm/ModalSendForm";
import ModalTransferBox from "@/features/checkout/infrastructure/ui/modalTransferBox/ModalTransferBox";
import { MiniCheckoutSummary } from "@/features/checkout/infrastructure/ui/miniCheckout/miniCheckoutSummary/MiniCheckoutSummary";
import { MiniCheckoutFooter } from "@/features/checkout/infrastructure/ui/miniCheckout/miniCheckoutFooter/MiniCheckoutFooter";
import { sendMessageEvaluateOrder } from "@/features/checkout/infrastructure/utils/channel/sendMiniCheckoutMessage";
import { openChannel } from "@/features/common/infrastructure/adapters/BroadcastChannelAdapter";
import { BroadcastMessageType } from "@/features/common/domain/enums/broadCast/BroadcastMessageType";
import { ProductService } from '@/features/products/application/service/product.services';
import { setTelemarketingLeadsList, setTelemarketingLeadsModal } from "@/features/teleMarketingLead/application/redux/telemarketingLeadSlice";
import { InitTeleMarketingLeadSlice } from "@/features/teleMarketingLead/domain/data/redux/InitTeleMarketingLeadSlice";
import { ILoyaltyPlanProductsRequest } from "@/features/loyaltyPlan/domain/interface/ILoyaltyPlanProductRequest"
import { setOrderClosed } from "@/features/loyaltyPlan/application/redux/loyaltyPlanSlice";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { guestCustomers } from "@/features/common/domain/data/guestCustomers";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
/**
 * Accordion component that displays mini checkout details.
 * This component renders an expandable accordion section containing information about a mini checkout,
 * including its products, subtotal and actions like transferring or sending the checkout.
 * 
 * @component
 * @param {Object} props - Component properties
 * @param {TypeMiniCheckoutEnum} props.typeCheckout - Type of mini checkout (Primary or Secondary)
 * @param {Readonly<IMiniCheckout>} props.checkoutInfo - Mini checkout data containing products and totals
 * @param {string} props.title - Title displayed in the accordion header
 * @param {boolean} [props.defaultExpanded] - Indicates if the accordion is expanded by default
 * @param {SxProps} [props.sxSummary] - Custom styles for the accordion summary section
 * @param {SxProps} [props.sxDetail] - Custom styles for the accordion detail section
 * @param {ReactNode} [props.children] - Child components to render inside the accordion
 * @returns {JSX.Element} Rendered accordion component with mini checkout details
 */
export const AccordionDetailMiniCheckouts: FC<IAccordionDetailMiniCheckout> = ({
    typeCheckout,
    checkoutInfo,
    title,
    defaultExpanded,
    sxSummary,
    sxDetail,
    children,
    genericProductsDescriptions
}) => {
    // hooks
    const dispatch = useAppDispatch();
    const { showSnackbar } = useSnackbar();
    const router = useRouter();
    const { isMobileExperience } = useWindowDimensions();
    const channelCheckoutsRef = useRef<BroadcastChannel | null>(openChannel("checkouts"));

    //Redux 
    const { openPay, purchaseOrder, purchaseOrderError, miniCheckoutState, formatoOrden }: IShipmentState = useAppSelector(state => state.sessionState.shipmentState);
    const { selectedOrderSummary, checkOutList }: ICheckOutState = useAppSelector(state => state.sessionState.checkOutsState);
    const { userAuth }: IAuth = useAppSelector(state => state.localState.authState);
    const { tabId } = useAppSelector(state => state.sessionState.windowState);
    const { telemarketingLeads } = useAppSelector(state => state.localState.telemarketingLeadState);
    const { customers } = useAppSelector((state) => state.sessionState.loyaltyPlanState);

    //api
    const { GetSucursalesConExistencia, PostChangeBranchMiniBoxes, deleteBoxMiniBoxId, PostSendMiniCheckout } = SMCService();
    const { getPurchaseOrderRelation } = ordersService();
    const { getLinkStatus, sendWebPay } = paymentGatewayService();
    const { InsertSpecialOrderTlc } = ProductService();
    const { getValidarFormatoOrdenCompra } = checkoutServices();
    // constants
    const formattedSubtotal = new CoinFormatter(checkoutInfo.subtotal + checkoutInfo.ivaTotal);
    const quantity: number = checkoutInfo.detalle.reduce((acc, detalle) => acc + (detalle.cantidad ?? 0), 0);
    const openMiniCheckout: IStatusOpenPay | undefined = openPay.miniCheckouts.find(ck => ck.pedidoId === checkoutInfo.miniCajaID);
    const clientId = selectedOrderSummary?.clienteId;
    const orderId = selectedOrderSummary?.pedidoID;
    const kmsApplied = clientId && orderId
    ? (customers?.[clientId]?.ordersKms?.[orderId]?.kmsInUsePerOrder ?? 0) > 0
    : false;




    // states
    const [customerInfo, setCustomerInfo] = useState<ICustomer>();
    const [modalEmptyBox, setModalEmptyBox] = useState<boolean>(false);
    const [optionsStores, setOptionsStores] = useState<IOptionsStores[]>([]);
    const [modalTransfer, setModalTransfer] = useState<boolean>(false);
    const [modalPartial, setModalPartial] = useState<boolean>(false);
    const [branchesMiniBox, setBranchesMiniBox] = useState<IBranchStockSMC[]>([]);
    const [loadingDeleteMiniBox, setLoadingDeleteMiniBox] = useState<boolean>(false);
    const [loadingBranchesMiniBox, setLoadingBranchesMiniBox] = useState<boolean>(true);
    const [openModalSend, setOpenModalSend] = useState<boolean>(false);
    const [modalConfirm, setModalConfirm] = useState<boolean>(false);
    const [endedOrderModalState, setEndedOrderModalState] = useState<boolean>(false);
    const [loadingConfirm, setLoadingConfirm] = useState<boolean>(false);
    const [formData, setFormData] = useState<IOrderShipment>(initialOrderShipment);
    const [orderIdsResponse, setOrderIdsResponse] = useState<number[]>([]);
    const [orderResponse, setOrderResponse] = useState<IResponseDto<ISendMiniCheckoutResponse | null>>();
    const [openPayDisabledSend, setOpenPayDisabledSend] = useState<boolean>(openMiniCheckout?.estatusId === StatusOrderOpenPayEnum.Pendiente && openMiniCheckout.tieneVigencia && typeCheckout === TypeMiniCheckoutEnum.Primary)
    const [openPayDisabled, setOpenPayDisabled] = useState<boolean>(
        openMiniCheckout
            ? (openMiniCheckout.estatusId === StatusOrderOpenPayEnum.Pendiente && openMiniCheckout.tieneVigencia)
            || openMiniCheckout.estatusId === StatusOrderOpenPayEnum.Pagado
            : false
    );
    const [modalConfirmFormato, setModalConfirmFormato] = useState<boolean>(false);
    const [formatoConfirmMsg, setFormatoConfirmMsg] = useState<string>('');
    const [formatoConfirmTitle, setFormatoConfirmTitle] = useState<string>('');
    // stores selected products per mini checkout
    const [selectedRows, setSelectedRows] = useState<IMiniCheckoutDetail[]>([]);
    const isExternalOrigin = selectedOrderSummary?.origenExternoId === OrigenEnum.Web;
    const skipFormatValidation = useRef<boolean>(false);
    // init
    useEffect(() => {
        init()
    }, [])

    useEffect(() => {
        if (typeCheckout === TypeMiniCheckoutEnum.Primary && selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay && selectedOrderSummary?.openPayStatus === undefined) {
            setOpenPayDisabledSend(true)
            return
        }


        // Si es origen externo (4) se toma el pedidoIdExterno
        const currentMiniCheckout = openPay.miniCheckouts.find(ck => {
            if (isExternalOrigin) {
                return Number(selectedOrderSummary?.pedidoIdExterno) === ck.pedidoId;
            }

            return ck.pedidoId === checkoutInfo.miniCajaID;
        });
        if (openPay.miniCheckouts.length > 0 &&
            !currentMiniCheckout
        ) {
            setOpenPayDisabledSend(false);
            return;
        }
        const isPendingWithVigency =
            currentMiniCheckout?.estatusId === StatusOrderOpenPayEnum.Pendiente &&
            currentMiniCheckout.tieneVigencia;

        const isPaid =
            currentMiniCheckout?.estatusId === StatusOrderOpenPayEnum.Pagado;

        setOpenPayDisabled(isPendingWithVigency || isPaid);
        setOpenPayDisabledSend(isPendingWithVigency && typeCheckout === TypeMiniCheckoutEnum.Primary)

    }, [openPay.miniCheckouts,
    selectedOrderSummary?.estatusID,
    selectedOrderSummary?.openPayStatus,
    checkoutInfo.miniCajaID,
        typeCheckout
    ]);


    //#region FUNCIONES

    /**
     * Initializes the component by:
     * - Setting up initial store options with the current checkout store info
     * - Fetching and setting customer data from IndexDB
     * - Setting loading state for branch selection
     * 
     * @async
     * @function init
     * @returns {Promise<void>} Promise that resolves when initialization is complete
     */
    const init = async () => {
        //First option selected store
        setOptionsStores([{ id: checkoutInfo.infoSucursalID, name: checkoutInfo.nombreSucursal, description: checkoutInfo.distancia, time: checkoutInfo.tiempo }]);
        const resCustomer: ICustomer = await fetchCustomerIndexDB(selectedOrderSummary?.clienteId ?? 0)
        if (resCustomer) setCustomerInfo(resCustomer);

        setOptionsStores([{
            id: checkoutInfo.infoSucursalID,
            name: checkoutInfo.nombreSucursal,
            description: checkoutInfo.distancia,
            time: checkoutInfo.tiempo
        }]);
        setLoadingBranchesMiniBox(false);
    }

    /**
     * Fetches and sets up branch options for the branch selection dropdown.
     * 
     * This function:
     * - Sets loading state while fetching branches
     * - For non-new checkouts with an order summary:
     *   1. Gets order shipment details by ID
     *   2. Fetches branches with available inventory based on:
     *      - Mini checkout ID
     *      - Delivery address ID (package or regular delivery)
     *      - Whether it's package delivery
     *      - Whether it's primary checkout
     *      - Store ID (if shipping method is store pickup)
     * - Maps branch data to dropdown options format
     * - Sets the current store as first option followed by other available branches
     * 
     * @async
     * @function getBranchesMiniBox
     * @returns {Promise<void>} Promise that resolves when branches are fetched and set
     */
    const getBranchesMiniBox = async () => {
        setLoadingBranchesMiniBox(true);
        if (TypeMiniCheckoutEnum.New !== typeCheckout && selectedOrderSummary) {
            const OrderShipment = (await GetOrderShipmentById(selectedOrderSummary.pedidoID)).data[0]
            const sucursalesConExistencia = await GetSucursalesConExistencia(
                checkoutInfo.miniCajaID,
                (OrderShipment.EnviarPaqueteria?.active ? OrderShipment.EnviarPaqueteria.DireccionPaqueteriaId : OrderShipment.DireccionEntregaId) || 0,
                OrderShipment.EnviarPaqueteria?.active || false,
                checkoutInfo.principal,
                (OrderShipment.MetodoEnvio === ShippingMethodEnum.Sucursal) ? checkoutInfo.infoSucursalID : undefined,
            )
            handleRequestDto({
                snackBar: showSnackbar,
                response: sucursalesConExistencia,
                onSuccess: async () => {
                    setBranchesMiniBox(sucursalesConExistencia.data || []);
                    setLoadingBranchesMiniBox(false);
                },
                onError: () => {
                    setLoadingBranchesMiniBox(false);
                },
                onInvalid: () => {
                    setLoadingBranchesMiniBox(false);
                },
            })
            const optionsSucursalesConExistencia: IOptionsStores[] = sucursalesConExistencia?.data?.map(suc => ({
                id: suc.infoSucursalID,
                name: suc.descripcion,
                description: suc.distanciaTexto,
                time: suc.tiempoTexto,
            })) || [];

            setOptionsStores([{
                id: checkoutInfo.infoSucursalID,
                name: checkoutInfo.nombreSucursal,
                description: checkoutInfo.distancia,
                time: checkoutInfo.tiempo
            },
            ...optionsSucursalesConExistencia]);
        }
    }

    /**
     * Handles checkbox selection logic for table rows
     * 
     * When a row is selected:
     * - For Revista/Default type promotions: Only selects/deselects the specific row
     * - For other promotion types: Selects/deselects all rows related to the same promotion
     * 
     * When no row is provided (header checkbox):
     * - Toggles selection of all rows
     *
     * @param {ChangeEvent<HTMLInputElement>} event - The checkbox change event
     * @param {IMiniCheckoutDetail | null} row - The row being selected, or null for header checkbox
     */
    const handleCheckboxChange = (event: ChangeEvent<HTMLInputElement>, row: IMiniCheckoutDetail | null) => {
        if (row) {
            const isSelected = selectedRows!.includes(row);
            let newSelectedRows: IMiniCheckoutDetail[];

            // Determine if it's a 'Revista' or 'Normal' type promotion
            const isRevistaOrDefault =
                row.tipoPromocionId === PromotionTypesEnum.Default ||
                row.tipoPromocionId === PromotionTypesEnum.Revista;

            if (isSelected) {
                // Deselects the current row and if it's not 'Revista', also selects all related rows to the same promotion
                newSelectedRows = selectedRows.filter((currentRow: { miniCajaDetalleID: number; promocionID: number; }) => {
                    if (isRevistaOrDefault) {
                        // Removes only the specific row
                        return currentRow.miniCajaDetalleID !== row.miniCajaDetalleID;
                    } else {
                        // Removes all rows related to the promotion
                        return currentRow.promocionID !== row.promocionID;
                    }
                });
            } else {
                // Selects the current row
                newSelectedRows = [...selectedRows, row];

                // If it's not 'Revista', selects the rows related to the promotion
                if (!isRevistaOrDefault) {
                    const relatedRows = checkoutInfo.detalle.filter((detalle) =>
                        detalle.promocionID === row.promocionID && !newSelectedRows.includes(detalle)
                    );
                    newSelectedRows = [...newSelectedRows, ...relatedRows];
                }
            }

            setSelectedRows(newSelectedRows);
        } else {
            // Selects or deselects all rows
            setSelectedRows(event.target.checked ? [...checkoutInfo.detalle] : []);
        }
    };

    /**
     * Handles the selection of a branch for the mini box
     * 
     * This function:
     * - Finds the selected branch from the branchesMiniBox array
     * - If a valid branch is found and there's an order summary:
     *   - Sets loading state
     *   - Posts a request to change the branch for the mini box
     *   - Handles the response with handleRequestDto
     *   - Updates the order summary and branchesMiniBox state
     * 
     * @async
     * @param {SelectChangeEvent<number>} event - The select change event
     * @returns {Promise<void>} Promise that resolves when the branch is selected
     */
    const handleBranchChange = async (event: SelectChangeEvent<number>) => {
        const branch = branchesMiniBox.find((branch: { infoSucursalID: string | number; }) => branch.infoSucursalID === event.target.value);
        const kmsApplied = (customers?.[selectedOrderSummary?.clienteId!]?.ordersKms?.[selectedOrderSummary?.pedidoID!]?.kmsInUsePerOrder ?? 0) > 0;
        if (branch && selectedOrderSummary) {
            setLoadingBranchesMiniBox(true);
            const resChangeBranchMiniBoxes = await PostChangeBranchMiniBoxes({
                infoSucursalId: branch.infoSucursalID,
                miniCajaId: checkoutInfo.miniCajaID,
                distancia: branch.distanciaTexto,
                tiempo: branch.tiempoTexto,
                tipoServicioSucursalId: branch.tipoServicioSucursalID,
                aplicoKms: kmsApplied
            });
            handleRequestDto({
                snackBar: showSnackbar,
                response: resChangeBranchMiniBoxes,
                onSuccess: async () => {
                    await fetchSMCResult(selectedOrderSummary.pedidoID, selectedOrderSummary, showSnackbar, dispatch);
                    sendMessageEvaluateOrder(channelCheckoutsRef, selectedOrderSummary, tabId);
                    setLoadingBranchesMiniBox(false);
                },
                onError: () => {
                    setLoadingBranchesMiniBox(false);
                },
                onInvalid: () => {
                    setLoadingBranchesMiniBox(false);
                },
                messages: {
                    error: GENERIC_ERROR_MESSAGE,
                }
            })
        }
    }

    /**
     * Validates if the row is checked
     * 
     * This function:
     * - Checks if the row is in the selectedRows array
     * 
     * @param {IMiniCheckoutDetail} row - The table row to check
     * @returns {boolean} True if the row is checked, false otherwise
     */
    const isChecked = (row: IMiniCheckoutDetail): boolean => selectedRows.findIndex((selected: { miniCajaDetalleID: number; }) => selected?.miniCajaDetalleID === row.miniCajaDetalleID) !== -1;

    /**
     * Manages the logic for delete a box
     * 
     * This function:
     * - Sets the modal transfer state to the provided value
     * 
     * @param {boolean} value - The value to set the modal transfer state to
     */
    const handleModalTransfer = (value: boolean) => {
        setModalTransfer(value);
    };

    /**
     * Manages the logic for delete a box
     * 
     * This function:
     * - Shows the modal to delete the box when transferring all items from the box
     * - Verifies if the box is gray or the primary box
     * 
     * @param {number} transferedItemsSize - The number of items transferred from the modal
     */
    const handleDeleteBox = (transferedItemsSize: number = 0) => {
        try {
            // verify the number of transferred items matches the mini checkout quantity
            if (transferedItemsSize === quantity && checkoutInfo.tipoServicio !== null)
                return handleSetModalEmptyBox(true);

            // reloads the data
            handleSetModalEmptyBox(false);
        } catch (e) {
            handleCathError(e, showSnackbar)
        }
    };

    /**
     * Deletes a mini checkout box by its ID
     * 
     * This function:
     * - Makes an API call to delete the mini box
     * - Shows success/error messages via snackbar
     * - Updates Redux state by removing the deleted box
     * - Refreshes the SMC data
     * 
     * @param {number} miniBoxId - ID of the mini box to delete
     * @param {?boolean | null} kmsApplied - flag indicating if this order contains any kms points
     * @throws {Error} When the selected order summary is null
     */
    const deleteBox = async (miniBoxId: number, kmsApplied?: boolean) => {
        try {
            setLoadingDeleteMiniBox(true);

            const res: IResponseDto<boolean | null> = await deleteBoxMiniBoxId(miniBoxId, kmsApplied);

            handleRequestDto({
                snackBar: showSnackbar,
                response: res,
                messages: {
                    error: 'Error al eliminar la minicaja',
                    invalid: 'No fue posible procesar la solicitud',
                    success: 'Caja eliminada con éxito',
                },
                onSuccess: async () => {
                    if (selectedOrderSummary === null)
                        throw new Error('No fue posible obtener los datos del pedido');

                    dispatch(setMiniCheckouts(miniCheckoutState.miniCheckouts.filter(mini => mini.miniCajaID !== miniBoxId)));
                    await fetchSMCResult(selectedOrderSummary.pedidoID, selectedOrderSummary, showSnackbar, dispatch);
                    sendMessageEvaluateOrder(channelCheckoutsRef, selectedOrderSummary, tabId);
                },
            })
        } catch (error) {
            handleCathError(error, showSnackbar);
        } finally {
            setLoadingDeleteMiniBox(false);
        }
    };


    /**
     * Controls the state of the empty box modal and refreshes data when closing.
     * 
     * When opening the modal (show=true), it simply updates the state.
     * When closing (show=false), it refreshes the SMC data by fetching the latest state.
     * 
     * @param {boolean} show - Whether to show or hide the modal
     * @throws {Error} When selected order summary is null during refresh
     */
    const handleSetModalEmptyBox = async (show: boolean) => {
        try {
            setModalEmptyBox(show);

            // When the modal is opened, it does not perform any tasks
            if (show)
                return;

            if (selectedOrderSummary === null)
                throw new Error('No fue posible obtener los datos del pedido');

            await fetchSMCResult(selectedOrderSummary.pedidoID, selectedOrderSummary, showSnackbar, dispatch);
            sendMessageEvaluateOrder(channelCheckoutsRef, selectedOrderSummary, tabId);
        } catch (e) {
            handleCathError(e, showSnackbar);
        }
    }


    /**
     * Returns the display name for a consolidated mini checkout type based on its numeric value.
     * Maps the TypeConsolidatedEnum values to their corresponding human-readable names.
     *
     * @param {number} selected - The numeric value representing the consolidated type from TypeConsolidatedEnum
     * @returns {TypeConsolidatedNameEnum} The human-readable name of the consolidated type:
     * - "Consolidado Automático" for automatic consolidation
     * - "Consolidado Usuario" for user consolidation 
     * - "Mejor Sucursal" for best branch
     * - "Pedido Dividido" for split order
     * - "Pedido Automático" for automatic order
     * - undefined if the type is not recognized
     */
    const getMessageConsolidate = (selected: number) => {
        switch (selected) {
            case TypeConsolidatedEnum.ConsolidadoAutomatico:
                return TypeConsolidatedNameEnum.ConsolidadoAutomatico;
            case TypeConsolidatedEnum.ConsolidadoUsuario:
                return TypeConsolidatedNameEnum.ConsolidadoUsuario;
            case TypeConsolidatedEnum.MejorSucursal:
                return TypeConsolidatedNameEnum.MejorSucursal;
            case TypeConsolidatedEnum.PedidoDividido:
                return TypeConsolidatedNameEnum.PedidoDividido;
            case TypeConsolidatedEnum.PedidoAutomatico:
                return TypeConsolidatedNameEnum.PedidoAutomatico;
        }
    }

    /**
     * Handles the transfer of a product by validating the order status.
     * Displays a warning if the order has already been sent.
     * 
     * This function:
     * - Validates that the order has not been sent in the main mini checkout
     * - Shows a warning message if the order has already been sent
     */
    const handleTransferProduct = () => {
        //Validate that the order has not been sent in the main mini checkout
        if (selectedOrderSummary!.estatusID === 5) {
            showSnackbar(NOTIFICATIONS_SHIPMENT.SMC.CHECKOUT_SEND.TRANSFER_WARNING, 'warning');
            return;
        }
        setModalTransfer(true);
    }

    /**
     * Handles the shipment checkout process.
     * 
     * This function:
     * - Validates that the main mini checkout is sent before sending the current mini checkout
     * - Shows a warning message if the main mini checkout is not sent
     * - Validates the purchase order
     * - Shows a warning message if the purchase order is not valid
     * - Shows the modal to send the mini checkout
     *
     * @returns {void} This function does not return a value.
     *
     */
    const handleShipmentCheckout = async () => {
        //logic to send mini box
        const checkoutPrimary = miniCheckoutState.miniCheckouts.find(checkout => checkout.principal);
        if (checkoutPrimary?.statusID === 1 && !checkoutInfo.principal) {
            showSnackbar("Debes enviar primero la mini caja principal", 'warning');
            return;
        }
        if (checkoutInfo.principal) {
            //Logic for the main mini box
            validatePurchaseOrder();
        } else {
            setOpenModalSend(true);
        }


    }

    /**
     * Closes the modal by updating the state to indicate that the modal is no longer open.     
     *
     * @returns {void} This function does not return any value. It only updates the modal state.
     */
    const handleCloseModalSend = () => {
        setOpenModalSend(false);
    }

    /**
     * Closes the modal and performs an asynchronous action to fetch the result of an order.
     *
     * @returns {Promise<void>} A promise that resolves when the asynchronous fetch operation is completed.
     */
    const closeModalEnd = async () => {
        setEndedOrderModalState(false);
        if (selectedOrderSummary?.estatusID === StatusOrderEnum.EnviadoSMC) {
            await fetchSMCResult(selectedOrderSummary!.pedidoID, selectedOrderSummary!, showSnackbar, dispatch);
            sendMessageEvaluateOrder(channelCheckoutsRef, selectedOrderSummary, tabId);
        } else if (selectedOrderSummary?.estatusID === StatusOrderEnum.Retenido) {
            router.push(PATH_PAGE.clientes.root)
        }
    }

    /**
     * Determines and returns the appropriate payment method based on the order shipment and OpenPay status.
     * 
     * This function checks the OpenPay payment status for the mini checkout and returns the corresponding payment method:
     * - If payment was made through OpenPay and is marked as paid, returns OpenPay payment method details
     * - Otherwise returns the original payment method from the order shipment
     *
     * @async
     * @param {IOrderShipment} ord - The order shipment object containing payment details
     * @returns {Promise<IGetPayment>} Object containing payment method details:
     *   - openPay: boolean indicating if payment is through OpenPay
     *   - id: payment method ID (4 for OpenPay credit, 5 for OpenPay debit)
     *   - forcePickup: boolean forcing pickup for OpenPay payments
     *   - concessionId: ID of the concession
     *   - forcePue: boolean forcing PUE (Pago en Una sola Exhibición)
     */
    const getPaymentMethod = async (ord: IOrderShipment): Promise<IGetPayment> => {
        const orderIds: number[] = [checkoutInfo.miniCajaID];
        const orderExternal = Number(selectedOrderSummary?.pedidoIdExterno);
        const linkStatus = await getLinkStatus(isExternalOrigin && orderExternal > 0 ? [orderExternal] : orderIds);
        const originalMethod = {
            openPay: false,
            id: ord!.FormaPago!.metodoPagoId!,
            forcePickup: false,
            concessionId: ord.consecion!.concesionId!,
            forcePue: ord!.PUE!
        }
        const id = await handleRequestDto<IStatusOpenPay[] | null, IGetPayment>({
            snackBar: showSnackbar,
            response: linkStatus,
            onSuccess: async () => {
                if (linkStatus.data) {
                    if (linkStatus.data[0].estatusId === StatusOrderOpenPayEnum.Pagado) {
                        return {
                            openPay: true,
                            id: linkStatus.data[0].esDebito ? 5 : 4,
                            forcePickup: true,
                            concessionId: 15,
                            forcePue: true
                        };
                    } else {
                        return originalMethod;
                    }
                }
            },
        }) || originalMethod;
        return id;
    }


    /**
     * Sends a mini checkout request to the server, processes the response, and updates the state accordingly.
     * 
     * This function:
     * 1. Finds any pending mini checkouts that haven't been sent yet
     * 2. Gets the order shipment details and payment method
     * 3. Constructs the request body based on shipping method (delivery or pickup)
     * 4. Sends the request to create the mini checkout
     * 5. Handles the response:
     *    - On success: Updates order status and saves shipping preferences if needed
     *    - On error: Shows error modal
     * 6. Updates UI state (modals, loading indicators)
     *
     * @async
     * @function
     * @returns {Promise<void>} A promise that resolves when the mini checkout is processed
     * @throws {Error} If order summary data is missing
     */
    const sendMiniChekcout = async () => {
        try {
            //Search for pending mini checkouts that haven't been sent yet
            setLoadingConfirm(true);
            setOrderIdsResponse([]);
            const miniCheckoutNoSends = miniCheckoutState.miniCheckouts.filter(checkout => checkout.statusID === 1 && checkout.detalle.length > 0 && checkout.miniCajaID !== checkoutInfo.miniCajaID);
            const orderShipment = (await GetOrderShipmentById(selectedOrderSummary!.pedidoID)).data[0];
            const ord = checkoutInfo.principal ? orderShipment : formData;
            const paymentMethodId = await getPaymentMethod(orderShipment);

            const clientId = selectedOrderSummary?.clienteId;
            const orderId = selectedOrderSummary?.pedidoID;

            const kmsInUse = clientId && orderId
                ? customers?.[clientId]?.ordersKms?.[orderId]?.kmsInUsePerOrder ?? 0
                : 0;
            const kmsApplied = kmsInUse > 0;

            const bodyRequest: ISendMiniCheckoutRequest = ord.MetodoEnvio === ShippingMethodEnum.Domicilio ? mapToAddressRequest(orderShipment, ord, checkoutInfo, selectedOrderSummary!, userAuth!, purchaseOrder, paymentMethodId!, Boolean(formatoOrden?.mascara)) : mapToBranchRequest(orderShipment, ord, checkoutInfo, selectedOrderSummary!, userAuth!, purchaseOrder, paymentMethodId!, Boolean(formatoOrden?.mascara));
            bodyRequest.aplicoKms = kmsApplied;
            if (selectedOrderSummary != null && checkOutList.length > 0) {
                const pedidoExternoId = checkOutList.find((order) => order.pedidoID === `ORD-${selectedOrderSummary.pedidoID.toString()}`);
                if (pedidoExternoId?.origenExternoId) {
                    bodyRequest.PedidoExternoId = pedidoExternoId.origenExternoId;
                }
            }

            const responseSendCheckout = await PostSendMiniCheckout(bodyRequest)

            const setErrorValues = () => {
                setModalConfirm(false);
                setOrderResponse(responseSendCheckout);
                setEndedOrderModalState(true)
            }

            await handleRequestDto({
                snackBar: showSnackbar,
                response: responseSendCheckout,
                onSuccess: async () => {
                    setOrderIdsResponse(responseSendCheckout!.data!.pedidoID.split(',').map(id => Number(id)))
                    // Si es origen externo se manda el pago de openpay a sucursal
                    if (selectedOrderSummary?.origenExternoId === OrigenEnum.Web) {
                        try {
                            const pedidosGenerados = responseSendCheckout!.data!.pedidoID
                                .split(',')
                                .map(id => Number(id));

                            const webPayRequests = pedidosGenerados.map((pedidoSucursalId) =>
                                sendWebPay({
                                    pedidoExternoId: Number(selectedOrderSummary?.pedidoIdExterno),
                                    origenId: bodyRequest.origenId,
                                    pedidoSucursalId,
                                    sucursalId: bodyRequest.sucursalId,
                                    clienteVendedorId: bodyRequest.clienteVendedorId,
                                    usuarioId: bodyRequest.usuarioId
                                })
                            );

                            await Promise.all(webPayRequests);

                        } catch (error) {
                            console.error("Error enviando WebPay", error);
                        }
                    }

                    if (selectedOrderSummary === null)
                        throw new Error('No fue posible obtener los datos del pedido');

                    if (guestCustomers.includes(selectedOrderSummary!.clienteId)) {
                        const newLeadsList = telemarketingLeads.filter(lead => Number(lead.checkoutId?.split('-')[1]) !== selectedOrderSummary.pedidoID);
                        dispatch(setTelemarketingLeadsList(newLeadsList ?? []));
                        dispatch(setTelemarketingLeadsModal(InitTeleMarketingLeadSlice.telemarketingLeadsModal));
                    }

                    await UpdateOrderService(selectedOrderSummary, [{ name: PatchOrderSummaryEnum.estatusInternoId, data: miniCheckoutNoSends.length > 0 ? StatusOrderEnum.EnviadoSMC : StatusOrderEnum.Retenido }], showSnackbar, dispatch);
                    //save orderShipment, if there are pending mini checkouts
                    if (miniCheckoutNoSends.length && checkoutInfo.principal) {
                        await saveShippingPreference(orderShipment, purchaseOrder, showSnackbar);
                    }

                    sendMessageEvaluateOrder(channelCheckoutsRef, selectedOrderSummary, tabId, BroadcastMessageType.UPDATE, miniCheckoutNoSends.length > 0 ? StatusOrderEnum.EnviadoSMC : StatusOrderEnum.Retenido, 'Se actualizó el estado de la caja');

                    if (genericProductsDescriptions) {

                        for (let pedidoId of responseSendCheckout!.data!.pedidoID.split(',').map(id => Number(id))) {

                            await InsertSpecialOrderTlc(pedidoId, checkoutInfo.infoSucursalID, genericProductsDescriptions.map(item => item.id));
                        }

                    }

                   if(kmsApplied != null && kmsApplied){
                        dispatch(setOrderClosed({
                            orderClosed: true,
                            clientId:selectedOrderSummary.clienteId.toString(),
                            orderId:selectedOrderSummary.pedidoID.toString()
                        }));

                    }
                    setModalConfirm(false);
                    setEndedOrderModalState(true);
                },
                onError: () => {
                    setErrorValues();
                },
                onInvalid: () => {
                    setErrorValues();
                },
            })
        } catch (error) {
            showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
        } finally {
            setLoadingConfirm(false);
        }
    }

    /**
     * Validates the purchase order and handles the shipment checkout process.
     * 
     * This function performs several validations:
     * - For non-corporate customers, checks if there are purchase order errors
     * - For corporate customers, validates that purchase order is provided and has no errors
     * - Validates the type of mini checkout and customer type combinations
     * - If validation passes, checks for existing order relations
     * 
     * Based on validations it will:
     * - Show warning messages for invalid purchase orders
     * - Open confirmation modal for valid scenarios
     * - Open partial modal if order relation exists
     * 
     * @returns {Promise<void>} Returns a promise that resolves when validation completes
     * @throws {Error} If there is an error fetching order relations
     */
    const validatePurchaseOrder = async () => {

        if (!skipFormatValidation.current) {
            if (formatoOrden?.obligatorio && purchaseOrder.trim() === '' && formatoOrden.mascara) {
                dispatch(setPurchaseOrderErrorMsj('Orden obligatoria para este cliente'));
                dispatch(setPurchaseOrderError(true));
                showSnackbar('La orden de compra es obligatoria para este cliente', 'warning');
                return;
            }

            if (formatoOrden?.obligatorio && purchaseOrderError && formatoOrden.mascara) {
                showSnackbar('El formato de la orden de compra es incorrecto', 'warning');
                return;
            }

            if (formatoOrden && !formatoOrden.obligatorio && purchaseOrder.trim() === '' && formatoOrden.mascara) {
                setFormatoConfirmTitle('SALIR SIN CAPTURAR ORDEN DE COMPRA')
                setFormatoConfirmMsg('Aún no has capturado la orden de compra. Es posible que en el futuro tengas problemas para relacionar la factura con la orden de compra del cliente.  ¿Está seguro de salir sin capturar la orden de compra? ');
                setModalConfirmFormato(true);
                return;
            }

            if (formatoOrden && !formatoOrden.obligatorio && purchaseOrderError && formatoOrden.mascara) {
                setFormatoConfirmTitle('FORMATO DE ORDEN DE COMPRA INCORRECTO')
                setFormatoConfirmMsg(`El Formato de la orden de compra capturado no corresponde con el formato esperado: ${formatoOrden?.formatoPredefinido}. ¿Desea continuar sin capturar el formato correcto?`);
                setModalConfirmFormato(true);
                return;
            }
            if (!customerInfo?.esCorporativo && purchaseOrderError) {
                showSnackbar(NOTIFICATIONS_ORDERS.PURCHASEORDER.ERROR_PURCHASE_ORDER, 'warning');
                return;
            }

            if (customerInfo!.esCorporativo && (purchaseOrder === '' || purchaseOrderError)) {
                showSnackbar(NOTIFICATIONS_ORDERS.PURCHASEORDER.NOT_PURCHASE_ORDER, 'warning');
                if (purchaseOrder === '') dispatch(setPurchaseOrderErrorMsj('La orden de compra es requerida'));
                return;
            }

            if ((TypeMiniCheckoutEnum.Primary !== typeCheckout && !customerInfo!.esCorporativo)
                || (TypeMiniCheckoutEnum.Primary === typeCheckout && !customerInfo!.esCorporativo && purchaseOrder === '' && !purchaseOrderError)
                || (TypeMiniCheckoutEnum.Primary !== typeCheckout && customerInfo!.esCorporativo)) {
                setOpenModalSend(false);
                setModalConfirm(true);
                return;
            }
        }


        if (!purchaseOrder || purchaseOrder.trim() === '') {
            setOpenModalSend(false);
            setModalConfirm(true);
            return;
        }

        //Fetch to validate order relation in another order
        const responseOrderRelation = await getPurchaseOrderRelation(purchaseOrder);
        await handleRequestDto<boolean | null, boolean>({
            snackBar: showSnackbar,
            response: responseOrderRelation,
            messages: {
                error: 'Error al obtener la relacion de pedidos'
            },
            onSuccess: async () => {
                if (responseOrderRelation.data) {
                    setOpenModalSend(false);
                    setModalPartial(true);
                    return;
                }
                setOpenModalSend(false);
                setModalConfirm(true);
            },
        });
    }

    /**
     * Returns the modal content to display based on the API request result
     * 
     * If orderIdsResponse has values, displays a success modal with:
     * - Order ID
     * - Branch name
     * - Generated order IDs
     * - Status indicators
     * 
     * If orderIdsResponse is empty, displays an error modal with:
     * - Order ID
     * - Branch name  
     * - Error response details
     * - Loading state
     * - Retry action
     * 
     * @returns {JSX.Element} Modal content component based on request result
     */
    const getBodyEndedModal = () => {
        const orderId = selectedOrderSummary?.pedidoID ?? 0;
        const sucursal = miniCheckoutState.miniCheckouts.find(checkout => checkout.miniCajaID === checkoutInfo.miniCajaID)?.nombreSucursal ?? '';
        return orderIdsResponse.length > 0 ?
            <OrderPlacedCorrectly
                orderId={orderId}
                sucursal={sucursal}
                ordersGenerated={orderIdsResponse}
                finished={selectedOrderSummary?.estatusID === StatusOrderEnum.Retenido}
                notFinished={closeModalEnd}
            />
            :
            <OrderPlacedError
                orderId={orderId}
                sucursal={sucursal}
                response={orderResponse}
                isLoading={loadingConfirm}
                handleClick={sendMiniChekcout}
            />
    }
    return (
        <>
            {/* Modal ended order */}
            {
                endedOrderModalState && (
                    <ModalEndedOrder
                        openModal={endedOrderModalState}
                        onClose={closeModalEnd}>
                        {getBodyEndedModal()}
                    </ModalEndedOrder>
                )
            }
            {
                openModalSend && <ModalSendForm
                    open={openModalSend}
                    miniCheckout={checkoutInfo}
                    onSave={validatePurchaseOrder}
                    onClose={handleCloseModalSend}
                    formData={formData}
                    setFormData={setFormData}
                />
            }
            {modalConfirm &&
                <ModalGeneric
                    openModal={modalConfirm}
                    titulo={"Confirmar pedido"}
                    regularTitle={false}
                    btnTextSave="Aceptar"
                    onSave={sendMiniChekcout}
                    onClose={() => setModalConfirm(false)}
                    btndisabledClose={loadingConfirm}
                    isLoading={loadingConfirm}
                >
                    <Typography
                        fontWeight={FontWeightEnum.Bold}
                    >
                        ¿Estas seguro que deseas confirmar el pedido?
                    </Typography>
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                    >
                        Verifica los artículos, método de pago y envío para una mejor experiencia para el cliente
                    </Typography>
                </ModalGeneric>
            }
            {
                modalPartial && <ModalPurchaseOrder
                    open={modalPartial}
                    onClose={() => setModalPartial(false)}
                    onSave={() => {
                        setModalPartial(false)
                        setModalConfirm(true);
                    }}
                />
            }
            {modalConfirmFormato && (
                <ModalGeneric
                    openModal={modalConfirmFormato}
                    titulo={formatoConfirmTitle}
                    regularTitle={false}
                    btnTextSave="Sí"
                    btnTextClose="No"
                    onSave={() => {
                        setModalConfirmFormato(false);
                        skipFormatValidation.current = true;
                        validatePurchaseOrder();
                    }}
                    onClose={() => setModalConfirmFormato(false)}
                >
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                    >
                        {formatoConfirmMsg}
                    </Typography>
                </ModalGeneric>
            )}
            {modalTransfer &&
                <ModalTransferBox
                    open={modalTransfer}
                    sourceBox={selectedRows}
                    boxes={miniCheckoutState.miniCheckouts.filter(checkout =>
                        checkout.infoSucursalID !== checkoutInfo.infoSucursalID
                    )}
                    handleOpenModal={handleModalTransfer}
                    onSuccess={handleDeleteBox}
                    auxInfo={{ sourceInfo: checkoutInfo, quantityProducts: quantity, kmsApplied: kmsApplied }}/>
            }

            {
                modalEmptyBox &&
                <ModalGeneric
                    titulo={`La mini caja de la sucursal #${checkoutInfo.nombreSucursal} ha quedado sin productos`}
                    openModal={modalEmptyBox}
                    regularTitle={false}
                    btnTextSave="Si"
                    btnTextClose="No"
                    isLoading={loadingDeleteMiniBox}
                    onClose={() => handleSetModalEmptyBox(false)}
                    onSave={() => deleteBox(checkoutInfo.miniCajaID, kmsApplied)}
                >
                    <Typography
                        fontWeight={FontWeightEnum.Medium}
                    >
                        ¿Desea eliminarla?
                    </Typography>
                </ModalGeneric>
            }

            <Accordion
                disableGutters
                elevation={0}
                defaultExpanded={defaultExpanded}
                sx={{
                    "&:before": { display: 'none' },
                    border: "1.5px solid",
                    boxShadow: "rgb(194 196 198 / 20%) 0px 3px 4px",
                    borderRadius: "10px !important",
                    borderColor: ColorsEpico.ColorLightBlueishGray,
                    marginBottom: '20px'
                }}
            >
                <Box>
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls={"panel-content-" + title}
                        id={"panel-header-" + title}
                        // El span de contenido de AccordionSummary es un flex item sin
                        // minWidth:0: no encoge por debajo de su min-content y se sale
                        // del relleno del acordeón. La sonda lo nombró con +32 sobre su
                        // padre, que son los 16px de relleno por lado que se comía.
                        sx={[
                            { "& .MuiAccordionSummary-content": { minWidth: 0 } },
                            ...(Array.isArray(sxSummary) ? sxSummary : [sxSummary]),
                        ]}
                    >
                        <Stack
                            pr={{ xs: 0, md: 5.5 }}
                            width={'100%'}
                            direction={'row'}
                            useFlexGap
                            flexWrap="wrap"
                            rowGap={0.5}
                            alignItems={'center'}
                            justifyContent={'space-between'}
                        >
                            {/* flexWrap: los dos distintivos sumaban 350px con el piso de
                                160 y el hueco, contra los ~305 que quedan dentro del
                                acordeón en un teléfono. Sin el piso caben los dos en un
                                renglón; si aun así no caben, el segundo baja en vez de
                                salirse. El piso existe para que en escritorio queden
                                parejos en la columna, que en móvil no es columna. */}
                            <Stack direction='row' alignItems='center' sx={{ gap: '10px', minWidth: 0, flexWrap: 'wrap' }}  >
                                <BadgeGeneric
                                    label={typeCheckout}
                                    color={TypeMiniCheckoutEnum.Primary === typeCheckout ? ColorsEpico.ColorPrimary : TypeMiniCheckoutEnum.Secondary === typeCheckout ? ColorsEpico.ColorSaturateBlue : ColorsEpico.ColorNeutralGray}
                                    minWidth={isMobileExperience ? "auto" : "160px"}
                                />
                                {(!miniCheckoutState.applyDivision && TypeMiniCheckoutEnum.Primary === typeCheckout && miniCheckoutState.logCheckout.tipoConsolidadoID !== TypeConsolidatedEnum.ConsolidadoUsuario) && <BadgeGeneric label={getMessageConsolidate(miniCheckoutState.logCheckout.tipoConsolidadoID)!} color={ColorsEpico.ColorGreenLush} />}
                            </Stack>
                            <Stack direction={"row"} spacing={{ xs: 2, md: 6 }} alignItems="center">
                                <Typography
                                    fontWeight={FontWeightEnum.Regular}
                                    color={ColorsEpico.ColorGray}
                                >
                                    {`(${quantity} ${quantity === 1 ? 'ARTÍCULO' : 'ARTÍCULOS'})`}
                                </Typography>
                                <Stack direction='row' sx={{ whiteSpace: 'nowrap' }}>
                                    <Typography
                                        fontWeight={FontWeightEnum.Regular}
                                        color={ColorsEpico.ColorDarkCharcoal}
                                        fontSize={FontSizesEnum.Alpha}
                                        sx={{ textTransform: 'uppercase', textAlign: 'left', letterSpacing: '1.28px' }}
                                    >
                                        {formattedSubtotal.intCoin}
                                    </Typography>
                                    <Typography
                                        fontWeight={FontWeightEnum.Regular}
                                        color={ColorsEpico.ColorDarkCharcoal}
                                        fontSize={FontSizesEnum.Alpha}
                                        sx={{
                                            display: 'flex',
                                            fontSize: '1rem',
                                            alignItems: 'center',
                                        }}
                                    >
                                        {formattedSubtotal.decimal}
                                    </Typography>
                                </Stack>
                            </Stack>
                        </Stack>
                    </AccordionSummary>
                    <MinicheckoutSubHeader
                        typeCheckout={typeCheckout}
                        defaultValue={checkoutInfo.infoSucursalID}
                        options={optionsStores}
                        time={checkoutInfo.tiempo}
                        distance={checkoutInfo.distancia}
                        service={checkoutInfo.tipoServicio}
                        disableBtnTransfer={selectedRows.length === 0 || checkoutInfo.detalle.length === 0 || openPay.requested}
                        handleTransferProduct={handleTransferProduct}
                        numRows={checkoutInfo.detalle.length}
                        onChange={handleBranchChange}
                        onOpenSelectBranch={getBranchesMiniBox}
                        isLoading={loadingBranchesMiniBox}
                        statusID={checkoutInfo.statusID}
                        openPayDisabled={openPayDisabled}
                    />
                </Box>
                <AccordionDetails sx={{ px: 0, ...sxDetail }}>
                    <Box sx={{ height: 'auto' }}>
                        {isMobileExperience ? (
                            <Stack spacing={1} sx={{ px: 1, py: 1 }}>
                                {/* Paridad con la columna de selección del grid en escritorio: sin
                                    esta barra, transferir una mini caja completa obligaba a tocar
                                    los checkboxes uno por uno. Pasa `null` como fila, que es lo que
                                    handleCheckboxChange interpreta como "seleccionar/limpiar todo". */}
                                {checkoutInfo.detalle.length > 0 && (
                                    <Box sx={{ display: "flex", alignItems: "center", gap: 0.5 }}>
                                        <Checkbox
                                            size="small"
                                            inputProps={{ "aria-label": "Seleccionar todo" }}
                                            onChange={(event) => handleCheckboxChange(event, null)}
                                            indeterminate={selectedRows.length > 0 && selectedRows.length < checkoutInfo.detalle.length}
                                            checked={checkoutInfo.detalle.length > 0 && selectedRows.length === checkoutInfo.detalle.length}
                                            sx={{ p: 1 }}
                                        />
                                        <Typography sx={{ fontWeight: FontWeightEnum.Medium, color: ColorsEpico.ColorGray }}>
                                            Seleccionar todo
                                        </Typography>
                                    </Box>
                                )}
                                {/* ⚠️ Esta derivación está duplicada con la de
                                    AccordionDetailMiniCheckouts.data.tsx. El acuerdo entre
                                    ambas rutas está fijado en
                                    __tests__/app/features/checkout/miniCheckoutArticleParity.test.tsx:
                                    al cambiar aquí, cambiar allá. */}
                                {checkoutInfo.detalle.map((row: IMiniCheckoutDetail) => {
                                    const generic = genericProductsDescriptions?.find((product) => product.producto == row.producto);
                                    const description = generic?.descripcion || row.descripcion;
                                    const imageNode = (generic && generic.imagenUrl)
                                        ? (
                                            // eslint-disable-next-line @next/next/no-img-element
                                            <img src={generic.imagenUrl} width={34} height={28} alt={row.descripcion} />
                                        )
                                        : (
                                            <ImageCell
                                                producto={row.producto ?? ""}
                                                alt={row.descripcion}
                                                width={34}
                                                height={28}
                                                onError={fetchImageProducts}
                                            />
                                        );
                                    const badge = (row.gratis && PromotionTypesEnum.ProductoRegalo === row.tipoPromocionId)
                                        ? <GiftIcon />
                                        : row.promocionID
                                            ? <IconPromo />
                                            : undefined;
                                    return (
                                        <ArticleCard
                                            key={row.miniCajaDetalleID}
                                            imageNode={imageNode}
                                            badge={badge}
                                            code={row.producto}
                                            description={description}
                                            quantity={row.cantidad}
                                            selection={{
                                                checked: isChecked(row),
                                                onChange: (event) => handleCheckboxChange(event, row),
                                            }}
                                        />
                                    );
                                })}
                            </Stack>
                        ) : (
                            <Box sx={{
                                height: 'auto',
                                display: 'grid',
                                gridTemplateColumns: '100%',
                            }}>
                                <DataGridServerPagination
                                    columns={COLUMNS(selectedOrderSummary!, genericProductsDescriptions)}
                                    rows={checkoutInfo.detalle.length ? checkoutInfo.detalle : DEFAULT_RECORD}
                                    rowCount={checkoutInfo.detalle.length ? checkoutInfo.detalle.length : DEFAULT_RECORD.length}
                                    getRowId={(row: { miniCajaDetalleID: any; }) => `${row.miniCajaDetalleID}`}
                                    hideFooter
                                    sx={{
                                        ...sxDataGrid,
                                        paddingX: { xs: '8px', md: '32px' }
                                    }}
                                    checkboxSelected={true}
                                    checkboxField={"producto"}
                                    handleCheckboxChange={handleCheckboxChange}
                                    selectedRows={selectedRows}
                                    isChecked={isChecked}
                                />
                            </Box>
                        )}
                        <MiniCheckoutSummary
                            subtotal={checkoutInfo.subtotal}
                            ivaTotal={checkoutInfo.ivaTotal}
                            ahorroPromociones={checkoutInfo.ahorroPromociones}
                        />
                    </Box>
                    {(TypeMiniCheckoutEnum.New !== typeCheckout && checkoutInfo.statusID === 1) &&
                        <>
                            <Divider />
                            <MiniCheckoutFooter
                                disableSendBox={openPayDisabledSend}
                                handleShipmentCheckout={handleShipmentCheckout}
                            />
                        </>
                    }
                    {children}
                </AccordionDetails>
            </Accordion>
        </>
    )
}