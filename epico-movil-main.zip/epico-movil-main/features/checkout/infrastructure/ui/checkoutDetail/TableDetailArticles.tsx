/* eslint-disable @next/next/no-img-element */
/* eslint-disable react-hooks/exhaustive-deps */
import { DataGridServerPagination } from "@/features/common/infrastructure/ui/tables/DataGridServerPagination";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { IAuth } from "@/features/auth/domain/interfaces/IAuth";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import {
  useAppDispatch,
  useAppSelector,
} from "@/features/common/application/redux/hooks";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { CoinFormatter } from "@/features/common/infrastructure/utils/models/CoinFormatter";
import { setConfigScalesThunk } from "@/features/products/application/redux/ProductThunks";
import { ProductService } from "@/features/products/application/service/product.services";
import { PromotionTypesEnum } from "@/features/promotions/domain/enums/PromotionTypesEnum";
import { IPromotion } from "@/features/promotions/domain/interfaces";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import {
  Box,
  Button,
  Collapse,
  Divider,
  Drawer,
  Grid2,
  IconButton,
  InputAdornment,
  Paper,
  Popover,
  Stack,
  TextField,
  Typography,
  Tooltip,
  Skeleton,
  Link
} from "@mui/material";
import ChevronRight from "@mui/icons-material/ChevronRight";
import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";
import { resolveMobileArticleRow } from "@/features/checkout/infrastructure/ui/checkoutDetail/mobileArticleRow";
import {
  GridActionsCellItem,
  GridColDef,
  GridColumnVisibilityModel,
} from "@mui/x-data-grid";
import { redirect } from "next/navigation";
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  useTransition,
} from "react";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import {
  setProductSelectedDiscounts,
  setPromotionSelected,
  updateProductPromotionCheckout,
} from "@/features/promotions/application/redux/promotionThunks";
import {
  switchLoadingThunk,
  updateOrderSummaryDetail,
  updateOrderSummaryThunk,
} from "@/features/checkout/application/redux/checkOutThunks";
import { actionsCheckout } from "@/features/checkout/application/redux/checkOutSlice";
import { PatchOrderSummaryDetailsEnum } from "@/features/checkout/domain/enums/OrderSummaryDetailsEnum";
import { handleCathError } from "@/features/common/infrastructure/utils/handleCathError";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { debounce } from "lodash";
import { fetchOrderSummariesAction } from "@/features/checkout/application/actions/fetchOrderSummariesAction";
import { ModalProductsPromotions } from "@/features/promotions/infrastructure/ui/Modal/modalProductsPromotions/ModalProductsPromotions";
import { ModalDelete } from "@/features/common/infrastructure/ui/modal/ModalDelete";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { SpecialPriceService } from "@/features/checkout/application/service/specialPrice.services";
import { IClientSellerComplete } from "@/features/seller/domain/interface/IClientSellerComplete";
import { Counter } from "@/features/common/infrastructure/ui/counter/Counter";
import { IconDeployedAlert } from "@/features/common/infrastructure/ui/icons/IconDeployedAlert";
import SelectDiscount from "@/features/checkout/infrastructure/ui/selectDiscount/SelectDiscount";
import { SpecialPriceButton } from "@/features/checkout/infrastructure/ui/specialPrice/ButtonSpecialPrice";
import { fetchAndUpdateOrderSummary } from "@/features/orders/application/actions/fetchAndUpdateOrderSummary";
import { fetchDeniedProducts } from "@/features/products/application/actions/fetchDeniedProducts";
import { getClienteVendedorCompleto } from "@/features/customer/application/actions/db/CustomersRepository";
import { ISpecialPriceResponse } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceResponse";
import { updateOrderDetail } from "@/features/orders/application/actions/updateOrderDetail";
import { fetchDeleteProduct } from "@/features/products/application/actions/fetchDeleteProduct";
import { cancelSpecialPrice } from "@/features/checkout/application/actions/cancelSpecialPrice";
import { fetchSpecialPriceRequest } from "@/features/checkout/application/actions/fetchSpecialPriceRequest";
import { fetchUpdateSpecialPrice } from "@/features/checkout/application/actions/fetchUpdateSpecialPrice";
import { updateSpecialPriceReset } from "@/features/checkout/application/actions/updateSpecialPriceReset";
import { ModalGenericTwoActions } from "@/features/common/infrastructure/ui/modal/modalGenericTwoActions/ModalGenericTwoActions";
import { InputCash } from "@/features/common/infrastructure/ui/inputs/inputCash/InputCash";
import { AccordionGeneric } from "@/features/common/infrastructure/ui/accordion/AccordionGeneric";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { Close, Edit, LocalOffer } from "@mui/icons-material";
import "@/features/checkout/infrastructure/ui/checkoutDetail/TableDetailArticles.styles.css";
import { openChannel } from "@/features/common/infrastructure/adapters/BroadcastChannelAdapter";
import { sendUpdateArticulePromotion } from "@/features/checkout/infrastructure/utils/channel/sendUpdateArticulePromotion";
import { ImageCell } from "@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell";
import { fetchImageProducts } from "@/features/products/application/actions/fetchImageProducts";
import { extraerCodigoProducto } from "@/features/common/infrastructure/utils/extractPrductoCode";
import { SecurityProjectService } from "@/features/branch/application/actions/securityProjectService";
import { regexSafeInput } from "@/features/common/infrastructure/utils/regexGlobal";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import { ILastInvoicedPriceData } from "@/features/checkout/domain/interfaces/ILastInvoicedPrice";
import { GridRenderCellParams } from "@mui/x-data-grid";
import {
  setProductInOrder,
  resetProductKms,
} from "@/features/loyaltyPlan/application/redux/loyaltyPlanSlice";
import { usePathname } from "next/navigation";
import LoyaltyPlanApplyKms from "@/features/loyaltyPlan/infrastructure/ui/loyaltyPlanApplyKms/LoyaltyPlanApplyKms";
import { PickupIcon } from "@/features/common/infrastructure/ui/icons/PickupIcon";
import { BadgeGeneric } from "@/features/common/infrastructure/ui/badge/BadgeGeneric";
import { IResponseDto } from "@/features/common/domain/axios/IResponseDto";
import { IBranch } from "@/features/branch/domain/interfaces/branch";
import { StockService } from "@/features/common/application/service/StockService";
import { branchService } from "@/features/branch/application/services/branch.services";
import { totalStocksNational } from "@/features/checkout/infrastructure/utils/stock/totalStocks";
import { handleRequestStockDto } from "@/features/common/infrastructure/utils/handleRequestStockDto/handleRequestStockDto";
import { loyaltyPlanService } from "@/features/loyaltyPlan/application/service/loyaltyPlanService";
import { IPatchOp } from "@/features/common/domain/axios/IPatchOp";
import { resetKmsSummary } from "@/features/loyaltyPlan/application/Actions/resetKmsSummary"
import { ModalGenericProductDescriptionEdition } from "@/features/products/infrastructure/ui/modalGenericProductDescriptionEdition/ModalGenericProductDescriptionEdition";
import { IGenericProduct } from "@/features/products/domain/interfaces/IGenericProduct";
import { GenericProduct } from "@/features/products/domain/interfaces/IGenericProductList";
import { ProductFamilyId } from "@/features/products/domain/interfaces/IFamiliesList";
import { store } from "@/features/common/application/redux/store";
import { customerService } from "@/features/customer/application/service/customer.services";
import { getPrice, PriceType } from "@/features/common/infrastructure/utils/priceUtils";
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";
import { ChipProcedencia } from "@/features/commercialProposal/infrastructure/ui/ChipProcedencia";

/**
 * Message shown when the special price is removed from a line item that came from a commercial proposal.
 * The text gives no figure because the proposal price is not available in the front end.
 *
 * @constant {string}
 */
const MENSAJE_RETIRO_PRECIO_ESPECIAL_EN_PROPUESTA =
  "Al retirar el precio especial, este producto vuelve al precio de la propuesta — no al de lista.";

/**
 * Visible reason, shown as text next to the control, why a proposal line item does not support promotions.
 *
 * @constant {string}
 */
const MOTIVO_SIN_PROMOCION_EN_PROPUESTA =
  "Precio de propuesta: no admite promoción.";

/**
 * Confirmation message shown when removing a line item that came from a commercial proposal.
 *
 * @constant {string}
 */
const MENSAJE_QUITAR_PARTIDA_DE_PROPUESTA =
  "Si quitas este producto y después lo vuelves a agregar, deja de contar como parte de la propuesta y pierde el precio protegido.";
import { OrigenCotizacionEnum } from "@/features/quotation/domain/enum/OrigenCotizacionEnum";
import { quotationServiceWithFixture } from "@/features/quotation/infraestructure/ui/fixtures/quotationServiceWithFixture";
import { isUserTypeWithoutUserId } from "@/features/users/infrastructure/utils/isUserTypeWithoutUserId";

/**
 * Props del componente {@link ProductKmsEffect}.
 *
 * @interface IProductKmsEffectProps
 * @property {string} productoId - Código del producto para el que se calculan los Kms.
 * @property {number} precioIVA - Precio con IVA usado como base de la conversión a Kms.
 * @property {(productoId: string, precioIVA: number) => void} useProductKms - Hook `useProductKms`
 *   del contenedor, ejecutado por cada card para poblar `productKmsValues[productoId]`.
 */
interface IProductKmsEffectProps {
  productoId: string;
  precioIVA: number;
  useProductKms: (productoId: string, precioIVA: number) => void;
}

/**
 * Componente sin salida visual (`return null`) cuya única responsabilidad es ejecutar
 * el hook `useProductKms` por cada artículo de la vista de cards móvil. Al vivir en su
 * propio límite de componente, cada instancia mantiene el estado/efecto del hook de
 * forma aislada (equivalente a como el DataGrid invoca el hook por celda), respetando
 * las reglas de hooks sin llamarlas dentro de un `.map`.
 *
 * @param {IProductKmsEffectProps} props - Props del efecto.
 * @returns {null} No renderiza UI.
 * @component
 */
const ProductKmsEffect = ({
  productoId,
  precioIVA,
  useProductKms,
}: IProductKmsEffectProps) => {
  useProductKms(productoId, precioIVA);
  return null;
};

/**
 * A partir de esta cantidad de artículos, la lista móvil ofrece un buscador: por debajo
 * caben en un par de pantallas y el campo solo estorbaría.
 */
const MIN_ARTICULOS_PARA_BUSCADOR = 8;

/**
 * TableDetailArticles component that handles the articles detail table in checkout.
 *
 * @component
 * @description Manages the display and manipulation of items in the checkout process,
 * including special prices, discounts, quantities and product removal.
 *
 * Main states:
 * @state {number} price - Current item price
 * @state {number|string} deletedId - ID of item to delete
 * @state {number} pedidoDetalleId - Order detail ID
 * @state {number} specialPriceId - Special price ID
 * @state {string} comment - User comment
 * @state {string} executiveComment - Executive comment
 * @state {number} suggestedPrice - Suggested price
 * @state {boolean} modalSpecialPriceButtonStatus - Special price button state
 * @state {string} denyProduct - Denied product
 * @state {string} modalDeleteMessage - Delete confirmation message
 * @state {number} newCount - New quantity
 * @state {string} productCode - Product code
 * @state {number} packageCuantity - Package quantity
 * @state {boolean} loadingTable - Table loading state
 *
 * Modals:
 * @state {boolean} warningModal - Warning modal
 * @state {boolean} specialPriceModal - Special price modal
 * @state {boolean} denyProductModal - Denied product modal
 * @state {boolean} showDiscountModal - Discounts modal
 * @state {boolean} packageModal - Packages modal
 * @state {boolean} editGenericProductDescriptionModal
 *
 * Services:
 * @service SpecialPriceService - Service to handle special prices
 * @service ProductService - Service to handle products
 */
/**
 * Optional origin and folio of the quotation, when the parent component already knows them.
 * If omitted, the component resolves them from `selectedOrderSummary.cotizacionIdOrigen`.
 */
interface ITableDetailArticlesProps {
  origenCotizacionPropuesta?: {
    origenCotizacion?: OrigenCotizacionEnum;
    idCotizacion?: number;
  };
}

export const TableDetailArticles = ({ origenCotizacionPropuesta: origenCotizacionPropuestaProp }: ITableDetailArticlesProps = {}) => {
  //hooks
  const { showSnackbar } = useSnackbar();
  const { isMobileExperience } = useWindowDimensions();
  const channelCheckoutsRef = useRef<BroadcastChannel | null>(
    openChannel("checkouts")
  );
  const abortStockNationalControllerRef = useRef<AbortController | null>(null);
  const isFetchingStockNationalRef = useRef(false);
  const branchesCacheRef = useRef<IBranch[] | null>(null);
  const [pendingDelete, startPendingDelete] = useTransition();
  const [pendingDeletePromotion, startPendingDeletePromotion] = useTransition();
  const [pendingCancelSpecialPrice, startPendingCancelSpecialPrice] = useTransition();
  const [pendingStockNational, startPendingStockNational] = useTransition();

  //api
  const { getSpecialPriceRequest } = SpecialPriceService();
  const { postListProductsStock } = StockService();
  const { getBranches } = branchService();
  const { postDenyProduct, getProductDiscounts, getScalesConfigPromotion, GetGenericsProductsTlcIds, GetIdsProductsByFamily, DeleteGenericProductTlc } =
    ProductService();
  const { ProjectActiveInSucursal } = SecurityProjectService();
  const { getLastInvoicedPrice } = checkoutServices();
  const { getKmsConversion, addjustAppliedKms } = loyaltyPlanService();
  const { getComercialParameter } = customerService();
  // `getQuotes` already comes enriched with the quotation origin (see quotationServiceWithFixture.ts).
  const { getQuotes } = quotationServiceWithFixture();
  // states
  const [price, setPrice] = useState(0);
  const [deletedId, setDeletedId] = useState<number | string>(0);
  const [productoIdDelete, setProductoIdDelete] = useState<number | string>(0);
  const [pedidoDetalleId, setPedidoDetalleId] = useState<number>(0);
  const [pedidoDetalleIdReset, setPedidoDetalleIdReset] = useState<number>(0);
  const [pedidoDetallePrecioListaReset, setpedidoDetallePrecioListaReset] =
    useState<number>(0);
  const [specialPriceId, setSpecialPriceId] = useState(0);
  const [specialPriceIdReset, setSpecialPriceIdReset] = useState(0);
  const [comment, setComment] = useState("");
  const [executiveComment, setExecutiveComment] = useState("");
  const [suggestedPrice, setSuggestedPrice] = useState(0);
  const [modalSpecialPriceButtonStatus, setModalSpecialPriceButtonStatus] =
    useState(true);
  const [denyProduct, setDenyProduct] = useState<string | undefined>(undefined);
  const [modalDeleteMessage, setModalDeleteMessage] = useState("");
  const [newCount, setNewCount] = useState(0);
  const [productCode, setProductCode] = useState("");
  const [packageCuantity, setPackageCuantity] = useState<number>(0);
  const [addCuantity, setAddCuantity] = useState<number>(0);
  const [oldCuantity, setOldCuantity] = useState<number>(0);
  const [loadingTable, setLoadingTable] = useState<boolean>(false);
  const [readOnly, setReadOnly] = useState(false);
  const [alertTable, setAlertTable] = useState(false);
  /** Artículo abierto en la hoja de edición móvil, por `pedidoDetalleId`. */
  const [articuloEnHoja, setArticuloEnHoja] = useState<number | null>(null);
  /** Filtro de la lista de artículos en móvil (código o descripción). */
  const [filtroArticulos, setFiltroArticulos] = useState("");
  const [onSpecialPriceRules, setSpecialPriceRules] = useState<boolean>(false);
  const [nameCompetitor, setNameCompetitor] = useState("");
  const [brandCompetitor, setBrandCompetitor] = useState("");
  const [productsLoading, setProductsLoading] = useState<Set<string>>(
    new Set()
  );
  const [loadingKms, SetIsLoadingKms] = useState<boolean>();
  const [productKmsValues, setProductKmsValues] = useState<Record<string, number>>({});
  const [isUpdatingKms, setIsUpdatingKms] = useState(false);
  const [product, setProducto] = useState<string | null>();
  const [mostrarExistenciasSMC4, setMostrarExistenciasSMC4] = useState<boolean>(false);
  /**
   * Origin and folio of the source quotation, rendered by `ChipProcedencia`.
   * Resolved with `getQuotes` unless the parent already provides it.
   */
  const [origenCotizacionPropuestaFetched, setOrigenCotizacionPropuesta] = useState<{
    origenCotizacion?: OrigenCotizacionEnum;
    idCotizacion?: number;
  }>({});
  const origenCotizacionPropuesta = origenCotizacionPropuestaProp ?? origenCotizacionPropuestaFetched;


  // modals
  const [warningModal, setWarningModal] = useState<boolean>(false);
  const [isRemoveDiscountModalOpen, setIsRemoveDiscountModalOpen] =
    useState<boolean>(false);
  const [warningOrderModal, setWarningOrderModal] = useState<boolean>(false);
  const [specialPriceModal, setSpecialPriceModal] = useState<boolean>(false);
  const [specialPriceModalReset, setSpecialPriceModalReset] =
    useState<boolean>(false);
  const [specialPriceNegotiatedModal, setSpecialPriceNegotiatedModal] =
    useState<boolean>(false);
  const [denyProductModal, setDenyProductModal] = useState<boolean>(false);
  const [cancelSpecialPriceModal, setCancelSpecialPriceModal] =
    useState<boolean>(false);
  const [specialPriceButtonUpdate, setSpecialPriceButtonUpdate] =
    useState<boolean>(false);
  const [counterButtonState, setCounterButtonState] = useState<boolean>(false);
  const [counterButtonStateReset, setCounterButtonStateReset] =
    useState<boolean>(false);
  const [showDiscountModal, setShowDiscountModal] = useState<boolean>(false);
  const [loadingDiscounts, setLoadingDiscounts] = useState<boolean>(true);
  const [loadingProductsTLC, setLoadingProductsTLC] = useState<boolean>(true)
  const [packageModal, setPackageModal] = useState<boolean>(false);
  const [editGenericProductDescriptionModal, setEditGenericProductDescriptionModal] = useState(false);
  const [lastPriceAnchorEl, setLastPriceAnchorEl] = useState<HTMLElement | null>(null);
  const [lastPriceData, setLastPriceData] = useState<ILastInvoicedPriceData | null>(null);
  const [lastPriceLoading, setLastPriceLoading] = useState(false);
  const [finalPriceModalReset, setFinalPriceModalReset] =  useState<boolean>(false);

  //Modal Decrement Scales
  
  const [pendingScalesDecrement, startPendingScalesDecrement] = useTransition();

  const [scalesDecrementModal, setScalesDecrementModal] = useState<boolean>(false);
  const [pendingScalesDetail, setPendingScalesDetail] = useState<IOrderSummaryDetail | null>(null);
  const [pendingScalesNewCount, setPendingScalesNewCount] = useState<number>(0);
  const [pendingScalesOriginalCount, setPendingScalesOriginalCount] = useState<number>(0);

  // redux
  const dispatch = useAppDispatch();
  const dataCustomer = useAppSelector(
    (state) => state.sessionState?.loyaltyPlanState?.customers
  )!;
  const tabId = useAppSelector((state) => state.sessionState?.windowState?.tabId) ?? null;
  const {
    checkOutList,
    selectedOrderSummary,
    loading,
    quotationState,
  } = useAppSelector(
    (state) => state.sessionState?.checkOutsState
  ) ?? ({} as ICheckOutState);
  const isBlocked = selectedOrderSummary?.estatusInternoId === StatusOrderEnum.OpenPay && selectedOrderSummary?.origenExternoId === OrigenEnum.Web;

  const userAuthState = useAppSelector(
    (state) => state.localState?.authState
  ) as IAuth;
  const detalles: IOrderSummaryDetail[] = selectedOrderSummary?.detalles ?? [];

  /**
   * Map `pedidoDetalleId -> {esPropuestaComercial, folio}`, computed once per order and used by
   * both the desktop grid and the mobile list card to paint `ChipProcedencia`.
   *
   * The origin comes from `esPropuestaComercial` of each line item; the folio belongs to the quotation
   * (`propuestaComercialId` of the header) and only appears in the chip tooltip and `aria-label`.
   */
  const origenLineaPorDetalle = useMemo(() => {
    const folioPropuesta = selectedOrderSummary?.propuestaComercialId
      ? String(selectedOrderSummary.propuestaComercialId)
      : null;

    const mapa = new Map<number, { esPropuestaComercial: boolean; folio: string | null }>();

    detalles.forEach((detalle) => {
      const esDePropuesta = detalle.esPropuestaComercial === true;
      mapa.set(detalle.pedidoDetalleId, {
        esPropuestaComercial: esDePropuesta,
        folio: esDePropuesta ? folioPropuesta : null,
      });
    });

    return mapa;
  }, [detalles, selectedOrderSummary?.propuestaComercialId]);

  /**
   * Artículos que se ven en la lista móvil, con su posición original: el número de
   * renglón tiene que seguir siendo el del artículo en la caja aunque haya filtro.
   */
  const articulosFiltrados = detalles
    .map((detail, index) => ({ detail, index }))
    .filter(({ detail }) => {
      const busqueda = filtroArticulos.trim().toLowerCase();
      if (!busqueda) return true;

      return `${detail.producto ?? ""} ${detail.descripcion ?? ""}`.toLowerCase().includes(busqueda);
    });

  /** Artículo abierto en la hoja de edición. */
  const detalleEnHoja = articuloEnHoja === null
    ? undefined
    : detalles
      .map((detail, index) => ({ detail, index }))
      .find(({ detail }) => detail.pedidoDetalleId === articuloEnHoja);
  const newOrderSummaryRef = useRef(selectedOrderSummary);
  const { telemarketingLeads, telemarketingLeadsModal } = useAppSelector(
    (state) => state.localState?.telemarketingLeadState
  )!;

  const [newDetailState, setNewDetailState] = useState<IOrderSummaryDetail>(
    selectedOrderSummary?.detalles?.[0] || ({} as IOrderSummaryDetail)
  );
  const [customerInfo, setCustomerInfo] =
    useState<IClientSellerComplete | null>(null);
  const [columnVisibilityModel, setColumnVisibilityModel] =
    useState<GridColumnVisibilityModel>({ stockEnSMC: false });

  // producto
  const [orderSummaryDetail, setOrderSummaryDetail] =
    useState<IOrderSummaryDetail>(
      selectedOrderSummary?.detalles?.[0] || ({} as IOrderSummaryDetail)
    );

  const [genericProductsDescriptions, setGenericProductsDescriptions] = useState<IGenericProduct[]>([]);
  const [genericProductSelected, setGenericProductSelected] = useState<IGenericProduct | null>(null);
  const [genericProductsIdsCatalog, setGenericProductsIdsCatalog] = useState<number[]>([]);
  const [doesOrderHasGenericProducts, setOrderHasGenericProducts] = useState<boolean>(false);
  const FamilyIdGenericTlcProduct = +process.env.NEXT_PUBLIC_GENERIC_PRODUCT_TLC!;

  // contants

  const pendingUpdates = useRef<
    Map<
      number,
      { detail: IOrderSummaryDetail; auxCount: number; isPackage: boolean; isPaquetePorEscala: boolean }
    >
  >(new Map());
  const formattedSubtotal = new CoinFormatter(
    selectedOrderSummary?.subTotalIVA ?? 0
  );
  const pathname = usePathname();
  const comesFromCotizacion = pathname.includes("/Cotizacion");
  const changeTotalOfProductsKms = async (params: any) => {
  const clienteId = selectedOrderSummary?.clienteId ?? 0;
  const clienteData = dataCustomer[selectedOrderSummary?.clienteId ?? 0];

  const pedidoID = params.row.pedidoID || selectedOrderSummary?.pedidoID;
  const pedidoDetalleId = params.row.pedidoDetalleId;

    if (!pedidoID || !pedidoDetalleId) {
      return;
    }

    if (clienteData?.customerLoyaltyPlan) {
      const productoKey = String(params.row.producto);

      dispatch(
        setProductInOrder({
          clientId: clienteId.toString(),
          orderId: pedidoID,
          productoKey: productoKey,
          valueOfKms: 0,
          isActiveKms: false,
          isPagoTotal: false,
        })
      );

      setIsUpdatingKms(true);

      try {
        const reqData: IPatchOp[] = [
          {
            op: "replace",
            path: "/Cantidad",
            value: params.row.cantidad,
          },
        ];

        const result = await addjustAppliedKms(
          String(pedidoID),
          String(pedidoDetalleId),
          "0",
          reqData
        );

        await handleRequestDto({
          response: result,
          messages: {
            error: "No se pudo actualizar los kilómetros del producto.",
            invalid: result.error?.mensaje,
          },
          onSuccess: async () => {
            if (result.data != null) {
              await dispatch(
                updateOrderSummaryThunk({
                  ...result.data,
                  cliente: selectedOrderSummary!.cliente,
                })
              );
            }

            updateProductKms(String(params.row.producto), 0);
          },
          onInvalid: async () => {
            console.warn("Respuesta inválida al actualizar KMS");
          },
          onError: async () => {
            console.error("Error al actualizar KMS");
          },
        });
      } catch (error) {
        console.error("Error en changeTotalOfProductsKms:", error);
      } finally {
        setIsUpdatingKms(false);
      }
    }
  };

  const updateProductKms = (productoId: string, kmsValue: number) => {
    setProductKmsValues((prev) => ({
      ...prev,
      [productoId]: kmsValue,
    }));
  };

  const withProductLoading = async (
    productId: string,
    operation: () => Promise<void>
  ): Promise<void> => {
    setProductsLoading((prev) => {
      const newSet = new Set(prev);
      newSet.add(productId);
      return newSet;
    });

    try {
      await operation();
    } finally {
      setProductsLoading((prev) => {
        const newSet = new Set(prev);
        newSet.delete(productId);
        return newSet;
      });
    }
  };

  const anyProductLoading = productsLoading.size > 0;

  const useProductKms = (productoId: string, precioIVA: number) => {
    const lastPrecioIVA = useRef<number | null>(null);
    const lastKmsValue = useRef<number | null>(null);
    const [shouldRecalculate, setShouldRecalculate] = useState(false);
    useEffect(() => {
      if (!anyProductLoading && shouldRecalculate) {
        setShouldRecalculate(false);
        lastPrecioIVA.current = null;
      }
    }, [anyProductLoading, shouldRecalculate]);

    useEffect(() => {
      if (anyProductLoading) return;

      if (lastPrecioIVA.current === precioIVA) return;
      lastPrecioIVA.current = precioIVA;

      const convertKms = async () => {
        if (!selectedOrderSummary || !productoId || isUpdatingKms) return;

        try {
          SetIsLoadingKms(true);
          let valor = 0;

          if (precioIVA > 0) {
            const productosConKms = [
              {
                producto: String(productoId),
                precioProducto: precioIVA,
              },
            ];

            const response = await getKmsConversion(
              String(selectedOrderSummary.clienteId),
              undefined,
              productosConKms
            );

            if (response.data?.data?.puntosProductos) {
              const productoConvertido =
                response.data.data.puntosProductos.find(
                  (x) => x.producto === String(productoId)
                );
              valor = productoConvertido?.puntosProducto || 0;
            }
          }

          if (lastKmsValue.current !== valor) {
            updateProductKms(String(productoId), valor);
            lastKmsValue.current = valor;
          }
        } catch (err) {
          console.warn("Error:", err);
          if (lastKmsValue.current !== 0) {
            updateProductKms(String(productoId), 0);
            lastKmsValue.current = 0;
          }
        } finally {
          SetIsLoadingKms(false);
        }
      };

      convertKms();
    }, [productoId, precioIVA, selectedOrderSummary?.clienteId, anyProductLoading]);
  };

  useEffect(
    () => {

      const getGenericProductsCatalog = async () => {
        const response: IResponseDto<ProductFamilyId[] | null> = await GetIdsProductsByFamily(FamilyIdGenericTlcProduct);

        if (response.huboError) {
          setLoadingProductsTLC(false);
          return;
        }

        setGenericProductsIdsCatalog(response.data?.map(item => item.productoId) ?? []);
        setLoadingProductsTLC(false);
      }

      getGenericProductsCatalog();

    }, []);

  useEffect(
    () => setOrderHasGenericProducts(selectedOrderSummary?.detalles?.filter(product => genericProductsIdsCatalog.includes(product.productoID)).some(item => item) ?? false),
    [genericProductsIdsCatalog]);

  useEffect(() => {

    const mapToGenericProduct = (productDto: GenericProduct): IGenericProduct => {
      return {
        GenericProductId: productDto.id,
        description: productDto.descripcion,
        imageFile: null,
        imageRoute: productDto.imagenUrl,
        OrderId: productDto.pedidoId,
        productNumber: productDto.producto,
        satCode: productDto.claveSat
      }
    }

    setOrderHasGenericProducts(selectedOrderSummary?.detalles?.filter(product => genericProductsIdsCatalog.includes(product.productoID)).some(item => item) ?? false)

    const getGenericProductsDescriptions = async () => {

      const genericDescriptionsDtos: IResponseDto<GenericProduct[] | null> = await GetGenericsProductsTlcIds(selectedOrderSummary?.cotizacionIdOrigen ?? selectedOrderSummary?.pedidoID!);

      if (genericDescriptionsDtos.huboError) {
        showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
        return;
      }

      setGenericProductsDescriptions([...genericProductsDescriptions, ...(genericDescriptionsDtos.data?.map(mapToGenericProduct) ?? [])]);

    }

    if (!selectedOrderSummary || genericProductsDescriptions.some(item => item.OrderId === selectedOrderSummary.pedidoID || item.OrderId === selectedOrderSummary.cotizacionIdOrigen) || !doesOrderHasGenericProducts) {
      return;
    }

    getGenericProductsDescriptions();


  }, [selectedOrderSummary?.pedidoID, selectedOrderSummary?.detalles?.length, doesOrderHasGenericProducts]);

  const COLUMNS: GridColDef<IOrderSummaryDetail>[] = [
    {
      headerName: "#",
      field: "index",
      width: 60,
      align: "center",
      headerAlign: "center",
      sortable: false,
      filterable: false,
      disableColumnMenu: true,
      renderCell: (params) => params.api.getRowIndexRelativeToVisibleRows(params.id) + 1,
    },
    {
      headerName: "Producto",
      field: "producto",
      flex: 1,
      minWidth: 100,
      align: "left",
      headerAlign: "left",
      cellClassName: "producto-cell",
      renderCell: (params) => {
        const findGiftDiscount = (): boolean =>
          params.row.promociones ? params.row.gratis === true : false;
        const allQuantity = detalles
          .filter((pr) => pr.producto === params.row.producto)
          .reduce((stock, pr) => stock + +pr!.cantidad!, 0);
        const getDisabled = (): boolean => userAuthState.userAuth?.engineSMC4 ?
          params.row.stockNacional === "-" ||
          params.row.stockNacional === undefined ||
          params.row.productoNegado === true ||
          (params.row.stockNacional.toString() != "-" &&
            allQuantity <= params.row.stockNacional) ||
          readOnly
          :
          params.row.stockEnSucursal === "-" ||
          params.row.stockEnSucursal === undefined ||
          params.row.productoNegado === true ||
          (params.row.stockEnSucursal.toString() != "-" &&
            allQuantity <= params.row.stockEnSucursal) ||
          readOnly;
        const isActive =
          dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
            selectedOrderSummary?.pedidoID ?? 0
          ]?.products[String(params.row.producto)]?.isActiveKms ?? false;

        const valorProducto = isActive && (params.row.importeIVA ?? 0)
          ? dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
            selectedOrderSummary?.pedidoID ?? 0
          ]?.products[String(params.row.producto)]?.valueProductAfterKms ??
          params.row.importeIVA ?? 0
          : params.row.importeIVA ?? 0;

        const genericProductDescription: IGenericProduct | null = genericProductsDescriptions.find(item => item.productNumber == params.row.producto && (item.OrderId == selectedOrderSummary?.pedidoID || item.OrderId == selectedOrderSummary?.cotizacionIdOrigen)) ?? null;

        useProductKms(String(params.row.producto), valorProducto);
        return (
          <Box
            display="flex"
            alignItems="center"
            justifyContent="space-between"
            gap={2}
            width="100%"
          >
            <Box display="flex" alignItems="center">

              {
                (genericProductDescription && genericProductDescription.imageRoute)
                  ? (<img width={66} height={66} src={genericProductDescription.imageRoute} />)
                  : (
                    <ImageCell
                      producto={
                        extraerCodigoProducto(params.row.producto ?? "") ?? ""
                      }
                      alt={params.row.producto ?? ""}
                      width={66}
                      height={66}
                      onError={fetchImageProducts}
                    />
                  )
              }


            </Box>

            <Box display="flex" flexDirection="column" flex={1}>
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography
                  color={ColorsEpico.ColorBlack}
                  fontWeight={FontWeightEnum.Bold}
                  fontSize={FontSizesEnum.Gamma}
                >
                  #{params.row.producto}
                </Typography>
                <ChipProcedencia folio={origenLineaPorDetalle.get(params.row.pedidoDetalleId)?.folio ?? null} />
                {params.row.pickUp && userAuthState.userAuth?.engineSMC4 && <BadgeGeneric
                  fontSize={FontSizesEnum.Epsilon}
                  sxContainerParam={{
                    height: '20px',
                  }}
                  color={ColorsEpico.ColorChipBackground}
                  textColor={ColorsEpico.ColorChipText}
                  borderRadius={'4px'}
                  label="Exclusivo pickup"
                  icon={<PickupIcon />}
                />}
              </Stack>
              <Typography
                color={ColorsEpico.ColorBlack}
                fontWeight={FontWeightEnum.Regular}
                fontSize={FontSizesEnum.Beta}
                sx={{
                  whiteSpace: "normal",
                  wordBreak: "break-word",
                  overflowWrap: "break-word",
                }}
              >
                {genericProductDescription?.description ?? params.row.descripcion}
              </Typography>
              {
                (Boolean(dataCustomer && selectedOrderSummary &&
                  dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.customerLoyaltyPlan
                ) && !comesFromCotizacion && params.row.familia !== "Pedido" && dataCustomer && selectedOrderSummary && selectedOrderSummary.clienteId != null && dataCustomer[selectedOrderSummary?.clienteId]?.flagUp) ? (
                  <Typography
                    fontSize={FontSizesEnum.Gamma}
                    fontWeight={FontWeightEnum.Bold}
                    color={ColorsEpico.ColorBlack}
                  >
                    {new CoinFormatter(Number(params.row.importe)).coin} ó{" "}
                    {(
                      productKmsValues[String(params.row.producto)] || 0
                    ).toLocaleString()}{" "}
                    Kms
                  </Typography>
                ) : (
                  <Typography
                    fontSize={FontSizesEnum.Gamma}
                    fontWeight={FontWeightEnum.ExtraBold}
                  >
                    {new CoinFormatter(Number(params.row.importe)).coin}
                  </Typography>
                )
              }

              <Box display="flex" alignItems="center" gap={1} mt={1}>
                {!params.row.gratis && !readOnly && !isBlocked &&(
                  <GridActionsCellItem
                    key={`action-delete-${params.row.pedidoDetalleId}`}
                    label="Eliminar"
                    onClick={() =>
                      handleDeleteProduct(
                        params.row.pedidoDetalleId,
                        params.row.precioEspecialId,
                        params.row.promocionID,
                        Number(params.row.producto)
                      )
                    }
                    icon={
                      <Typography
                        sx={{
                          color: ColorsEpico.ColorDodgerBlue,
                          cursor: "pointer",
                          fontWeight: "bold",
                          fontSize: FontSizesEnum.Gamma,
                        }}
                      >
                        Eliminar
                      </Typography>
                    }
                  />
                )}
                {(doesOrderHasGenericProducts) ? (
                  <Link
                    className={!genericProductsIdsCatalog.some(item => item == params.row.productoID) ? "generic-product-description-button" : ""}
                    component="button"
                    onClick={() => {

                      setGenericProductSelected(
                        genericProductsDescriptions.find(item => item.productNumber == params.row.producto && (item.OrderId == selectedOrderSummary?.pedidoID || item.OrderId == selectedOrderSummary?.cotizacionIdOrigen)) ??
                        {
                          OrderId: selectedOrderSummary?.cotizacionIdOrigen ?? selectedOrderSummary!.pedidoID,
                          productNumber: params.row.producto!,
                          imageFile: null,
                          description: null,
                          imageRoute: null,
                          satCode: null,
                          GenericProductId: null
                        }
                      )
                      setEditGenericProductDescriptionModal(true)
                    }}
                    variant="body2"
                    disabled={!genericProductsIdsCatalog.some(item => item == params.row.productoID)}
                    color={ColorsEpico.ColorGrayLight}
                  >
                    <Box display="flex" alignItems="center" gap={1}>
                      <Typography
                        fontSize={FontSizesEnum.Gamma}
                        fontWeight={FontWeightEnum.Medium}
                      >
                        Editar descripción Te lo consigo
                      </Typography>
                      <Edit fontSize="small" />
                    </Box>
                  </Link>) : null}
              </Box>
            </Box >

            <Box display="flex" flexDirection="column" alignItems="center">
              <Box
                sx={{ width: "80%", display: "flex", justifyContent: "center" }}
              >
                <Counter
                  isDisabled={
                    counterButtonState || findGiftDiscount() || readOnly || isBlocked
                  }
                  editable={!findGiftDiscount()}
                  key={`cantidad-${params.id}`}
                  count={params.row.cantidad}
                  handleChangeCount={async (count: number) => {
                    const clienteId = selectedOrderSummary?.clienteId;
                    const pedidoID = selectedOrderSummary?.pedidoID;
                    const productoID = params.row.producto;

                    if (
                      clienteId !== undefined &&
                      pedidoID !== undefined &&
                      productoID !== undefined &&
                      dataCustomer[clienteId]?.ordersKms?.[pedidoID]?.products?.[productoID]?.isActiveKms
                    ) {
                      await changeTotalOfProductsKms(params);
                    }

                    handleChangeCountDetail(count, params.row);
                  }}
                  min={1}
                  inputStyle={{
                    fontSize: FontSizesEnum.Epsilon,
                    width: "100%",
                    height: "0.5rem",
                  }}
                />
              </Box>
              {Number(params.row.stockEnSucursal ?? 0) > 0 && (
                <Typography
                  variant="caption"
                  color={ColorsEpico.ColorBlack}
                  fontSize={FontSizesEnum.Gamma}
                  fontWeight={FontWeightEnum.Bold}
                >
                  {params.row.stockEnSucursal} disponibles
                </Typography>
              )}
              {Number(params.row.stockEnSucursal) <= 0 && (
                <Typography
                  variant="caption"
                  color={ColorsEpico.ColorRed}
                  fontSize={FontSizesEnum.Gamma}
                  fontWeight={FontWeightEnum.Bold}
                >
                  0 disponibles
                </Typography>
              )}
              {userAuthState.userAuth?.engineSMC4 && mostrarExistenciasSMC4 ? pendingStockNational ? <Skeleton variant="text" width={100} height={20} /> : <Tooltip title="Existencias nacionales" arrow>
                <Typography variant="caption" color={(isNaN(Number(params.row?.stockNacional)) || (Number(params.row.stockNacional) > 0 && Number(params.row.stockNacional) >= Number(params.row.cantidad))) ? ColorsEpico.ColorBlack : ColorsEpico.ColorRed} fontSize={FontSizesEnum.Gamma} fontWeight={FontWeightEnum.Bold}>
                  {isNaN(Number(params.row?.stockNacional)) ? '-' : Number(params.row?.stockNacional) <= 0 ? 0 : Number(params.row?.stockNacional)} disponibles
                </Typography>
              </Tooltip> : null}
              {Number(params.row.stockEnSMC ?? 0) > 0 && (
                <Typography
                  variant="caption"
                  color={ColorsEpico.ColorBlack}
                  fontSize={FontSizesEnum.Gamma}
                  fontWeight={FontWeightEnum.Bold}
                >
                  {params.row.stockEnSMC} SMC
                </Typography>
              )}
              {Number(params.row.stockEnSMC) <= 0 && (
                <Typography variant="caption" color={ColorsEpico.ColorRed} fontSize={FontSizesEnum.Gamma} fontWeight={FontWeightEnum.Bold}>
                  0 SMC
                </Typography>
              )}

              {!userAuthState.userAuth?.engineSMC4 && (
                <Box display="flex" alignItems="center" gap={1} mt={1}>
                  <GridActionsCellItem
                    key={`actions-${params.id}`}
                    label="Comentario"
                    onClick={() => {
                      handleDenyProduct(params.row.producto!);
                    }}
                    disabled={getDisabled()}
                    icon={
                      <IconDeployedAlert
                        sx={{
                          color: params.row.productoNegado
                            ? ColorsEpico.ColorGreenLush
                            : (params.row.stockEnSucursal != "-" &&
                              allQuantity > +params.row.stockEnSucursal!)
                              ? ColorsEpico.ColorsDarkBlue
                              : ColorsEpico.GrayClearBlue,
                        }}
                      />
                    }
                  />
                </Box>
              )}
            </Box>
          </Box >
        );
      },
    },
    {
      headerName: "Promoción",
      field: "promocion",
      align: "center",
      headerAlign: "center",
      flex: 0.5,
      minWidth: 260,
      renderCell: (params) => {
        const promo = params.row.promociones?.find(
          (x: IPromotion) => x.id === params.row.promocionID
        );
        // A line item that came from the proposal does not support promotions.
        const esDePropuesta =
          origenLineaPorDetalle.get(params.row.pedidoDetalleId)?.esPropuestaComercial ?? false;
        const promocionesValues: IPromotion[] = Array.isArray(
          params.row.promociones
        )
          ? params.row.promociones
          : [];
        return (
          <Box display="flex" flexDirection="column" alignItems="center">
            <Tooltip
              title={params.row.tipoPrecio === PriceType.Final ?
                "El producto tiene un mejor precio aplicado, se debe cancelar el mejor precio para poder aplicar una promoción" : ""
               }
              arrow>
              <span>
                <SelectDiscount
                  isQuiteDiscount={isRemoveDiscountModalOpen}
                  orderSummaryDetail={params.row}
                  handleShowDiscountModal={handleShowDiscountModal}
                  handleDiscount={async (id, selectedOrderSummary) => {
                    await handleDiscount(
                      id,
                      selectedOrderSummary,
                      params.row.promociones!
                    );
                  }}
                  showDiscountModal={showDiscountModal}
                  disabled={esDePropuesta}
                />
              </span>
            </Tooltip>
            {esDePropuesta ? (
              <Typography
                variant="caption"
                fontSize={FontSizesEnum.Gamma}
                sx={{
                  color: ColorsEpico.ColorDarkCharcoal,
                  backgroundColor: ColorsEpico.ColorGrayDull,
                  px: 1,
                  py: 0.5,
                  borderRadius: 1,
                  // The DataGrid cell clips by default and the text was cut off
                  // mid-word. The row is a fixed 200px (`personalizedRowHeight`),
                  // so wrapping does not change the height of any row.
                  whiteSpace: "normal",
                  textAlign: "center",
                  lineHeight: 1.35,
                  maxWidth: "100%",
                }}
              >
                {MOTIVO_SIN_PROMOCION_EN_PROPUESTA}
              </Typography>
            ) : promocionesValues.length > 0 ? (
              params.row.promocionID === 0 ? (
                <Typography
                  variant="caption"
                  sx={{
                    color: ColorsEpico.ColorDarkCharcoal,
                    backgroundColor: ColorsEpico.ColorGrayDull,
                    px: 1,
                    py: 0.5,
                    borderRadius: 1,
                  }}
                >
                  Sin promoción aplicada
                </Typography>
              ) : (
                <Typography
                  sx={{
                    color: ColorsEpico.ColorDarkCharcoal,
                    backgroundColor: ColorsEpico.ColorGrayDull,
                    px: 1,
                    py: 0.5,
                    borderRadius: 1,
                  }}
                >
                  {promo?.clasificacion}
                </Typography>
              )
            ) : (
              <Typography
                variant="caption"
                fontSize={FontSizesEnum.Gamma}
                sx={{
                  color: ColorsEpico.ColorDarkCharcoal,
                  backgroundColor: ColorsEpico.ColorGrayDull,
                  px: 1,
                  py: 0.5,
                  borderRadius: 1,
                }}
              >
                Sin promociones disponibles
              </Typography>
            )}
          </Box>
        );
      },
    },
    {
      headerName: "Precio final",
      field: "precio",
      type: "actions",
      minWidth: 150,
      align: "center",
      headerAlign: "center",
      flex: 0.5,
      renderCell: (params) => {
        const productoKey = String(params.row.producto);
        const clienteId = selectedOrderSummary?.clienteId;
        const isPagoTotal =
          clienteId && productoKey
            ? dataCustomer[clienteId]?.ordersKms?.[
              selectedOrderSummary?.pedidoID ?? 0
            ]?.products[productoKey]?.isPagoTotal
            : undefined;
        const isValidPrecioEspecialId =
          params.row.precioEspecialId && params.row.precioEspecialId !== 0;
        const hasDiscount = params.row.promocionID !== 0;
        let findDiscount: IPromotion | undefined;
        
        const price = params.row.precio;
        const priceType = params.row.tipoPrecio || PriceType.Lista;

        if (params.row.promociones) {
          findDiscount = params.row.promociones.find(
            (x: IPromotion) =>
              (x.tipoPromocionId === PromotionTypesEnum.Revista &&
                x.id === params.row.promocionID) ||
              (x.tipoPromocionId === PromotionTypesEnum.Paquete &&
                x.id === params.row.promocionID) ||
              (x.tipoPromocionId === PromotionTypesEnum.Escalas &&
                x.id === params.row.promocionID) ||
              (x.tipoPromocionId === PromotionTypesEnum.PaquetePorEscala &&
                x.id === params.row.promocionID)
          );
        }

        const mustShowDiscount =
          (hasDiscount && (findDiscount || params.row.gratis)) || priceType != PriceType.Lista;

        const pedidoId = selectedOrderSummary?.pedidoID ?? 0;
        const orderProductData =
          dataCustomer[clienteId ?? 0]?.ordersKms?.[pedidoId]?.products[
          productoKey
          ];
        const isActive =
          !!dataCustomer[clienteId ?? 0]?.ordersKms[pedidoId]?.products[
          productoKey
          ];

        const valorProducto =
          isActive &&
            isPagoTotal &&
            orderProductData?.valueProductAfterKms !== undefined
            ? orderProductData.valueProductAfterKms
            : params.row.importeIVA ?? 0;

        return (
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-end"
            gap={0.25}
            width="100%"
            marginRight={10}
          >
            <Box display="flex" alignItems="center" gap={0.5}>

              {Number(params.row.ahorroPorcentaje ?? 0) > 0 && (
                <Box
                  px={0.6}
                  py={0.2}
                  borderRadius="6px"
                  bgcolor={ColorsEpico.ColorGreenLush}
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    color={ColorsEpico.ColorBlack}
                    fontSize={FontSizesEnum.Zeta}
                  >
                    {params.row.ahorroPorcentaje}%
                  </Typography>
                </Box>
              )}

              <Typography
                fontSize={FontSizesEnum.Alpha}
                color={ColorsEpico.ColorBlack}
              >
                {new CoinFormatter(Number(price)).coin}
              </Typography>
              {params.row.esPrecioDePreciosPersonalizadas && (
                <Tooltip title="Precio de lista personalizada" arrow>
                  <Typography
                    fontSize={FontSizesEnum.Beta}
                    fontWeight={FontWeightEnum.Bold}
                    color={ColorsEpico.ColorDodgerBlue}
                    sx={{ lineHeight: 1, cursor: 'default' }}
                  >
                    *
                  </Typography>
                </Tooltip>
              )}
            </Box>

            <Typography
              fontSize={FontSizesEnum.Gamma}
              color={ColorsEpico.ColorBlack}
            >
              +IVA {selectedOrderSummary?.porcentajeImpuesto}%
            </Typography>
            {mustShowDiscount ? (
              <Box
                display="flex"
                flexDirection="row"
                alignItems="center"
                gap={1}
              >
                <Typography
                  fontSize={FontSizesEnum.Gamma}
                  fontWeight={FontWeightEnum.Bold}
                  color={ColorsEpico.ColorGrayDisabled}
                  sx={{
                    textDecoration: "line-through",
                    transition: "all 0.3s ease",
                  }}
                >
                  {new CoinFormatter(params.row.precioLista).coin}
                </Typography>
                <Typography
                  fontSize={FontSizesEnum.Alpha}
                  fontWeight={FontWeightEnum.Bold}
                  color={ColorsEpico.ColorBlack}
                  sx={{
                    textDecoration:
                      isPagoTotal &&
                        !!dataCustomer[clienteId ?? 0].ordersKms[
                          selectedOrderSummary?.pedidoID ?? 0
                        ].products[productoKey].isActiveKms
                        ? "line-through"
                        : "none",
                    transition: "all 0.3s ease",
                  }}
                >
                  {new CoinFormatter(valorProducto).coin}
                </Typography>
              </Box>
            ) : (
              <Typography  
                fontSize={FontSizesEnum.Lambda}
                fontWeight={FontWeightEnum.Bold}
                color={ColorsEpico.ColorBlack}
                sx={{
                  textDecoration:
                    isPagoTotal &&
                      !!dataCustomer[clienteId ?? 0].ordersKms[
                        selectedOrderSummary?.pedidoID ?? 0
                      ].products[productoKey].isActiveKms
                      ? "line-through"
                      : "none",
                  transition: "all 0.3s ease",
                }}
              >
                {new CoinFormatter(Number(valorProducto)).coin}
              </Typography>
            )}
            {Boolean(
              dataCustomer && selectedOrderSummary && selectedOrderSummary.clienteId && dataCustomer[selectedOrderSummary?.clienteId]?.customerLoyaltyPlan
            ) && !comesFromCotizacion && selectedOrderSummary && dataCustomer && dataCustomer?.[selectedOrderSummary?.clienteId]?.flagUp === true && params.row.familia !== "Pedido" ? (
              <Typography
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
                color={ColorsEpico.ColorBlack}
              >
                {(
                  productKmsValues[String(params.row.producto)] || 0
                ).toLocaleString()}{" "}
                Kms
              </Typography>
            ) : null}
           {/* <Box
              component="span"
              onClick={async (e) => {
                setLastPriceAnchorEl(e.currentTarget);
                setLastPriceLoading(true);
                setLastPriceData(null);
                try {
                  const response = await getLastInvoicedPrice({
                    productoId: params.row.productoID,
                    clienteVendedorId: selectedOrderSummary?.clienteVendedorId ?? 0,
                  });
                  if (!response.huboError && response.data) {
                    setLastPriceData(response.data);
                  }
                } catch {
                  setLastPriceData(null);
                } finally {
                  setLastPriceLoading(false);
                }
              }}
              sx={{
                display: "inline-flex",
                alignItems: "center",
                gap: 0.5,
                fontSize: FontSizesEnum.Gamma,
                color: ColorsEpico.ColorDodgerBlue,
                cursor: "pointer",
                textDecoration: "underline",
                "&:hover": { color: ColorsEpico.ColorLinkHover },
              }}
            >
              <LocalOffer sx={{ fontSize: 14, color: ColorsEpico.ColorNeutralYellow }} />
              Ver últ. precio
            </Box>*/}
            <Box>
              <Tooltip
                arrow
                title={params.row.tipoPrecio === PriceType.Final ?
                "El producto tiene un mejor precio aplicado" : ""
               }
              >
                <span>
                  <SpecialPriceButton
                    isDisabled={readOnly || isBlocked}
                    isLoading={counterButtonState}
                    orderSummaryDetail={params.row}
                    handleSpecialPrice={handleSpecialPrice}
                  />      
                </span>
              </Tooltip>                    
              {
                <GridActionsCellItem
                  key={`action-${params.row.pedidoID}`}
                  label="Eliminar Precio Especial"
                  onClick={() =>
                    handleOpenModalPrecioEspecial(
                      params.row.precioEspecialId,
                      params.row.pedidoDetalleId,
                      params.row.precioLista,
                      params.row.producto,
                      params.row.tipoPrecio
                    )
                  }
                  icon={
                    <RestartAltIcon
                      sx={{ color: ColorsEpico.ColorDarkCharcoal }}
                    />
                  }
                  sx={{visibility:(!params.row.gratis && isValidPrecioEspecialId && !readOnly) || (priceType == PriceType.Final) ?
                    "visible" : "hidden"
                  }}
                />
              }
            </Box>
          </Box>
        );
      },
    },
    ...(Boolean(dataCustomer && selectedOrderSummary && selectedOrderSummary.clienteId != null &&
      !!dataCustomer?.[selectedOrderSummary?.clienteId]?.customerLoyaltyPlan &&
      !!dataCustomer?.[selectedOrderSummary?.clienteId]?.flagUp &&
      !comesFromCotizacion
    )
      ? [
        {
          headerName: "Pago con Kms",
          field: "pagoConKms",
          align: "center" as const,
          headerAlign: "center" as const,
          flex: 0.3,
          minWidth: 130,
          renderCell: (params: GridRenderCellParams<IOrderSummaryDetail>) => {
            const productoKey = String(params.row.producto);
            const clienteId = selectedOrderSummary?.clienteId;
            const kmsValue =
              dataCustomer[clienteId ?? 0]?.ordersKms?.[
                selectedOrderSummary?.pedidoID ?? 0
              ]?.products[productoKey]?.valueOfKms ?? 0;
            const saldoPuntos =
              dataCustomer?.[clienteId ?? 0]?.customerLoyaltyPlan?.saldoPuntos ?? 0;
            const importeIVA = Number(params.row.importeIVA) * 100 || 0;

            let pagoState: "ninguno" | "parcial" | "total" | "invalido" =
              "ninguno";
            if (kmsValue === 0) pagoState = "ninguno";
            else if (kmsValue > saldoPuntos) pagoState = "invalido";
            else if (kmsValue < importeIVA) pagoState = "parcial";
            else pagoState = "total";

            if (
              params.row.familia === "Pedido" ||
              params.row.gratis == true
            ) {
              return (
                <Box
                  sx={{
                    whiteSpace: "normal",
                    wordBreak: "break-word",
                    textAlign: "center",
                  }}
                >
                  <Typography
                    color={ColorsEpico.ColorGrayDisabled}
                    fontSize={FontSizesEnum.Alpha}
                  >
                    No disponible para pago con Kms
                  </Typography>
                </Box>
              );
            }

            return (
              <LoyaltyPlanApplyKms
                params={params}
                dataCustomer={dataCustomer}
                selectedOrderSummary={selectedOrderSummary}
                dispatch={dispatch}
                withProductLoading={withProductLoading}
                valueKmsProvider={
                  productKmsValues[String(params.row.producto)] || 0
                }
              />
            );
          },
        },
      ]
      : []),
  ];

  // Effects
  useEffect(() => {
    const fetchMostrarExistencias = async () => {
      const result = await getComercialParameter(
        process.env.NEXT_PUBLIC_PARAMETRO_COMERCIAL_EXISTENCIAS ??
        "MostrarExistenciasSMC4"
      );

      setMostrarExistenciasSMC4(result.data?.valor === "True");
    };

    fetchMostrarExistencias();
  }, []);

  /**
   * Resolves the origin of the quotation this order comes from (`cotizacionIdOrigen`),
   * so `ChipProcedencia` can be painted on the lines, when the parent did not pass it already resolved.
   *
   * @effect
   * @dependencies [selectedOrderSummary?.cotizacionIdOrigen, selectedOrderSummary?.clienteVendedorId]
   */
  useEffect(() => {
    if (origenCotizacionPropuestaProp) return;

    const cotizacionIdOrigen = selectedOrderSummary?.cotizacionIdOrigen;
    const clienteVendedorId = selectedOrderSummary?.clienteVendedorId;

    if (!cotizacionIdOrigen || !clienteVendedorId) {
      setOrigenCotizacionPropuesta({});
      return;
    }

    const fetchOrigenCotizacion = async () => {
      const isUserType = isUserTypeWithoutUserId(userAuthState.userAuth?.userTypeId);
      const userIdToSend = isUserType ? undefined : userAuthState.userAuth?.userId ?? 0;

      const response = await getQuotes(clienteVendedorId, userIdToSend, cotizacionIdOrigen);

      if (response.huboError || !response.data) return;

      const [quoteConFixture] = response.data;

      setOrigenCotizacionPropuesta({
        origenCotizacion: quoteConFixture?.origenCotizacion,
        idCotizacion: quoteConFixture?.idCotizacion ?? cotizacionIdOrigen,
      });
    };

    fetchOrigenCotizacion();
  }, [selectedOrderSummary?.cotizacionIdOrigen, selectedOrderSummary?.clienteVendedorId, origenCotizacionPropuestaProp]);

  useEffect(() => {
    if (selectedOrderSummary?.pedidoID && !loading && userAuthState.userAuth?.engineSMC4 && mostrarExistenciasSMC4 && !loadingProductsTLC) {
      getStockNational();
    }
  }, [selectedOrderSummary?.pedidoID, detalles.length, userAuthState.userAuth?.engineSMC4, mostrarExistenciasSMC4, loadingProductsTLC])

  /**
   * Updates and fetches order summary data when the order ID changes
   *
   * @effect
   * @dependency selectedOrderSummary?.pedidoID - Triggers when order ID changes
   * @action Updates order summary ref and fetches latest order data
   */
  useEffect(() => {
    const activeCheckOut = checkOutList.find(
      (checkOut) => checkOut.active === true
    );
    if (
      !loading &&
      selectedOrderSummary &&
      ((activeCheckOut &&
        selectedOrderSummary.pedidoID === +activeCheckOut.pedidoID) ||
        selectedOrderSummary.estatusID === 4)
    ) {
      setReadOnly(quotationState.readOnlyQuotation);
      setAlertTable(
        !quotationState.readOnlyQuotation &&
        selectedOrderSummary.estatusID === StatusOrderEnum.Facturado
      );
      newOrderSummaryRef.current = selectedOrderSummary;
      fetchAndUpdateOrderSummary(
        true,
        selectedOrderSummary,
        showSnackbar,
        dispatch,
        selectedOrderSummary.estatusID === 4 ? quotationState.historialId : 0
      );
    }
  }, [selectedOrderSummary?.pedidoID]);

  /**
   * Fetches denied products when order details or destination branch changes
   *
   * @effect
   * @dependencies [pedidoID, sucursalIdDestino, detalles.length, loadingTable]
   * @action Fetches denied products and updates stock deletion flag
   */
  useEffect(() => {
    if (!loading && !loadingTable && !userAuthState.userAuth?.engineSMC4) {
      fetchDeniedProducts(selectedOrderSummary!, showSnackbar, dispatch);
    }
  }, [
    selectedOrderSummary?.pedidoID,
    selectedOrderSummary?.sucursalIdDestino,
    selectedOrderSummary?.detalles?.length,
    loadingTable,
  ]);

  /**
   * Fetches customer information when vendor/client ID changes
   *
   * @effect
   * @dependencies [clienteVendedorId, loading, loadingTable]
   * @action Updates customer info state with fetched data
   */
  useEffect(() => {
    const customerInfo = async () => {
      if (selectedOrderSummary && selectedOrderSummary.clienteId !== 0)
        setCustomerInfo(
          await getClienteVendedorCompleto(selectedOrderSummary.clienteId)
        );
    };
    customerInfo();
  }, [selectedOrderSummary?.clienteVendedorId, loading, loadingTable]);

  /**
   * Updates column visibility based on customer SMC status
   *
   * @effect
   * @dependency customerInfo - Triggers when customer info changes
   * @action Updates column visibility model for SMC stock
   */
  useEffect(() => {
    if (customerInfo)
      setColumnVisibilityModel({
        stockEnSMC: customerInfo.AplicaClienteSMC || false,
      });
    if (customerInfo) onSpecialPriceRulesActive(customerInfo.sucursalId);
  }, [customerInfo]);

  // handlers
  /**
   * Retrieves the national stock for products.
   *
   * Executes the startPendingStockNational function which manages the loading state,
   * and then calls fetchListProductsStock to fetch and update the national stock list for products.
   *
   * @async
   * @function getStockNational
   * @returns {Promise<void>} Resolves when the request for national stock has completed.
   */
  const getStockNational = async (): Promise<void> => {
    startPendingStockNational(async () => {
      await fetchListProductsStock();
    });
  }
  /**
   * Fetches the list of branches from the API, sorts them alphabetically by name, 
   * and returns the sorted array.
   * Provides feedback via a snackbar and handles errors appropriately.
   *
   * @function fetchBranches
   * @async
   * @returns {Promise<IBranch[]>} The sorted array of branches, or an empty array if none found or an error occurs.
   */
  const fetchBranches = useCallback(async (): Promise<IBranch[]> => {
    if (branchesCacheRef.current) return branchesCacheRef.current;

    const resBranches: IResponseDto<IBranch[] | null> = await getBranches();

    const branches =
      (await handleRequestDto<IBranch[] | null, IBranch[]>({
        snackBar: showSnackbar,
        response: resBranches,
        onSuccess: () => {
          const branchesSorted =
            resBranches.data?.sort((a, b) =>
              a.sucursal.localeCompare(b.sucursal)
            ) ?? [];
          return branchesSorted;
        },
        messages: {
          error: "Error al obtener las sucursales",
          invalid: "Petición invalida de sucursales revise los datos",
        },
      })) || [];

    branchesCacheRef.current = branches;
    return branches;
  }, [getBranches, showSnackbar]);

  /**
   * Fetches and updates the national stock for products with undefined or non-numeric stock values.
   *
   * @async
   * @function fetchListProductsStock
   * @returns {Promise<void>}
   */
  const fetchListProductsStock = useCallback(async () => {
    if (selectedOrderSummary?.estatusID !== StatusOrderEnum.Activo && selectedOrderSummary?.estatusID !== StatusOrderEnum.Facturado) return;
    if (isFetchingStockNationalRef.current) return;
    const detailsOutOfStock = detalles.filter(detail => isNaN(Number(detail.stockNacional)) && !genericProductsIdsCatalog.includes(detail.productoID));

    // If there are no details out of stock, return
    if (detailsOutOfStock.length === 0) return;

    isFetchingStockNationalRef.current = true;
    try {

      const branches = await fetchBranches();
      // If there are no branches, return
      if (branches.length === 0) return;
      // Abort the previous request if it exists
      if (abortStockNationalControllerRef.current) {
        abortStockNationalControllerRef.current.abort();
      }

      // Create a new abort controller
      const abortController = new AbortController();
      abortStockNationalControllerRef.current = abortController;

      // Make the request to get the national stock
      const response = await postListProductsStock({
        sucursales: branches.map(branch => branch.id),
        productos: detailsOutOfStock.map(detail => detail.producto ?? ""),
      }, abortController.signal);

      handleRequestStockDto({
        response: response,
        onSuccess: async () => {
          abortStockNationalControllerRef.current = null;
          // If there are no products in the response, return
          if (!response.data || response.data?.length === 0) return;

          // Cede el hilo antes de calcular
          await new Promise<void>((resolve) =>
            requestAnimationFrame(() => resolve())
          );

          // Calculate the total national stock for the products
          const stocksNationals = totalStocksNational(response?.data ?? [], detailsOutOfStock.map(detail => detail.producto ?? ""));
          const currentDeails = store.getState().sessionState.checkOutsState.selectedOrderSummary?.detalles ?? detalles;
          const updatedDetails = currentDeails.map(detail => ({
            ...detail,
            stockNacional: (genericProductsIdsCatalog.includes(detail.productoID) ? '-' : detail?.stockNacional && Number(detail.stockNacional) >= 0 ? Number(detail.stockNacional) : stocksNationals[detail.producto ?? ""] ?? 0) as number | "-" | undefined,
          }));

          await dispatch(updateOrderSummaryDetail(updatedDetails));
        },
        onError: () => {
          if (response.statusCode === 'ERR_CANCELED') return;
          showSnackbar("Ocurrio un error al obtener las existencias nacionales", "error");
        },
      });
    } finally {
      isFetchingStockNationalRef.current = false;
    }
  }, [detalles, fetchBranches, postListProductsStock]);

  /**
   * Updates the order summary details with special price data.
   *
   * @param {ISpecialPriceResponse[]} specialPriceData - Array of special price data containing pricing details for specific products.
   * @returns {IOrderSummary} The updated order summary with special price details.
   */
  const updateOrderSummaryWithSpecialPrices = (
    specialPriceData: ISpecialPriceResponse[]
  ): IOrderSummary => {
    return {
      ...selectedOrderSummary!,
      detalles: selectedOrderSummary!.detalles?.map((detalle) => {
        const matchingData = specialPriceData.find(
          (data) => data.productoId === detalle.productoID
        );
        if (matchingData) {
          return {
            ...detalle,
            precioSolicitado: matchingData.precioSolicitado,
            cantidadPrecioEspecial: matchingData.cantidad,
            comentarioEjecuto: matchingData.comentarioEjecuto,
            estatusPrecioEspecialId: matchingData.estatusPreciosEspecialesId,
            precioMinimoSugeridoParaToken:
              matchingData.precioMinimoSugeridoParaToken,
          };
        } else {
          return detalle;
        }
      }),
    };
  };

  /**
   * Fetches the scale configuration from the API.
   *
   * @async
   * @function fetchScalesConfig
   * @returns {Promise<void>} Resolves after fetching and dispatching the scale config.
   */
  const fetchScalesConfig = async (promotionId: number) => {
    const response = await getScalesConfigPromotion(promotionId);
    if (response?.statusCode === 200) {
      await dispatch(await setConfigScalesThunk(response.data!));
    }
  };

  /**
   * Handles the selection of a discount for an order detail.
   *
   * This function manages the application of discounts and promotions to order details.
   * It validates OpenPay payment status, handles different promotion types including scales,
   * and updates the order details with the selected promotion.
   *
   * @param {number} id - The ID of the promotion to be applied
   * @param {IOrderSummaryDetail} orderSummaryDetail - The order summary detail containing product and order information
   * @param {IPromotion[]} promociones - Array of available promotions that can be applied to the order
   * @returns {Promise<void>} A promise that resolves when the discount handling is completed
   * @throws Will show error message if discount application fails
   */
  const handleDiscount = async (
    id: number,
    orderSummaryDetail: IOrderSummaryDetail,
    promociones: IPromotion[]
  ): Promise<void> => {
    //Validate that the order does not have open pay payment.
    if (selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay) {
      showSnackbar(NOTIFICATIONS_CHECKOUT.OPEN_PAY.NOTIFICATION, "warning");
      return;
    }
    try {
      const aux = promociones.find((x: IPromotion) => x.id === id);
      if (+id && aux?.tipoPromocionId !== 1 && aux?.tipoPromocionId) {
        // open the modal to apply the discount
        setShowDiscountModal(true);
        await dispatch(await setPromotionSelected(aux!));
        if (aux.tipoPromocionId === PromotionTypesEnum.Escalas) {
          await fetchScalesConfig(id);
        }
      } else if (aux === undefined) {
        // open the modal to remove the discount
        setIsRemoveDiscountModalOpen(true);
        setPedidoDetalleId(id);
        setOrderSummaryDetail(orderSummaryDetail);
      } else {
        await dispatch(switchLoadingThunk(true));
        const newDetail = {
          ...orderSummaryDetail,
          promocionID: id,
        } as IOrderSummaryDetail;
        dispatch(
          actionsCheckout.setDetailById({
            id: orderSummaryDetail.pedidoDetalleId,
            newDetail,
          })
        );
        await updateOrderDetail(
          orderSummaryDetail.pedidoDetalleId,
          selectedOrderSummary,
          [
            {
              name: PatchOrderSummaryDetailsEnum.PromocionID,
              data: id,
            },
          ],
          showSnackbar,
          dispatch,
          false,
          selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
        );
        sendUpdateArticulePromotion(
          channelCheckoutsRef,
          selectedOrderSummary!,
          tabId
        );
      }
    } catch (e) {
      handleCathError(e, showSnackbar);
    } finally {
      await dispatch(switchLoadingThunk(false));
    }
  };

  /**
   * Handles the selection of a modal to open and sets the corresponding modal message
   * when attempting to delete a product from the order.
   *
   * This function determines which modal to show and what message to display based on:
   * - If it's the last product in the order (shows order deletion warning)
   * - If the product has promotions applied
   * - If the product has special pricing
   *
   * @param {number | string} id - The ID of the product to be deleted
   * @param {number} [specialPriceId=0] - The ID of the special price if one exists
   * @param {number} [promocionID] - The ID of any promotion applied to the product
   * @param {number} [productoID] - The ID of any product to delete
   */
  const handleDeleteProduct = (
    id: number | string,
    specialPriceId: number = 0,
    promocionID?: number,
    productoId?: number
  ) => {
    let modalText: string = "";

    if (selectedOrderSummary?.detalles) {
      if (selectedOrderSummary.detalles.length === 1) {
        modalText =
          selectedOrderSummary.estatusID === 4
            ? "Si eliminas esta cotización, se perderá la cotización y los productos relacionados."
            : "Si eliminas esta caja, se perderá el pedido y los productos relacionados.";
        setWarningOrderModal(true);
      } else {
        // Removing a proposal line item cannot be undone by adding it back (it loses its origin and
        // protected price), so its notice replaces the generic one and takes precedence over the promotion one.
        if (origenLineaPorDetalle.get(Number(id))?.esPropuestaComercial) {
          modalText = MENSAJE_QUITAR_PARTIDA_DE_PROPUESTA;
        } else if (promocionID) {
          modalText =
            "El producto es parte de una promoción, la cual se modificará o eliminará.";
        } else {
          modalText =
            "Si eliminas este producto, se descontará del pedido actual.";
        }
        setWarningModal(true);
      }
    }

    if (specialPriceId) {
      modalText +=
        "\nAdemás, se CANCELARÁ el precio especial asignado a este producto.";
    }

    setModalDeleteMessage(modalText);
    setSpecialPriceId(specialPriceId);
    setDeletedId(id);
    setProductoIdDelete(String(productoId));
  };

  /**
   * Handles changes to the comment input field and updates the special price modal button state.
   *
   * This function:
   * 1. Validates the comment text against an allowed character regex
   * 2. Updates the comment state if validation passes
   * 3. Enables/disables the modal button based on:
   *    - Price being non-zero
   *    - Comment being non-empty
   *    - Comment containing non-whitespace characters
   *
   * @param {React.ChangeEvent<HTMLInputElement>} event - The input change event
   */
  const handleCommentChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const { value: newComment } = event.target;
    const regex = /^[a-zA-ZáéíóúÁÉÍÓÚüÜñÑ0-9.\-,¡!¿?:;()#\$%\+\='/\s"" ]*$/;
    const trimmedComment = newComment.trim();
    if (regex.test(newComment) || newComment === "") {
      setComment(newComment);
      if (price !== 0 && newComment !== "" && trimmedComment !== "")
        setModalSpecialPriceButtonStatus(false);
    }
    if (price === 0 || newComment === "" || trimmedComment === "")
      setModalSpecialPriceButtonStatus(true);
  };

  /**
   * Handles changes to the price input field and updates the special price modal button state.
   *
   * This function:
   * 1. Updates the price state with the new numeric value
   * 2. Enables/disables the modal button based on:
   *    - Price being non-zero
   *    - Comment being non-empty
   *    - Comment containing non-whitespace characters
   *
   * @param {React.ChangeEvent<HTMLInputElement>} event - The input change event containing the new price value
   */
  const handlePriceChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newPrice = Number(event.target.value);
    setPrice(newPrice);
    const trimmedComment = comment.trim();
    if (newPrice !== 0 && comment !== "" && trimmedComment !== "") {
      setModalSpecialPriceButtonStatus(false);
    }

    if (newPrice === 0 || comment === "" || trimmedComment === "") {
      setModalSpecialPriceButtonStatus(true);
    }
  };

  /**
   * Handles changes to the comment input field nameCompetitor
   *
   * This function:
   * 1. Validates the comment text against an allowed character regexSafeInput
   * 2. Updates the comment state if validation passes
   *
   * @param {React.ChangeEvent<HTMLInputElement>} event - The input change event
   */
  const handleNameCompetitorChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { value: newNameCompetitor } = event.target;

    if (regexSafeInput.test(newNameCompetitor)) {
      setNameCompetitor(newNameCompetitor);
    }
  };

  /**
   * Handles changes to the comment input field brandCompetitor
   *
   * This function:
   * 1. Validates the comment text against an allowed character regexSafeInput
   * 2. Updates the comment state if validation passes
   *
   * @param {React.ChangeEvent<HTMLInputElement>} event - The input change event
   */
  const handleBrandCompetitorChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const { value: newBrandCompetitor } = event.target;

    if (regexSafeInput.test(newBrandCompetitor)) {
      setBrandCompetitor(newBrandCompetitor);
    }
  };

  /**
   * Handles the special price modal logic for a given order summary detail.
   * This function:
   * 1. Validates if the order has OpenPay payment status
   * 2. Sets the order summary detail state
   * 3. Checks the special price status:
   *    - If negotiated: Fetches special price request, updates order summary and shows negotiated modal
   *    - If not negotiated: Shows regular special price modal with empty values
   *
   * @async
   * @param {IOrderSummaryDetail} orderSummaryDetail - The details of the order summary related to the special price
   * @returns {Promise<void>} A promise that resolves after handling the special price logic
   * @throws {Error} If the detail with provided specialPriceId is not found
   */
  const handleSpecialPrice = async (
    orderSummaryDetail: IOrderSummaryDetail
  ) => {
    //Validate that the order does not have open pay payment.
    if (selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay) {
      showSnackbar(NOTIFICATIONS_CHECKOUT.OPEN_PAY.NOTIFICATION, "warning");
      return;
    }
    setOrderSummaryDetail(orderSummaryDetail);
    if (
      orderSummaryDetail.estatusPrecioEspecialId ==
      SpecialPriceStates.Negociado.index
    ) {
      const res = await getSpecialPriceRequest([
        orderSummaryDetail.precioEspecialId,
      ]);
      if (selectedOrderSummary) {
        let updatedOrderSummary: IOrderSummary = { ...selectedOrderSummary };
        const detailIndex = updatedOrderSummary.detalles?.findIndex(
          (detalle) =>
            detalle.precioEspecialId === orderSummaryDetail.precioEspecialId
        );

        if (detailIndex !== -1 && detailIndex !== undefined) {
          updatedOrderSummary = updateOrderSummaryWithSpecialPrices(res.data!);
          await dispatch(updateOrderSummaryThunk(updatedOrderSummary));

          const detail: IOrderSummaryDetail =
            updatedOrderSummary.detalles![detailIndex];

          setSpecialPriceNegotiatedModal(true);

          if (detail) {
            setExecutiveComment(detail.comentarioEjecuto);
            setSuggestedPrice(detail.precioMinimoSugeridoParaToken);
            setSpecialPriceButtonUpdate(false);
          }
        } else {
          console.error(
            "No se encontró el detalle con el precioEspecialId proporcionado."
          );
        }
      }
    } else {
      setSpecialPriceModal(true);
      setComment("");
      setPrice(0);
      setModalSpecialPriceButtonStatus(true);
      setNameCompetitor("");
      setBrandCompetitor("");
    }
  };

  /**
   * Handles the denial of a product by setting the denied product state and opening the denial modal.
   * This function is called when a user wants to deny a product in the checkout process.
   * It performs two actions:
   * 1. Sets the product name in the denyProduct state
   * 2. Opens the denial confirmation modal by setting denyProductModal to true
   *
   * @param {string} product - The name of the product to be denied
   * @example
   * ```ts
   * handleDenyProduct("Product XYZ")
   * // Sets denyProduct state to "Product XYZ" and opens denial modal
   * ```
   */
  const handleDenyProduct = (product: string) => {
    setDenyProduct(product);
    setDenyProductModal(true);
  };

  /**
   * Sets a product as denied in the order summary and updates the product details in the backend.
   * This function takes an array of order summary details and marks each product as denied by setting
   * the 'productoNegado' flag to true. It then dispatches an action to update these changes in the store
   * and backend.
   *
   * @async
   * @param {IOrderSummaryDetail[]} product - Array of order summary details to be marked as denied
   * @returns {Promise<void>} A promise that resolves when the products have been successfully updated
   * @throws {Error} Throws and handles error by showing a generic error message if update fails
   * @example
   * ```ts
   * // Mark multiple products as denied
   * await handleSetDeniedProduct([
   *   { id: 1, productoNegado: false, ...otherDetails },
   *   { id: 2, productoNegado: false, ...otherDetails }
   * ]);
   * ```
   */
  const handleSetDeniedProduct = async (product: IOrderSummaryDetail[]) => {
    try {
      const updatedProduct: IOrderSummaryDetail[] = product.map(
        (currentProduct) => ({ ...currentProduct, productoNegado: true })
      );
      await dispatch(updateOrderSummaryDetail(updatedProduct));
    } catch (_error) {
      showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
    }
  };

  /**
   * Handles the closing of the discount modal.
   *
   * @returns {Promise<void>} A promise that resolves when the modal has been closed.
   */
  const handleHideDiscountModal = async () => {
    setShowDiscountModal(false);
    setLoadingDiscounts(true);
    // Clear discounts values
    await dispatch(await setPromotionSelected(undefined));
    await dispatch(await setProductSelectedDiscounts([]));
    await dispatch(await updateProductPromotionCheckout(0, 0, [], [], []));
  };

  /**
   * Handles the opening of the discount modal.
   *
   * @param {number} productId - The ID of the product for which to show the discount modal.
   */
  const handleShowDiscountModal = (productId: number) => {
    //Validate that the order does not have open pay payment.
    if (selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay) {
      showSnackbar(NOTIFICATIONS_CHECKOUT.OPEN_PAY.NOTIFICATION, "warning");
      return;
    }
    fetchProductDiscounts(productId);
    setShowDiscountModal(true);
  };

  /**
   * Fetches discounts for a specific product.
   *
   * @param {number} productId - The ID of the product for which to fetch discounts.
   * @returns {Promise<void>} A promise that resolves when the discounts have been fetched.
   */
  const fetchProductDiscounts = async (productId: number): Promise<void> => {
    const productDiscountsResponse = await getProductDiscounts(
      selectedOrderSummary?.clienteId ?? 0,
      productId,
      selectedOrderSummary?.origenExternoId ?? 0
    );
    handleRequestDto({
      response: productDiscountsResponse,
      onSuccess: async () => {
        await dispatch(
          await setProductSelectedDiscounts(productDiscountsResponse.data!)
        );
      },
      onInvalid: async () => {
        await dispatch(await setProductSelectedDiscounts([]));
      },
      onError: async () => {
        await dispatch(await setProductSelectedDiscounts([]));
      },
    });
    setLoadingDiscounts(false);
  };

  /**
   * Handles the change in quantity for an order detail.
   *
   * @param {number} count - The new quantity to set for the order detail.
   * @param {IOrderSummaryDetail} detail - The order summary detail being updated.
   * @returns {void} resolves once the quantity change logic has been handled.
   */
  const handleChangeCountDetail = (
    count: number,
    detail: IOrderSummaryDetail
  ): void => {
    // constants
    //Validate that the order does not have open pay payment.
    if (selectedOrderSummary?.estatusID === StatusOrderEnum.OpenPay) {
      showSnackbar(NOTIFICATIONS_CHECKOUT.OPEN_PAY.NOTIFICATION, "warning");
      return;
    }
    const { pedidoDetalleId, cantidadPrecioEspecial, cantidad } = detail;
    if (cantidadPrecioEspecial > count) {
      setNewCount(count);
      setNewDetailState(detail);
      setCancelSpecialPriceModal(true);
    } else {
      const newDetail = { ...detail, cantidad: count } as IOrderSummaryDetail;
      ChangeCountDetail(pedidoDetalleId, newDetail, cantidad);
    }
  };

  
  /**
   * Confirms the decrement action for a PaquetePorEscala product.
   * Removes the promotion from all involved products and applies the new quantity.
   */
  const handleScalesDecrementConfirm = (
    closeModal: React.Dispatch<React.SetStateAction<boolean>>
  ): (() => void) => {
    return async () => {
      if (!pendingScalesDetail) return;
      startPendingScalesDecrement(async () => {
        try {
          setLoadingTable(true);
          // promotion name stays visible until the API responds (same pattern as Paquete).
          dispatch(actionsCheckout.setDetailById({
            id: pendingScalesDetail.pedidoDetalleId,
            newDetail: { ...pendingScalesDetail, cantidad: pendingScalesNewCount } as IOrderSummaryDetail,
          }));
          // Backend: update quantity and remove promotion in a single call.
          await updateOrderDetail(
            pendingScalesDetail.pedidoDetalleId,
            selectedOrderSummary,
            [
              { 
                name: PatchOrderSummaryDetailsEnum.Cantidad, 
                data: pendingScalesNewCount 
              },
            ],
            showSnackbar,
            dispatch,
            false,
            selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
          );
        } catch (error) {
          handleCathError(error, showSnackbar);
        } finally {
          setLoadingTable(false);
          closeModal(false);
          setPendingScalesDetail(null);
          setPendingScalesNewCount(0);
          setPendingScalesOriginalCount(0);
        }
      });
    };
  };

  /**
   * Cancels the decrement action for a PaquetePorEscala product.
   * Closes the modal without making any changes.
   */
  const handleScalesDecrementCancel = (): void => {
    if (pendingScalesDetail) {
      const restoredDetail = { ...pendingScalesDetail, cantidad: pendingScalesOriginalCount } as IOrderSummaryDetail;
      ChangeCountDetail(pendingScalesDetail.pedidoDetalleId, restoredDetail, pendingScalesOriginalCount);
    }
    setScalesDecrementModal(false);
    setPendingScalesDetail(null);
    setPendingScalesNewCount(0);
    setPendingScalesOriginalCount(0);
  };


  /**
   * Updates the order summary detail by dispatching a new detail with the updated quantity.
   *
   * @param {number} pedidoDetalleId - The ID of the order detail to be updated.
   * @param {IOrderSummaryDetail} newDetail - The updated detail with the new quantity.
   */
  const ChangeCountDetail = (
    pedidoDetalleId: number,
    newDetail: IOrderSummaryDetail,
    auxCount?: number
  ) => {
    dispatch(actionsCheckout.setDetailById({ id: pedidoDetalleId, newDetail }));
    // Accumulate pending change
    const existingEntry = pendingUpdates.current.get(pedidoDetalleId);
    pendingUpdates.current.set(pedidoDetalleId, {
      detail: newDetail,
      auxCount: existingEntry !== undefined ? existingEntry.auxCount : auxCount!,
      isPackage:
        newDetail.promociones?.find((x) => x.id === newDetail.promocionID)
          ?.tipoPromocionId === PromotionTypesEnum.Paquete,
      isPaquetePorEscala:
        newDetail.promociones?.find((x) => x.id === newDetail.promocionID)
          ?.tipoPromocionId === PromotionTypesEnum.PaquetePorEscala,
    });

    // Activate debounce
    debouncedSendUpdates();
  };

  /**
   * Debounced function to update the order detail in the backend after a delay.
   *
   * @param {IOrderSummaryDetail} detail - The updated order summary detail to be sent to the backend.
   */
  const debouncedSendUpdates = useCallback(
    debounce(async () => {
      let lastSummary: IOrderSummary = selectedOrderSummary!;
      // When we return early to show a modal (Paquete or PaquetePorEscala), the
      // finally block must NOT dispatch lastSummary — it is the stale closure
      // value and would overwrite the optimistic UI update, reverting the counter.
      let skippedForModal = false;
      try {
        // Here we start the loading, and it should run only once.
        setLoadingTable(true);

        // We convert the Map values ​​to an array ordered by details that have a package promotion
        const updatesArray = Array.from(pendingUpdates.current.values()).sort(
          (a, b) => Number(a.isPackage) - Number(b.isPackage)
        );

        for (const { detail, auxCount, isPackage, isPaquetePorEscala } of updatesArray) {
          const { cantidad, pedidoDetalleId } = detail;

          try {
            if (detail.promocionID !== 0 && detail.promociones) {
              if (isPackage && cantidad - auxCount > 0) {
                setPackageModal(true);
                setProductCode(detail?.producto ?? "");
                setPackageCuantity(cantidad);
                setOldCuantity(auxCount);
                setAddCuantity(cantidad - auxCount);
                setPedidoDetalleId(pedidoDetalleId);
                skippedForModal = true;
                return;
              }
              if (isPaquetePorEscala && cantidad < auxCount && cantidad > 0) {
                setPendingScalesNewCount(cantidad);
                setPendingScalesDetail(detail);
                setPendingScalesOriginalCount(auxCount);
                setScalesDecrementModal(true);
                skippedForModal = true;
                return;
              }
            }

            const updateSummary = await updateOrderDetail(
              pedidoDetalleId,
              selectedOrderSummary,
              [
                {
                  name: PatchOrderSummaryDetailsEnum.Cantidad,
                  data: cantidad,
                },
              ],
              showSnackbar,
              dispatch,
              false,
              selectedOrderSummary?.estatusID == 4
                ? quotationState.historialId
                : 0,
              false
            );

            if (updateSummary) lastSummary = updateSummary;
          } catch (_error) {
            fetchOrderSummariesAction(
              dispatch,
              userAuthState,
              selectedOrderSummary?.pedidoID
            );
          }
        }
      } catch (e) {
        fetchOrderSummariesAction(
          dispatch,
          userAuthState,
          selectedOrderSummary?.pedidoID
        );
      } finally {
        if (!skippedForModal) {
          await dispatch(
            updateOrderSummaryThunk({
              ...lastSummary,
              cliente: selectedOrderSummary!.cliente,
            })
          );
        }
        pendingUpdates.current.clear();
        setLoadingTable(false);
      }
    }, 2000),
    [selectedOrderSummary?.pedidoID]
  );

  /**
   * Wraps the product deletion function to be passed as props.
   * This wrapper handles the deletion of a product from the order details.
   *
   * @param {string | number} pedidoDetalleId - The ID of the order detail to be deleted
   * @param {number} specialPriceId - The ID of the special price associated with the product
   * @param {React.Dispatch<React.SetStateAction<boolean>>} closeModal - Function to close the modal
   * @param {boolean} deleteCheckOut - Flag indicating if the checkout should be deleted
   * @returns {() => void} A function that executes the product deletion when called
   */
  const wrappedFetchDeleteProduct = (
    pedidoDetalleId: string | number,
    specialPriceId: number,
    closeModal: React.Dispatch<React.SetStateAction<boolean>>,
    deleteCheckOut: boolean
  ) => {
    return async () => {

      let genericProductDescription: IGenericProduct | null;

      if (doesOrderHasGenericProducts) {

        genericProductDescription = genericProductsDescriptions.find(item => (item.OrderId == selectedOrderSummary?.pedidoID || item.OrderId == selectedOrderSummary?.cotizacionIdOrigen) && item.productNumber == String(productoIdDelete)) ?? null;

        if (genericProductDescription?.GenericProductId) {
          await DeleteGenericProductTlc(genericProductDescription?.GenericProductId);
          setGenericProductsDescriptions(genericProductsDescriptions.filter(item => item.GenericProductId != genericProductDescription?.GenericProductId));
        }

      }

      startPendingDelete(async () => {
        if (selectedOrderSummary && userAuthState.userAuth) {
          const clienteId = selectedOrderSummary.clienteId;
          const productoId = String(productoIdDelete).padStart(7, "0");
          const customerData = dataCustomer[clienteId];
          const hadActiveKms =
            !!customerData?.customerLoyaltyPlan &&
            !!customerData?.ordersKms?.[selectedOrderSummary?.pedidoID]
              ?.products?.[productoId]?.isActiveKms;
          if (hadActiveKms) {
            await dispatch(
              resetProductKms({
                clientId: String(clienteId),
                orderId: String(selectedOrderSummary.pedidoID ?? 0),
                productoKey: productoId,
              })
            );
            await fetchDeleteProduct(
              pedidoDetalleId,
              specialPriceId,
              deleteCheckOut,

              selectedOrderSummary,
              userAuthState.userAuth.employeeId,
              checkOutList,
              showSnackbar,
              dispatch,
              redirect,
              selectedOrderSummary?.estatusID == 4
                ? quotationState.historialId
                : undefined,
              telemarketingLeads,
              telemarketingLeadsModal.selectedCvid,
              hadActiveKms
            );
          } else {
            await fetchDeleteProduct(
              pedidoDetalleId,
              specialPriceId,
              deleteCheckOut,
              selectedOrderSummary,
              userAuthState.userAuth.employeeId,
              checkOutList,
              showSnackbar,
              dispatch,
              redirect,
              selectedOrderSummary?.estatusID == 4
                ? quotationState.historialId
                : undefined,
              telemarketingLeads,
              telemarketingLeadsModal.selectedCvid
            );
          }
          closeModal(false);
        }
      });
    };
  };

  /**
   * Sets, deletes, or changes a discount for a given order detail.
   *
   * @param {number} id - The ID of the order.
   * @param {IOrderSummaryDetail} detail - The order detail object containing the discount information.
   * @returns {Promise<void>} A promise that resolves when the operation is complete.
   */
  const handleQuitDiscount = async (
    id: number,
    detail: IOrderSummaryDetail
  ): Promise<void> => {
    try {
      await dispatch(switchLoadingThunk(true));
      // create a new detail with the id of the detail and the id of the promotion
      const newDetail = { ...detail, promocionID: id } as IOrderSummaryDetail;

      // update the detail order on the store
      dispatch(
        actionsCheckout.setDetailById({ id: detail.pedidoDetalleId, newDetail })
      );

      // update the detail order on the indexDb
      await updateOrderDetail(
        detail.pedidoDetalleId,
        selectedOrderSummary,
        [
          {
            name: PatchOrderSummaryDetailsEnum.PromocionID,
            data: id,
          },
        ],
        showSnackbar,
        dispatch,
        false,
        selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
      );
    } catch (e) {
      handleCathError(e, showSnackbar);
    } finally {
      sendUpdateArticulePromotion(
        channelCheckoutsRef,
        selectedOrderSummary!,
        tabId
      );
      await dispatch(switchLoadingThunk(false));
    }
  };

  /**
   * Function that goes through the details component
   *
   * @param {() => void} closeModal
   * @returns {void) => () => void}
   */
  const wrappedFetchCancelSpecialPrice = (
    closeModal: React.Dispatch<React.SetStateAction<boolean>>
  ): (() => void) => {
    return async () => {
      startPendingCancelSpecialPrice(async () => {
        // eslint-disable-next-line @typescript-eslint/no-unused-expressions
        if (selectedOrderSummary && userAuthState.userAuth) {
          const response = await cancelSpecialPrice(
            selectedOrderSummary,
            userAuthState.userAuth.employeeId,
            newDetailState,
            newCount,
            showSnackbar,
            dispatch,
            selectedOrderSummary.estatusID == 4 ? quotationState.historialId : 0
          );
          ChangeCountDetail(response.pedidoDetalleId, response.newDetail);
          closeModal(false);
        }
      });
    };
  };

  /**
   * Creates a wrapped function to handle special price requests.
   * This function is passed as a prop and calls the main special price request function.
   *
   * @param {React.Dispatch<React.SetStateAction<boolean>>} disabledButton - Function to disable/enable the special price button
   * @param {IOrderSummaryDetail} pedidoDetalle - The order detail object
   * @param {number} price - The requested special price
   * @param {string} comment - Comment explaining the special price request
   * @param {React.Dispatch<React.SetStateAction<boolean>>} closeModal - Function to close the modal
   * @param {React.Dispatch<React.SetStateAction<boolean>>} disabledCounter - Function to disable/enable the counter
   * @param {number} [specialPriceState=0] - The state of the special price request (0 for new request)
   * @returns {() => void} A function that handles the special price request
   */
  const wrappedFetchSpecialPriceRequest = (
    disabledButton: React.Dispatch<React.SetStateAction<boolean>>,
    pedidoDetalle: IOrderSummaryDetail,
    price: number,
    comment: string,
    closeModal: React.Dispatch<React.SetStateAction<boolean>>,
    disabledCounter: React.Dispatch<React.SetStateAction<boolean>>,
    specialPriceState = 0
  ) => {
    if (selectedOrderSummary && userAuthState.userAuth !== undefined) {
      if (specialPriceState === 0) {
        return () => {
          disabledCounter(true);
          disabledButton(true);
          fetchSpecialPriceRequest(
            pedidoDetalle,
            price,
            comment,
            selectedOrderSummary,
            userAuthState.userAuth!,
            showSnackbar,
            dispatch,
            selectedOrderSummary.estatusID == 4
              ? quotationState.historialId
              : 0,
            nameCompetitor,
            brandCompetitor
          ).then(() => {
            closeModal(false);
            disabledCounter(false);
          });
        };
      } else {
        return () => {
          disabledCounter(true);
          disabledButton(true);
          fetchUpdateSpecialPrice(
            pedidoDetalle,
            price,
            specialPriceState,
            selectedOrderSummary,
            showSnackbar,
            dispatch,
            selectedOrderSummary.estatusID == 4 ? quotationState.historialId : 0
          ).then(() => {
            closeModal(false);
            disabledCounter(false);
          });
        };
      }
    }
  };

  /**
   * Handles the logic when a negative save action occurs.
   * Closes the package modal, clears the product code, updates the order detail with a negative save,
   * and resets the package quantity and order detail ID.
   *
   * @returns {void}
   */
  const onNegativeSave = async (): Promise<void> => {
    try {
      setLoadingTable(true);
      await updateOrderDetail(
        pedidoDetalleId,
        selectedOrderSummary,
        [
          {
            name: PatchOrderSummaryDetailsEnum.Cantidad,
            data: packageCuantity,
          },
        ],
        showSnackbar,
        dispatch,
        false,
        selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
      );
    } catch (error) {
      handleCathError(error, showSnackbar);
    } finally {
      setPackageModal(false);
      setProductCode("");
      setPackageCuantity(0);
      setPedidoDetalleId(0);
      setLoadingTable(false);
    }
  };

  /**
   * Closes the package modal, clears the product code, and resets the package quantity and order detail ID.
   *
   * @returns {void}
   */
  const onClose = (): void => {
    const newDetail = {
      ...newDetailState,
      cantidad: oldCuantity,
    } as IOrderSummaryDetail;
    ChangeCountDetail(pedidoDetalleId, newDetail, oldCuantity);
    setPackageModal(false);
    setProductCode("");
    setPackageCuantity(0);
    setOldCuantity(0);
    setPedidoDetalleId(0);
    setLoadingTable(false);
  };

  /**
   * Handles the logic when a positive save action occurs.
   * Updates the order detail with the provided package quantity, closes the modal, clears the product code,
   * and resets the package quantity and order detail ID.
   *
   * @returns {void}
   */
  const onPositiveSave = async (): Promise<void> => {
    try {
      setLoadingTable(true);
      await updateOrderDetail(
        pedidoDetalleId,
        selectedOrderSummary,
        [
          {
            name: PatchOrderSummaryDetailsEnum.Cantidad,
            data: packageCuantity,
          },
        ],
        showSnackbar,
        dispatch,
        true,
        selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
      );
    } catch (error) {
      handleCathError(error, showSnackbar);
    } finally {
      setPackageModal(false);
      setProductCode("");
      setPackageCuantity(0);
      setPedidoDetalleId(0);
      setLoadingTable(false);
    }
  };

  /**
   * - If the branch corresponds to the central distribution center (CEDIS), it disables the special price rules.
   * - Otherwise, it queries the backend to check if the policy is active for the specified branch.
   * - The result updates local state via `setSpecialPriceRules`.
   *
   * @async
   * @param {number} sucursalId - The ID of the branch (sucursal) to validate.
   * @returns {Promise<void>} This function does not return a value, but sets the PC2025 state.
   */
  const onSpecialPriceRulesActive = async (sucursalId: number) => {
    if (sucursalId == +process.env.NEXT_PUBLIC_SUCURSAL_CEDIS!)
      return setSpecialPriceRules(false);
    const response = await ProjectActiveInSucursal(
      parseInt(process.env.NEXT_PUBLIC_PRECIO_ESPECIAL_REGLAS_OBJETOID!),
      sucursalId
    );
    handleRequestDto({
      snackBar: showSnackbar,
      response: response,
      onSuccess: () => {
        setSpecialPriceRules(response.data || false);
      },
      messages: {
        error:
          "Hubo un problema al validar si la sucursal admite la politica PC2025",
      },
      onInvalid: () => {
        setSpecialPriceRules(false);
      },
    });
  };

  /**
   * Handles the logic to open the special price modal.
   * Resets the modal state with the given special price ID and order detail ID.
   * This function is used to prepare the modal for displaying or editing special pricing information.
   *
   * @param {number} [specialPriceId=0] - The ID of the special price. Default is 0 if not provided.
   * @param {number} pedidoDetalleId - The ID of the order detail associated with the special price.
   *
   * @returns {void}
   */
  const handleOpenModalPrecioEspecial = (
    specialPriceId: number = 0,
    pedidoDetalleId: number,
    preciolista: number,
    producto?: string,
    tipoPrecio?: number | null | undefined
  ) => {

    if (tipoPrecio === PriceType.Especial || specialPriceId !== 0) {
      setSpecialPriceModalReset(true);
      setSpecialPriceIdReset(specialPriceId);
    } else if (tipoPrecio === PriceType.Final) {
      setFinalPriceModalReset(true);
    }
    setPedidoDetalleIdReset(pedidoDetalleId);
    setpedidoDetallePrecioListaReset(preciolista);
    setProducto(producto);

  };

  /**
   * Handles the logic to delete a special price and reset relevant state.
   * This function checks if the user is authenticated and if an order summary is selected,
   * then calls the `updateSpecialPriceReset` function to delete the special price.
   * After the deletion, it hides the special price modal and resets the button state.
   *
   * @param {number} specialPriceId - The ID of the special price to be deleted.
   * @param {number} pedidoDetalleId - The ID of the order detail associated with the special price.
   *  @param {number} preciolista - Tlist price of a product in detail.
   * @returns {Promise<void>} - A promise that resolves when the deletion and state reset are complete.
   */
  const wrappedFetchDeleteSpecialPriceReset = async (
    specialPriceId: number,
    pedidoDetalleId: number,
    preciolista: number,
    producto?: string | null,
    mejorPrecio?: boolean
  ) => {
    if (selectedOrderSummary && userAuthState.userAuth) {
      setCounterButtonStateReset(true);
      try {
        if (!selectedOrderSummary) return;
        if (producto &&
          dataCustomer?.[selectedOrderSummary?.clienteId]
            ?.ordersKms?.[selectedOrderSummary?.pedidoID]
            ?.products?.[producto]?.isActiveKms
        ) {
          SetIsLoadingKms(true);
          await resetKmsSummary(producto, pedidoDetalleId, selectedOrderSummary, dataCustomer?.[selectedOrderSummary?.clienteId], dispatch, showSnackbar);
          SetIsLoadingKms(false);
        }
        const updatedOrderSummary = await updateOrderDetail(
          pedidoDetalleId,
          selectedOrderSummary,
          [
            {
              name: PatchOrderSummaryDetailsEnum.precioEspecialId,
              data: undefined,
            },
            {
              name: PatchOrderSummaryDetailsEnum.tieneToken,
              data: false,
            },
            {
              name: PatchOrderSummaryDetailsEnum.precio,
              data: preciolista,
            },
          ],

          showSnackbar,
          dispatch,
          false,
          selectedOrderSummary?.estatusID == 4 ? quotationState.historialId : 0
        );

        if (!updatedOrderSummary) {
          setSpecialPriceModalReset(false);
          setCounterButtonStateReset(false);
          return;
        }
        showSnackbar(
          NOTIFICATIONS_CHECKOUT.SPECIAL_PRICE_RESET.UPDATE_SUCCESS,
          "success"
        );
        setSpecialPriceModalReset(false);
        setCounterButtonStateReset(false);

        await updateSpecialPriceReset(
          specialPriceId,
          selectedOrderSummary,
          showSnackbar,
          userAuthState.userAuth.employeeId
        );
      } finally {
        setSpecialPriceModalReset(false);
        setCounterButtonStateReset(false);
        SetIsLoadingKms(false);
        setFinalPriceModalReset(false);
      }
    }
  };

  const handleGenericProductEdition = (product: IGenericProduct) => {

    setEditGenericProductDescriptionModal(false);
    setGenericProductSelected(null);

    if (!genericProductsDescriptions.some(item => item.productNumber == product.productNumber && (item.OrderId == selectedOrderSummary?.pedidoID || item.OrderId == selectedOrderSummary?.cotizacionIdOrigen)))
      setGenericProductsDescriptions([...genericProductsDescriptions, product]);

  }

  /**
   * Indica si en la experiencia móvil debe mostrarse el bloque "Pago con Kms" por
   * artículo. Réplica exacta de la condición con la que el DataGrid agrega la columna
   * homónima (cliente con plan de lealtad + `flagUp` y fuera del flujo de cotización).
   */
  const showKmsColumnMobile = Boolean(
    dataCustomer &&
    selectedOrderSummary &&
    selectedOrderSummary.clienteId != null &&
    !!dataCustomer?.[selectedOrderSummary?.clienteId]?.customerLoyaltyPlan &&
    !!dataCustomer?.[selectedOrderSummary?.clienteId]?.flagUp &&
    !comesFromCotizacion
  );

  /**
   * Renderiza la card móvil de un artículo del checkout (experiencia `<900px`).
   * Reproduce, en un layout vertical, las mismas columnas del DataGrid (imagen,
   * código/descripción, contador de cantidad, existencias, precio final +IVA,
   * promoción/`SelectDiscount`, precio especial, pago con Kms y acciones
   * eliminar/comentario/editar descripción) reutilizando los mismos handlers y thunks
   * del contenedor, sin duplicar la lógica de negocio.
   *
   * Los `GridActionsCellItem` del DataGrid se sustituyen por botones planos porque
   * requieren el contexto del grid (`useGridRootProps`) y lanzarían fuera de él; se
   * preservan `icon`/`label`/`onClick`/`disabled`. El cálculo de Kms se delega a
   * {@link ProductKmsEffect} para respetar las reglas de hooks.
   *
   * @param {IOrderSummaryDetail} detail - Detalle del pedido que representa la card.
   * @param {number} index - Índice del artículo dentro del listado (columna "#").
   * @returns {JSX.Element} La card del artículo.
   */
  /**
   * Cuerpo del artículo en la experiencia móvil: los mismos datos y controles que la
   * columna del DataGrid. Vive dentro de la hoja de edición que abre el renglón
   * compacto; antes era la tarjeta completa de la lista, y con 25 artículos en la caja
   * la lista medía más de doce metros.
   *
   * @param {IOrderSummaryDetail} detail - Artículo de la caja.
   * @param {number} index - Posición en la lista, para el número de renglón.
   * @returns {JSX.Element} El detalle del artículo.
   */
  const renderMobileArticleDetail = (
    detail: IOrderSummaryDetail,
    index: number
  ) => {
    const productoKey = String(detail.producto);
    const clienteId = selectedOrderSummary?.clienteId;
    const pedidoId = selectedOrderSummary?.pedidoID ?? 0;

    // --- Derivados de la columna "Producto" ---
    const findGiftDiscount: boolean = detail.promociones
      ? detail.gratis === true
      : false;
    const allQuantity = detalles
      .filter((pr) => pr.producto === detail.producto)
      .reduce((stock, pr) => stock + +pr!.cantidad!, 0);
    const denyDisabled: boolean = userAuthState.userAuth?.engineSMC4
      ? detail.stockNacional === "-" ||
      detail.stockNacional === undefined ||
      detail.productoNegado === true ||
      (detail.stockNacional.toString() != "-" &&
        allQuantity <= detail.stockNacional) ||
      readOnly
      : detail.stockEnSucursal === "-" ||
      detail.stockEnSucursal === undefined ||
      detail.productoNegado === true ||
      (detail.stockEnSucursal.toString() != "-" &&
        allQuantity <= detail.stockEnSucursal) ||
      readOnly;
    const isActiveProducto =
      dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
        selectedOrderSummary?.pedidoID ?? 0
      ]?.products[productoKey]?.isActiveKms ?? false;
    const valorProductoKms =
      isActiveProducto && (detail.importeIVA ?? 0)
        ? dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
          selectedOrderSummary?.pedidoID ?? 0
        ]?.products[productoKey]?.valueProductAfterKms ??
        detail.importeIVA ??
        0
        : detail.importeIVA ?? 0;
    const genericProductDescription: IGenericProduct | null =
      genericProductsDescriptions.find(
        (item) =>
          item.productNumber == detail.producto &&
          (item.OrderId == selectedOrderSummary?.pedidoID ||
            item.OrderId == selectedOrderSummary?.cotizacionIdOrigen)
      ) ?? null;
    const showLoyaltyLine = Boolean(
      dataCustomer &&
      selectedOrderSummary &&
      dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.customerLoyaltyPlan
    ) &&
      !comesFromCotizacion &&
      detail.familia !== "Pedido" &&
      dataCustomer &&
      selectedOrderSummary &&
      selectedOrderSummary.clienteId != null &&
      dataCustomer[selectedOrderSummary?.clienteId]?.flagUp;

    // --- Derivados de la columna "Precio final" ---
    const isPagoTotal =
      clienteId && productoKey
        ? dataCustomer[clienteId]?.ordersKms?.[selectedOrderSummary?.pedidoID ?? 0]
          ?.products[productoKey]?.isPagoTotal
        : undefined;
    const isValidPrecioEspecialId =
      detail.precioEspecialId && detail.precioEspecialId !== 0;
    const hasDiscount = detail.promocionID !== 0;
    let findDiscount: IPromotion | undefined = {};
    const price = detail.precio;
    if (detail.promociones) {
      findDiscount = detail.promociones.find(
        (x: IPromotion) =>
          (x.tipoPromocionId === PromotionTypesEnum.Revista &&
            x.id === detail.promocionID) ||
          (x.tipoPromocionId === PromotionTypesEnum.Paquete &&
            x.id === detail.promocionID) ||
          (x.tipoPromocionId === PromotionTypesEnum.Escalas &&
            x.id === detail.promocionID)
      );
    }
    // El "precio final" (release 3.22.0 del original) cuenta como descuento aunque no
    // haya promoción ni precio especial. Misma regla que la columna de escritorio.
    const priceType = detail.tipoPrecio || PriceType.Lista;
    const mejorPrecioAplicado = priceType === PriceType.Final;
    const mustShowDiscount =
      (hasDiscount && (findDiscount || detail.gratis)) || priceType !== PriceType.Lista;
    const orderProductData =
      dataCustomer[clienteId ?? 0]?.ordersKms?.[pedidoId]?.products[productoKey];
    const isActivePrecio =
      !!dataCustomer[clienteId ?? 0]?.ordersKms[pedidoId]?.products[productoKey];
    const valorProductoPrecio =
      isActivePrecio &&
        isPagoTotal &&
        orderProductData?.valueProductAfterKms !== undefined
        ? orderProductData.valueProductAfterKms
        : detail.importeIVA ?? 0;

    // --- Derivados de la columna "Promoción" ---
    const promo = detail.promociones?.find(
      (x: IPromotion) => x.id === detail.promocionID
    );
    const promocionesValues: IPromotion[] = Array.isArray(detail.promociones)
      ? detail.promociones
      : [];

    // --- Derivados de la columna "Pago con Kms" ---
    // El estado de pago (ninguno/parcial/total) lo calcula internamente
    // LoyaltyPlanApplyKms; aquí sólo se necesita saber si el artículo admite Kms.
    const kmsUnavailable =
      detail.familia === "Pedido" || detail.gratis == true;

    const labelSx = {
      fontSize: FontSizesEnum.Epsilon,
      fontWeight: FontWeightEnum.Medium,
      color: ColorsEpico.ColorGray,
      textTransform: "uppercase" as const,
      letterSpacing: "0.5px",
    };

    return (
      <Box key={`${detail.pedidoDetalleId}`} sx={{ px: 1.5, pb: 1.5 }}>
        {/* Encabezado: # + imagen + código/descripción */}
        <Box display="flex" gap={1.5} alignItems="flex-start">
          <Typography
            fontSize={FontSizesEnum.Gamma}
            fontWeight={FontWeightEnum.Bold}
            color={ColorsEpico.ColorGray}
            sx={{ minWidth: "1.25rem" }}
          >
            {index + 1}
          </Typography>

          <Box>
            {genericProductDescription && genericProductDescription.imageRoute ? (
              <img
                width={66}
                height={66}
                src={genericProductDescription.imageRoute}
                alt={detail.producto ?? ""}
              />
            ) : (
              <ImageCell
                producto={extraerCodigoProducto(detail.producto ?? "") ?? ""}
                alt={detail.producto ?? ""}
                width={66}
                height={66}
                onError={fetchImageProducts}
              />
            )}
          </Box>

          <Box display="flex" flexDirection="column" flex={1} minWidth={0}>
            <Stack direction="row" spacing={1} alignItems="center">
              <Typography
                color={ColorsEpico.ColorBlack}
                fontWeight={FontWeightEnum.Bold}
                fontSize={FontSizesEnum.Gamma}
              >
                #{detail.producto}
              </Typography>
              {detail.pickUp && userAuthState.userAuth?.engineSMC4 && (
                <BadgeGeneric
                  fontSize={FontSizesEnum.Epsilon}
                  sxContainerParam={{ height: "20px" }}
                  color={ColorsEpico.ColorChipBackground}
                  textColor={ColorsEpico.ColorChipText}
                  borderRadius={"4px"}
                  label="Exclusivo pickup"
                  icon={<PickupIcon />}
                />
              )}
            </Stack>
            <Typography
              color={ColorsEpico.ColorBlack}
              fontWeight={FontWeightEnum.Regular}
              fontSize={FontSizesEnum.Beta}
              sx={{
                whiteSpace: "normal",
                wordBreak: "break-word",
                overflowWrap: "break-word",
              }}
            >
              {genericProductDescription?.description ?? detail.descripcion}
            </Typography>
            {showLoyaltyLine ? (
              <Typography
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
                color={ColorsEpico.ColorBlack}
              >
                {new CoinFormatter(Number(detail.importe)).coin} ó{" "}
                {(productKmsValues[String(detail.producto)] || 0).toLocaleString()}{" "}
                Kms
              </Typography>
            ) : (
              <Typography
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.ExtraBold}
              >
                {new CoinFormatter(Number(detail.importe)).coin}
              </Typography>
            )}
          </Box>
        </Box>

        <Divider sx={{ my: 1 }} />

        {/* Cantidad + existencias */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="flex-start"
          gap={1}
        >
          <Typography sx={labelSx}>Cantidad</Typography>
          <Box display="flex" flexDirection="column" alignItems="flex-end">
            <Counter
              isDisabled={
                counterButtonState || findGiftDiscount || readOnly || isBlocked
              }
              editable={!findGiftDiscount}
              count={detail.cantidad}
              handleChangeCount={async (count: number) => {
                const clienteIdCount = selectedOrderSummary?.clienteId;
                const pedidoID = selectedOrderSummary?.pedidoID;
                const productoID = detail.producto;

                if (
                  clienteIdCount !== undefined &&
                  pedidoID !== undefined &&
                  productoID !== undefined &&
                  dataCustomer[clienteIdCount]?.ordersKms?.[pedidoID]?.products?.[
                    productoID
                  ]?.isActiveKms
                ) {
                  await changeTotalOfProductsKms({ row: detail });
                }

                handleChangeCountDetail(count, detail);
              }}
              min={1}
              inputStyle={{
                fontSize: FontSizesEnum.Epsilon,
                width: "100%",
                height: "0.5rem",
              }}
            />
            {Number(detail.stockEnSucursal ?? 0) > 0 && (
              <Typography
                variant="caption"
                color={ColorsEpico.ColorBlack}
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
              >
                {detail.stockEnSucursal} disponibles
              </Typography>
            )}
            {Number(detail.stockEnSucursal) <= 0 && (
              <Typography
                variant="caption"
                color={ColorsEpico.ColorRed}
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
              >
                0 disponibles
              </Typography>
            )}
            {userAuthState.userAuth?.engineSMC4 && mostrarExistenciasSMC4 ? (
              pendingStockNational ? (
                <Skeleton variant="text" width={100} height={20} />
              ) : (
                <Tooltip title="Existencias nacionales" arrow>
                  <Typography
                    variant="caption"
                    color={
                      isNaN(Number(detail?.stockNacional)) ||
                        (Number(detail.stockNacional) > 0 &&
                          Number(detail.stockNacional) >= Number(detail.cantidad))
                        ? ColorsEpico.ColorBlack
                        : ColorsEpico.ColorRed
                    }
                    fontSize={FontSizesEnum.Gamma}
                    fontWeight={FontWeightEnum.Bold}
                  >
                    {isNaN(Number(detail?.stockNacional))
                      ? "-"
                      : Number(detail?.stockNacional) <= 0
                        ? 0
                        : Number(detail?.stockNacional)}{" "}
                    disponibles
                  </Typography>
                </Tooltip>
              )
            ) : null}
            {Number(detail.stockEnSMC ?? 0) > 0 && (
              <Typography
                variant="caption"
                color={ColorsEpico.ColorBlack}
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
              >
                {detail.stockEnSMC} SMC
              </Typography>
            )}
            {Number(detail.stockEnSMC) <= 0 && (
              <Typography
                variant="caption"
                color={ColorsEpico.ColorRed}
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
              >
                0 SMC
              </Typography>
            )}
          </Box>
        </Box>

        <Divider sx={{ my: 1 }} />

        {/* Precio final */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="flex-start"
          gap={1}
        >
          <Typography sx={labelSx}>Precio final</Typography>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-end"
            gap={0.25}
          >
            <Box display="flex" alignItems="center" gap={0.5}>
              {Number(detail.ahorroPorcentaje ?? 0) > 0 && (
                <Box
                  px={0.6}
                  py={0.2}
                  borderRadius="6px"
                  bgcolor={ColorsEpico.ColorGreenLush}
                  display="flex"
                  alignItems="center"
                  justifyContent="center"
                >
                  <Typography
                    variant="caption"
                    fontWeight={600}
                    color={ColorsEpico.ColorBlack}
                    fontSize={FontSizesEnum.Zeta}
                  >
                    {detail.ahorroPorcentaje}%
                  </Typography>
                </Box>
              )}
              <Typography
                fontSize={FontSizesEnum.Alpha}
                color={ColorsEpico.ColorBlack}
              >
                {new CoinFormatter(Number(price)).coin}
              </Typography>
              {detail.esPrecioDePreciosPersonalizadas && (
                <Tooltip title="Precio de lista personalizada" arrow>
                  <Typography
                    fontSize={FontSizesEnum.Beta}
                    fontWeight={FontWeightEnum.Bold}
                    color={ColorsEpico.ColorDodgerBlue}
                    sx={{ lineHeight: 1, cursor: "default" }}
                  >
                    *
                  </Typography>
                </Tooltip>
              )}
            </Box>

            <Typography
              fontSize={FontSizesEnum.Gamma}
              color={ColorsEpico.ColorBlack}
            >
              +IVA {selectedOrderSummary?.porcentajeImpuesto}%
            </Typography>
            {mustShowDiscount ? (
              <Box
                display="flex"
                flexDirection="row"
                alignItems="center"
                gap={1}
              >
                <Typography
                  fontSize={FontSizesEnum.Gamma}
                  fontWeight={FontWeightEnum.Bold}
                  color={ColorsEpico.ColorGrayDisabled}
                  sx={{
                    textDecoration: "line-through",
                    transition: "all 0.3s ease",
                  }}
                >
                  {new CoinFormatter(detail.precioLista).coin}
                </Typography>
                <Typography
                  fontSize={FontSizesEnum.Alpha}
                  fontWeight={FontWeightEnum.Bold}
                  color={ColorsEpico.ColorBlack}
                  sx={{
                    textDecoration:
                      isPagoTotal &&
                        !!dataCustomer[clienteId ?? 0].ordersKms[
                          selectedOrderSummary?.pedidoID ?? 0
                        ].products[productoKey].isActiveKms
                        ? "line-through"
                        : "none",
                    transition: "all 0.3s ease",
                  }}
                >
                  {new CoinFormatter(valorProductoPrecio).coin}
                </Typography>
              </Box>
            ) : (
              <Typography
                fontSize={FontSizesEnum.Lambda}
                fontWeight={FontWeightEnum.Bold}
                color={ColorsEpico.ColorBlack}
                sx={{
                  textDecoration:
                    isPagoTotal &&
                      !!dataCustomer[clienteId ?? 0].ordersKms[
                        selectedOrderSummary?.pedidoID ?? 0
                      ].products[productoKey].isActiveKms
                      ? "line-through"
                      : "none",
                  transition: "all 0.3s ease",
                }}
              >
                {new CoinFormatter(Number(valorProductoPrecio)).coin}
              </Typography>
            )}
            {showLoyaltyLine ? (
              <Typography
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Bold}
                color={ColorsEpico.ColorBlack}
              >
                {(productKmsValues[String(detail.producto)] || 0).toLocaleString()}{" "}
                Kms
              </Typography>
            ) : null}
            {/* "Ver últ. precio" queda comentado igual que en la columna de escritorio
                y que su Popover: el equipo del proyecto original comentó esa
                funcionalidad en el 3.29.0 (commit b641e4118, "Se comenta funcionalidad
                ultimo precio facturado"). Dejarlo vivo aquí abriría un popover que ya
                no existe. Si allá se reactiva, reactivar también esta copia.
            <Box
              component="span"
              onClick={async (e) => {
                setLastPriceAnchorEl(e.currentTarget);
                setLastPriceLoading(true);
                setLastPriceData(null);
                try {
                  const response = await getLastInvoicedPrice({
                    productoId: detail.productoID,
                    clienteVendedorId:
                      selectedOrderSummary?.clienteVendedorId ?? 0,
                  });
                  if (!response.huboError && response.data) {
                    setLastPriceData(response.data);
                  }
                } catch {
                  setLastPriceData(null);
                } finally {
                  setLastPriceLoading(false);
                }
              }}
              sx={{
                display: "inline-flex",
                alignItems: "center",
                gap: 0.5,
                fontSize: FontSizesEnum.Gamma,
                color: ColorsEpico.ColorDodgerBlue,
                cursor: "pointer",
                textDecoration: "underline",
                "&:hover": { color: ColorsEpico.ColorLinkHover },
              }}
            >
              <LocalOffer
                sx={{ fontSize: 14, color: ColorsEpico.ColorNeutralYellow }}
              />
              Ver últ. precio
            </Box>
            */}
          </Box>
        </Box>

        <Divider sx={{ my: 1 }} />

        {/* Promoción */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="flex-start"
          gap={1}
        >
          <Typography sx={labelSx}>Promoción</Typography>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-end"
            sx={{ minWidth: 0 }}
          >
            <SelectDiscount
              isQuiteDiscount={isRemoveDiscountModalOpen}
              orderSummaryDetail={detail}
              handleShowDiscountModal={handleShowDiscountModal}
              handleDiscount={async (id, selectedOrderSummaryDetail) => {
                await handleDiscount(
                  id,
                  selectedOrderSummaryDetail,
                  detail.promociones!
                );
              }}
              showDiscountModal={showDiscountModal}
              disabled={
                origenLineaPorDetalle.get(detail.pedidoDetalleId)
                  ?.esPropuestaComercial ?? false
              }
            />
            {/* Same reason and gray pill as on desktop; it replaces the promotion status. */}
            {origenLineaPorDetalle.get(detail.pedidoDetalleId)
              ?.esPropuestaComercial && (
              <Typography
                variant="caption"
                sx={{
                  color: ColorsEpico.ColorDarkCharcoal,
                  backgroundColor: ColorsEpico.ColorGrayDull,
                  px: 1,
                  py: 0.5,
                  borderRadius: 1,
                  whiteSpace: "normal",
                  textAlign: "right",
                  lineHeight: 1.35,
                  maxWidth: "100%",
                  mt: 0.5,
                }}
              >
                {MOTIVO_SIN_PROMOCION_EN_PROPUESTA}
              </Typography>
            )}
            {/* En escritorio esta explicación es un tooltip; en táctil no hay hover, así
                que el aviso se pinta a la vista. */}
            {mejorPrecioAplicado && (
              <Typography
                fontSize={FontSizesEnum.Epsilon}
                color={ColorsEpico.ColorGrayDisabled}
                sx={{ textAlign: "right", mt: 0.5 }}
              >
                El producto tiene un mejor precio aplicado, se debe cancelar el mejor
                precio para poder aplicar una promoción
              </Typography>
            )}
            {/* On a proposal line item the reason above replaces this status:
                «Sin promociones disponibles» speaks of the catalog and the reason speaks of
                permission. Showing both stacks two sentences that sound the same. */}
            {origenLineaPorDetalle.get(detail.pedidoDetalleId)
              ?.esPropuestaComercial ? null : promocionesValues.length > 0 ? (
              detail.promocionID === 0 ? (
                <Typography
                  variant="caption"
                  sx={{
                    color: ColorsEpico.ColorDarkCharcoal,
                    backgroundColor: ColorsEpico.ColorGrayDull,
                    px: 1,
                    py: 0.5,
                    borderRadius: 1,
                  }}
                >
                  Sin promoción aplicada
                </Typography>
              ) : (
                <Typography
                  sx={{
                    color: ColorsEpico.ColorDarkCharcoal,
                    backgroundColor: ColorsEpico.ColorGrayDull,
                    px: 1,
                    py: 0.5,
                    borderRadius: 1,
                  }}
                >
                  {promo?.clasificacion}
                </Typography>
              )
            ) : (
              <Typography
                variant="caption"
                fontSize={FontSizesEnum.Gamma}
                sx={{
                  color: ColorsEpico.ColorDarkCharcoal,
                  backgroundColor: ColorsEpico.ColorGrayDull,
                  px: 1,
                  py: 0.5,
                  borderRadius: 1,
                }}
              >
                Sin promociones disponibles
              </Typography>
            )}
          </Box>
        </Box>

        {/* Precio especial */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          gap={1}
          mt={1}
        >
          <Typography sx={labelSx}>Precio especial</Typography>
          <Box
            display="flex"
            flexDirection="column"
            alignItems="flex-end"
            gap={0.5}
            sx={{ minWidth: 0 }}
          >
            <Box display="flex" alignItems="center" gap={0.5}>
              <SpecialPriceButton
                isDisabled={readOnly || isBlocked}
                isLoading={counterButtonState}
                orderSummaryDetail={detail}
                handleSpecialPrice={handleSpecialPrice}
              />
              {/* Con un mejor precio aplicado este botón es la única forma de cancelarlo,
                  así que se muestra igual que en escritorio aunque no haya precio
                  especial. El `tipoPrecio` decide cuál de los dos modales abre. */}
              {(!detail.gratis && isValidPrecioEspecialId && !readOnly) ||
                mejorPrecioAplicado ? (
                <Tooltip title="Eliminar Precio Especial">
                  <span>
                    <IconButton
                      size="small"
                      aria-label="Eliminar Precio Especial"
                      onClick={() =>
                        handleOpenModalPrecioEspecial(
                          detail.precioEspecialId,
                          detail.pedidoDetalleId,
                          detail.precioLista,
                          detail.producto,
                          detail.tipoPrecio
                        )
                      }
                    >
                      <RestartAltIcon
                        sx={{ color: ColorsEpico.ColorDarkCharcoal }}
                      />
                    </IconButton>
                  </span>
                </Tooltip>
              ) : null}
            </Box>
            {mejorPrecioAplicado && (
              <Typography
                fontSize={FontSizesEnum.Epsilon}
                color={ColorsEpico.ColorGrayDisabled}
                sx={{ textAlign: "right" }}
              >
                El producto tiene un mejor precio aplicado
              </Typography>
            )}
          </Box>
        </Box>

        {/* Pago con Kms */}
        {showKmsColumnMobile && (
          <>
            <Divider sx={{ my: 1 }} />
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="flex-start"
              gap={1}
            >
              <Typography sx={labelSx}>Pago con Kms</Typography>
              {kmsUnavailable ? (
                <Typography
                  color={ColorsEpico.ColorGrayDisabled}
                  fontSize={FontSizesEnum.Alpha}
                  sx={{ textAlign: "right" }}
                >
                  No disponible para pago con Kms
                </Typography>
              ) : (
                <LoyaltyPlanApplyKms
                  params={
                    { row: detail } as GridRenderCellParams<IOrderSummaryDetail>
                  }
                  dataCustomer={dataCustomer}
                  selectedOrderSummary={selectedOrderSummary}
                  dispatch={dispatch}
                  withProductLoading={withProductLoading}
                  valueKmsProvider={
                    productKmsValues[String(detail.producto)] || 0
                  }
                />
              )}
            </Box>
          </>
        )}

        <Divider sx={{ my: 1 }} />

        {/* Acciones: eliminar / comentario / editar descripción */}
        <Box display="flex" alignItems="center" gap={1} flexWrap="wrap">
          {!detail.gratis && !readOnly && !isBlocked && (
            <Typography
              onClick={() =>
                handleDeleteProduct(
                  detail.pedidoDetalleId,
                  detail.precioEspecialId,
                  detail.promocionID,
                  Number(detail.producto)
                )
              }
              sx={{
                color: ColorsEpico.ColorDodgerBlue,
                cursor: "pointer",
                fontWeight: "bold",
                fontSize: FontSizesEnum.Gamma,
              }}
            >
              Eliminar
            </Typography>
          )}
          {!userAuthState.userAuth?.engineSMC4 && (
            <Tooltip title="Comentario">
              <span>
                <IconButton
                  size="small"
                  aria-label="Comentario"
                  disabled={denyDisabled}
                  onClick={() => handleDenyProduct(detail.producto!)}
                >
                  <IconDeployedAlert
                    sx={{
                      color: detail.productoNegado
                        ? ColorsEpico.ColorGreenLush
                        : detail.stockEnSucursal != "-" &&
                          allQuantity > +detail.stockEnSucursal!
                          ? ColorsEpico.ColorsDarkBlue
                          : ColorsEpico.GrayClearBlue,
                    }}
                  />
                </IconButton>
              </span>
            </Tooltip>
          )}
          {doesOrderHasGenericProducts ? (
            <Link
              className={
                !genericProductsIdsCatalog.some(
                  (item) => item == detail.productoID
                )
                  ? "generic-product-description-button"
                  : ""
              }
              component="button"
              onClick={() => {
                setGenericProductSelected(
                  genericProductsDescriptions.find(
                    (item) =>
                      item.productNumber == detail.producto &&
                      (item.OrderId == selectedOrderSummary?.pedidoID ||
                        item.OrderId == selectedOrderSummary?.cotizacionIdOrigen)
                  ) ?? {
                    OrderId:
                      selectedOrderSummary?.cotizacionIdOrigen ??
                      selectedOrderSummary!.pedidoID,
                    productNumber: detail.producto!,
                    imageFile: null,
                    description: null,
                    imageRoute: null,
                    satCode: null,
                    GenericProductId: null,
                  }
                );
                setEditGenericProductDescriptionModal(true);
              }}
              variant="body2"
              disabled={
                !genericProductsIdsCatalog.some(
                  (item) => item == detail.productoID
                )
              }
              color={ColorsEpico.ColorGrayLight}
            >
              <Box display="flex" alignItems="center" gap={1}>
                <Typography
                  fontSize={FontSizesEnum.Gamma}
                  fontWeight={FontWeightEnum.Medium}
                >
                  Editar descripción Te lo consigo
                </Typography>
                <Edit fontSize="small" />
              </Box>
            </Link>
          ) : null}
        </Box>
      </Box>
    );
  };

  /**
   * Renglón compacto de un artículo. Muestra lo que hay que distinguir de un vistazo
   * —número, imagen, código, distintivos, descripción, importe y cantidad— y abre la
   * hoja con todo lo demás. Los datos los resuelve `resolveMobileArticleRow`.
   *
   * @param {IOrderSummaryDetail} detail - Artículo de la caja.
   * @param {number} index - Posición en la lista.
   * @returns {JSX.Element} El renglón.
   */
  const renderMobileArticleRow = (detail: IOrderSummaryDetail, index: number) => {
    const productoKey = String(detail.producto);
    const clienteId = selectedOrderSummary?.clienteId ?? 0;
    const pedidoId = selectedOrderSummary?.pedidoID ?? 0;
    const kmsProducto = dataCustomer[clienteId]?.ordersKms?.[pedidoId]?.products?.[productoKey];
    const genericProductDescription = genericProductsDescriptions.find(
      (item) =>
        item.productNumber == detail.producto &&
        (item.OrderId == selectedOrderSummary?.pedidoID ||
          item.OrderId == selectedOrderSummary?.cotizacionIdOrigen)
    );

    const row = resolveMobileArticleRow({
      detail,
      descripcionGenerico: genericProductDescription?.description,
      engineSMC4: Boolean(userAuthState.userAuth?.engineSMC4),
      mostrarExistenciasSMC4,
      pendingStockNational,
      kmsAplicados: Boolean(kmsProducto?.isActiveKms),
      pagoTotalConKms: Boolean(kmsProducto?.isPagoTotal),
      importeConKms: kmsProducto?.valueProductAfterKms,
      kmsDelArticulo: productKmsValues[productoKey] || 0,
    });

    const chipSx = {
      fontSize: FontSizesEnum.Zeta,
      fontWeight: FontWeightEnum.Medium,
      px: 0.7,
      py: 0.1,
      borderRadius: "5px",
      whiteSpace: "nowrap" as const,
    };

    return (
      <Box
        key={`${detail.pedidoDetalleId}`}
        component="button"
        type="button"
        onClick={() => setArticuloEnHoja(detail.pedidoDetalleId)}
        aria-label={`Editar ${detail.producto}`}
        sx={{
          width: "100%",
          textAlign: "left",
          font: "inherit",
          color: "inherit",
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 1.25,
          px: 1.25,
          py: 1,
          border: "none",
          borderLeft: `3px solid ${row.existenciaInsuficiente ? ColorsEpico.ColorRed : "transparent"}`,
          borderBottom: `1px solid ${ColorsEpico.ColorLightBlueishGray}`,
          backgroundColor: ColorsEpico.ColorWhite,
          // 44px es el objetivo táctil; el renglón es el disparador de la hoja.
          minHeight: "56px",
        }}
      >
        <Typography
          fontSize={FontSizesEnum.Epsilon}
          fontWeight={FontWeightEnum.Bold}
          color={ColorsEpico.ColorGray}
          sx={{ minWidth: "1.1rem", flexShrink: 0 }}
        >
          {index + 1}
        </Typography>

        <Box sx={{ width: 38, height: 38, flexShrink: 0, display: "flex", alignItems: "center" }}>
          {genericProductDescription?.imageRoute ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img width={38} height={38} src={genericProductDescription.imageRoute} alt={detail.producto ?? ""} />
          ) : (
            <ImageCell
              producto={extraerCodigoProducto(detail.producto ?? "") ?? ""}
              alt={detail.producto ?? ""}
              width={38}
              height={38}
              onError={fetchImageProducts}
            />
          )}
        </Box>

        {/* minWidth 0 en toda la cadena: sin él la descripción no se recorta y se sale. */}
        <Box sx={{ minWidth: 0, flex: 1 }}>
          <Box sx={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 0.5, minWidth: 0 }}>
            <Typography component="span" fontSize={FontSizesEnum.Delta} fontWeight={FontWeightEnum.Bold}>
              #{detail.producto}
            </Typography>
            <ChipProcedencia folio={origenLineaPorDetalle.get(detail.pedidoDetalleId)?.folio ?? null} />
            {row.existenciaInsuficiente && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorRedStatusOrders, backgroundColor: ColorsEpico.ColorRedStatusOrdersBg }}>
                Sin existencia
              </Typography>
            )}
            {row.kmsAplicados && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorWhite, backgroundColor: ColorsEpico.ColorGreenLush }}>
                Kms
              </Typography>
            )}
            {row.ahorro > 0 && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorBlack, backgroundColor: ColorsEpico.ColorGreenLush }}>
                {row.ahorro}%
              </Typography>
            )}
            {row.tienePrecioEspecial && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorDarkCharcoal, backgroundColor: ColorsEpico.ColorGrayDull }}>
                PE
              </Typography>
            )}
            {/* El equivalente de la insignia verde que escritorio pinta junto al precio. */}
            {row.tieneMejorPrecio && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorGreenStatusOrders, backgroundColor: ColorsEpico.ColorGreenStatusOrdersBg }}>
                PF
              </Typography>
            )}
            {row.esRegalo && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorDarkCharcoal, backgroundColor: ColorsEpico.ColorGrayDull }}>
                Regalo
              </Typography>
            )}
            {row.esPickupExclusivo && (
              <Typography component="span" sx={{ ...chipSx, color: ColorsEpico.ColorChipText, backgroundColor: ColorsEpico.ColorChipBackground }}>
                Pickup
              </Typography>
            )}
          </Box>
          <Typography
            sx={{
              display: "block",
              minWidth: 0,
              fontSize: FontSizesEnum.Epsilon,
              color: ColorsEpico.ColorDarkCharcoal,
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap",
            }}
          >
            {row.descripcion}
          </Typography>
        </Box>

        <Box sx={{ flexShrink: 0, textAlign: "right" }}>
          <Typography
            fontSize={FontSizesEnum.Delta}
            fontWeight={FontWeightEnum.Bold}
            sx={row.importeTachado ? { textDecoration: "line-through", color: ColorsEpico.ColorGrayDisabled } : undefined}
          >
            {new CoinFormatter(Number(row.importe)).coin}
          </Typography>
          {row.kmsAplicados && (
            <Typography fontSize={FontSizesEnum.Epsilon} fontWeight={FontWeightEnum.Bold} color={ColorsEpico.ColorGreenLush}>
              {row.kms.toLocaleString()} Kms
            </Typography>
          )}
          <Typography fontSize={FontSizesEnum.Epsilon} color={ColorsEpico.ColorGray}>
            ×{detail.cantidad}
          </Typography>
        </Box>

        <ChevronRight sx={{ flexShrink: 0, color: ColorsEpico.ColorGray }} />
      </Box>
    );
  };

  return (
    <Box>
      <ModalProductsPromotions
        open={showDiscountModal}
        handleClose={handleHideDiscountModal}
        loading={loadingDiscounts}
      />
      <ModalDelete
        titulo={"ELIMINAR PRODUCTO"}
        openModal={warningModal}
        onOk={wrappedFetchDeleteProduct(
          deletedId,
          specialPriceId,
          setWarningModal,
          false
        )}
        onClose={() => setWarningModal(false)}
        description={modalDeleteMessage}
        question={"¿Estás seguro de querer eliminarlo?"}
        loading={pendingDelete}
      />
      <ModalDelete
        titulo="AJUSTE DE CANTIDAD"
        openModal={scalesDecrementModal}
        description={'El producto es parte de la promoción "Paquete por escalas", al momento de reducir las piezas, la promoción se modificará o invalidará.'}
        question="¿Estás seguro de querer reducir las piezas?"
        btnTextClose="Cancelar"
        btnTextConfirm="Reducir"
        onClose={handleScalesDecrementCancel}
        onOk={handleScalesDecrementConfirm(setScalesDecrementModal)}
        loading={pendingScalesDecrement}
      />
      <ModalDelete
        titulo={"QUITAR PROMOCIÓN"}
        openModal={isRemoveDiscountModalOpen}
        onOk={async () => {
          startPendingDeletePromotion(async () => {
            await handleQuitDiscount(pedidoDetalleId, orderSummaryDetail);
            setIsRemoveDiscountModalOpen(false);
          });
        }}
        onClose={() => setIsRemoveDiscountModalOpen(false)}
        description={"Se retirará la promoción y se conservarán los productos"}
        question={"¿Estás seguro de querer eliminarlo?"}
        loading={pendingDeletePromotion}
      />
      <ModalDelete
        titulo={
          selectedOrderSummary?.estatusID === 4
            ? "ELIMINAR COTIZACIÓN"
            : "ELIMINAR CAJA"
        }
        openModal={warningOrderModal}
        onOk={wrappedFetchDeleteProduct(
          deletedId,
          specialPriceId,
          setWarningOrderModal,
          true
        )}
        onClose={() => setWarningOrderModal(false)}
        description={modalDeleteMessage}
        question={`¿Estás seguro de querer eliminarl${selectedOrderSummary?.estatusID === 4 ? "a" : "o"
          }?`}
        loading={pendingDelete}
      />

      <ModalDelete
        titulo="Producto con precio especial"
        openModal={cancelSpecialPriceModal}
        question="¿Estás seguro de cancelarlo?"
        description="El producto cuenta con un precio especial aplicado. Si continúas con esta acción sera cancelado."
        btnTextClose="Cancelar"
        btnTextConfirm="Continuar"
        onClose={() => setCancelSpecialPriceModal(false)}
        onOk={wrappedFetchCancelSpecialPrice(setCancelSpecialPriceModal)}
        loading={pendingCancelSpecialPrice}
      />
      <ModalGenericTwoActions
        openModal={packageModal}
        regularTitle={false}
        title={"Promoción paquete"}
        onNegativeSave={onNegativeSave}
        onClose={onClose}
        onPositiveSave={onPositiveSave}
        btnTextNegativeSave={"Solo un producto"}
        btnSizeNegativeSave="small"
        btnTextPositiveSave="Todo el paquete"
        saveNotRequired={false}
      >
        <p
          style={{
            color: "#1A202C",
            fontSize: "16px",
            fontWeight: 500,
          }}
        >
          La cantidad de piezas de ésta promoción se esta modificando. ¿Deseas
          agregar la cantidad de piezas correspondientes a un nuevo paquete o
          solo {addCuantity} pieza(s) del código {productCode}?
          <br />
          <br />
          Nota: Al agregar todo el paquete, se aumentarán las piezas de todos
          los productos de la promoción.
        </p>
      </ModalGenericTwoActions>
      <ModalGeneric
        openModal={specialPriceModal}
        titulo={"Solicitud de precio especial"}
        onSave={
          orderSummaryDetail &&
          wrappedFetchSpecialPriceRequest(
            setModalSpecialPriceButtonStatus,
            orderSummaryDetail,
            Number(price.toString()),
            comment,
            setSpecialPriceModal,
            setCounterButtonState
          )
        }
        onClose={
          counterButtonState ? () => { } : () => setSpecialPriceModal(false)
        }
        btnTextSave={"Solicitar"}
        btnTextClose={"Cancelar"}
        btndisabledSave={modalSpecialPriceButtonStatus}
        isLoading={counterButtonState}
      >
        <Stack spacing={1}>
          <Typography variant="subtitle1" fontWeight="bold">
            <span style={{ color: "red" }}>*</span> Precio Solicitado
          </Typography>
          <InputCash
            disabled={counterButtonState}
            denyNegatives={true}
            value={price}
            onChange={handlePriceChange}
            size="small"
          />
          <Box sx={{ display: onSpecialPriceRules ? "block" : "none" }}>
            <Typography variant="subtitle1" fontWeight="bold">
              INFORMACIÓN DEL COMPETIDOR
            </Typography>
            <Typography variant="subtitle1" fontWeight="bold">
              Nombre del competidor
            </Typography>
            <TextField
              placeholder="Escribe el nombre del proveedor de la competencia"
              variant="outlined"
              value={nameCompetitor}
              onChange={handleNameCompetitorChange}
              fullWidth
              autoComplete="off"
              name="nobreCompetidor"
              id="nobreCompetidor-token-id"
              inputProps={{
                maxLength: 50,
              }}
              size="small"
            />
            <Typography variant="subtitle1" fontWeight="bold">
              Marca del competidor
            </Typography>
            <TextField
              placeholder="Marca de la competencia"
              variant="outlined"
              value={brandCompetitor}
              onChange={handleBrandCompetitorChange}
              fullWidth
              autoComplete="off"
              name="marcaCompetidor"
              id="marcaCompetidor-token-id"
              inputProps={{
                maxLength: 50,
              }}
              size="small"
            />
          </Box>
          <Typography variant="subtitle1" fontWeight="bold">
            <span style={{ color: "red" }}>*</span> Comentario
          </Typography>
          <TextField
            disabled={counterButtonState}
            placeholder="Escribe tu comentario"
            variant="outlined"
            value={comment}
            onChange={handleCommentChange}
            fullWidth
            autoComplete="on"
            name="comentarioToken"
            id="comentario-token-id"
            rows={1}
            size="small"
            slotProps={{
              input: {
                sx: {
                  maxLength: 200,
                },
              },
            }}
            inputProps={{
              maxLength: 200,
            }}
            helperText={
              <div style={{ textAlign: "right" }}>
                {`${comment.length}/200`}
              </div>
            }
          />
        </Stack>
      </ModalGeneric>
      <ModalGeneric
        openModal={specialPriceModalReset}
        titulo={"SOLICITAR NUEVO TOKEN"}
        onSave={() => {
          wrappedFetchDeleteSpecialPriceReset(
            specialPriceIdReset,
            pedidoDetalleIdReset,
            pedidoDetallePrecioListaReset,
            product,
            false, //Mejor precio aplicado
          );
        }}
        onClose={() => setSpecialPriceModalReset(false)}
        btnTextSave={"Aceptar"}
        btnTextClose={"Cancelar"}
        isLoading={counterButtonStateReset}
      >
        <Box>
          <Typography
            fontWeight={FontWeightEnum.Regular}
            fontSize={FontSizesEnum.Gamma}
          >
            Al solicitar un nuevo token se perderá la petición y/o status de la
            actual solicitud y deberás reiniciar el proceso.
          </Typography>
          {/* On a proposal line item, removing the special price returns it to the proposal price, not the list price; this notice is added to the token one. */}
          {origenLineaPorDetalle.get(pedidoDetalleIdReset)?.esPropuestaComercial && (
            <Typography
              fontWeight={FontWeightEnum.Regular}
              fontSize={FontSizesEnum.Gamma}
            >
              {MENSAJE_RETIRO_PRECIO_ESPECIAL_EN_PROPUESTA}
            </Typography>
          )}
          <Typography
            fontWeight={FontWeightEnum.Medium}
            fontSize={FontSizesEnum.Gamma}
          >

            ¿Estas seguro de querer solicitar un nuevo token?
          </Typography>
        </Box>
      </ModalGeneric>
      <ModalGeneric //MODAL PRECIO FINAL
        openModal={finalPriceModalReset}
        titulo={"PRODUCTO CON MEJOR PRECIO"}
        onSave={() => {
          wrappedFetchDeleteSpecialPriceReset(
            specialPriceIdReset,
            pedidoDetalleIdReset,
            pedidoDetallePrecioListaReset,
            product,
            true, //Mejor precio aplicado
          );
        }}
        onClose={() => setFinalPriceModalReset(false)}
        btnTextSave={"Aceptar"}
        btnTextClose={"Cancelar"}
        isLoading={counterButtonStateReset}
      >
        <Box>
          <Typography
            fontWeight={FontWeightEnum.Regular}
            fontSize={FontSizesEnum.Gamma}
          >
            Este producto tiene un mejor precio aplicado, si lo cancelas para solicitar otro precio o aplicar una promoción, perderás este beneficio.
            Para recuperarlo, elimina el producto del pedido y agrégalo nuevamente.
          </Typography>
          <Typography
            fontWeight={FontWeightEnum.Medium}
            fontSize={FontSizesEnum.Gamma}
          >

            ¿Estas seguro de querer quitar el precio especial?
          </Typography>
        </Box>
      </ModalGeneric>
      <ModalGenericTwoActions
        btndisabledSave={specialPriceButtonUpdate}
        openModal={specialPriceNegotiatedModal}
        regularTitle={false}
        title={"Precio Negociado"}
        onNegativeSave={wrappedFetchSpecialPriceRequest(
          setSpecialPriceButtonUpdate,
          orderSummaryDetail,
          suggestedPrice,
          executiveComment,
          setSpecialPriceNegotiatedModal,
          setCounterButtonState,
          SpecialPriceStates.Rechazado.index
        )}
        onClose={() => setSpecialPriceNegotiatedModal(false)}
        btnTextNegativeSave={"Rechazar Precio"}
        btnSizeNegativeSave="small"
        saveNotRequired={true}
      >
        <Stack spacing={1}>
          <Typography fontWeight={FontWeightEnum.Bold}>
            PRECIO SUGERIDO
          </Typography>
          <Grid2 container alignItems="right">
            <Grid2 size={{ xs: 8 }}>
              <InputCash
                sx={{ width: "80%" }}
                denyNegatives={true}
                value={suggestedPrice}
                size="small"
                disabled
              />
            </Grid2>
            <Grid2
              size={{ xs: 4 }}
              sx={{ textAlign: "end", alignContent: "center" }}
              justifyContent="flex-end"
            >
              <Button
                disabled={specialPriceButtonUpdate}
                sx={{
                  px: 3,
                  fontSize: FontSizesEnum.Gamma,
                  "&.Mui-disabled": {
                    backgroundColor: "#9FA8DA",
                    color: "#FFFFFF",
                    opacity: 1,
                  },
                }}
                size="small"
                variant="contained"
                type="submit"
                onClick={wrappedFetchSpecialPriceRequest(
                  setSpecialPriceButtonUpdate,
                  orderSummaryDetail,
                  suggestedPrice,
                  executiveComment,
                  setSpecialPriceNegotiatedModal,
                  setCounterButtonState,
                  SpecialPriceStates.Aceptado.index
                )}
              >
                Aceptar Precio
              </Button>
            </Grid2>
          </Grid2>
          <Typography fontWeight={FontWeightEnum.Bold}>
            COMENTARIO
          </Typography>
          <TextField
            variant="outlined"
            value={executiveComment}
            fullWidth
            multiline
            rows={1}
            disabled
            size="small"
          />
        </Stack>
      </ModalGenericTwoActions>
      <ModalGeneric
        titulo="registrar producto negado"
        openModal={denyProductModal}
        btnTextClose="Cancelar"
        btnTextSave="Continuar"
        onClose={() => {
          setDenyProduct(undefined);
          setDenyProductModal(false);
        }}
        onSave={async () => {
          const detail = detalles.filter(
            (detail) => detail.producto === denyProduct
          );
          if (detail && selectedOrderSummary && userAuthState.userAuth) {
            const denyResponse = await postDenyProduct({
              pedidoId: detail[0].pedidoID,
              producto: detail[0].producto || "",
              cantidad: detalles
                .filter((pr) => pr.producto === denyProduct)
                .reduce((stock, pr) => stock + +pr!.cantidad!, 0),
              sucursalId: selectedOrderSummary.sucursalIdDestino || 0,
              clienteId: selectedOrderSummary.clienteId,
              usuarioId: userAuthState.userAuth.userId,
            });
            handleRequestDto({
              response: denyResponse,
              onSuccess: async () => {
                await handleSetDeniedProduct(detail);
                setDenyProduct(undefined);
                setDenyProductModal(false);
                showSnackbar(
                  "El código se registro como producto negado con éxito",
                  "success"
                );
              },
              onError: () => {
                setDenyProduct(undefined);
                setDenyProductModal(false);
                showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
              },
              onInvalid: () => {
                setDenyProduct(undefined);
                setDenyProductModal(false);
                showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
              },
            });
          }
        }}
      >
        <Box>
          <Typography fontWeight={FontWeightEnum.Regular}>
            ¿Deseas registrar el producto <b>{denyProduct}</b> como Producto
            Negado?
          </Typography>
        </Box>
      </ModalGeneric>

    {/*  <Popover
        open={Boolean(lastPriceAnchorEl)}
        anchorEl={lastPriceAnchorEl}
        onClose={() => setLastPriceAnchorEl(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        transformOrigin={{ vertical: "top", horizontal: "left" }}
        slotProps={{ paper: { sx: { p: 1.5, minWidth: 360 } } }}
      >
        <Typography
          fontSize={FontSizesEnum.Gamma}
          fontWeight={FontWeightEnum.Bold}
          mb={1}
          color={ColorsEpico.ColorDarkCharcoal}
        >
          Último precio comprado
        </Typography>
        {lastPriceLoading ? (
          <Stack spacing={0.75}>
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} variant="text" width="100%" height={24} />
            ))}
          </Stack>
        ) : lastPriceData ? (
          <Stack spacing={0.75}>
            {([
              { label: "Factura", value: String(lastPriceData.numeroFactura) },
              { label: "Fecha", value: lastPriceData.fecha },
              { label: "Cantidad", value: String(lastPriceData.cantidad) },
              { label: "Precio", value: new CoinFormatter(lastPriceData.precio).coin },
              { label: "Sucursal", value: lastPriceData.sucursal },
            ] as { label: string; value: string }[]).map(({ label, value }) => (
              <Stack key={label} direction="row" justifyContent="space-between" gap={2}>
                <Typography fontSize={FontSizesEnum.Gamma} color={ColorsEpico.ColorGray}>
                  {label}
                </Typography>
                <Typography fontSize={FontSizesEnum.Gamma} fontWeight={FontWeightEnum.Medium} color={ColorsEpico.ColorDarkCharcoal}>
                  {value}
                </Typography>
              </Stack>
            ))}
          </Stack>
        ) : (
          <Typography fontSize={FontSizesEnum.Gamma} color={ColorsEpico.ColorGray}>
            No se encontró información del último precio facturado.
          </Typography>
        )}
      </Popover>*/}

      <ModalGenericProductDescriptionEdition
        openDialog={editGenericProductDescriptionModal}
        closeDialog={() => {
          setEditGenericProductDescriptionModal(false);
          setGenericProductSelected(null);
        }}
        onSaveEvent={handleGenericProductEdition}
        genericProduct={genericProductSelected}
      />

      <AccordionGeneric
        title={`${selectedOrderSummary?.estatusID === StatusOrderEnum.Facturado
          ? "Cotización"
          : "Pedido"
          } ${selectedOrderSummary?.pedidoID ?? "N/A"}`}
        defaultExpanded
        sxSummary={{ pl: 0 }}
        sxTitle={{
          textTransform: "uppercase",
          color: ColorsEpico.ColorDarkCharcoal,
          fontSize:
            selectedOrderSummary?.estatusID === StatusOrderEnum.Facturado
              ? FontSizesEnum.Alpha
              : FontSizesEnum.Gamma,
          ml:
            selectedOrderSummary?.estatusID === StatusOrderEnum.Facturado
              ? "10px"
              : 0,
          fontWeight:
            selectedOrderSummary?.estatusID === StatusOrderEnum.Facturado
              ? FontWeightEnum.Medium
              : FontWeightEnum.Bold,
        }}
        sxDetail={{
          pt: 0,
          px: 0,
        }}
        titleNode={
          selectedOrderSummary?.origenExternoId && (
            <Typography
              style={{
                marginLeft: "5px",
                background: ColorsEpico.ColorGrayLight,
                borderRadius: "50px",
                padding: "0px 10px",
                color: ColorsEpico.ColorWhite,
              }}
            >
              {selectedOrderSummary?.origenExternoId == OrigenEnum.Web
                ? "ExodusWeb"
                : "Samsung"}
            </Typography>
          )
        }
        summary={
          <Stack direction={"row"} spacing={3} alignItems="center">
            <Typography
              fontWeight={FontWeightEnum.Regular}
              color={ColorsEpico.ColorGrayLight}
              fontSize={FontSizesEnum.Gamma}
            >
              ( {detalles.length} articulos )
            </Typography>

            <Stack direction="row">
              <Typography
                fontWeight={FontWeightEnum.Regular}
                color={ColorsEpico.ColorDarkCharcoal}
                fontSize={FontSizesEnum.Alpha}
                sx={{
                  textTransform: "uppercase",
                  textAlign: "left",
                  letterSpacing: "1.28px",
                }}
              >
                {formattedSubtotal.intCoin}
              </Typography>
              <Typography
                fontWeight={FontWeightEnum.Regular}
                color={ColorsEpico.ColorDarkCharcoal}
                fontSize={FontSizesEnum.Alpha}
                sx={{
                  display: "flex",
                  fontSize: "1rem",
                  alignItems: "center",
                }}
              >
                {formattedSubtotal.decimal}
              </Typography>
            </Stack>
          </Stack>
        }
        alert={
          selectedOrderSummary?.estatusID === StatusOrderEnum.Facturado &&
          !readOnly && (
            <Collapse in={alertTable}>
              <Stack
                width={"99%"}
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                py="8px"
                px="10px"
                sx={{
                  backgroundColor: ColorsEpico.ColorLightBlueishGray,
                  height: "32px",
                  mb: 2,
                }}
              >
                <Typography
                  color={ColorsEpico.ColorDarkCharcoal}
                  fontWeight={FontWeightEnum.Regular}
                  fontSize={FontSizesEnum.Delta}
                  textTransform="uppercase"
                >
                  Los cambios que realices se actualizarán automáticamente
                </Typography>
                <IconButton onClick={() => setAlertTable(false)}>
                  <Close
                    sx={{
                      fontSize: FontSizesEnum.Alpha,
                      color: ColorsEpico.ColorDarkCharcoal,
                    }}
                  />
                </IconButton>
              </Stack>
            </Collapse>
          )
        }
      >
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* <900px (isMobileExperience): cada artículo se renderiza como una card a
              medida reutilizando los mismos handlers y thunks del contenedor.
              >=900px: se conserva intacto el DataGridServerPagination. Las celdas del
              grid usan hooks (useProductKms) y params.api, por lo que no pueden
              reutilizarse con el AdaptiveDataGrid genérico. */}
          {isMobileExperience ? (
            <Box
              sx={{
                opacity:
                  loading || loadingTable || anyProductLoading || loadingKms || isUpdatingKms
                    ? 0.5
                    : 1,
                pointerEvents:
                  loading || loadingTable || anyProductLoading || loadingKms || isUpdatingKms
                    ? "none"
                    : "auto",
                transition: "opacity 0.2s ease",
              }}
            >
              {/* El efecto que calcula los Kms de cada artículo se monta por artículo y
                  fuera de la hoja: si viviera dentro, los Kms de los artículos cerrados
                  no se calcularían y el renglón mostraría cero. Va sobre `detalles`
                  completo, no sobre el filtro, para que buscar no los desmonte. */}
              {detalles.map((detail) => {
                const productoKey = String(detail.producto);
                const kmsProducto =
                  dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
                    selectedOrderSummary?.pedidoID ?? 0
                  ]?.products[productoKey];
                const precioIVA =
                  kmsProducto?.isActiveKms && (detail.importeIVA ?? 0)
                    ? kmsProducto?.valueProductAfterKms ?? detail.importeIVA ?? 0
                    : detail.importeIVA ?? 0;

                return (
                  <ProductKmsEffect
                    key={`kms-${detail.pedidoDetalleId}`}
                    productoId={productoKey}
                    precioIVA={precioIVA}
                    useProductKms={useProductKms}
                  />
                );
              })}

              {/* Con la caja llena, encontrar un artículo es el problema real. */}
              {detalles.length >= MIN_ARTICULOS_PARA_BUSCADOR && (
                <TextField
                  fullWidth
                  size="small"
                  value={filtroArticulos}
                  onChange={(event) => setFiltroArticulos(event.target.value)}
                  placeholder="Buscar en la caja: código o descripción"
                  sx={{ mt: 1, mb: 0.5 }}
                  slotProps={{
                    input: {
                      startAdornment: (
                        <InputAdornment position="start">
                          <SearchIcon fontSize="small" />
                        </InputAdornment>
                      ),
                    },
                  }}
                />
              )}

              <Box sx={{ mt: 1, borderTop: `1px solid ${ColorsEpico.ColorLightBlueishGray}` }}>
                {articulosFiltrados.map(({ detail, index }) =>
                  renderMobileArticleRow(detail, index)
                )}
                {articulosFiltrados.length === 0 && (
                  <Typography
                    sx={{ p: 2, textAlign: "center", color: ColorsEpico.ColorGray }}
                    fontSize={FontSizesEnum.Gamma}
                  >
                    Ningún artículo de la caja coincide con «{filtroArticulos}»
                  </Typography>
                )}
              </Box>

              {/* Hoja de edición: el detalle completo del artículo, al alcance del pulgar
                  y sin mover la lista de sitio. */}
              <Drawer
                anchor="bottom"
                open={detalleEnHoja !== undefined}
                onClose={() => setArticuloEnHoja(null)}
                slotProps={{
                  paper: {
                    sx: {
                      borderRadius: "14px 14px 0 0",
                      maxHeight: "85vh",
                      paddingBottom: "env(safe-area-inset-bottom)",
                    },
                  },
                }}
              >
                {detalleEnHoja && (
                  <Box>
                    <Box
                      sx={{
                        position: "sticky",
                        top: 0,
                        zIndex: 1,
                        backgroundColor: ColorsEpico.ColorWhite,
                        pt: 1,
                        px: 1.5,
                        borderBottom: `1px solid ${ColorsEpico.ColorLightBlueishGray}`,
                      }}
                    >
                      <Box
                        sx={{
                          width: 36,
                          height: 4,
                          borderRadius: "99px",
                          backgroundColor: ColorsEpico.ColorLightBlueishGray,
                          mx: "auto",
                          mb: 1,
                        }}
                      />
                      <Box sx={{ display: "flex", alignItems: "flex-start", gap: 1, pb: 1 }}>
                        <Box sx={{ minWidth: 0, flex: 1 }}>
                          <Typography fontSize={FontSizesEnum.Gamma} fontWeight={FontWeightEnum.Bold}>
                            #{detalleEnHoja.detail.producto}
                          </Typography>
                          {/* En la hoja hay sitio: la descripción se lee completa. */}
                          <Typography
                            fontSize={FontSizesEnum.Epsilon}
                            color={ColorsEpico.ColorDarkCharcoal}
                            sx={{ wordBreak: "break-word" }}
                          >
                            {detalleEnHoja.detail.descripcion}
                          </Typography>
                        </Box>
                        <IconButton
                          aria-label="Cerrar"
                          onClick={() => setArticuloEnHoja(null)}
                          sx={{ flexShrink: 0, width: 44, height: 44 }}
                        >
                          <CloseIcon />
                        </IconButton>
                      </Box>
                    </Box>
                    {renderMobileArticleDetail(detalleEnHoja.detail, detalleEnHoja.index)}
                  </Box>
                )}
              </Drawer>
            </Box>
          ) : (
            <Box sx={{ overflow: "visible" }}>
              <DataGridServerPagination
                personalizedRowHeight={200}
                sx={{
                  height: "auto !important",
                  overflow: "visible !important",
                  minHeight: "400px",

                  "& .MuiDataGrid-cell": {
                    borderBottom: "none",
                    display: "flex",
                    alignItems: "center",
                  },

                  "& .MuiDataGrid-scrollbar": {
                    display: "none !important",
                  },
                }}
                rows={detalles}
                columns={COLUMNS}
                loading={
                  loading || loadingTable || anyProductLoading || loadingKms || isUpdatingKms
                }
                getRowId={(row) => `${row.pedidoDetalleId}`}
                rowCount={detalles.length}
                columnVisibilityModel={columnVisibilityModel}
                hideFooter
                getRowClassName={(params) => {
                  if (
                    (userAuthState.userAuth?.engineSMC4 && mostrarExistenciasSMC4 && !pendingStockNational && (params.row.stockNacional === 0 || params.row.stockNacional < params.row.cantidad)) ||
                    !userAuthState.userAuth?.engineSMC4 && (
                      params.row.stockEnSucursal === 0 ||
                      params.row.stockEnSucursal < params.row.cantidad ||
                      params.row.stockEnSMC === 0 ||
                      params.row.stockEnSMC < params.row.cantidad
                    )
                  ) {
                    return "Stock-LessThanQuantity";
                  }
                  return "";
                }}
              />
            </Box>
          )}
        </Box>
      </AccordionGeneric>
    </Box>
  );
};