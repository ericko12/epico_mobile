import { redirect } from "next/navigation";
import { PATH_PAGE } from "@/routes/paths";
import { FC, Fragment, useEffect, useState } from "react";
import { Button } from "@mui/material";
import { ICheckoutFooter } from "@/features/checkout/domain/interfaces/checkOut/ICheckoutFooter";
import {
  useAppDispatch,
  useAppSelector,
} from "@/features/common/application/redux/hooks";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { CoinFormatter } from "@/features/common/infrastructure/utils/models/CoinFormatter";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { fetchCustomerInformationAction } from "@/features/customer/application/actions/fetchCustomerApplySMC";
import { IShipmentState } from "@/features/shipment/domain/interfaces/IShipmentState";
import { ShipmentSteps } from "@/features/shipment/domain/enum/ShipmentSteps";
import { setActiveStep, setResetSteps, setOrderShipmentSMC4 } from "@/features/shipment/application/redux/ShipmentSlice";
import { DeleteUnshippedMiniCheckouts } from "@/features/checkout/application/actions/deletedUnshippedMiniCheckouts";
import { SpecialPriceStates } from "@/features/checkout/domain/data/SpecialPriceStates";
import { ProductService } from "@/features/products/application/service/product.services";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import { SummaryFooter } from "@/features/common/infrastructure/ui/summaryFooter/SummaryFooter";
import { handleInfoShippingChangeThunk, resetSummarySMC4Thunk } from "@/features/shipment/application/redux/ShipmentThunks";
import { loyaltyPlanService } from "@/features/loyaltyPlan/application/service/loyaltyPlanService";
import { customRound } from "@/features/common/infrastructure/utils/numeric";
import { ModalAllExlusivePickup } from "@/features/checkout/infrastructure/ui/checkoutDetail/dialogs/ModalAllExlusivePickup";
import { allProductsPickup } from "@/features/checkout/infrastructure/utils/stock/allProductsPickup";
import { ContinueAction, OrderTrackingModal } from "@/features/checkout/infrastructure/ui/checkoutDetail/dialogs/OrderTrackingModal";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { paymentGatewayService } from "@/features/openPay/application/services/paymentGateway.services";
import { ConcessionsEnum } from "@/features/common/domain/enums/ConcessionsEnum";
import { FormaPagoEnum } from "@/features/common/domain/enums/FormaPagoEnum";
import { getSMC4NextShowDate, setSMC4NextShowDate } from "@/features/common/infrastructure/utils/smc4Preference";
import { EngineSMCEnum } from "@/features/auth/domain/enums/securityProject/EngineSMCEnum";
import { fetchObject } from "@/features/common/application/action/fetchObject";
import { ModalRememberSMC4 } from "@/features/checkout/infrastructure/ui/smc4/dialogs/ModalRememberSMC4";
import { ObjectResponse } from "@/features/auth/domain/interfaces/securityProject/objectResponse";
import { customerService } from "@/features/customer/application/service/customer.services";
import { NOTIFICATIONS_CUSTOMER } from "@/features/customer/infrastructure/utils/messages/NotificationCustomer";
import { setTotalAfterKms } from "@/features/loyaltyPlan/application/redux/loyaltyPlanSlice";

/**
 * Organismo: componente que contiene el footer de la pagina de checkout
 * @param {handleBtnQuoation} () => void ? - controlador del boton para confirmar cotizacion.
 */
export const CheckoutDetailFooter: FC<ICheckoutFooter> = ({
  handleBtnQuoation,
}) => {
  //Redux
  const dispatch = useAppDispatch();
  const { selectedOrderSummary, loading }: ICheckOutState = useAppSelector(
    (state) => state.sessionState.checkOutsState ?? ({} as ICheckOutState)
  );
  const { shipmentsSteps }: IShipmentState = useAppSelector(
    (state) => state.sessionState.shipmentState ?? ({} as IShipmentState)
  );
  const dataCustomer = useAppSelector(
    (state) => state.sessionState.loyaltyPlanState?.customers ?? {}
  );
  const userAuth = useAppSelector((state) => state.localState.authState?.userAuth);
  const isForcedSMC3 = useAppSelector(
    (state) => (state.sessionState.shipmentState?.forcedSMC3Orders ?? []).includes(selectedOrderSummary?.pedidoID ?? 0)
  );
  // SMC 4.0 applies only if the user has it active and the order was not sent to SMC 3 ("Procesar con SMC 3")
  const engineSMC4ForOrder = !!userAuth?.engineSMC4 && !isForcedSMC3;

  //state
  const [moneyValue, setMoneyValue] = useState<number>();
  const [openModalPickupExclusive, setOpenModalPickupExclusive] = useState<boolean>(false);
  const [openTrackingModal, setOpenTrackingModal] = useState<boolean>(false);
  const [continueAction, setContinueAction] = useState<ContinueAction>(null);
  const [objectEngineSMC4, setObjectEngineSMC4] = useState<ObjectResponse[]>([]);

  //Hooks
  const { showSnackbar } = useSnackbar();
  const { GetIdsProductsByFamily } = ProductService();
  const { getKmsConversion } = loyaltyPlanService();
  const { getLinkStatus } = paymentGatewayService();
  const { getComercialParameter, getIsKeyAccountCustomer } = customerService();

  //states
  const [specialCodes, setSpecialCodes] = useState<number[]>([]);
  const [openModalRemember, setOpenModalRemember] = useState(false);

  const hasTrackingData = (): boolean => {
    const originadorId = selectedOrderSummary?.originadorId;
    const medioAtencionId = selectedOrderSummary?.medioAtencionId;
    return (
      originadorId !== null &&
      originadorId !== undefined &&
      originadorId > 0 &&
      medioAtencionId !== null &&
      medioAtencionId !== undefined &&
      medioAtencionId > 0
    );
  };

  // constants
  const formattedSubtotal = new CoinFormatter(
    selectedOrderSummary?.subTotalIVA ?? 0
  );
  const formattedSubtotalSinIva = new CoinFormatter(
    selectedOrderSummary?.subTotal ?? 0
  );
  const formattedIVA = new CoinFormatter(
    selectedOrderSummary?.ivaCalculado ?? 0
  );
  const formattedDescuento = selectedOrderSummary?.ahorroPromociones
    ? new CoinFormatter(selectedOrderSummary?.ahorroPromociones!).coin
    : new CoinFormatter(0).coin;
  const fortmattedKms = new CoinFormatter(moneyValue ?? 0);
  const FamilyIdGenericTlcProduct =
    +process.env.NEXT_PUBLIC_GENERIC_PRODUCT_TLC!;

  // comprueba que si existen productos o precios especiales en pendientes
  const disableBtnContinue: boolean =
    (selectedOrderSummary?.detalles ?? []).length === 0 ||
    (selectedOrderSummary?.detalles?.some(
      (detail) =>
        detail.estatusPrecioEspecialId ===
        SpecialPriceStates.Solicitado.index ||
        detail.estatusPrecioEspecialId === SpecialPriceStates.Negociado.index
    ) ??
      true);

  const isBlocked = selectedOrderSummary?.estatusInternoId === StatusOrderEnum.OpenPay && selectedOrderSummary?.origenExternoId === OrigenEnum.Web;

  /**
   * Fetches the total kms of usage and makes to convertion to actual money
   * uses the provider information
   */
  useEffect(() => {
    const convertKMs = async () => {
      let puntosAConvertir = 0;

      // Verificar todos los niveles con optional chaining
      const clienteId = selectedOrderSummary?.clienteId;
      const pedidoID = selectedOrderSummary?.pedidoID;

      if (clienteId !== undefined && pedidoID !== undefined) {
        const customer = dataCustomer[clienteId];
        const order = customer?.ordersKms?.[pedidoID];

        if (order && !order.orderClosed) {
          puntosAConvertir = order.kmsInUsePerOrder || 0;
        }
      }

      if (puntosAConvertir === 0) {
        setMoneyValue(0);
        return;
      }

      try {
        const response = await getKmsConversion(
          String(clienteId ?? 0),
          puntosAConvertir
        );
        await handleRequestDto({
          response,
          messages: {
            error: "No se pudo recuperar la información del cliente.",
            invalid: response.error?.mensaje,
          },
          onSuccess: async () => {
            setMoneyValue(customRound(response.data?.data.montoEnPesos || 0));
          },
          onInvalid: async () => {
            setMoneyValue(0);
          },
          onError: async () => {
            setMoneyValue(0);
          },
        });
      } catch (err: any) {
        setMoneyValue(0);
      }
    };

    convertKMs();
  }, [
    selectedOrderSummary?.clienteId,
    selectedOrderSummary?.pedidoID,
    dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
      selectedOrderSummary?.pedidoID ?? 0
    ]?.orderClosed,
    dataCustomer[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
      selectedOrderSummary?.pedidoID ?? 0
    ]?.kmsInUsePerOrder,
  ]);
  /**
   * Checks if there are any products with special codes in the selected order summary
   * that have special prices which have not been accepted.
   *
   * If such products exist, displays a warning snackbar notification.
   *
   * @returns {boolean} Returns `true` if there are products with special codes and unaccepted special prices; otherwise, `false`.
   */
  const SpecialCodeAndSpecialPriceNotAcepted = () => {
    var result =
      selectedOrderSummary?.detalles?.some(
        (detail) =>
          specialCodes.includes(detail.productoID) &&
          detail.estatusPrecioEspecialId !== SpecialPriceStates.Aceptado.index
      ) ?? false;
    if (result) {
      showSnackbar(
        "A los productos TLC se les debe asignar un precio especial, solicita token para poder continuar.",
        "warning"
      );
    }
    return result;
  };



  /**
   * Retrieves and normalizes the KAM empresas employee ids from the comercial parameter.
   *
   * @returns {Promise<Set<string>>} A set with allowed KAM employee ids.
   */
  const fetchKamUsers = async (): Promise<Set<string>> => {
    const kamUsersParameterName = process.env.NEXT_PUBLIC_PARAMETRO_COMERCIAL_USUARIOS_KAM ?? "UsuariosKamEmpresas";
    const kamUsersParameter = await getComercialParameter(kamUsersParameterName);
    return new Set(
      (kamUsersParameter.data?.valor ?? '')
        .split(',')
        .map((id) => id.trim())
        .filter(Boolean)
    );
  };

  /**
   * Checks whether the KAM empresas validation feature is enabled via its comercial parameter flag.
   *
   * @returns {Promise<boolean>} True when the validation flag is 'True'.
   */
  const fetchUserKamFlag = async (): Promise<boolean> => {
    const flagParameterName = process.env.NEXT_PUBLIC_PARAMETRO_COMERCIAL_BANDERA_USUARIOS_KAM ?? "Bandera_UsuariosKamEmpresa";
    const flagParameter = await getComercialParameter(flagParameterName);
    return flagParameter.data?.valor === 'True';
  };

  /**
   * Indicates whether the selected order's customer is marked as key account in backend.
   *
   * @returns {Promise<boolean>} True when customer is key account, otherwise false.
   */
  const fetchIsKeyAccountCustomer = async (clienteId: number): Promise<boolean> => {
    const response = await getIsKeyAccountCustomer(clienteId);
    return response.data ?? false;
  };

  /**
   * Validates whether the current user can continue the flow for key-account customers.
   * Mirrors the validation done in the customer search module (TableCustomers).
   *
   * @returns {Promise<boolean>} True when the action is allowed, otherwise false.
   */
  const validateKamPermissionForKeyAccount = async (): Promise<boolean> => {
    const isFlagActive = await fetchUserKamFlag();
    if (!isFlagActive) return true;

    const clienteId = Number(selectedOrderSummary?.clienteId);
    const [kamUsers, isKeyAccountCustomer] = await Promise.all([
      fetchKamUsers(),
      fetchIsKeyAccountCustomer(clienteId),
    ]);

    const employeeId = String(userAuth?.employeeId ?? '');
    const isUserKam = kamUsers.has(employeeId);

    if (isKeyAccountCustomer && !isUserKam) {
      showSnackbar(NOTIFICATIONS_CUSTOMER.CUSTOMER.KEY_ACCOUNT_KAM_ONLY, "warning");
      return false;
    }

    return true;
  };

  /**
   * Handles the click event for the quotation button.
   *
   * - Validates KAM permission for key-account customers.
   * - Checks if special codes and special prices are not accepted by calling `SpecialCodeAndSpecialPriceNotAcepted`.
   * - If not accepted, the function returns early and does nothing.
   * - Otherwise, proceeds to handle the quotation button action by calling `handleBtnQuoation`.
   */
  const handleClickQuotation = async () => {
    if (!(await validateKamPermissionForKeyAccount())) return;

    const pedidoId = Number(selectedOrderSummary?.pedidoID);
    const hasActiveKms = Object.values(selectedCustomer?.ordersKms?.[pedidoId]?.products || {})
      .some(product => product.isActiveKms === true);
    if (!!hasActiveKms) {
      showSnackbar("Los productos con Kms deben ser desmarcados", 'warning');
      return;
    }
    if (SpecialCodeAndSpecialPriceNotAcepted()) return;

    if (hasTrackingData()) {
      if (handleBtnQuoation) handleBtnQuoation();
      return;
    }

    setContinueAction("quotation");
    setOpenTrackingModal(true);
  };

  const validateRememberSMC4 = async () => {
    //validations for smc3 before continuing to shipment
    if (!userAuth?.engineSMC4) {
      const nextShowDate = getSMC4NextShowDate();
      if (!!objectEngineSMC4.length && (nextShowDate === null || nextShowDate <= new Date())) {
        setOpenModalRemember(true)
        return
      }
    }
    btnContinue();
  }

  /**
   * validate before continuing to Shipment
   *
   * @async
   * @returns {*}
   */
  const btnContinue = async (engineSMC4Activated?: boolean) => {
    if (!(await validateKamPermissionForKeyAccount())) return;

    const pedidoId = Number(selectedOrderSummary?.pedidoID);
    const orderKms = selectedCustomer?.ordersKms?.[pedidoId];

    if (
      orderKms &&
      orderKms.kmsInUsePerOrder != null &&
      orderKms.kmsInUsePerOrder > 0 &&
      orderKms.kmsInUsePerOrder < 100
    ) {
      showSnackbar(
        "La cantidad mínima para pagar con KMs es de 100. Ajusta el monto aplicado e inténtalo nuevamente.",
        "error"
      );
      return;
    }


    if (
      selectedCustomer?.kmsInUse != null &&
      selectedCustomer.kmsInUse > selectedCustomer.kmsForUse
    ) {
      showSnackbar(
        "Se están usando más Kms para pagar que puntos disponibles, favor de verificar los pedidos",
        "error"
      );
      return;
    }

    
  if (selectedOrderSummary && orderKms && orderKms.kmsInUsePerOrder) {
    dispatch(setTotalAfterKms({
      clientId: String(selectedOrderSummary.clienteId),
      orderId: String(selectedOrderSummary.pedidoID),
      totalValueOfOrder: selectedOrderSummary.total ?? 0,
    }));
  }


    if (SpecialCodeAndSpecialPriceNotAcepted()) return;

    if (hasTrackingData()) {
      await continueAsOrder(engineSMC4Activated);
      return;
    }

    setContinueAction("order");
    setOpenTrackingModal(true);
  };

  /**
 * Continues to shipment flow after required validations are completed.
 * @param {boolean} [engineSMC4Activated] - Parámetro opcional heredado de main para forzar la activación del motor.
 */
const continueAsOrder = async (engineSMC4Activated?: boolean) => {
  const pedidoId = selectedOrderSummary?.pedidoID ?? 0;
  const stepShipment = shipmentsSteps[pedidoId]?.activeStep ?? null;
  const engineActivated = engineSMC4Activated ?? engineSMC4ForOrder;

  if (isBlocked) {
    if (engineActivated) {
      // Si el origen del pedido es externo se consulta el status de la liga pago del pedido y obtener el metodo de pago.
      const pedidoIdExterno = Number(selectedOrderSummary?.pedidoIdExterno);
      const origenId = Number(selectedOrderSummary?.origenExternoId);
      const linkStatus = await getLinkStatus([pedidoIdExterno], origenId ?? 16);
      
      let cardTxt = ConcessionsEnum.credito.toString();
      let metodoPago = FormaPagoEnum.TarjetaCredito;
      
      if (linkStatus.data && linkStatus.data.length > 0) {
        if (linkStatus.data[0].esDebito) {
          cardTxt = ConcessionsEnum.debito.toString();
          metodoPago = FormaPagoEnum.TarjetaDebito;
        }
      }

      dispatch(
        setOrderShipmentSMC4({
          pedidoID: pedidoId,
          PUE: false,
          consecion: {
            concesionId: 15,
            concesion: "Contado",
            plazo: 0,
            status: true,
          },
          FormaPago: {
            metodoPagoId: metodoPago,
            metodoPago: cardTxt,
            status: true,
          },
          FormaPagoId: metodoPago,
        })
      );
    }

    dispatch(
      setActiveStep({
        pedidoId: pedidoId,
        activeStep: ShipmentSteps.SendMethod,
      })
    );
    redirect(PATH_PAGE.checkout.shipment.root);
  }

  if (stepShipment !== null && engineActivated) {
    if (stepShipment !== ShipmentSteps.PaymentMethod) {
      dispatch(handleInfoShippingChangeThunk("isPreviewMiniCheckouts", false, pedidoId));
      dispatch(resetSummarySMC4Thunk());
    }
    if (stepShipment === ShipmentSteps.Summary) {
      handleStepsMC();
    }
  }

  if (stepShipment !== null && stepShipment === ShipmentSteps.Summary) {
    const dataCustomer = await fetchCustomerInformationAction(
      showSnackbar,
      selectedOrderSummary?.clienteVendedorId!
    );
    if (dataCustomer?.AplicaClienteSMC) {
      DeleteUnshippedMiniCheckouts(
        pedidoId,
        showSnackbar,
        handleStepsMC
      );
      return;
    }
  }

  // validate if all products are exclusive for pickup
  if (engineActivated) {
    if (allProductsIsExclusivePickup()) return;
  }

  redirect(PATH_PAGE.checkout.shipment.root);
};

  /**
   * Delete the mini checkouts and return it one step
   *
   * @async
   * @returns {*}
   */
  const handleStepsMC = async () => {
    dispatch(
      setActiveStep({
        pedidoId: selectedOrderSummary!.pedidoID,
        activeStep: isBlocked ? ShipmentSteps.SendMethod : ShipmentSteps.PaymentMethod

      })
    );
    // validate if all products are exclusive for pickup
    if (engineSMC4ForOrder) {
      if (allProductsIsExclusivePickup()) return;
    }
    redirect(PATH_PAGE.checkout.shipment.root);
  };

  /**
 * Checks if all products in the order are exclusive pickup items.
 * If all items are pickup-only, opens the exclusive pickup modal.
 * 
 * @returns {boolean} Returns `true` if all products are pickup-only and the modal is opened, 
 * otherwise returns `false`.
 */
  const allProductsIsExclusivePickup = () => {
    const allPickup = allProductsPickup(selectedOrderSummary?.detalles ?? []);
    if (allPickup) {
      setOpenModalPickupExclusive(true);
      return true;
    }
    return false;
  }


  const selectedCustomer =
    dataCustomer[Number(selectedOrderSummary?.clienteId)];

  /**
   * Fetches product IDs associated with a generic TLC family
   * and updates the `setSpecialCodes` state with those IDs.
   *
   * This function performs an asynchronous request to the `GetIdsProductsByFamily` service
   * using the `FamilyIdGenericTlcProduct` identifier. The response is then handled using
   * `handleRequestDto`, which shows a snackbar on error and updates the state upon success.
   *
   * @async
   * @function fetchCodes
   * @returns {Promise<void>} A promise that resolves when the process completes.
   */
  const fetchCodes = async () => {
    const response = await GetIdsProductsByFamily(FamilyIdGenericTlcProduct);
    handleRequestDto({
      response,
      snackBar: showSnackbar,
      onSuccess: () => {
        setSpecialCodes(response.data?.map((p) => p.productoId) ?? []);
      },
      messages: {
        error: GENERIC_ERROR_MESSAGE_CAE,
      },
    });
  };

  /**
   * Fetches the engine object for SMC4 and updates the `setObjectEngineSMC4` state.
   *
   * This function performs an asynchronous request to the `fetchObject` service
   * using the `EngineSMCEnum.SMC4` identifier and stores the result in the component state.
   *
   * @async
   * @function fetchObjectEngineSMC4
   * @returns {Promise<void>} A promise that resolves when the process completes.
   */
  const fetchObjectEngineSMC4 = async () => {
    const response = await fetchObject(EngineSMCEnum.SMC4);
    setObjectEngineSMC4(response);
  }

  useEffect(() => {
    fetchCodes();
    fetchObjectEngineSMC4();
  }, []);

  /**
   * Activates the SMC4 engine flow by closing the reminder modal,
   * resetting the active step, and continuing the checkout process.
   *
   * @async
   * @function activeEngineSMC4
   * @returns {Promise<void>} A promise that resolves when the activation process completes.
   */
  const activeEngineSMC4 = async () => {
    setOpenModalRemember(false);
    dispatch(setResetSteps());
    btnContinue(true);
  }

  /**
   * Closes the SMC4 reminder modal, sets the next show date, and continues the checkout process.
   *
   * @function closeModalRemember
   * @returns {void}
   */
  const closeModalRemember = () => {
    setSMC4NextShowDate();
    setOpenModalRemember(false);
    btnContinue();
  }

  return (
    <Fragment>
      {(openModalPickupExclusive && engineSMC4ForOrder) && <ModalAllExlusivePickup
        openModal={openModalPickupExclusive}
        onClose={() => setOpenModalPickupExclusive(false)}
        onSave={() => redirect(PATH_PAGE.checkout.shipment.root)}
      />}
      <OrderTrackingModal
        openModal={openTrackingModal}
        continueAction={continueAction}
        selectedOrderSummary={selectedOrderSummary}
        onClose={() => {
          setOpenTrackingModal(false);
          setContinueAction(null);
        }}
        onContinueQuotation={() => {
          if (handleBtnQuoation) handleBtnQuoation();
        }}
        onContinueOrder={continueAsOrder}
      />
      <ModalRememberSMC4
        open={openModalRemember}
        onClose={closeModalRemember}
        onActivate={activeEngineSMC4}
      />
      <SummaryFooter
        subtotal={formattedSubtotalSinIva}
        descuento={formattedDescuento}
        iva={formattedIVA}
        total={formattedSubtotal}
        kmsMoney={fortmattedKms}
        Children={
          <>
            <Button
              variant="contained"
              size="medium"
              disabled={
                (selectedOrderSummary?.detalles ? selectedOrderSummary.detalles.length === 0 : true) || isBlocked
              }
              sx={{
                background: ColorsEpico.ColorDodgerBlue,
                borderRadius: 1.5,
                fontSize: FontSizesEnum.Delta,
                fontWeight: FontWeightEnum.Medium,
                // 3.5 son 28px por lado que no encogen: con los dos botones en una
                // fila sin envolver, en pantallas angostas el segundo se salía.
                px: { xs: 1.25, md: 3.5 },
                minWidth: { md: "12.5rem" },
              }}
              onClick={handleClickQuotation}
            >
              Cotización
            </Button>
            <Button
              variant="contained"
              size="small"
              type="submit"
              disabled={disableBtnContinue || loading}
              sx={{
                borderRadius: 1.5,
                fontSize: FontSizesEnum.Delta,
                fontWeight: FontWeightEnum.Medium,
                px: { xs: 1.25, md: 3.5 },
              }}
              onClick={validateRememberSMC4}
            >
              Continuar como pedido
            </Button>
          </>
        }
      ></SummaryFooter>
    </Fragment>
  );
};
