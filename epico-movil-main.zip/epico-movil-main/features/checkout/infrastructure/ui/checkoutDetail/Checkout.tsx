"use client";

import { useEffect, useState, useRef } from "react";
import { Box, Grid2 } from "@mui/material";
import { useBreadcrumb } from "@/features/common/infrastructure/hooks/useBreadcrumb";
import { BREAD_CRUMBS } from "@/features/checkout/infrastructure/ui/Checkout.data";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import {
  useAppDispatch,
  useAppSelector,
} from "@/features/common/application/redux/hooks";
import { IBranchesState } from "@/features/branch/domain/interfaces/branch/IBranchState";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { CheckoutDetailFooter } from "@/features/checkout/infrastructure/ui/checkoutDetail/CheckoutDetailFooter";
import { TableDetailArticles } from "@/features/checkout/infrastructure/ui/checkoutDetail/TableDetailArticles";
import { HeaderDetail } from "@/features/checkout/infrastructure/ui/checkoutDetail/CheckoutDetailHeader";
import { ConfirmQuoation } from "@/features/quotation/infraestructure/ui/confirmQuotation/ConfirmQuotation";
import { QuotationSummary } from "@/features/quotation/infraestructure/ui/quotationSummary/QuotationSummary";
import useZoom from "@/features/common/infrastructure/hooks/useZoom";
import {
  setOnSelectCheckOutThunk,
  updateOrderSummaryDetail,
} from "@/features/checkout/application/redux/checkOutThunks";
import { PATH_PAGE } from "@/routes/paths";
import { useRouter } from "next/navigation";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { NOTIFICATIONS_CHECKOUT } from "@/features/checkout/infrastructure/utils/messages/NotificationsCheckout";
import { ProductService } from "@/features/products/application/service/product.services";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { CreateOrUpdateOrderSummaryDetail } from "@/features/checkout/infrastructure/db/OrderSummaryDetailsRepository";
import { fetchCustomerApplySMC } from "@/features/customer/application/actions/fetchCustomerApplySMC";
import { shipmentMiniCheckout } from "@/features/checkout/application/actions/shipmentMiniCheckout";
import { openPayCheckout } from "@/features/checkout/application/actions/openPayCheckout";
import { setActiveStep } from "@/features/shipment/application/redux/ShipmentSlice";
import { ShipmentSteps } from "@/features/shipment/domain/enum/ShipmentSteps";
import { fetchLoyaltyPlanThunk } from "@/features/loyaltyPlan/application/redux/loyaltyPlanThunk";
import { StatusOrderEnum } from "@/features/checkout/domain/enums/StatusOrderEnum";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
/**
 * Checkout view component that displays the checkout details and handles quotation functionality.
 *
 * This component renders:
 * - A quotation summary modal when an order is selected
 * - A confirmation modal for quotations
 * - Header with checkout details
 * - Table showing article details
 * - Footer with checkout actions
 *
 * The component manages state for:
 * - Opening/closing quotation confirmation modal
 * - Opening/closing quotation summary modal
 * - Selected order summary from redux store
 * - Branch list from redux store
 *
 * @component
 * @returns {JSX.Element} The checkout view component
 */
export const CheckoutView = () => {
  const [openConfirmQuotation, setQuotation] = useState<boolean>(false);
  const [openQuotation, setOpenQuotation] = useState<boolean>(false);
  const { selectedOrderSummary, loading, checkOutList }: ICheckOutState =
    useAppSelector((state) => state.sessionState.checkOutsState);
  const { branchesList }: IBranchesState = useAppSelector(
    (state) => state.sessionState.branchesState
  );
  const userAuthState = useAppSelector((state) => state.localState.authState);
  const [apiError, setApiError] = useState(false);

  /**
   * Hook to manage breadcrumb navigation
   */
  const { MIN_RESOLUTION, isCurrentWidthScreen } = useZoom();
  const { setBreadcrumb } = useBreadcrumb();
  const { getDeniedProducts } = ProductService();
  const { showSnackbar } = useSnackbar();
  const dispatch = useAppDispatch();
  const router = useRouter();

  /**
   * Effect hook that sets the breadcrumb navigation on component mount
   *
   * @effect
   * @listens []
   */
  useEffect(() => {
    setBreadcrumb(BREAD_CRUMBS);
    dispatch(setOnSelectCheckOutThunk(() => { }));
  }, []);

  useEffect(() => {
    if (checkOutList.length === 0 && !loading)
      router.replace(PATH_PAGE.clientes.root);
  }, [loading]);

  useEffect(() => {
    if (!loading) initDeniedProducts();
  }, [
    selectedOrderSummary?.pedidoID,
    selectedOrderSummary?.sucursalIdDestino,
    selectedOrderSummary?.detalles?.length,
  ]);


  
useEffect(() => {
}, [selectedOrderSummary]);

  /**
   *
   */

  useEffect(() => {
    if (selectedOrderSummary?.clienteId) {
      dispatch(
        fetchLoyaltyPlanThunk(
          String(selectedOrderSummary.clienteId),
          showSnackbar
        )
      );
    }
  }, [selectedOrderSummary?.clienteId]);

  const hasShownBlockedMessage = useRef(false);
  const isBlocked = selectedOrderSummary?.estatusInternoId === StatusOrderEnum.OpenPay && selectedOrderSummary?.origenExternoId === OrigenEnum.Web;
  /**
   * Effect para mostrar el toast en caso de que el pedido esté pagado
   */
  useEffect(() => {
    if (isBlocked && !hasShownBlockedMessage.current) {
      showSnackbar(NOTIFICATIONS_CHECKOUT.OPEN_PAY.DISABLED, 'warning');
      hasShownBlockedMessage.current = true;
    }

    if (!isBlocked) {
      hasShownBlockedMessage.current = false;
    }
  }, [isBlocked]);
  /**
   * Initializes and processes denied products for the current order summary.
   * This function performs several key operations:
   * 1. Checks if there is a valid order summary with a destination branch
   * 2. Sets up SMC client application and handles order status
   * 3. Fetches denied products from the server for the current order
   * 4. Processes the denied products to:
   *    - Mark products as denied in the order details
   *    - Clear stock information for denied products
   *    - Update both Redux store and database with denied product status
   *
   * The function maintains two separate lists:
   * - updatedProducts: Products marked as denied for Redux store
   * - updatedNonStockProducts: Products with cleared stock info for database
   *
   * @async
   * @function
   * @throws {Error} If there's an error fetching or processing denied products
   */
  const initDeniedProducts = async () => {
    if (selectedOrderSummary && selectedOrderSummary.sucursalIdDestino) {
      setApplyClientSMC();
      hanldeStatusOrder();

      if (!userAuthState?.userAuth?.engineSMC4) {
        const DeniedProducts = await getDeniedProducts(
          selectedOrderSummary.sucursalIdDestino,
          selectedOrderSummary.pedidoID
        );

        handleRequestDto({
          response: DeniedProducts,
          snackBar: showSnackbar,
          messages: {
            error: NOTIFICATIONS_CHECKOUT.PRODUCT.FETCH_ERROR,
          },
          onSuccess: async () => {
            const { updatedProducts, updatedNonStockProducts } =
              DeniedProducts.data?.reduce(
                (
                  acc: {
                    updatedProducts: IOrderSummaryDetail[];
                    updatedNonStockProducts: IOrderSummaryDetail[];
                  },
                  denied
                ) => {
                  const product = selectedOrderSummary.detalles?.filter(
                    (product) => product.producto === denied.codigo
                  );

                  if (product) {
                    product.map((currentProduct) => {
                      const updatedProduct: IOrderSummaryDetail = {
                        ...currentProduct,
                        productoNegado: true,
                      };
                      const updatedNonStockProduct: IOrderSummaryDetail = {
                        ...updatedProduct,
                        stockEnSucursal: undefined,
                        stockEnSMC: undefined,
                        stockNacional: undefined,
                      };
                      acc.updatedProducts.push(updatedProduct);
                      acc.updatedNonStockProducts.push(updatedNonStockProduct);
                    });
                  }
                  return acc;
                },
                { updatedProducts: [], updatedNonStockProducts: [] }
              ) || { updatedProducts: [], updatedNonStockProducts: [] };

            await dispatch(updateOrderSummaryDetail(updatedProducts));
            await CreateOrUpdateOrderSummaryDetail(updatedNonStockProducts);
          },
        });
      }
    }
  };

  /**
   * Applies SMC (Sistema de Manejo de Clientes) settings for the current customer.
   * Makes an API call to fetch and apply SMC configuration for the selected customer
   * based on their vendor ID and customer ID.
   *
   * @async
   * @function
   * @throws {Error} If there's an error applying the SMC configuration
   */
  const setApplyClientSMC = async () => {
    await fetchCustomerApplySMC(
      showSnackbar,
      selectedOrderSummary!.clienteVendedorId,
      selectedOrderSummary!.clienteId
    );
  };

  /**
   * Handles the order status and redirects to shipment summary if needed.
   * Checks if the current order status corresponds to either a shipment mini-checkout
   * or an OpenPay checkout. If either condition is true, updates the active step
   * to Summary and redirects to the shipment root page.
   *
   * @function
   * @returns {void}
   */
  const hanldeStatusOrder = () => {
    const checkoutActive = checkOutList.find((ck) => ck.active);
    if (
      Number(checkoutActive?.pedidoID.split("-")[1]) !==
      selectedOrderSummary?.pedidoID
    )
      return;

    if (
      shipmentMiniCheckout(selectedOrderSummary!.estatusID) ||
      openPayCheckout(selectedOrderSummary!.estatusID)
    ) {
      if (!isBlocked) {
      dispatch(
        setActiveStep({
          pedidoId: selectedOrderSummary!.pedidoID,
          activeStep: ShipmentSteps.Summary,
        })
      );

      router.push(PATH_PAGE.checkout.shipment.root);
    }

    }
  };

  /**
   * Handles opening/closing the quotation modal
   *
   * @param {boolean} value - Whether to open (true) or close (false) the modal
   */
  const confirmQuoation = (value: boolean) => {
    setOpenQuotation(value);
  };
  
  return (
    <div id="checkout-main-container">
      <Grid2 container>
        {selectedOrderSummary && (
          <QuotationSummary
            openModal={openQuotation}
            closeModal={() => setOpenQuotation(false)}
          />
        )}
        <ConfirmQuoation
          openConfirmQuotation={openConfirmQuotation}
          onCloseConfirm={() => setQuotation(false)}
          sucursalDestino={
            branchesList.find(
              (sucursal) =>
                sucursal.id == selectedOrderSummary?.sucursalIdDestino
            )?.sucursal ?? "N/A"
          }
          confirmQuoation={confirmQuoation}
          pedidoId={selectedOrderSummary?.pedidoID ?? 0}
        />
        <Grid2 size={{ xs: 12 }} m={3}>
          <HeaderDetail />
        </Grid2>
        <Grid2
          size={{ xs: 12 }}
          mx={{ xs: 1.5, md: 3 }}
          sx={{ marginBottom: "50px", paddingBottom: { xs: "170px", md: "70px" } }}
        >
          <TableDetailArticles />
        </Grid2>
        <Grid2
          size={{ xs: 12 }}
          sx={{ position: "fixed", zIndex: 99, marginBottom: "20px" }}
        >
          <Box
            sx={{
              position: "fixed",
              zIndex: 99,
              // En móvil ocupa todo el ancho del viewport (left/right 0) para no desbordarse;
              // en desktop conserva -webkit-fill-available para respetar el menú lateral.
              width: { xs: "100%", md: "-webkit-fill-available" },
              left: { xs: 0, md: "auto" },
              right: { xs: 0, md: "auto" },
              borderTop: `1.7px solid ${ColorsEpico.ColorLightBlueishGray}`,
              background: ColorsEpico.ColorWhite,
              // En móvil el footer se coloca por encima del submenú inferior (70px) + safe-area.
              bottom: { xs: "calc(70px + env(safe-area-inset-bottom))", md: 0 },
            }}
          >
            <CheckoutDetailFooter
              handleBtnQuoation={() => setQuotation(true)}
            />
          </Box>
        </Grid2>
      </Grid2>
    </div>
  );
};
