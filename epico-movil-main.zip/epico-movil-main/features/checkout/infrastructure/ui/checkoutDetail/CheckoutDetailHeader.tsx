// mui
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { ICustomerPriceList } from "@/features/checkout/domain/interfaces/ICustomerPriceList";
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks";
import { actionsAuth } from "@/features/auth/application/redux/authSlice";
import { getSMC4Preference, setSMC4Preference } from "@/features/common/infrastructure/utils/smc4Preference";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import {
  Box,
  Button,
  Stack,
  Typography,
  Skeleton,
  Grid2,
  Tooltip,
} from "@mui/material";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import { useEffect, useState } from "react";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { fetchCustomerListaPrecioIndexDB } from "@/features/customer/application/actions/fetchCustomerListaPrecioIndexDB";
import { CustomListLabel } from "@/features/common/infrastructure/ui/labels/customListLabel/CustomListLabel";
import { HeadBranch } from "@/features/branch/infrastructure/ui/headBranch/HeadBranch";
import { ProductCode } from "@/features/products/infrastructure/ui/productCode/ProductCode";
import { Error } from "@mui/icons-material";
import { ModalCustomerDetails } from "@/features/customer/infrastructure/ui/customerInfo/dialog/modalCustomerDetails/ModalCustomerDetails";
import ToggleSMC4 from "@/features/checkout/infrastructure/ui/smc4/toggleSMC4/ToggleSMC4";
import { fetchObject } from "@/features/common/application/action/fetchObject";
import { EngineSMCEnum } from "@/features/auth/domain/enums/securityProject/EngineSMCEnum";
import { ObjectResponse } from "@/features/auth/domain/interfaces/securityProject/objectResponse";
import { setResetSteps } from "@/features/shipment/application/redux/ShipmentSlice";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";

/**
 * HeaderDetail component: Contains the header section for the selected box detail.
 *
 * This component displays key information about the selected order/box including:
 * - Customer name and details
 * - Price list information
 * - Branch information
 * - Product search functionality
 *
 * The component manages:
 * - Loading states for price list data
 * - Customer price list fetching and display
 * - Integration with branch and product components
 *
 * @component
 * @returns {React.ReactElement} A React component for displaying order header details
 */
export const HeaderDetail = () => {
  //#region Redux
  const dispatch = useAppDispatch();
  const { selectedOrderSummary }: ICheckOutState = useAppSelector(
    (state) => state.sessionState.checkOutsState
  );
  const userAuth = useAppSelector((state) => state.localState.authState?.userAuth);
  //#endregion Redux
  //#region Hooks
  const { showSnackbar } = useSnackbar();
  //#endregion Hooks
  //#region States
  const [customerPriceList, setCustomerPriceList] =
    useState<ICustomerPriceList>();
  const [loading, setLoading] = useState<boolean>(true);
  const data = useAppSelector(
    (state) => state.sessionState.loyaltyPlanState.customers
  );
  const [openModalCustomerDetails, setOpenModalCustomerDetails] =
    useState<boolean>(false);
  const [objectEngineSMC4, setObjectEngineSMC4] = useState<ObjectResponse[]>([]);
  /** Panel de sucursal, existencias y botones del pedido, plegado en móvil. */
  const [opcionesAbiertas, setOpcionesAbiertas] = useState<boolean>(false);
  //#endregion States

  //#region Functions
  /**
   * Fetches the customer's price list information from IndexedDB.
   *
   * This function retrieves the price list data for the currently selected customer
   * by making a request to IndexedDB using the customer ID. If the request is successful
   * and returns data, it updates the component state with the first price list found.
   *
   * @async
   * @function fetchPriceListInfo
   * @returns {Promise<void>}
   */
  const fetchPriceListInfo = async () => {
    const request = await fetchCustomerListaPrecioIndexDB(
      selectedOrderSummary?.clienteId ?? 0
    );
    if (!request.hasError && request.rows > 0) {
      setCustomerPriceList(request.data.at(0));
    }
  };

  /**
   * Initializes the header component by fetching and setting up the price list data.
   *
   * This function handles the initialization process by:
   * 1. Setting the loading state to true while data is being fetched
   * 2. Calling fetchPriceListInfo to retrieve customer price list data
   * 3. Setting loading state back to false once data is loaded
   *
   * @async
   * @function initHead
   * @returns {Promise<void>}
   */
  const initHead = async () => {
    setLoading(true);
    await fetchPriceListInfo();
    setLoading(false);
  };

  useEffect(() => {
    initHead();
  }, [selectedOrderSummary?.clienteId]);

  useEffect(() => {
    fetchObject(EngineSMCEnum.SMC4)
      .then((result) => {
        setObjectEngineSMC4(result);
        if (!result.length && !userAuth?.permissionSMC4 && getSMC4Preference()) {
          setSMC4Preference(false);
          dispatch(actionsAuth.setEngineSMC4(false));
          dispatch(setResetSteps());
        }
      })
      .catch(() => {
        showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
      })
      ;
  }, [dispatch, userAuth]);

  return (
    <Box>
      <Stack
        direction={{ xs: "column", md: "row" }}
        spacing={{ xs: 2, md: 4 }}
        alignItems={{ xs: "flex-start", md: "center" }}
        justifyContent={"space-between"}
        width="100%">
        <Stack direction={{ xs: "column", md: "row" }} spacing={{ xs: 1, md: 4 }} alignItems={"start"}>
          <Stack direction={"row"} alignItems={"center"} spacing={0.5} useFlexGap flexWrap={{ xs: "wrap", md: "nowrap" }}>
            <Typography
              fontWeight={FontWeightEnum.Bold}
              fontSize={FontSizesEnum.Alpha}
              color={ColorsEpico.ColorDarkCharcoal}
              sx={{ textAlign: "left", maxWidth: "700px" }}
            >
              {selectedOrderSummary?.cliente ?? "N/A"}
            </Typography>
            <Typography
              fontWeight={FontWeightEnum.Bold}
              fontSize={FontSizesEnum.Alpha}
              color={ColorsEpico.ColorDarkCharcoal}
              sx={{ textAlign: "left", maxWidth: "700px" }}
            >
              ClienteId: {selectedOrderSummary?.clienteId ?? "N/A"}
            </Typography>
            <Tooltip
              arrow
              title={"Ver datos del cliente"}
              onClick={() => setOpenModalCustomerDetails(true)}
            >
              <Error
                sx={{
                  color: ColorsEpico.ColorNeutralGray,
                  fontSize: FontSizesEnum.Lambda,
                  "&:hover": {
                    color: ColorsEpico.ColorPrimary,
                    cursor: "pointer",
                  },
                }}
              />
            </Tooltip>
          </Stack>
          {customerPriceList &&
            (loading ? (
              <Stack direction={"row"} spacing={1}>
                <Skeleton variant="rounded" height={25} width={100} />
                <Skeleton variant="rounded" height={25} width={100} />
              </Stack>
            ) : (
              <Grid2 pt={"3px"}>
                <CustomListLabel customerPriceList={customerPriceList} />
              </Grid2>
            ))}
          {Boolean(
            data &&
            selectedOrderSummary &&
            data[selectedOrderSummary.clienteId]?.customerLoyaltyPlan != null &&
            data[selectedOrderSummary.clienteId]?.flagUp === true
          ) && (
              <Typography
                fontSize={FontSizesEnum.Beta}
                color={ColorsEpico.ColorDarkCharcoal}
                sx={{ textAlign: "left", maxWidth: "700px" }}
              >
                <Typography
                  component="span"
                  fontWeight={FontWeightEnum.Bold}
                  fontSize={FontSizesEnum.Beta}
                  sx={{ marginRight: "4px" }}
                >
                  Kms disponibles:
                </Typography>
                <Typography
                  component="span"
                  fontWeight={FontWeightEnum.Medium}
                  fontSize={FontSizesEnum.Delta}
                >
                  {(data?.[selectedOrderSummary?.clienteId ?? 0]
                    ?.customerLoyaltyPlan?.saldoPuntos ?? 0) -
                    Number(
                      data?.[selectedOrderSummary?.clienteId ?? 0]?.ordersKms?.[
                        selectedOrderSummary?.pedidoID ?? 0
                      ]?.kmsInUsePerOrder ?? 0
                    )}
                </Typography>
              </Typography>
            )}
        </Stack>
        {!!objectEngineSMC4.length && <ToggleSMC4 />}
      </Stack>
      <Stack gap={{ xs: 2, md: 2.5 }} mt={2.5}>
        {/* En móvil, sucursal, existencias y los cuatro botones de pedido son cinco
            controles apilados a lo ancho: se comen la primera pantalla y la lista de
            artículos empieza donde ya no se ve. Se pliegan detrás de un botón y se
            despliegan a petición. El panel se oculta con un breakpoint de CSS, no con el
            flag de móvil, para que el primer pintado no salte; y solo se oculta, así que
            HeadBranch se sigue montando y sus peticiones no cambian. */}
        <Button
          onClick={() => setOpcionesAbiertas((abierto) => !abierto)}
          aria-expanded={opcionesAbiertas}
          aria-controls="opciones-del-pedido"
          endIcon={opcionesAbiertas ? <ExpandLess /> : <ExpandMore />}
          sx={{
            display: { xs: "flex", md: "none" },
            justifyContent: "space-between",
            minHeight: "44px",
            borderRadius: 2,
            border: `1px solid ${ColorsEpico.ColorLightBlueishGray}`,
            color: ColorsEpico.ColorDarkCharcoal,
            fontSize: FontSizesEnum.Delta,
            fontWeight: FontWeightEnum.Medium,
            textTransform: "none",
          }}
        >
          Opciones del pedido
        </Button>
        <Box
          id="opciones-del-pedido"
          sx={{ display: { xs: opcionesAbiertas ? "block" : "none", md: "block" } }}
        >
          <HeadBranch />
        </Box>
        <ProductCode />
      </Stack>
      <ModalCustomerDetails
        open={openModalCustomerDetails}
        onClose={() => setOpenModalCustomerDetails(false)}
      />
    </Box>
  );
};
