/**
 * Props interface for the ModalAllExclusivePickup component.
 * 
 * @interface IModalAllExlusivePickupProps
 * @property {boolean} openModal - Determines whether the modal is visible or hidden.
 * @property {() => void} [onClose] - callback function triggered when the modal is closed.
 * @property {() => void} [onSave] - callback function triggered when the save action is performed.
 */
export interface IModalAllExlusivePickupProps {
    openModal: boolean;
    onClose: () => void;
    onSave: () => void;
}