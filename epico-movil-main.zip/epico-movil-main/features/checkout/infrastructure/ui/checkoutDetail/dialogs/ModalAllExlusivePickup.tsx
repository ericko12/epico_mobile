import { IModalAllExlusivePickupProps } from "@/features/checkout/infrastructure/ui/checkoutDetail/dialogs/ModalAllExlusivePickup.types"
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes"
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight"
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric"
import { Typography } from "@mui/material"

/**
 * Modal component that displays a warning message when all items in an order are exclusive for pickup.
 * 
 * @param {IModalAllExlusivePickupProps} props - The component props
 * @param {boolean} props.openModal - Controls the visibility of the modal
 * @param {function} props.onSave - Callback function triggered when the user clicks "Continuar" button
 * @param {function} props.onClose - Callback function triggered when the user clicks "Cancelar" button
 * 
 * @returns {JSX.Element} A modal dialog informing the user that the order is not eligible for home delivery
 */
export const ModalAllExlusivePickup: React.FC<IModalAllExlusivePickupProps> = ({
    openModal,
    onSave,
    onClose
}) => {
    return (
        <ModalGeneric
            openModal={openModal}
            titulo="Este pedido no es elegible para envío a domicilio"
            btnTextClose="Cancelar"
            btnTextSave="Continuar"
            onSave={onSave}
            onClose={onClose}
            borderModal={`2px solid ${ColorsEpico.ColorVibrantYellow} !important`}
        >
            <Typography
                fontSize={FontSizesEnum.Gamma}
                fontWeight={FontWeightEnum.Regular}
            >
                Todos los artículos del pedido son exclusivos para recolección en sucursal, por lo que no es posible procesarlo como envío a domicilio.
                Al continuar se seleccionará Pickup como método de entrega.
            </Typography>
        </ModalGeneric>
    )
}
