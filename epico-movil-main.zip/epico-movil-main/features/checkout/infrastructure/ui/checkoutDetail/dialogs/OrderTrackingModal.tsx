import { FC, useEffect, useState } from "react";
import { SelectChangeEvent, Stack, Typography } from "@mui/material";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric";
import { SelectLabel } from "@/features/common/infrastructure/ui/select/selectLabel/SelectLabel";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { ISelect } from "@/features/common/domain/interfaces/select/ISelect";
import {
  useAppDispatch,
} from "@/features/common/application/redux/hooks";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { ordersService } from "@/features/orders/application/services/order.services";
import {
  IOrderAttentionChannelCatalog,
  IOrderOriginatorCatalog,
} from "@/features/orders/domain/interfaces/IOrderTrackingCatalog";
import { handleRequestDto } from "@/features/common/application/handleRequestDto/handleRequestDto";
import { PatchOrderSummaryEnum } from "@/features/checkout/domain/enums/PatchCheckoutEnum";
import { UpdateOrderService } from "@/features/orders/application/actions/fetchOrdersAction";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";

export type ContinueAction = "quotation" | "order" | null;

const ORIGINADOR_STORAGE_KEY = "checkout:lastOriginadorId";
const MEDIO_ATENCION_STORAGE_KEY = "checkout:lastMedioAtencionId";

interface OrderTrackingModalProps {
  openModal: boolean;
  onClose: () => void;
  continueAction: ContinueAction;
  selectedOrderSummary: IOrderSummary | null;
  onContinueQuotation?: () => void;
  onContinueOrder: () => Promise<void> | void;
}

export const OrderTrackingModal: FC<OrderTrackingModalProps> = ({
  openModal,
  onClose,
  continueAction,
  selectedOrderSummary,
  onContinueQuotation,
  onContinueOrder,
}) => {
  const dispatch = useAppDispatch();
  const { showSnackbar } = useSnackbar();
  const { getOrderOriginators, getOrderAttentionChannels } = ordersService();

  const [savingTrackingData, setSavingTrackingData] = useState<boolean>(false);
  const [catalogsLoading, setCatalogsLoading] = useState<boolean>(false);
  const [originadorId, setOriginadorId] = useState<number | "">("");
  const [medioAtencionId, setMedioAtencionId] = useState<number | "">("");
  const [originadorError, setOriginadorError] = useState<boolean>(false);
  const [medioAtencionError, setMedioAtencionError] = useState<boolean>(false);
  const [originadoresOptions, setOriginadoresOptions] = useState<readonly ISelect[]>([]);
  const [mediosAtencionOptions, setMediosAtencionOptions] = useState<readonly ISelect[]>([]);

  const getStoredTrackingValue = (key: string): number | "" => {
    if (typeof window === "undefined") return "";
    const rawValue = window.localStorage.getItem(key);
    if (!rawValue) return "";
    const parsedValue = Number(rawValue);
    return Number.isNaN(parsedValue) || parsedValue <= 0 ? "" : parsedValue;
  };

  const persistTrackingValue = (key: string, value: number | "") => {
    if (typeof window === "undefined") return;
    if (value === "") {
      window.localStorage.removeItem(key);
      return;
    }
    window.localStorage.setItem(key, String(value));
  };

  useEffect(() => {
    const selectedOriginadorId = selectedOrderSummary?.originadorId ?? null;
    const selectedMedioAtencionId = selectedOrderSummary?.medioAtencionId ?? null;
    const defaultOriginadorId =
      selectedOriginadorId && selectedOriginadorId > 0
        ? selectedOriginadorId
        : getStoredTrackingValue(ORIGINADOR_STORAGE_KEY);
    const defaultMedioAtencionId =
      selectedMedioAtencionId && selectedMedioAtencionId > 0
        ? selectedMedioAtencionId
        : getStoredTrackingValue(MEDIO_ATENCION_STORAGE_KEY);

    setOriginadorId(defaultOriginadorId);
    setMedioAtencionId(defaultMedioAtencionId);
    setOriginadorError(false);
    setMedioAtencionError(false);
  }, [selectedOrderSummary?.pedidoID]);

  const fetchOrderTrackingCatalogs = async () => {
    setCatalogsLoading(true);
    try {
      const [originadoresResponse, mediosAtencionResponse] = await Promise.all([
        getOrderOriginators(),
        getOrderAttentionChannels(),
      ]);

      await handleRequestDto({
        response: originadoresResponse,
        snackBar: showSnackbar,
        messages: {
          error: "No fue posible recuperar el catálogo de originadores.",
          invalid: "No fue posible recuperar el catálogo de originadores.",
        },
        onSuccess: () => {
          const options: readonly ISelect[] =
            originadoresResponse.data
              ?.filter((item: IOrderOriginatorCatalog) => item.activo)
              .map((item: IOrderOriginatorCatalog) => ({
                value: item.idOriginador,
                label: item.descripcion,
              })) ?? [];
          setOriginadoresOptions(options);
        },
      });

      await handleRequestDto({
        response: mediosAtencionResponse,
        snackBar: showSnackbar,
        messages: {
          error: "No fue posible recuperar el catálogo de medios de atención.",
          invalid: "No fue posible recuperar el catálogo de medios de atención.",
        },
        onSuccess: () => {
          const options: readonly ISelect[] =
            mediosAtencionResponse.data
              ?.filter((item: IOrderAttentionChannelCatalog) => item.activo)
              .map((item: IOrderAttentionChannelCatalog) => ({
                value: item.idMedioAtencion,
                label: item.descripcion,
              })) ?? [];
          setMediosAtencionOptions(options);
        },
      });
    } finally {
      setCatalogsLoading(false);
    }
  };

  useEffect(() => {
    if (!openModal) return;
    fetchOrderTrackingCatalogs();
  }, [openModal]);

  const validateTrackingFields = (): boolean => {
    const hasOriginadorId = originadorId !== "";
    const hasMedioAtencionId = medioAtencionId !== "";

    setOriginadorError(!hasOriginadorId);
    setMedioAtencionError(!hasMedioAtencionId);

    if (!hasOriginadorId || !hasMedioAtencionId) {
      showSnackbar(
        "Debes capturar originador y medio de atención para continuar.",
        "warning"
      );
      return false;
    }

    return true;
  };

  const executeContinueAction = async () => {
    if (continueAction === "quotation") {
      if (onContinueQuotation) onContinueQuotation();
      return;
    }

    if (continueAction === "order") {
      await onContinueOrder();
    }
  };

  const saveTrackingData = async () => {
    if (!selectedOrderSummary) return;
    if (!validateTrackingFields()) return;

    setSavingTrackingData(true);
    try {
      await UpdateOrderService(
        selectedOrderSummary,
        [
          { name: PatchOrderSummaryEnum.originadorId, data: Number(originadorId) },
          { name: PatchOrderSummaryEnum.medioAtencionId, data: Number(medioAtencionId) },
        ],
        showSnackbar,
        dispatch
      );
      onClose();
      await executeContinueAction();
    } finally {
      setSavingTrackingData(false);
    }
  };

  return (
    <ModalGeneric
      openModal={openModal}
      onClose={onClose}
      onSave={saveTrackingData}
      titulo="Datos de cierre"
      btnTextSave="Continuar"
      btnTextClose="Cancelar"
      isLoading={savingTrackingData}
      btndisabledSave={savingTrackingData || catalogsLoading}
      btndisabledClose={savingTrackingData}
      maxWidth="md"
    >
      <Stack spacing={2} pt={0.5}>
        <Typography
          fontSize={FontSizesEnum.Gamma}
          color={ColorsEpico.ColorDarkCharcoal}
        >
          Captura originador y medio de atención para continuar con la cotización o pedido.
        </Typography>
        <SelectLabel
          label="Originador"
          name="originador"
          required
          loading={catalogsLoading}
          value={originadorId}
          error={originadorError}
          errorMessage="Campo obligatorio"
          onChange={(e: SelectChangeEvent<any>) => {
            const nextValue = e.target.value === "" ? "" : Number(e.target.value);
            setOriginadorId(nextValue);
            setOriginadorError(false);
            persistTrackingValue(ORIGINADOR_STORAGE_KEY, nextValue);
          }}
          selectProps={{
            options: originadoresOptions,
            placeHolder: "Selecciona un originador",
          }}
        />
        <SelectLabel
          label="Medio de atención"
          name="medioAtencion"
          required
          loading={catalogsLoading}
          value={medioAtencionId}
          error={medioAtencionError}
          errorMessage="Campo obligatorio"
          onChange={(e: SelectChangeEvent<any>) => {
            const nextValue = e.target.value === "" ? "" : Number(e.target.value);
            setMedioAtencionId(nextValue);
            setMedioAtencionError(false);
            persistTrackingValue(MEDIO_ATENCION_STORAGE_KEY, nextValue);
          }}
          selectProps={{
            options: mediosAtencionOptions,
            placeHolder: "Selecciona un medio de atención",
          }}
        />
      </Stack>
    </ModalGeneric>
  );
};
