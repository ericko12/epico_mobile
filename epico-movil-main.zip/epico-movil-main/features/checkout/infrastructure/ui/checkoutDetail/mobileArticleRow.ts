import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { PriceType } from "@/features/common/infrastructure/utils/priceUtils";

/**
 * Datos que necesita el renglón compacto de un artículo en la experiencia móvil del
 * detalle de la caja. La hoja de edición sigue mostrándolo todo; el renglón solo tiene
 * sitio para lo que hay que distinguir de un vistazo con 25 productos en la caja.
 *
 * @interface IMobileArticleRow
 */
export interface IMobileArticleRow {
    /** Descripción a mostrar: la del genérico gana sobre la de la fila. */
    descripcion: string;
    /** Importe con IVA que se cobra, ya descontado lo que se paga con Kms. */
    importe: number;
    /** Kms del artículo; solo se muestran cuando se están aplicando. */
    kms: number;
    /** El artículo se está pagando con Kms (total o parcialmente). */
    kmsAplicados: boolean;
    /** Se paga completo con Kms: el importe va tachado, como en la vista de hoy. */
    importeTachado: boolean;
    /** Distintivos que se pintan junto al código. */
    esRegalo: boolean;
    tienePromocion: boolean;
    tienePrecioEspecial: boolean;
    /** Lleva aplicado un mejor precio (precio final); en escritorio se marca con la insignia verde. */
    tieneMejorPrecio: boolean;
    esPickupExclusivo: boolean;
    /** Porcentaje de ahorro; 0 cuando no hay. */
    ahorro: number;
    /** La cantidad pedida supera la existencia: el renglón se marca en rojo. */
    existenciaInsuficiente: boolean;
}

/**
 * Entrada de {@link resolveMobileArticleRow}. Lo que hay que buscar en redux —el plan de
 * lealtad y la descripción del genérico— llega ya resuelto, para que esta función sea
 * pura y se pueda probar.
 *
 * @interface IMobileArticleRowInput
 */
export interface IMobileArticleRowInput {
    detail: IOrderSummaryDetail;
    /** Descripción del genérico ("Te lo consigo") si la hay. */
    descripcionGenerico?: string | null;
    engineSMC4: boolean;
    mostrarExistenciasSMC4: boolean;
    /** Las existencias nacionales todavía se están cargando. */
    pendingStockNational: boolean;
    /** `isActiveKms` del producto en el plan de lealtad. */
    kmsAplicados: boolean;
    /** `isPagoTotal` del producto en el plan de lealtad. */
    pagoTotalConKms: boolean;
    /** Importe ya recalculado cuando se pagan Kms (`valueProductAfterKms`). */
    importeConKms?: number;
    /** Kms que cuesta el artículo (`productKmsValues`). */
    kmsDelArticulo: number;
}

/**
 * Decide si la cantidad pedida supera la existencia. Es la misma regla que pinta de rojo
 * la fila del DataGrid en escritorio (`Stock-LessThanQuantity`): con SMC 4.0 manda la
 * existencia nacional —y solo cuando ya cargó—, y sin él la de sucursal o la de SMC.
 *
 * @param {IMobileArticleRowInput} input - Datos del artículo.
 * @returns {boolean} `true` si falta existencia para la cantidad pedida.
 */
const faltaExistencia = ({ detail, engineSMC4, mostrarExistenciasSMC4, pendingStockNational }: IMobileArticleRowInput): boolean => {
    if (engineSMC4) {
        if (!mostrarExistenciasSMC4 || pendingStockNational) return false;

        return detail.stockNacional === 0 || (detail.stockNacional as number) < detail.cantidad;
    }

    return detail.stockEnSucursal === 0
        || (detail.stockEnSucursal as number) < detail.cantidad
        || detail.stockEnSMC === 0
        || (detail.stockEnSMC as number) < detail.cantidad;
};

/**
 * Arma el modelo del renglón compacto a partir del artículo de la caja.
 *
 * ⚠️ Estos mismos datos se derivan en la hoja de edición (`TableDetailArticles.tsx`) y en
 * las columnas de escritorio. El acuerdo está fijado en
 * `__tests__/app/features/checkout/mobileArticleRow.test.ts`.
 *
 * @param {IMobileArticleRowInput} input - Artículo y datos ya resueltos de redux.
 * @returns {IMobileArticleRow} Modelo listo para pintar el renglón.
 */
export const resolveMobileArticleRow = (input: IMobileArticleRowInput): IMobileArticleRow => {
    const { detail, descripcionGenerico, kmsAplicados, pagoTotalConKms, importeConKms, kmsDelArticulo, engineSMC4 } = input;

    const importeTachado = kmsAplicados && pagoTotalConKms;
    const importe = kmsAplicados && pagoTotalConKms && importeConKms !== undefined
        ? importeConKms
        : detail.importeIVA ?? 0;

    return {
        descripcion: descripcionGenerico || detail.descripcion || "",
        importe,
        kms: kmsDelArticulo,
        kmsAplicados,
        importeTachado,
        esRegalo: detail.gratis === true,
        tienePromocion: (detail.promocionID ?? 0) !== 0,
        tienePrecioEspecial: (detail.precioEspecialId ?? 0) !== 0,
        tieneMejorPrecio: detail.tipoPrecio === PriceType.Final,
        esPickupExclusivo: Boolean(detail.pickUp) && engineSMC4,
        ahorro: Number(detail.ahorroPorcentaje ?? 0),
        existenciaInsuficiente: faltaExistencia(input),
    };
};
