import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { alpha, SxProps } from "@mui/material";

export const SxTableDetailArticles: SxProps = {
  maxHeight: "32rem",
  "& .MuiDataGrid-columnHeader": {
    height: "20px",
  },
  "& .MuiDataGrid-columnHeaderTitle": {
    whiteSpace: "normal",
    lineHeight: "1.2",
    wordBreak: "break-word",
    textAlign: "center",
  },
  "& .row-eliminado": {
    backgroundColor: alpha(ColorsEpico.ColorRedOpaque, 0.1),
    color: ColorsEpico.ColorBlack,
    "&:hover": {
      backgroundColor: alpha(ColorsEpico.ColorRedOpaque, 0.1),
    },
  },
  "& .row-editado": {
    backgroundColor: alpha(ColorsEpico.ColorGreenLush, 0.1),
    color: ColorsEpico.ColorBlack,
    "&:hover": {
      backgroundColor: alpha(ColorsEpico.ColorGreenLush, 0.1),
    },
  },
  "& .row-agregado": {
    backgroundColor: alpha(ColorsEpico.ColorBrightBlue5, 0.1),
    color: ColorsEpico.ColorBlack,
    "&:hover": {
      backgroundColor: alpha(ColorsEpico.ColorBrightBlue5, 0.1),
    },
  },
  "& .MuiDataGrid-virtualScrollerRenderZone": {
    rowGap: "1px",
  },
  "& .Stock-LessThanQuantity": {
    boxShadow: `0 0 0 2px ${ColorsEpico.ColorRedOpaque}`,
    borderRadius: "3px",
  },
};
