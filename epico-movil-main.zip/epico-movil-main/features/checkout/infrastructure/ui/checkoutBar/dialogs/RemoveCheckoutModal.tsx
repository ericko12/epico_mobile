import { ButtonLoading } from "@/features/common/infrastructure/ui/buttons/ButtonLoading/ButtonLoading"
import { Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, Typography } from "@mui/material"
import CloseIcon from '@mui/icons-material/Close';
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { RemoveCheckoutModalProps } from "./RemoveCheckoutModal.types";

/**
 * RemoveCheckoutModalProps component used to display a modal for updating the status of a role.
 *
 * @param {UpdateStatusRoleModalProps} props - Properties passed to the modal component.
 * @param {boolean} props.open - Indicates whether the modal is open or closed.
 * @param {() => void} props.onClose - Callback function to close the modal.
 * @param {string} props.title - The title of the modal.
 * @param {() => void} props.onSave - Callback function triggered when the save action is performed.
 * @param {boolean | undefined} props.loading - Indicates if a loading state is active (optional).
 *
 * @returns {JSX.Element} The RemoveCheckoutModalProps component.
 */
const RemoveCheckoutModal: React.FC<RemoveCheckoutModalProps> = ({ open, onClose, title, onSave, loading }) => {
    return (
        <Dialog
            open={open}
            onClose={onClose}
            fullWidth
            sx={{
                '& .MuiPaper-root': {
                    border: `2px solid ${ColorsEpico.ColorRedOpaque}`,
                },
            }}
        >
            <DialogTitle sx={{ fontSize: '18px', fontWeight: '600', padding: '10px 15px 0' }}>
                {title}
                <IconButton
                    onClick={onClose}
                    style={{ position: "absolute", right: 3, top: 7 }}
                >
                    <CloseIcon sx={{ color: ColorsEpico.ColorBlack }} />
                </IconButton>
            </DialogTitle>
            <DialogContent sx={{ padding: '0px 15px' }}>
                <Box component="div">
                    <Typography
                        sx={{
                            fontSize: FontSizesEnum.Gamma,
                            fontWeight: FontWeightEnum.Regular,
                            my: 1

                        }}
                    >
                        Si eliminas esta caja se perderá el pedido y los productos relacionados
                    </Typography>
                    <Typography
                        sx={{
                            fontSize: FontSizesEnum.Gamma,
                            fontWeight: FontWeightEnum.Medium,
                            mt: 1.5
                        }}
                    >
                        ¿Estás seguro de querer eliminarla?
                    </Typography>
                </Box>
            </DialogContent>
            <DialogActions
                sx={{
                    padding: '10px 15px',
                }}
            >
                <Button
                    onClick={onClose}
                    disabled={loading}
                    variant="outlined"
                    size="small"
                    sx={{
                        marginRight: '8px',
                        fontWeight: FontWeightEnum.Medium,
                        color: ColorsEpico.ColorDarkCharcoal,
                        borderColor: ColorsEpico.ColorGrayNeutral,
                        minWidth: "64px",
                        borderRadius: '4px',
                        height: '32px',
                        '&.Mui-disabled': {
                            opacity: .5,
                        },
                    }}
                >
                    <Typography
                        sx={{
                            lineHeight: 1.5,
                            fontWeight: '600',
                            fontSize: '16px',
                        }}
                    >
                        Cancelar
                    </Typography>
                </Button>
                <ButtonLoading
                    onClick={onSave}
                    variant="contained"
                    disabled={loading}
                    size="small"
                    sx={{
                        width: "6.35rem",
                        background: ColorsEpico.ColorRedOpaque,
                        fontWeight: FontWeightEnum.Medium,
                        borderRadius: '4px',
                        height: '32px',
                    }}
                    loading={loading}
                >
                    <Typography
                        sx={{
                            lineHeight: 1.5,
                            fontWeight: '600',
                            fontSize: '16px',
                        }}
                    >
                        Eliminar
                    </Typography>
                </ButtonLoading>
            </DialogActions>
        </Dialog>
    )
}

export default RemoveCheckoutModal
