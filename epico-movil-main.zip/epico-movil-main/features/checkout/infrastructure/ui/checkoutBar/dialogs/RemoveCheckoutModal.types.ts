/**
 * Props for the `UpdateStatusRoleModal` component.
 *
 * @interface RemoveCheckoutModalProps
 * @property {boolean} open - Indicates whether the modal is open.
 * @property {() => void} onClose - Callback function triggered when the modal is closed.
 * @property {() => void} onSave - Callback function triggered when the modal's save action is performed.
 * @property {string} title - Title of the modal.
 * @property {boolean} [loading] - Optional. Specifies if the modal is in a loading state.
 */
export interface RemoveCheckoutModalProps {
    open: boolean;
    onClose: () => void;
    onSave: () => void;
    title: string;
    loading?: boolean;
}