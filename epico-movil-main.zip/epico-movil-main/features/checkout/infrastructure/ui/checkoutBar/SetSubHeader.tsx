import { useBreadcrumb } from "@/features/common/infrastructure/hooks/useBreadcrumb";
import { Box, Grid2 } from "@mui/material";
import { CheckOutsSection } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CheckOutsSection";
import { headerContainerSx } from "@/features/checkout/infrastructure/ui/checkoutBar/SetSubheader.style";
import { SearchFilterCatalog } from "@/features/products/infrastructure/ui/searchFilterCatalog/SearchFilterCatalog";
import { NotificationExternalOrders } from "@/features/common/infrastructure/ui/notification/NotificationExternalOrders";
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";

/**
 * Export the SetSubheader component
 */
export const SetSubheader = () => {
    const { breadcrumbs } = useBreadcrumb();
    const sectionSelected = breadcrumbs[0];
    const { isMobile } = useWindowDimensions();
    // Define a function to select the subheader based on the section selected
    const subHeaderSelector = () => {
        if (!sectionSelected?.title) return null;

        const excludedTitles = [
            "Listado de cotizaciones",
            "Edición de cotizaciones",
            "Alta de clientes",
            "Alta Premia Expertos",
            "Listado de garantías y devoluciones",
            "Prospectos",
            "Pedidos",
            "Solicitar garantía o devolución",
            "Detalle pedido",
            "Estado de Cuenta",
            "Historial de Movimientos",
            "Método de pago",
            "Método de envío",
            "Resumen de la caja",
            "Revisión del pedido",
        ];
        if (breadcrumbs.some(x => excludedTitles.includes(x.title as string))) {
            return ([]);
        }

        const onlyChekout = [
            "Promociones"
        ]
        if (breadcrumbs.some(x => onlyChekout.includes(x.title as string))) {
            return ([<CheckOutsSection />]);
        }

        switch (sectionSelected.title) {
            case 'Clientes':
            case 'Promociones':
            case 'Clientes/Informacion':
            case 'Checkout':
                return ([<CheckOutsSection />])
            case 'Catálogo':
                return ([
                    <CheckOutsSection />,
                    <SearchFilterCatalog />
                ]);
        }
        return null;
    }

    // Return the Grid container with the subheader components
    return (
        <>
            {
                !isMobile &&
                (
                    <Box
                        sx={{
                            position: "relative",
                        }}
                    >
                        <NotificationExternalOrders />
                    </Box>
                )}
            {!!subHeaderSelector()?.length && (
                <Grid2 container spacing={2} sx={{
                    ...headerContainerSx, paddingBottom: '20px'
                }}>
                    {
                        subHeaderSelector()?.map((item, index) => {
                            return (
                                <Grid2 key={index + "BCR"} size={12}>
                                    {item}
                                </Grid2>
                            )
                        })
                    }
                </Grid2>
            )}
        </>
    )
}