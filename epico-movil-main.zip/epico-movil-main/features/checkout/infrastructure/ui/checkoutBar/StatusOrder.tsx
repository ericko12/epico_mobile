import { useEffect, useState } from "react";
import { StatusOrderOpenPayEnum } from "@/features/checkout/domain/enums/StatusOrderOpenPayEnum";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { PaidRounded } from "@mui/icons-material";
import { Typography } from "@mui/material";
import { IStatusOrderProps, StatusProps } from "@/features/checkout/infrastructure/ui/checkoutBar/StatusOrder.types";

/**
 * StatusOrder Component
 * Displays the payment status from Openpay.
 * 
 * @param {Props} props - The properties passed to the component.
 * @param {number} props.estatusId - The status ID of the payment.
 * @param {string} [props.pagados] - Optional string indicating the number of payments made.
 * @returns {ReactNode} - The rendered component.
 */
export const StatusOrder: React.FC<IStatusOrderProps> = ({ estatusId, pagados }) => {
    const [statusStyle, setStatusStyle] = useState<StatusProps>();
    const getStatusProps = () => {
        switch (estatusId) {
            case StatusOrderOpenPayEnum.Pendiente:
                return {
                    icon: "PaidRounded",
                    text: "Pago pendiente " + (pagados ? `(${pagados})` : ''),
                    color: ColorsEpico.ColorRed
                }
            case StatusOrderOpenPayEnum.Pagado:
                return {
                    icon: "PaidRounded",
                    text: "Pagado " + (pagados ? `(${pagados})` : ''),
                    color: ColorsEpico.ColorLimeGreen
                }
            case StatusOrderOpenPayEnum.Rechazado:
                return {
                    icon: "PaidRounded",
                    text: "Pago rechazado",
                    color: ColorsEpico.ColorRed
                }
            case StatusOrderOpenPayEnum.Cancelado:
                return {
                    icon: "PaidRounded",
                    text: "Liga cancelada",
                    color: ColorsEpico.ColorRed
                }
        }
    }
    useEffect(() => {
        setStatusStyle(getStatusProps());
    }, [])
    return (
        <>
            <PaidRounded
                sx={{
                    fontSize: FontSizesEnum.Omega,
                    mr: "3px",
                    color: statusStyle?.color
                }}
            />
            <Typography sx={{ fontSize: FontSizesEnum.Omega, color: statusStyle?.color }}>{statusStyle?.text}</Typography>
        </>
    )
}
