import { SxProps } from "@mui/material";

export const headerContainerSx: SxProps = {
    height: 'auto',
    display: 'block',
    background: 'white',
    paddingInline: '1.7rem',
    borderBottom: `1px #edf2f7 solid`,
}