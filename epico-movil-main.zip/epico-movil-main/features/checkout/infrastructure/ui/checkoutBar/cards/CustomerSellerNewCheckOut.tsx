import { Card, Grid2, Typography } from "@mui/material";
import { PATH_PAGE } from "@/routes/paths";
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import { redirect } from 'next/navigation';
import { Add } from "@mui/icons-material";
import { cardBasicCheckoutSx } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CheckOutsSection.style";

/**
 * Molecule: Returns the new checkout component.
 * 
 * @returns {ReactNode} The new checkout component.
 */
export const CustomerSellerNewCheckOut = () => {

    // This continues the process of creating a checkout.
    const newCheckOut = () => redirect(PATH_PAGE.clientes.root);

    return (
        <Card
            sx={cardBasicCheckoutSx}
            onClick={newCheckOut}
        >
            <Grid2 container justifyContent="center" py={2.5}>
                <Grid2 container justifyContent="space-between" width="70%">
                    <Grid2>
                        <Typography sx={{ fontSize: FontSizesEnum.Epsilon }}>NUEVA CAJA</Typography>
                    </Grid2>
                    <Grid2 sx={{ display: 'flex', alignItems: 'center' }}>
                        <Add sx={{ fontSize: FontSizesEnum.Gamma }} />
                    </Grid2>
                </Grid2>
            </Grid2>
        </Card>
    )
}
