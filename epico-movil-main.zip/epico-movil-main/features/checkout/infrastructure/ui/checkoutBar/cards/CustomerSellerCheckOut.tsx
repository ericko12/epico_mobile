import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { ICheckOut } from "@/features/checkout/domain/interfaces/checkOut/ICheckOut";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { GENERIC_ERROR_MESSAGE_CAE } from "@/features/common/infrastructure/utils/messages/generic";
import {
  removeCheckOutThunk,
  toggleActiveCheckOutThunk,
  onSelectCheckOut,
} from "@/features/checkout/application/redux/checkOutThunks";
import { PATH_PAGE } from "@/routes/paths";
import { AccessTimeFilled, Delete } from "@mui/icons-material";
import { Grid2, Button, Tooltip, Box, Card, Typography } from "@mui/material";
import { useState, useTransition } from "react";
import { StatusOrder } from "@/features/checkout/infrastructure/ui/checkoutBar/StatusOrder";
import { StatusOrderOpenPayEnum } from "@/features/checkout/domain/enums/StatusOrderOpenPayEnum";
import { getTimeElapsed } from "@/features/common/infrastructure/utils/getTimeElapsed";
import {
  cardBasicCheckoutActiveSx,
  cardBasicCheckoutSx,
} from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CheckOutsSection.style";
import RemoveCheckoutModal from "@/features/checkout/infrastructure/ui/checkoutBar/dialogs/RemoveCheckoutModal";
import { shipmentMiniCheckout } from "@/features/checkout/application/actions/shipmentMiniCheckout";
import { NOTIFICATIONS_SHIPMENT } from "@/features/common/infrastructure/utils/messages/notificationShipment";
import { searchCheckoutById } from "@/features/checkout/application/actions/searchCheckoutById";
import { fetchCustomerApplySMC } from "@/features/customer/application/actions/fetchCustomerApplySMC";
import { useRouter, usePathname } from "next/navigation";
import { checkoutServices } from "@/features/checkout/application/service/checkout.services";
import {
  useAppDispatch,
  useAppSelector,
} from "@/features/common/application/redux/hooks";
import { setTelemarketingLeadsList } from "@/features/teleMarketingLead/application/redux/telemarketingLeadSlice";
import { resetProductKms } from "@/features/loyaltyPlan/application/redux/loyaltyPlanSlice";

/**
 * Returns a checkout box.
 *
 * @param {Object} props - The component props.
 * @param {ICheckOut} props.CheckOut - The checkout object to be displayed.
 * @param {React.RefObject<boolean>} props.changeCheckoutRef - Ref to signal checkout change.
 *
 * @returns {React.ReactNode} - The rendered checkout box component.
 */
export const CustomerSellerCheckOut = ({
  CheckOut,
  changeCheckoutRef,
}: {
  CheckOut: ICheckOut;
  changeCheckoutRef: React.RefObject<boolean>;
}) => {
  //states
  const [modalDelete, setModalDelete] = useState(false);
  //api
  const { patchOrderById } = checkoutServices();
  // hooks
  const { showSnackbar } = useSnackbar();
  const pathname = usePathname();
  const router = useRouter();
  const [pendingDelete, startPendingDelete] = useTransition();
  //redux
  const dispatch = useAppDispatch();
  const CheckOuts: ICheckOutState = useAppSelector(
    (state) => state.sessionState.checkOutsState
  );
  const dataCustomer = useAppSelector(
    (state) => state.sessionState.loyaltyPlanState.customers
  );
  const { telemarketingLeads } = useAppSelector(
    (state) => state.localState.telemarketingLeadState
  );

  /**
   * Function to cancel an order by changing the EstatusInternoId to 2.
   *
   * @async
   * @param {number} pedidoID - The ID of the order to be canceled.
   * @returns {unknown} - The result of the cancellation operation.
   */
  const cancelOrder = async (pedidoID: number) => {
    return await patchOrderById(pedidoID, [
      {
        op: "replace",
        path: "/EstatusInternoId",
        value: 2,
      },
    ]);
  };



  /**
   * Function to call cancelOrder, remove the checkout from the state, and trigger a Snackbar.
   *
   * @async
   * @returns {Promise<void>} - The result of the operation.
   */
  const removeThisCheckOut = async (): Promise<void> => {
    startPendingDelete(async () => {
      try {
        //Validate that the order has not been sent in the main mini checkout
        const orderEvaluated: any = await searchCheckoutById(CheckOut.pedidoID);
        const pedidoKeySinVTL = String(CheckOut.pedidoID).replace(/^VTL-/, "");
        if (!orderEvaluated && CheckOut.pedidoID.startsWith("VTL")) {
          await dispatch(
            removeCheckOutThunk(CheckOut.pedidoID, CheckOuts.checkOutList, CheckOuts.selectedOrderSummary)
          );
          if (
            dataCustomer[CheckOut.clienteId]?.ordersKms[pedidoKeySinVTL] &&
            orderEvaluated.detalles
          ) {
            orderEvaluated.detalles.forEach((detalle: any) => {
              const productoKey = String(detalle.producto);
              const kmsActivos = dataCustomer[CheckOut?.clienteId ?? 0].ordersKms[pedidoKeySinVTL ?? 0].products[productoKey].isActiveKms ?? false;
              const kmsValue = dataCustomer[CheckOut?.clienteId ?? 0].ordersKms[pedidoKeySinVTL?? 0].products[productoKey]?.valueOfKms ?? 0;
              if (kmsActivos || kmsValue > 0) {

                dispatch(
                  resetProductKms({
                    clientId: String(CheckOut.clienteId),
                    orderId: pedidoKeySinVTL,
                    productoKey: productoKey,
                  })
                );
              }
            });
          }
          showSnackbar("LA CAJA SE HA ELIMINADO CON ÉXITO", "success");
          return;
        }
        if (
          CheckOut.clienteId ===
          Number(process.env.NEXT_PUBLIC_CLIENTE_MOSTRADOR) ||
          CheckOut.clienteId ===
          Number(process.env.NEXT_PUBLIC_CLIENTE_MOSTRADOR_CC)
        ) {
          // Remove the lead associated with this CheckOut.pedidoID and update the leads list
          const newLeadsList = telemarketingLeads.filter(
            (lead) => lead.checkoutId !== CheckOut.pedidoID
          );
          dispatch(setTelemarketingLeadsList(newLeadsList));
        }
        if (shipmentMiniCheckout(orderEvaluated.estatusID ?? 0)) {
          showSnackbar(
            NOTIFICATIONS_SHIPMENT.SMC.CHECKOUT_SEND.REMOVE_CHECKOUT_WARNING,
            "warning"
          );
          setModalDelete(false);
          return;
        }
        const pedidoKey = String(CheckOut.pedidoID).replace(/\D/g, "");
        if (
          dataCustomer?.[CheckOut.clienteId]
            ?.ordersKms?.[pedidoKey]
            ?.products &&
          orderEvaluated?.detalles
        ) {
          orderEvaluated.detalles.forEach((detalle: any) => {
            const productoKey = String(detalle.producto);
            const kmsActivos = dataCustomer[CheckOut?.clienteId ?? 0].ordersKms[pedidoKey ?? 0].products[productoKey]?.isActiveKms ?? false;
            const kmsValue =  dataCustomer[CheckOut?.clienteId ?? 0].ordersKms[pedidoKey ?? 0].products[productoKey]?.valueOfKms ?? 0;
            if (kmsActivos || kmsValue > 0) {
              dispatch(
                resetProductKms({
                  clientId: String(CheckOut.clienteId),
                  orderId: pedidoKey,
                  productoKey: productoKey,
                })
              );
            }
          });
        }
        const res =
          CheckOut.pedidoID.startsWith("ORD") &&
          (await cancelOrder(parseInt(CheckOut.pedidoID.split("-")[1])));
        if (res && res.huboError) throw new Error(res.error.mensaje);
        await dispatch(
          removeCheckOutThunk(CheckOut.pedidoID, CheckOuts.checkOutList, CheckOuts.selectedOrderSummary)
        );
        setModalDelete(false);
        showSnackbar("LA CAJA SE HA ELIMINADO CON ÉXITO", "success");
        switch (pathname) {
          case PATH_PAGE.checkout.root:
            CheckOuts.checkOutList.length <= 1 &&
              router.push(PATH_PAGE.clientes.root);
            break;
          case PATH_PAGE.catalago.root:
            router.push(PATH_PAGE.clientes.root);
          case PATH_PAGE.catalago.familias:
            router.push(PATH_PAGE.clientes.root);
          case PATH_PAGE.catalago.promociones:
            router.push(PATH_PAGE.clientes.root);
        }
      } catch (error) {
        setModalDelete(false);
        showSnackbar(GENERIC_ERROR_MESSAGE_CAE, "error");
      }
    });
  };

  /**
   * Function to set the order as active.
   *
   * @returns {Promise<void>} - The result of the operation.
   */
  const toggleActiveThisCheckOut = async () => {
    const orderEvaluated = await searchCheckoutById(CheckOut.pedidoID);
    if (!orderEvaluated && CheckOut.pedidoID.startsWith("VTL")) {
      await dispatch(
        removeCheckOutThunk(CheckOut.pedidoID, CheckOuts.checkOutList)
      );
      showSnackbar(
        `Se eliminó la caja, ya que su información no estaba disponible`,
        "warning"
      );
      return;
    }
    if(PATH_PAGE.catalago.root === pathname){
      sessionStorage.removeItem("catalogSourceFromMenu");
    }
    changeCheckoutRef.current = true;
    if (shipmentMiniCheckout(orderEvaluated.estatusID ?? 0))
      showSnackbar(
        NOTIFICATIONS_SHIPMENT.SMC.CHECKOUT_SEND.CHANGE_CHECKOUT_WARNING,
        "warning"
      );
    await fetchCustomerApplySMC(
      showSnackbar,
      CheckOut!.clienteVendedorId,
      CheckOut!.clienteId
    );
    await dispatch(toggleActiveCheckOutThunk(CheckOut.pedidoID));
    onSelectCheckOut();
  };

  return (
    <>
      <Card
        sx={{
          ...(CheckOut.active
            ? cardBasicCheckoutActiveSx
            : cardBasicCheckoutSx),
          ...(CheckOut.openPayStatus && {
            "&:hover": {
              boxShadow: "0px 6px 12px rgba(218, 226, 235, 0.7) !important",
              backgroundColor: ColorsEpico.ColorGraySmoke,
              transform: "scale(1.05)",
              border:
                "2px solid" +
                (CheckOut.openPayStatusId == StatusOrderOpenPayEnum.Pagado
                  ? ColorsEpico.ColorLimeGreen
                  : ColorsEpico.ColorRed),
            },
          }),
        }}
        onClick={toggleActiveThisCheckOut}
      >
        <Grid2 container>
          <Grid2
            container
            width="100%"
            justifyContent="space-between"
            alignItems="center"
          >
            <Grid2>
              <Typography
                sx={{
                  fontSize: FontSizesEnum.Epsilon,
                  fontWeight: FontWeightEnum.Medium,
                  color: ColorsEpico.ColorDarkCharcoal,
                }}
              >
                {CheckOut.pedidoID}
              </Typography>
            </Grid2>
            <Grid2>
              <Button
                onClick={(event) => {
                  event.stopPropagation();
                  setModalDelete(true);
                }}
                variant="text"
                sx={{
                  minWidth: "25px",
                  color: ColorsEpico.ColorDarkCharcoal,
                  m: 0,
                  mr: 0.3,
                  p: 0,
                  "&:hover": {
                    color: ColorsEpico.ColorRed,
                  },
                }}
              >
                {!CheckOut.openPayStatus && (
                  <Delete sx={{ fontSize: FontSizesEnum.Gamma }} />
                )}
              </Button>
            </Grid2>
          </Grid2>
          <Grid2 width="100%">
            <Tooltip
              title={CheckOut.cliente}
              disableHoverListener={!(CheckOut.cliente.length > 30)}
              disableInteractive
              arrow
            >
              <Box>
                <Typography
                  sx={{
                    fontSize: FontSizesEnum.Omega,
                    fontWeight: FontWeightEnum.Regular,
                    color: ColorsEpico.ColorGray,
                    whiteSpace: "nowrap",
                  }}
                >
                  {`${CheckOut.cliente.substring(0, 30)}${CheckOut.cliente.length > 30 ? "..." : ""
                    }`}
                </Typography>
              </Box>
            </Tooltip>
          </Grid2>
          <Grid2 container width="100%">
            <Grid2 size={8} display="flex" alignItems="center">
              {CheckOut.openPayStatus && (
                <StatusOrder estatusId={CheckOut.openPayStatusId ?? 0} pagados={CheckOut.pagados} />
              )}
            </Grid2>
            <Grid2  
              size={4}
              alignItems="center"
              justifyContent="end"
              display="flex"
            >
              <AccessTimeFilled
                sx={{ fontSize: FontSizesEnum.Delta, mr: "3px" }}
              />
              <Typography
                sx={{
                  fontSize: FontSizesEnum.Omega,
                  color: ColorsEpico.ColorGray,
                }}
              >
                {getTimeElapsed(new Date(CheckOut.ts))}
              </Typography>
            </Grid2>
          </Grid2>
        </Grid2>
      </Card>
      <RemoveCheckoutModal
        open={modalDelete}
        title={"ELIMINAR CAJA"}
        onClose={() => setModalDelete(false)}
        onSave={removeThisCheckOut}
        loading={pendingDelete}
      />
    </>
  );
};
