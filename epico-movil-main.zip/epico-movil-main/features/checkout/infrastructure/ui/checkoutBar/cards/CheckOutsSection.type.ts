/**
 * Interface: Properties for the CheckOutsSection component.
 * 
 * @property {boolean} [newCheckOut] - Indicates if a new checkout is being created.
 */
export interface CheckOutsSectionProp {
    newCheckOut: boolean,
}