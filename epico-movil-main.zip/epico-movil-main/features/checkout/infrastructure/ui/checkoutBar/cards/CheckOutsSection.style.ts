import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import { SxProps } from "@mui/material";

export const gridCheckoutSectionSx: SxProps = {
    justifyContent: 'start',
    paddingBottom: '15px',
    // Desktop (>=900px): rejilla que envuelve con scroll vertical
    maxHeight: { xs: 'none', md: '203px' },
    overflowY: { xs: 'hidden', md: 'auto' },
    // Móvil (<900px): carrusel horizontal con snap; las tarjetas no se encogen
    // para que "asome" la siguiente (indica que hay más a los lados)
    flexWrap: { xs: 'nowrap', md: 'wrap' },
    overflowX: { xs: 'auto', md: 'visible' },
    scrollSnapType: { xs: 'x mandatory', md: 'none' },
    '& > *': {
        flexShrink: { xs: 0, md: 1 },
        scrollSnapAlign: { xs: 'start', md: 'unset' },
    },
    // Barra de scroll delgada solo en móvil (= breakpoints.down('md')); en escritorio va la global de globals.css
    '@media (max-width:899.95px)': {
        '&::-webkit-scrollbar': { height: '6px' },
        '&::-webkit-scrollbar-thumb': {
            backgroundColor: ColorsEpico.ColorLightBlueishGray,
            borderRadius: '3px',
        },
    },
}

export const cardBasicCheckoutSx: SxProps = {
    cursor: 'pointer',
    padding: '7px 5px',
    border: `2px solid ${ColorsEpico.ColorGrayNeutral}`,
    boxShadow: `0px 4px 8px rgba(218, 226, 235, 0.5) !important`,
    borderRadius: '8px !important',
    margin: '7px',
    height: '80px !important',
    alignContent: 'space-around',
    alignItems: 'center',
    justifyContent: 'center',
    transform: 'scale(1)',
    transition: 'all 0.2s ease-in-out !important',
    '&:hover': {
        boxShadow: '0px 6px 12px rgba(218, 226, 235, 0.7) !important',
        backgroundColor: ColorsEpico.ColorGraySmoke,
        transform: 'scale(1.05)',
        cursor: 'pointer',
    }
}

export const cardBasicCheckoutActiveSx = {
    cursor: 'pointer',
    padding: '7px 5px',
    boxShadow: '0px 4px 8px rgba(218, 226, 235, 0.5) !important',
    borderRadius: '8px !important',
    margin: '7px',
    height: '80px !important',
    alignContent: 'space-around',
    alignItems: 'center',
    justifyContent: 'center',
    transform: 'scale(1)',
    transition: 'all 0.2s ease-in-out !important',
    border: `2px solid ${ColorsEpico.ColorSecondary}`,
    '&:hover': {
        boxShadow: `0px 6px 12px rgba(218, 226, 235, 0.7) !important`,
        backgroundColor: ColorsEpico.ColorGraySmoke,
        transform: 'scale(1.05)',
        cursor: 'pointer',
        border: `2px solid ${ColorsEpico.ColorSecondary}`,
    }
}