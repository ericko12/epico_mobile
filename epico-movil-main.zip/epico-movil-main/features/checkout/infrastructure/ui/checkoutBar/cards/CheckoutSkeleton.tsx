import { FontWeightEnum } from '@/features/common/domain/enums/FontWeight';
import { Card, Grid2, Skeleton, Typography } from "@mui/material";
import { cardBasicCheckoutSx } from './CheckOutsSection.style';

/**
 * Molecule: devuelve el skeleton de una caja
 * @returns ReactNode
*/
export const CheckoutSkeleton = () => {

    return (
        <Card sx={cardBasicCheckoutSx}>
            <Grid2 container width="100%">
                <Grid2 container width="100%" justifyContent="space-between" alignItems="center">
                    <Grid2>
                        <Typography sx={{ fontWeight: FontWeightEnum.Medium }}><Skeleton animation="wave" height={20} width={70} /></Typography>
                    </Grid2>
                    <Grid2 >
                        <Typography sx={{ fontWeight: FontWeightEnum.Medium }}><Skeleton animation="wave" height={20} width={70} /></Typography>
                    </Grid2>
                </Grid2>
                <Grid2 width="100%" >
                    <Typography sx={{ fontWeight: FontWeightEnum.Regular }}><Skeleton animation="wave" height={20} width={120} /></Typography>
                </Grid2>
                <Grid2 container width="100%" alignItems="center" justifyContent="end">
                    <Typography sx={{ fontWeight: FontWeightEnum.Regular, mr: "3px" }}><Skeleton animation="wave" height={18} width={15} /></Typography>
                    <Typography sx={{ fontWeight: FontWeightEnum.Regular }}><Skeleton animation="wave" height={18} width={25} /></Typography>
                </Grid2>
            </Grid2>
        </Card>
    )
}
