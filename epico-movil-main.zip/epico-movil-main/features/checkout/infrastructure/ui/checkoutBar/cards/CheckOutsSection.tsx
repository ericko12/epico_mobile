"use client";
import {
  useAppDispatch,
  useAppSelector,
} from "@/features/common/application/redux/hooks";
import { Box, Grid2 } from "@mui/material";
import { FC, useEffect, useRef, useState } from "react";
import { PATH_PAGE } from "@/routes/paths";
import { CustomerSellerNewCheckOut } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CustomerSellerNewCheckOut";
import { CheckoutSkeleton } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CheckoutSkeleton";
import { usePathname, useRouter } from "next/navigation";
import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";
import { ICheckOut } from "@/features/checkout/domain/interfaces/checkOut/ICheckOut";
import { fetchOrderSummariesAction } from "@/features/checkout/application/actions/fetchOrderSummariesAction";
import { CustomerSellerCheckOut } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CustomerSellerCheckOut";
import { gridCheckoutSectionSx } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CheckOutsSection.style";
import { CheckOutsSectionProp } from "@/features/checkout/infrastructure/ui/checkoutBar/cards/CheckOutsSection.type";
import { IAuth } from "@/features/auth/domain/interfaces/IAuth";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";
import {
  closeChannel,
  onMessage,
  openChannel,
  sendMessage,
} from "@/features/common/infrastructure/adapters/BroadcastChannelAdapter";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { setSelectedOrderSummaryThunk } from "@/features/checkout/application/redux/checkOutThunks";
import { BroadcastMessageType } from "@/features/common/domain/enums/broadCast/BroadcastMessageType";
import { BroadcastMessageState } from "@/features/common/domain/enums/broadCast/BroadcastMessageState";
import { setTelemarketingLeadsList } from "@/features/teleMarketingLead/application/redux/telemarketingLeadSlice";

/**
 * Functional component that displays the checkout section for customers and vendors.
 *
 * @returns {JSX.Element} - The JSX representation of the component.
 */
export const CheckOutsSection: FC<Partial<CheckOutsSectionProp>> = () => {
  //hooks
  const pathname = usePathname();
  const router = useRouter();
  const { showSnackbar } = useSnackbar();

  //refs
  const prevCheckOutsRef = useRef<ICheckOut[]>([]);
  const prevSummaryRef = useRef<IOrderSummary | null>(null);
  const pausedReloadRef = useRef(false);
  const firstRenderRef = useRef(true);
  const changeCheckoutRef = useRef(false);
  const channelCheckoutsRef = useRef<BroadcastChannel | null>(null);

  //redux
  const dispatch = useAppDispatch();
  const CheckOuts: ICheckOutState = useAppSelector(state => state.sessionState.checkOutsState);
  const userAuthState: IAuth = useAppSelector(state => state.localState.authState);
  const { telemarketingLeads } = useAppSelector(state => state.localState.telemarketingLeadState);
  const { tabId } = useAppSelector(state => state.sessionState.windowState);


  //states
  const [newCheckOut, setNewCheckOut] = useState(true);

  // Carrusel móvil: degradados indicadores sensibles al scroll
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const [showLeftFade, setShowLeftFade] = useState(false);
  const [showRightFade, setShowRightFade] = useState(false);

  /** Recalcula si hay más cajas hacia la izquierda o la derecha para mostrar el degradado. */
  const updateFades = () => {
    const el = scrollRef.current;
    if (!el) return;
    setShowLeftFade(el.scrollLeft > 4);
    setShowRightFade(el.scrollLeft < el.scrollWidth - el.clientWidth - 4);
  };

  useEffect(() => {
    pathname === PATH_PAGE.clientes.root
      ? setNewCheckOut(false)
      : setNewCheckOut(true);
  }, [pathname]);

  // Recalcula los degradados al montar, al hacer scroll, al cambiar el tamaño
  // o cuando cambia la lista de cajas.
  useEffect(() => {
    updateFades();
    const el = scrollRef.current;
    if (!el) return;
    el.addEventListener("scroll", updateFades, { passive: true });
    window.addEventListener("resize", updateFades);
    return () => {
      el.removeEventListener("scroll", updateFades);
      window.removeEventListener("resize", updateFades);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [CheckOuts.checkOutList.length, CheckOuts.loading, newCheckOut]);

  /**
   * Asynchronous function that retrieves and processes the order summaries of users.
   */
  const fetchOrderSummaries = async () => {
    await fetchOrderSummariesAction(
      dispatch,
      userAuthState,
      CheckOuts.selectedOrderSummary?.pedidoID
    );
  };

  /**
   * Asynchronous function that retrieves and processes the order summaries of the active checkout.
   */
  const fetchOrderSummariesByActiveCheckout = async () => {
    const indexCheckout = CheckOuts.checkOutList.filter(
      (ck: ICheckOut) => ck.active === true
    );
    const activeIdCheckout = indexCheckout[0]?.pedidoID?.split("-")[1] ?? 0;
    await fetchOrderSummariesAction(
      dispatch,
      userAuthState,
      Number(activeIdCheckout)
    );
  };

  useEffect(() => {
    fetchOrderSummaries();
    channelCheckoutsRef.current = openChannel("checkouts");

    return () => {
      if (channelCheckoutsRef.current) {
        channelCheckoutsRef.current.onmessage = null;
        closeChannel(channelCheckoutsRef.current);
      }
    };
  }, []);

  // Update checkouts
  useEffect(() => {
    if (!CheckOuts.loading) {
      firstRenderRef.current = false;
      prevCheckOutsRef.current = CheckOuts.checkOutList;
    }
  }, [CheckOuts.loading]);

  // Update selected order summary
  useEffect(() => {
    if (pausedReloadRef.current || firstRenderRef.current || CheckOuts.loading)
      return;
    const prevCheckOuts = prevCheckOutsRef.current;
    const currentCheckOuts = CheckOuts.checkOutList;
    const prev = prevSummaryRef.current;
    const current = CheckOuts.selectedOrderSummary;

    //check if checkOuts changed
    const agregados = currentCheckOuts.filter(
      (caja) => !prevCheckOuts.some((prev) => prev.pedidoID === caja.pedidoID)
    );

    const eliminados = prevCheckOuts.filter(
      (caja) =>
        !currentCheckOuts.some((curr) => curr.pedidoID === caja.pedidoID)
    );

    if ((agregados.length > 0 || eliminados.length > 0) && !changeCheckoutRef.current) {
      sendMessage(channelCheckoutsRef.current, {
        type: agregados.length > 0 ? BroadcastMessageType.SYNC : BroadcastMessageType.DELETE,
        value: {
          'checkOuts': {
            allCheckout: currentCheckOuts,
            modifiedCheckout: agregados.length > 0 ? agregados : eliminados,
            telemarketingLeads
          },
        },
        state: BroadcastMessageState.CHECKOUTS,
        path: pathname,
        sender: tabId,
        key: agregados.length > 0 ? agregados[0].pedidoID : eliminados[0].pedidoID,
        msg: `Hubo modificaciones en la barra de cajas`,
      });
      prevCheckOutsRef.current = currentCheckOuts;
      return;
    }

    function getChangedOrderSummaryKey(
      a: IOrderSummary,
      b: IOrderSummary
    ): string | undefined {
      for (const key of Object.keys(a)) {
        const k = key as keyof IOrderSummary;
        const valA = a[k];
        const valB = b[k];

        if (Array.isArray(valA) && Array.isArray(valB)) {
          if (valA.length !== valB.length) return key;
          if (
            !valA.every((v, i) => JSON.stringify(v) === JSON.stringify(valB[i]))
          )
            return key;
        } else if (valA !== valB) {
          return key;
        }
      }
      return undefined;
    }

    //check if selected order summary changed
    if (prev && current && !changeCheckoutRef.current) {
      let keys: string[] = [];
      const key = getChangedOrderSummaryKey(prev, current);
      if (key) keys.push(key);

      if (keys.length > 0) {
        sendMessage(channelCheckoutsRef.current, {
          type: BroadcastMessageType.SYNC,
          value: {
            selectedOrderSummary: current,
          },
          state: BroadcastMessageState.SELECTED_ORDER_SUMMARY,
          path: pathname,
          sender: tabId,
          key: keys.join(","),
          msg: `Se ha actualizado la caja`,
        });
      }
    }
    // Guardar el valor actual para la próxima comparación
    prevSummaryRef.current = CheckOuts.selectedOrderSummary;
    changeCheckoutRef.current = false;
  }, [
    CheckOuts.selectedOrderSummary,
    CheckOuts.selectedOrderSummary?.detalles?.length,
    CheckOuts.checkOutList.length,
  ]);

  /**
   * Handles incoming messages from the checkout broadcast channel.
   *
   * This asynchronous callback processes messages received via the checkout channel,
   * updating the order summaries or triggering UI changes based on the message type and state.
   *
   * @function
   * @param {any} msg - The message object received from the broadcast channel.
   * @returns {Promise<void>} Resolves when the message has been processed.
   */
  onMessage(channelCheckoutsRef.current, async (msg) => {
    if (!document.hidden) return;
    if (msg.sender === tabId || pausedReloadRef.current || CheckOuts.loading)
      return;
    pausedReloadRef.current = true;

    try {
      switch (msg.state) {
        case BroadcastMessageState.SELECTED_ORDER_SUMMARY:
          if (msg.value.selectedOrderSummary.pedidoID === CheckOuts.selectedOrderSummary?.pedidoID) {
            if (msg.type === BroadcastMessageType.UPDATE) {
              await fetchOrderSummariesByActiveCheckout();
            } else {
              await dispatch(setSelectedOrderSummaryThunk(msg.value.selectedOrderSummary));
              prevSummaryRef.current = msg.value.selectedOrderSummary;
            }
            showSnackbar(msg.msg, 'info');
          }
          break;
        case BroadcastMessageState.CHECKOUTS:
          switch (msg.type) {
            case BroadcastMessageType.SYNC:
            case BroadcastMessageType.DELETE:
              if (msg.value.checkOuts.modifiedCheckout[0].pedidoID.startsWith("VTL")) return;
              if (msg?.value?.checkOuts?.telemarketingLeads && msg?.value?.checkOuts?.telemarketingLeads?.length > 0) {
                dispatch(setTelemarketingLeadsList(msg.value.checkOuts.telemarketingLeads));
              }
              await fetchOrderSummariesByActiveCheckout();
              showSnackbar(msg.msg, 'info');
              break;
            case BroadcastMessageType.UPDATE:
              if (msg.value.checkOuts.selectedOrderSummary.pedidoID !== CheckOuts.selectedOrderSummary?.pedidoID) {
                await fetchOrderSummariesByActiveCheckout();
                showSnackbar(msg.msg, 'info');
                return;
              }
              switch (msg.value.checkOuts.estatusInternoId) {
                case 4:
                  if (pathname === PATH_PAGE.checkout.root) {
                    router.push(PATH_PAGE.clientes.cotizaciones(msg.value.checkOuts.selectedOrderSummary.clienteVendedorId.toString()));
                    break;
                  }
                  showSnackbar(msg.msg, 'info');
                  await fetchOrderSummariesByActiveCheckout();
                  break;
              }
              break;
          }
          break;
        case BroadcastMessageState.MINI_CHECKOUTS:
          switch (msg.type) {
            case BroadcastMessageType.UPDATE:
              await fetchOrderSummariesByActiveCheckout();
              showSnackbar(msg.msg, 'info');
              break;
          }
          break;
      }

    } catch (error) {
      console.log('error', error);
    }
    finally {
      pausedReloadRef.current = false;
    }
  });

  return (
    <Box sx={{ position: 'relative' }}>
      <Grid2 container ref={scrollRef} sx={gridCheckoutSectionSx}>
        {!CheckOuts.loading ? (
          <>
            {newCheckOut && (
              <Grid2 width="260px">
                <CustomerSellerNewCheckOut />
              </Grid2>
            )}
            {CheckOuts.checkOutList.map((CheckOut: ICheckOut) => {
              if (!CheckOut.origenExternoId) {
                return (
                  <Grid2 width="260px" key={CheckOut.pedidoID}>
                    <CustomerSellerCheckOut
                      CheckOut={CheckOut}
                      changeCheckoutRef={changeCheckoutRef}
                    />
                  </Grid2>
                );
              }
            })}
          </>
        ) : (
          <>
            <Grid2 width="260px">
              <CheckoutSkeleton />
            </Grid2>
            <Grid2 width="260px">
              <CheckoutSkeleton />
            </Grid2>
          </>
        )}
      </Grid2>
      {/* Indicadores de scroll (solo móvil): solo aparecen si hay más cajas hacia ese lado */}
      <Box sx={{ display: { xs: showRightFade ? 'block' : 'none', md: 'none' }, position: 'absolute', top: 0, right: 0, height: '100%', width: '28px', background: 'linear-gradient(to right, rgba(255,255,255,0), rgba(255,255,255,1))', pointerEvents: 'none' }} />
      <Box sx={{ display: { xs: showLeftFade ? 'block' : 'none', md: 'none' }, position: 'absolute', top: 0, left: 0, height: '100%', width: '28px', background: 'linear-gradient(to left, rgba(255,255,255,0), rgba(255,255,255,1))', pointerEvents: 'none' }} />
    </Box>
  );
};
