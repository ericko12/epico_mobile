import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico"

/**
 * Data type for OpenPay status component.
 * 
 * @property {number} estatusId - The status ID of the order.
 * @property {?string} [pagados] - Optional property indicating payment status.
 */
export interface IStatusOrderProps {
    estatusId: number
    pagados?: string;
}
/**
 * Properties used to identify the payment status.
 * 
 * @property {string} icon - The icon representing the status.
 * @property {string} text - The text describing the status.
 * @property {ColorsEpico} color - The color associated with the status.
 */
export interface StatusProps {
    icon: string,
    text: string,
    color: ColorsEpico
}