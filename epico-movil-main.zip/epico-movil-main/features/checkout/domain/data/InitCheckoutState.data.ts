import { ICheckOutState } from "@/features/checkout/domain/interfaces/checkOut/ICheckOutState";

/**
 * Initial state for the checkout feature
 */
export const InitCheckoutState: ICheckOutState = {
    error: null,
    loading: false,
    checkOutList: [],
    selectedOrderSummary: null,
    pageAuxiliarStates: {
        productCode: "",
        countProduct: 1
    },
    quotationState: {
        historialId: 0,
        readOnlyQuotation: false,
    }
};