import { IOrderDetail } from "@/features/checkout/domain/interfaces/IOrderDetail";

// default initial state for order detail
export const InitOrderDetail: IOrderDetail = {
    Gratis: false,
    Precio: 0,
    Cantidad: 0,
    ProductoId: 0,
    TieneToken: false,
    PrecioLista: 0,
    PcPromocionId: null,
    ComprarMasTarde: null,
    PrecioEspecialId: null,
    DescuentoAdicional: null,
    ProductoPaqueteria: null,
    TipoPrecio: 0,
};