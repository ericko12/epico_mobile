import { SwitchToSMC3ReasonEnum } from "@/features/checkout/domain/enums/SwitchToSMC3ReasonEnum";

/**
 * Local catalog of reasons for the "Procesar con SMC 3" modal.
 * Used only as fallback when GET /api/v4/SMC4/MotivosCambioFlujo fails or returns no content.
 * The ids must match VYM.Mto_Cat_SMC4_MotivosCambioFlujo.
 *
 * @type {{ id: SwitchToSMC3ReasonEnum; label: string }[]}
 */
export const SWITCH_TO_SMC3_REASONS: { id: SwitchToSMC3ReasonEnum; label: string }[] = [
    { id: SwitchToSMC3ReasonEnum.OPTIONS_TOO_FAR, label: "Las opciones mostradas están muy lejanas al cliente" },
    { id: SwitchToSMC3ReasonEnum.CUSTOMER_REQUESTS_OTHER_BRANCH, label: "El cliente pide que se le envíe de otra sucursal" },
    { id: SwitchToSMC3ReasonEnum.OTHER, label: "Otro" },
];

/**
 * Minimum number of words required in the observation field.
 *
 * @type {number}
 */
export const SWITCH_TO_SMC3_MIN_WORDS = 3;
