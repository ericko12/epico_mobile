export const CHECKOUT_MESSAGES = {
    autoTransferWarning: 'Este pedido genera traspasos automáticos por falta de existencia.',
    cannotSplitWithTransfers: 'No puedes dividir este pedido porque incluye traspasos entre sucursales.',
    includesTransfersWarning: 'Incluye traspasos por falta de existencia.',
} as const;
