import { ISpecialPriceStates } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPricesStates";

export const SpecialPriceStates: ISpecialPriceStates = {
    SinSolicitud: { index: 0, text: "Solicitar PE" },
    Solicitado: { index: 1, text: "En Revisión" },
    Aceptado: { index: 2, text: "Aprobado" },
    Rechazado: { index: 3, text: "Rechazado" },
    Cancelado: { index: 4, text: "Cancelado" },
    Negociado: { index: 5, text: "Negociado" },
};