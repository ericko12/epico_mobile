import { EngineDivisionEnum } from "@/features/checkout/domain/enums/EngineDivisionEnum";

/**
 * Interface: Model for Search and Filters for Client Listings.
 *
 * @interface ICheckOut
 * @typedef {ICheckOut}
 * 
 * @property {string} pedidoID - Unique identifier for the order.
 * @property {number} clienteVendedorId - The ID of the client seller.
 * @property {number} clienteId - The ID of the client.
 * @property {string} cliente - The name of the client.
 * @property {string} ts - Date and time of the order.
 * @property {boolean} active - Active status of the order.
 * @property {?number} [openPayStatusId] - ID of the OpenPay status (optional).
 * @property {?boolean} [openPayStatus] - OpenPay status (optional).
 * @property {?number} [origenExternoId] - ID of external origin (null).
 * @property {?string} [pagados] - Payment status or details (optional).
 * @property {?EngineDivisionEnum} [motorDivisionId] - Identifier for the division engine used in order processing.
 */
export interface ICheckOut {
    pedidoID: string;
    clienteVendedorId: number;
    clienteId: number;
    cliente: string;
    ts: string;
    active: boolean;
    openPayStatusId?: number;
    openPayStatus?: boolean;
    origenExternoId?: number | null;
    motorDivisionId?: EngineDivisionEnum;
    pagados?: string;
}