export interface ICheckoutFooter {
    total?: number,
    disableBtnContinue?: boolean,
    handleBtnContinue?: () => void;
    handleBtnQuoation?: () => void;
}