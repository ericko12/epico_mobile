import { IOrderShipment } from "@/features/checkout/domain/interfaces/checkOut/IOrderShipment";
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum";
import { IGeoposition } from "@/features/shipment/domain/interfaces/evaluatorSMC4/IGeoposition";
import { IPlaceSerializable } from "@/features/common/domain/interfaces/google/IPlaceSerializable";
import { ReferenceLocationOptionEnum } from "@/features/checkout/domain/enums/ReferenceLocationOptionEnum";
import { IFormExternalAddress } from "@/features/address/domain/interface/IFormExternalAddress";

/**
 * Extends the base shipment model with optional contact details required by the SMC4 integration.
 *
 * @extends IOrderShipmentSMC4
 *
 * @property {?ShippingMethodSMC4Enum} [MetodoEnvio] - Shipping method for the order (optional).
 * @property {?string} [Email] - Recipient email for notifications (RFC 5322 compliant).
 * @property {?string} [Phone] - Recipient phone for delivery coordination (E.164 format).
 * @property {?boolean} [isPreviewMiniCheckouts] - Flag indicating if the shipment is part of a preview for mini checkouts.
 * @property {?ReferenceLocationOptionEnum} [referenceLocationOption] - Reference location option (address or city).
 * @property {?number} [CityId] - Identifier for the city associated with the shipping address.
 * @property {?number} [StateId] - Identifier for the state associated with the shipping address.
 * @property {?string} [ShippingMethod] - Specific shipping method selected for the order.
 * @property {?IGeoposition} [MailingAddress] - Geographical coordinates of the shipping address.
 * @property {?boolean} [optionChecked] - Indicates if the shipping option has been selected by the user.
 * @property {?boolean} [isFiscalAddress] - Indicates if the selected delivery address is a fiscal address.
 * @property {?number} [AddressFiscalId] - Identifier for the customer's fiscal address, used for tax calculations.
 * @property {?IPlaceSerializable} googleMapsPlace - Serialized Google Place information for the shipping address.
 * @property {?number} [Iva] - The IVA (VAT) percentage associated with the shipping address.
 * @property {?string} [DireccionEntrega] - Full delivery address as a string.
 * @property {?boolean} [allArticlesExclusivePickup] - Flag indicating if all articles in the order are exclusive for pickup.
 * @property {?IFormExternalAddress} [ExternalAddressCustomer] - External address details for the customer.   
 */
export interface IOrderShipmentSMC4 extends Omit<IOrderShipment, 'MetodoEnvio'> {
    MetodoEnvio?: ShippingMethodSMC4Enum;
    Email?: string;
    Phone?: string;
    isPreviewMiniCheckouts?: boolean;
    referenceLocationOption?: ReferenceLocationOptionEnum
    CityId?: number;
    StateId?: number;
    ShippingMethod?: string;
    MailingAddress?: IGeoposition;
    optionChecked?: number;
    isFiscalAddress?: boolean;
    AddressFiscalId?: number;
    googleMapsPlace?: IPlaceSerializable;
    Iva?: number;
    DireccionEntrega?: string;
    allArticlesExclusivePickup?: boolean;
    ExternalAddressCustomer?: IFormExternalAddress;
}