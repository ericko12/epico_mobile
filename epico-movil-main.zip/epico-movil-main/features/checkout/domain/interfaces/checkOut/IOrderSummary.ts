import { IStatusOpenPay } from "@/features/checkout/domain/interfaces/openpay/IStatusOpenPay";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { EngineDivisionEnum } from "@/features/checkout/domain/enums/EngineDivisionEnum";

/**
 * Interface for the order summary.
 * 
 * @interface IOrderSummary
 * 
 * @property {number} pedidoID - Unique identifier for the order.
 * @property {?number | null} [miniCajaId] - Identifier of the main mini box for the order.
 * @property {number} estatusID - Identifier for the order status.
 * @property {?string} [estatus] - Description of the order status.
 * @property {string} fechaCaptura - Date the order was captured.
 * @property {string} fecha - Date of the order.
 * @property {?string} [fechaReparto] - Delivery date of the order.
 * @property {?string} [fechaEntrega] - Delivery date of the order.
 * @property {number} subTotal - Subtotal of the order.
 * @property {number} subTotalIVA - Subtotal of the order including VAT.
 * @property {?number} [ivaCalculado] - Calculated VAT for the order.
 * @property {number} total - Total amount for the order.
 * @property {number} ahorro - Total savings on the order.
 * @property {number} ahorroIVA - Total savings on the order including VAT.
 * @property {number} porcentajeImpuesto - Tax percentage applied to the order.
 * @property {number} porcentajeDescuento - Discount percentage applied to the order.
 * @property {?number} [costoEnvio] - Shipping cost for the order.
 * @property {number} clienteId - Customer identifier.
 * @property {?number} [pagoID] - Payment identifier.
 * @property {number} pedidoIdSucursal - Identifier for the order in the branch.
 * @property {?IOrderSummaryDetail[]} [detalles] - List of order details.
 * @property {number} monitoreoId - Monitoring identifier for the order.
 * @property {?string} [monitoreo] - Description of the order monitoring.
 * @property {?number} [servicioPaqueteriaId] - Delivery service identifier.
 * @property {?number} [paqueteriaId] - Courier identifier.
 * @property {number} clienteVendedorId - Vendor's customer identifier.
 * @property {?string} [cliente] - Name of the customer.
 * @property {?string} [hora] - Time of the order in TimeSpan format.
 * @property {?number} [plazo] - Payment term for the order.
 * @property {number} prontoPago - Early payment discount.
 * @property {?number} [sucursalId] - Branch identifier.
 * @property {?number} [sucursalIdDestino] - Destination branch identifier.
 * @property {?number} [direcionId] - Fiscal address identifier.
 * @property {?number} [contactoId] - Contact identifier.
 * @property {?number} [AhorroPorcentaje] - Identifier for discount promotions related to volume.
 * @property {?number} [ahorroPromociones] - Identifier for savings on promotions.
 * @property {?number} [tipoProntoPagoId] - Identifier for the type of early payment.
 * @property {?boolean} [openPayStatusId] - Identifier for the OpenPay status.
 * @property {?boolean} [openPayStatus] - Current status of OpenPay.
 * @property {?boolean} [openPayVigencia] - Validity status of OpenPay.
 * @property {?number | null} [origenExternoId] - External origin identifier 
 * @property {?number | null} [pedidoIdExterno] - External order identifier.
 * @property {string} [ordenCompra] - purchase order
 * @property {?string} [pagados] - Payment status or details (optional).
 * @property {EngineDivisionEnum} [motorDivisionId] - Identifier for the division engine used in order processing.
 * @typedef {IOrderSummary}
 */
export interface IOrderSummary {
    pedidoID: number;
    usuarioId?: number;
    miniCajaId?: number | null;
    estatusID: number;
    estatus?: string;
    fechaCaptura: string;
    fecha: string;
    fechaReparto?: string;
    fechaEntrega?: string;
    subTotal: number;
    subTotalIVA: number;
    ivaCalculado?: number;
    total: number;
    ahorro: number;
    ahorroIVA: number;
    porcentajeImpuesto: number;
    porcentajeDescuento: number;
    costoEnvio?: number;
    clienteId: number;
    metodoPagoId?: number;
    pedidoIdSucursal: number;
    detalles?: IOrderSummaryDetail[];
    monitoreoId: number;
    monitoreo?: string;
    servicioPaqueteriaId?: number;
    paqueteriaId?: number;
    clienteVendedorId: number;
    cliente?: string; //Valor para sobre carga
    hora?: string;
    plazo?: number;
    prontoPago: number;
    sucursalId?: number;
    sucursalIdDestino?: number;
    direccionId?: number;
    contactoId?: number;
    AhorroPorcentaje?: number;
    ahorroPromociones?: number;
    tipoProntoPagoId?: number;
    openPayStatusId?: number;
    openPayStatus?: boolean;
    openPayVigencia?: boolean;
    openPay?: IStatusOpenPay;
    origenExternoId?: number | null;
    pedidoIdExterno?: number | null;
    ordenCompra?: string;
    motorDivisionId?: EngineDivisionEnum;
    pagados?: string;
    cotizacionIdOrigen?: number | null;
    originadorId?: number | null;
    medioAtencionId?: number | null;
    estatusInternoId?: number | null;
    /**
     * Folio of the Commercial Proposal that originated the quotation, or `null`/absent when it does not come from one.
     */
    propuestaComercialId?: number | null;
    /**
     * End of the validity period the quotation inherited from its Commercial Proposal, in ISO-8601.
     */
    propuestaComercialVencimiento?: string | null;
}

export * from '@/features/checkout/domain/data/InitOrderSummary.data';
