import { ICheckOut } from "@/features/checkout/domain/interfaces/checkOut/ICheckOut";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";

/**
 * Interface: State model for managing checkout data.
 *
 * @interface ICheckOutState
 * @typedef {ICheckOutState}
 * 
 * @property {string | null} error - Error message or `null` if there is no error.
 * @property {boolean} loading - Indicates if the checkout data is loading.
 * @property {ICheckOut[]} checkOutList - List of checkouts.
 * @property {IOrderSummary | null} selectedOrderSummary - Selected order summary or `null` if none is selected.
 * @property {{ productCode: string, countProduct: number }} pageAuxiliarStates - Auxiliary state for managing product code and quantity.
 * @property {string} pageAuxiliarStates.productCode - Product code in the auxiliary state.
 * @property {number} pageAuxiliarStates.countProduct - Product quantity in the auxiliary state.
 * @property {{ historialId: number, readOnlyQuotation: boolean }} quotationState - Quotation state.
 * @property {number} quotationState.historialId - Quotation history ID.
 * @property {boolean} quotationState.readOnlyQuotation - Indicates if the quotation is read-only.
 */
export interface ICheckOutState {
    error: string | null;
    loading: boolean;
    checkOutList: ICheckOut[];
    selectedOrderSummary: IOrderSummary | null;
    pageAuxiliarStates: { productCode: string, countProduct: number };
    quotationState: { historialId: number, readOnlyQuotation: boolean }
}