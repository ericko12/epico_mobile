import { ISendDelivery } from "@/features/common/domain/interfaces/db/ISendDelivery";
import { ShippingMethodEnum } from "@/features/shipment/domain/enum/ShippingMethodEnum";
import { ShippingTypeEnum } from "@/features/checkout/domain/enums/ShippingTypeEnum";
import { TipoPersonaRecogera } from "@/features/checkout/domain/enums/TipoPersonaRecogera";

/**
 * Interface for the order shipping process.
 * 
 * @interface IOrderShipping
 * 
 * @property {ShippingMethodEnum} MetodoEnvio - Shipping method for the order.
 * @property {number} [DireccionEntregaId] - Delivery address identifier.
 * @property {number} SucursalEnviaId - Identifier for the shipping branch.
 * @property {number} PorteId - Freight of the shipment.
 * @property {number} [ServicioEntrega] - Delivery service for the shipment.
 * @property {string} [cantidad] - Quantity of the order.
 * @property {TipoPersonaRecogera} TipoPersonaRecogera - Type of person who will pick up the order.
 * @property {number} PersonaRecogeraId - Identifier for the person picking up the order.
 * @property {string} [PersonaRecogera] - Name of the person picking up the order.
 * @property {boolean} [HandHeld] - Indicator for using a Hand Held device.
 * @property {ShippingTypeEnum} [TipoEnvio] - Type of shipping.
 * @property {number} [PaqueteriaId] - Courier company identifier.
 * @property {boolean} [PickUp] - Indicator for pickup.
 * @property {string} [TiempoRecogera] - Time for the order to be picked up.
 * @property {boolean} [EnviarPaqueteria] - Enables shipping via parcel service.
 * @property {IDelivery} [EnviarPaqueteria] - Delivery details for parcel shipping.
 * @property {boolean} [NoStock] - Stock status for the order.
 */
export interface IOrderShipmentShippingForm {
    MetodoEnvio?: ShippingMethodEnum;
    DireccionEntregaId?: number;
    SucursalEnviaId?: number;
    PorteId?: number;
    ServicioEntrega?: number;
    cantidad?: string;
    TipoPersonaRecogera?: TipoPersonaRecogera;
    PersonaRecogeraId?: number;
    PersonaRecogera?: string;
    HandHeld?: boolean;
    TipoEnvio?: ShippingTypeEnum;
    PaqueteriaId?: number;
    TiempoRecogera?: string
    PickUp?: boolean;
    EnviarPaqueteria?: ISendDelivery;
    NoStock?: boolean;
    Loading?: boolean;
}