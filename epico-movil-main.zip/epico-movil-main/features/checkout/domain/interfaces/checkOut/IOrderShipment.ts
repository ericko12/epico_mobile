import { IConcession } from "@/features/common/domain/interfaces/catalogs/IConcession";
import { IPaymentMethod } from "@/features/common/domain/interfaces/catalogs/IPaymentMethod";
import { ISendDelivery } from "@/features/common/domain/interfaces/db/ISendDelivery";
import { ShippingMethodEnum } from "@/features/shipment/domain/enum/ShippingMethodEnum";
import { ShippingTypeEnum } from "@/features/checkout/domain/enums/ShippingTypeEnum";
import { SplitBill } from "@/features/common/domain/enums/SplitBill";
import { TipoPersonaRecogera } from "@/features/checkout/domain/enums/TipoPersonaRecogera";
import { IRetentions } from "@/features/checkout/domain/interfaces/retetion/IRetentions";
import { ShippingMethodSMC4Enum } from "@/features/shipment/domain/enum/ShippingMethodSMC4Enum";

/**
 * Interface for the order shipping process.
 * 
 * @interface IOrderShipping
 * 
 * @property {number} pedidoID - Unique identifier for the order.
 * @property {?IConcession | undefined} [consecion] - The concession of the order, may be `undefined`.
 * @property {?boolean | undefined} [PUE] - Single exhibition payment indicator, may be `undefined`.
 * @property {?number | undefined} [FormaPagoId] - Payment method identifier, may be `undefined`.
 * @property {?IPaymentMethod | undefined} [FormaPago] - Payment method used, may be `undefined`.
 * @property {?ShippingMethodEnum | ShippingMethodSMC4Enum | undefined} [MetodoEnvio] - Shipping method for the order, may be `undefined`.
 * @property {?number | undefined} [DireccionEntregaId] - Delivery address identifier, may be `undefined`.
 * @property {?number | undefined} [SucursalEnviaId] - Shipping branch identifier, may be `undefined`.
 * @property {?number | undefined} [PorteId] - Shipping freight identifier, may be `undefined`.
 * @property {?number | undefined} [ServicioEntrega] - Delivery service identifier, may be `undefined`.
 * @property {?string | undefined} [cantidad] - Quantity of the order, may be `undefined`.
 * @property {?TipoPersonaRecogera | undefined} [TipoPersonaRecogera] - Type of person collecting the order, may be `undefined`.
 * @property {?number | undefined} [PersonaRecogeraId] - Identifier of the person collecting the order, may be `undefined`.
 * @property {?string | undefined} [PersonaRecogera] - Name of the person collecting the order, may be `undefined`.
 * @property {?boolean | undefined} [HandHeld] - Indicator for using Hand Held device, may be `undefined`.
 * @property {?ShippingTypeEnum | undefined} [TipoEnvio] - Shipping type, may be `undefined`.
 * @property {?number | undefined} [PaqueteriaId] - Courier identifier, may be `undefined`.
 * @property {?ISendDelivery | undefined} [EnviarPaqueteria] - Information about the parcel shipping, may be `undefined`.
 * @property {?boolean | undefined} [PickUp] - Pickup indicator, may be `undefined`.
 * @property {?string | undefined} [TiempoRecogera] - Estimated collection time for the order, may be `undefined`.
 * @property {?IRetentions | undefined} [Retenciones] - Details of the applied retentions, may be `undefined`.
 * @property {?string | undefined} [Comentarios] - Additional comments on the order, may be `undefined`.
 * @property {?SplitBill | undefined} [Split] - Information about the bill split, may be `undefined`.
 * @property {?boolean | undefined} [NoStock] - Stock availability indicator, may be `undefined`.
 * @property {?boolean | undefined} [OpenPayStatus] - Indicator for an OpenPay payment order, may be `undefined`.
 */
export interface IOrderShipment {
    pedidoID: number;
    consecion?: IConcession;
    PUE?: boolean;
    FormaPagoId?: number;
    FormaPago?: IPaymentMethod;
    MetodoEnvio?: ShippingMethodEnum;
    DireccionEntregaId?: number;
    SucursalEnviaId?: number;
    PorteId?: number;
    ServicioEntrega?: number;
    cantidad?: string;
    TipoPersonaRecogera?: TipoPersonaRecogera;
    PersonaRecogeraId?: number;
    PersonaRecogera?: string;
    HandHeld?: boolean;
    TipoEnvio?: ShippingTypeEnum;
    PaqueteriaId?: number;
    EnviarPaqueteria?: ISendDelivery;
    PickUp?: boolean;
    TiempoRecogera?: string;
    Retenciones?: IRetentions;
    Comentarios?: string;
    Split?: SplitBill;
    NoStock?: boolean;
    Loading?: boolean;
    OpenPayStatus?: boolean;
}
