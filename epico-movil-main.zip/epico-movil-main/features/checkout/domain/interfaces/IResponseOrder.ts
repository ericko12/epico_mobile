/**
 * IResponseOrder - Response after posting new order
 * @property {string} pedidoId - New order identifier.
 * 
 */
export interface IResponseOrder {
    pedidoId: string
}