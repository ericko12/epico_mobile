import { IPromotion } from "@/features/promotions/domain/interfaces";


/**
 * Interface for the details of an order summary.
 * 
 * @export
 * @interface IOrderSummaryDetail
 * 
 * @property {number} pedidoID - Unique identifier for the order.
 * @property {number} productoID - Unique identifier for the product.
 * @property {?number} precioRevista - Price of the product from the catalog, if available.
 * @property {?string} producto - Name of the product.
 * @property {?string} descripcion - Description of the product.
 * @property {?string} imagen - Image URL or reference for the product.
 * @property {number} precio - Price of the product.
 * @property {number} precioIVA - Price of the product including VAT.
 * @property {?number} importe - Amount for the product, if available.
 * @property {?number} importeIVA - Amount for the product including VAT, if available.
 * @property {?number} ivaCalculado - Calculated VAT for the product.
 * @property {number} cantidad - Quantity of the product in the order.
 * @property {number} precioLista - List price of the product.
 * @property {number} promocionID - Promotion identifier applied to the product.
 * @property {number} importeOriginal - Original amount for the product.
 * @property {number} importeOriginalIVA - Original amount including VAT for the product.
 * @property {number} ahorro - Savings for the product.
 * @property {number} ahorroIVA - Savings for the product including VAT.
 * @property {number} ahorroPorcentaje - Percentage of savings for the product.
 * @property {number} precioListaIVA - List price of the product including VAT.
 * @property {?boolean} productoPaqueteria - Flag indicating if the product is for packaging.
 * @property {?number} prontoPago - Early payment discount for the product, if applicable.
 * @property {?string[]} oems - OEM identifiers related to the product.
 * @property {number} pedidoDetalleId - Unique identifier for the order detail.
 * @property {number} precioEspecialId - Identifier for the special price, if applicable.
 * @property {number} estatusPrecioEspecialId - Identifier for the special price status.
 * @property {boolean} permitePrecioEspecial - Flag indicating if special pricing is allowed for the product.
 * @property {number} cantidadPrecioEspecial - Quantity eligible for the special price.
 * @property {?IPromotion[]} promociones - List of promotions applied to the product.
 * @property {number} precioSolicitado - Price requested for the product by the customer.
 * @property {string} comentarioEjecuto - Comment about the execution of the product request.
 * @property {number} precioMinimoSugeridoParaToken - Suggested minimum price for the product to be tokenized.
 * @property {?number | '-'} stockEnSucursal - Available stock for the product in the branch, or `'-'` if not available.
 * @property {?boolean} productoNegado - Flag indicating if the product is denied for sale.
 * @property {?boolean} gratis - Flag indicating if the product is free.
 * @property {?number} porcentajeDescuento - Discount percentage applied to the product, if applicable.
 * @property {?boolean} openPay - Flag indicating if OpenPay is used for the product payment.
 * @property {?number | '-'} stockEnSMC - Available stock for the product in the System of Customer Monitoring (SMC), or `'-'` if not available.
 * @property {?number} familia - The information about the family where the product belongs to
 * @property {?number | '-'} stockEnSucursalNacional - Available stock for the product in the national branch, or `'-'` if not available.
 * @property {?boolean} pickUp - Flag indicating if the product is for pickup.
 * @property {?number} descuentoAdicional - Additional discount applied to the product, if applicable.
 * @property {?boolean} esPrecioDePreciosPersonalizadas - Flag indicating if the product price comes from the customer's personalized price list (multi-lista).

 * @property {number | null} tipoPrecio - Flag indicating the type of discount (defined in priceUtils)
 */
export interface IOrderSummaryDetail {
    pedidoID: number;
    productoID: number;
    precioRevista?: number;
    producto?: string;
    descripcion?: string;
    imagen?: string;
    precio: number;
    precioIVA: number;
    importe?: number;
    importeIVA?: number;
    ivaCalculado?: number;
    cantidad: number;
    precioLista: number;
    promocionID: number;
    importeOriginal: number;
    importeOriginalIVA: number;
    ahorro: number;
    ahorroIVA: number;
    ahorroPorcentaje: number;
    precioListaIVA: number;
    productoPaqueteria?: boolean;
    prontoPago?: number;
    oems?: string[];
    pedidoDetalleId: number;
    precioEspecialId: number;
    estatusPrecioEspecialId: number;
    permitePrecioEspecial: boolean;
    cantidadPrecioEspecial: number;
    promociones?: IPromotion[];
    precioSolicitado: number;
    comentarioEjecuto: string;
    precioMinimoSugeridoParaToken: number;
    stockEnSucursal?: number | '-';
    productoNegado?: boolean;
    gratis?: boolean;
    porcentajeDescuento?: number;
    openPay?: boolean;
    stockEnSMC?: number | '-';
    familia?: string;
    stockNacional?: number | '-';
    pickUp?: boolean;
    descuentoAdicional?: number;
    esPrecioDePreciosPersonalizadas?: boolean;
    kmsAplicados?: number;
    /**
     * Whether the line item originated from a Commercial Proposal.
     * Only set when the line is created, so a line removed and added again arrives as `false`.
     */
    esPropuestaComercial?: boolean;
    tipoPrecio?: number | null;
}

