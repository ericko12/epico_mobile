/**
 * Interface representing the parameters required for stock retrieval.
 *
 * @param {boolean} RecuperarExistencia - Indicates whether to retrieve the current stock.
 * @param {number} SucursalId - The ID of the branch or store for which the stock is to be retrieved.
 * @param {boolean} [RecuperarTienePromociones] - Optional. Indicates whether to retrieve information about available promotions.
 * @param {boolean} [RecuperarListadoPromociones] - Optional. Indicates whether to retrieve a detailed list of promotions.
 * @param {string} [PedidoID] - Optional. The ID of the order for which stock is being checked.
 * @param {boolean} [AplicarRevistaPromocion] - Optional. Indicates to apply revista discount.
 */
export interface IStockParam {
    RecuperarExistencia: boolean;
    SucursalId: number;
    RecuperarTienePromociones?: boolean;
    RecuperarListadoPromociones?: boolean;
    PedidoID?: string;
    AplicarRevistaPromocion?: boolean;
}
