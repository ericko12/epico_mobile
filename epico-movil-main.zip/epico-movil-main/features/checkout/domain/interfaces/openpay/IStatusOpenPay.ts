/**
 * Modelo para ver el estatus de un pedido con pago openPay
 * @property {number} pedidoId - El ID del pedido.
 * @property {string} estatus - El estatus del pedido.
 * @property {number} estatusId - El ID del estatus del pedido.
 * @property {string} liga - La liga asociada al pedido.
 * @property {boolean} esDebito - Indica si el método de pago es débito.
 * @property {boolean} tieneVigencia - Indica si la liga tiene vigencia.
 * @property {number} ligaId - El ID de la liga.
 * @property {string} correo - El correo asociado al pedido.
 * @property {string} [pagados] - Cadena opcional que indica el número de pagos realizados.
 * @property {number} [pedidoIdDivision] - ID opcional para la división del pedido.
 * @exports
 */
export interface IStatusOpenPay {
    pedidoId: number;
    estatus: string;
    estatusId: number;
    liga: string;
    esDebito: boolean;
    tieneVigencia: boolean;
    ligaId: number;
    correo: string;
    pagados?: string;
    pedidoIdDivision?: number;
}