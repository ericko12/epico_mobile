/**
 * Interface for sending the status of an order.
 * 
 * @export
 * @interface ISendOrderStatus
 * 
 * @property {number[]} pedidosIds - Array of unique identifiers for the orders.
 * @property {number} origenId - Identifier for the origin of the order.
 */
export interface ISendOrderStatus {
    pedidosIds: number[];
    origenId: number;
}