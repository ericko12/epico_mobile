/**
 * Interface for the customer price list details.
 * 
 * @export
 * @interface ICustomerPriceList
 * 
 * @property {number} clienteId - Unique identifier for the customer.
 * @property {number} listaPrecioId - Unique identifier for the price list.
 * @property {string} listaPrecio - Name or description of the price list.
 * @property {number} listaPrecioPersonalizadaId - Unique identifier for the personalized price list.
 * @property {string} listaPrecioPersonalizada - Name or description of the personalized price list.
 * @property {number} regionId - Unique identifier for the region.
 * @property {string} region - Name or description of the region.
 * @property {number} tipoDescuentoProntoPagoId - Identifier for the type of early payment discount.
 * @property {string} tipoDescuentoProntoPago - Description of the early payment discount type.
 * @property {number} descuentoProntoPago - Early payment discount percentage.
 * @property {string} portafolio - Portfolio associated with the customer.
 */
export interface ICustomerPriceList {
    clienteId: number;
    listaPrecioId: number;
    listaPrecio: string;
    listaPrecioPersonalizadaId: number;
    listaPrecioPersonalizada: string;
    regionId: number;
    region: string;
    tipoDescuentoProntoPagoId: number;
    tipoDescuentoProntoPago: string;
    descuentoProntoPago: number;
    portafolio: string
}