import { SwitchToSMC3ReasonEnum } from "@/features/checkout/domain/enums/SwitchToSMC3ReasonEnum";

/**
 * Payload sent to POST /api/v4/SMC4/CambioFlujoSMC3 when the user leaves the SMC 4.0 delivery options
 * and continues the order with the SMC 3 flow ("Procesar con SMC 3").
 * The reason description is not sent: the backend takes it from its catalog using motivoId.
 *
 * @interface ISwitchToSMC3LogRequest
 * @property {number} pedidoId - Order identifier.
 * @property {number} empleadoId - Employee who triggered the change of flow.
 * @property {number} usuarioId - Epico user who triggered the change of flow.
 * @property {SwitchToSMC3ReasonEnum} motivoId - Selected reason identifier (must be active in the catalog).
 * @property {string} observacion - Free text observation (minimum 3 words, maximum 500 characters).
 * @property {string} fechaHora - Date and time of the event in UTC (ISO 8601).
 * @property {string | null} uuidSMC4 - Identifier of the SMC 4.0 evaluation returned by the algorithm (maximum 100 characters).
 * @property {string | null} requestSMC4 - Raw request sent to the SMC 4.0 algorithm (JSON).
 * @property {string | null} responseSMC4 - Raw response returned by the SMC 4.0 algorithm (JSON).
 */
export interface ISwitchToSMC3LogRequest {
    pedidoId: number;
    empleadoId: number;
    usuarioId: number;
    motivoId: SwitchToSMC3ReasonEnum;
    observacion: string;
    fechaHora: string;
    uuidSMC4: string | null;
    requestSMC4: string | null;
    responseSMC4: string | null;
}
