/**
 * Interface representing the details of a transfer request.
 * 
 * @interface ITransferRequestDetail
 * @property {number} productoId - The product identifier
 * @property {number} cantidad - The quantity of the product
 * @property {number} precioUnitario - The unit price of the product
 */
export interface ITransferRequestDetail {
    productoId: number;
    cantidad: number;
    precioUnitario: number;
}

/**
 * Interface representing the foreign/local requests associated with a transfer request.
 * 
 * @interface IForeignLocalRequests
 * @property {number} branchOfficeId - The branch office identifier
 * @property {ITransferRequestDetail[]} requestDetails - The array of transfer request details
 * @property {IBranchTransferPetition[]} branchesPetitions - The array of branch petitions associated with the transfer request
 */
export interface IForeignLocalRequests {
    branchOfficeId: number;
    requestDetails: ITransferRequestDetail[];
    branchesPetitions: IBranchTransferPetition[];
}

/**
 * Interface representing the details of a transfer request for a branch petition.
 * 
 * @interface IBranchTransferPetition
 * @property {number} branchOfficeId - The branch office identifier
 * @property {ITransferRequestDetail[]} requestDetails - The array of transfer request details
 * @property {IForeignLocalRequests} foraneaLocalSolicitudes - The foreign/local requests associated with the branch petition
 */
export interface IBranchTransferPetition {
    branchOfficeId: number;
    requestDetails: ITransferRequestDetail[];
    foraneaLocalSolicitudes?: IForeignLocalRequests;
}

/**
 * Interface representing the details of an automatic transfer request.
 * 
 * @interface IAutomaticTransferRequest
 * 
 * @property {number} branchOfficeId - The branch office identifier
 * @property {number} userId - The user identifier
 * @property {ITransferRequestDetail[]} requestDetails - The array of transfer request details
 * @property {IBranchTransferPetition[]} branchesPetitions - The array of branch petitions associated with the transfer request
 */
export interface IAutomaticTransferRequest {
    branchOfficeId: number;
    userId: number;
    requestDetails: ITransferRequestDetail[];
    branchesPetitions: IBranchTransferPetition[];
}

/**
 * Interface representing the request payload for sending a mini checkout in SMC4 system.
 * 
 * @interface ISendMiniCheckoutRequestSMC4
 * 
 * @property {number} metodoEntrega - The delivery method identifier
 * @property {number} clienteVendedorId - The client-seller relationship identifier
 * @property {number} pedidoOrigenId - The origin order identifier
 * @property {number} origenId - The origin identifier
 * @property {number} usuarioId - The user identifier
 * @property {?number} [monedaId] - The currency identifier (optional)
 * @property {number} tipoProntoPagoId - The prompt payment type identifier
 * @property {number} prontoPago - The prompt payment value
 * @property {number} sucursalIdDestino - The destination branch identifier
 * @property {?number} [pcid] - The PC identifier (optional)
 * @property {number} motorDivisionId - The division motor identifier
 * @property {?number | null} KmsAplicados - The ammount of Kms Applied to this mini checkout
 * @property {number} divisionPedidoId - The division order identifier
 * @property {boolean} esTransitorio - Flag indicating if the division is transitory
 * 
 * @property {Object} preferenciasPedido - Order preferences configuration
 * @property {number} preferenciasPedido.concesionId - The concession identifier
 * @property {number} preferenciasPedido.plazo - The payment term
 * @property {number} preferenciasPedido.metodoPagoId - The payment method identifier
 * @property {boolean} preferenciasPedido.pue - PUE (Pago en Una sola Exhibición) flag
 * @property {string} preferenciasPedido.observaciones - Additional observations or notes
 * @property {number} preferenciasPedido.porteId - The shipping/freight identifier
 * @property {?string} [preferenciasPedido.cantidadPagara] - The amount to be paid (optional)
 * @property {?string} [preferenciasPedido.personaRecogera] - The person who will pick up (optional)
 * @property {?string} [preferenciasPedido.tiempoRecogera] - The pickup time (optional)
 * @property {?boolean} [preferenciasPedido.pickup] - Pickup flag (optional)
 * @property {?number} [preferenciasPedido.direccionId] - The address identifier (optional)
 * @property {?number} [preferenciasPedido.paqueteriaId] - The courier service identifier (optional)
 * @property {boolean} preferenciasPedido.surtidoHandHeld - Handheld fulfillment flag
 * @property {?number} [preferenciasPedido.servicioEntregaId] - The delivery service identifier (optional)
 * @property {?number} [preferenciasPedido.direccionPaqueteriaId] - The courier address identifier (optional)
 * @property {number} preferenciasPedido.dividirPedido - Split order flag
 * @property {?string} [preferenciasPedido.ordenCompra] - The purchase order number (optional)
 * @property {string} preferenciasPedido.correoElectronicoContacto - The contact email address
 * @property {string} preferenciasPedido.telefonoContacto - The contact phone number
 * @property {?number} [preferenciasPedido.tipoServicioEntregaID] - The delivery service type identifier (optional)
 * @property {boolean} preferenciasPedido.pagadoConOpenpay - Flag indicating if the order was paid with OpenPay
 * @property {?number} [preferenciasPedido.distancia] - The distance for delivery (optional)
 * 
 * @property {Array<Object>} pedidoDetalles - Array of order line items
 * @property {number} pedidoDetalles[].productoId - The product identifier
 * @property {number} pedidoDetalles[].precio - The product price
 * @property {number} pedidoDetalles[].cantidad - The quantity ordered
 * @property {number} pedidoDetalles[].pcListaPrecioId - The price list identifier
 * @property {?number} pedidoDetalles[].pcPromocionId - The promotion identifier
 * @property {number} pedidoDetalles[].descuentoAdicional - The additional discount amount
 * @property {boolean} pedidoDetalles[].gratis - Free item flag
 * @property {boolean} pedidoDetalles[].tieneToken - Has token flag
 * @property {?number} pedidoDetalles[].KmsAplicados - The ammount of kms applied on this specific code
 * @property {?number} pedidoDetalles[].precioEspecialId - The special price identifier
 * @property {?Object} [pedidoExterno] - External order information (optional)
 * @property {number} pedidoExterno.pedidoId - The external order identifier
 * @property {number} pedidoExterno.origenId - The external order origin identifier
 * @property {ISolicitudTraspasoAutomatica} solicitudTraspasoAutomatica - Automatic transfer request payload.
 */
export interface ISendMiniCheckoutRequestSMC4 {
    metodoEntrega: number;
    clienteVendedorId: number;
    pedidoOrigenId: number;
    origenId: number;
    usuarioId: number;
    monedaId?: number;
    tipoProntoPagoId: number;
    prontoPago: number;
    sucursalIdDestino: number;
    pcid?: number;
    motorDivisionId: number;
    KmsAplicados?: number | null;
    divisionPedidoId: number;
    esTransitorio: boolean;
    preferenciasPedido: {
        concesionId: number;
        plazo: number;
        metodoPagoId: number;
        pagadoConOpenpay?: boolean;
        pue: boolean;
        observaciones: string;
        porteId: number;
        cantidadPagara?: string;
        personaRecogera?: string;
        tiempoRecogera?: string;
        pickup?: boolean;
        direccionId?: number;
        paqueteriaId?: number;
        surtidoHandHeld: boolean;
        servicioEntregaId?: number;
        direccionPaqueteriaId?: number;
        dividirPedido: number;
        ordenCompra?: string;
        correoElectronicoContacto: string;
        telefonoContacto: string;
        tipoServicioEntregaID?: number;
        distancia?: number;
    },
    pedidoDetalles: {
        productoId: number;
        precio: number;
        cantidad: number;
        pcListaPrecioId: number;
        pcPromocionId?: number;
        descuentoAdicional: number;
        gratis: boolean;
        tieneToken: boolean;
        KmsAplicados?: number | null;
        precioEspecialId?: number;
    }[],
    pedidoExterno?: {
        pedidoId: number;
        origenId: number;
    },
    solicitudTraspasoAutomatica?: IAutomaticTransferRequest;
};