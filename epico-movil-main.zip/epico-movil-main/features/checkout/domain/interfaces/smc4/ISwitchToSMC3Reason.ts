import { SwitchToSMC3ReasonEnum } from "@/features/checkout/domain/enums/SwitchToSMC3ReasonEnum";

/**
 * Reason of the catalog returned by the backend to switch from SMC 4.0 to the SMC 3 flow ("Procesar con SMC 3").
 *
 * @interface ISwitchToSMC3Reason
 * @property {SwitchToSMC3ReasonEnum} motivoId - Reason identifier.
 * @property {string} descripcion - Reason description shown in the modal.
 * @property {boolean} activo - Indicates whether the reason is active.
 */
export interface ISwitchToSMC3Reason {
    motivoId: SwitchToSMC3ReasonEnum;
    descripcion: string;
    activo: boolean;
}
