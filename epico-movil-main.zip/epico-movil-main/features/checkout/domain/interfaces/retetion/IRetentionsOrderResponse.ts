/**
 * Interface to get the retentions response
 *
 * @export
 * @interface IRetentionsOrderResponse
 * @property {string} motivos - The retention reasons concatenated in a single string, separated by "|"
 * @property {boolean} retener - Indicates whether the shipment should be retained or not
 */
export interface IRetentionsOrderResponse {
    motivos: string,
    retener: boolean
}



/**
 * Default retention order response object.
 * @type {IRetentionsOrderResponse}
 * @property {string} motivos - The reason or motive for the retention (empty by default)
 * @property {boolean} retener - Flag indicating whether to apply retention (false by default)
 */
export const RetentionsOrderResponseDefault: IRetentionsOrderResponse = {
    motivos: '',
    retener: false
}
