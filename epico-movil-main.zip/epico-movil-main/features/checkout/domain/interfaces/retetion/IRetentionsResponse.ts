/**
 * Interface para obtener el response de retenciones
 *
 * @export
 * @interface IRetentionsResponse
 * @typedef {IRetentionsResponse}
 */
export interface IRetentionsResponse {
    observacion: string,
    retener: boolean
}


/**
 * Variable con valores por defecto
 *
 * @type {IRetentionsResponse}
 */
export const RetentionsResponseDefault: IRetentionsResponse = {
    observacion: "",
    retener: false
}
