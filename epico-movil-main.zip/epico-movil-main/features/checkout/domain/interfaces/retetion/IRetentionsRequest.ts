
/**
 * Interface del body para consumir endpoint de retenciones
 *
 * @export
 * @interface IRetentionsRequest
 * @typedef {IRetentionsRequest}
 */
export interface IRetentionsRequest {
    clienteVendedorId: number,
    infoSucursalId: number,
    llamadaPedidoId: number,
    origenId: number,
    origenIdSMC: number,
    concesionId: number,
    importeTotal: number,
    ivaTotal: number
}
