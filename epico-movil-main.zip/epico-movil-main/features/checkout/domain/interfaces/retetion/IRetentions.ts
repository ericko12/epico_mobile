/**
 * Interface que contiene motivos y comentarios de retencion
 *
 * @export
 * @interface IRetentions
 * @typedef {IRetentions}
 */
export interface IRetentions {
    motivos: string,
    observacion: string
}