/**
 * Represents a request for retention information associated with an order.
 * 
 * @interface IRetentionsOrderRequest
 * @property {number} clienteVendedorId - The unique identifier for the client/vendor.
 * @property {number} concesionId - The unique identifier for the concession or agreement.
 * @property {number} importeTotal - The total amount of the transaction.
 * @property {number} ivaTotal - The total VAT (Value Added Tax) amount.
 * @property {number} pedidoId - The unique identifier for the order/request.
 * @property {number} origenId - The unique identifier for the origin or source of the transaction.
 */
export interface IRetentionsOrderRequest {
    clienteVendedorId: number
    concesionId: number
    importeTotal: number
    ivaTotal: number
    pedidoId: number
    origenId: number
}