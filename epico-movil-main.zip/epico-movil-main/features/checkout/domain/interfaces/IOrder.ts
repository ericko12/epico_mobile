import { EngineDivisionEnum } from "@/features/checkout/domain/enums/EngineDivisionEnum"

/**
 * Interface for Order summary
 * @property {number} ClienteId - Customer ID
 * @property {number} ClienteVendedorId - Customer Seller ID
 * @property {number} SucursalId - Branch ID
 * @property {number} OrigenId - Origin ID
 * @property {number} UsuarioId - User ID
 * @property {?number} DireccionId - Address ID
 * @property {?number} ContactoId - Contact ID
 * @property {?number} MetodoPagoId - Payment method ID
 * @property {number} ProntoPago - Prompt payment amount
 * @property {?number} SucursalIdDestino - Destination branch ID
 * @property {number} Pcid - Policy ID
 * @property {number} TipoProntoPagoId - Type of prompt payment
 * @property {bool} EsCotizacion - Indicates if the order is a quotation
 * @property {?number} Plazo - Terms of the order
 * @property {?EngineDivisionEnum} [motorDivisionId] - Identifier for the division engine used in order processing.
 */
export interface IOrder {
    clienteId: number;
    ClienteVendedorId: number;
    SucursalId: number;
    OrigenId: number;
    UsuarioId: number;
    DireccionId?: number;
    ContactoId?: number;
    MetodoPagoId?: number;
    ProntoPago: number;
    SucursalIdDestino?: number;
    Pcid: number;
    TipoProntoPagoId: number;
    EsCotizacion: boolean;
    Plazo?: number;
    motorDivisionId?: EngineDivisionEnum;
}
