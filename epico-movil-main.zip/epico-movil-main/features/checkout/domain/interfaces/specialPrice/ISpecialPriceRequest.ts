/**
 * Interface that defines the request for a special price
 * 
 * @interface ISpecialPriceRequest
 * @property {number} clienteId - Client identifier
 * @property {number} infoSucursalId - Branch office identifier
 * @property {number} precioLista - List price
 * @property {number} precioSolicitado - Requested price
 * @property {number} cantidadPiezas - Number of pieces
 * @property {number} empleadoIdSolicitante - Employee requester identifier
 * @property {string} comentarioSolicitud - Request comment
 * @property {string} producto - Product
 * @property {number} pedidoId - Order identifier
 * @property {number} pedidoDetalleId - Order detail identifier
 * @property {number} origenId - Origin identifier
 * @property {?number} historialId - historic identifier
 */
export interface ISpecialPriceRequest {
    clienteId: number,
    infoSucursalId: number,
    precioLista: number,
    precioSolicitado: number,
    cantidadPiezas: number,
    empleadoIdSolicitante: number,
    comentarioSolicitud: string,
    producto: string,
    pedidoId: number,
    pedidoDetalleId: number,
    origenId: number,
    historialId?: number,
    nombreCompetidor?: string,
    marcaCompetidor?: string,
}