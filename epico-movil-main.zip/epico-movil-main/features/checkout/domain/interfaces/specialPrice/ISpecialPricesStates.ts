import { ISpecialPriceState } from "@/features/checkout/domain/interfaces/specialPrice/ISpecialPriceState";

/**
 * Interface that defines the possible states of a special price
 * @interface ISpecialPriceStates
 * @property {ISpecialPriceState} SinSolicitud - State when there is no special price request
 * @property {ISpecialPriceState} Solicitado - State when special price has been requested
 * @property {ISpecialPriceState} Aceptado - State when special price has been accepted
 * @property {ISpecialPriceState} Rechazado - State when special price has been rejected
 * @property {ISpecialPriceState} Cancelado - State when special price has been cancelled
 * @property {ISpecialPriceState} Negociado - State when special price is under negotiation
 */
export interface ISpecialPriceStates {
    SinSolicitud: ISpecialPriceState;
    Solicitado: ISpecialPriceState;
    Aceptado: ISpecialPriceState;
    Rechazado: ISpecialPriceState;
    Cancelado: ISpecialPriceState;
    Negociado: ISpecialPriceState;
}