/**
 * Interface that defines the state of a special price
 * @interface ISpecialPriceState
 * @property {number} index - Numeric identifier for the state
 * @property {string} text - Display text for the state
 */
export interface ISpecialPriceState {
    index: number;
    text: string;
}