
/**
 * Interface that defines the response for a special price
 * 
 * @interface ISpecialPriceResponse
 * @property {number} precioEspecialId - Special price identifier
 * @property {number} productoId - Product identifier
 * @property {number} precioSolicitado - Requested price
 * @property {number} cantidad - Quantity
 * @property {string} comentarioEjecuto - Execution comment
 * @property {number} estatusPreciosEspecialesId - Special price status identifier
 * @property {number} precioMinimoSugeridoParaToken - Minimum suggested price for token
 */
export interface ISpecialPriceResponse {
    precioEspecialId: number,
    productoId: number,
    precioSolicitado: number,
    cantidad: number,
    comentarioEjecuto: string,
    estatusPreciosEspecialesId: number,
    precioMinimoSugeridoParaToken: number,
}