/**
 * Interface that defines the response for a special price request
 *
 * @interface IRequestForSpecialPriceResponse
 * @property {number} precioEspecialId - Special price identifier
 */
export interface IRequestForSpecialPriceResponse {
    precioEspecialId: number
}