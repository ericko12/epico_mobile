export interface IFormatoOrdenCompra {
    esValida: boolean;
    obligatorio: boolean;
    formatoId: number;
    mascara: string;
    patronRegex: string;
    formatoPredefinido: string;
}