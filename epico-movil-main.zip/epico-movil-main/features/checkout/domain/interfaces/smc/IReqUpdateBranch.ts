/**
 * Interface that defines the necessary properties to update branch information.
 * @export
 * @interface IReqUpdateBranch
 * @typedef {IReqUpdateBranch}
 * @property {number} infoSucursalId - Unique identifier for the branch.
 * @property {number} miniCajaId - Unique identifier for the associated mini box.
 * @property {string} distancia - Distance to the branch in text format (e.g. "25 km").
 * @property {string} tiempo - Estimated arrival or delivery time in text format (e.g. "4 hr").
 * @property {number} tipoServicioSucursalId - Unique identifier for the branch service type.
 * @property {boolean | nul} aplicoKms - flag indicating if the customer applied kms

 */
export interface IReqUpdateBranch {
    infoSucursalId: number;
    miniCajaId: number;
    distancia: string;
    tiempo: string;
    tipoServicioSucursalId: number;
    aplicoKms: boolean | null;
}
