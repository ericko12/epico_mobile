/**
 * Interface of product items to evaluate order
 *
 * @export
 * @interface ItemsEvaluateOrder
 * @property {number} productoID - Unique identifier for the product.
 * @property {number} cantidad - Quantity of the product ordered.
 * @property {number | null} cantidadUrgente - Urgent quantity needed.
 * @property {number} precio - Price of the product.
 * @property {number} importe - Total amount for the product.
 * @property {number} promocionID - Identifier for the promotion applied.
 * @property {number | null} porcentajeDescuento - Discount percentage applied.
 * @property {number | null} precioEspecialID - Identifier for any special pricing.
 * @property {boolean} gratis - Indicates if the product is free.
 * @property {number | null} tipoPrecio - Indicates the type of the price (TKN, UPA, DIN, etc).
 */
export interface ItemsEvaluateOrder {
    productoID: number;
    cantidad: number;
    cantidadUrgente: number | null;
    precio: number;
    importe: number;
    promocionID: number | null;
    porcentajeDescuento: number | null;
    precioEspecialID: number | null;
    gratis: boolean;
    tipoPrecio?: number | null;
}