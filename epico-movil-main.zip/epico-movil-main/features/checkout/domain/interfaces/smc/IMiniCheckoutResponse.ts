import { IMiniCheckout } from "@/features/shipment/domain/interfaces/minisCheckout/IMiniCheckout";

/**
 * Interface SMC algorithm response
 *
 * @export
 * @interface IMiniCheckoutResponse
 * @property {IMiniCheckout[]} miniCajas - Array of mini checkouts.
 */
export interface IMiniCheckoutResponse {
    miniCajas: IMiniCheckout[];
}