/**
 * Represents the response structure for sending a mini checkout order.
 * 
 * @interface ISendMiniCheckoutResponse
 * @typedef {ISendMiniCheckoutResponse}
 * 
 * @property {string} pedidoID - Unique identifier for the order that was processed.
 * @property {string} respuesta - The response message or status from the mini checkout process.
 * @property {number} sucursalID - ID of the branch associated with the order.
 * @property {string} sucursal - The name or description of the branch.
 * @property {boolean} quedanMiniCajas - Whether there are remaining mini checkout sessions available.
 */
export interface ISendMiniCheckoutResponse {
    pedidoID: string;
    respuesta: string;
    sucursalID: number;
    sucursal: string;
    quedanMiniCajas: boolean;
}