import { SplitBill } from "@/features/common/domain/enums/SplitBill";
import { ILoyaltyPlanProductsRequest } from "@/features/loyaltyPlan/domain/interface/ILoyaltyPlanProductRequest"
/**
 * Interface representing a request to send a mini checkout order.
 * 
 * @interface ISendMiniCheckoutRequest
 * @typedef {ISendMiniCheckoutRequest}
 * 
 * @property {number} pedidoLlamadaId - ID of the original order call
 * @property {number} miniCajaId - ID of the mini checkout box
 * @property {number} concesionId - ID of the concession
 * @property {number} clienteVendedorId - ID of the customer vendor
 * @property {number} origenId - Origin ID of the request
 * @property {number} origenIDSMC - SMC origin ID
 * @property {number} importeTotalPedido - Total amount of the order
 * @property {number} [pedidoIdExterno] - Optional external order ID
 * @property {number} usuarioId - ID of the user making the request
 * @property {string} [ordenCompra] - Optional purchase order number
 * @property {number} porteId - ID of the shipping type
 * @property {number} [direccionPaqueteriaId] - Optional ID of the courier address
 * @property {number} sucursalId - ID of the branch
 * @property {number} [paqueteriaId] - Optional ID of the courier service
 * @property {number} [servicioEntregaId] - Optional ID of the delivery service
 * @property {string} [personaRecogera] - Optional name of person who will pick up
 * @property {string} [cantidadPagara] - Optional payment amount
 * @property {string} [tiempoRecogera] - Optional pickup time
 * @property {string} observaciones - Comments or observations
 * @property {boolean} [envioHandHeld] - Optional flag for handheld delivery
 * @property {SplitBill} dividirPedido - Split bill configuration
 * @property {boolean} [pickUp] - Optional flag for pickup
 * @property {number} [direccionid] - Optional address ID
 * @property {number} metodoPagoId - Payment method ID
 * @property {boolean} pue - Single exhibition payment flag
 * @property {number} plazo - Payment term
 * @property {number} [TipoServicioEntregaId] - Optional delivery service type ID
 * @property {boolean?} [aplicoKms] - (Optional) flag indicating if the customer applied kms
 */
export interface ISendMiniCheckoutRequest {
    pedidoLlamadaId: number;
    miniCajaId: number;
    concesionId: number;
    clienteVendedorId: number;
    origenId: number;
    origenIDSMC: number;
    importeTotalPedido: number;
    pedidoIdExterno?: number;
    usuarioId: number;
    ordenCompra?: string;
    porteId: number;
    direccionPaqueteriaId?: number;
    sucursalId: number;
    paqueteriaId?: number;
    servicioEntregaId?: number;
    personaRecogera?: string;
    cantidadPagara?: string;
    tiempoRecogera?: string;
    observaciones: string;
    envioHandHeld?: boolean;
    dividirPedido: SplitBill;
    pickUp?: boolean;
    direccionid?: number;
    metodoPagoId: number;
    pue: boolean;
    plazo: number;
    TipoServicioEntregaId?: number;
    HasFormat: boolean;
    aplicoKms?: boolean;
    PedidoExternoId?: number;
}