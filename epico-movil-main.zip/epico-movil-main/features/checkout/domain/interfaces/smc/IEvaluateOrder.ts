
/**
 * Interface to evaluate order in SMC request
 *
 * @export
 * @interface EvaluateOrder
 * @property {boolean} aplicoDivision - Indicates if division was applied.
 * @property {null} observacion - Observations (currently set to null).
 */
export interface IEvaluateOrder {
    aplicoDivision: boolean,
    observacion: null
}