/**
 * Request interface for consolidating mini checkouts.
 *
 * @export
 * @interface IConsolidateMiniCheckoutsRequest
 * @property {number} CajaID - Unique identifier for the checkout box.
 * @property {number} OrigenId - Identifier for the origin.
 * @property {number} OrigenIdSMC - Identifier for the SMC origin.
 * @property {number} InfoSucursalID - Identifier for the branch information.
 * @property {boolean} incluirNuevaCaja - Indicates whether to include a new checkout box.
 * @property {number} Prioridad - Priority level for the request.
 * @property {number} [DireccionID] - (Optional) Identifier for the address.
 * @property {boolean | null} [aplicoKms] - (Optional) Checks if the customer applied points
 */
export interface IConsolidateMiniCheckoutsRequest {
    cajaID: number;
    OrigenId: number;
    OrigenIdSMC: number;
    infoSucursalID: number;
    incluirNuevaCaja: boolean;
    prioridad: number;
    direccionId?: number;
    aplicoKms?:boolean | null;
}