import { Smc4TypeEventEnum } from '@/features/checkout/domain/enums/Smc4TipoEventoEnum';
/**
 * Interface representing a log entry for SMC4 (Sistema de Manejo de Checkout 4).
 * 
 * @interface ISmc4Log
 * @property {number} pedidoId - The unique identifier of the order.
 * @property {?number} opcionId - The identifier of the selected option.
 * @property {string} sucursalesIncluidas - A string representation of the included branches/stores.
 * @property {number | null} sucursalId - The unique identifier of the branch/store, or null if not applicable.
 * @property {string | null} estadoFincado - The settlement status, or null if not applicable.
 * @property {Smc4TypeEventEnum} tipoEvento - The type of event, either option selection or branch settlement.
 * @property {number} usuarioId - The unique identifier of the user who triggered the event.
 * @property {string | null} [PedidoSucursalId] - Optional identifier for the order-branch relationship.
 */
export interface ISmc4Log {
  pedidoId: number;
  opcionId?: number;
  sucursalesIncluidas: string;
  sucursalId: number | null;
  PedidoSucursalId?: string | null;
  estadoFincado: string | null;
  tipoEvento: Smc4TypeEventEnum;
  usuarioId: number;
}