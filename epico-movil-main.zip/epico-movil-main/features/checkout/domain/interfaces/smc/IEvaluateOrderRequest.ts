import { ItemsEvaluateOrder } from "@/features/checkout/domain/interfaces/smc/ItemsEvaluateOrder";

/**
 * Interface to evaluate order in SMC request
 *
 * @export
 * @interface IEvaluateOrderRequest
 * @property {number} registroPedidoID - Identifier for the order registration.
 * @property {number} clienteVendedorID - Identifier for the client/vendor.
 * @property {number} infoSucursalID - Identifier for the branch information.
 * @property {number} origenID - Identifier for the order origin.
 * @property {number} origenIDSMC - Identifier for the origin in SMC.
 * @property {number} [direccionID] - (Optional) Identifier for the address.
 * @property {boolean} enviarSucursal - Indicates if the order should be sent to the branch.
 * @property {number} prioridad - Priority level of the order.
 * @property {number} prontoPago - Payment term for early payment.
 * @property {boolean} esPaqueteria - Indicates if it's a package delivery.
 * @property {ItemsEvaluateOrder[]} partidas - Array of items to evaluate in the order.
 * @property {boolean | null} aplicoKms - (Optional) Identifies if the customer applied points
 */
export interface IEvaluateOrderRequest {
    registroPedidoID: number;
    clienteVendedorID: number;
    infoSucursalID?: number;
    origenID: number;
    origenIDSMC: number;
    direccionID?: number;
    ivaTotal: number;
    importeTotal: number;
    total: number;
    enviarSucursal: boolean;
    prioridad: number;
    prontoPago: number;
    esPaqueteria: boolean;
    partidas: ItemsEvaluateOrder[];
    aplicoKms?: boolean | null;
}