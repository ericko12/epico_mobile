import { IOrderDetail } from "./IOrderDetail";
/**
 * Interface for the order detail request.
 * @property {number} PCListaPrecioId - The price list ID
 * @property {IOrderDetail[]} PedidoDetalle - The order details
 */
export interface IOrderDetailRequest {
    PcListaPrecioId: number
    PedidoDetalle: IOrderDetail[];
}
