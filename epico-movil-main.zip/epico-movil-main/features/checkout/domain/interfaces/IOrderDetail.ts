/**
 * Interface para el resumen de pedido.
 * @property {number} ProductoId 
 * @property {number} Precio 
 * @property {number} Cantidad 
 * @property {number} PcPromocionId 
 * @property {number} DescuentoAdicional 
 * @property {bool}   Gratis 
 * @property {bool}  ComprarMasTarde 
 * @property {bool}  TieneToken 
 * @property {number} PrecioEspecialId 
 * @property {number} PrecioLista 
 * @property {bool} ProductoPaqueteria 
 * @property {number} TipoPrecio --Lista, Revista, Final, Dinámico 
 */
export interface IOrderDetail {
    Gratis: boolean;
    Precio: number;
    Cantidad: number;
    ProductoId: number;
    TieneToken: boolean
    PrecioLista: number;
    PcPromocionId?: number | null;
    ComprarMasTarde?: false | null;
    PrecioEspecialId?: number | null;
    DescuentoAdicional?: number | null;
    ProductoPaqueteria?: boolean | null;
    TipoPrecio: number;
}