/**
 * Payment request interface
 *
 * @interface IGetPayment
 * @property {boolean} openPay - A flag indicating whether the payment is open (true) or not (false).
 * @property {number} id - Unique identifier for the payment or transaction request.
 * @property {boolean} forcePickup - A flag indicating whether the payment requires forced pickup (true) or not (false).
 * @property {number} concessionId - The ID associated with the concession for this payment.
 * @property {boolean} forcePue - A flag indicating whether the payment requires forced PUE (true) or not (false).
 */
export interface IGetPayment {
    openPay: boolean;
    id: number;
    forcePickup: boolean;
    concessionId: number;
    forcePue: boolean;
}