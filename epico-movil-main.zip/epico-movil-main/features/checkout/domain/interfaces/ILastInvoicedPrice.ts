export interface ILastInvoicedPriceRequest {
  productoId: number;
  clienteVendedorId: number;
}

export interface ILastInvoicedPriceData {
  numeroFactura: number;
  fecha: string;
  infoSucursalId: number;
  sucursal: string;
  cantidad: number;
  precio: number;
}
