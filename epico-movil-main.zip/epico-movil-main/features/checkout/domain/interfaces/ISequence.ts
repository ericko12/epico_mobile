/**
 * @interface ISequence
 * @property {number} id - The unique identifier of the sequence.
 * @property {number} secuencia - number of sequence.
 * @property {number} cantidad - products per sequence.
 */
export interface ISequence {
    id: number;
    secuencia: number;
    cantidad: number;
    regalo: boolean | undefined;
}