export enum PatchOrderSummaryDetailsEnum {
    Cantidad = 'Cantidad',
    tieneToken = 'TieneToken',
    precio = 'Precio',
    estatusPreciosEspecialesId = 'EstatusPreciosEspecialesId',
    precioEspecialId = 'PrecioEspecialId',
    empleadoIDEjecuto = "EmpleadoIDEjecuto",
    PromocionID = 'PcPromocionId'
}