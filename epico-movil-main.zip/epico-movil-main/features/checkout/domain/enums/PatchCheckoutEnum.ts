export enum PatchOrderSummaryEnum {
    prontoPago = 'Prontopago',
    sucursalDestino = 'SucursalIdDestino',
    direccionId = 'DireccionId',
    tipoProntoPagoId = 'TipoProntoPagoId',
    estatusInternoId = 'EstatusInternoId',
    originadorId = 'OriginadorId',
    medioAtencionId = 'MedioAtencionId',
}