/**
 * Enum for consolidated types in the checkout process
 * 
 * Defines the different ways orders can be consolidated:
 * - ConsolidadoAutomatico (1): System automatically consolidates orders
 * - ConsolidadoUsuario (2): User manually consolidates orders
 * - MejorSucursal (3): Orders consolidated by best branch location
 * - PedidoDividido (4): Split order across multiple locations
 * - PedidoAutomatico (5): Automatically processed order
 *
 * Used in conjunction with TypeConsolidatedNameEnum for display names
 * 
 * @export
 * @enum {number}
 */
export enum TypeConsolidatedEnum {
    ConsolidadoAutomatico = 1,
    ConsolidadoUsuario = 2,
    MejorSucursal = 3,
    PedidoDividido = 4,
    PedidoAutomatico = 5,
}