/**
 * Enum for order statuses name
 *
 * @export
 * @enum {number}
 */
export enum StatusOrderNameEnum {
    Activo = "Activo",
    Cancelado = "Cancelado",
    Retenido = "Retenido",
    Facturado = "Facturado",
}

