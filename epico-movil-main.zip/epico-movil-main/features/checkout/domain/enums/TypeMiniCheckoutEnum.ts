
/**
 * Enum representing the different types of mini-checkouts in the system
 * 
 * - Primary: The main checkout box that serves as the base for consolidation
 * - Secondary: Additional checkout boxes that can be merged with the primary
 * - New: A newly created checkout box that hasn't been assigned a type yet
 *
 * Used to visually distinguish between different mini-checkout roles in the UI
 * and determine behavior during checkout consolidation.
 *
 * @export
 * @enum {string} The display text for each mini-checkout type
 */
export enum TypeMiniCheckoutEnum {
    Primary = 'Caja principal',
    Secondary = 'Caja secundaria',
    New = 'Nueva caja'
}