/**
 * Enum for order statuses
 *
 * @export
 * @enum {number}
 */
export enum StatusOrderEnum {
    Activo = 1,
    Cancelado = 2,
    Retenido = 3,
    Facturado = 4,
    EnviadoSMC = 5,
    OpenPay = 6
}

/**
 * Enum for order movements
 *
 * @export
 * @enum {number}
 */
export enum MovementOrderEnum {
    NotaCredito = 1,
    CambioFisico = 2,
    Efectivo = 3
}

/**
 * Enum for user types
 * 
 * @export 
 * @enum {number}
 */
export enum TypeUser {
    AgenteSQL = 3
}