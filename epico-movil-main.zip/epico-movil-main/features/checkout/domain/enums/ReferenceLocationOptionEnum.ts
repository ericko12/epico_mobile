/**
 * Enum for reference location options in shipment selection.
 */
export enum ReferenceLocationOptionEnum {
    Address = 'address',
    City = 'city',
}
