/**
 * Enumeration representing different engine division types.
 * 
 * @enum {number}
 * @readonly
 */
export enum EngineDivisionEnum {
    NOT_DIVISION = 1,
    SMC3 = 2,
    SMC4 = 3
}