/**
 * Enum para los tipos de personas que recogerán el pedido.
 * @enum {string}
 * @property {string} Cliente - Cliente.
 * @property {string} Asesor - Asesor.
 * @property {string} Otro - Otro.
 */
export enum TipoPersonaRecogera {
    Cliente = 'Cliente',
    Asesor = 'Asesor',
    Otro = 'Otro',
}