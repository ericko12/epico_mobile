
/**
 * Enum para los tipos de estatus de openpay.
 * @export
 * @enum {number}
 */
export enum StatusOrderOpenPayEnum {
    Pendiente = 1,
    Pagado = 2,
    Rechazado = 3,
    Cancelado = 4
}