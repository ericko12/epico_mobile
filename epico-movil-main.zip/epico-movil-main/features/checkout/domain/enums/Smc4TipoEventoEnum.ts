/**
 *Enumeration that defines the types of events available in the SMC4 system.
 * 
 * @enum {string}
 */
export enum Smc4TypeEventEnum {
  SELECCION_OPCION = "SELECCION_OPCION",
  FINCADO_SUCURSAL = "FINCADO_SUCURSAL",
}