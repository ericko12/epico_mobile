/**
 * Enum for consolidated type display names
 * 
 * Maps TypeConsolidatedEnum numeric values to their corresponding Spanish display names
 * Used for showing human-readable consolidated status labels in the UI
 *
 * @export
 * @enum {string}
 */
export enum TypeConsolidatedNameEnum {
    ConsolidadoAutomatico = 'Consolidado Automático',
    ConsolidadoUsuario = 'Consolidado Usuario',
    MejorSucursal = 'Mejor Sucursal',
    PedidoDividido = 'Pedido Dividido',
    PedidoAutomatico = 'Pedido Automático'
}