/**
 * Enumeration of the reasons a user can select when leaving the SMC 4.0 delivery options
 * to continue the order with the SMC 3 flow ("Procesar con SMC 3").
 *
 * @enum {number}
 * @readonly
 */
export enum SwitchToSMC3ReasonEnum {
    OPTIONS_TOO_FAR = 1,
    CUSTOMER_REQUESTS_OTHER_BRANCH = 2,
    OTHER = 3,
}
