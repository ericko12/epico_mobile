/**
 * Enum para los tipos de envío en caso de requerir.
 * @enum {string}
 * @property {string} Completo - Envío completo.
 * @property {string} Parcial - Envío parcial.
 */
export enum ShippingTypeEnum {
    Completo = 'Completo',
    Parcial = 'Parcial',
}
