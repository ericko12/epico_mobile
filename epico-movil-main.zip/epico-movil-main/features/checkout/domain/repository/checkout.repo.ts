/* eslint-disable @typescript-eslint/no-unused-vars */
import { methods } from "@/features/common/domain/enums/CRUD";
import { DBtablesEnum } from "@/features/common/domain/enums/WorkerDBTables";
import { dbStoreMessage } from "@/features/common/application/dbStoreMessage";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";
import { IResponseDB } from "@/features/common/domain/interfaces/dbStore/IResponseDB";
import { IOrderSummary } from "@/features/checkout/domain/interfaces/checkOut/IOrderSummary";

/**
 * Create or update a check out in the database.
 * @param {IOrderSummary[]} checkOut - List of orders to create or update.
 * @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves in an IResponseDB object with the result of the creation or update operation.
 */
export const createOrUpdateCheckOut = async <T>(checkOut: IOrderSummary[]): Promise<IResponseDB<IOrderSummary>> => {
    const data = checkOut.map((item) => ({
        ...item,
        detalles: item.detalles ?? undefined,
    }));
    const response = await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        upsert: true,
        method: methods.create,
        dataCreate: data,
    });
    return response;
};

/**
 * Create or update a check out detail in the database.
 * @param {IOrderSummaryDetail[]} checkOutDetail - List of details to create or update.
 * @returns {Promise<IResponseDB<IOrderSummaryDetail>>} 
 */
export const createOrUpdateCheckOutDetail = async <T>(checkOutDetail: IOrderSummaryDetail[]): Promise<IResponseDB<IOrderSummaryDetail>> => {
    const response = await dbStoreMessage<IOrderSummaryDetail>({
        db: true,
        table: DBtablesEnum.CheckoutsDetails,
        upsert: true,
        method: methods.create,
        dataCreate: checkOutDetail,
    });
    return response;
};

/**
 * Retrieves a check out by the seller and customer ID.
 * @param {number} cvId - The seller and customer ID.
 * @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves in an IResponseDB object with the result of the read operation.
 */
export const readCheckOutBySellerCustomer = async <T>(cvId: number): Promise<IResponseDB<IOrderSummary>> => {
    const response = await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        method: methods.read,
        querySelect: {
            from: DBtablesEnum.Checkouts,
            where: { clienteVendedorId: cvId },
        },
    });
    return response;
};

/**
 * Deletes a check out by its ID.
 * @param {string} orderID - The order ID.
 */
export const deleteCheckOut = async (orderID: string) => {
    const numericPedidoID = parseInt(orderID.split("-")[1]);
    await Promise.all([
        dbStoreMessage({
            db: true,
            table: DBtablesEnum.Checkouts,
            method: methods.delete,
            deleteWhere: { pedidoID: numericPedidoID },
        }),
        dbStoreMessage({
            db: true,
            table: DBtablesEnum.CheckoutsDetails,
            method: methods.delete,
            deleteWhere: { pedidoID: numericPedidoID },
        }),
    ]);
};

/**
* Reads a check out by its order ID.
* @param {number} orderId - The order ID.
* @returns {Promise<IResponseDB<IOrderSummary>>} - A promise that resolves in an IResponseDB object with the result of the read operation.
*/
export const getCheckOutByOrderId = async <T>(orderId: number): Promise<IResponseDB<IOrderSummary>> => {
    const response = await dbStoreMessage<IOrderSummary>({
        db: true,
        table: DBtablesEnum.Checkouts,
        method: methods.read,
        querySelect: {
            from: DBtablesEnum.Checkouts,
            where: { pedidoID: orderId },
        },
    });
    return response;
};