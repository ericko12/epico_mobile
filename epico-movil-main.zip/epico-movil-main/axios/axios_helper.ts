import { closeSession } from "@/features/auth/application/closeSesion";
import axios from "axios";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { PATH_AUTH } from "@/routes/paths";


/**
 * Axios instance for API requests with predefined headers and base URL.
 *
 * Sin `httpAgent`/`httpsAgent`: esta instancia solo corre en el navegador (ningún
 * route handler ni componente de servidor la importa), donde axios usa el
 * adaptador XHR y los ignora. Lo único que lograban era arrastrar los polyfills
 * de `http`/`https` de Node al bundle del cliente.
 *
 * `timeout` a 60 s: sin él, una petición colgada deja el spinner girando para
 * siempre. Se eligió 60 y no los 20-30 habituales porque hay subidas multipart
 * (digitalización, carga masiva de productos, pool) que en datos móviles pueden
 * tardar bastante y no deben cortarse.
 */
export const EPICO_API = axios.create({
    baseURL: "/api/proxy",
    withCredentials: true,
    timeout: 60000,
    headers: {
        "Content-Type": "application/json",
        "X-OrigenId": OrigenEnum.Epico,
        "X-ExodusDev": OrigenEnum.Epico
    },
});


/**
 * Axios instance for custom api for logging
 */
export const TORRECONTROL_API = axios.create({
    baseURL: process.env.NEXT_PUBLIC_BASE_TORREDECONTROL_GATEWAY,
    headers: {
        "Content-Type": "application/json",
        "X-OrigenId": OrigenEnum.Epico,
        "X-ExodusDev": OrigenEnum.Epico
    },
});


// Response interceptor to handle specific HTTP status codes
//
// ⚠️ Aquí va **un solo** interceptor para EPICO_API. Al sincronizar con el proyecto
// original quedaron dos registrados —el de allá y este— porque el bloque se movió de
// sitio y git lo leyó como una adición, no como un cambio. Con los dos puestos, ante un
// 401 corren ambos y el primero redirige incluso estando ya en Login, que es justo el
// bucle que este evita. Si en una sincronización futura vuelve a aparecer un
// `EPICO_API.interceptors.response.use` de más, es este mismo caso.
EPICO_API.interceptors.response.use(
    (response) => {
        if (response.status === 204) {
            return {
                ...response,
                data: {
                    data: null,
                    message: "No se encontraron resultados.",
                    success: true,
                    statusCode: response.status,
                },
            };
        }

        return response;
    },
    (error: unknown) => {
        if (error instanceof Error) {
            // Optional: Handle specific status codes globally
            if (axios.isAxiosError(error) && error.response?.status === 401) {
                // Evita el bucle de redirección: si ya estamos en la página de Login,
                // un 401 (p. ej. de una llamada del shell antes de autenticarse) no debe
                // volver a redirigir a /Login usando la URL actual como `?p=`, porque se
                // reencadenaría infinitamente (/Login?p=%2FLogin%3Fp%3D...).
                if (!window.location.pathname.startsWith(PATH_AUTH.login.root)) {
                    // Capture the original URL with query parameters before navigating
                    const currentUrl = window.location.pathname + window.location.search;
                    closeSession(false).finally(() => {
                        window.location.href = PATH_AUTH.login.reqByPage(currentUrl);
                    });
                }
            }
        }

        return Promise.reject(error);
    }
);



TORRECONTROL_API.interceptors.response.use(
    (response) => {
        if (response.status === 204) {
            return {
                ...response,
                data: {
                    data: null,
                    message: "No se encontraron resultados.",
                    success: true,
                    statusCode: response.status,
                },
            };
        }
        return response;
    },
    (error: unknown) => {
        if (error instanceof Error) {
            if (axios.isAxiosError(error) && error.response?.status === 401) {
                closeSession();
                const currentUrl = window.location.pathname + window.location.search;
                window.location.href = PATH_AUTH.login.reqByPage(currentUrl);
            }
        }
        return Promise.reject(error);
    }
);