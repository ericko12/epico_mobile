import React, { createContext, useContext, ReactNode, useState, useCallback, JSX } from 'react';
import Snackbar from '@mui/material/Snackbar';
import { Alert, AlertColor, AlertTitle, Typography } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import ErrorIcon from '@mui/icons-material/Error';
import CancelIcon from '@mui/icons-material/Cancel';
import { SnackbarContextProps } from './SnackBarContext.types';
import { FontWeightEnum } from '@/features/common/domain/enums/FontWeight';
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";

/**
 * Minimum time in milliseconds a notice stays on screen, whatever its length.
 *
 * @constant {number}
 */
const PERMANENCIA_MINIMA_MS = 3000;

/**
 * Time in milliseconds a long message stays on screen so it can be read.
 *
 * @constant {number}
 */
const PERMANENCIA_MENSAJE_LARGO_MS = 8000;

/**
 * Message length in characters from which the extended time applies.
 *
 * @constant {number}
 */
const LARGO_QUE_PIDE_MAS_TIEMPO = 75;

/**
 * Context for managing the state and displaying the Snackbar throughout the application.
 */
const SnackbarContext = createContext<SnackbarContextProps | undefined>(undefined);

/**
 * Snackbar context provider.
 * Wraps the application or parts of the application that need access to the Snackbar.
 * 
 * @param {ReactNode} children - The child components that will be inside the context.
 * @returns {JSX.Element} The context provider that includes the Snackbar.
 */
export const SnackbarProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [snackbarOpen, setSnackbarOpen] = useState(false);
    const [snackBarAlert, setSnackBarAlert] = useState<AlertColor>();
    const [snackbarMessage, setSnackbarMessage] = useState('');
    // The key remounts the Snackbar so each notice gets its own timer.
    const [snackbarKey, setSnackbarKey] = useState(0);

    const { isMobileExperience } = useWindowDimensions();
    // Lo único que depende del flag es de qué lado se ancla el aviso: el ancho y los
    // rellenos van por breakpoint en el `sx`, que es lo que sobrevive al primer pintado.
    const [horizontal, setHorizontal] = useState<'left' | 'center' | 'right'>('right');

    const showStyles = useCallback(() => {
        setHorizontal(isMobileExperience ? 'center' : 'right');
    }, [isMobileExperience]);

    /**
     * Function to show a Snackbar with a message and an optional type.
     * 
     * @param {string} message - The message to be displayed in the Snackbar.
     * @param {AlertColor} [type='info'] - The type of alert (success, info, warning, error).
     */
    const showSnackbar = useCallback((message: string, type: AlertColor = 'info') => {
        setSnackbarMessage(message);
        setSnackBarAlert(type);
        setSnackbarOpen(true);
        setSnackbarKey((anterior) => anterior + 1);
        showStyles();
    }, [showStyles]);

    /**
     * Determines which icon to show based on the alert type.
     * 
     * @returns {JSX.Element} The icon component to display.
     */
    const showIcon = (): JSX.Element => {
        // 45px se comen un tercio del ancho útil de un teléfono; en móvil el icono baja a
        // 28px, que sigue leyéndose y le deja el espacio al mensaje.
        const sx = { fontSize: { xs: '28px', md: '45px' }, paddingRight: { xs: '8px', md: '10px' } };

        switch (snackBarAlert) {
            case 'success':
                return <CheckCircleIcon sx={sx} />;
            case 'info':
            case 'warning':
                return <ErrorIcon sx={sx} />;
            case 'error':
                return <CancelIcon sx={sx} />;
            default:
                return <ErrorIcon sx={sx} />;
        }
    };

    /**
     * Closes the notice, ignoring `clickaway` so a click outside it does not dismiss it.
     * The close button and the timer still close it.
     *
     * @param {React.SyntheticEvent | Event} [_evento] - Close event.
     * @param {string} [motivo] - Close reason reported by MUI.
     */
    const handleClose = (_evento?: React.SyntheticEvent | Event, motivo?: string) => {
        if (motivo === 'clickaway') return;
        setSnackbarOpen(false);
    };

    return (
        <SnackbarContext.Provider value={{ showSnackbar }}>
            {children}
            <Snackbar
                key={snackbarKey}
                open={snackbarOpen}
                onClose={handleClose}
                // Notices can be closed by hand; this is only the ceiling, never below the minimum.
                autoHideDuration={Math.max(
                    snackbarMessage?.length > LARGO_QUE_PIDE_MAS_TIEMPO
                        ? PERMANENCIA_MENSAJE_LARGO_MS
                        : PERMANENCIA_MINIMA_MS,
                    PERMANENCIA_MINIMA_MS,
                )}
                anchorOrigin={{ horizontal, vertical: 'top' }}
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    // El ancho se ata al viewport. Sin esto, un mensaje del backend con un
                    // token sin espacios —los errores traen cosas como
                    // "GetDetalleProductoPorClienteQueryHandler"— estira el aviso más allá
                    // de la pantalla y, al estar centrado con translateX(-50%), se recorta
                    // por **los dos** lados: el icono de error se queda fuera de la pantalla
                    // y el texto llega pegado a los bordes, sin tarjeta ni color que lo
                    // identifiquen como error. Al ser un elemento posicionado, tampoco
                    // genera desplazamiento horizontal que lo delate.
                    width: { xs: 'calc(100vw - 24px)', md: '400px' },
                    maxWidth: '100%',
                }}
            >
                <Alert
                    icon={showIcon()}
                    severity={snackBarAlert}
                    // Con `onClose` MUI agrega la ✕: un error largo se puede quitar de
                    // encima sin esperar a que se vaya solo.
                    onClose={handleClose}
                    sx={{
                        border: '1px solid #CBD5E0',
                        // El fondo blanco anula el tinte por severidad de MUI, así que un
                        // error se veía igual que un aviso. La banda de color a la
                        // izquierda es la que lo distingue.
                        borderLeft: '6px solid',
                        borderLeftColor: theme => theme.palette[snackBarAlert ?? 'info'].main,
                        display: 'flex',
                        padding: { xs: '10px 12px', md: '25px 25px' },
                        boxShadow: '0px 4px 19px 0px rgba(0, 0, 0, 0.25)',
                        alignItems: 'center',
                        background: 'white',
                        borderRadius: '8px',
                        // En escritorio el aviso se ajusta al texto (hasta los 400px del Snackbar), como el original.
                        width: { xs: '100%', md: 'auto' },
                        // minWidth: 0 en el mensaje para que pueda encoger, y el corte de
                        // palabra para que un token larguísimo se parta en vez de empujar.
                        '& .MuiAlert-message': { minWidth: 0, overflowWrap: 'anywhere' },
                    }}
                >
                    <AlertTitle sx={{ margin: '0px' }}>
                        <Typography
                            fontWeight={FontWeightEnum.Medium}
                            color="#000000E0"
                            sx={{ fontSize: { xs: FontSizesEnum.Delta, md: 'inherit' } }}
                        >
                            {snackbarMessage || ""}
                        </Typography>
                    </AlertTitle>
                </Alert>
            </Snackbar>
        </SnackbarContext.Provider>
    );
};

/**
 * Hook to access the Snackbar context.
 * 
 * @returns {SnackbarContextProps} The object containing the `showSnackbar` function to display the Snackbar.
 * @throws {Error} Throws an error if the hook is not used within a `SnackbarProvider`.
 */
export const useSnackbar = (): SnackbarContextProps => {
    const context = useContext(SnackbarContext);

    if (!context)
        throw new Error('useSnackbar must be used within a SnackbarProvider');

    return context;
};
