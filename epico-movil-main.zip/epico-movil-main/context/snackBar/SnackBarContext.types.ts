import { AlertColor } from "@mui/material";

/**
 * Interface for Snackbar context properties.
 */
export interface SnackbarContextProps {
    /**
     * Function to show a Snackbar with a message and an optional type.
     * 
     * @param {string} message - The message to be displayed in the Snackbar.
     * @param {AlertColor} [type='info'] - The type of alert (success, info, warning, error).
     */
    showSnackbar: (message: string, type?: AlertColor) => void;
}