# Skills del Modelo Operativo Epico (V2.1)

Las 5 skills del modelo, listas para commitear. Una skill de Claude Code es una
carpeta con un `SKILL.md` adentro: el frontmatter (`name`, `description`) le dice a la
IA cuándo usarla, y el cuerpo son las instrucciones que ejecuta igual para todos.
**No se descargan de ningún lado — este paquete ES la fuente.**

## Qué hace cada una

| Skill | Qué hace | Cuándo | Etapa |
|---|---|---|---|
| `inicio-tarea` | Desde la clave del issue **localiza la página de Confluence** de la Spec (regla de `ENLACE_SPEC_CONFLUENCE.md`), verifica el gate (página en `Ready for Dev`), crea la rama, **copia las páginas verbatim** como snapshots (funcional · UX · proyecto, con hash), genera `plan.md`, propone subtareas | Al arrancar toda tarea: `/inicio-tarea EF-50620` (y `--refresh` si la página cambió) | E4 |
| `cierre-tarea` | Redacta la bitácora (≤6 líneas), la publica como comentario del issue y avisa si el hash de alguna página derivó | Al final de TODA sesión, cualquier rol | E4–E5 |
| `contrato-api` | Redacta/extiende `contracts/openapi.json` según los estándares (RN-*, examples, x-eventos, aditivo) | En Definición, antes de construir | E3 |
| `front-feature` | Cliente generado + mocks del contrato + pantalla desde el snapshot UX (UX-VIEW/COMP/STATE/MSG) | Tareas de front, con rama abierta | E4 |
| `nuevo-microservicio` | Exige ADR, genera esqueleto de la plantilla, CLAUDE.md, contrato inicial y registro en el catálogo | Solo cuando extender no es viable | E3–E4 |

## Instalación — dónde va cada una

Se commitean en `.claude/skills/<nombre>/SKILL.md` de cada repo (llegan al equipo
con `git clone`; Claude Code las detecta solo y se invocan con `/nombre`):

| Repo | Skills que se commitean ahí |
|---|---|
| Repo del front (`epico-front`) | `inicio-tarea` · `cierre-tarea` · `front-feature` |
| Plantilla de microservicios (→ nace en cada `ms-*`) | `inicio-tarea` · `cierre-tarea` · `contrato-api` |
| `ms-*` existentes que toque el piloto | las mismas 3 de la plantilla (copiarlas) |
| `base-docs` | `nuevo-microservicio` (se corre desde ahí al crear servicios) — y es el **hogar canónico de las 5** (`base-docs/skills/`), para que tengan una sola fuente versionada |

**Vía complementaria:** el administrador de Claude Teams puede desplegar skills a toda
la organización desde la consola de administración — útil para que también estén en la
app de Claude. La vía del repo es la obligatoria: es la que versiona por MR.

## Ajustes antes del primer uso (10 minutos)

1. Reemplazar los `<marcadores>` que quedan: `<rama-principal>` (main/master),
   `<comando de generación del repo>` (cliente TS del front) y
   `<comando/proceso de scaffold de la plantilla>` (nuevo ms).
2. **Llenar las líneas `Jira:` y `Confluence:`** del `CLAUDE.md` de cada repo: sitio,
   nombre del tipo de issue de la Spec (`#Partial release (Spec)` en `EF`), espacio de
   Confluence (`PE`) y página de la Spec de Proyecto. Y **enlazar cada página `SPEC-…` a
   su issue** (o poner el folio al inicio del título) — `ENLACE_SPEC_CONFLUENCE.md §6`.
   Sin enlace, `inicio-tarea` cae a la vía manual y pide la URL.
3. Con el **MCP de Atlassian** conectado (`.mcp.json` del repo; cubre Jira **y**
   Confluence con una sola autorización), las skills resuelven todo solas: leen el issue
   por su clave (`EF-50620` — autocontenida, sirva en el proyecto que sea), llegan a su
   página, la copian verbatim con hash, comentan la bitácora y crean subtareas. Sin MCP
   funcionan en modo manual: piden la URL y el contenido de la página y entregan la
   bitácora lista para pegar. **Nunca piden credenciales en el chat.**
4. Prueba de humo (T1 de la Academia): correr el circuito completo con una Spec real
   en una rama de prueba — issue enlazado a su página en `Ready for Dev`,
   `/inicio-tarea <CLAVE>`, CI validando los snapshots y `/cierre-tarea` publicando la
   bitácora.

## Reglas de mantenimiento

- Las skills implementan las **plantillas de `base-docs/plantillas/`** — esa es la
  fuente única de formato. Cambiar una plantilla = revisar la skill que la aplica,
  en el mismo MR (regla 5 del CLAUDE.md de base-docs).
- Cambios a una skill: por MR, dueños Dev líder + Arquitecto. Si cambia el formato
  que produce, sube la versión del string `generado_por` (v1.1 → v1.2) — el CI y los
  humanos sabrán con qué versión se generó cada archivo.
- Las skills **nunca escriben en las páginas de la Spec**: proponen el texto, dicen en
  qué sección de qué página va y quién lo aplica (BA / UX / PO). La IA propone, la
  persona decide.
- La **regla de enlace** es parte del contrato: si cambia la convención de títulos, la
  cabecera de las plantillas o la forma de enlazar el issue, se actualiza
  `ENLACE_SPEC_CONFLUENCE.md` **en el mismo MR** que la skill.
- Si una skill y `base-docs` se contradicen, **gana base-docs** — y se corrige la
  skill.

---
*Skills v1.4 · Septiembre 2026 · Modelo Operativo V2.1 (ADR-005: la Spec vive en su
página de Confluence enlazada al issue, la rama congela, la IA nunca adivina).*
