---
name: contrato-api
description: >-
  Redacta o extiende el contrato OpenAPI en JSON (contracts/openapi.json) de un
  microservicio a partir de la Spec, siguiendo los estándares de API de la
  plataforma: errores RN-* con mensajes textuales, examples por operación, eventos
  en x-eventos, cambios aditivos si el servicio es compartido. Úsala en Definición
  (Etapa 3), antes de que nadie construya.
---

# contrato-api — congelar la frontera entre front y back

Uso: `/contrato-api EF-50620` (la clave de la Spec, dentro del repo del ms dueño)

El contrato se negocia **una vez, por escrito**. De sus `examples` el front genera
cliente y mocks; el back lo implementa; el CI falla si el código deriva. Cambiarlo
después es MR aprobado — nunca "se arregla en el código".

## 0 · Verificaciones

1. Estás en el repo del **servicio dueño del dominio** (verifica contra
   `base-docs/productos/epico/CATALOGO_SERVICIOS.md`). Si el dominio no tiene dueño claro o
   apunta a servicio nuevo: detente — eso es `/nuevo-microservicio` y requiere ADR.
2. ¿El servicio es **compartido** (columna ⚠ del catálogo)? Entonces TODO cambio debe
   ser aditivo. Tenlo presente en cada paso; si algo no puede ser aditivo, detente y
   repórtalo (implica `/v2` + ADR + migración de consumidores — decisión de Arquitecto).
3. Insumos de la Spec Funcional: del `spec.snapshot.md` si ya existe en la rama; si
   no, de **su página de Confluence**, resuelta desde la clave con la regla de
   `base-docs/docs/ENLACE_SPEC_CONFLUENCE.md` (ADR-005) — con MCP de Atlassian la lees
   en Markdown; sin MCP, pide al usuario que pegue la página. Lo que necesitas: flujo y
   excepciones EX-* (§4) · requisitos RF-*, reglas RN-*, datos DAT-* y permisos PER-*
   (§5) · criterios AC-* (§6) · NFR (§7) · dependencias DEP-* (§3). Si la página está
   en `Borrador`, dilo: el contrato puede redactarse, pero **no se congela** hasta que
   la Spec esté en `Ready for Dev`.
4. Lee el `contracts/openapi.json` actual completo antes de proponer nada.

## 1 · Redacción — estándares obligatorios

Fuente canónica: `base-docs/docs/ESTANDARES_API.md`. Resumen operativo:

- **Rutas:** recursos en español, plural, kebab-case; versión en la ruta (`/v1/...`);
  acciones de dominio con POST (`/{id}/check-in`); nunca verbos sueltos en la ruta.
- **Errores:** cuerpo estándar `{ codigo, mensaje, detalle }`. Códigos HTTP: 409
  conflicto de estado · 422 regla de negocio · 400/401/403/404 los usuales.
  El `codigo` es la RN-* de la Spec (prefijado con la clave —`EF-50620.RN-02`— si el
  servicio compartido implementa reglas de varias specs) y el `mensaje` es el **texto TEXTUAL**
  de los AC/EX de la funcional — las mismas palabras que aprobó el equipo. Si la Spec
  UX define el `UX-MSG` correspondiente, debe coincidir; una discrepancia se reporta
  como `[NEEDS CLARIFICATION]`, no se resuelve eligiendo.
- **Datos:** fechas ISO-8601 UTC; camelCase; ids opacos; paginación `?page=&limit=`
  con `meta`.
- **Idempotencia:** toda escritura que registra algo es idempotente por clave natural
  (p. ej. actividad+operación) — decláralo en la `description` de la operación.
- **`examples` en CADA operación:** caso feliz con datos realistas, variante vacía si
  aplica, y un example por cada error RN-*. De aquí salen los mocks del front — un
  contrato sin examples está incompleto.
- **Eventos RabbitMQ:** también son contrato. Naming `<contexto>.<entidad>.<accion>`
  en pasado, schema versionado, documentados en la extensión `x-eventos` de este
  mismo archivo.

Referencia de cómo se ve uno terminado: el ejemplo dorado
`base-docs/ejemplos/EF-50575-checkin-checkout/contracts/openapi.json`.

## 2 · Verificación antes de proponer el MR

Corre mentalmente (y dilo en el resumen) el checklist del Arquitecto:

- ▢ ¿Servicio compartido? → ¿el cambio es 100 % aditivo? (nada renombrado, quitado
  ni con tipo cambiado)
- ▢ Errores de reglas con su `RN-*` y el mensaje textual de la Spec
- ▢ Idempotencia definida para toda escritura
- ▢ `examples` en cada operación
- ▢ Eventos nuevos en `x-eventos` **y** anotados para registrarse en
  `CATALOGO_SERVICIOS.md` en el mismo MR
- ▢ La versión de `info.version` sube (aditiva = minor)
- ▢ El `contracts/openapi.json` congelado coincide con el que expondrá el servicio
  .NET 10 en runtime (`/openapi/v1.json`, generado por `Microsoft.AspNetCore.OpenApi`)
  — esa comparación la corre el CI del `ms-*` ya en Desarrollo, no aquí; este ítem es
  para dejar dicho en el resumen que el contrato quedó listo para esa verificación
  posterior, no para correrla ahora.

Valida la sintaxis del JSON antes de committear (parsear, no solo mirar).

## 3 · MR

- Rama `<CLAVE>/contrato` (p. ej. `EF-50620/contrato`) — **nace de una release, igual
  que toda rama de Spec** (ADR-002): si la rama de la Spec ya existe, usa su misma
  release; si no, pregunta al humano cuál (u ofrece crear una nueva, pidiendo el
  nombre). Commit `EF-50620: contrato — <resumen del cambio>`.
- El MR apunta a **esa misma release** (nunca a `main`) y debe tocar `contracts/` (y el
  catálogo si hay eventos/servicios nuevos), nada más. Aprobador: **Arquitecto**. Al mergear queda **congelado**: anota la fecha de
  congelado en el plan.md (§4) de la rama de la Spec.

## Reglas duras

- El contrato es la fuente de verdad: el código se ajusta al contrato, nunca al revés.
  El JSON que el servicio .NET 10 expone en runtime (`/openapi/v1.json`) **no es una
  fuente alterna**: es solo lo que el CI compara contra este archivo para detectar
  deriva. Si difieren, se corrige el código — nunca se acepta el runtime como si fuera
  el contrato.
- Nada de endpoints, campos o eventos que la Spec no pida — si crees que falta algo,
  propónlo como pregunta a la Spec, no como sorpresa en el JSON.
- Los mensajes de error jamás se redactan aquí: se **copian** de los AC/EX de la
  funcional. Si la Spec no trae el mensaje, está incompleta — repórtalo al BA.

## Al terminar, imprime

El resumen del cambio (endpoints/eventos, aditivo sí/no), el resultado del checklist,
y el recordatorio: al mergear, el front puede generar cliente + mocks (`/front-feature`)
y el back arranca la implementación — en paralelo.
