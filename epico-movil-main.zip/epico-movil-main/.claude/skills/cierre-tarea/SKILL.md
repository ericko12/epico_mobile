---
name: cierre-tarea
description: >-
  Cierra la sesión de trabajo: redacta la bitácora de máximo 6 líneas (hecho,
  decisiones, sigue, bloqueos, MRs) y la publica como comentario del Work Item de la
  Spec en Jira. Úsala al final de TODA sesión de construcción, de cualquier rol —
  es el traspaso para la siguiente persona o IA.
---

# cierre-tarea — el traspaso de la sesión

Uso: `/cierre-tarea`

La bitácora existe para que mañana —tú, otro dev o la IA— arranque en 2 minutos.
Es un **traspaso, no un reporte**: si pasa de ~6 líneas, sobra detalle.

## 1 · Reúne la evidencia (no le preguntes al usuario lo que puedes ver)

1. Identifica la Spec por el nombre de la rama actual (`<CLAVE>/...`, p. ej.
   `EF-50620/ligar-pedido-propuesta`) — esa clave es el issue de la Spec (tipo
   `#Partial release (Spec)`) donde va la bitácora. Si la rama no sigue el patrón,
   pregunta de qué Spec fue la sesión.
2. Junta: `git log` de la sesión (commits de hoy en esta rama), `git status`, estado
   de los MRs si `glab` está disponible, y lo trabajado en esta conversación
   (tareas Txx tocadas, decisiones discutidas, dudas que surgieron).

## 2 · Redacta con el formato exacto

Fuente canónica: `base-docs/plantillas/plantilla-bitacora.md`.

```markdown
**📓 Bitácora · <AAAA-MM-DD am/pm> · <Rol/Nombre> (+ Claude Code)**

- **Hecho:** <qué se completó, con referencia a tareas Txx>
- **Decisiones:** <las de la sesión, con enlace — o "ninguna">
- **Sigue:** <la siguiente acción concreta>
- **Bloqueos:** <qué y quién lo destraba — o "ninguno">  **MRs:** <!nn estado>
```

Reglas de redacción:

- "Hecho" referencia tareas del plan (`T04`), no vaguedades ("avancé en el back").
- "Sigue" es UNA acción concreta que cualquiera podría retomar.
- **Filtro de decisiones:** si alguna decisión de la sesión cambia el
  COMPORTAMIENTO del producto, NO va en la bitácora — va a la Spec en Jira ese
  mismo día (dueño: BA). En la bitácora solo queda la referencia. Las decisiones
  técnicas locales sí van aquí (o al plan.md si afectan el enfoque).
- Las dudas detectadas se registran como `[NEEDS CLARIFICATION]` en la **sección de
  Pendientes** de la página que corresponda: la Funcional (§9, dueño BA) para negocio;
  la UX (§14, dueño UX) para experiencia. **La skill no escribe en las páginas de la
  Spec**: redacta el texto exacto, dice en qué sección de qué página va y quién lo
  lleva, y lo deja anotado en la bitácora ("pendiente propuesto para SPEC-F1-003 §9 —
  lo aplica el BA").

## 3 · Valida con el humano y publica

3. Muestra el borrador al usuario para ajuste rápido (nombre/rol correctos, nada
   confidencial, nada de más).
4. Publica:
   - **Con MCP de Atlassian:** agrégala como comentario del issue de la Spec cuya clave
     nombra la rama (la clave es autocontenida: no hay proyecto que resolver). Va en
     **comentario** del issue, nunca en la página de Confluence: esa es de la
     especificación.
   - **Sin MCP:** entrega el texto listo para pegar y pide confirmación de que quedó
     publicado — la sesión no está cerrada hasta que la bitácora está en Jira.
5. Si hay MCP y subtareas: propone actualizar su estado (Txx terminadas → Done).

## 4 · Chequeo de salida

Antes de despedirte, verifica y reporta:

- ¿Pruebas y lint en verde localmente? ¿Escenarios `@<CLAVE>` de la tarea pasando?
- ¿El `contenido_hash` de cada snapshot sigue coincidiendo con su página de Confluence
  (regla de `ENLACE_SPEC_CONFLUENCE.md §5`)? Si la Spec derivó durante la sesión, dilo
  en la bitácora — es lo primero que necesita saber quien retome. Sin MCP, pregunta;
  no asumas.
- ¿Commits pusheados y MR actualizado?
- ¿Quedó algo sin escribir que mañana costaría 10 minutos re-descubrir? (regla 8)
  → entonces falta una línea en la bitácora o en el plan. Agrégala ahora.

## Reglas duras

- Una entrada por sesión de trabajo, siempre en el Work Item de la Spec — nunca en
  documentos sueltos ni en el chat.
- No infles la bitácora: máximo ~6 líneas.
- No cierres sesión sin bitácora publicada (o entregada para pegar). Sin excepciones,
  incluido UX.
