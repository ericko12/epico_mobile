---
name: nuevo-microservicio
description: >-
  Crea un microservicio nuevo desde la plantilla Epico: exige el ADR que lo
  justifica, genera el esqueleto, escribe su CLAUDE.md y su contrato inicial, y lo
  registra en CATALOGO_SERVICIOS.md en el mismo MR. Úsala SOLO cuando extender un
  servicio existente no es viable — crear es la excepción, no el default.
---

# nuevo-microservicio — crear con justificación, nacer con reglas

Uso: `/nuevo-microservicio ms-<nombre> "<propósito en una línea>"`

## 0 · El gate — sin ADR no hay servicio

1. **Regla del modelo:** el default es extender al servicio dueño del dominio. Crear
   uno nuevo exige un **ADR aceptado** que lo justifique (dueño: Arquitecto).
2. Pide la referencia del ADR (`ADR-XXX`). Si no existe: detente y ofrece redactar el
   borrador con `base-docs/plantillas/plantilla-adr.md`, que va en
   `base-docs/productos/<producto>/adr/` (es una decisión de esa plataforma, no del
   modelo) — contexto, decisión,
   consecuencias (+/−) — para que el Arquitecto lo apruebe ANTES de continuar.
   No generes ni un archivo del servicio sin ADR aceptado.
3. Verifica en `base-docs/productos/epico/CATALOGO_SERVICIOS.md` que no exista ya un servicio
   dueño de ese dominio (regla 10: buscar antes de crear).

## 1 · Esqueleto desde la plantilla

4. Genera el repo con el mecanismo de la plantilla Epico
   (`<comando/proceso de scaffold de la plantilla, p. ej. dotnet new epico-ms>`).
   Estructura esperada: `src/<Ms>.Api / .Application / .Domain / .Infrastructure`,
   `contracts/openapi.json`, `tests/` con `features/`.
5. La plantilla ya trae `CLAUDE.md` y `.claude/rules/contracts.md`. Ajusta los
   `<marcadores>` del `CLAUDE.md`: nombre, propósito (la línea del argumento), dueño,
   y la línea de compartido: ⚠ **SÍ | NO es compartido** — pregunta al usuario si
   otros sistemas además de Epico lo van a consumir.

## 2 · Contrato inicial

6. Esqueleto de `contracts/openapi.json` con `info` (title = ms-<nombre>, versión
   0.1.0, description con el propósito y la marca de compartido), `servers` vía
   gateway, y los primeros endpoints SOLO si ya hay una Spec que los defina — en ese
   caso corre el procedimiento de `/contrato-api` para redactarlos. Sin Spec, el
   contrato queda en esqueleto: aquí no se inventan APIs.

## 3 · Registro — «si no está en el catálogo, no existe»

7. En el MISMO MR que crea el servicio, agrega su fila a
   `base-docs/productos/epico/CATALOGO_SERVICIOS.md`: servicio, propósito, dueño, ruta del
   contrato, consumidores conocidos, ¿compartido?. Si nace con eventos, regístralos
   también en la tabla de eventos.
8. Anota las tareas de plataforma que NO hace esta skill y quedan como subtareas
   explícitas con dueño: ruta en **Ocelot** (el servicio no se expone directo),
   alta en el pipeline de despliegue (imagen → Swarm), variables de entorno y
   secretos (jamás en el repo).

## 4 · Convenciones que nacen activadas (de la plantilla — verifícalas)

- Logs estructurados → Elastic con `op`, usuario y correlación.
- Health checks expuestos; cache Redis con TTL explícito; escrituras idempotentes.
- Eventos RabbitMQ `<contexto>.<entidad>.<accion>`; pruebas Reqnroll en
  `tests/features/` con tags `@SPEC @RN`.
- Ramas `<CLAVE-JIRA>/<breve>` (p. ej. `EF-50620/…`); toda sesión abre con `inicio-tarea`
  (que congela la página de Confluence de la Spec — ADR-005) y cierra con `cierre-tarea`.
- `Program.cs` ya registra `builder.Services.AddOpenApi()` / `app.MapOpenApi()`
  (paquete nativo `Microsoft.AspNetCore.OpenApi`, .NET 10): el servicio expone su
  propio OpenAPI generado en `/openapi/v1.json`. Ese documento **no reemplaza**
  `contracts/openapi.json` — es contra lo que el CI lo compara para detectar deriva
  (ver `contrato-api`, checklist de la sección 2).

## Reglas duras

- Sin ADR aceptado, esta skill no crea nada. Sin excepción "temporal".
- El registro en el catálogo va en el mismo MR — no "después".
- Si el repo generado se desvía de la plantilla en algo, anótalo en su `CLAUDE.md`
  para que la IA no asuma la estructura estándar.

## Al terminar, imprime

Resumen: repo creado, ADR de respaldo, fila del catálogo agregada, y la lista de
tareas de plataforma pendientes con su dueño sugerido (Ocelot, despliegue, secretos).
