---
name: front-feature
description: >-
  Construye una tarea de front de una Spec desde sus DOS verdades congeladas: el
  spec-ux.snapshot.md (pantallas UX-VIEW, componentes UX-COMP, estados UX-STATE,
  textos UX-MSG) y el spec.snapshot.md + contrato (reglas, datos, mensajes RN-*).
  Genera el cliente tipado, los mocks derivados de los examples y arma la pantalla.
  Úsala en el repo del front, con la rama de la Spec ya abierta por inicio-tarea.
---

# front-feature — construir el front desde las Specs, no desde la imaginación

Uso: `/front-feature EF-50620 T0X` (la clave de la Spec y la tarea del plan)

División de verdades: la **Spec Funcional** (snapshot) define QUÉ hace la solución;
la **Spec UX** (snapshot UX) define CÓMO la vive el usuario; el **contrato** define los
datos. Tu trabajo es materializar las tres — no completarlas con inventiva.

## 0 · Verificaciones

1. Estás en la rama `<CLAVE>/...` y existen `spec.snapshot.md` y `plan.md`. Si no:
   detente — primero corre `/inicio-tarea <CLAVE>`.
2. **Chequeo de deriva (ADR-005).** Vuelve a traer la página de Confluence que indica
   el `origen:` de cada snapshot (funcional y UX), recalcula el hash con la regla de
   `base-docs/docs/ENLACE_SPEC_CONFLUENCE.md §5` y compáralo con el `contenido_hash` del
   front matter. Si alguno no coincide, **detente**: la Spec cambió con construcción en
   vuelo. La decisión es humana: terminar contra el snapshot actual o
   `/inicio-tarea <CLAVE> --refresh`. Nunca construyas contra un snapshot que ya sabes
   desactualizado sin que alguien lo decida. (Sin MCP, pregunta al usuario si la página
   se movió — no asumas.)
3. **¿La Spec tiene UX?** Si el plan o la funcional referencian una Spec UX:
   - Existe `spec-ux.snapshot.md` en la rama → esa es tu fuente de experiencia.
   - No existe → la UX no estaba lista al arrancar. **Alto para tareas de front**:
     pide correr `/inicio-tarea <CLAVE> --refresh` cuando la página UX pase a
     `Ready for Dev`.
   - La Spec no tiene UX enlazada → construye con las reglas de la casa (modo sin
     UX-Spec, abajo).
4. Localiza el contrato (enlace en la funcional §8 Referencias o plan §4) y confirma que está
   **congelado**. Sin contrato congelado no hay front: el paso siguiente sería
   `/contrato-api`, no inventar datos "mientras tanto".
5. Lee la tarea `T0X` en el plan §11 — eso y solo eso es el alcance de esta sesión.
6. Revisa el snapshot UX: si trae `[NEEDS CLARIFICATION]` que toque tu tarea, **alto**
   — se resuelve en la Spec UX (dueño UX), no improvisando en el código.

## 1 · Cliente tipado

7. Genera/actualiza el cliente desde el contrato con el comando del repo
   (`<comando de generación del repo>`). El código generado vive en
   `src/api/generated/` y **jamás se edita a mano** — si algo está mal ahí, está mal
   el contrato.

## 2 · Mocks (reglas de `.claude/rules/mocks.md` — se cargan solas)

8. Estructura: `src/mocks/<CLAVE>/fixtures.ts` + `handlers.ts` (MSW por endpoint) —
   el directorio se llama con la clave de la Spec (`src/mocks/EF-50620/`). Un
   directorio por spec; no mezclar.
9. **Todo fixture deriva de los `examples` del contrato** — cópialos, no los redactes.
   Cubre los estados que la pantalla necesita, con el `codigo` y `mensaje` EXACTOS
   del contrato para los errores de regla.
10. Los handlers respetan los códigos HTTP del contrato (409/422/…): el front debe
   comportarse idéntico con mock que con servicio real.

## 3 · La pantalla — el snapshot UX manda

Con `spec-ux.snapshot.md` en la rama, cada bloque del documento es una instrucción:

10. **`UX-VIEW-*`** — qué construir: propósito, entrada, salida y referencia Figma de
    cada vista. Tu tarea T0X normalmente corresponde a una o dos vistas; no toques las
    demás.
11. **Jerarquía (§4 UX)** — qué es primario/secundario y cuál es LA acción principal
    de la vista. La composición sale de aquí y del Figma, no de tu criterio.
12. **`UX-COMP-*`** — los componentes, con variante, propiedades y estados requeridos.
    Regla **Reutilizar > Extender > Crear**: usa el componente DS indicado; si la Spec
    trae `UX-NEW-*` (justificado), créalo Y **regístralo en
    `base-docs/productos/epico/SISTEMA_DISENO.md` en el mismo MR** — así el DS gobernado se
    construye spec a spec. Nunca inventes un componente que la Spec UX no pida.
13. **`UX-INT-*`** — interacciones y comportamientos (qué dispara qué, qué percibe el
    usuario, bajo qué condición). Implementa exactamente esas; las no documentadas y
    no evidentes son `[NEEDS CLARIFICATION]`, no decisiones tuyas.
14. **`UX-STATE-*`** — los estados de la experiencia (inicial · vacío · carga · error ·
    éxito · deshabilitado, los que la Spec defina). **Sustituyen a la regla genérica de
    "4 estados"**: cubre todos los que el snapshot UX declare, con su condición,
    indicador y comportamiento.
15. **`UX-DAT-*`** — formularios: componente, etiqueta, placeholder, obligatoriedad,
    validación visual y mensaje de error **tal cual**. (La regla funcional del dato
    sigue viviendo en la funcional; aquí solo su presentación.)
16. **`UX-MSG-*` / `UX-TXT-*`** — textos de interfaz EXACTOS, misma regla que los
    mensajes `RN-*`: se copian, no se redactan. Sin texto definido = pendiente a la
    Spec UX.
17. **`UX-RESP-*` / `UX-ACC-*` / `UX-MOTION-*`** — responsive, accesibilidad y motion:
    implementa las condiciones particulares documentadas; los estándares transversales
    se heredan del proyecto/DS.

**Modo sin UX-Spec** (la capacidad no tiene participación UX): aplican las reglas de
la casa — componentes del catálogo `SISTEMA_DISENO.md` (buscar antes de crear,
`PROPUESTA-DS` para nuevos), los **4 estados** (éxito · vacío · error · carga) y los
mensajes textuales de los AC/EX de la funcional (§4 y §6).

## 4 · Pruebas

19. e2e Playwright de la tarea con tag `@<CLAVE>` (p. ej. `@EF-50620`): el flujo feliz
    + un error de regla como mínimo; si el snapshot UX define `UX-STATE` o `UX-INT`
    verificables, cúbrelos. Los escenarios salen del `behavior.feature` y del snapshot
    UX — no se inventan.
20. Corre lint + pruebas antes de dar la tarea por lista.

## Definición de terminado (front)

▢ vistas de la tarea implementadas según sus `UX-VIEW` (o el alcance del plan, sin UX)
▢ estados del snapshot UX cubiertos (o los 4 genéricos, sin UX)
▢ cero datos hardcodeados — todo del cliente generado / fixtures del contrato
▢ componentes según `UX-COMP` · `UX-NEW` registrados en `SISTEMA_DISENO.md` (mismo MR)
▢ textos de `UX-MSG`/`UX-TXT` y mensajes `RN-*` tal cual
▢ e2e `@<CLAVE>` en verde
▢ el `contenido_hash` de cada snapshot sigue coincidiendo con su página (sin deriva)
▢ mock NO borrado al integrar — queda para pruebas y para el siguiente

## Reglas duras

- No inventes componentes, comportamientos ni textos cuando existe definición
  gobernada — y cuando no existe, el camino es `[NEEDS CLARIFICATION]` en la sección de
  Pendientes de la página de la Spec UX (§14, dueño UX) o de la funcional (§9, dueño
  BA), nunca una decisión silenciosa.
- No modifiques reglas funcionales para resolver decisiones visuales (ni al revés).
- El alcance es la tarea T0X: lo que descubras fuera de ella va al plan o a la Spec.
- Cierra la sesión con `/cierre-tarea`.
