---
name: catalogar-dependencias
description: >-
  Analiza las dependencias salientes de un repo de código (llamadas HTTP a un
  gateway/microservicios, colas de eventos) y propone filas nuevas para el
  CATALOGO_SERVICIOS.md del producto en base-docs, agrupando por dominio cuando
  todo pasa por un único gateway y sin inventar dueño ni contrato que el código no
  declara. Úsala para poner al día el catálogo de un producto, auditar de qué
  depende un repo, o incorporar un repo nuevo al modelo operativo.
---

# catalogar-dependencias — documentar lo que un repo consume, sin inventar lo que no ve

Uso: `/catalogar-dependencias` (corre en la raíz del repo de código que quieres analizar)

Este repo es un **consumidor**: ve endpoints de un gateway, no el código de los
microservicios reales que hay detrás. La regla dura de todo este skill es la misma
que la del catálogo: **si el código no lo dice, va como `TODO` — nunca se adivina.**
La IA propone filas candidatas; el Arquitecto decide si son reales
(`base-docs/CLAUDE.md`, regla 1).

## 0 · Verificaciones

1. Confirma que hay una carpeta `features/` en la raíz — si no, este skill no aplica
   a este repo (no es un consumidor de estilo Epico) y hay que preguntar al usuario
   cómo adaptar la búsqueda.
2. Localiza `base-docs/` para saber dónde vive el catálogo: primero como subcarpeta
   del repo actual; si no está, sube directorios hasta encontrarla o pregunta la
   ruta. Sin `base-docs/` no hay dónde escribir — el skill puede seguir hasta el
   reporte (paso 2) pero no puede aplicar el paso 3.
3. Determina el **producto**: lee la línea `Producto:` del `CLAUDE.md` del repo. Si
   no existe, lista las carpetas de `base-docs/productos/*/` y pregunta al usuario
   cuál corresponde — y sugiere agregar la línea `Producto:` al `CLAUDE.md` del repo
   para que la próxima corrida no tenga que preguntar (proponlo, no lo escribas sin
   permiso).
4. Lee el `CATALOGO_SERVICIOS.md` completo del producto encontrado. Todo lo que ya
   tiene Dueño/Contrato llenos es verdad confirmada por el Arquitecto — **nunca se
   sobreescribe** en este flujo, solo se puede *agregar* el repo actual a la columna
   Consumidores si falta.
5. Pregúntale al usuario: *"¿Qué API gateway hay detrás de la variable de
   transporte (ej. `BASE_APIGATEWAY`) y tienes su repo (o al menos su
   `ocelot.json`) en esta máquina? Si me das la ruta, cruzo sus rutas reales con lo
   que detecto en el código."* Es un plus, no un requisito:
   - Si da una ruta (a la carpeta del repo o directo al archivo) → pásala como
     segundo argumento en el paso 1.
   - Si no la tiene a la mano, o prefiere no darla → sigue exactamente igual que
     hasta ahora, sin ese cruce. No insistas ni bloquees el flujo por esto.
   - Hoy el cruce solo entiende **Ocelot** (`Routes`/`ReRoutes` con
     `UpstreamPathTemplate`). Si el gateway es otra tecnología, dilo y sigue sin el
     cruce — no hay soporte todavía para otros formatos.

## 1 · Extraer candidatos del código

Corre el extractor de este mismo skill contra la raíz del repo. El segundo
argumento (ruta al gateway) es opcional — solo inclúyelo si el usuario la dio en el
paso 0.5:

```bash
node .claude/skills/catalogar-dependencias/extraer-dependencias.mjs . [ruta-del-gateway]
```

El script solo lee código — no llama red, no modifica nada — e imprime, por
feature:

- **Microservicio declarado en JSDoc**, cuando el propio código ya lo dice (ej.
  `Service for consuming the Branch microservice`, `Servicio del microservicio
  \`IApymsa.Search\``). Esta es la señal más confiable: es el desarrollador
  original nombrando explícitamente el servicio real, no una inferencia por URL.
  Cuando **dos features distintas declaran el mismo nombre** (ej. `customer` y
  `teleMarketingLead` ambas dicen `ClientService`), es evidencia fuerte de que
  comparten un microservicio — agrúpalas en una sola fila candidata.
- **Prefijos de recurso vistos** en los `*Url.ts` de la feature (ej. `Sucursales`,
  `ClienteVendedor`), para las features que no tienen JSDoc con el nombre. Esto es
  **mucho menos confiable**: dos features pueden tocar el mismo recurso
  (`Clientes` aparece tanto en `customer` como en `products`) sin ser el mismo
  microservicio, o dos nombres distintos pueden ser el mismo servicio. Trátalo como
  punto de partida para leer el código, no como respuesta.
- **Bases HTTP fuera de `EPICO_API`**: variables de entorno `*_BASE`/`*_URL` o
  `axios.create(...)` fuera del helper compartido. Estas SÍ son candidatas a fila
  propia (no agrupada) porque no comparten transporte con el resto — ver
  `IAPYMSA_SEARCH_BASE` en este mismo repo como ejemplo ya documentado en
  `CLAUDE.md` (el buscador nuevo tiene su propio switch de transporte, ver
  `features/products/application/service/searchProducts.services.ts`).
- **Confirmado por gateway** (solo si diste la ruta en el paso 0.5): el script
  cruzó el prefijo de recurso contra las `UpstreamPathTemplate` de Ocelot y
  encontró a qué host/`ServiceName` real lo manda. Esto sube la fila de
  "candidato" a "identidad de servicio confirmada" — pero el match es por
  subcadena de ruta, así que igual pasa por la verificación manual del paso 2
  antes de tratarlo como bueno.

## 2 · Verificar cada candidato antes de proponerlo

El script agrupa por texto, no entiende el negocio. Antes de escribir nada:

1. Para cada nombre declarado en JSDoc, `Read` el archivo `*.services.ts` completo
   (no solo el comentario) y confirma que de verdad describe un servicio distinto,
   no una nota vieja o copiada de otro archivo por costumbre.
2. Para cada match "confirmado por gateway", abre el `ocelot*.json` real y lee la
   ruta completa (verbo, plantilla completa, no solo el fragmento que hizo match)
   para descartar que sea una coincidencia de subcadena casual (ej. que "Clientes"
   matchee una ruta de otro dominio que también contenga esa palabra).
3. Para las features sin nombre declarado ni match de gateway, decide si el
   prefijo de recurso alcanza para proponer un nombre hipotético (`ms-<dominio>`)
   o si es mejor dejarlo como una sola fila genérica sin dividir — **no fuerces un
   nombre de microservicio que no puedes sostener con el código**. Ante la duda,
   la fila genérica.
4. Revisa si el candidato ya existe en el catálogo con otro nombre (ej. el catálogo
   dice `ms-clientes` y el código dice `ClientService`): si el dominio coincide,
   es la misma fila — agrega este repo a Consumidores, no dupliques.
5. Confirma con el usuario cualquier caso ambiguo antes de tocar el archivo — igual
   que cualquier otro cambio a `base-docs` (regla 1 de su `CLAUDE.md`: todo cambio
   va por MR, dueño editorial el Arquitecto).

## 3 · Redactar el cambio en `CATALOGO_SERVICIOS.md`

Formato de fila para un candidato **agrupado tras el gateway, sin dueño real
visible desde este repo**:

```markdown
| `ClientService` *(candidato, ver nota)* | <propósito inferido de los endpoints usados> | TODO | TODO | <Repo actual> | TODO |
```

Formato de fila para un candidato **confirmado por el gateway** (paso 0.5 + match
verificado a mano en el paso 2) — ya no lleva la anotación de "candidato", pero
Dueño sigue en `TODO` salvo que el nombre de host/`ServiceName` lo delate sin
ambigüedad:

```markdown
| `ms-clientes` *(identidad confirmada por gateway, dueño pendiente)* | <propósito inferido de los endpoints usados> | TODO | TODO | <Repo actual> | TODO |
```

Formato de fila para un **servicio fuera del gateway** (base HTTP propia detectada
en el paso 1, como el ejemplo de LeadService de la plataforma):

```markdown
| LeadService | <propósito, si el código o un swagger lo dice> | TODO | <URL del swagger si el código la referencia> | <Repo actual> | TODO |
```

Debajo de la tabla (o en un comentario HTML si el formato de la tabla no admite
notas), deja explícito qué filas son candidatas sin confirmar:

```markdown
> Candidatas agregadas por `catalogar-dependencias` el <fecha>, generadas desde
> `<repo>` — Dueño y Contrato pendientes de que el Arquitecto los confirme.
```

Nunca elimines la nota hasta que alguien con autoridad edite Dueño/Contrato con un
valor real — es la señal de que la fila todavía no es verdad de catálogo.

## Reglas duras

- Dueño y Contrato **nunca** se llenan con una suposición — van `TODO` si el código
  no los declara literalmente (una URL de swagger sí cuenta; un nombre de dominio
  adivinado no).
- Nunca se sobreescribe una fila que el catálogo ya tiene con Dueño/Contrato
  llenos — solo se extiende su columna Consumidores si el repo actual la usa y no
  aparece.
- Un cambio a `CATALOGO_SERVICIOS.md` sigue las reglas de `base-docs`: por MR,
  aprobación del Arquitecto. Este skill prepara el diff; no lo mergea.
- Si `features/` no sigue el patrón `infrastructure|infraestructure/api/*Url.ts` +
  `*.services.ts`, dilo explícitamente en vez de forzar una lectura que no aplica.

## Al terminar, imprime

Cuántas filas se proponen y de qué tipo (confirmadas por gateway, agrupadas por
JSDoc, genéricas por recurso, o fuera del gateway), qué features quedaron sin señal
suficiente para proponer nada, y el recordatorio de que el Arquitecto debe
confirmar Dueño/Contrato antes de que cualquiera trate estas filas como catálogo
real.
