#!/usr/bin/env node
/**
 * Extrae, desde el código de un repo, candidatos a filas de CATALOGO_SERVICIOS.md:
 *   - por cada feature, los prefijos de recurso usados en sus *Url.ts
 *   - el nombre de microservicio que el propio JSDoc de *.services.ts ya declara
 *     (ej. "Service for consuming the Branch microservice")
 *   - bases HTTP fuera del gateway (axios.create, process.env.*_BASE/_URL)
 *
 * No escribe nada: solo imprime un reporte en Markdown para que un humano (o la IA
 * guiada por SKILL.md) lo revise antes de tocar el catálogo. No inventa dueño ni
 * contrato — eso no está en este código.
 *
 * Si se pasa una segunda ruta (repo o archivo del API gateway), busca ahí
 * `ocelot*.json` y cruza sus rutas (`Routes`/`ReRoutes`, `UpstreamPathTemplate`)
 * contra los prefijos de recurso detectados, para pasar de "candidato" a
 * "confirmado por el gateway" cuando hay match. Sin esa ruta, el reporte queda
 * igual que antes — el cruce es un plus, no un requisito.
 *
 * Uso: node extraer-dependencias.mjs [raizDelRepo] [rutaDelGateway]
 */
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2] || ".");
const featuresDir = path.join(root, "features");

if (!fs.existsSync(featuresDir)) {
    console.error(`No existe ${featuresDir}. Corre este script desde (o pasando como argumento) la raíz de un repo con carpeta features/.`);
    process.exit(1);
}

const WALK_SKIP = new Set(["node_modules", ".next", "dist", "build", "out", "coverage"]);
function walk(dir, out = []) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
        if (WALK_SKIP.has(entry.name) || entry.name.startsWith(".")) continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) walk(full, out);
        else out.push(full);
    }
    return out;
}

const allFiles = walk(featuresDir);
const urlFiles = allFiles.filter(f => /\/(infrastructure|infraestructure)\/api\/.*Url\.ts$/i.test(f.replace(/\\/g, "/")));
const serviceFiles = allFiles.filter(f => /\.services?\.ts$/i.test(f));

function featureOf(file) {
    const rel = path.relative(featuresDir, file).replace(/\\/g, "/");
    return rel.split("/")[0];
}

// --- 1. prefijos de recurso por feature, desde *Url.ts ---
const RESOURCE_RE = /['"`](\/(?:api\/v\d+\/)?)([A-Za-zÁÉÍÓÚáéíóúñÑ]+)/g;
const prefixesByFeature = new Map();

for (const file of urlFiles) {
    const content = fs.readFileSync(file, "utf8");
    const feature = featureOf(file);
    if (!prefixesByFeature.has(feature)) prefixesByFeature.set(feature, new Map());
    const counts = prefixesByFeature.get(feature);
    let m;
    while ((m = RESOURCE_RE.exec(content)) !== null) {
        const resource = m[2];
        counts.set(resource, (counts.get(resource) || 0) + 1);
    }
}

// --- 2. nombres de microservicio ya declarados en JSDoc ---
const MS_DOC_RE = /\/\*\*([\s\S]*?)\*\//g;
// El nombre real puede venir ANTES del sustantivo ("the Branch microservice") o
// DESPUÉS ("del microservicio `IApymsa.Search`", "consumo de microservice SMCService").
// Se exige mayúscula inicial o un punto (IApymsa.Search) para no capturar
// preposiciones sueltas (the/de/del/para).
const NAME_BEFORE_RE = /([A-Z][\w.]*)\s+microservic\w*/;
const NAME_AFTER_RE = /microservic\w*\s+[`"']?([A-Z][\w.]*)[`"']?/;
const declaredByFeature = new Map();

for (const file of serviceFiles) {
    const content = fs.readFileSync(file, "utf8");
    const feature = featureOf(file);
    let m;
    while ((m = MS_DOC_RE.exec(content)) !== null) {
        const block = m[1];
        if (!/microservic/i.test(block)) continue;
        const nameMatch = block.match(NAME_BEFORE_RE) || block.match(NAME_AFTER_RE);
        if (!nameMatch) continue;
        const name = nameMatch[1].replace(/\.$/, "");
        if (!declaredByFeature.has(feature)) declaredByFeature.set(feature, new Set());
        declaredByFeature.get(feature).add(name);
    }
}

// --- 2.5 cruce opcional con las rutas reales del API gateway (Ocelot) ---
const gatewayArg = process.argv[3] ? path.resolve(process.argv[3]) : null;
let gatewayRoutes = null;
const gatewayFilesUsed = [];
// Prefijos demasiado genéricos como para que un match de subcadena signifique algo.
const GENERIC_RESOURCES = new Set(["api", "user", "objeto", "health"]);

if (gatewayArg) {
    if (!fs.existsSync(gatewayArg)) {
        console.error(`Aviso: no existe la ruta de gateway indicada (${gatewayArg}) — se ignora el cruce.`);
    } else {
        const isFile = fs.statSync(gatewayArg).isFile();
        const candidateFiles = isFile ? [gatewayArg] : walk(gatewayArg);
        const ocelotFiles = candidateFiles.filter(f => /ocelot.*\.json$/i.test(path.basename(f)));
        gatewayRoutes = [];
        for (const file of ocelotFiles) {
            try {
                // Algunos ocelot.json reales llevan comentarios de línea completa
                // (divisores "////...", "// Inicio X") que no son JSON válido.
                // Se quitan solo las líneas que son comentario puro, sin tocar el resto.
                const raw = fs.readFileSync(file, "utf8")
                    .split(/\r?\n/)
                    .filter(line => !/^\s*\/\//.test(line))
                    .join("\n");
                const json = JSON.parse(raw);
                const routes = json.Routes || json.ReRoutes || [];
                for (const r of routes) {
                    const downstreamId = r.ServiceName
                        || (Array.isArray(r.DownstreamHostAndPorts) && r.DownstreamHostAndPorts[0]?.Host)
                        || r.DownstreamPathTemplate
                        || "(sin identificar)";
                    gatewayRoutes.push({
                        upstream: r.UpstreamPathTemplate || "",
                        downstreamId,
                    });
                }
                gatewayFilesUsed.push(path.relative(isFile ? path.dirname(gatewayArg) : gatewayArg, file).replace(/\\/g, "/") || path.basename(file));
            } catch {
                console.error(`Aviso: ${file} no parseó como JSON válido de Ocelot — se ignora.`);
            }
        }
        if (!gatewayFilesUsed.length) {
            console.error(`Aviso: no se encontró ningún "ocelot*.json" bajo ${gatewayArg}. Si el gateway usa otro formato de ruteo, este cruce no aplica todavía — se sigue sin él.`);
            gatewayRoutes = null;
        }
    }
}

function matchGateway(resource) {
    if (!gatewayRoutes || GENERIC_RESOURCES.has(resource.toLowerCase()) || resource.length <= 3) return null;
    const hits = gatewayRoutes.filter(r => r.upstream.toLowerCase().includes(resource.toLowerCase()));
    if (!hits.length) return null;
    return [...new Set(hits.map(h => h.downstreamId))];
}

// --- 3. bases HTTP fuera del gateway EPICO_API ---
// axios_helper.ts declara EPICO_API (el helper compartido, ya documentado) pero puede
// declarar OTRAS instancias de axios con su propia baseURL — esas sí son candidatas.
// No basta con saltar el archivo entero: hay que identificar cada instancia por nombre.
// Y ese archivo vive fuera de features/ (ej. axios/axios_helper.ts), así que este chequeo
// recorre todo el repo, no solo la carpeta de features.
const AXIOS_INSTANCE_RE = /export const (\w+)\s*=\s*axios\.create\(\{([\s\S]*?)\n\}\);/g;
const KNOWN_DOCUMENTED_INSTANCES = new Set(["EPICO_API"]);
const externalHits = [];
const allRepoFiles = walk(root);
for (const file of allRepoFiles) {
    if (!/\.(ts|tsx)$/.test(file)) continue;
    const content = fs.readFileSync(file, "utf8");
    let m;
    while ((m = AXIOS_INSTANCE_RE.exec(content)) !== null) {
        const [, name, body] = m;
        if (KNOWN_DOCUMENTED_INSTANCES.has(name)) continue;
        const baseUrlMatch = body.match(/baseURL\s*:\s*([^\n,]+)/);
        externalHits.push({
            file: path.relative(root, file).replace(/\\/g, "/"),
            match: `axios.create(${name})`,
            baseUrl: baseUrlMatch ? baseUrlMatch[1].trim() : "(sin baseURL literal)",
        });
    }
    // otras bases *_BASE/*_URL fuera de un axios.create ya capturado arriba
    const ENV_RE = /process\.env\.[A-Z0-9_]*(?:_BASE|_URL)[A-Z0-9_]*/g;
    let em;
    while ((em = ENV_RE.exec(content)) !== null) {
        if (path.basename(file) === "axios_helper.ts") continue; // ya se reportó vía baseURL arriba
        externalHits.push({ file: path.relative(root, file).replace(/\\/g, "/"), match: em[0] });
    }
}

// --- reporte ---
const lines = [];
lines.push("# Dependencias detectadas (candidatas, sin confirmar)");
lines.push("");
lines.push(`Raíz analizada: \`${root}\``);
lines.push(`Archivos \`*Url.ts\` revisados: ${urlFiles.length} · archivos \`*.services.ts\` revisados: ${serviceFiles.length}`);
if (gatewayArg) {
    lines.push(
        gatewayRoutes
            ? `Gateway cruzado: ${gatewayRoutes.length} rutas leídas de ${gatewayFilesUsed.map(f => `\`${f}\``).join(", ")}.`
            : `Gateway indicado (${gatewayArg}) sin \`ocelot*.json\` reconocible — reporte sin cruce.`
    );
}
lines.push("");
lines.push("## Por feature");
lines.push("");

const features = new Set([...prefixesByFeature.keys(), ...declaredByFeature.keys()]);
for (const feature of [...features].sort()) {
    lines.push(`### ${feature}`);
    const declared = declaredByFeature.get(feature);
    if (declared && declared.size) {
        lines.push(`- **Microservicio declarado en JSDoc:** ${[...declared].map(n => `\`${n}\``).join(", ")}`);
    } else {
        lines.push("- **Microservicio declarado en JSDoc:** (ninguno — inferir solo por recurso)");
    }
    const counts = prefixesByFeature.get(feature);
    if (counts && counts.size) {
        const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
        lines.push(`- **Prefijos de recurso vistos:** ${top.map(([r, c]) => `${r} (${c})`).join(", ")}`);
        if (gatewayRoutes) {
            const matches = top
                .map(([resource]) => [resource, matchGateway(resource)])
                .filter(([, targets]) => targets);
            lines.push(
                matches.length
                    ? `- **Confirmado por gateway:** ${matches.map(([r, t]) => `${r} → ${t.join(" / ")}`).join(" · ")}`
                    : "- **Confirmado por gateway:** sin match en las rutas leídas"
            );
        }
    }
    lines.push("");
}

lines.push("## Bases HTTP fuera de EPICO_API (posibles servicios NO detrás del gateway)");
lines.push("");
if (externalHits.length) {
    for (const hit of externalHits) {
        lines.push(`- \`${hit.match}\` en \`${hit.file}\``);
    }
} else {
    lines.push("(ninguna encontrada)");
}
lines.push("");
lines.push("---");
lines.push("Esto es un candidato para revisión humana, no un hecho de arquitectura. Dueño y");
lines.push("Contrato NUNCA se llenan desde aquí: el código del consumidor no los conoce. Un");
lines.push("match \"confirmado por gateway\" confirma la IDENTIDAD del servicio (a qué host o");
lines.push("nombre lo manda el gateway) — no confirma Dueño, y el match es por subcadena de");
lines.push("ruta: verifica a mano que no sea una coincidencia casual antes de darlo por bueno.");

console.log(lines.join("\n"));
