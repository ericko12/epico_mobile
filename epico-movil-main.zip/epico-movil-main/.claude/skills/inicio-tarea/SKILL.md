---
name: inicio-tarea
description: >-
  Arranca el trabajo de una Spec en este repo a partir de la clave de su issue de Jira
  (p. ej. EF-50620): localiza la página de Confluence que el issue enlaza, verifica el
  gate (página en Ready for Dev, issue fuera de Backlog/Discovery), crea la rama desde la
  release elegida y congela la página VERBATIM como spec.snapshot.md (y las de su Spec UX
  y Spec de Proyecto como spec-ux.snapshot.md / spec-proyecto.snapshot.md) con hash de
  contenido, genera el borrador de plan.md y propone las subtareas. Úsala al iniciar
  cualquier tarea de una Spec, o con --refresh cuando la página cambió a media
  construcción.
---

# inicio-tarea — abrir el paquete de trabajo de una Spec

Uso: `/inicio-tarea EF-50620` · refresco: `/inicio-tarea EF-50620 --refresh` ·
sin la página de Proyecto: `--sin-proyecto`

Las reglas que implementa esta skill:

- **ADR-001** — la Spec se gobierna en Jira y se **construye desde copias congeladas en
  la rama**. Tú generas esas copias; nadie las edita a mano.
- **ADR-005** — la Spec **vive en su página de Confluence**, enlazada desde el issue. El
  snapshot es una **copia verbatim** de esa página (no se reconstruye nada) y guarda un
  **hash del contenido** para detectar deriva. La **clave del issue es la identidad**
  (`EF-50620`): nombra la rama, los archivos y las referencias; el **folio** de la página
  (`SPEC-F1-003`) se registra como referencia. Cómo se llega de la clave a la página:
  `base-docs/docs/ENLACE_SPEC_CONFLUENCE.md` — esa es tu regla, no la inventes.
- Hay hasta **tres verdades por tarea**: la Spec Funcional (el QUÉ), la Spec UX (el CÓMO
  se vive) si la capacidad tiene experiencia, y la Spec de Proyecto (las restricciones
  transversales de todas).

## 0 · Resolver el issue en Jira

1. `git status` limpio. Si hay cambios sin commitear: **detente** y dile al usuario qué
   hay pendiente.
2. **La clave es autocontenida.** `EF-50620` ya dice proyecto (`EF`) y número, y las
   Specs **viven en varios proyectos** — no hay tablero que elegir: solo hace falta el
   **sitio**, que lo da la conexión del **MCP de Atlassian** (cada persona la autoriza
   una vez con su cuenta; cubre Jira **y** Confluence). Las líneas `Jira:` y
   `Confluence:` del `CLAUDE.md` del repo dan el sitio, el **nombre del tipo de issue de
   la Spec**, el **espacio** de Confluence y la **página de la Spec de Proyecto** —
   referencia, no filtro.
3. Lee el issue por su clave y verifica:
   - **Es una Spec:** el nombre de su tipo contiene «Spec» (`#Partial release (Spec)` en
     el proyecto `EF`; el `CLAUDE.md` dice el nombre exacto de este repo). Si es el
     `#Release` del proyecto, detente: de la Spec de Proyecto no se construye — pide la
     clave de una Spec hija. Si es una `#Historia de Spec` o `#Task`, sube al **padre**
     hasta dar con la Spec y dilo.
   - **Estado del issue fuera de `Backlog` y `Discovery`** (lo normal: `Definition` o
     `Development`). Si no, **detente** — el flujo no llegó a Definición.
   - Anota el **padre** (`#Release` = Spec de Proyecto), el título, las etiquetas y la
     fecha de última actualización.
   - **Si no tienes herramientas de Atlassian disponibles** (el MCP no está conectado en
     esta sesión): **dilo de una vez y explica cómo se conecta** — no pidas credenciales
     ni las aceptes en el chat; la conexión es fuera de la sesión:
     ```
     El servidor ya viene configurado en el repo (.mcp.json). Autoriza tu cuenta con:
       /mcp            → elige «atlassian» y completa el login en el navegador
     (o en terminal: claude mcp login atlassian)
     Si el repo no lo trae:
       claude mcp add --transport http atlassian https://mcp.atlassian.com/v1/mcp --scope project
     ```
     Mientras no esté conectado, ofrece el **modo manual**: el usuario pega la URL de la
     página y su contenido completo (cabecera incluida), más el estado del issue. Anota
     `resuelto_por: manual` y `origen: … (pegado por <persona>)` en el snapshot. No sigas
     con secciones a medias.

## 1 · De la clave a la página (regla de `ENLACE_SPEC_CONFLUENCE.md §3`)

4. Prueba las vías **en este orden** y quédate con la primera que devuelva **exactamente
   una** página:
   1. **Enlaces remotos del issue** a Confluence (URL con `/wiki/`). Varios → prefiere el
      que su título empiece por `SPEC-` (no `UX-SPEC-`); si sigue habiendo más de uno,
      **pregunta**. → `resuelto_por: enlace-remoto`
   2. **Folio en el título o la descripción** del issue: patrón `\bSPEC-F\d+-\d{3}\b`
      sin `UX-` delante → búsqueda CQL en el espacio del `CLAUDE.md`:
      `space = <PE> AND type = page AND title ~ "<folio>*"`. → `folio-en-titulo`
   3. **La página menciona la clave:** `space = <PE> AND type = page AND text ~
      "<CLAVE>"`, descartando títulos `UX-SPEC-…` y `00_SPEC_PROYECTO…`. →
      `mencion-en-pagina`
   4. **Manual:** pide la URL o el id de la página. → `manual`
   Cero páginas en las cuatro vías = **la Spec no es construible**: repórtalo y detente.
   Si resolviste por 3 o 4, incluye en el resumen final la instrucción de **enlazar la
   página al issue** para que la próxima vez sea automático (§6 del doc de enlace).
5. **Trae la página en Markdown** (formato `markdown` del MCP) y lee su **cabecera**
   (la lista numerada del inicio): `Spec Funcional:` (folio), `Spec UX/UI asociada:`,
   `Spec de Proyecto / Iniciativa:`, `Responsable`, `Versión`, `Última actualización`,
   `Estado`. Anota también la fecha de modificación que reporta Confluence.
   - Si llegaste por folio o por mención, **el folio de la cabecera debe coincidir** con
     el esperado; si no, pregunta — la búsqueda pudo traer una página parecida.
6. **Gate de la página:** `Estado: Ready for Dev`. Si dice `Borrador` (o cualquier otra
   cosa), **detente** e imprime la checklist «Validación para Ready for Dev» tal como
   está (qué falta y quién lo lleva: BA). Excepción: el humano lo pide explícitamente →
   continúa y anota `estado_pagina_al_congelar: Borrador (forzado por <nombre>)`. No es
   `--refresh` lo que lo permite: es una persona.
7. **§9 Pendientes de Definición:** si hay `[NEEDS CLARIFICATION]` marcados **críticos**
   (o la checklist tiene sin marcar «No existen [NEEDS CLARIFICATION] críticos»),
   detente e imprime cuáles y su dueño. Con críticos abiertos no se construye.
8. **Página UX:** de la cabecera (`Spec UX/UI asociada: UX-SPEC-F1-003`) → CQL
   `title ~ "UX-SPEC-F1-003*"`. → `resuelto_por: cabecera-funcional`
   - **Existe y está en `Ready for Dev`:** se congela también (paso 15).
   - **Existe pero está en `Borrador`:** advierte con claridad — *las tareas de front
     quedan bloqueadas hasta que la UX esté lista; las de back pueden continuar.*
     Regístralo en el plan.
   - **`N/A`, vacío o «sin UX»:** la Spec no tiene participación UX — continúa normal.
   - **Más de una candidata:** pregunta cuál aplica; no adivines.
9. **Página de Proyecto:** el id de `Spec de Proyecto: página <id>` del `CLAUDE.md`
   (`resuelto_por: claude-md`); si no está, CQL `title ~ "00_SPEC_PROYECTO*"` cuyo texto
   contenga el folio `PROJ-SPEC-…` de la cabecera (`titulo-proyecto`). Se congela como
   `spec-proyecto.snapshot.md` (paso 16) salvo `--sin-proyecto`. De ahí salen las
   **definiciones y restricciones transversales** (§4) para el plan.
10. **Páginas complementarias** del BA: CQL `space = <PE> AND type = page AND text ~
    "<folio>" AND (title ~ "Reglas de negocio*" OR title ~ "Decisiones pendientes*")`.
    Lista lo que encuentres (título, id, fecha) y **pregunta cuáles van como anexos** del
    snapshot funcional. Una «decisión pendiente» con estado abierto cuenta como
    `[NEEDS CLARIFICATION]`: si toca el alcance de esta tarea, dilo antes de seguir.

## 2 · Rama — nace de una release, nunca de main (ADR-002)

11. Lista las ramas release del repo (`git fetch --prune` y luego
    `git branch -r --list '*release*'`, ordenadas por fecha) y **pregunta al humano**:

    > ¿De qué release nace esta Spec?
    > 1) release/<a>  2) release/<b>  …  N) **crear una release nueva**

    - Si elige una existente: `git checkout` a esa release actualizada.
    - Si elige crear una nueva: **pídele el nombre** (formato `release/<nombre>`),
      créala desde `<rama-principal>` actualizada y púshala antes de continuar.
    - No asumas ni inventes la release: sin respuesta del humano, no hay rama.
12. Deriva un slug corto del título (2–4 palabras, kebab-case, sin acentos). Crea la
    rama **`EF-50620/<slug>`** —la clave real, tal cual— **desde la release elegida**.
    El MR de esta rama apuntará a esa misma release, nunca a `main`.

## 3 · Congelar (copiar, no reconstruir)

13. **El cuerpo del snapshot es el Markdown de la página, VERBATIM**: cabecera numerada,
    las 9 secciones con sus encabezados tal cual, la checklist final. Sin resumir, sin
    reordenar, sin "mejorar" la redacción, sin omitir secciones vacías. Si confirmaron
    anexos (paso 10), van al final, cada uno bajo
    `## Anexo <A|B> · <título de la página> (página <id>)` con su cuerpo verbatim.
14. **Calcula el hash** con la regla de `ENLACE_SPEC_CONFLUENCE.md §5`: `\r\n`→`\n`, sin
    espacios al final de línea, sin líneas en blanco al inicio/fin, anexos concatenados
    con `\n\n---\n\n` en orden de id, SHA-256 en UTF-8 → `sha256:<64 hex>`. El front matter
    y el banner **no** entran.
15. Escribe `spec.snapshot.md` con este formato EXACTO (fuente canónica:
    `base-docs/plantillas/plantilla-snapshot.md` — si esta skill y la plantilla difieren,
    gana la plantilla y hay que actualizar la skill por MR):

```markdown
---
spec: EF-50620
folio: SPEC-F1-003
tipo: funcional
titulo: <título de la página>
spec_proyecto: <CLAVE del #Release> · <PROJ-SPEC-…> · página <id>
spec_ux: <UX-SPEC-…> · página <id> · <Ready for Dev | Borrador> | —
origen: Confluence · espacio <PE> · página <id> «<título>» · modificada <fecha> · cabecera Versión <n> · Estado <estado>
resuelto_por: <enlace-remoto | folio-en-titulo | mencion-en-pagina | manual>
anexos: <ids> | ninguno
contenido_hash: sha256:<64 hex>
estado_pagina_al_congelar: Ready for Dev
estado_issue_al_congelar: <Definition | Development>
rama: EF-50620/<slug>
generado_por: skill inicio-tarea v1.4
---

# ⚠ SNAPSHOT — Copia congelada de la página de Confluence de EF-50620 (SPEC-F1-003). No editar este archivo.
> La Spec se edita **en su página de Confluence**. Si la página cambia durante la
> construcción, el hash deja de coincidir: la skill lo avisa. El refresco es un commit
> visible (`/inicio-tarea EF-50620 --refresh`).

<CUERPO DE LA PÁGINA, VERBATIM>
<ANEXOS confirmados, si los hay>
```

16. **Si hay Spec UX lista (paso 8):** escribe también `spec-ux.snapshot.md`, mismo
    mecanismo y su propio hash. La UX **no tiene issue propio**: `spec:` lleva la misma
    clave de la funcional.

```markdown
---
spec: EF-50620
folio: UX-SPEC-F1-003
tipo: ux
spec_funcional: SPEC-F1-003 · página <id>
titulo: <título de la página UX>
spec_proyecto: <CLAVE del #Release> · <PROJ-SPEC-…> · página <id>
origen: Confluence · espacio <PE> · página <id> «<título>» · modificada <fecha> · cabecera Versión <n> · Estado <estado>
resuelto_por: cabecera-funcional
anexos: ninguno
contenido_hash: sha256:<64 hex>
estado_pagina_al_congelar: Ready for Dev
estado_issue_al_congelar: <Definition | Development>
rama: EF-50620/<slug>
generado_por: skill inicio-tarea v1.4
---

# ⚠ SNAPSHOT UX — Copia congelada de la página de Confluence UX-SPEC-F1-003 (issue EF-50620). No editar este archivo.
> La experiencia se edita **en su página de Confluence**. Misma regla de deriva.

<CUERPO DE LA PÁGINA UX, VERBATIM>
```

17. **Spec de Proyecto (paso 9):** `spec-proyecto.snapshot.md` con `tipo: proyecto`,
    `folio: PROJ-SPEC-…`, `spec:` la clave del `#Release`, `resuelto_por: claude-md |
    titulo-proyecto`, su hash, y el banner `# ⚠ SNAPSHOT PROYECTO — …`. Es contexto: de
    ahí no se construye, pero sus restricciones (§4) obligan.

## 4 · plan.md (borrador)

18. Genera `plan.md` con la estructura de `base-docs/plantillas/plantilla-plan.md`
    (11 secciones, front matter con `generado_por: skill plan-tecnico v1.0`).
19. En la sección 1 anota la base y las fuentes: `Rama base: release/<nombre> — los MR
    de esta spec apuntan ahí (ADR-002)` · `Spec: EF-50620 · SPEC-F1-003 · página <id>
    (hash <8 primeros>)` · el estado de la UX (`UX-SPEC-F1-003 congelada (hash …)` o
    `UX en Borrador — front bloqueado`) · `Proyecto: PROJ-SPEC-… (hash …)`.
20. Llena solo lo **derivable de los documentos**:
    - De la **Funcional**: servicios afectados (sus dependencias DEP-* del §3 e impactos
      IMP-* del §8, marcando ⚠ compartidos según `CATALOGO_SERVICIOS.md`), extender vs
      crear (default: extender al dueño del dominio), riesgos RISG-* y NFR (§7) que
      exijan trabajo explícito.
    - Del **Proyecto**: las restricciones transversales (§4) que apliquen a esta tarea,
      citadas por su código.
    - De la **UX** (si existe): el inventario `UX-VIEW-*` se vuelve **tareas de front**
      (una por vista o flujo); los `UX-NEW-*` se marcan para registro en
      `SISTEMA_DISENO.md`; los `UX-STATE/UX-INT` alimentan la estrategia de pruebas e2e.
    Lo que no sepas, márcalo `<pendiente: …>`. **No inventes decisiones.**
21. Si el plan toca varios servicios, seguridad, datos o un servicio compartido: escribe
    en el front matter que la revisión del **Arquitecto es obligatoria**.

## 5 · Subtareas y cierre

22. Propón la tabla de tareas (plan §11) con dueño `<por asignar>` — las de front
    referenciando su `UX-VIEW-*` cuando exista. Si hay MCP y el usuario aprueba, créalas
    como `#Task` bajo la `#Historia de Spec` que corresponda (o como subtareas del issue
    de la Spec si el equipo no usa historias).
23. Commit: `EF-50620: congela snapshots y borrador de plan.md`.
24. Si `glab` está disponible y el usuario quiere: abre el MR **en borrador** desde ya,
    con `--target-branch` la release elegida (el CI valida los snapshots y el equipo ve
    qué se construye).

## Modo --refresh (la página cambió con construcción en vuelo)

- Corre solo con **autorización explícita del humano**: la deriva de hash es un aviso,
  no un permiso.
- Vuelve a traer la(s) página(s), recalcula el hash y **antes de escribir nada di qué
  cambió**: compara el snapshot en disco contra la página recién traída **sección por
  sección** (encabezados `## `), y cita la cabecera nueva (`Versión`, `Última
  actualización`, `Estado`). Si la página tiene historial visible, di quién y cuándo.
- Reemplaza **completo** el snapshot que cambió (funcional, UX, proyecto o varios) con su
  nuevo hash. Commit separado por refresh:
  `EF-50620: refresh de snapshot <funcional|ux|proyecto> — página modificada`.
- No toques `plan.md` automáticamente: propone los ajustes y deja que el humano decida.
- Si la página **retrocedió** a `Borrador`, detente: eso no es un refresh, es una Spec
  reabierta — la decisión de seguir construyendo es del equipo, no tuya.

## Reglas duras

- Nunca edites un snapshot existente línea por línea: siempre copia completa + commit
  visible.
- Nunca escribas en la página de la Spec (ni en Confluence ni en el issue, salvo
  comentarios y subtareas aprobadas). La IA propone; el dueño (BA / UX / PO) escribe.
- Congela **solo** lo que la regla de enlace resolvió. Si crees que la Spec "debería"
  tener otra página, eso es una pregunta al BA — no una búsqueda a ojo.
- Una sesión ≈ una tarea. Si te piden abrir dos specs en la misma sesión, sugiere abrir
  otra sesión.
- Si algo de esta skill contradice a `base-docs`, **gana base-docs** — y avisa.

## Al terminar, imprime

- Clave y título de la Spec · folio y página (id) · **cómo se resolvió el enlace** · rama
  creada y de qué release nace · qué snapshots se generaron con los primeros 8
  caracteres de cada hash · a dónde apunta el MR · anexos incluidos, si alguno.
- Si el enlace se resolvió por mención o manual: **la instrucción de enlazar la página al
  issue** (y de poner el folio al inicio del título) para la próxima vez.
- El checklist humano: ▢ leí el/los snapshots completos · ▢ contrato congelado y
  enlazado (§8 Referencias de la funcional) · ▢ `[NEEDS CLARIFICATION]` críticos = 0 ·
  ▢ si hay Spec UX: congelada, o el front queda explícitamente bloqueado · ▢ si toca
  servicio compartido, el plan va a revisión del Arquitecto.
- Recordatorio: la sesión se cierra con `/cierre-tarea`.
