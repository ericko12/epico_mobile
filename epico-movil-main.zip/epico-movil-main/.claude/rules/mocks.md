---
paths:
  - "__tests__/**"
  - "__fixtures__/**"
  - "app/prototipos/**"
---

# Reglas de los datos simulados (se cargan al tocar pruebas, fixtures o prototipos)

> **Qué es este archivo:** reglas de la casa para la IA, no un entregable por Spec. Hay uno solo y
> cambia por MR. **Dueño:** Dev líder front + Arquitecto · **Revisa el MR:** QA, porque consume los
> datos. Los datos de cada Spec los produce el Dev de la tarea con `/front-feature`, y QA los audita
> contra los `examples` del contrato.
>
> **Diferencia con el modelo:** este repo **no usa MSW**. El modelo pedía handlers MSW en
> `src/mocks/<CLAVE>/`. Aquí los datos simulados son fixtures que una prueba de Jest sirve en lugar
> de la red, y cumplen el mismo fin: la pantalla se comporta igual con datos simulados que con el
> servicio real. Ejemplo completo: EF-50620 (Cotizaciones).

1. **Todo fixture sale del contrato.** La única fuente es el `contracts/openapi.json` del ms dueño,
   con su schema y sus `examples`. En Cotizaciones es `pedidoservice`, v3.4.0, congelado el
   29-09-2026. No se inventan campos ni formas. Si el contrato no trae el example de un estado que
   la pantalla necesita, se le pide al dueño del contrato; no se redacta aquí. La única excepción
   está en la regla 3.
2. **Dónde y cómo:** `__fixtures__/app/features/<feature>/<CLAVE>/fixtures.ts`, un directorio por
   Spec y sin mezclar Specs. **Nunca dentro de `__tests__/`:** Jest corre como prueba todo archivo
   de esa carpeta (el repo no define `testMatch`), y un archivo sin pruebas truena la corrida.
   Cada fixture es el `value` del example **tal cual**, con el sobre que ya trae el contrato
   (`{ statusCode, data, huboError, error }`). Se copia por programa desde el JSON, no a mano, y
   si el contrato cambia se vuelve a copiar.
3. **Qué casos cubrir**, siempre que el contrato traiga su example:
   - el caso feliz;
   - el vacío que declare el contrato (en el listado de Cotizaciones es un 204, sin cuerpo);
   - cada error de regla, con su código `<CLAVE>.<RN-XX>` (en el contrato de `pedidoservice` viaja
     en `erroresValidaciones[].campo`, y el texto en `errores[]`).

   **Una sola excepción: el valor desconocido.** Cuando el contrato declara un string abierto
   (p. ej. `statusPropuestaComercial`, «string abierto, no un enum cerrado»), se copia un example
   y se cambia solo ese dato por uno que el contrato todavía no emite. Se marca con
   `// DERIVADO de <origen>: <qué cambia>`. La pantalla debe mostrarlo sin romper ni inventar un
   color.
4. **Los fixtures entran por la red, no por el servicio.** `__fixtures__/contratoHttp.ts` sustituye
   solo el adaptador de red de `EPICO_API`. Así corren el interceptor, `handleRequest` y
   `catchResponse` reales, y el fixture no tiene que imitar lo que ese código hace:
   - con un 204, el interceptor entrega `{ data: null, message, success, statusCode }`, **sin**
     `huboError` ni `error`;
   - con un error, `catchResponse` convierte un `erroresValidaciones: null` en `[]`.

   Por eso no se usa `jest.mock` del servicio para dar datos del contrato. Tampoco un
   `if (fixture)` dentro de un componente: en código de producto no puede quedar ningún fixture
   encendido. El `aplicarFixtureOrigenPropuesta` del prototipo F1-003, que la UX apagó en la v0.13,
   es el ejemplo de lo que no debe llegar a una pantalla real.
5. **Los prototipos** (`app/prototipos/**`) pueden sembrar datos, pero no son la entrega. Su lógica
   pasa a `features/` con pruebas, y sus datos se reemplazan por los fixtures del contrato.
6. **Datos de prueba ficticios:** nada de nombres, RFC o correos de clientes reales, aunque salgan de
   un ambiente de pruebas. Si un example del contrato parece traer datos reales, se le avisa a ARQ.
7. **Al integrar, el fixture no se borra.** Queda para las pruebas y para quien trabaje la pantalla
   después.
8. **QA puede agregar casos** (un error raro, un borde de fechas) en el mismo directorio de la Spec,
   por MR y con estas mismas reglas: si el caso no está en el contrato, primero se pide ahí.
