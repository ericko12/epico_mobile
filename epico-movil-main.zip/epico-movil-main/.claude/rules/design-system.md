---
paths:
  - "features/common/infrastructure/ui/**"
  - "features/common/domain/enums/ColorsEpico.ts"
  - "features/common/domain/enums/FontSizes.ts"
  - "features/common/domain/enums/FontWeight.ts"
  - "config/theme/**"
---

# Reglas del sistema de diseño (se cargan al tocar el catálogo compartido o los tokens)

> En este repo no hay un `src/components/`: el sistema de diseño de hecho es
> `features/common/infrastructure/ui/`, con los tokens de `features/common/domain/enums/` y el tema
> de `config/theme/`. Es el catálogo compartido de todo el proyecto (31 features). El catálogo para humanos e IA está en
> `base-docs/productos/epico/SISTEMA_DISENO.md`. **Dueños:** UX + Dev líder front.

1. **Un cambio aquí se acuerda entre UX y Dev, y no se hace «de pasada»** dentro del MR de una
   Spec. En el MR se listan las pantallas que usan el componente (un `grep` de sus imports).
2. **Buscar antes de crear**, en el catálogo y en este directorio. Si la Spec tiene Spec UX, sus
   `UX-COMP-*` dicen qué componente usar, con qué variante y en qué estados.
3. Un **componente nuevo** entra solo si trae: props tipadas en `*.types.ts`, JSDoc, sus estados
   (incluidos deshabilitado y carga cuando apliquen), la variante por debajo de 900px ya resuelta
   (44px táctiles, sin desborde a 320px), una prueba en `__tests__/app/features/common/…` y su
   registro en `SISTEMA_DISENO.md` **en el mismo MR**. Mientras no se acuerde, vive en el feature
   con la marca `// PROPUESTA-DS`.
4. **Extender antes que duplicar.** Si hace falta «casi el mismo» componente, se le agrega una prop
   al existente (nada de `Label2`). Para que escritorio quede idéntico se usa el valor de fábrica en
   `md`: `{ xs: …, md: 'auto' }`. Un `xs` solo se emite como `@media (min-width:0px)` y llega también
   a escritorio.
5. **Tokens siempre.** Colores de `ColorsEpico`, tamaños de `FontSizesEnum` y pesos de
   `FontWeightEnum`. El catálogo tiene hex sueltos históricos: esos no se copian a código nuevo.
6. **`sx`, nunca `style=`.** `style` ignora los breakpoints de MUI y además gana sobre `sx` (anti-patrón 7
   de `docs/Patrones-Movil.md`).
7. Si el cambio toca `AdaptiveDataGrid`, `DataCardList`, `DataCard` o `cardFieldResolver`, el MR
   incluye una prueba de paridad fila/tarjeta (el modelo es
   `__tests__/app/features/customer/tableCustomersCardParity.test.tsx`) y el conteo de acciones antes
   y después.
8. **Corregir un defecto de un átomo compartido** se permite dentro del MR de una Spec solo si la
   Spec UX lo nombra, y con prueba. Ejemplo vigente: `UX-RES-02` de `UX-SPEC-F1-003` autoriza
   aplicar el `sxContainer` que `Label` declara y, en `release/busqueda-ia-1.0`, ignora.
   `UX-COMP-02` dice que ya «se corrigió», probablemente en la rama del prototipo: antes de
   repetirlo, revisar si ya está.
9. **El motivo de un control deshabilitado se ve en texto**, no solo en un `Tooltip`: en táctil el
   tooltip no aparece. Esto aplica a los componentes que envuelven con tooltip, como
   `AddProductTooltip`.
