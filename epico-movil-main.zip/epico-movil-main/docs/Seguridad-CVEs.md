# CVEs de dependencias — decisiones tomadas

Registro de los hallazgos de `npm audit` que se decidió **no corregir** en el momento, y por qué. La
intención es que la próxima vez que alguien corra `npm audit` y vea estos dos paquetes, no vuelva a
investigar desde cero ni los reporte como hallazgos nuevos.

Ver también `git log` de la rama `hotfix/cve-2025-55182`, donde se subió `next` de `15.5.6` a
`^15.5.26` para cerrar **CVE-2025-55182 / CVE-2025-66478** (React2Shell, RCE crítico en React Server
Components) — esa sí se corrigió. Desde nov-2026 el proyecto va en `next` 16.4 (lo subió el
original); la regla sigue: **nunca por debajo de 15.5.25**.

---

## ⚠️ El `package-lock.json` del original deshace nuestras subidas (nov-2026)

En la 11ª sincronización (release 4.0.1, Next 16) se tomó su `package-lock.json` para resolver el
conflicto y se corrió `npm install`. Resultado: **177 paquetes bajaron de versión** respecto del lock
del fork, entre ellos `axios` 1.20.0 → 1.13.1 (rango con avisos altos) y
`@aws-sdk/client-secrets-manager` 3.1138.0 → 3.948.0, **dentro del rango vulnerable** 3.894.0 –
3.972.0. `npm install` no lo corrige solo: si la versión del lock cumple el rango de `package.json`,
la respeta.

**Cómo se resuelve un conflicto del lock**: se parte del lock **nuestro** y se le aplica el
`package.json` fusionado, sin tocar `node_modules`, y después se comparan versiones:

```bash
git show HEAD:package-lock.json > package-lock.json     # (antes de commitear el merge; después, HEAD^1)
npm install --package-lock-only
npm install
```

Comprobado con un script que compara versión por paquete entre los dos locks: con este método solo
retroceden `@mui/system` y sus dos internos (7.3 → 6.5, a propósito: el original lo fija en `^6.5.0`
para emparejarlo con `@mui/material` 6.5).

`npm audit --omit=dev` al 4-nov-2026: con el lock del original, 1 crítica y 12 altas; con el
rehecho, **0 críticas y 6 altas**: `@serwist/build` y `@serwist/turbopack` (por `glob`/`zod`, solo
en build), `follow-redirects` (vía axios), `source-map-js`, `xlsx` (aceptada, ver abajo) y `zod`
3.x (el arreglo es la 4, un salto mayor). Pendientes de una pasada de dependencias aparte.

---

## postcss ≤8.5.22 — cerrado con Next 16 (nov-2026)

`next@16` ya no trae una copia anidada de postcss (`node_modules/next/node_modules` no existe) y la
raíz está en 8.5.28. Lo de abajo queda como historia.

## postcss ≤8.5.22 — riesgo aceptado (sep-2026, Next 15)

**GHSA:** qx2v-qp2m-jg93, 6g55-p6wh-862q, fxqj-rqcc-2cmp, r28c-9q8g-f849 (XSS y path traversal vía
`sourceMappingURL`).

La copia vulnerable **no** es la dependencia raíz que usa Tailwind (esa está en `8.5.28`, ya segura).
Vive empaquetada dentro de `next` mismo: `node_modules/next/node_modules/postcss@8.4.31`, declarada
como dependencia fija en el propio `package.json` de `next@15.5.26`.

Verificado (sep-2026): ningún parche `15.x` de Next.js —hasta el `15.5.26` actual, el último de esa
línea— actualizó ese postcss interno. La única versión que lo trae corregido es `next@16.3.6`
(`npm audit fix --force`), un salto de major con breaking changes.

**Por qué se acepta:** es una dependencia de build-time — Next la usa para procesar el CSS del propio
proyecto durante `next build`/`dev`, no para procesar input de un atacante en tiempo de ejecución. El
vector de ambos GHSA (`sourceMappingURL` en comentarios CSS controlados por el atacante) no aplica al
CSS que el propio equipo escribe.

**Cuándo revisar:** al migrar a `next@16` (fuera de alcance de este hotfix). Antes de esa migración,
volver a correr `npm audit` para confirmar que ninguna versión `15.x` posterior lo haya corregido.

---

## xlsx (SheetJS) — riesgo aceptado

**GHSA:** 4r6h-8v6p-xvw6 (Prototype Pollution), 5pgg-2g8v-p4x9 (ReDoS). Sin fix publicado en el
registro de npm.

Se rastreó el único punto de uso real del paquete en el repo:
[`CustomExportButton.tsx`](../features/common/infrastructure/ui/tables/CustomExportButton/CustomExportButton.tsx),
que solo llama `XLSX.utils.json_to_sheet` y `XLSX.writeFile` sobre datos que la propia app ya tiene en
memoria (exportar una grilla a Excel). En ningún archivo del repo se llama `XLSX.read` /
`XLSX.readFile` / `sheet_to_json` sobre un archivo `.xlsx` subido por el usuario — `ModalMassiveUpload`
reenvía el archivo tal cual al backend sin parsearlo en el cliente.

**Por qué se acepta:** ambas CVEs son de *parseo* de una hoja de cálculo maliciosa. Un uso de
solo-escritura sobre datos propios no las expone.

**Cuándo revisar:** si en algún momento se agrega una ruta que parsea un `.xlsx`/`.xls` subido por el
usuario en el cliente (con `XLSX.read` o `sheet_to_json`), esta decisión ya no aplica — hay que migrar
a esa función a una build parchada de SheetJS servida desde `cdn.sheetjs.com` (npm no publica los
parches) o a una librería alternativa como `exceljs`.

---

## sharp — corregido, pero exigió subir la imagen base de Docker a Node 20

> Nov-2026: el original subió los nueve `Dockerfile.*` a **Node 22** con la release 4.0.1 y `sharp`
> a `^0.35.5`. El fork conserva además su `USER node` (contenedor sin root).

**GHSA:** rgj7-g3m4-5g8c — libheif (decodificador AVIF/HEIF que `sharp` empaqueta) permite RCE al
decodificar una imagen manipulada. Corregido recién en `sharp@0.35.4`; **todas** las versiones
anteriores, incluida la línea `0.34.x`, siguen expuestas — no hay una versión parcheada que soporte
Node 18.

`sharp` se subió de `^0.33.5` a `^0.35.4` en el mismo commit que arregló CVE-2025-55182, pero
`sharp@0.35.x` exige `engines.node: >=20.9.0`. Los nueve `Dockerfile.*` construían sobre
`node:18-alpine`/`node:18-slim`, así que el build fallaba en el paso `next build` (que usa `sharp`
para el placeholder `blur` de `next/image`) con *"Could not load the sharp module using the
linuxmusl-x64 runtime"*.

**Se corrigió** subiendo las tres etapas (`dependencies`, `builder`, `runner`) de los nueve
`Dockerfile.*` a `node:20-alpine`/`node:20-slim`. No se bajó `sharp` a `0.34.x` porque eso habría
revertido el arreglo del RCE de libheif — en un hotfix de seguridad, bajar la versión de un paquete
para esquivar un error de build no es aceptable cuando esa versión es la única que trae el CVE
corregido.

**Pendiente de verificar fuera de este repo:** confirmar que el clúster/runner de despliegue soporta
imágenes basadas en Node 20 (debería, es LTS desde 2023), y que ningún otro Dockerfile o script fuera
de este repo asume Node 18.
