# Bugs encontrados durante la adaptación móvil

Hallazgos de la adaptación responsiva de EPICO (rama `feature/AdaptacionMovil`, julio 2026). La
mayoría **no son problemas de la vista móvil**: salieron al revisar el service worker, el consumo de
datos y el flujo de checkout, y afectan por igual a escritorio.

Cada hallazgo dice de dónde viene. La distinción importa para saber qué revisar en el código que
sigue en producción:

- **Preexistente** — ya estaba en `main` antes de este trabajo. Es lo que conviene mirar con calma.
- **Introducido aquí** — lo introduje yo durante la adaptación y ya está corregido. Se listan para
  que quede el registro completo, no porque haya que hacer algo.

---

## Críticos

### 1. IndexedDB dejó de funcionar por completo

**Introducido aquí** · corregido en `00a27dca3`

Al eliminar los `importScripts` a `cdn.jsdelivr.net` del service worker se perdió el global
`self['JsStoreWorker']`, que es de donde JsStore saca su motor cuando la conexión se crea sin
argumentos (`worker/db.ts`: `new JsStore.Connection()`).

```js
// node_modules/jsstore/dist/jsstore.js:353
get jsstoreWorker() { return this.$worker || self['JsStoreWorker']; }
// jsstore.js:471 — pushApi, lanza de forma SÍNCRONA
if (!this.jsstoreWorker && !this.worker_) throw new Error("JsStoreWorker not found...")
```

Toda operación de IndexedDB fallaba. Se corrigió inyectando el motor con
`jsstore/dist/worker_injector`, que viene en el paquete ya instalado.

> **Lo que vale la pena revisar:** `new Connection()` sin argumentos es frágil por diseño — depende
> de un global que nada en el código del proyecto declara ni verifica. Si alguien toca los
> `importScripts` otra vez, vuelve a romperse en silencio.

### 2. El service worker nunca contestaba ante un error → cuelgues permanentes

**Preexistente** · corregido en `9d0e13b8d`

Este es el más importante para el equipo, porque **sigue explicando cualquier pantalla que se quede
cargando para siempre**.

`dbStoreMessage` (`features/common/application/dbStoreMessage/index.ts`) usa `messageSW` de
`@serwist/window`, que abre un `MessageChannel` y devuelve una promesa que **solo** se resuelve
cuando el worker contesta por `event.ports[0]`.

Había cinco ramas que terminaban sin contestar, haciendo únicamente `console.error`:

| Archivo | Rama |
|---|---|
| `worker/dbEpico/index.ts` | el `catch` general |
| `worker/dbEpico/index.ts` | el `default` (`"Method not allowed"`) |
| `worker/dbEpico/index.ts` | `create` cuando `dataCreate` llega vacío |
| `worker/index.ts` | el `catch` del manejador de mensajes |
| `worker/db.ts` | los `default` de `dbManager` e `imagesDbManager` |

Consecuencias:

1. El `await` del cliente **no vuelve nunca**. El `finally` que apaga el spinner no corre.
2. No hay error visible: el `console.error` queda en la consola **del service worker**, no en la de
   la página, que es donde uno busca.

Esto fue lo que volvió indiagnosticable el bug 1: el síntoma reportado fue *"selecciono un cliente,
doy clic en Búsqueda de producto y el botón se queda girando"*, sin nada en consola.

Ahora toda salida pasa por `worker/replyWithError.ts`, que registra y contesta un `IResponseDB` con
`hasError`. **Un error propagado siempre es preferible a un cuelgue silencioso.**

### 13. Agregar un producto nuevo a una cotización vigente falla con 500 en `Pedidos/{id}/Detalle`

**Preexistente** · **documentado, no corregido**

Diagnosticado el 17-09-2026 en la rama `feature/propuesta-en-cotizaciones`, reportado como *"al
agregar productos con el buscador de productos desde la edición de una cotización vigente, sale el
mensaje genérico de error"*.

**Reproducción:**

1. Ir a `Clientes/Informacion/Cotizacion?cvid=<id>` de un cliente con cotizaciones (probado con
   CLIENTE MOSTRADOR, `cvid=167324`).
2. Abrir en modo **Editar** una cotización con Origen "Cotización" (una cotización vigente normal,
   **no** una propuesta) que ya tenga al menos un producto — en la prueba, la cotización 147411.
3. En el campo "Código" del buscador de productos (`ProductCode.tsx`), capturar el código de un
   producto que **todavía no esté en el pedido** (en la prueba, `5903903`, encontrado vía el
   catálogo) y pulsar "Agregar a pedido".
4. Sale el snackbar genérico `GENERIC_ERROR_MESSAGE_CAE`: *"Error, intenta nuevamente, si el error
   persiste comunícate al Centro de atención Exodus (CAE)"*.

**Nota:** si el código capturado ya es el de un producto que **ya está** en el pedido, la operación
sí funciona (el backend la resuelve como incremento de cantidad vía `PATCH
/api/proxy/api/v3/Pedidos/{pedidoId}/Detalle/{pedidoDetalleId}`, que responde 200). El error solo
aparece al agregar una línea genuinamente nueva.

**Endpoint que falla:**

```
POST /api/proxy/api/v3/Pedidos/147411/Detalle?HistorialId=10988
→ 500 Internal Server Error
{"statusCode":500,"data":null,"huboError":true,"error":{"mensaje":"Se produjo un error al procesar la solicitud.","erroresValidaciones":[]}}
```

`handleRequestDto` recibe `statusCode: 500` / `huboError: true` y por eso cae al mensaje genérico:
la respuesta no trae ningún detalle de validación, así que del lado del front no hay más señal que
seguir. El problema está del lado del gateway/servicio que atiende `Pedidos/{id}/Detalle` (fuera del
alcance de este agente).

**Verificado que es preexistente:** se reprodujo con `git stash` aplicado sobre
`feature/propuesta-en-cotizaciones` (árbol de trabajo limpio, sin ninguno de los cambios en curso de
esa rama) y reiniciando el dev server para forzar la recompilación. El 500 ocurre igual, así que no
es una regresión introducida por los cambios en curso en `TableDetailArticles.tsx`,
`SelectDiscount.tsx`, `HeadBranchEditQuotation.tsx`, `CheckoutDetailFooterEditQuotation.tsx` ni
`ProductCode.tsx`.

---

## Consumo de datos

Contexto: la PWA está pensada para vendedores en **datos móviles**, no wifi.

### 3. Un speedtest corriendo solo cada 10 minutos

**Preexistente** · corregido

`NavBarSpeedTest.tsx` está montado en `app/(epico)/layout.tsx`, o sea en **todas** las pantallas, y
ejecutaba `setInterval(runSpeedTest, 10*60*1000)` con `@cloudflare/speedtest`, que mide la velocidad
**descargando y subiendo datos reales**. Corría con la app abierta aunque el usuario no hiciera nada.

Se sustituyó por `navigator.connection` (`effectiveType`, `downlink`, `saveData`): la misma señal,
cero bytes. Se conservaron el aviso y el registro.

De paso, incoherencias del mismo archivo: el JSDoc decía *"every 2 minutes"* y el código usaba 10; el
JSDoc decía *"greater than"* y el código evaluaba `<`.

### 4. La caché del service worker estaba anulada por un listener `fetch`

**Preexistente** (viene de `2699e5694 Hot fix/workbox`) · corregido

`worker/index.ts` registraba un listener `fetch` que hacía `event.respondWith(fetch(event.request))`
cuando `isXHR === false`. `isXHR` comprobaba la cabecera `x-requested-with`, **que nadie envía**
—axios no la añade, y un grep confirma que solo aparecía dentro del propio worker—.

Además se registraba **antes** de `serwist.addEventListeners()`, y por especificación el primer
`respondWith` gana. Resultado: `precacheEntries` y `runtimeCaching` **nunca sirvieron nada**. La app
volvía a descargar todos sus chunks en cada visita.

### 5. Las fotos de producto se re-descargaban cada hora

**Preexistente** · corregido

`imageCache.ts` tenía `EXPIRATION_MS = 60*60*1000`. Las fotos de producto son inmutables. Se subió a
30 días; la vía de invalidación manual ya existía (`actionsEnum.cleancachedimages`).

### 6. Descarga de imágenes sin límite de concurrencia

**Preexistente** · corregido

`Promise.all(productos.map(fetch))` lanzaba N peticiones simultáneas sin tope. En un enlace móvil
malo eso genera encolado, timeouts y reintentos que gastan **más** datos que la descarga ordenada. Se
acotó a 5 en vuelo con un pool.

---

## Seguridad y privacidad

### 7. `defaultCache` habría cacheado respuestas del gateway autenticado

**Preexistente (latente)** · evitado

`defaultCache` de `@serwist/next` incluye una regla `NetworkFirst` para `/api/**` con
`maxAgeSeconds: 24h` y `networkTimeoutSeconds: 10`. `/api/auth/*` está excluido, pero
**`/api/proxy/*` no** — y por ahí pasa todo el tráfico al gateway.

De haber estado activa habría guardado respuestas GET autenticadas 24 horas y caído a caché tras 10
segundos de red mala: precios, existencias y saldos viejos, y en un dispositivo compartido, **datos
del usuario anterior**.

Nunca llegó a activarse por el bug 4 — pero se habría activado en el momento en que alguien lo
arreglara. Se reemplazó por una lista explícita donde `/api/**` es `NetworkOnly`, innegociable.

**Cómo verificarlo:** en DevTools → Application → Cache Storage no debe existir ninguna entrada con
`/api/proxy`. Prueba obligada antes de liberar: login usuario A → navegar → logout → login usuario B
→ cero datos de A.

### 8. Datadog subía el texto real de la interfaz

**Preexistente** · **resuelto retirando Datadog**

`app/DatadogInitializer.tsx:24` usaba `defaultPrivacyLevel: 'allow'`, que envía a Datadog el
contenido real de la pantalla —nombres de clientes, precios— en las sesiones que graban replay. Con
`sessionSampleRate: 100` y `sessionReplaySampleRate: 30`, era el 30% de todas las sesiones de
producción.

Por decisión del negocio **se retiró Datadog por completo**, no solo el nivel de privacidad: el
componente, su montaje en `app/layout.tsx`, los paquetes `@datadog/browser-rum` y
`@datadog/browser-rum-react`, y la variable `NEXT_PUBLIC_DATADOG_ACTIVO` de los cinco ambientes.

> ⚠️ **Consecuencia**: producción se queda **sin monitoreo de usuario real**. No hay reemplazo. Si
> más adelante se quiere volver a instrumentar, el nivel de privacidad correcto es
> `mask-user-input`, no `allow`.

---

## Layout móvil

### 9. Regla responsiva invertida en el resumen de cotización

**Preexistente** (viene de `e6885e85f`) · corregido en `25db55ea9`

```ts
// QuotationSummary.styles.ts
export const SummarySx: SxProps = {
    display: 'flex',
    '@media (max-width:860px)': { flexDirection: 'row' }   // fuerza FILA en móvil
}
```

Forzaba fila precisamente en pantallas chicas, así que el texto legal (80%) y los totales (20%) se
quedaban lado a lado y se encimaban. Además usaba 860px, un breakpoint que no existe en el proyecto
(el de MUI y el de `BreakpointEnum` es 900).

### 10. Otros patrones de desborde horizontal

Los ocho patrones que explican casi todos los desbordes están documentados aparte, en
**[Patrones-Movil.md](./Patrones-Movil.md)**, con el tratamiento que corresponde a cada arquetipo de
pantalla. Los dos que más sorprenden:

- **`style=` ignora los breakpoints de MUI.** Encontrado tres veces. Un `style={{width: 500}}` no
  responde a `xs`/`md`; hay que usar `sx=`.
- **`spacing` de MUI aplica `margin-left`, no `gap`.** Con un hijo `width: 100%` el contenedor
  desborda exactamente esa cantidad. Se resuelve con `useFlexGap`.

---

## Entorno de desarrollo

### 11. `npm run dev` no arranca: el service worker no compila y Next queda sin manifiestos

**Preexistente** · corregido el 14-09-2026 en la rama `feature/ligar-pedido-propuesta`

`npm run dev` terminaba en `Internal Server Error` en cualquier ruta, con este par de síntomas en la
terminal:

```
⨯ Multiple instances of self.__SW_MANIFEST were found in your SW source. Include it only once.
⨯ [Error: ENOENT: no such file or directory, open '...\.next\fallback-build-manifest.json']
 GET / 500
```

Los dos son el mismo problema. Workbox busca el literal `self.__SW_MANIFEST` en el código del worker
mediante una **búsqueda textual** y falla si aparece más de una vez. En `worker/index.ts` aparecía
tres veces: la referencia real de la línea 47 y **dos comentarios** que, al explicar el mecanismo,
escribían el token completo. Al fallar la compilación del worker, webpack deja `.next` incompleto y
Next no encuentra `fallback-build-manifest.json` — de ahí el 500.

Se corrigió reescribiendo los dos comentarios para que no contengan el literal. No hay cambio de
comportamiento.

> **Por qué nadie lo había visto:** en los builds de producción los comentarios se eliminan antes de
> que Workbox haga su búsqueda, así que sólo queda una ocurrencia y compila. El error aparece
> únicamente en `next dev`. Quien haya trabajado siempre contra un ambiente desplegado no se topa
> con él.

> **Lo que vale la pena cuidar:** no escribir `self.__SW_MANIFEST` completo en comentarios,
> documentación o JSDoc dentro de `worker/`. El comentario que lo provocaba era, irónicamente, el que
> advertía que esa referencia debía conservarse. Quedó una nota en el archivo explicándolo.

### 12. Un `package-lock.json` suelto en el directorio de usuario secuestra la raíz del workspace

**No es del proyecto** · se documenta porque el síntoma es idéntico al del hallazgo 11

Si existe un `package-lock.json` en un directorio ancestro (por ejemplo `C:\Users\<usuario>\`,
tras un `npm install` corrido por error fuera del repo), Next lo toma como raíz del workspace y
busca los manifiestos de build en el lugar equivocado. El resultado es el mismo `ENOENT` de
`fallback-build-manifest.json` y el mismo 500.

Next lo avisa, pero como **advertencia al inicio del arranque**, muy por encima del error, así que es
fácil pasarla por alto:

```
⚠ Warning: Next.js inferred your workspace root, but it may not be correct.
We detected multiple lockfiles and selected the directory of C:\Users\<usuario>\package-lock.json
```

Se resuelve quitando el lockfile ajeno y borrando `.next`. No conviene "arreglarlo" fijando
`outputFileTracingRoot` en `next.config.mjs`: eso mete en el repo una configuración para resolver un
problema que sólo existe en una máquina.

---

## Pendientes — requieren decisión del equipo

### A. `changeImgSize` no hace nada

`features/common/infrastructure/utils/image.ts:6-8`

```ts
export const changeImgSize = (imgSrc: string) => {
    return imgSrc.replace(/(\d)([a-zA-Z])\.JPG$/, "3$2.JPG");
};
```

La expresión regular exige `.JPG` **en mayúsculas**, pero las URLs se construyen con `.jpg`
(`imageCache.ts:176,284`). La función devuelve la cadena intacta: **nunca se piden miniaturas**.

El impacto es grande: la galería de producto descarga todas las caras a tamaño completo para pintar
miniaturas de 50px (`ImgGallery.tsx:86`).

**Está bloqueado**, no olvidado: arreglarlo exige conocer la convención `{código}{tamaño}{cara}.jpg`
de `resources.apymsa.com.mx` —qué significan el 1, el 2 y el 3—, y eso no se puede deducir del
repositorio. Hay que preguntárselo a quien administre ese bucket.

### B. Notificaciones push — dos problemas distintos

**Preexistentes los dos.** Ninguno tiene que ver con la adaptación móvil.

#### B.1 — Chrome muestra "este sitio se ha actualizado en segundo plano"

Reportado por el usuario: *"me salió una notificación de que el sitio de epico-movil se había
actualizado, pero yo no estaba lanzando ninguna actualización"*. **No era un despliegue.**

El manejador de `push` (`worker/index.ts`) solo muestra notificación cuando `data.esNativa` es
verdadero:

```ts
if (data.esNativa) {
    self.registration.showNotification(data.titulo, { ... });
} else {
    // solo postMessage a las ventanas abiertas — nunca llama showNotification
}
```

La especificación de Web Push obliga a que todo push recibido produzca una notificación visible.
Chrome tolera unos cuantos push silenciosos y, al agotarse ese margen, **muestra su propia
notificación genérica**: *"Este sitio se ha actualizado en segundo plano"*. Eso es lo que vio el
usuario.

Se dispara cuando llega un push con `esNativa: false` y la app está cerrada o en segundo plano: no
hay ventanas a las que hacer `postMessage`, así que el push no produce nada visible.

**Qué hacer:** que la rama `else` muestre también una notificación, o que el backend deje de enviar
push no nativos cuando no hay cliente activo. Para confirmarlo basta cruzar la hora del aviso con los
envíos de push del backend.

#### B.2 — Al tocar la notificación no pasa nada

El handler `notificationclick` solo existía en `worker/index.js`, un archivo que **nunca se compiló**:
`next.config.mjs` declara `swSrc: "worker/index.ts"`. Es decir, ya estaba muerto desde antes —las
notificaciones ya no respondían al tap—. Hay que reimplementarlo en `worker/index.ts`.

### C. Buscar desde la página 2 en Pedidos Externos no devuelve nada

**Preexistente** · **documentado a petición del negocio, no corregido**

En `features/orders/infraestructure/ui/externalOrders/externalOrders.tsx`, el `onSearch` del buscador
fija `ClienteId` pero **no reinicia `Pagina`**:

```tsx
onSearch={(value) => {
    if (value === '' || value.length < 3) return;
    setSearchParams({ ...searchParams, ClienteId: value });   // Pagina se queda como estaba
}}
```

Si el usuario paginó a la 2 o más y luego busca, se pide esa página de un resultado que casi siempre
tiene una sola: la pantalla responde "No se encontraron resultados" para un cliente que sí existe. El
filtro "Tipo pago", tres líneas más abajo, sí hace `Pagina: 1`; este no.

**Por qué no se corrigió aquí**: hacerlo bien exige reordenar los dos `useEffect` de paginación
(`[searchParams]` y `[paginationModel]`). Reiniciar solo `searchParams.Pagina` deja el pie del grid
mostrando la página 2 mientras los datos son de la 1; reiniciar ambos dispara **dos peticiones** por
cada búsqueda. Se decidió dejarlo documentado en vez de introducir una regresión de red.

### D. `ChunkLoadError` tras un despliegue

**Preexistente** · **corregido**

`self.skipWaiting()` + `clients.claim()` entregan el service worker nuevo a una pestaña que sigue
ejecutando el JS del build anterior. En cuanto esa pestaña pide un chunk diferido —una tabla, el
exportador de Excel— pide un hash que el despliegue nuevo ya no sirve (`Dockerfile.prod` copia solo
el `.next/static` del build vigente) y la pantalla revienta, sin más salida que cerrar la app.

El riesgo **subió** con la carga diferida de la Fase 3: hay más chunks que se piden tarde, ya con la
pantalla abierta.

Corregido con `app/ChunkErrorReloader.tsx`, montado en `app/layout.tsx`: escucha `error` y
`unhandledrejection`, reconoce el fallo de carga de chunk (incluidos los mensajes de CSS y de módulo
dinámico, que no siempre se llaman `ChunkLoadError`) y recarga. La recarga trae el HTML nuevo con los
hashes nuevos porque el documento se sirve `NetworkFirst`.

Con protección de bucle: una sola recarga cada 30 s, marcada en `sessionStorage`. Si tras recargar el
chunk sigue faltando, el problema no es de versión y no tiene sentido gastarle datos al usuario
recargando en ciclo.

### E. Agregar a pedido puede fallar en silencio

**Preexistente** · **documentado, no corregido**

En `ProductCard`, el botón de agregar llama primero a `validateProductPrice`, que vuelve a pedir el
producto con el cliente activo. Esa función hace:

```tsx
const {mejorPrecio} = productResponse.data!;   // ← `mejorPrecio` no se usa en ninguna parte
return {...productResponse.data!, /* ... */ }
```

Cuando el producto no es válido para el cliente de ahora, `data` llega `null` y la desestructuración
revienta **dentro de un `onClick` sin `try/catch`**: no se agrega nada y no aparece ningún mensaje.
El vendedor pulsa y no pasa nada. Lo irónico es que `mejorPrecio` no se usa: la línea solo existe
para tronar, porque el objeto que se devuelve ya hace `spread` del mismo `data`.

Se llega ahí porque el botón viene **habilitado**: `disabled` mira `product.sinPrecio`, que es un
dato del objeto en pantalla —congelado del cliente con el que se buscó—, no del cliente actual. Una
pieza sin precio para el cliente X queda además inagregable para el Y aunque sí pueda comprarla.

**Por qué no se corrigió aquí**: `ProductCard` y `validateProductPrice` están en el camino de agregar
del catálogo, del historial de compras y de dos modales. Un arreglo de presentación del chat no puede
llevarse por delante el camino del dinero de todo el catálogo. Por eso, además, el aviso de contexto
del asistente (5.4 del análisis técnico) **no promete** que el precio se recalcule al agregar: en
este camino la propia pantalla lo impediría.

El arreglo, cuando se decida: borrar la desestructuración muerta, envolver la llamada en `try/catch`
con snackbar, y pasar el estado de precio del cliente actual al `disabled`.

### F. `console.log` de los criterios de búsqueda en Monitoreo de pedidos

**Preexistente** · **llegó en la 3.34.0** · **documentado, no corregido**

`Monitoring.tsx:407`, dentro del armado de la consulta:

```tsx
console.log("Query Params:", queryParams); // Log the query parameters for <debugging />
```

Se ejecuta en cada búsqueda, también en producción, y `queryParams` lleva `Cliente`, `PedidoId`,
`FacturaId` y `OrdenCompra`. No es una fuga grave —queda en la consola del propio navegador—, pero
son datos de clientes y pedidos a la vista de cualquiera que abra las herramientas de desarrollo o
comparta pantalla, y ruido permanente para depurar otra cosa.

**Por qué no se corrigió aquí**: es código suyo recién llegado y borrarlo crea divergencia en una
línea que van a seguir tocando. Se reporta para que lo quiten en origen. Si el equipo decide dejarlo,
en el fork conviene quitarlo igual antes del siguiente despliegue a producción.

### G. Encontrados en la 11ª sincronización y en la auditoría de escritorio (nov-2026)

Son del original. Los dos primeros el fork los dejó tal cual en escritorio, para no cambiarlo; el
tercero lo corrigió en las dos experiencias porque descuadraba los montos.

- **`Counter` con `min = 1` no deja borrar el 1** (detalle de la caja): vaciar el campo devuelve el
  mínimo al instante, así que lo que se teclea se pega al 1 («15» en vez de «5»). En el fork se
  arregló solo en móvil.
- **El resumen de cotización encima el tercer botón** con una razón social larga entre 900 y 1050px.
- **`SummaryGeneric`: con taller sin plan de lealtad, la fila de Kms del valor se pinta sin su
  etiqueta** (el valor usaba `isTaller` y la etiqueta `isTaller && plan de lealtad`), así que cada
  valor queda junto a la etiqueta equivocada. El fork lo corrigió también en escritorio.
- **`.env.uat` no tiene `NEXT_PUBLIC_OBJETO_APARTADOMERCANCIA_ID`**: cada consulta de existencias en
  uat hace una petición extra a `/api/v1/Origen/16/Objeto/NaN` que falla en silencio.
- **Su `package-lock.json` (release 4.0.1) fija `@aws-sdk/client-secrets-manager` 3.948.0**, dentro
  del rango vulnerable 3.894.0 – 3.972.0, y `axios` 1.13.1 (avisos altos). Ver `docs/Seguridad-CVEs.md`.

---

## Cómo reproducir y verificar

```bash
npx tsc --noEmit
npm run lint
npm run testJest      # ojo: `npm run test` NO corre Jest, levanta el dev server
```

Para lo del service worker hay que **desregistrarlo** (DevTools → Application → Service Workers →
Unregister) y recargar: el navegador conserva el anterior y los cambios no se ven. El procedimiento
de emergencia está en [`worker/KILL-SWITCH.md`](../worker/KILL-SWITCH.md).

Para el layout: recorrer a 360px de ancho comprobando que ninguna página tenga desplazamiento
horizontal.
