# Análisis técnico de EPICO

Este documento existe para que alguien que nunca ha visto el proyecto —con o sin una IA de copiloto—
pueda cambiar algo sin romper lo que ya funciona. No es un tutorial de Next.js: es el mapa de las
decisiones que este código ya tomó y de las trampas que se han cobrado tiempo de verdad.

Orden de lectura: este archivo; luego [Patrones-Movil.md](./Patrones-Movil.md) si vas a tocar UI, y
[Auth-BFF.md](./Auth-BFF.md) si vas a tocar autenticación o llamadas al gateway.

---

## 1. Qué es esto

EPICO es la PWA interna de APYMSA (refacciones automotrices) que usa la fuerza de ventas: catálogo de
productos, armado de pedidos, checkout con varios motores de envío, clientes, cotizaciones,
promociones, garantías, digitalización, monitoreo de pedidos y torre de control.

Tamaño real, para calibrar: **31 features**, **37 páginas**, **478 componentes de UI**, 22 servicios
HTTP, 15 slices de Redux y más de 160 000 líneas en `features/`. No es un proyecto que se entienda de
una lectura; se entiende feature por feature.

### Este repositorio no es el original

Hay dos repositorios y **la diferencia importa antes de escribir una línea**:

| | |
|---|---|
| `epico/epico` | El proyecto original, que sigue en desarrollo activo por el equipo. **Se trae (`git fetch`), no se pushea nunca** |
| `epico/epico-movil` | Este. El fork donde vive la adaptación móvil. Único destino de `git push` |

Si estás leyendo esto dentro de `epico-movil`, tu trabajo es la **experiencia móvil (<900px) sin
alterar escritorio**, y cada pocos días hay que traer lo nuevo del original con `git merge
origin/main`. El procedimiento está en la sección 8.

**Desde el 4-nov-2026 el fork deja de ser una app aparte: se llama «Epico» y un mismo contenedor
atiende las dos URLs**, la suya (`epico-movil.…`) y la del original (`epico.…`). Lo decidió el equipo
(MR `hotfix/movil` de Jonatan Cárdenas) y se completó en la 11ª sincronización:

- `.gitlab-ci.yml` lleva `STACK_NAME: epico`, el mismo stack que el original. Los jobs hacen
  `docker stack rm $STACK_NAME` antes de desplegar, así que **desplegar el fork quita el contenedor
  del original** en ese ambiente y pone el nuestro. Si el equipo del original vuelve a desplegar
  desde su repo, pasa lo contrario: hay que acordar que solo despliegue uno de los dos.
- Cada `<ambiente>.yml` (los nueve) tiene un solo router de Traefik **con el nombre del original**
  (`epico`, `epicouat`, `epicosr`, `epicotestf2`, `epicosecond`, `epicomb`) y la regla
  `Host(<url -movil>) || Host(<url del original>)`. El nombre importa: los stacks viejos del fork
  (`epico-movil`, `epico-movilsr`, …) **no los quita nadie** y siguen declarando sus routers
  `*-movil`. Si el nuevo usara ese mismo nombre, Traefik vería el router definido dos veces con
  reglas distintas y lo descartaría. Con otro nombre no chocan, y para la URL `-movil` gana el
  nuevo porque su regla es más larga (Traefik prioriza por longitud).
- **Pendiente de operar a mano**, una vez por ambiente después del primer despliegue:
  `docker stack rm epico-movil` (y `epico-movilsr`, `epico-movilsecond`, `epico-moviltestf2`,
  `epico-moviltestmb` donde existan). No afectan el tráfico, pero ocupan memoria.
- Nombre e ícono son los del original («Epico», sin la insignia del teléfono que distinguía la PWA de
  prueba). En un teléfono que ya tenía «Epico Movil» instalada, el nombre nuevo solo aparece al
  desinstalar, reiniciar y reinstalar (Android cachea la etiqueta del WebAPK).
- Al sincronizar, si el original toca sus `*.yml`, conservar las dos URLs y su nombre de router.

**Fusionar a `main` no despliega nada.** Desde la migración al registro Harbor (26-ago-2026) el
pipeline es simple de leer: **todos** los jobs de `config/gitlab-ci/containerize.yml` y
`deployment.yml` exigen `$CI_COMMIT_BRANCH =~ /^release/` y son `when: manual`, y los de producción
(`release.yml`) exigen `$CI_COMMIT_TAG`, también manuales. En `main` no corre nada. Para que un cambio
llegue a un ambiente hay que llevarlo a una rama `release/*` y lanzar el job a mano; a producción, con
una etiqueta.

---

## 2. La tecnología

| Para qué | Con qué | Notas |
|---|---|---|
| Framework | **Next.js 16.4** (App Router, build con **Turbopack**) + **React 19.3** | `output: "standalone"`; casi todo es `"use client"`. Subió desde 15.5 con la release 4.0.1 del original (nov-2026) |
| Lenguaje | **TypeScript 5**, estricto | Nada de `any`; variables sin usar solo con prefijo `_` |
| UI | **MUI 6.1** + `x-data-grid` 7.24 + `x-date-pickers` 7.24, **Emotion 11** | El estilo va en `sx`; el tema, en `config/theme/` |
| Estado | **Redux Toolkit 2.5**, react-redux 9.2, **redux-persist 6** + `transform-encrypt` 5.1 | Ver sección 5.2 |
| HTTP | **axios 1.7** | Una sola instancia: `EPICO_API` |
| Validación | **zod 3.24** (25 archivos) | Yup y Formik quedan en 2 archivos cada uno: **no son el patrón** |
| PWA / sin conexión | **Serwist 9** (`@serwist/turbopack` + `@serwist/window`) + **JsStore 4.9** sobre IndexedDB | Ver sección 5.3 |
| Sesión de servidor | **redis 4.7**, `jwt-decode` 4 | Ver sección 5.1 |
| Fechas | **dayjs 1.11** (65 archivos) y date-fns 4 (8) | **Usa dayjs**; date-fns es residual |
| Gráficas | ApexCharts 4.5 y ECharts 6 | Conviven; mira qué usa la pantalla vecina antes de elegir |
| Mapas | `@vis.gl/react-google-maps` | Geoposición y autocompletado de direcciones |
| Otros | `xlsx` (exportar), `tesseract.js` (OCR de la cámara), `react-slick`, `react-draggable`, `framer-motion`, `react-number-format`, `lodash`, `sharp`, `@aws-sdk/client-secrets-manager` | |
| Tests | **Jest 29** + jsdom + **Testing Library 16** | Ver sección 8 |
| Lint | **ESLint 9** (`eslint.config.mjs`, flat config) + `eslint-config-next` 16 | `next/core-web-vitals` + `next/typescript`; `npm run lint` es `eslint .` |
| Imagen Docker | **Node 22** (`node:22-alpine` / `node:22-slim`), usuario `node` | Ver sección 8 |

Tres cosas que sorprenden y conviene saber antes de "seguir la convención":

- **Formik y Yup casi no se usan** (2 archivos cada uno) aunque estén en `package.json`. Los
  formularios reales son componentes controlados a mano, y la validación es **zod**. No montes un
  Formik nuevo por inercia: mira el formulario vecino.
- **Tailwind está instalado y es prácticamente decorativo**: las directivas están en `globals.css`
  pero solo tres archivos usan clases suyas. El estilo de verdad es `sx` de MUI.
- **`@cloudflare/speedtest` es una dependencia fantasma**: nadie la importa. La medición de ancho de
  banda de `NavBarSpeedTest` está hecha a mano contra `speed.cloudflare.com`.

---

## 3. El mapa

```
app/                     Rutas (App Router). Dos grupos: (auth) y (epico).
  (epico)/layout.tsx     El shell: menú lateral, validación de permisos por ruta, redirecciones.
  api/                   Solo 5 rutas de servidor: auth/ids4, auth/logout, auth/session,
                         logred y proxy/[...path]. Todo lo demás pasa por el proxy.
features/<feature>/      Todo el código de negocio, en tres capas fijas (ver sección 4).
routes/paths.ts          PATH_AUTH y PATH_PAGE. Ningún path se escribe a mano en un componente.
axios/axios_helper.ts    La instancia EPICO_API y sus interceptores.
worker/                  Service worker (Serwist) y capa sin conexión (JsStore/IndexedDB).
config/theme/            Tema de MUI. El breakpoint md=900 es la frontera de la experiencia móvil.
config/gitlab-ci/        El pipeline, partido en containerize / deployment / release.
context/                 Contextos globales (snackbar, cámara, etc.).
enviroments/.env.*       Cinco ambientes: dev, test, stg, uat, prod.
__tests__/               Jest + Testing Library, espejando la ruta del feature.
docs/                    Este archivo y los otros dos documentos de arquitectura.
```

---

## 4. Los patrones que sigue este código

Respetarlos importa más que tu estilo personal: son lo que hace que 478 componentes se puedan leer.

### 4.1 Capas por feature (Clean Architecture)

Cada feature en `features/<feature>/` tiene tres capas, y la dirección de las dependencias no se
negocia:

- **`domain/`** — interfaces con prefijo `I`, enums, y `data/` con estados iniciales y datos
  estáticos. **Sin dependencias de React ni de APIs.**
- **`application/`** — `redux/` (slice y thunks del feature), `service/` (llamadas HTTP), `actions/`
  (lógica de casos de uso).
- **`infrastructure/`** — `api/` (constantes de URL, patrón `*Url.ts`), `hooks/`, `ui/` (componentes).

Un componente consume el servicio del feature, no `axios`. Un servicio consume la URL declarada en
`infrastructure/api/`, no una cadena literal.

`features/common/` es la excepción: ahí viven los componentes compartidos, los enums de estilo
(`ColorsEpico`, `FontSizesEnum`, `FontWeightEnum`), los hooks tipados de Redux y el
`AdaptiveDataGrid`. **Antes de crear cualquier componente genérico, busca ahí: casi siempre ya
existe.**

### 4.2 Servicios como fábricas

Un servicio es un archivo `<feature>.services.ts` que **exporta una función** que devuelve las
operaciones:

```ts
const { getGeneralInfo } = customerService();
const response = await getGeneralInfo(clienteId);
```

No son clases ni hooks. Se llaman dentro del componente o del thunk, no en el cuerpo del render.

### 4.3 El sobre de respuesta y `handleRequestDto`

Todo lo que devuelve el gateway viene envuelto en `IResponseDto<T>`:

```ts
{ statusCode: number; data: T; huboError: boolean; error: IErrorDto }
```

**Ojo: no hay campo `success`.** El éxito se decide con `statusCode` **y** `huboError`, y esa decisión
no se escribe a mano: se delega en `handleRequestDto`, que usan **189 archivos**:

```ts
await handleRequestDto({
    response,
    snackBar: showSnackbar,
    messages: { error: MENSAJE_DE_ERROR },
    onSuccess: () => { /* ... */ },
    onInvalid: () => { /* 204, o data en null */ },
});
```

Reparte en tres ramas —éxito, inválido, error—, muestra el snackbar y **maneja el 401 redirigiendo a
Login sin caer en el bucle** cuando ya estás ahí. Escribir el `if (response.statusCode === 200)` a
mano se salta todo eso.

### 4.4 Páginas delgadas

Toda página de `app/` es un envoltorio que solo renderiza el componente principal del feature (ej.
`app/(epico)/Catalogo/page.tsx` → `features/catalogue/infrastructure/ui/Catalogue`). Si encuentras
lógica en `app/`, está fuera de lugar. Las rutas navegables se declaran en `routes/paths.ts`
(`PATH_AUTH`, `PATH_PAGE`) — **nunca un path literal en un componente**.

### 4.5 Adaptador de tabla: `AdaptiveDataGrid`

En ≥900px es un passthrough a `DataGridServerPagination`; en <900px pinta tarjetas **reutilizando el
`renderCell` y el `valueGetter` de las mismas columnas**. Migrar una tabla es cambiar el import y, si
hace falta, pasar `cardOptions`. Con `cardOptions.renderCard` puedes dar una tarjeta a medida sin
perder la paginación de servidor, los estados vacíos ni el skeleton. Es el patrón que evita mantener
dos tablas.

### 4.6 Un juego de controles, dos disposiciones

Cuando una pantalla necesita layouts distintos en móvil y escritorio, los controles **se declaran una
sola vez** en variables y luego hay `if (isMobileExperience) return (<disposición móvil>)` seguido de
la de escritorio, que se deja exactamente como estaba. Así ninguna de las dos se queda sin un control
cuando la otra cambia. Duplicar el JSX es lo que hace que un botón exista en una y no en la otra.

### 4.7 Mensajes con el worker por enum

La UI no habla con IndexedDB: le manda un mensaje al service worker con los enums `WorkerActions` y
`WorkerDBTables` (`features/common/domain/enums/`). Tabla nueva = esquema en `worker/schemas/` +
entrada en el enum + el CRUD genérico de `worker/dbEpico/crud/`.

---

## 5. Los sistemas transversales

### 5.1 Autenticación: el token nunca llega al navegador

Detalle completo en [Auth-BFF.md](./Auth-BFF.md). El resumen que hay que tener en la cabeza:

1. `POST /api/auth/ids4` pide el token a IDS4 vía el gateway, lo guarda **en Redis** y devuelve al
   navegador una cookie `httpOnly` llamada `epico_session` que solo lleva un id opaco.
2. Toda llamada al gateway pasa por `/api/proxy/[...path]`, que lee la sesión de Redis e inyecta el
   `Authorization` del lado del servidor.
3. El cliente usa la instancia **`EPICO_API`** (`axios/axios_helper.ts`), con `baseURL` `/api/proxy`.
   Su interceptor de respuesta convierte los 204 en una respuesta estándar y, ante un **401**, cierra
   la sesión y redirige a Login.

Consecuencias prácticas: **si Redis no está disponible, el login y todas las llamadas fallan**; y
crear una instancia de axios nueva o llamar al gateway directo desde un componente rompe el modelo de
seguridad completo, no solo el estilo del código.

### 5.2 Estado global: dos árboles, cifrados y con caducidad

`features/common/application/redux/reducers.ts` define dos árboles persistidos:

- **`localState`** → `localStorage`: auth, sellers, configuration, menu, telemarketing.
- **`sessionState`** → `sessionStorage`: product, shipment, branches, customer, checkout, window,
  loyaltyPlan.

Los dos se cifran con `redux-persist-transform-encrypt` (clave `NEXT_PUBLIC_REDUX_STORAGE`) y
**caducan**: 8 horas en producción, 10 minutos en el resto (`persistedReducer.ts`). Si algo "se
pierde solo" tras una pausa larga, mira ahí antes de buscar un bug.

Para agregar estado global nuevo: crea el slice en `features/<feature>/application/redux/` y
regístralo en `reducers.ts` eligiendo árbol local o de sesión. En los componentes, siempre
`useAppDispatch` / `useAppSelector` de `features/common/application/redux/hooks.ts`.

### 5.3 PWA y trabajo sin conexión

`worker/index.ts` es el service worker. Desde Next 16 lo empaqueta `@serwist/turbopack` con esbuild
dentro de la ruta `app/serwist/[path]/route.ts` (estática: se genera en `next build`) y se sirve en
**`/serwist/sw.js`**, con `Service-Worker-Allowed: /` para poder controlar todo el origen. Lo registra
`SerwistProvider` en `app/layout.tsx`. Antes lo escribía `@serwist/next` en `public/sw.js`; los
teléfonos que tenían instalado ese `/sw.js` pasan al nuevo cuando la página registra
`/serwist/sw.js` con el mismo `scope` —el registro es por `scope`, no por URL—. Maneja precache,
background sync y push. La capa sin conexión usa IndexedDB vía JsStore: `worker/db.ts` crea las
bases `Epico` y `EpicoImages`, los esquemas están en `worker/schemas/` y el CRUD genérico en
`worker/dbEpico/crud/`.

Dos decisiones del fork que el original no tiene y que hay que conservar en cada sincronización:

- **`runtimeCaching` explícito, sin `defaultCache`**: el `defaultCache` de Serwist cachea `/api/**`
  con `NetworkFirst` y serviría precios o existencias viejos (y de otro usuario en un equipo
  compartido). Todo `/api/` va por `NetworkOnly`. Y el precache se filtra a manifest, favicon e
  iconos (6 de unas 285 entradas): el resto se cachea bajo demanda.
- **`cacheOnNavigation={false}` en el `SerwistProvider`**: con el valor por defecto (`true`) cada
  navegación le pide al worker "cachear" la URL, y como el worker no cachea documentos fuera de una
  navegación real, eso es una descarga completa de la página que se tira. `@serwist/next` lo traía
  apagado.

⚠️ **Si tocas `worker/`, el arreglo "no se ve" en el dispositivo hasta desregistrar el service worker
anterior**: el navegador conserva el que ya tenía instalado. Ha costado más de una sesión de
depuración de un bug que ya estaba arreglado. Hay un procedimiento de emergencia en
`worker/KILL-SWITCH.md`.

### 5.4 El buscador nuevo y el asistente

La búsqueda del catálogo dejó de ir a `productoservice` y va al microservicio **`IApymsa.Search`**
(`POST /api/v1/BusquedaProductos`). El mismo servicio tiene un modo `ia` que alimenta el chat del
asistente, **Ania**, montado solo en el layout del catálogo.

**Dos vías de transporte, conmutables por ambiente** (`NEXT_PUBLIC_BUSQUEDA_NUEVA_VIA`): `gateway`,
que pasa por el proxy de siempre, y `bff`, una ruta propia en `app/api/search/[...path]`. La ruta
propia existe porque **el gateway todavía no publica el endpoint**; exige sesión, no reenvía el
token y devuelve el sobre de la casa cuando falla. Hoy los cinco ambientes están en `bff`, y la vía
`gateway` **nunca se ha probado**.

Lo que cuesta tiempo si no se sabe:

- **Nunca devuelve 204.** «Sin resultados» es un éxito con `data.total === 0`. Y un `succeeded:false`
  puede llegar con **HTTP 200**, así que la condición de error es `huboError`, no el `statusCode`.
- **`consulta` debe medir de 3 a 300 caracteres**, o responde 400. Por eso la navegación por familia
  y la búsqueda solo por vehículo siguen yendo por el camino anterior (`canUseNewSearch`).
- **`total` y lo paginable no son lo mismo.** El motor materializa 100 resultados como mucho
  (`SEARCH_MAX_RESULTS`): puede decir `total: 4409` y servir cuatro páginas. El paginador se arma con
  `totalPaginas`, no con `total`.
- **La hidratación es obligatoria.** El DTO del buscador no trae `precioRevista`, existencias,
  `agotarExistencia`, `esNuevo`, `imagenMarca` ni `categoria`, y `useAddToPurchaseOrder` los
  necesita. Se hidrata contra `POST /api/v3/Clientes/Productos`, que **rechaza el lote entero si un
  solo producto está inactivo**: por eso `hydrateSearchProducts` aísla en trozos y marca
  `sinPrecio` en vez de inventar un importe.

**Las facetas, medido contra producción** (consulta «foco»), porque de esto depende el filtro rápido
y no está en ninguna documentación del servicio:

- Los conteos **no mienten**: la faceta dice `faro 1289` y filtrar por faro devuelve `total: 1289`.
- Filtrar **acota los menús de las otras dimensiones, no el de la propia**. Al filtrar por familia,
  familia conserva sus veinte valores con los mismos conteos y marca baja de 44 a 30 con los conteos
  ya cruzados (`qbh star` pasa de 621 a 93). Por eso las insignias de la dimensión que se acaba de
  tocar no se mueven, y el número que se pinta después de filtrar es el cruce real.
- **Hay que mandar todos los ids del valor.** Un valor de familia puede tener varios (`faro` son
  `[96, 1729]`): con los dos salen 1289, con `[96]` solo salen 1286. Por eso `IProductFilter` lleva
  `idsRelacionados` y la selección se resuelve **por valor y no por `ids[0]`**, cuyo orden el
  contrato no promete.

**La voz.** El dictado usa `webkitSpeechRecognition`, que manda el audio a Google, y por eso tiene
bandera propia. La síntesis usa `speechSynthesis` con las voces del dispositivo: se prefieren
**Dalia** (Edge) y **Sabina** (cualquier Windows), y en Android o iOS suena la que haya.

⚠️ **`speechSynthesis` no siempre es local.** `localService === false` significa voz **remota**, y la
puntuación de `pickVoice` las prefiere justamente porque suenan mejor: con Dalia o con las de Google,
el texto de la respuesta sale a servidores de terceros. Aquí llegó a estar escrito lo contrario.
Sintetizar en servidor —lo único que daría una sola voz para todos— se descartó por costo: unos
660 USD/mes con Amazon Polly a 400-600 usuarios, sin descuentos por volumen.

**El hilo no se rehidrata al cambiar de cliente, y por eso cada mensaje va sellado.** El catálogo sí
reacciona —`ProductCatalogue` lleva `selectedOrderSummary?.clienteId` en las dependencias de su
efecto y vuelve a buscar—, pero el hilo del asistente vive en `sessionStorage` y sobrevive al cambio:
una tarjeta de hace tres turnos seguía enseñando el precio, el precio tachado, la existencia y la «P»
del cliente con el que se buscó.

El dinero **no** se equivoca: `ProductCard` llama a `validateProductPrice` antes de agregar, que
vuelve a pedir el producto con el cliente activo, y es ese objeto fresco el que entra al pedido. Lo
que se equivocaba era **lo que el vendedor lee en voz alta**. El arreglo es de presentación:

- Cada mensaje con tarjetas guarda un `IContextoPrecios` —`clienteId`, `sucursalId` y el nombre del
  cliente congelado— con los valores **efectivamente enviados** a la hidratación, no releídos al
  despachar: entre la búsqueda y la respuesta pasan unos cinco segundos en los que el vendedor puede
  cambiar de caja, y un sello releído mentiría.
- `contextoPrecios.ts` decide qué avisar. Son **dos ejes**: el precio depende del cliente y la
  existencia de la sucursal, así que cambiar solo de sucursal dice «estas existencias son de otra
  sucursal; los precios sí son de este cliente».
- **`clienteId: 0` es un valor legítimo** —«se buscó sin pedido activo»—, nunca «no se sabe». Lo
  desconocido es la ausencia del sello: un hilo persistido antes de este cambio vuelve por
  `REHYDRATE` sin él y **no se marca**, porque no se puede afirmar de quién eran unos precios que
  nadie fechó.
- **Si la hidratación fracasó del todo, el mensaje no se sella.** `hydrateSearchProducts` devuelve
  entonces los productos crudos del índice con `failed: true` y todos marcados `sinPrecio`: el índice
  **no trae precio ni existencia** —`null` en 22 de 22 resultados medidos—, así que no hay precio de
  lista al que caer. Sellarlos haría que el hilo afirmara luego «estos precios son de X» sobre unas
  cifras que nunca fueron de X, que es justo la mentira que el sello existe para evitar.
- El aviso **no bloquea nada** y se funde dentro del Alert de «confirma la aplicación» que ya sale
  bajo toda respuesta con productos. Medido a 320×568: fundido son 111 px de los 387 px de hilo
  visible, y en dos cajas 125 px. La rejilla lleva además un `outline` porque de la tarjeta se ven
  198 px: al desplazarse hasta el precio, el aviso ya salió por arriba.

**El chat avisa cuando la hidratación falla**, como el catálogo: el mensaje lleva
`hidratacionFallida` y el motivo del gateway, y el aviso se funde en el mismo Alert. Hasta
`a460441e4` no lo hacía, y en producción se vio como tarjetas a «$0.00 · No disponible» sin ninguna
explicación. `hydrationWithoutPromotions` sigue sin aviso en el chat.

**El botón «ver en el catálogo» no puede mandar la frase del chat.** El agente entiende preguntas; el
catálogo busca literal. Medido contra producción: `modo: ia` con «qué tipo de cintas tienes» devuelve
**66**, y la misma frase en `modo: normal` devuelve **cero**, sin `terminoCorregido` al que caer de
vuelta. El servicio **no dice qué buscó**; lo único que lo delata son las facetas, donde la familia
principal era `cinta` —que en modo normal da los mismos 66.

Por eso `consultaCatalogo` **pregunta antes de prometer**: al cerrar el turno sondea la frase en
`modo: normal` y solo si no encuentra nada cae a la familia principal, así que una consulta que ya
funcionaba —«balatas chevy 2005»— no pierde precisión. El botón pinta el total **de la consulta a la
que lleva**, no el del chat, y si ninguna encuentra nada no se ofrece. La sonda es la misma barata del
rescate del dictado: sin agente, sin `sesionId` y sin hidratar.

⚠️ **El telón del panel no puede cerrar con un `onClick` a secas.** Se monta bajo el dedo durante el
`pointerup` que abre el chat, y el `click` que el navegador dispara después cae ya sobre él: el chat
se cerraba en el mismo gesto que lo abría, y solo se reabría según dónde estuviera el robot. Cierra
únicamente el gesto que **empezó** en el telón, comparando su propio `pointerdown`.

⚠️ **Todo camino que lleve una búsqueda a `/Catalogo` tiene que levantar `isSaveSearched` antes del
`push`.** `Catalogue` al montarse vuelve a familias y vacía `CadenaBusqueda`, salvo que encuentre esa
bandera; la búsqueda normal (`SearchFilterCatalog`) y el «regresar» del detalle la levantan, y el
«Ver los N resultados» del chat no lo hacía. No se notaba porque **el `push` no siempre remonta**:
el App Router usa la query dentro de la clave del segmento de página (`__PAGE__?{"cvid":"…"}`), y al
abrir una caja se entra a `/Catalogo?cvid=…`. Pasar de ahí a `/Catalogo` remonta; de `/Catalogo` a
`/Catalogo`, no. Resultado: fallaba el primer clic desde familias, funcionaba el segundo, funcionaba
si antes se había buscado a mano —esa búsqueda ya había dejado la URL sin query— y fallaba siempre
desde el detalle del producto.

**Las tarjetas del chat abren el detalle, y el panel se cierra.** `ProductCard` ya navegaba al
tocar la imagen o el código, pero el panel tiene velo en los dos tamaños y el detalle se abría detrás:
parecía que no hacía nada. La tarjeta avisa con `onOpenDetail` y el panel se cierra; la conversación
no se pierde, porque el layout del catálogo no se vuelve a montar al ir al detalle. Desde el detalle
de otro producto la URL es la misma y la página no se remonta: el detalle enseña el producto del chat
pero **no vuelve a pedirlo** con la lista de promociones. Es lo mismo que ya pasa con los carruseles
del propio detalle, que usan la misma tarjeta.

**La pestaña APLICACIONES ya no se fía de `tieneAplicaciones`.** El detalle hereda esa bandera de la
tarjeta de origen (`ProductDetailsView` la conserva a propósito, código del original), y la pestaña
solo preguntaba a `VehiculosCompatibles` si venía en verdadero. Con el buscador nuevo la bandera la
calculaba la hidratación con `??`, y un `false` de v3 anulaba los vehículos del índice: al entrar
desde el catálogo salía «sin información» en productos que sí tienen aplicaciones, y desde un
relacionado —que viene de endpoints v2— sí cargaban. Visto en producción el 8-oct-2026; **no se
midió qué devuelve v3**, así que el arreglo funciona con cualquier valor:

- La hidratación acepta un `true` de cualquiera de las dos fuentes (`=== true ||`): arregla también
  el botón de aplicaciones de la tarjeta en el catálogo y en el chat.
- La pestaña pregunta siempre, **al abrirse y una vez por producto** (`useProductApplications`, del
  fork), y decide por lo que responde el servicio. Cuesta menos que antes: sin abrir la pestaña no
  hay petición. Un 2xx o 4xx es respuesta; sin red o un 5xx es fallo y se reintenta al volver.
- El cambio en `ProductDetailsTabs.tsx` (compartido) son cuatro bloques. **Revisarlo en cada
  sincronización**: si el original vuelve a tocar la zona de aplicaciones, git puede fusionar sin
  conflicto algo que contradiga esto.

**Al llegar la respuesta, el hilo se queda en su principio, no en el final.** Bajaba al final con
todo, y con tarjetas debajo el texto de Ania quedaba por encima de la vista. Ahora baja al final solo
mientras el vendedor escribe y espera; la regla está en `destinoDelHilo` y se mide contra el
contenedor con `getBoundingClientRect`, no con `offsetTop`.

⚠️ **Defecto abierto del microservicio, no nuestro: el contexto de la conversación encoge los
resultados.** `cinta aislante` en `modo: ia` devuelve 6 productos en conversación nueva y **1** como
cuarto turno de un hilo; con uno, dos o tres turnos devuelve 6, y quitando cualquier turno del hilo
vuelve a 6, así que la variable es la profundidad. En otro hilo el `total` se quedó clavado en el
`tamanoPagina` pedido durante tres turnos. **No** es que deje de buscar: un cambio de tema vuelve a
consultar el índice bien. Reportado al equipo del buscador con la reproducción completa; mientras no
se arregle, el sondeo de `consultaCatalogo` es lo que le da al vendedor la salida a los resultados
que el agente dejó fuera.

---

## 6. La experiencia móvil

Esta es la razón de existir del fork, y la parte donde es más fácil hacer daño sin darse cuenta.

**La frontera es una sola**: `BreakpointEnum.mobileExperience = 900`, alineada con el breakpoint `md`
de MUI. Se consulta con `isMobileExperience` (`useWindowDimensions`, en
`features/common/infrastructure/hooks/getDimensions.ts`). Dos detalles del cálculo, ambos
deliberados:

- Considera **`screen.width` además de `innerWidth`**, porque `innerWidth` crece con el zoom de página
  y un teléfono con zoom caía en la experiencia de escritorio.
- `BreakpointEnum.mobile = 480` **no** es la frontera: significa "teléfono real" y la usan la cámara y
  el snackbar. No la cambies pensando que es lo mismo.

**El contrato de paridad fila/tarjeta.** Cuando una tarjeta necesita un dato que la tabla deriva —un
estatus que se calcula a partir de tres campos, un importe que depende del plan de lealtad—, la regla
es: **no lo recalcules**. Píntalo con `renderColumnValue` del `cardFieldResolver`, que aplica la misma
cascada del DataGrid, o pásalo desde `renderCard` con el helper `renderField`. Cada vez que se ha
duplicado una derivación, las dos copias se separaron en la siguiente sincronización y la tarjeta
acabó mostrando algo distinto que la tabla.

Las reglas de layout —los seis arquetipos de pantalla, los doce anti-patrones (once de desborde horizontal y uno de
escritorio),
los objetivos táctiles de 44px, el ancho de referencia de 320px— están en
**[Patrones-Movil.md](./Patrones-Movil.md)**, y hay que leerlas antes de tocar UI, no después de que
alguien mande una captura.

---

## 7. Las diez cosas que rompen esto

Ordenadas por cuánto han costado. Cada una ocurrió de verdad.

1. **Pushear al repositorio original.** `origin` es el proyecto del equipo. Se trae, no se manda.
   Verifica `git remote -v` antes de tu primer push.

2. **Adaptar quitando una acción, sin borrar código.** Pasó dos veces. `DataCard` descartaba las
   columnas sin `headerName` —que es justo como se declara una columna de control— y se perdieron
   botones en 17 pantallas; y `UserNavBar` se ocultó entero en móvil con un
   `{!isMobileExperience && ...}`, y con él seis acciones globales. Para auditarlo: cuenta
   `<Button`, `<IconButton`, `<Switch`, `<Checkbox` y `onClick=` por archivo antes y después, y revisa
   todo `display: { xs: 'none' }` y todo `!isMobileExperience &&`. **Si algo no cabe, se colapsa en un
   menú o en una hoja; no se elimina.**

3. **Alto o ancho fijo en un control cuya etiqueta puede envolver.** El defecto más repetido del
   proyecto: apareció seis veces en un solo día. El texto se pinta por fuera de la caja. Al tocar un
   control, deja `minHeight`/`minWidth` en vez de `height`/`width`, o hazlos responsivos
   (`{ xs: 'auto', md: '72px' }`).

4. **Romper la cadena de `minWidth: 0`.** En flexbox, un texto no se recorta con `text-overflow` si
   algún ancestro flexible no tiene `minWidth: 0`. Falta uno y la descripción de un producto empuja la
   tarjeta fuera de la pantalla. La cadena tiene que llegar completa desde el contenedor hasta el
   texto.

5. **Empates de especificidad con el `sx` de un componente MUI.** El `sx` de un componente genera una
   clase. Si el contenedor intenta domarlo con `'& > *'`, eso también es **una** clase: empatan y gana
   el hijo, que se inserta después. Con `'&& > *'` el contenedor duplica su clase y gana. Así se
   descubrió por qué un select con 200px fijos se pintaba encima del botón de al lado mientras su
   vecino sí se encogía —el del vecino llevaba el ancho en un `.MuiTextField-root` interno, donde el
   selector del contenedor ya sumaba dos clases—.

6. **Registros duplicados que `tsc` no ve.** Interceptores de axios, `addEventListener`, `useEffect`,
   suscripciones: todo lo que se registra por efecto tolera duplicados sin error de compilación. En
   una sincronización el interceptor de `EPICO_API` quedó registrado **dos veces** —movieron el bloque
   y git lo leyó como una adición— y el duplicado anulaba la protección contra el bucle de redirección
   a Login. Se detecta contando esas apariciones por archivo en las tres versiones: la nuestra, la
   suya y la fusionada.

7. **Un tooltip como única explicación.** En táctil no hay hover: el texto no se muestra nunca. Duele
   sobre todo cuando el tooltip explica por qué un control está deshabilitado. Ver la sección
   correspondiente en Patrones-Movil.

8. **`npm run test` no corre Jest.** Levanta el servidor de desarrollo con `.env.test`. Los tests se
   corren con **`npm run testJest`**.

9. **Verificar mal.** Dos formas, las dos vividas. Una: `npx tsc --noEmit | tail -10 && echo "OK"`
   **imprime OK aunque `tsc` falle**, porque el estado de una tubería es el del último comando y
   `tail` siempre tiene éxito; usa `npx tsc --noEmit; if [ $? -ne 0 ]; then ...`. Otra: correr la
   verificación y **después** seguir editando. **Jest no comprueba tipos**, así que un test recién
   escrito puede pasar en verde y romper `tsc` — pasó con un test cuyo objeto de prueba le faltaba un
   campo obligatorio de la interfaz, y el error viajó hasta un merge request. La puerta se cruza
   después del último cambio, no antes. **Y desde Next 16 es peor**: el `tsconfig.json` del original
   excluye `__tests__`, así que ese mismo test tampoco rompe `tsc`. Los tipos de un test solo los ve
   quien los revisa (o un tsconfig temporal que los incluya).

10. **Creer que `tsc` verde significa "no rompí nada".** No ve: layout (jsdom no calcula anchos),
    registros duplicados, paridad entre una fila y su tarjeta, ni una acción que dejó de renderizarse
    por una condición. Lo que sí sirve para cada caso está en la sección siguiente.

Y una advertencia que no es un error de código: **el monitoreo de usuario real se retiró**. Datadog
RUM se quitó por completo el 28-jul-2026 por decisión del negocio —componente, montaje, paquetes y la
variable en los cinco ambientes— y producción quedó sin reemplazo. Si un usuario reporta algo, no hay
telemetría que consultar.

---

## 8. Cómo trabajar aquí

### Comandos

```bash
npm run dev          # servidor de desarrollo con enviroments/.env.dev (también: test, stg, uat, prod)
npm run build:dev    # build por ambiente (build:test, build:stg, build:uat, build:prod)
npm run lint         # eslint . (ESLint 9, eslint.config.mjs)
npm run testJest     # Jest. NO uses `npm run test`
npx jest ruta/al/test.tsx     # un solo archivo
npx jest -t "nombre del test" # por nombre
```

Los ambientes se inyectan con `env-cmd` desde `enviroments/.env.*`. En producción los secretos se
cargan desde AWS Secrets Manager con `scripts/load-aws-secrets.js` (ver los Dockerfiles).

### La puerta de salida, antes de decir que terminaste

```bash
npx tsc --noEmit     # tiene que salir en 0 (no mira __tests__: ver la trampa 9)
npm run lint         # eslint . — no subir el conteo en los archivos que tocaste, ver abajo
npm run testJest     # todo verde
npm run build:dev    # compila (Turbopack)
```

⚠️ **`npm run lint` ya no es «limpio»: es «no peor que antes».** Hasta Next 15 el script era
`next lint`, que solo recorría `app/` —«lint limpio» significaba «limpio en `app/`»—. Desde Next 16
(nov-2026) es `eslint .` con `eslint.config.mjs` y recorre todo el repo, `features/` incluido, con
las reglas nuevas de `react-hooks` 7 (`set-state-in-effect`, `immutability`, `refs`…). Resultado
al 4-nov-2026: **1746 problemas en el fork y 1730 en el original**, acumulados de años. No se
corrigen de golpe ni bloquean nada. La regla es comparar los archivos que tocaste antes y después:

```bash
npx eslint ruta/del/archivo.tsx     # antes y después del cambio
```

`eslint.config.mjs` ignora `.claude/worktrees/**`: sin eso, el worktree viejo que vive dentro del
repo duplicaba 1626 avisos.


Y para lo que esos cuatro no ven:

- **Layout**: mide. La forma barata es una sonda que recorra el DOM comparando el borde derecho de
  cada elemento contra el ancho de la pantalla; hubo una en el repo (`MobileOverflowProbe`) y sigue en
  el historial de git. Lo definitivo es abrirlo en un teléfono.
- **Acciones perdidas**: el conteo de elementos interactivos por archivo, antes y después.
- **Paridad fila/tarjeta**: que cada columna esté cubierta por la tarjeta, la hoja o el encabezado.
- **Tratamiento móvil perdido en un merge**: cuenta los marcadores (`isMobileExperience`, `xs:`,
  `renderMobile`) por archivo antes y después, y **léelo por pareja de archivos**: si el componente
  baja y su archivo de estilos sube, el tratamiento se movió, no se perdió.

Los tests viven en `__tests__/` espejando la ruta del feature, y el alias `@/*` apunta a la raíz del
repo. Si tocas un componente que ya tiene test, córrelo y actualízalo cuando el cambio de
comportamiento sea intencional.

### Sincronizar con el proyecto original

```bash
git fetch origin main    # NO `git fetch origin` a secas: ver abajo
git merge origin/main
```

⚠️ **`git fetch origin` a secas ya no funciona en Windows** (comprobado el 8-sep-2026, sale con
código 1 sin traer nada). El original tiene dos ramas que solo se diferencian en mayúsculas
—`hotFix/ordenCompraHolder` y `hotfix/ordenCompraHolder`— y en un sistema de archivos que no
distingue mayúsculas git no puede guardar las dos referencias:

```
error: You're on a case-insensitive filesystem, and the remote you are
trying to fetch from has references that only differ in casing.
```

**Pedir la rama por su nombre** (`git fetch origin main`) esquiva el problema: git no intenta
almacenar todas las referencias remotas y actualiza `origin/main` igual. Es lo que hay que usar. La
alternativa que sugiere git —`git refs migrate --ref-format=reftable`— convierte el repositorio a un
formato que otras herramientas todavía no leen, y no hace falta para esto. Lo limpio sería que el
equipo del original borrara una de las dos ramas.

La mayoría de los archivos compartidos se fusionan solos; los conflictos reales han sido de dos a
seis. **El trabajo de verdad empieza después del merge**, y el primer paso es sacar la lista de lo que
tocaron ellos y también nosotros:

```bash
BASE=$(git merge-base HEAD origin/main)
comm -12 <(git diff --name-only $BASE...origin/main | sort) <(git diff --name-only $BASE...HEAD | sort)
```

Esa intersección es la lista de trabajo. Sobre ella, cinco preguntas:

1. **¿Ganaron algo en una pantalla que tiene rama móvil propia?** Entonces la rama móvil también tiene
   que ganarlo, o móvil pierde funcionalidad en silencio. Y al revés: lo que ellos comentan o quitan,
   hay que comentarlo o quitarlo en la copia móvil.
2. **¿Cambiaron una firma compartida?** `tsc` señalará *nuestros* archivos móviles. La tentación es
   hacerlos compilar; lo correcto es ver **cómo resolvieron ellos el mismo punto en la rama de
   escritorio** y copiar esa decisión.
3. **¿Extendieron una regla que nosotros habíamos extraído a una función?** El valor nuevo se suma
   dentro de la función extraída, no se parchea aparte.
4. **¿Reescribieron una pantalla que teníamos adaptada?** Se toma su versión como base y se
   reconstruye encima la disposición móvil. Reconciliar hunk por hunk no lleva a nada cuando el
   archivo se reescribió.
5. **¿Hay algo nuevo que se pinte en un componente compartido?** Mide cuánto ocupa en la tarjeta más
   angosta. Una insignia de 40px junto a dos precios desbordó la tarjeta de cuadrícula del catálogo,
   que en móvil no llega a 150px útiles.

Detalle extra: **`.env.uat` conflictúa casi siempre** por fin de línea (ellos usan CRLF); se toma su
contenido y se quitan las líneas de Datadog.

Lo que dejó la 8ª (28-sep-2026, 103 commits, traspasos en mini checkouts):

- **La cola de un elemento fuera del conflicto vuelve a traer su versión.** El conflicto cortó a mitad
  de la insignia «La mejor opción» y lo que seguía entró con su `minWidth 190px` y `width 190px` fijos.
  Se compara el elemento entero contra la versión previa al merge, no solo el bloque marcado.
- **Borraron un estilo que la rama móvil usaba** (`sxCounterNoStock`). `tsc` lo ve; lo que no ve es
  que la tarjeta móvil replica **reglas** de la columna, y esas también cambiaron (existencia y tope
  por SKU sumando filas, tope ampliado en la opción de traspasos, una columna nueva). Hoy esa
  derivación vive en `mobileMiniCheckoutArticle.ts`, fijada por `miniCheckoutArticleParity.test.tsx`.
- **Escritorio idéntico se consigue con el valor de fábrica en `md`**, no quitando la clave:
  `{ xs: 0, md: 'auto' }`, `{ xs: 'wrap', md: 'nowrap' }` e `inherit` para lo que se hereda
  (`white-space`, `word-break`). Un `xs` solo se emite como `@media (min-width:0px)` y llega a
  escritorio. Así se corrigieron estilos de adaptaciones anteriores que se aplicaban a todo ancho.

La 9ª (4-oct-2026, release 3.39.0, 8 commits, 2 conflictos) rehízo **la tira de indicadores del
monitoreo**, que teníamos rediseñada: de 4 a 7 tarjetas, cada una con su explicación en un Tooltip.
Se tomó su versión como base y el tratamiento móvil se metió **dentro de su archivo de estilos**
(`MetricsAndInidicatorsCards.ts`), con su valor exacto en `md` y un test que lo fija. Un revisor midió
el estilo calculado de las 7 tarjetas en 12 combinaciones de ancho y menú: 0 diferencias con el
original. Ojo con los tests de 5 s: con otro proceso pesado en paralelo, dos suites fallaron por
timeout y pasaron solas.

La 10ª (16-oct-2026, release 3.40.0, 9 commits, 1 conflicto) dejó una variante nueva de la trampa de
siempre: **un cambio suyo de lógica convirtió en escritorio una adaptación nuestra que antes solo se
veía en móvil**. La cámara pasó a abrir en modo nativo en cualquier ancho, y el botón «Usar la cámara
de la app con guía» —subido a 44px sin breakpoint porque ese panel solo existía en móvil— empezó a
cambiar escritorio. Ninguna línea nuestra conflictuó. Lección: un ajuste móvil sin `xs/md` es una
apuesta sobre dónde se pinta el componente, y el original puede cambiarla.

La 11ª (4-nov-2026, release 4.0.1, 26 commits, 18 conflictos, todos de infraestructura) fue la
**subida a Next 16**: React 19.3, Turbopack, `@serwist/next` → `@serwist/turbopack`, ESLint 9 y
Node 22. La UI casi no cambió (dos selects en el alta de cliente), pero dejó cuatro trampas nuevas:

- **El `package-lock.json` no se resuelve tomando el suyo.** Hacerlo bajó 177 paquetes, entre ellos
  `axios` y el SDK de AWS a un rango vulnerable, y `npm install` no lo corrige porque esas versiones
  cumplen los rangos. Se parte del lock nuestro y se le aplica el `package.json` fusionado con
  `npm install --package-lock-only`; detalle en `docs/Seguridad-CVEs.md`.
- **Cambiar de librería cambia valores por defecto que nadie escribió.** `SerwistProvider` trae
  `cacheOnNavigation: true` y `@serwist/next` lo traía en `false`: con nuestro worker, cada
  navegación habría descargado la página completa otra vez. No da error ni se ve; hay que comparar
  las opciones por defecto de la librería que sale con la que entra.
- **Nuestros parches pueden depender del empaquetador.** `ChunkErrorReloader` reconocía los mensajes
  de webpack; Turbopack dice «Failed to load chunk». Buscar en el código propio lo que asume
  webpack (mensajes, `require.context`, `webpackChunkName`) en cada cambio de empaquetador.
- **Un catálogo nuevo puede exponer un defecto viejo de un componente compartido.** `SelectGeneric`
  siempre recortó las opciones a una línea con el texto completo en un Tooltip; con las descripciones
  del SAT eso dejó de ser cosmético. Se resolvió en el feature (`MenuProps` con `md` de fábrica), no
  en el átomo.

Y una operativa: durante el merge **otra sesión de Claude editaba ~30 archivos en el mismo árbol**.
Nada se perdió porque cada commit llevó solo los archivos propios (`git add <rutas>`, nunca
`git add -A`) y antes de cada uno se revisó `git status`.

### Publicar

Los merge requests se crean **desde el propio push** (no hay `glab` ni token en el entorno):

```bash
git push -o merge_request.create -o merge_request.title="..." -o merge_request.description="..." movil <rama>
```

Las opciones solo se aplican si el push mueve la rama: con un MR ya abierto, `create` no hace nada. Y
la descripción no admite saltos de línea — usa `<br>` y `<ul>`, que GitLab renderiza.

---

## 9. Lo que no está verificado

Dos cosas que conviene saber de entrada, porque cambian cómo hay que probar:

- **Toda la adaptación móvil es layout e integración**, y no hay test automático que lo cubra: jsdom
  no mide anchos. Un cambio de UI puede pasar los cuatro comandos de la puerta de salida y verse mal
  en un teléfono. La única verificación que cuenta es abrirlo en uno.
- **La aplicación corre con usuarios reales.** Un defecto visual que se cuela llega a gente que está
  trabajando, no a un ambiente de pruebas.

Y lo que quedó sin comprobar del buscador nuevo y del asistente (ver 5.4). Desde el 28-ago-2026
**esto ya no es un piloto a puerta cerrada**: las banderas están encendidas en `prod`, y como son por
ambiente y no por usuario, cualquiera que abra el catálogo en producción tiene el asistente. Lo que
siga en esta lista se está comprobando en la calle.

Del chat escribiendo sí hay recorrido real, y salieron dos defectos que ya están arreglados —el telón
que impedía reabrirlo y el botón al catálogo que llevaba a una pantalla vacía—. Lo que sigue sin
tocarse es esto:

- **La vía `gateway` nunca se ha ejercitado.** Los cinco ambientes van por la ruta propia porque el
  gateway no publica el endpoint. El día que lo publique, conmutar la bandera es la primera prueba.
- **El dictado y la voz no están probados de punta a punta**, porque exigen micrófono y sesión: que
  el micrófono se cierre al cerrar el chat, que el asistente no hable con el chat ya cerrado, y que
  dictar encima de texto escrito concatene en vez de borrar.
- **Subir `maxAlternatives` de 1 a 5 puede cambiar la hipótesis principal, y no está medido.** El
  valor viaja al servicio de reconocimiento y es él quien decide qué devuelve. Por eso solo se piden
  cinco cuando la bandera del rescate está encendida: con ella apagada, el dictado se comporta
  exactamente igual que antes.
- **Las insignias de filtro rápido se midieron en una réplica**, a 320 px y a 900, no en la
  aplicación con sesión y datos reales.
- **El aviso de contexto también se midió en una réplica**, no con datos reales. Falta comprobar tres
  cosas en el dispositivo: que cambiar de caja repinte el panel en el acto (por código lo hace, el
  aviso se calcula en render y no dentro de un efecto); si `selectedOrderSummary.cliente` viene
  poblado en la práctica —de eso depende si se ve el texto que nombra al cliente o el de reserva—; y
  cómo queda un hilo largo con tres o cuatro mensajes marcados a la vez, que nadie ha visto todavía.
- **El caso de la sucursal no se sabe si ocurre en el trabajo diario.** Exige ir al Checkout, cambiar
  la sucursal de destino y volver al catálogo con el hilo abierto. El sello la guarda igual; si
  resulta que nadie hace eso, sobra la rama `OtraSucursal` y su texto.
- **La existencia se pide con `SucursalId` dentro de una llamada que ya lleva `clienteId`**, así que
  no está probado que dependa *solo* de la sucursal. Si dependiera también del cliente, el texto de
  `OtraSucursal` se queda corto.

Pendiente de confirmar en un teléfono (al 5-nov-2026 todo esto está en `main` y con tag, pero solo
verificado con tests y medición en réplica):

- **El paso de la PWA instalada al service worker nuevo** (tag 1.0.79, Next 16): abrir la app en un
  teléfono que ya la tenía y confirmar que el script activo es `/serwist/sw.js`, que las
  notificaciones siguen llegando y que nada se queda cargando. El navegador integrado de Claude no
  registra service workers: no se pudo probar en local.
- **La app en `epico.apymsa.com.mx`** (tag 1.0.78-1.0.79): que el mismo contenedor responda por las
  dos URLs y que la sesión de cada una sea independiente (las cookies no fijan dominio).
- **Alta de cliente con Régimen fiscal y Uso de CFDI** (tag 1.0.79): a 320px, que el menú del SAT
  muestre las descripciones completas; entre 600 y 899px, persona moral sin huecos.
- **La cámara de digitalización con Turbopack**: los WASM (`mozjpeg`, `scanic`, `tesseract`) y los
  `import()` diferidos cambiaron de empaquetador. Que se pida `/wasm/mozjpeg_enc.wasm` y que el OCR
  funcione.
- **El sumario del pedido al recargar directo** (tag 1.0.80): ahora elige rama con
  `isMobileExperience`, y el primer render del servidor es el de escritorio. Ver si salta de dos
  columnas a una.

- **Pestaña APLICACIONES** del detalle al entrar desde una búsqueda por texto (MR !82): que cargue, que
  el botón de aplicaciones de la tarjeta ya no salga gris, y el indicador mientras llega la respuesta.
- **Chat sin caja activa** entrando desde el menú (MR !85): que los precios lleguen con el cliente
  mostrador en vez de «Entidad ClienteId (0) no encontrada».
- **Indicadores del monitoreo** (9ª sincronización): dos por renglón, la séptima a lo ancho y la
  leyenda «¿Qué mide cada indicador?».
- **Botón «Procesar con SMC 3»** y su modal a pantalla completa, en el paso de opciones de envío.
- **Hoja del monitoreo con un pedido repartido en varias sucursales** (id compuesto, 10ª sincronización)
  y la **cabecera de beneficios** del plan de lealtad con su botón de refrescar.

Lo que no se puede medir sin sesión y está en manos del servicio:

- **Qué devuelve `POST /api/v3/Clientes/Productos` en `tieneAplicaciones`.** Nunca se midió; el arreglo
  de !82 funciona con cualquier valor. La sonda: en Network, la respuesta de ese POST para un producto
  con aplicaciones conocidas.
- **Los mensajes de error de `productoservice` llegan con la codificación rota** («ocurri� un error
  con la conexi�n»). Es del servicio, no de la app.
- **Cuando Componentes, Similares o Sustitutos responden 500**, el carrusel dice «Información no
  disponible», igual que un producto sin datos. Pasó el 16-oct-2026 y era del servicio. Se le propuso a
  Jorge distinguir el error («No se pudo cargar», como en APLICACIONES); quedó en pausa por decisión
  suya.
