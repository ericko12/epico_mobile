# Auth BFF and API Proxy

## Goal
Provide an authentication layer that keeps access tokens out of the browser and routes all gateway calls through a backend proxy. The browser stores only an opaque session id. The real token lives in Redis.

## Components
- Frontend (Next.js client)
- Auth API route: /api/auth/ids4
- Session store (Redis): app/api/auth/sessionStore.ts
- Session check: /api/auth/session
- Logout: /api/auth/logout
- Gateway proxy: /api/proxy/**
- API gateway (external)

## Environment
- BASE_APIGATEWAY
- IDS4_CLIENT_ID
- IDS4_CLIENT_SECRET
- IDS4_GRANT_TYPE
- HOST_DISTRIBUTED_CACHE

## Sequence - Login
```mermaid
sequenceDiagram
    participant UI as Browser UI
    participant BFF as /api/auth/ids4
    participant GW as API Gateway
    participant IDS4 as IDS4 Token
    participant Redis as Redis

    UI->>BFF: POST /api/auth/ids4 (user, password)
    BFF->>GW: POST /api/v1/connect/token
    GW->>IDS4: Validate credentials
    IDS4-->>GW: access_token
    GW-->>BFF: access_token
    BFF->>Redis: store session {token, userId, expiresAt}
    BFF-->>UI: set cookie epico_session (httpOnly)
```

## Sequence - API Call
```mermaid
sequenceDiagram
    participant UI as Browser UI
    participant Proxy as /api/proxy/*
    participant Redis as Redis
    participant GW as API Gateway

    UI->>Proxy: Request /api/proxy/...
    Proxy->>Redis: get session by epico_session
    Redis-->>Proxy: token
    Proxy->>GW: Forward request with Authorization
    GW-->>Proxy: Response
    Proxy-->>UI: Response
```

## Sequence - Session Check
```mermaid
sequenceDiagram
    participant UI as Browser UI
    participant Session as /api/auth/session
    participant Redis as Redis

    UI->>Session: GET /api/auth/session
    Session->>Redis: get session by epico_session
    Redis-->>Session: session exists?
    Session-->>UI: { valid: true|false }
```

## Responsibilities
- /api/auth/ids4
  - Calls IDS4 through the gateway.
  - Creates an opaque session in Redis.
  - Returns userId and expires_in (no token).

- /api/proxy/*
  - Reads the session from Redis.
  - Injects Authorization header.
  - Proxies requests to the gateway.

- /api/auth/session
  - Validates if the session id still exists.

- /api/auth/logout
  - Deletes the session in Redis.
  - Clears epico_session cookie.

## Notes
- Sessions are stored in Redis DB 1 using HOST_DISTRIBUTED_CACHE.
- Tokens never reach browser JS; only opaque session id is stored in cookies.
- If Redis is unavailable, auth and proxy will fail.
