# Patrones de la experiencia móvil

Reglas de diseño y de layout para pantallas de EPICO por debajo de 900px. Salieron de una ronda
larga de QA en dispositivo real: cada regla existe porque un defecto concreto la hizo falta, y la
mayoría se repite en varias pantallas.

**Aplicar esto sin esperar a que alguien reporte la pantalla.** Si una pantalla encaja en uno de los
arquetipos de abajo, se adapta con el patrón correspondiente aunque nadie haya mandado una captura.

## Regla base

La experiencia móvil es **<900px** (`md` de MUI). Se detecta con `isMobileExperience` de
`features/common/infrastructure/hooks/getDimensions`, alineado con `BreakpointEnum.mobileExperience`
y con los breakpoints de `config/theme/muiTheme.ts`. **Escritorio (≥900px) no se toca**: todo cambio
va condicionado por breakpoint o por ese flag.

Nunca inventar un breakpoint nuevo. Un `@media (max-width:860px)` suelto es un error — ya causó que
el pie de la cotización se encimara.

### Escritorio idéntico: cómo se rompe sin que nadie lo note

En nov-2026 una auditoría de los 251 archivos que la adaptación tocó encontró **70 lugares donde
escritorio ya no era el original**, 15 de ellos visibles a simple vista (el formulario de método de
envío había quedado en una columna de 452px que "parecía de móvil"). Ninguno rompía `tsc`, lint ni
pruebas. Los mecanismos, por frecuencia:

- **Un `xs` o `sm` sin `md`.** `{ xs: 'column', sm: 'row' }` llega a escritorio con `row`; si el
  original era otra cosa, escritorio cambió. Un `xs` solo se emite como `@media (min-width:0px)`.
- **Una propiedad nueva sin breakpoint** (`flexWrap: 'wrap'`, `width: '100%'`, `gap`, `minWidth: 0`,
  `alignItems`, `borderRadius`). En `md` va el valor de fábrica: `{ xs: 'wrap', md: 'nowrap' }`.
- **Un shorthand que revive un system prop muerto** (anti-patrón 12, abajo).
- **Un envoltorio nuevo** (`<div>` → `<Stack spacing>`) o una rama JSX reescrita para las dos
  experiencias: cambia márgenes, alineación y el reparto del espacio también en escritorio.
- **Un componente compartido** (`SummaryGeneric`, `ModalGeneric`, `SnackBarContext`): un cambio sin
  breakpoint llega a decenas de pantallas de escritorio a la vez.

**Antes de dar por bueno un cambio de estilo**, comparar el `sx` del original con el nuevo:

```bash
node scripts/sx-escritorio.cjs '<sysOriginal>' '<sxOriginal>' '<sysNuevo>' '<sxNuevo>'
```

Resuelve los dos con la función real de MUI de 900 a 1920px (escritorio: tiene que salir
`"escritorio_identico": true`, código 0) y de 320 a 899px (muestra qué cambió en móvil, incluido el
rango `sm` de 600 a 899, donde un `{ xs, sm }` sin `md` ya se comporta como escritorio), más cada
umbral que aparezca en los dos `sx`. Respeta el orden en que emotion emite el CSS (también entre una
`@media` y un selector anidado), `!important`, el orden entre un shorthand y su longhand
(`padding` contra `paddingLeft`), aplana los selectores anidados (`&:hover`, `&.Mui-disabled`,
`& .MuiX`) y normaliza los números a px. Límites: solo JSON (sin funciones de tema) y el tema por
defecto de MUI, que hoy coincide con `config/theme/muiTheme.ts`. Una declaración explícita con el
valor inicial de CSS (`minWidth: 'auto'`) sale distinta de "no declarada": se revisa a mano.

Y no todo es `sx`: **un envoltorio nuevo cambia el reparto del espacio** aunque cada `sx` resuelva
igual. Cuando una fila del original tenía los controles como hijos directos y la adaptación los
agrupó (pie del sumario, código de producto), en `md` el grupo lleva `display: 'contents'` para que
no genere caja y la fila encoja igual que allá.

> Nov-2026: la primera versión del script solo medía 360 y 1280px, ignoraba las `max-width` y no
> aplanaba lo anidado. Con ella se dio por idéntico un escritorio que no lo era en cuatro lugares
> (pie del sumario, encabezado de envío, código de producto y el APLICAR del buscador).

**No solo el estilo: también el comportamiento.** Un arreglo de captura hecho para el teléfono
(filtrar dígitos, dejar el campo vacío mientras se escribe, `maxLength`) cambia escritorio igual si
no pregunta por `isMobileExperience`. `Counter`, `CatalogueCounter` y el campo de código de
`ProductCode` lo aplican solo en móvil; escritorio conserva el manejo del original, y los tests de
los dos contadores prueban las dos experiencias (incluido cambiar de una a otra a media edición).

Diferencias de escritorio que se conservan a propósito (decididas, no olvidadas):

- **Botonera del resumen de cotización** (`QuotationSummary`): un `Stack` en fila en lugar del
  `Grid2` con márgenes en línea del original. A anchos normales es idéntica; con razón social larga
  el original encimaba el tercer botón.
- **`inputMode="numeric"`** en los contadores y en el código de producto, también en escritorio: no
  cambia nada a la vista y en una laptop táctil abre el teclado que corresponde (regla de arriba:
  `inputMode` en todo campo que filtra caracteres).
- **Etiqueta del buscador de Pedidos Externos**: «Buscar por ID de cliente» solo en móvil (el campo
  solo acepta dígitos); escritorio dice «Buscar por cliente», como el original.
- **Pendiente de decisión con Jorge**: el aviso global (`SnackBarContext`) muestra la X de cerrar y
  deja 8 s los mensajes largos también en escritorio, junto con la banda de color y el texto sin
  mayúsculas forzadas. Vienen del rediseño del aviso de error y el arreglo de ESC-61 cuenta con la X.

## Arquetipos de pantalla

### 1. Listado con DataGrid

Usar `AdaptiveDataGrid` (`features/common/infrastructure/ui/tables/adaptiveDataGrid/`): en escritorio
delega en `DataGridServerPagination`, en móvil pinta `DataCardList`. No escribir la rama móvil a mano.

Dos cosas que hay que revisar en la card resultante, porque no siempre sale bien sola:

- **El título sale de la primera columna con `headerName`.** Si esa columna es "Imagen", la foto queda
  sola arriba y lo que de verdad identifica la fila baja a ser un renglón más de etiqueta/valor. Se
  arregla con `cardOptions.titleField`, o componiendo con `cardOptions.renderCard` cuando conviene
  juntar imagen y descripción (ejemplo: `AccordionOrderDetail`).
- **Cada `renderCell` trae su propio `textAlign`** pensado para la celda del grid —centrado, o a la
  derecha en los importes—, y en la card eso deja los valores a sangrías distintas. Alinearlos desde
  el contenedor: `sx={{ '& .MuiTypography-root': { textAlign: 'left' } }}`.

Al componer con `renderCard`, derivar las filas de las **columnas ya filtradas** que recibe el grid,
no de una lista fija: así siguen respetando los filtros condicionales de la pantalla.

### 2. Tabla dentro de un modal o tabla nativa `<Table>`

Pasa a tarjetas por debajo de 900px. Referencias ya hechas:
`PromotionModalProductCard`, `QuotationSummaryProductCard`, `ArticleCard`
(`features/common/infrastructure/ui/cards/ArticleCard.tsx`).

La tarjeta muestra **los mismos datos que la tabla**, no un subconjunto. Composición típica: imagen +
código + descripción arriba; los campos numéricos en una rejilla
`gridTemplateColumns: 'repeat(3, minmax(0, 1fr))'`; el importe separado por un `Divider` al pie.

`minmax(0, 1fr)` es obligatorio: con `1fr` a secas las columnas toman el min-content y la rejilla
desborda la tarjeta.

### 3. Modal de captura

`ModalGeneric` con `maxWidth` md/lg/xl entra solo a pantalla completa en móvil. Los botones van en
**una fila, cancelar a la izquierda y continuar a la derecha** — el orden lo da el DOM. No usar
`flexDirection: 'column-reverse'`: apila y sube el botón principal, al revés que el resto de la app.

Para modales que no usan `ModalGeneric` está `ModalWithoutButtons` con la prop `mobileFullScreen`.

**Un modal con ancho fijo no aparece en `scrollWidth`.** Los que se arman a mano —`Modal` de MUI con
un `Box` `position: absolute` centrado con `translate(-50%, -50%)`— se recortan por **los dos lados**
cuando su ancho fijo pasa del de la pantalla, y como el contenedor está posicionado no generan
desplazamiento horizontal: la sonda de desborde no los ve y la pantalla parece sana. Pasó con
`ModalMassiveUpload` (600px fijos en un teléfono de 368). Van a `width: { xs: '100%', md: N }` con
`overflowY: 'auto'`, porque el teclado encoge el viewport y deja fuera de alcance los últimos campos.

### 4. Pantalla de paso de flujo (cabecera + formulario + sumario + pie)

Es el arquetipo de Método de pago, Método de envío y Revisión del pedido, y lo comparten
`ShipmentMethods`, `ShipmentMethodsSMC4` y el detalle de pedidos. En escritorio el sumario es barra
lateral (`md: 3`); en móvil cae debajo de todo el contenido.

- **Cabecera** (`ShipmentHead`): los datos de contexto se apilan dentro de una tarjeta con borde. En
  fila son cuatro renglones de texto plano que se comen un tercio de la pantalla y no se distinguen
  del contenido de abajo.
- **El nombre del cliente no se trunca.** `TextLabel` recorta con puntos suspensivos por defecto para
  proteger el layout; en las cabeceras se pasa `wrapOnMobile` para que se parta en varias líneas.
- **Sumario** (`SumSummary`): tarjeta con borde, desglose **abierto** y el TOTAL separado por una
  línea, para que no se lea como un renglón más.
- **Títulos de sección** en móvil van como etiqueta chica en gris (`FontSizesEnum.Delta`, gris,
  `letterSpacing`), no como encabezado grande.

### 5. Listado largo dentro de una pantalla de captura

El detalle de la caja del checkout es el caso: cada artículo tenía su tarjeta con todo desplegado
—cantidad, existencias, precio final con desglose, promoción, precio especial, pago con Kms y
acciones— y **hay usuarios que meten 25 productos**. A 470px por tarjeta, la pantalla medía doce
metros y llegar al último artículo era un viaje.

El patrón es **fila compacta + hoja de edición**:

- **La fila** (≈56px) lleva número, imagen, código, distintivos, descripción recortada con puntos
  suspensivos, importe y cantidad. Nada más.
- **Al tocarla sube un `Drawer anchor="bottom"`** con el detalle completo — literalmente el cuerpo de
  la tarjeta anterior, sin mover un control. La lista no cambia de alto, así que no salta al abrir y
  cerrar, y los controles quedan al alcance del pulgar.
- **Buscador dentro de la lista** a partir de 8 elementos: con la lista llena, encontrar es el
  problema real, no editar. El número de renglón sigue siendo el de la lista completa aunque haya
  filtro.

Dos cosas que se aprendieron al aplicarlo y que valen para cualquier lista que se compacte:

- **Lo que cambia el importe tiene que verse en la fila.** Un artículo que se paga con Kms se veía
  idéntico a uno cobrado en dinero: hay que subir a la fila el distintivo, el importe tachado y los
  Kms. Lo mismo con la existencia insuficiente, que en escritorio pinta la fila de rojo. Al
  compactar, la pregunta no es "qué cabe" sino **"qué se necesita para no tener que abrir"**.
- ⚠️ **Los componentes que solo existen por su efecto se montan fuera de la hoja.** En esta pantalla,
  `ProductKmsEffect` es un componente que no pinta nada: llama a `useProductKms` para calcular los
  Kms de un producto. Si se hubiera quedado dentro del detalle, solo se montaría el del artículo
  abierto y todas las filas mostrarían cero Kms. Va uno por artículo, al nivel de la lista y **sobre
  la lista sin filtrar**, para que buscar no los desmonte.

Y el encabezado de la pantalla cuenta igual que la lista: los cinco controles apilados de "Opciones
del pedido" se pliegan tras un botón —con breakpoint de CSS, no con el flag de móvil, y solo
ocultando, para que el subárbol se siga montando y sus peticiones no cambien—; lo que se usa en cada
visita (agregar por código) se queda a la vista.

### 6. El aviso de error también es una pantalla

El snackbar (`context/snackBar/SnackBarContext.tsx`) es el único canal de errores de la aplicación y
recibe **el mensaje del gateway tal cual** (`handleRequestDto` y `handleRequestStockDto` pasan
`response.message`). Eso significa cadenas de 200 caracteres con tokens sin espacios
—`GetDetalleProductoPorClienteQueryHandler`— que no se pueden partir por donde uno quisiera.

- **Atarlo al viewport**: `width: { xs: 'calc(100vw - 24px)', md: 400 }`. Sin ancho, el `Alert` crece
  con su min-content y, al estar centrado con `translateX(-50%)`, se recorta por **los dos** lados:
  el icono de severidad queda fuera de la pantalla y el texto llega pegado a los bordes, sin tarjeta
  ni color. Se lee como un bloque de texto suelto, no como un error. Y al ser un elemento
  posicionado, tampoco genera desplazamiento horizontal que lo delate.
- **`overflowWrap: 'anywhere'` en el mensaje**, más `minWidth: 0`: es lo único que parte un token
  larguísimo en vez de dejar que empuje.
- **Un fondo fijo anula la severidad.** `background: 'white'` sobre el `Alert` borra el tinte que MUI
  pone por `severity`, así que un error se ve igual que un aviso. Si se quiere conservar la tarjeta
  blanca, la señal de color tiene que volver por otro lado (banda de 6px a la izquierda con
  `theme.palette[severity].main`).
- **Cerrable y con tiempo de lectura**: `onClose` en el `Alert` (MUI pone la ✕) y un autohide más
  largo para los mensajes largos. Un error de 200 caracteres no se lee en 5 segundos.
- **Sin mayúsculas forzadas**: `toUpperCase()` sobre un mensaje largo dificulta la lectura y no
  aporta jerarquía.

## El ancho de referencia es 320px, no 360px

360px es el teléfono típico, no el más angosto. La **pantalla externa del Galaxy Z Fold 6** es más
estrecha que eso (la del Fold 7 mide justo 360, y por eso ahí todo se veía bien), y el zoom de página
de Chrome —que Android recuerda por sitio— reduce el viewport todavía más. Diseñar contra 360 deja
sin margen: cualquier pantalla por debajo rompe.

**Nada en la experiencia móvil puede exigir más de 320px.** Antes de dar por buena una pantalla,
revisarla a 320px, no a 360.

Cuando el ancho real baja del piso que exige la página, el síntoma **no** es un elemento que se sale:
es la app entera maquetada más ancha que la pantalla, con todo recortado a la derecha —se lee como si
el navegador tuviera zoom—. Eso pasa porque `#main-content-container` (`app/(epico)/layout.tsx`) es
hijo de un contenedor flex, y un flex item sin `minWidth: 0` **no encoge por debajo del min-content de
su contenido**: un solo elemento que pida 350px estira toda la aplicación a 350px. Ya lleva
`minWidth: 0`, pero el patrón se repite en cualquier fila flex que se escriba.

### Sumar los pisos, no mirarlos de uno en uno

Un desborde así casi nunca sale de un valor grande: sale de sumar varios chicos que no encogen.
Padding lateral del contenedor + padding horizontal de cada botón + el `gap` + el `min-width` que
trae el componente de MUI. Ejemplos reales:

- `BottomNavigationAction` trae `min-width: 80px` de MUI. Con cuatro acciones son 320px **antes** del
  padding del `BottomNavigation`; con los 15px por lado que tenía, 350px. Se recortaba "Digitalizar".
- Dos botones con `px: 3.5` (28px por lado) en una fila `flexWrap: nowrap` son 112px que no encogen
  aunque los hijos tengan `flex: 1 1 0` y `minWidth: 0`.

Los `min-width` que MUI trae de fábrica (`Button` 64px, `BottomNavigationAction` 80px,
`Tab` 90px) son parte de la cuenta.

## Anti-patrones — buscarlos antes de editar

Estos doce explican casi todos los defectos encontrados: del 1 al 11, desbordes horizontales en
móvil; el 12, escritorio que cambia sin que nada lo detecte:

1. **`Grid2 size={{ md: N }}` sin `xs`** — el ítem queda en `width: auto` y crece hasta su
   max-content. Siempre `{ xs: 12, md: N }`. Igual con `size={N}` numérico, que aplica a todos los
   breakpoints.
2. **Anchos fijos en px/rem** (`width: '190px'`, `13rem`) — usar `{ xs: '100%', md: '190px' }`.
   **Ojo al cambiar un px fijo por `100%` dentro de una fila flex**: si el componente envuelve su
   control (`AutocompleteLabel` lo mete en un `Stack`, `BadgeGeneric` en un contenedor), el flex item
   es el envoltorio y no el control. El `100%` se mide contra un envoltorio sin ancho propio, que se
   encoge a su min-content, y el campo queda de 40px con el desplegable a una letra por renglón —el
   px fijo al menos le daba tamaño—. El ancho va en el envoltorio: `width: { xs: '100%', md: 'auto' }`
   en una caja alrededor, o la prop de contenedor si el componente la expone (`sxContainerParam`).
3. **Contenedores `display: grid` con `1fr`** — toman el min-content del hijo. Usar `minmax(0, 1fr)`.
4. **`Stack direction="row"` sin envolver** — su min-content ensancha **al padre**, así que el
   síntoma aparece en un título vecino cortado, no en el Stack. Añadir `useFlexGap` + `flexWrap`, o
   `direction={{ xs: 'column', md: 'row' }}`.
5. **Alturas en porcentaje dentro de contenedores de altura automática.**
6. **`position: fixed` con `bottom: 0`** — queda detrás de la barra inferior de 70px. Usar `sticky`
   dentro del contenedor y sumar `env(safe-area-inset-bottom)`.
7. **`style=` en vez de `sx=`** — `style` **ignora los breakpoints de MUI**. Encontrado tres veces
   (`CustomModal`, `HeaderPrioritySMC`, `StepperPromotionProduct`).
   Y la mitad que muerde al reutilizar un estilo de escritorio: **`style` gana sobre `sx`**, porque
   es un atributo en línea. Al escribir una rama móvil, **no heredar el `style=` de la vista de
   escritorio**: si ese objeto trae `display: flex`, los bloques que uno apila salen en una fila y
   el `display: block` del `sx` no se aplica nunca. Pasó en `VerticalProductCardPurchaseHistory` al
   reusar `cardPorduct`.
8. **`spacing` de MUI con un hijo `width: 100%`** — `spacing` aplica `margin-left`, no `gap`, así que
   el hijo desborda exactamente esa cantidad. Solución: `useFlexGap` (que sí usa `gap`).
9. **Columna flex que envuelve** (`Grid2 container direction="column"`, `Stack` con `flexWrap`) — en
   un contenedor en columna que envuelve, **el ancho de la línea lo fija el hijo que más pide**, y
   `align-items: stretch` estira a todos los demás a esa medida. Un solo bloque con un min-content de
   425px deja la pantalla entera maquetada a 425 en un teléfono de 368: el síntoma no es un elemento
   que se sale, es todo corrido. `Grid2 container` trae `flexWrap: wrap` **de fábrica**, así que pasa
   sin que nadie lo escriba. En una columna sin alto definido envolver no sirve para nada: poner
   `wrap="nowrap"` y el desborde se queda dentro de quien lo provoca. Encontrado en `ShipmentMethods`.
   **Cómo se reconoce en la sonda**: dos hermanos con el *mismo* exceso sobre su padre — que se pasen
   los dos exactamente lo mismo no son dos defectos, es el padre.
10. **Menú o panel `position: absolute` anclado a un borde de su disparador** (`right: 0` o `left: 0`
    sobre un `Paper` hecho a mano, en vez de un `Menu`/`Popper` de MUI). El menú mide lo que pide su
    texto más largo, pero se despliega hacia **un solo lado**: si el botón está cerca de ese borde de
    la pantalla, no hay espacio y el menú se sale. Con `right: 0` en un botón pegado a la izquierda, se
    sale por la izquierda y se leen las palabras cortadas por delante ("escargar", "nviar por correo").
    En escritorio nunca se nota porque sobra sitio a los dos lados. Encontrado en el detalle de
    producto, en los desplegables de "Ficha Técnica" y "Otros documentos".
    **Solución**: en móvil quitarle al botón el papel de bloque contenedor (`position: { xs: 'static',
    md: 'relative' }`), poner `position: relative` en la fila que los agrupa y estirar el menú de borde
    a borde de esa fila con `left: 0` + `right: 0` — y bajar `minWidth` a `0` en `xs`, porque
    `max-content` gana sobre los dos desplazamientos y volvería a ensanchar el menú. Lo limpio de
    verdad es `Popper` con detección de colisión, pero eso cambia el comportamiento en escritorio.
    ⚠️ **Al ser `absolute`, este desborde NO aparece en `scrollWidth`**: ninguna sonda lo detecta. Es
    la familia de defectos que solo se encuentra mirando la pantalla.

11. **Márgenes o anchos en `vw` en la raíz de un modal** (`sx={{ margin: '0 25vw' }}` sobre un
    `Dialog`). En escritorio es la forma cómoda de que el diálogo ocupe la mitad de la pantalla; en un
    teléfono esos 25vw por lado dejan el contenedor en 50vw —180px de 360— y encima MUI le resta al
    papel los 64px de margen de `fullWidth`: el modal se queda en **~116px**. El síntoma no es un
    elemento que se sale: es un modal altísimo y angostísimo con el texto a dos o tres letras por
    renglón, y los botones de ancho fijo recortados dentro. Como el `Dialog` es `fixed`, **no genera
    desplazamiento horizontal**: es otro de los que solo se ven mirando la pantalla. Encontrado en
    `ModalEndedOrder`, el "la caja se registró correctamente" que cierra los tres flujos de envío
    (mini caja SMC3, mini caja SMC4 y pedido completo).
    **Solución**: el margen en `vw` solo desde `md` (`margin: { xs: 0, md: '0 25vw' }`) y recalcular
    el ancho del papel por breakpoint (`m`, `width` y `maxWidth`, porque `fullWidth` y
    `maxWidth={false}` los fijan en `calc(100% - 64px)`). Regla corta: **un valor en `vw` es un ancho
    fijo disfrazado** — se revisa igual que un `px`, y hay que sumarle lo que el componente de MUI ya
    descuenta por su cuenta.

12. **Mover un system prop al `sx` sin ver si estaba muerto.** MUI junta los system props de
    `Box`/`Stack`/`Grid` (`px={12}`, `mt={2}`, `width="50%"`) **antes** del `sx`. Con valores
    **planos** gana la clave que va después, así que un `paddingLeft: 0` en el `sx` anula a
    `px={12}`: en el original ese relleno no se aplicaba nunca. Pero un valor **responsive** se
    emite dentro de una `@media`, que en el CSS va después de las declaraciones planas: **gana
    siempre** a un valor plano de la misma propiedad, esté antes o después en el objeto. Por eso,
    al "ordenar" el código y meter el relleno al `sx` como `px: { xs: 0, md: 12 }`, revivió **justo
    en escritorio**. Así quedó el formulario de método de envío: 644px de ancho con 96px de relleno
    por lado, 452px útiles, etiquetas partidas en dos líneas.
    **Regla:** un system prop (o un valor plano del `sx`) que otra clave pisa es letra muerta: se
    borra, no se traslada ni se vuelve responsive. Y se comprueba con `scripts/sx-escritorio.cjs`
    comparando antes y después.

Además: **`textAlign: 'justify'` solo en escritorio.** En columna estrecha reparte las palabras con
huecos enormes y el párrafo se vuelve ilegible.

Y: **pestañas en `variant="fullWidth"`.** Reparte la tira en partes iguales y la etiqueta no encoge,
así que en cuanto hay tres pestañas de texto largo cada una se queda con ~100px, el texto se sale de
su pestaña y se enciman. Pasó en Información del cliente, y **solo con los clientes que tienen
"Premia expertos"** — con dos pestañas alcanzaba justo. `TabGeneric` ya trae `scrollable` por
defecto: no pasarle `fullWidth` salvo con dos etiquetas cortas.

### Paddings de escritorio: `px: 10` son 80px por lado

`px: 10` en un `AccordionDetails`, `p: 4` en un contenedor, `mx={5}` en una fila — en escritorio son
respiración; en 360px se comen la pantalla. Encontrado en el detalle de pedido: `px: 10` (80px por
lado) más un `Box px={5}` interno (40px más) dejaban **~120px útiles** de 360, y todo el acordeón
salía en una columna estrecha y centrada. Buscar `px:` y `p:` de 4 en adelante y bajarlos con
`{ xs: 1.5, md: N }`.

### Un alto fijo se quita entero o no se quita

Al liberar un alto fijo hay que seguir la cadena **hasta el final**. Si se quita el `overflow: hidden`
del contenedor exterior pero queda un alto adentro, el defecto no desaparece: **cambia de recortar a
desbordarse a la vista**, que se ve peor. Pasó dos veces en la tarjeta de crédito: primero se
liberó `CardCreditInfo` (500px) y el "Monto disponible" empezó a dibujarse *fuera* del borde, porque
quedaban `CreditInfo` (420px) y dos `ctnCreditSx` con `height: 100%`.

Ojo también con el orden del spread: `sx={{ ...estiloCompartido, height: '100%' }}` **anula** el valor
responsivo que traía el estilo compartido.

### Los controles de MUI traen mínimos de escritorio

Antes de meter un control de MUI en una tarjeta angosta hay que mirar su **min-content**, no su
apariencia: `Button` trae `min-width: 64px` de fábrica, un `TextField` reclama ~180px por el tamaño
por defecto de su input y los `Select` se comportan igual. El contador (`Counter`) suma los tres y
exigía **~310px** en una tarjeta de 360: la descripción del artículo se quedaba con unos pocos
píxeles y, con `wordBreak: break-word`, salía **una letra por renglón**. Salió en la vista previa del
mini checkout SMC4 al llevar a móvil el contador editable del proyecto original.

Al montar un control dentro de una tarjeta: bajar los mínimos a lo táctil (44px), dejar que el campo
encoja (`minWidth: 0`) y ponerle **techo a la columna del control** para que el texto conserve su
mitad.

### El único elemento flexible de un renglón se come todo el faltante

Cuando en una fila hay varios controles con ancho fijo y **uno solo** que puede encoger, el
navegador no reparte el desborde: lo carga entero sobre ese uno. Si además lleva `minWidth: 0`,
llega a **cero píxeles** — no se recorta, desaparece, y con él la posibilidad de tocarlo.

Le pasó al contador del catálogo (`CatalogueCounter` dentro de `ProductCard`): el renglón pedía
165px —88 del contador, 37 del botón de compatibilidad, 40 de la P de promociones— en los 144px de
una tarjeta de la rejilla de dos columnas a 360px. El `<input>` de la cantidad se quedó en 0px: el
usuario veía `−` y `+` sin número en medio y no había forma de escribir la cantidad.

Dos reglas que van juntas:

- **Piso al campo, no `minWidth: 0`.** Un campo editable necesita un mínimo (32px alcanzan para el
  número). Con piso, si aún no cabe el desborde queda a la vista, que es un defecto que se reporta;
  sin piso queda un control invisible, que nadie reporta porque nadie sabe que está ahí.
- **Bajar los pisos del renglón, no solo darle piso al campo.** Es la cuenta de "sumar los pisos":
  si los fijos ya no dejan sitio, hay que partir el renglón. En la tarjeta de la rejilla el contador
  pasó a ocupar el ancho completo y los dos iconos bajaron a un segundo renglón alineado a la
  derecha. La tarjeta **crece de alto, no de ancho**, y eso en una rejilla no rompe nada.

### El salto de línea de flex se calcula con la base, no con el ancho encogido

En un `flex-wrap: wrap` con título a la izquierda y acciones a la derecha, poner `minWidth: 0` al
título **no basta**: flex decide el salto de línea con la base del ítem (su `max-content` si no se
declara), no con el ancho al que podría encogerse. Un título largo reclama todo el ancho y empuja
abajo hasta a un par de íconos, que quedan descolgados a la izquierda.

```tsx
// El título cede ancho y envuelve; las acciones se quedan al lado.
<Box sx={{ display:'flex', justifyContent:'space-between', flexWrap:'wrap', gap:1 }}>
    <Box sx={{ minWidth: 0, flex: '1 1 60%' }}>{titulo}</Box>
    <Box sx={{ flexShrink: 0 }}>{acciones}</Box>
</Box>
```

La base elegida decide el comportamiento: con `60%`, unas acciones compactas (~35%) caben al lado y
el título envuelve; una acción ancha (>40%, como "Convertir a pedido") sí baja a su renglón, que es
cuando conviene que baje. Le pasó al encabezado de `DataCard` con los nombres de rol largos.

## Un tooltip no existe en táctil

`Tooltip` de MUI aparece al pasar el ratón. En un teléfono **no hay hover**: el texto no se muestra
nunca. Da igual que el control esté envuelto en un `<span>` para que el tooltip funcione con el botón
deshabilitado — eso arregla el hover del ratón, no la ausencia de puntero.

Duele sobre todo cuando el tooltip explica **por qué un control está deshabilitado**: en escritorio
el usuario pasa el ratón y entiende; en móvil ve un botón apagado y no sabe qué hacer. Al adaptar una
pantalla donde el tooltip lleva esa carga, el texto se pinta a la vista —una línea de apoyo debajo o
al lado del control—, con **el mismo texto** que el tooltip. Si el tooltip es solo el nombre de un
icono evidente (la papelera, el lápiz), basta con el `aria-label`.

Pasó con el precio final (release 3.22.0 del original): dos tooltips explicaban que el select de
promoción y el botón de precio especial estaban bloqueados por haber un mejor precio aplicado.

**Variante aceptada: muchos tooltips informativos, una leyenda plegable.** Cuando cada elemento de
una serie lleva su explicación en un tooltip —las siete tarjetas de indicadores del monitoreo
(release 3.39.0)—, pintarlas dentro de cada tarjeta las haría medir el triple. Se pintan juntas en
una leyenda debajo, solo en móvil, detrás de un botón de 44px («¿Qué mide cada indicador?»). Dos
condiciones: el tooltip y la leyenda salen **del mismo arreglo** (nunca textos copiados), y la
leyenda vive siempre en el DOM con `hidden`, para que `aria-controls` apunte a algo que existe. Vale
para explicaciones informativas; el motivo de un control deshabilitado sigue yendo al lado del control.

## Objetivos táctiles

Mínimo **44px** en móvil para botones, selects, checkboxes y contadores. Los componentes heredados
traen 32–36px; al tocar uno, subirlo.

## Adaptar nunca puede quitar una acción

Dos formas de perder un botón sin borrar una sola línea de código. Las dos ocurrieron:

1. **Columna sin `headerName` en un `AdaptiveDataGrid`.** La card mostraba solo columnas con
   encabezado y trataba como acciones solo las `type: 'actions'`. Una columna sin etiqueta —que es
   justo como se declara una columna de control: editar, switch, radio, checkbox, botón de fila—
   no entraba en ninguna de las dos y desaparecía entera. Afectó a 17 pantallas. Resuelto en
   `cardFieldResolver.isCardActionColumn`: sin encabezado + con `renderCell`/`getActions` = acción.
2. **`{!isMobileExperience && <Componente />}`.** Ocultar en vez de adaptar. `UserNavBar` se dejó
   fuera de móvil y con él se fueron cotizador, existencias por región, cuentas bancarias, liga de
   expertos, notificaciones y detalle de orden. Si no cabe, se colapsa en un menú; no se elimina.

Regla: **ocultar es la última opción, y solo cuando la función tiene otra puerta en móvil** (el
sidebar de filtros del catálogo se oculta porque existe el drawer de filtros; el botón "Buscar" de
escritorio se oculta porque hay uno móvil a lo ancho). Si no hay otra puerta, hay que construirla.

Para verificarlo sin depender de capturas: contar elementos interactivos por archivo contra la
versión previa —`<Button`, `<IconButton`, `<Switch`, `<Checkbox`, `onClick=`— y revisar todo
`display: { xs: 'none' }` y todo `!isMobileExperience &&` que se haya introducido.

### Y al revés: cuando el original gana una acción, la rama móvil la gana igual

Este proyecto es un fork del EPICO original, que sigue en desarrollo. Cuando allá una tabla gana un
control —les pasó con el contador editable de la vista previa del mini checkout—, git fusiona sin
conflicto y **la rama móvil se queda sin él**, porque esa pantalla tiene su propia tarjeta. La
verificación después de cada sincronización es la misma de arriba, pero comparando contra **su**
versión: qué elementos interactivos aparecieron en las columnas de escritorio y no en la tarjeta.
Lo mismo con lo que ellos quitan: un control que allá se comenta y aquí sigue vivo acaba apuntando a
algo que ya no existe.

## Campos de texto que filtran caracteres

Si un input descarta parte de lo que se escribe, **tiene que declarar el teclado que corresponde**:

```tsx
slotProps={{ htmlInput: { inputMode: "numeric", pattern: "[0-9]*" } }}
```

En escritorio el filtro es invisible: el usuario ve la etiqueta, escribe lo correcto y sigue. En el
teléfono el teclado **es** la interfaz. Con el teclado alfabético abierto sobre un campo que solo
acepta dígitos, el usuario escribe, no aparece un solo carácter y no hay mensaje: el campo se lee
como roto, no como validado. Le pasó al buscador de Pedidos Externos, el único `SearchBar` con
`onlyDigits`.

Dos reglas que van juntas:

- **`inputMode`** (`numeric`, `decimal`, `tel`, `email`) en todo campo con filtro de caracteres.
- **La etiqueta dice qué se busca, no dónde se busca.** "Buscar por cliente" invita a escribir el
  nombre; el endpoint recibe `ClienteId`. Es "Buscar por ID de cliente".
- **Y si el campo descarta un valor, tiene que ofrecer una salida.** El contador del catálogo
  rechazaba el campo vacío, así que "seleccionar todo y escribir" o "borrar y teclear" devolvían el
  número anterior: se leía como un campo de solo lectura. Vaciarlo vale como 0; y en vez de rechazar
  toda la cadena por un carácter, se descartan los caracteres que no valen.

Los dos casos encontrados —el buscador de Pedidos Externos y `CatalogueCounter`, que alcanza a seis
pantallas— tenían el filtro correcto y el teclado equivocado.

Antes de asumir que el filtro está mal, revisar qué acepta el backend: en `IBranchOrdersFilters`
**todos** los filtros son IDs numéricos, fechas o estatus — no hay búsqueda por nombre que ofrecer.

## Duplicación fila/tarjeta

Cuando una pantalla tiene vista de tabla y vista de tarjeta, la lógica de resolución de datos
(descripción de genérico, imagen con respaldos, importes, estados en rojo) se extrae a una función
que usan **las dos**. Si se escribe dos veces, nada obliga a mantenerlas sincronizadas y divergen.
Ejemplo: `resolveDescription` / `renderProductImage` en `QuotationSummary.tsx`.

## Verificación

```bash
npx tsc --noEmit     # desde Next 16 no mira __tests__
npm run lint         # eslint . sobre todo el repo: compara el conteo de tus archivos antes y después
npm run testJest
```

Y revisar a **320px** de ancho que la página **no tenga desplazamiento horizontal** (ver arriba por
qué 320 y no 360), y que **escritorio resuelva igual que el original**:
`node scripts/sx-escritorio.cjs` con cuatro argumentos (el `sx` del original y el nuevo) tiene que
decir `"escritorio_identico": true`.
