import { render, screen, fireEvent, waitForElementToBeRemoved, act } from '@testing-library/react';
import { AlertColor } from '@mui/material';
import { SnackbarProvider, useSnackbar } from '@/context/snackBar/SnackBarContext';

/**
 * El snackbar es el único canal de errores de la aplicación, y los mensajes que recibe
 * son los del gateway tal cual (`handleRequestDto` y `handleRequestStockDto` pasan
 * `response.message`). En el teléfono se reportó un error que no se veía como error: iba
 * en mayúsculas, sin forma de cerrarlo. Lo que se puede probar aquí es el contrato del
 * mensaje; el ancho contra el viewport no, jsdom no calcula layout.
 */
describe('SnackbarProvider', () => {
    const MENSAJE_GATEWAY =
        '[GetDetalleProductoPorClienteQueryHandler - REFIT - RecuperarPreciosPorClienteIdCod] Ocurrió un error con la conexión a REFIT';

    const Lanzador = ({ mensaje, tipo }: { mensaje: string; tipo: AlertColor }) => {
        const { showSnackbar } = useSnackbar();
        return <button onClick={() => showSnackbar(mensaje, tipo)}>lanzar</button>;
    };

    const setup = (mensaje = MENSAJE_GATEWAY, tipo: AlertColor = 'error') => {
        render(
            <SnackbarProvider>
                <Lanzador mensaje={mensaje} tipo={tipo} />
            </SnackbarProvider>
        );
        fireEvent.click(screen.getByRole('button', { name: 'lanzar' }));
    };

    it('muestra el mensaje tal como llega, sin forzar mayúsculas', () => {
        setup();

        expect(screen.getByText(MENSAJE_GATEWAY)).toBeInTheDocument();
        expect(screen.queryByText(MENSAJE_GATEWAY.toUpperCase())).not.toBeInTheDocument();
    });

    it('marca la severidad en el aviso', () => {
        setup('No se pudieron obtener las existencias', 'error');

        expect(screen.getByRole('alert')).toHaveClass('MuiAlert-colorError');
    });

    it('se puede cerrar a mano sin esperar el autohide', async () => {
        setup();

        fireEvent.click(screen.getByRole('button', { name: /close/i }));

        // El aviso sale con transición, así que se espera a que desmonte.
        await waitForElementToBeRemoved(() => screen.queryByText(MENSAJE_GATEWAY));
    });
});

/**
 * A notice stays on screen for its minimum time, even when it arrives while another one is showing.
 */
describe('SnackbarProvider · UX-INT-08', () => {
    const PERMANENCIA_MINIMA_MS = 3000;
    const PRIMERO = 'Primer aviso';
    const SEGUNDO = 'Segundo aviso';

    const Lanzador = () => {
        const { showSnackbar } = useSnackbar();
        return (
            <>
                <button onClick={() => showSnackbar(PRIMERO, 'info')}>lanzar primero</button>
                <button onClick={() => showSnackbar(SEGUNDO, 'info')}>lanzar segundo</button>
            </>
        );
    };

    const avanzar = (ms: number) => act(() => { jest.advanceTimersByTime(ms); });

    beforeEach(() => {
        jest.useFakeTimers();
        render(
            <SnackbarProvider>
                <Lanzador />
            </SnackbarProvider>
        );
    });

    afterEach(() => {
        act(() => { jest.runOnlyPendingTimers(); });
        jest.useRealTimers();
    });

    it('mantiene un aviso en pantalla el mínimo legible', () => {
        fireEvent.click(screen.getByRole('button', { name: 'lanzar primero' }));

        avanzar(PERMANENCIA_MINIMA_MS - 1);

        expect(screen.getByText(PRIMERO)).toBeInTheDocument();
    });

    it('un aviso que sustituye a otro estrena su propio tiempo (ESC-61)', () => {
        fireEvent.click(screen.getByRole('button', { name: 'lanzar primero' }));

        // Let almost all of the first notice's time run out before launching the second.
        avanzar(PERMANENCIA_MINIMA_MS - 100);
        fireEvent.click(screen.getByRole('button', { name: 'lanzar segundo' }));

        expect(screen.getByText(SEGUNDO)).toBeInTheDocument();

        // If it inherited the first one's clock, it would have disappeared after 100 ms.
        avanzar(PERMANENCIA_MINIMA_MS - 1);

        expect(screen.getByText(SEGUNDO)).toBeInTheDocument();
    });
});
