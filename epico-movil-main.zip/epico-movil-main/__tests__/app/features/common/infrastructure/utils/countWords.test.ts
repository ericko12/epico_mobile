import { countWords } from '@/features/common/infrastructure/utils/countWords';

describe('countWords', () => {
    it('returns 0 for an empty or blank text', () => {
        expect(countWords('')).toBe(0);
        expect(countWords('   ')).toBe(0);
    });

    it('counts words separated by consecutive spaces, tabs or line breaks', () => {
        expect(countWords('  cliente   pide\trecoger\nhoy ')).toBe(4);
    });

    it('does not count isolated symbols as words', () => {
        expect(countWords('uno - dos ...')).toBe(2);
    });

    it('counts words with accents, ñ and numbers', () => {
        expect(countWords('sucursal Peñón 40 km')).toBe(4);
    });
});
