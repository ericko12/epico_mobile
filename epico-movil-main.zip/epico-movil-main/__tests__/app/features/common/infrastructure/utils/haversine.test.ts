import { haversineDistanceKm } from '@/features/common/infrastructure/utils/haversine';

describe('haversineDistanceKm', () => {
    it('returns 0 for the same point', () => {
        const point = { lat: 20.659698, lng: -103.349609 };
        expect(haversineDistanceKm(point, point)).toBe(0);
    });

    it('returns approximately 1 km for two points ~0.009° of latitude apart', () => {
        // 1° of latitude ≈ 111 km → 0.009° ≈ ~1 km
        const a = { lat: 20.659698, lng: -103.349609 };
        const b = { lat: 20.668698, lng: -103.349609 };
        expect(haversineDistanceKm(a, b)).toBeCloseTo(1.0, 0);
    });

    it('is symmetric: distance(a, b) === distance(b, a)', () => {
        const a = { lat: 20.698746, lng: -103.316165 };
        const b = { lat: 20.710000, lng: -103.320000 };
        expect(haversineDistanceKm(a, b)).toBeCloseTo(haversineDistanceKm(b, a), 10);
    });

    it('returns a value greater than 2 km for points clearly further apart', () => {
        // ~2.5 km west (1° lng ≈ 104 km at lat 20° → 0.025° ≈ 2.6 km)
        const a = { lat: 20.659698, lng: -103.349609 };
        const b = { lat: 20.659698, lng: -103.375 };
        expect(haversineDistanceKm(a, b)).toBeGreaterThan(2);
    });

    it('returns a value less than 2 km for points within range', () => {
        // < 200 m apart
        const a = { lat: 20.659698, lng: -103.349609 };
        const b = { lat: 20.661000, lng: -103.351000 };
        expect(haversineDistanceKm(a, b)).toBeLessThan(2);
    });

    it('returns a positive value for any two distinct points', () => {
        const a = { lat: 19.432608, lng: -99.133209 }; // CDMX
        const b = { lat: 20.659698, lng: -103.349609 }; // Guadalajara
        expect(haversineDistanceKm(a, b)).toBeGreaterThan(0);
    });
});
