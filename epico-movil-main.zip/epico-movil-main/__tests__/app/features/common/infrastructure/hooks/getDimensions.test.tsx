import React from 'react';
import { render, screen, act } from '@testing-library/react';
import useWindowDimensions, {
    __resetWindowDimensionsStore,
} from '@/features/common/infrastructure/hooks/getDimensions';

/**
 * El hook pasó de un `useState` + un listener de `resize` POR INSTANCIA a una
 * suscripción única a nivel de módulo. Estas pruebas fijan las dos propiedades
 * que motivaron el cambio: un solo listener y cero renders cuando nada cambió.
 */

const setWidth = (width: number, height = 800) => {
    Object.defineProperty(window, 'innerWidth', { value: width, configurable: true, writable: true });
    Object.defineProperty(window, 'innerHeight', { value: height, configurable: true, writable: true });
};

/** Dispara resize y ejecuta el frame que agrupa la ráfaga. */
const fireResize = () => {
    act(() => {
        window.dispatchEvent(new Event('resize'));
    });
};

let addSpy: jest.SpyInstance;
let removeSpy: jest.SpyInstance;

beforeEach(() => {
    // requestAnimationFrame síncrono: el hook agrupa la ráfaga de resize en un frame.
    jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb: FrameRequestCallback) => {
        cb(0);
        return 1;
    });
    jest.spyOn(window, 'cancelAnimationFrame').mockImplementation(() => { });
    addSpy = jest.spyOn(window, 'addEventListener');
    removeSpy = jest.spyOn(window, 'removeEventListener');
    setWidth(1280);
    __resetWindowDimensionsStore();
});

afterEach(() => {
    jest.restoreAllMocks();
});

/** Componente sonda: pinta el ancho y cuenta sus propios renders. */
const makeProbe = (id: string, onRender: () => void) => {
    const Probe = () => {
        const { width, isMobileExperience } = useWindowDimensions();
        onRender();
        return <span data-testid={id}>{`${width}|${isMobileExperience}`}</span>;
    };
    return Probe;
};

const countResizeListeners = (spy: jest.SpyInstance) =>
    spy.mock.calls.filter(([event]) => event === 'resize').length;

describe('useWindowDimensions', () => {
    it('registra un solo listener de resize aunque haya varios consumidores', () => {
        const noop = () => { };
        const A = makeProbe('a', noop);
        const B = makeProbe('b', noop);
        const C = makeProbe('c', noop);

        render(<><A /><B /><C /></>);

        expect(countResizeListeners(addSpy)).toBe(1);
    });

    it('entrega las mismas medidas a todos', () => {
        const noop = () => { };
        const A = makeProbe('a', noop);
        const B = makeProbe('b', noop);

        render(<><A /><B /></>);

        expect(screen.getByTestId('a')).toHaveTextContent('1280|false');
        expect(screen.getByTestId('b')).toHaveTextContent('1280|false');
    });

    it('no re-renderiza cuando el resize no cambió nada', () => {
        const onRender = jest.fn();
        const Probe = makeProbe('a', onRender);
        render(<Probe />);

        const rendersIniciales = onRender.mock.calls.length;
        fireResize();
        fireResize();

        expect(onRender.mock.calls.length).toBe(rendersIniciales);
    });

    it('propaga un cambio real de ancho a todos los consumidores', () => {
        const noop = () => { };
        const A = makeProbe('a', noop);
        const B = makeProbe('b', noop);
        render(<><A /><B /></>);

        act(() => setWidth(400));
        fireResize();

        expect(screen.getByTestId('a')).toHaveTextContent('400|true');
        expect(screen.getByTestId('b')).toHaveTextContent('400|true');
    });

    it('retira el listener cuando se desmonta el último consumidor', () => {
        const noop = () => { };
        const A = makeProbe('a', noop);
        const B = makeProbe('b', noop);
        const { unmount } = render(<><A /><B /></>);

        expect(countResizeListeners(removeSpy)).toBe(0);
        unmount();
        expect(countResizeListeners(removeSpy)).toBe(1);
    });
});
