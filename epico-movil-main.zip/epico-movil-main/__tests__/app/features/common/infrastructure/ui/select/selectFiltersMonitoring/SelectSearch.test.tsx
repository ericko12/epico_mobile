import React from 'react';
import { render, screen, fireEvent, within } from '@testing-library/react';
import { SelectSearch } from '@/features/common/infrastructure/ui/select/selectFiltersMonitoring/SelectSearch';
import { TypeSearchMonitoringEnum } from '@/features/common/infrastructure/ui/select/selectFiltersMonitoring/SelectSearch.type';

const handleSearch = jest.fn();

const openOptions = () => {
    fireEvent.click(screen.getByLabelText('Open'));
    return within(screen.getByRole('listbox'));
};

describe('SelectSearch', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('offers purchase order alongside the existing criteria', () => {
        render(<SelectSearch search={null} handleSearch={handleSearch} />);
        const listbox = openOptions();

        expect(listbox.getByText('Pedido')).toBeInTheDocument();
        expect(listbox.getByText('Cliente')).toBeInTheDocument();
        expect(listbox.getByText('Factura')).toBeInTheDocument();
        expect(listbox.getByText('Orden de compra')).toBeInTheDocument();
    });

    it('reports the purchase order criterion when it is picked', () => {
        render(<SelectSearch search={null} handleSearch={handleSearch} />);
        const listbox = openOptions();

        fireEvent.click(listbox.getByText('Orden de compra'));

        expect(handleSearch).toHaveBeenCalledWith(
            expect.objectContaining({ id: TypeSearchMonitoringEnum.OrdenCompra, nombre: 'Orden de compra' })
        );
    });

    it('keeps the identifiers already in use for the previous criteria', () => {
        expect(TypeSearchMonitoringEnum.Pedido).toBe(1);
        expect(TypeSearchMonitoringEnum.Cliente).toBe(2);
        expect(TypeSearchMonitoringEnum.Factura).toBe(3);
        expect(TypeSearchMonitoringEnum.OrdenCompra).toBe(4);
    });
});
