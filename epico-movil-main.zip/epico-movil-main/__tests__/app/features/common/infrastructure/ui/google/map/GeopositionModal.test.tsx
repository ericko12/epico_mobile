import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { GeopositionModal } from '@/features/common/infrastructure/ui/google/map/GeopositionModal';
import { haversineDistanceKm } from '@/features/common/infrastructure/utils/haversine';

// ─── Mocks ───────────────────────────────────────────────────────────────────

jest.mock('@/features/common/infrastructure/ui/dialog/ModalGeneric', () => ({
    ModalGeneric: ({
        children,
        onSave,
        onClose,
        openModal,
        titulo,
    }: {
        children?: React.ReactNode;
        onSave?: () => void;
        onClose?: () => void;
        openModal: boolean;
        titulo?: string;
    }) =>
        openModal ? (
            <div data-testid="modal-generic">
                <h2 data-testid="modal-title">{titulo}</h2>
                <div>{children}</div>
                <button data-testid="btn-save" onClick={onSave}>Guardar</button>
                <button data-testid="btn-close" onClick={onClose}>Cerrar</button>
            </div>
        ) : null,
}));

jest.mock('@vis.gl/react-google-maps', () => ({
    APIProvider: ({ children }: { children: React.ReactNode }) => <>{children}</>,
    Map: ({
        children,
        onClick,
    }: {
        children?: React.ReactNode;
        onClick?: (e: unknown) => void;
    }) => (
        <div
            data-testid="mock-map"
            onClick={() =>
                onClick?.({ detail: { latLng: { lat: 20.7, lng: -103.4 } } })
            }
        >
            {children}
        </div>
    ),
    Marker: ({ onDragEnd }: { onDragEnd?: (e: unknown) => void }) => (
        <div
            data-testid="mock-marker"
            onMouseUp={() =>
                onDragEnd?.({
                    latLng: { lat: () => 20.71, lng: () => -103.41 },
                })
            }
        />
    ),
    useMap: () => ({
        setCenter: jest.fn(),
        getZoom: jest.fn().mockReturnValue(18),
        setZoom: jest.fn(),
    }),
}));

jest.mock('@/features/common/infrastructure/utils/secrets/getGoogleSecret', () => ({
    getMapsApiKey: jest.fn().mockResolvedValue('TEST_API_KEY'),
}));

const mockShowSnackbar = jest.fn();
jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: mockShowSnackbar }),
}));

jest.mock('@/features/common/infrastructure/utils/haversine', () => ({
    haversineDistanceKm: jest.fn(),
}));

// ─── google.maps global ───────────────────────────────────────────────────────

const mockGeocode = jest.fn();

beforeAll(() => {
    Object.defineProperty(global, 'google', {
        value: {
            maps: {
                Geocoder: jest.fn(() => ({ geocode: mockGeocode })),
            },
        },
        writable: true,
        configurable: true,
    });
});

// ─── Shared fixtures ──────────────────────────────────────────────────────────

const mexicoResult = {
    address_components: [{ short_name: 'MX', types: ['country'] }],
};

const nonMexicoResult = {
    address_components: [{ short_name: 'US', types: ['country'] }],
};

const initialLatLng = { lat: 20.7, lng: -103.4 };

const waitForMap = () =>
    waitFor(() => expect(screen.getByTestId('mock-map')).toBeInTheDocument());

// ─── Setup / teardown ─────────────────────────────────────────────────────────

beforeEach(() => {
    mockGeocode.mockResolvedValue({ results: [mexicoResult] });
    (haversineDistanceKm as jest.Mock).mockReturnValue(0.5); // within 2 km limit
});

afterEach(() => {
    jest.clearAllMocks();
});

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('GeopositionModal', () => {
    describe('render', () => {
        it('renders the modal with the correct title', () => {
            render(
                <GeopositionModal open onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            expect(screen.getByTestId('modal-title')).toHaveTextContent(
                'AJUSTAR UBICACIÓN'
            );
        });

        it('does not render when open is false', () => {
            render(
                <GeopositionModal open={false} onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            expect(screen.queryByTestId('modal-generic')).not.toBeInTheDocument();
        });

        it('renders the map after the API key resolves', async () => {
            render(
                <GeopositionModal open onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            await waitForMap();
            expect(screen.getByTestId('mock-map')).toBeInTheDocument();
        });

        it('renders the marker when initialLatLng is provided', async () => {
            render(
                <GeopositionModal
                    open
                    onClose={jest.fn()}
                    onConfirm={jest.fn()}
                    initialLatLng={initialLatLng}
                />
            );
            await waitForMap();
            expect(screen.getByTestId('mock-marker')).toBeInTheDocument();
        });

        it('does not render the marker when no initialLatLng is provided', async () => {
            render(
                <GeopositionModal open onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            await waitForMap();
            expect(screen.queryByTestId('mock-marker')).not.toBeInTheDocument();
        });
    });

    describe('handleSave', () => {
        it('calls onConfirm with undefined and onClose when no position is selected', async () => {
            const onClose = jest.fn();
            const onConfirm = jest.fn();
            render(<GeopositionModal open onClose={onClose} onConfirm={onConfirm} />);
            await waitForMap();

            fireEvent.click(screen.getByTestId('btn-save'));

            expect(onConfirm).toHaveBeenCalledWith(undefined);
            expect(onClose).toHaveBeenCalled();
        });

        it('calls onConfirm with initialLatLng and onClose when a position is set', async () => {
            const onClose = jest.fn();
            const onConfirm = jest.fn();
            render(
                <GeopositionModal
                    open
                    onClose={onClose}
                    onConfirm={onConfirm}
                    initialLatLng={initialLatLng}
                />
            );
            await waitForMap();

            fireEvent.click(screen.getByTestId('btn-save'));

            expect(onConfirm).toHaveBeenCalledWith(initialLatLng);
            expect(onClose).toHaveBeenCalled();
        });
    });

    describe('onClose', () => {
        it('calls onClose when the close button is clicked', async () => {
            const onClose = jest.fn();
            render(
                <GeopositionModal open onClose={onClose} onConfirm={jest.fn()} />
            );
            await waitForMap();

            fireEvent.click(screen.getByTestId('btn-close'));

            expect(onClose).toHaveBeenCalled();
        });
    });

    describe('handleMapClick', () => {
        it('adds a marker after clicking on the map (valid Mexico location)', async () => {
            render(
                <GeopositionModal open onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            await waitForMap();

            fireEvent.click(screen.getByTestId('mock-map'));

            await waitFor(() =>
                expect(screen.getByTestId('mock-marker')).toBeInTheDocument()
            );
        });

        it('shows a warning snackbar when the selected location is outside Mexico', async () => {
            mockGeocode.mockResolvedValue({ results: [nonMexicoResult] });
            render(
                <GeopositionModal open onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            await waitForMap();

            fireEvent.click(screen.getByTestId('mock-map'));

            await waitFor(() =>
                expect(mockShowSnackbar).toHaveBeenCalledWith(
                    'Por favor selecciona una dirección dentro de México.',
                    'warning'
                )
            );
        });

        it('does not add a marker when the selected location is outside Mexico', async () => {
            mockGeocode.mockResolvedValue({ results: [nonMexicoResult] });
            render(
                <GeopositionModal open onClose={jest.fn()} onConfirm={jest.fn()} />
            );
            await waitForMap();

            fireEvent.click(screen.getByTestId('mock-map'));

            await waitFor(() => expect(mockShowSnackbar).toHaveBeenCalled());
            expect(screen.queryByTestId('mock-marker')).not.toBeInTheDocument();
        });

        it('updates the marker without a distance warning when the position is far from the origin', async () => {
            // The 2 km distance check was intentionally removed from GeopositionModal
            (haversineDistanceKm as jest.Mock).mockReturnValue(3);
            render(
                <GeopositionModal
                    open
                    onClose={jest.fn()}
                    onConfirm={jest.fn()}
                    initialLatLng={initialLatLng}
                />
            );
            await waitForMap();
            // Marker starts at initialLatLng
            expect(screen.getByTestId('mock-marker')).toBeInTheDocument();

            fireEvent.click(screen.getByTestId('mock-map'));

            await waitFor(() => expect(mockGeocode).toHaveBeenCalled());
            // Marker remains after the update and no warning is shown
            expect(screen.getByTestId('mock-marker')).toBeInTheDocument();
            expect(mockShowSnackbar).not.toHaveBeenCalled();
        });

        it('does not show a warning when the position is within 2 km', async () => {
            (haversineDistanceKm as jest.Mock).mockReturnValue(0.5); // < MAX_ADJUST_KM
            render(
                <GeopositionModal
                    open
                    onClose={jest.fn()}
                    onConfirm={jest.fn()}
                    initialLatLng={initialLatLng}
                />
            );
            await waitForMap();

            fireEvent.click(screen.getByTestId('mock-map'));

            await waitFor(() =>
                expect(screen.getByTestId('mock-marker')).toBeInTheDocument()
            );
            expect(mockShowSnackbar).not.toHaveBeenCalled();
        });
    });

    describe('handleMarkerDragEnd', () => {
        it('calls the geocoder with the new coordinates after dragging the marker', async () => {
            render(
                <GeopositionModal
                    open
                    onClose={jest.fn()}
                    onConfirm={jest.fn()}
                    initialLatLng={initialLatLng}
                />
            );
            await waitForMap();

            fireEvent.mouseUp(screen.getByTestId('mock-marker'));

            await waitFor(() =>
                expect(mockGeocode).toHaveBeenCalledWith(
                    expect.objectContaining({
                        location: { lat: 20.71, lng: -103.41 },
                    })
                )
            );
        });
    });
});
