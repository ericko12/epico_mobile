import React from 'react';
import { render, screen } from '@testing-library/react';
import { ModalGeneric } from '@/features/common/infrastructure/ui/dialog/ModalGeneric';

// Controla el branching responsivo del modal.
const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

const setMobile = () =>
    mockDimensions.mockReturnValue({ width: 375, height: 800, isMobile: true, isTablet: false, isDesktop: false, isMobileAndTablet: true, isMobileExperience: true });
const setDesktop = () =>
    mockDimensions.mockReturnValue({ width: 1280, height: 800, isMobile: false, isTablet: false, isDesktop: true, isMobileAndTablet: false, isMobileExperience: false });

afterEach(() => jest.clearAllMocks());

/** Devuelve el nodo Paper del diálogo abierto. */
const getDialogPaper = () => document.querySelector('.MuiDialog-paper');

describe('ModalGeneric - fullScreen en la experiencia móvil', () => {
    it('usa fullScreen en móvil para modales de contenido (maxWidth md)', () => {
        setMobile();
        render(
            <ModalGeneric titulo="Detalle" openModal maxWidth="md" onClose={jest.fn()}>
                <p>contenido</p>
            </ModalGeneric>,
        );
        expect(getDialogPaper()).toHaveClass('MuiDialog-paperFullScreen');
    });

    it('NO usa fullScreen en desktop aunque maxWidth sea md', () => {
        setDesktop();
        render(
            <ModalGeneric titulo="Detalle" openModal maxWidth="md" onClose={jest.fn()}>
                <p>contenido</p>
            </ModalGeneric>,
        );
        expect(getDialogPaper()).not.toHaveClass('MuiDialog-paperFullScreen');
    });

    it('NO usa fullScreen en móvil para modales de confirmación (maxWidth sm por defecto)', () => {
        setMobile();
        render(
            <ModalGeneric titulo="¿Confirmar?" openModal onClose={jest.fn()}>
                <p>contenido</p>
            </ModalGeneric>,
        );
        expect(getDialogPaper()).not.toHaveClass('MuiDialog-paperFullScreen');
    });

    it('permite forzar fullScreen en móvil con mobileFullScreen aunque sea maxWidth sm', () => {
        setMobile();
        render(
            <ModalGeneric titulo="Forzado" openModal maxWidth="sm" mobileFullScreen onClose={jest.fn()}>
                <p>contenido</p>
            </ModalGeneric>,
        );
        expect(getDialogPaper()).toHaveClass('MuiDialog-paperFullScreen');
    });

    it('sigue mostrando el título y el contenido en móvil', () => {
        setMobile();
        render(
            <ModalGeneric titulo="Detalle pedido" openModal maxWidth="md" onClose={jest.fn()}>
                <p>cuerpo del modal</p>
            </ModalGeneric>,
        );
        expect(screen.getByText('DETALLE PEDIDO')).toBeInTheDocument();
        expect(screen.getByText('cuerpo del modal')).toBeInTheDocument();
    });
});
