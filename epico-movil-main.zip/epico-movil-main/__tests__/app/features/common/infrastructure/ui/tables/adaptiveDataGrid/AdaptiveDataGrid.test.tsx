import React from 'react';
import { render, screen, fireEvent, within } from '@testing-library/react';
import { GridColDef, GridActionsCellItem } from '@mui/x-data-grid';
import { AdaptiveDataGrid } from '@/features/common/infrastructure/ui/tables/adaptiveDataGrid/AdaptiveDataGrid';

// ─── Mocks ───────────────────────────────────────────────────────────────────

// El branching depende de useWindowDimensions (getDimensions default export).
const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

// La rama desktop delega en el DataGrid real: lo sustituimos por un centinela
// para verificar el passthrough sin renderizar el grid de terceros.
jest.mock('@/features/common/infrastructure/ui/tables/DataGridServerPagination', () => ({
    DataGridServerPagination: () => <div data-testid="desktop-grid" />,
}));

// ─── Fixtures ──────────────────────────────────────────────────────────────────

interface IRowFixture {
    clienteVendedorId: number;
    clienteID: number;
    nombre: string;
    fechaAlta: string;
    statusCredito: string;
}

const rows: IRowFixture[] = [
    { clienteVendedorId: 1, clienteID: 101, nombre: 'Refaccionaria Uno', fechaAlta: '2024-01-15', statusCredito: 'Al corriente' },
    { clienteVendedorId: 2, clienteID: 102, nombre: 'Autopartes Dos', fechaAlta: '2023-03-20', statusCredito: 'Vencido' },
];

const onRedirect = jest.fn();

const columns: GridColDef[] = [
    { headerName: 'ID', field: 'clienteID', minWidth: 60 },
    { headerName: 'Nombre empresa', field: 'nombre', minWidth: 220 },
    {
        headerName: 'Alta',
        field: 'fechaAlta',
        type: 'number',
        // valueGetter (firma v7 value-first) -> timestamp; renderCell -> formato dd/MM/yyyy
        valueGetter: (value: string) => new Date(value).getFullYear(),
        renderCell: (params) => <span data-testid="alta-cell">Año {String(params.value)}</span>,
    },
    {
        headerName: 'Estatus Crédito',
        field: 'statusCredito',
        renderCell: (params) => <span data-testid="status-cell">{params.value}</span>,
    },
    {
        headerName: '',
        field: 'actions',
        type: 'actions',
        renderCell: (params) => (
            <GridActionsCellItem
                label="Redirigir"
                icon={<span>→</span>}
                onClick={() => onRedirect(params.row.clienteVendedorId)}
            />
        ),
    },
];

const getRowId = (row: IRowFixture) => row.clienteVendedorId;

const baseProps = {
    rows,
    columns,
    getRowId,
    rowCount: 25,
    paginationModel: { page: 0, pageSize: 10 },
    onPaginationModelChange: jest.fn(),
};

const setMobile = () =>
    mockDimensions.mockReturnValue({ width: 375, height: 800, isMobile: true, isTablet: false, isDesktop: false, isMobileAndTablet: true, isMobileExperience: true });
const setDesktop = () =>
    mockDimensions.mockReturnValue({ width: 1280, height: 800, isMobile: false, isTablet: false, isDesktop: true, isMobileAndTablet: false, isMobileExperience: false });

afterEach(() => jest.clearAllMocks());

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('AdaptiveDataGrid - branching', () => {
    // El grid se carga con next/dynamic para que el chunk de @mui/x-data-grid no
    // viaje al teléfono, que nunca lo renderiza: por eso la espera.
    it('renders the DataGrid (passthrough) on the desktop experience', async () => {
        setDesktop();
        render(<AdaptiveDataGrid {...baseProps} />);
        expect(await screen.findByTestId('desktop-grid')).toBeInTheDocument();
        // No cards
        expect(screen.queryByText('Nombre empresa')).not.toBeInTheDocument();
    });

    it('renders cards on the mobile experience', () => {
        setMobile();
        render(<AdaptiveDataGrid {...baseProps} cardOptions={{ titleField: 'nombre' }} />);
        expect(screen.queryByTestId('desktop-grid')).not.toBeInTheDocument();
        // Título por fila
        expect(screen.getByText('Refaccionaria Uno')).toBeInTheDocument();
        expect(screen.getByText('Autopartes Dos')).toBeInTheDocument();
        // headerName usado como label del cuerpo
        expect(screen.getAllByText('Estatus Crédito').length).toBe(2);
    });
});

describe('AdaptiveDataGrid - reutilización de renderCell/valueGetter en cards', () => {
    it('reuses renderCell for formatted/derived columns (fecha y estatus)', () => {
        setMobile();
        render(<AdaptiveDataGrid {...baseProps} cardOptions={{ titleField: 'nombre' }} />);
        // valueGetter aplicado (año) y renderCell usado
        expect(screen.getByText('Año 2024')).toBeInTheDocument();
        expect(screen.getByText('Año 2023')).toBeInTheDocument();
        // renderCell del estatus reutilizado
        const statuses = screen.getAllByTestId('status-cell').map((el) => el.textContent);
        expect(statuses).toEqual(expect.arrayContaining(['Al corriente', 'Vencido']));
    });

    it('renders row actions (GridActionsCellItem) standalone and fires its onClick', () => {
        setMobile();
        render(<AdaptiveDataGrid {...baseProps} cardOptions={{ titleField: 'nombre' }} />);
        const buttons = screen.getAllByRole('button', { name: 'Redirigir' });
        expect(buttons.length).toBe(2);
        fireEvent.click(buttons[0]);
        expect(onRedirect).toHaveBeenCalledWith(1);
    });
});

describe('AdaptiveDataGrid - columnas de control sin encabezado', () => {
    // Reproduce la columna real de Configuración -> Roles: sin headerName, sin
    // type 'actions', con los controles dentro de renderCell. La card la descartaba
    // entera porque solo mostraba columnas con headerName, y la pantalla se quedaba
    // en móvil sin editar ni activar/desactivar.
    const onEdit = jest.fn();
    const onToggle = jest.fn();

    const columnsWithControls: GridColDef[] = [
        { headerName: 'Id', field: 'clienteID', width: 80 },
        { headerName: 'Nombre de Rol', field: 'nombre', flex: 1 },
        {
            headerName: '',
            field: 'active',
            sortable: false,
            renderCell: ({ row }) => (
                <>
                    <button aria-label="Editar" onClick={() => onEdit(row.clienteVendedorId)} />
                    <input
                        type="checkbox"
                        aria-label="Activo"
                        checked={row.clienteVendedorId === 1}
                        onChange={() => onToggle(row.clienteVendedorId)}
                    />
                </>
            ),
        },
    ];

    it('renderiza los controles de una columna sin encabezado', () => {
        setMobile();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                columns={columnsWithControls}
                cardOptions={{ titleField: 'nombre' }}
            />,
        );

        expect(screen.getAllByRole('button', { name: 'Editar' })).toHaveLength(2);
        expect(screen.getAllByRole('checkbox', { name: 'Activo' })).toHaveLength(2);
    });

    it('conserva el handler y la fila correcta al tocarlos', () => {
        setMobile();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                columns={columnsWithControls}
                cardOptions={{ titleField: 'nombre' }}
            />,
        );

        fireEvent.click(screen.getAllByRole('button', { name: 'Editar' })[1]);
        expect(onEdit).toHaveBeenCalledWith(2);

        fireEvent.click(screen.getAllByRole('checkbox', { name: 'Activo' })[0]);
        expect(onToggle).toHaveBeenCalledWith(1);
    });

    it('no la duplica en el cuerpo de la card', () => {
        setMobile();
        const { container } = render(
            <AdaptiveDataGrid
                {...baseProps}
                columns={columnsWithControls}
                cardOptions={{ titleField: 'nombre' }}
            />,
        );

        // Dos filas, un control por fila: si además se pintara como campo del
        // cuerpo habría cuatro.
        expect(container.querySelectorAll('[aria-label="Editar"]')).toHaveLength(2);
    });

    it('no altera la vista de escritorio', () => {
        setDesktop();
        render(<AdaptiveDataGrid {...baseProps} columns={columnsWithControls} />);

        expect(screen.getByTestId('desktop-grid')).toBeInTheDocument();
        expect(screen.queryByRole('button', { name: 'Editar' })).not.toBeInTheDocument();
    });
});

describe('AdaptiveDataGrid - selección por checkbox (paridad)', () => {
    it('shows an indeterminate select-all when a subset is selected', () => {
        setMobile();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                cardOptions={{ titleField: 'nombre' }}
                checkboxSelected
                handleCheckboxChange={jest.fn()}
                selectedRows={[rows[0]]}
                isChecked={(row) => row.clienteVendedorId === 1}
            />,
        );
        const selectAll = screen.getByRole('checkbox', { name: /seleccionar todo/i });
        expect(selectAll).toBeInTheDocument();
        // 1 de 2 seleccionadas => indeterminate
        expect(selectAll).toHaveAttribute('data-indeterminate', 'true');
    });

    it('calls handleCheckboxChange with null when toggling select-all', () => {
        setMobile();
        const handleCheckboxChange = jest.fn();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                cardOptions={{ titleField: 'nombre' }}
                checkboxSelected
                handleCheckboxChange={handleCheckboxChange}
                selectedRows={[]}
                isChecked={() => false}
            />,
        );
        fireEvent.click(screen.getByRole('checkbox', { name: /seleccionar todo/i }));
        expect(handleCheckboxChange).toHaveBeenCalledWith(expect.anything(), null);
    });
});

describe('AdaptiveDataGrid - paginación server', () => {
    it('emits onPaginationModelChange with the same contract on page change', () => {
        setMobile();
        const onPaginationModelChange = jest.fn();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                onPaginationModelChange={onPaginationModelChange}
                cardOptions={{ titleField: 'nombre' }}
            />,
        );
        // Botón "página siguiente" de TablePagination
        fireEvent.click(screen.getByRole('button', { name: /next page|siguiente/i }));
        expect(onPaginationModelChange).toHaveBeenCalledWith(
            { page: 1, pageSize: 10 },
            expect.anything(),
        );
    });
});

describe('AdaptiveDataGrid - estados y overrides', () => {
    it('respects the screen noRowsOverlay when there are no rows', () => {
        setMobile();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                rows={[]}
                slots={{ noRowsOverlay: () => <div data-testid="custom-overlay">Sin búsqueda</div> }}
                cardOptions={{ titleField: 'nombre' }}
            />,
        );
        expect(screen.getByTestId('custom-overlay')).toBeInTheDocument();
    });

    it('uses a custom renderCard when provided', () => {
        setMobile();
        render(
            <AdaptiveDataGrid
                {...baseProps}
                cardOptions={{
                    renderCard: (row: IRowFixture) => <div data-testid="custom-card">Custom: {row.nombre}</div>,
                }}
            />,
        );
        const cards = screen.getAllByTestId('custom-card');
        expect(cards.length).toBe(2);
        expect(within(cards[0]).getByText(/Custom: Refaccionaria Uno/)).toBeInTheDocument();
    });
});

describe('AdaptiveDataGrid - footer y paginación local', () => {
    it('hides the pagination footer when hideFooter is set', () => {
        setMobile();
        render(<AdaptiveDataGrid {...baseProps} hideFooter cardOptions={{ titleField: 'nombre' }} />);
        // Sin barra de paginación (equivale a `hideFooter` del DataGrid)
        expect(screen.queryByRole('button', { name: /next page|siguiente/i })).not.toBeInTheDocument();
        // Pero las cards siguen presentes
        expect(screen.getByText('Refaccionaria Uno')).toBeInTheDocument();
    });

    it('paginates locally in uncontrolled client mode', () => {
        setMobile();
        const manyRows: IRowFixture[] = Array.from({ length: 12 }, (_, index) => ({
            clienteVendedorId: index + 1,
            clienteID: 100 + index,
            nombre: `Cliente ${index + 1}`,
            fechaAlta: '2024-01-01',
            statusCredito: 'Al corriente',
        }));
        render(
            <AdaptiveDataGrid
                rows={manyRows}
                columns={columns}
                getRowId={getRowId}
                paginationMode="client"
                cardOptions={{ titleField: 'nombre' }}
            />,
        );
        // Primera página con el tamaño por defecto (10)
        expect(screen.getByText('Cliente 1')).toBeInTheDocument();
        expect(screen.getByText('Cliente 10')).toBeInTheDocument();
        expect(screen.queryByText('Cliente 11')).not.toBeInTheDocument();
        // Avanza de página localmente, sin onPaginationModelChange
        fireEvent.click(screen.getByRole('button', { name: /next page|siguiente/i }));
        expect(screen.getByText('Cliente 11')).toBeInTheDocument();
        expect(screen.getByText('Cliente 12')).toBeInTheDocument();
        expect(screen.queryByText('Cliente 1')).not.toBeInTheDocument();
    });
});
