import React from 'react';
import { render, screen } from '@testing-library/react';
import { InputSearch } from '@/features/common/infrastructure/ui/inputs/InputSearch';

/**
 * `InputSearch` es el buscador de nueve pantallas de filtros. Varias de ellas
 * descartan todo lo que no sea dígito en su `onChange` (Listado de pedidos del
 * cliente, Solicitudes de cancelación, Historial del plan de lealtad, Garantías).
 * Sin `inputMode` el móvil abre el teclado alfabético sobre esos campos: el usuario
 * escribe y no aparece nada, sin mensaje, y el campo se lee como roto.
 */
describe('InputSearch', () => {
    const getInput = () => screen.getByRole('textbox') as HTMLInputElement;

    it('abre el teclado numérico cuando la búsqueda solo admite dígitos', () => {
        render(<InputSearch value="" inputMode="numeric" />);

        expect(getInput()).toHaveAttribute('inputmode', 'numeric');
    });

    it('no fuerza teclado cuando la búsqueda admite texto', () => {
        render(<InputSearch value="" inputMode="text" />);

        expect(getInput()).not.toHaveAttribute('inputmode', 'numeric');
    });

    it('no fuerza teclado por omisión: las búsquedas mixtas no se ven afectadas', () => {
        render(<InputSearch value="" />);

        expect(getInput()).not.toHaveAttribute('inputmode', 'numeric');
    });

    it('conserva el resto del contrato al declarar el teclado', () => {
        render(
            <InputSearch
                value="626291"
                placeholder="Buscar por ID de factura"
                inputMode="numeric"
                helperText="Máximo 9 caracteres"
                error
            />,
        );

        expect(getInput().value).toBe('626291');
        expect(screen.getByPlaceholderText('Buscar por ID de factura')).toBeInTheDocument();
        expect(screen.getByText('Máximo 9 caracteres')).toBeInTheDocument();
    });
});
