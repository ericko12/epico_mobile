import { appliesPromotionPrice } from "@/features/common/infrastructure/ui/accordion/accordionDetail/accordionDetail.pricing";
import { PromotionTypesEnum } from "@/features/promotions/domain/enums/PromotionTypesEnum";
import { IOrderSummaryDetail } from "@/features/checkout/domain/interfaces/IOrderSummaryDetail";

/**
 * Renglón mínimo del detalle; cada caso sobrescribe lo que le interesa.
 *
 * @param {Partial<IOrderSummaryDetail>} overrides - Campos del caso.
 * @returns {IOrderSummaryDetail} El renglón.
 */
const buildRow = (overrides: Partial<IOrderSummaryDetail>): IOrderSummaryDetail =>
    ({ promocionID: 0, precio: 100, precioLista: 120, cantidad: 1, ahorroPorcentaje: 0, ...overrides }) as IOrderSummaryDetail;

/**
 * Esta regla decide si el precio de lista se tacha y si se pinta el precio de
 * promoción, y la usan LAS DOS vistas: la tabla de escritorio y la tarjeta de
 * móvil. El test existe para que no puedan divergir — un artículo no puede salir
 * con promoción en el teléfono y sin ella en la computadora.
 */
describe("appliesPromotionPrice", () => {
    it("no aplica cuando el renglón no trae promoción", () => {
        expect(appliesPromotionPrice(buildRow({ promocionID: 0 }))).toBe(false);
    });

    it("aplica cuando la promoción del renglón está en la lista", () => {
        const row = buildRow({
            promocionID: 7,
            promociones: [{ id: 7, tipoPromocionId: PromotionTypesEnum.Revista }],
        });

        expect(appliesPromotionPrice(row)).toBe(true);
    });

    it("aplica al paquete por escalas, el tipo que llegó con el release 3.30.0", () => {
        const row = buildRow({
            promocionID: 12,
            promociones: [{ id: 12, tipoPromocionId: PromotionTypesEnum.PaquetePorEscala }],
        });

        expect(appliesPromotionPrice(row)).toBe(true);
    });

    it("no aplica cuando la promoción no es de un tipo con precio promocional", () => {
        const row = buildRow({
            promocionID: 7,
            promociones: [{ id: 7, tipoPromocionId: PromotionTypesEnum.GratisCantidad }],
        });

        expect(appliesPromotionPrice(row)).toBe(false);
    });

    it("aplica igual si el artículo es gratis aunque la promoción no esté en la lista", () => {
        const row = buildRow({
            promocionID: 7,
            gratis: true,
            promociones: [{ id: 99, tipoPromocionId: PromotionTypesEnum.Paquete }],
        });

        expect(appliesPromotionPrice(row)).toBe(true);
    });

    // Rareza de la regla original que se conserva a propósito: sin lista de
    // promociones lo que se evalúa es un objeto vacío, que es verdadero.
    it("aplica cuando el renglón tiene promoción y no trae lista de promociones", () => {
        expect(appliesPromotionPrice(buildRow({ promocionID: 7, promociones: undefined }))).toBe(true);
    });
});
