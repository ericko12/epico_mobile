import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { AutocompleteLabel } from '@/features/common/infrastructure/ui/select/autocompleteLabel/AutocompleteLabel';

interface IOption {
    label: string;
    value: number;
}

const mockOptions: IOption[] = [
    { label: 'Jalisco', value: 1 },
    { label: 'Nuevo León', value: 2 },
    { label: 'CDMX', value: 3 },
];

describe('AutocompleteLabel', () => {
    it('renders the label when provided', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
            />
        );

        expect(screen.getByText('Estado')).toBeInTheDocument();
    });

    it('does not render the label section when label is omitted', () => {
        render(
            <AutocompleteLabel<IOption>
                name="stateId"
                options={mockOptions}
                value={null}
            />
        );

        expect(screen.queryByRole('label')).not.toBeInTheDocument();
    });

    it('renders the required indicator (*) when required is true', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                required
                options={mockOptions}
                value={null}
            />
        );

        expect(screen.getByText('*')).toBeInTheDocument();
    });

    it('does not render the required indicator when required is false', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
            />
        );

        expect(screen.queryByText('*')).not.toBeInTheDocument();
    });

    it('renders the placeholder text', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                placeholder="Selecciona estado"
                options={mockOptions}
                value={null}
            />
        );

        expect(screen.getByPlaceholderText('Selecciona estado')).toBeInTheDocument();
    });

    it('renders the selected value', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={mockOptions[0]}
                isOptionEqualToValue={(o, v) => o.value === v.value}
            />
        );

        expect(screen.getByDisplayValue('Jalisco')).toBeInTheDocument();
    });

    it('shows the error message when error and errorMessage are provided', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
                error
                errorMessage="El estado es requerido"
            />
        );

        expect(screen.getByText('El estado es requerido')).toBeInTheDocument();
    });

    it('does not show the error message when error is false', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
                error={false}
                errorMessage="El estado es requerido"
            />
        );

        expect(screen.queryByText('El estado es requerido')).not.toBeInTheDocument();
    });

    it('shows options in dropdown when user types', async () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
                isOptionEqualToValue={(o, v) => o.value === v.value}
            />
        );

        const input = screen.getByRole('combobox');
        fireEvent.change(input, { target: { value: 'Jal' } });

        expect(await screen.findByRole('option', { name: 'Jalisco' })).toBeInTheDocument();
    });

    it('calls onChange when an option is selected', async () => {
        const mockOnChange = jest.fn();

        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
                onChange={mockOnChange}
                isOptionEqualToValue={(o, v) => o.value === v.value}
            />
        );

        const input = screen.getByRole('combobox');
        fireEvent.change(input, { target: { value: 'Jalisco' } });

        const option = await screen.findByRole('option', { name: 'Jalisco' });
        fireEvent.click(option);

        expect(mockOnChange).toHaveBeenCalledWith(
            expect.anything(),
            { label: 'Jalisco', value: 1 },
            'selectOption',
            expect.anything()
        );
    });

    it('uses custom noOptionsText when provided', async () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={[]}
                value={null}
                noOptionsText="No hay estados disponibles"
            />
        );

        const input = screen.getByRole('combobox');
        fireEvent.focus(input);
        fireEvent.change(input, { target: { value: 'a' } });

        expect(await screen.findByText('No hay estados disponibles')).toBeInTheDocument();
    });

    it('renders as disabled when disabled is true', () => {
        render(
            <AutocompleteLabel<IOption>
                label="Estado"
                name="stateId"
                options={mockOptions}
                value={null}
                disabled
            />
        );

        expect(screen.getByRole('combobox')).toBeDisabled();
    });
});
