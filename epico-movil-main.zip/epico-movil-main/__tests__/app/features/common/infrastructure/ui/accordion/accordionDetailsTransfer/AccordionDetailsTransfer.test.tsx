import React, { ReactNode } from 'react';
import { render, screen, within } from '@testing-library/react';
import { GridColDef } from '@mui/x-data-grid';
import { AccordionDetailsTransfer } from '@/features/common/infrastructure/ui/accordion/accordionDetailsTransfer/AccordionDetailsTransfer';
import {
    getTransferItemCardDetails,
    getTransferItemsColumns,
    TransferItemRow,
} from '@/features/common/infrastructure/ui/accordion/accordionDetailsTransfer/AccordionDetailsTransfer.data';
import { IBranchOption } from '@/features/shipment/domain/interfaces/evaluatorSMC4/IBranchOption';
import { IBranchTransferNode } from '@/features/shipment/domain/interfaces/evaluatorSMC4/IBranchTransferNode';
import { ShippingMethodSMC4Enum } from '@/features/shipment/domain/enum/ShippingMethodSMC4Enum';
import { NOTIFICATIONS_CHECKOUT } from '@/features/checkout/infrastructure/utils/messages/NotificationsCheckout';

/**
 * Acordeón de traspasos (componente del proyecto original, 3.35.0).
 *
 * En escritorio cada sucursal pinta una tabla; en la experiencia móvil (<900px) la
 * tabla pasa a una tarjeta por artículo. Este archivo fija dos cosas:
 *
 * - Que la rama móvil no pierde ningún dato: las tarjetas salen de las mismas
 *   columnas filtradas que el grid, con las mismas banderas.
 * - Que escritorio sigue siendo el grid del original, con su sangría.
 */

// ─── Mocks ───────────────────────────────────────────────────────────────────

const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

// El grid de terceros se sustituye por un centinela que expone las columnas que recibe.
jest.mock('@/features/common/infrastructure/ui/tables/DataGridServerPagination', () => ({
    DataGridServerPagination: ({ columns, rows }: { columns: GridColDef[]; rows: unknown[] }) => (
        <div
            data-testid="desktop-grid"
            data-fields={columns.map((column) => column.field).join(',')}
            data-rows={rows.length}
        />
    ),
}));

const setMobile = (isMobileExperience: boolean) => {
    mockDimensions.mockReturnValue({ isMobileExperience, width: isMobileExperience ? 320 : 1280 });
};

// ─── Fixtures ────────────────────────────────────────────────────────────────

const article = (overrides: Partial<TransferItemRow>): TransferItemRow => ({
    productoId: 1,
    sku: '0000000',
    cantidad: 1,
    gratis: false,
    precio: 10,
    promocionId: null,
    tipoPromocionId: 0,
    existencias: 0,
    descripcion: 'ARTICULO',
    tieneToken: false,
    cantidadOriginal: 1,
    cantidadPrecioEspecial: 0,
    cantidadTraspasos: 0,
    ...overrides,
});

const node = (overrides: Partial<IBranchTransferNode>): IBranchTransferNode => ({
    option: 1,
    infoSucursalId: 1,
    metodoEnvio: ShippingMethodSMC4Enum.Delivery,
    articulos: [],
    requiereTraspaso: true,
    concentrarPedido: false,
    esTransitorio: false,
    sucursal: 'SUCURSAL',
    pickup: false,
    traspasos: [],
    ...overrides,
});

/** Sucursal que completa a la consolidadora foránea. */
const apoyo = node({
    infoSucursalId: 30,
    sucursal: 'SUCURSAL APOYO SUR',
    articulos: [article({ productoId: 3, sku: '3000000', descripcion: 'BALATA DELANTERA', cantidad: 1, existencias: 9, cantidadTraspasos: 7 })],
});

const local = node({
    infoSucursalId: 10,
    sucursal: 'SUCURSAL LOCAL NORTE',
    articulos: [article({ productoId: 1, sku: '1394000', descripcion: 'CINTA AISLANTE NEGRO 60 PIES PLASTICA', cantidad: 2, existencias: 5, cantidadTraspasos: 6 })],
});

const foranea = node({
    infoSucursalId: 20,
    sucursal: 'CEDIS FORANEO',
    concentrarPedido: true,
    articulos: [article({ productoId: 2, sku: '2000000', descripcion: 'FILTRO DE ACEITE', cantidad: 3, existencias: 1, cantidadTraspasos: 4 })],
    traspasos: [apoyo],
});

const transferBranch = {
    ...node({ infoSucursalId: 1, sucursal: 'SUCURSAL PRINCIPAL' }),
    traspasos: [local, foranea],
} as IBranchOption;

const renderTransfer = (hideStockColumn?: boolean) =>
    render(<AccordionDetailsTransfer transferBranch={transferBranch} hideStockColumn={hideStockColumn} />);

/** Tarjetas de la sucursal cuya cabecera tiene `sucursal` como nombre. */
const cardsOf = (sucursal: string): HTMLElement => {
    const header = screen.getAllByText(sucursal)[0];
    const accordion = header.closest('.MuiAccordion-root') as HTMLElement;
    return within(accordion).getAllByTestId('transfer-items-cards')[0];
};

// ─── Tests ───────────────────────────────────────────────────────────────────

describe('AccordionDetailsTransfer', () => {
    afterEach(() => mockDimensions.mockReset());

    it('no pinta nada si la sucursal no trae traspasos', () => {
        setMobile(true);
        const { container } = render(
            <AccordionDetailsTransfer transferBranch={{ ...transferBranch, traspasos: [] }} />,
        );
        expect(container).toBeEmptyDOMElement();
    });

    describe('móvil (<900px)', () => {
        beforeEach(() => setMobile(true));

        it('pinta tarjetas en lugar de la tabla, una por artículo y sucursal', () => {
            renderTransfer();

            expect(screen.queryByTestId('desktop-grid')).not.toBeInTheDocument();
            expect(screen.getAllByTestId('transfer-items-cards')).toHaveLength(3);
            expect(screen.getByText('CINTA AISLANTE NEGRO 60 PIES PLASTICA')).toBeInTheDocument();
            expect(screen.getByText('FILTRO DE ACEITE')).toBeInTheDocument();
            expect(screen.getByText('BALATA DELANTERA')).toBeInTheDocument();
            expect(screen.getByText('1394000')).toBeInTheDocument();
            expect(screen.getByText('×2')).toBeInTheDocument();
            expect(screen.getByText('×3')).toBeInTheDocument();
            expect(screen.getByText('×1')).toBeInTheDocument();
        });

        it('conserva la jerarquía: secciones, flecha hacia la sucursal padre, chip y total', () => {
            renderTransfer();

            expect(screen.getByText('TRASPASOS LOCALES')).toBeInTheDocument();
            expect(screen.getByText('TRASPASOS FORÁNEOS')).toBeInTheDocument();
            expect(screen.getByText('SE COMPLETA CON TRASPASOS')).toBeInTheDocument();
            // La consolidadora aparece como sucursal propia y como padre de la que la completa.
            expect(screen.getAllByText('CEDIS FORANEO')).toHaveLength(2);
            expect(screen.getByText('→')).toBeInTheDocument();
            expect(screen.getByText(NOTIFICATIONS_CHECKOUT.MINI_CHECKOUT_TRASPASOS.FOREIGN_CONSOLIDATOR)).toBeInTheDocument();
            expect(screen.getByText('(3 ARTÍCULOS A TRASPASAR)')).toBeInTheDocument();
        });

        it('muestra la existencia salvo con hideStockColumn, igual que la columna', () => {
            const { unmount } = renderTransfer();
            expect(within(cardsOf('SUCURSAL LOCAL NORTE')).getByText('Existencia: 5')).toBeInTheDocument();
            unmount();

            renderTransfer(true);
            expect(screen.queryByText(/Existencia:/)).not.toBeInTheDocument();
        });

        it('"Por recibir en traspasos" solo en la consolidadora foránea y nunca con hideStockColumn', () => {
            const { unmount } = renderTransfer();

            const foreignCards = cardsOf('CEDIS FORANEO');
            expect(within(foreignCards).getByText('Por recibir en traspasos')).toBeInTheDocument();
            expect(within(foreignCards).getByText('4')).toBeInTheDocument();
            expect(within(cardsOf('SUCURSAL LOCAL NORTE')).queryByText('Por recibir en traspasos')).not.toBeInTheDocument();
            expect(within(cardsOf('SUCURSAL APOYO SUR')).queryByText('Por recibir en traspasos')).not.toBeInTheDocument();
            unmount();

            renderTransfer(true);
            expect(screen.queryByText('Por recibir en traspasos')).not.toBeInTheDocument();
        });

        it('baja la sangría de cada nivel (en escritorio son 56px por nivel)', () => {
            renderTransfer();

            const section = screen.getByText('TRASPASOS LOCALES').closest('section') as HTMLElement;
            expect(section).toHaveStyle({ marginLeft: '0px', paddingLeft: '10px' });
        });
    });

    describe('escritorio (>=900px)', () => {
        beforeEach(() => setMobile(false));

        it('conserva el grid del original con las columnas de cada sucursal', () => {
            renderTransfer();

            expect(screen.queryByTestId('transfer-items-cards')).not.toBeInTheDocument();
            const grids = screen.getAllByTestId('desktop-grid');
            expect(grids).toHaveLength(3);
            const fields = grids.map((grid) => grid.getAttribute('data-fields'));
            expect(fields).toContain('sku,descripcion,existencias,cantidad');
            expect(fields).toContain('sku,descripcion,existencias,cantidad,cantidadTraspasos');
        });

        it('conserva la sangría de escritorio', () => {
            renderTransfer();

            const section = screen.getByText('TRASPASOS LOCALES').closest('section') as HTMLElement;
            expect(section).toHaveStyle({ marginLeft: '35px', paddingLeft: '20px' });
        });
    });
});

describe('paridad tabla/tarjeta — artículos de traspaso', () => {
    /** Evalúa el `renderCell` de una columna fuera del DataGrid. */
    const renderColumn = (columns: GridColDef<TransferItemRow>[], field: string, row: TransferItemRow): ReactNode => {
        const column = columns.find((c) => c.field === field);
        if (!column) throw new Error(`No existe la columna '${field}'`);
        if (typeof column.renderCell !== 'function') return String(row[field as keyof TransferItemRow]);
        return column.renderCell({ row, value: row[field as keyof TransferItemRow], field } as never);
    };

    const SLOT_HEADERS = ['Código', 'Descripción', 'Existencia', 'Cantidad a traspasar'];

    it.each([-1, 0, 4])('"Por recibir en traspasos" = %p se pinta igual en tabla y tarjeta', (cantidadTraspasos) => {
        const row = article({ cantidadTraspasos });
        const columns = getTransferItemsColumns(false, false);

        const { container: table } = render(<>{renderColumn(columns, 'cantidadTraspasos', row)}</>);
        const detail = getTransferItemCardDetails(row, columns).find((d) => d.label === 'Por recibir en traspasos');

        expect(detail).toBeDefined();
        expect(String(detail?.value)).toBe(table.textContent);
    });

    it.each([
        [false, false],
        [true, false],
        [false, true],
        [true, true],
    ])('toda columna visible (hideStock=%p, hideTransfers=%p) tiene sitio en la tarjeta', (hideStock, hideTransfers) => {
        const columns = getTransferItemsColumns(hideStock, hideTransfers);
        const detailLabels = getTransferItemCardDetails(article({}), columns).map((d) => d.label);

        // Con dos cantidades a la vista, la de traspasar también va al pie con su
        // nombre: la píldora ×N a secas se confundiría con la del pedido.
        const twoQuantities = columns.some((c) => c.field === 'cantidadTraspasos');
        const expected = columns
            .map((c) => c.headerName)
            .filter((h) => !SLOT_HEADERS.includes(h ?? '') || (twoQuantities && h === 'Cantidad a traspasar'));
        expect(detailLabels).toEqual(expected);
    });

    it('"Cantidad a traspasar" lleva etiqueta solo cuando convive con "Por recibir"', () => {
        const conDos = getTransferItemCardDetails(article({ cantidad: 3 }), getTransferItemsColumns(false, false));
        const conUna = getTransferItemCardDetails(article({ cantidad: 3 }), getTransferItemsColumns(false, true));

        expect(conDos.find((d) => d.label === 'Cantidad a traspasar')?.value).toBe('3');
        expect(conUna.find((d) => d.label === 'Cantidad a traspasar')).toBeUndefined();
    });

    it('una columna nueva de escritorio llega sola al pie de la tarjeta', () => {
        const columns: GridColDef<TransferItemRow>[] = [
            ...getTransferItemsColumns(true, true),
            { field: 'precio', headerName: 'Precio' },
        ];

        expect(getTransferItemCardDetails(article({ precio: 25 }), columns)).toEqual([{ label: 'Precio', value: '25' }]);
    });
});
