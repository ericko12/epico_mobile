import {
    CARD_BREAKPOINTS,
    DEFAULT_SLIDES,
    THUMBNAIL_BREAKPOINTS,
    resolveSlidesToShow,
} from '@/features/common/infrastructure/ui/slider/SliderSection/SliderSection.breakpoints';

/**
 * Reparto de elementos visibles del carrusel. Con tres tarjetas de producto en
 * 360px cada una quedaba en ~120px: la descripción se partía a media palabra, el
 * contador se salía y el botón "Agregar a pedido" envolvía.
 */
describe('resolveSlidesToShow — tarjetas de producto', () => {
    it('muestra una sola tarjeta en teléfono', () => {
        expect(resolveSlidesToShow(360)).toBe(1);
        expect(resolveSlidesToShow(480)).toBe(1);
    });

    it('muestra dos en teléfono grande', () => {
        expect(resolveSlidesToShow(481)).toBe(2);
        expect(resolveSlidesToShow(790)).toBe(2);
    });

    it('muestra tres en tablet chica, que sigue siendo experiencia móvil', () => {
        expect(resolveSlidesToShow(791)).toBe(3);
        expect(resolveSlidesToShow(899)).toBe(3);
    });

    it('no altera el escritorio: desde 900px el reparto es el de siempre', () => {
        expect(resolveSlidesToShow(900)).toBe(5);
        expect(resolveSlidesToShow(1024)).toBe(5);
        expect(resolveSlidesToShow(1440)).toBe(DEFAULT_SLIDES);
    });

    it('trata el ancho 0 de SSR como el caso más estrecho', () => {
        expect(resolveSlidesToShow(0)).toBe(1);
    });
});

describe('resolveSlidesToShow — miniaturas de la galería', () => {
    it('conserva el reparto anterior: son pequeñas y caben varias', () => {
        expect(resolveSlidesToShow(360, THUMBNAIL_BREAKPOINTS)).toBe(3);
        expect(resolveSlidesToShow(600, THUMBNAIL_BREAKPOINTS)).toBe(4);
        expect(resolveSlidesToShow(1000, THUMBNAIL_BREAKPOINTS)).toBe(5);
        expect(resolveSlidesToShow(1440, THUMBNAIL_BREAKPOINTS)).toBe(DEFAULT_SLIDES);
    });

    it('en teléfono muestra más miniaturas que tarjetas', () => {
        expect(resolveSlidesToShow(360, THUMBNAIL_BREAKPOINTS))
            .toBeGreaterThan(resolveSlidesToShow(360, CARD_BREAKPOINTS));
    });
});

describe('tablas de breakpoints', () => {
    it('las tarjetas crecen de forma monótona con el ancho', () => {
        const slides = [...CARD_BREAKPOINTS]
            .sort((a, b) => a.breakpoint - b.breakpoint)
            .map((entry) => entry.slides);

        expect(slides).toEqual([...slides].sort((a, b) => a - b));
        expect(slides[slides.length - 1]).toBeLessThanOrEqual(DEFAULT_SLIDES);
    });
});
