import { useState } from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { Counter } from '@/features/common/infrastructure/ui/counter/Counter';

// El manejo del campo que fijan estos tests es el de móvil (<900px). Escritorio conserva el
// del original: se prueba aparte, al final, con `isMobileExperience` en false.
const mockDimensions = jest.fn(() => ({ isMobileExperience: true }));
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

/**
 * `Counter` es el contador de cantidad del detalle de la caja (tabla y tarjeta),
 * de "transferir caja", de código de producto y de crear garantía. En el teléfono se
 * reportaron dos cosas: abría el teclado alfanumérico, y en el detalle de la caja
 * —donde `min` es 1— el 1 no se podía quitar, así que solo se podían teclear cantidades
 * que lo contuvieran. Estos tests fijan ese contrato.
 */
describe('Counter', () => {
    beforeEach(() => {
        mockDimensions.mockReturnValue({ isMobileExperience: true });
    });

    /** El valor lo controla quien lo usa, así que las pruebas van con un anfitrión. */
    const Anfitrion = ({ inicial = 1, min = 1, max = 99999 }: { inicial?: number; min?: number; max?: number }) => {
        const [cantidad, setCantidad] = useState(inicial);
        return (
            <>
                <Counter count={cantidad} min={min} max={max} handleChangeCount={setCantidad} />
                <span data-testid="valor">{cantidad}</span>
            </>
        );
    };

    const setup = (props?: { inicial?: number; min?: number; max?: number }) => {
        render(<Anfitrion {...props} />);
        return {
            input: screen.getByRole('textbox') as HTMLInputElement,
            valor: () => screen.getByTestId('valor').textContent,
        };
    };

    it('declara el teclado numérico', () => {
        const { input } = setup();
        expect(input).toHaveAttribute('inputMode', 'numeric');
    });

    it('se puede vaciar el campo sin que vuelva el mínimo', () => {
        const { input, valor } = setup();

        fireEvent.change(input, { target: { value: '' } });

        expect(input.value).toBe('');
        // El valor de la caja no se toca mientras se edita.
        expect(valor()).toBe('1');
    });

    it('escribir después de vaciar da el número tecleado, no el 1 pegado', () => {
        const { input, valor } = setup();

        fireEvent.change(input, { target: { value: '' } });
        fireEvent.change(input, { target: { value: '5' } });

        expect(input.value).toBe('5');
        expect(valor()).toBe('5');
    });

    it('salir del campo vacío lo devuelve al mínimo', () => {
        const { input, valor } = setup({ inicial: 4, min: 1 });

        fireEvent.change(input, { target: { value: '' } });
        fireEvent.blur(input);

        expect(input.value).toBe('1');
        expect(valor()).toBe('1');
    });

    it('descarta lo que no es dígito', () => {
        const { input, valor } = setup();

        fireEvent.change(input, { target: { value: '2a4' } });

        expect(input.value).toBe('24');
        expect(valor()).toBe('24');
    });

    it('no pasa del máximo', () => {
        const { input, valor } = setup({ inicial: 1, min: 1, max: 10 });

        fireEvent.change(input, { target: { value: '99' } });

        expect(input.value).toBe('10');
        expect(valor()).toBe('10');
    });

    it('los botones + y - siguen moviendo el valor', () => {
        const { input, valor } = setup({ inicial: 2, min: 1 });

        fireEvent.click(screen.getByLabelText('increase'));
        expect(valor()).toBe('3');
        expect(input.value).toBe('3');

        fireEvent.click(screen.getByLabelText('reduce'));
        expect(valor()).toBe('2');
        expect(input.value).toBe('2');
    });

    /**
     * Desde la 8ª sincronización el botón de aumento dejó de ir `disabled` —igual que ya
     * pasaba con el de disminuir— para que su tooltip funcione: queda con `aria-disabled`,
     * fuera del orden de tabulación y sin efecto al tocarlo. Los dos botones tienen que
     * seguir siendo gemelos: mismo bloqueo y mismo piso táctil de 44px en la tarjeta.
     */
    describe('los dos botones son gemelos', () => {
        it('el aumento bloqueado no sube el valor y se marca igual que la disminución bloqueada', () => {
            const onChange = jest.fn();
            render(<Counter count={5} min={0} max={10} disabledIncrease disabledDecrease handleChangeCount={onChange} />);

            const aumento = screen.getByLabelText('increase');
            const disminucion = screen.getByLabelText('reduce');

            fireEvent.click(aumento);
            fireEvent.click(disminucion);

            expect(onChange).not.toHaveBeenCalled();
            for (const boton of [aumento, disminucion]) {
                expect(boton).toHaveAttribute('aria-disabled', 'true');
                expect(boton).toHaveAttribute('tabindex', '-1');
                // No es `disabled` nativo: un botón deshabilitado no recibe el ratón y
                // su tooltip no aparecería.
                expect(boton).not.toBeDisabled();
            }
        });

        it('los dos llevan el piso táctil de 44px en vez de los 64px de MUI', () => {
            render(<Counter count={1} handleChangeCount={jest.fn()} />);

            // El piso es una regla del grupo, `.<grupo> .MuiButtonGroup-grouped`, que en el
            // navegador gana por especificidad al `min-width: 64px` del propio Button.
            // jsdom no ordena por especificidad (su getComputedStyle devuelve 64px), así
            // que se comprueba la regla: que exista y que alcance a los dos botones —el
            // Tooltip que ahora envuelve al de aumento no puede dejarlo fuera—.
            const reglas = Array.from(document.styleSheets)
                .flatMap((hoja) => Array.from(hoja.cssRules) as CSSStyleRule[])
                .filter((regla) => typeof regla.selectorText === 'string'
                    && regla.selectorText.includes('.MuiButtonGroup-grouped')
                    && regla.style.getPropertyValue('min-width') === '44px');

            expect(reglas.length).toBeGreaterThan(0);
            for (const etiqueta of ['increase', 'reduce']) {
                const boton = screen.getByLabelText(etiqueta);
                expect(reglas.some((regla) => boton.matches(regla.selectorText))).toBe(true);
            }
        });

        it('el contador deshabilitado bloquea los dos', () => {
            const onChange = jest.fn();
            render(<Counter count={5} isDisabled handleChangeCount={onChange} />);

            fireEvent.click(screen.getByLabelText('increase'));
            fireEvent.click(screen.getByLabelText('reduce'));

            expect(onChange).not.toHaveBeenCalled();
            expect(screen.getByLabelText('increase')).toHaveAttribute('aria-disabled', 'true');
            expect(screen.getByLabelText('reduce')).toHaveAttribute('aria-disabled', 'true');
        });
    });

    it('respeta el mínimo 0 de crear garantía', () => {
        const { input, valor } = setup({ inicial: 1, min: 0, max: 5 });

        fireEvent.change(input, { target: { value: '' } });
        fireEvent.blur(input);

        expect(input.value).toBe('0');
        expect(valor()).toBe('0');
    });

    describe('en escritorio (>=900px) se comporta como el original', () => {
        beforeEach(() => {
            mockDimensions.mockReturnValue({ isMobileExperience: false });
        });

        it('vaciar el campo devuelve el mínimo al instante', () => {
            const { input, valor } = setup({ inicial: 4, min: 1 });

            fireEvent.change(input, { target: { value: '' } });

            expect(valor()).toBe('1');
            expect(input.value).toBe('1');
        });

        it('lo que no es un entero se rechaza entero', () => {
            const { input, valor } = setup({ inicial: 4, min: 1 });

            fireEvent.change(input, { target: { value: '12a' } });

            expect(valor()).toBe('4');
            expect(input.value).toBe('4');
        });

        it('un entero válido llega al padre', () => {
            const { input, valor } = setup({ inicial: 4, min: 1 });

            fireEvent.change(input, { target: { value: '7' } });

            expect(valor()).toBe('7');
        });

    });

    it('un borrador vacío no sobrevive a una pasada por escritorio', () => {
        const { rerender } = render(<Anfitrion inicial={4} min={1} />);
        const input = screen.getByRole('textbox') as HTMLInputElement;

        fireEvent.change(input, { target: { value: '' } });
        expect(input.value).toBe('');

        mockDimensions.mockReturnValue({ isMobileExperience: false });
        rerender(<Anfitrion inicial={4} min={1} />);
        expect(input.value).toBe('4');

        mockDimensions.mockReturnValue({ isMobileExperience: true });
        rerender(<Anfitrion inicial={4} min={1} />);
        expect(input.value).toBe('4');

        // Y salir del campo ya no lo lleva al mínimo: el valor sigue siendo 4.
        fireEvent.blur(input);
        expect(screen.getByTestId('valor').textContent).toBe('4');
    });
});
