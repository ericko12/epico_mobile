import { render, screen, fireEvent } from '@testing-library/react';
import { ArticleCard } from '@/features/common/infrastructure/ui/cards/ArticleCard';

/**
 * `ArticleCard` es la vista móvil de los artículos de mini caja en cuatro pantallas del
 * checkout y en el resumen de promociones. Estos tests fijan el contrato de sus props
 * opcionales: cada consumidor pasa un subconjunto distinto (unos tienen existencia, otros
 * importe, solo uno selección), y lo que no se pasa no debe dejar rastro en la tarjeta.
 */
describe('ArticleCard', () => {
    const BASE = {
        code: '1394000',
        description: 'CINTA AISLANTE NEGRO 60 PIES PLASTICA VERZE 20 U/L',
        quantity: 2,
    };

    it('muestra código, descripción y cantidad', () => {
        render(<ArticleCard {...BASE} />);

        expect(screen.getByText('1394000')).toBeInTheDocument();
        expect(screen.getByText(BASE.description)).toBeInTheDocument();
        expect(screen.getByText('×2')).toBeInTheDocument();
    });

    it('omite existencia, importe, imagen, distintivo y selección cuando no se pasan', () => {
        render(<ArticleCard {...BASE} />);

        expect(screen.queryByText(/Existencia:/)).not.toBeInTheDocument();
        expect(screen.queryByRole('checkbox')).not.toBeInTheDocument();
        expect(screen.queryByTestId('badge')).not.toBeInTheDocument();
    });

    it('muestra la existencia cuando se proporciona', () => {
        render(<ArticleCard {...BASE} existencia={48} />);
        expect(screen.getByText(/Existencia:/)).toHaveTextContent('Existencia: 48');
    });

    it('muestra el importe cuando se proporciona', () => {
        render(<ArticleCard {...BASE} amount="$1,154.29" />);
        expect(screen.getByText('$1,154.29')).toBeInTheDocument();
    });

    it('renderiza el distintivo de promoción o regalo', () => {
        render(<ArticleCard {...BASE} badge={<span data-testid="badge">Regalo</span>} />);
        expect(screen.getByTestId('badge')).toBeInTheDocument();
    });

    it('el control de cantidad sustituye a la píldora ×N', () => {
        render(
            <ArticleCard
                {...BASE}
                quantityControl={<button data-testid="contador">contador</button>}
            />,
        );

        expect(screen.getByTestId('contador')).toBeInTheDocument();
        // La píldora es de solo lectura: si la tabla deja editar, no debe convivir con ella.
        expect(screen.queryByText('×2')).not.toBeInTheDocument();
    });

    it('propaga el cambio del checkbox de selección', () => {
        const onChange = jest.fn();
        render(
            <ArticleCard
                {...BASE}
                selection={{ checked: false, onChange }}
            />,
        );

        fireEvent.click(screen.getByRole('checkbox'));
        expect(onChange).toHaveBeenCalledTimes(1);
    });

    it('respeta el estado deshabilitado de la selección', () => {
        render(
            <ArticleCard
                {...BASE}
                selection={{ checked: true, disabled: true, onChange: jest.fn() }}
            />,
        );

        const checkbox = screen.getByRole('checkbox');
        expect(checkbox).toBeDisabled();
        expect(checkbox).toBeChecked();
    });

    it('respeta un nodo de existencia ya estilizado (p. ej. stock insuficiente en rojo)', () => {
        render(
            <ArticleCard
                {...BASE}
                existencia={<span data-testid="stock-conflict">3</span>}
            />,
        );

        expect(screen.getByTestId('stock-conflict')).toBeInTheDocument();
    });
});
