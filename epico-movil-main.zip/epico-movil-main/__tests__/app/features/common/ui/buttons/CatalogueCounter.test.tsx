import { render, screen, fireEvent, act } from '@testing-library/react';
import { CatalogueCounter } from '@/features/common/infrastructure/ui/buttons/CatalogueCounter/CatalogueCounter';

// El manejo del campo que fijan estos tests es el de móvil (<900px). Escritorio conserva el
// del original: se prueba aparte, al final, con `isMobileExperience` en false.
const mockDimensions = jest.fn(() => ({ isMobileExperience: true }));
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

/**
 * `CatalogueCounter` es el contador de cantidad de seis pantallas: las dos vistas del
 * catálogo, el detalle de producto, el historial de compras y las dos vistas del modal de
 * promociones. En el teléfono se reportó que la cantidad no se podía escribir: el campo
 * abría el teclado alfabético (solo acepta dígitos) y al vaciarlo el valor anterior
 * volvía a aparecer. Estos tests fijan ese contrato — el ancho no se puede probar aquí,
 * jsdom no calcula layout.
 */
describe('CatalogueCounter', () => {
    const DEBOUNCE = 300;

    const setup = (counter = 1, maximumValue?: number) => {
        const setCounter = jest.fn();
        render(
            <CatalogueCounter
                counter={counter}
                setCounter={setCounter}
                addProducts
                fullWidth
                maximumValue={maximumValue}
            />
        );
        return { setCounter, input: screen.getByRole('textbox') as HTMLInputElement };
    };

    beforeEach(() => {
        jest.useFakeTimers();
        mockDimensions.mockReturnValue({ isMobileExperience: true });
    });

    afterEach(() => {
        jest.useRealTimers();
    });

    /** El debounce del componente es de 300ms; sin avanzarlo `setCounter` no se llama. */
    const flushDebounce = () => act(() => { jest.advanceTimersByTime(DEBOUNCE); });

    it('declara el teclado numérico', () => {
        const { input } = setup();
        expect(input).toHaveAttribute('inputMode', 'numeric');
    });

    it('en móvil el campo tiene ancho intrínseco de 3 caracteres y un piso de 32px', () => {
        const { input } = setup();

        expect(input).toHaveAttribute('size', '3');
        expect(input.style.minWidth).toBe('32px');
    });

    it('acepta un valor escrito', () => {
        const { setCounter, input } = setup();

        fireEvent.change(input, { target: { value: '12' } });
        expect(input.value).toBe('12');

        flushDebounce();
        expect(setCounter).toHaveBeenCalledWith(12);
    });

    it('vaciar el campo vale como 0 en vez de dejar el valor anterior', () => {
        const { setCounter, input } = setup(5);

        fireEvent.change(input, { target: { value: '' } });
        expect(input.value).toBe('0');

        flushDebounce();
        expect(setCounter).toHaveBeenCalledWith(0);
    });

    it('descarta lo que no es dígito y conserva el número', () => {
        const { setCounter, input } = setup();

        fireEvent.change(input, { target: { value: '1a2' } });
        expect(input.value).toBe('12');

        flushDebounce();
        expect(setCounter).toHaveBeenCalledWith(12);
    });

    it('no pasa del máximo', () => {
        const { setCounter, input } = setup(1, 10);

        fireEvent.change(input, { target: { value: '99' } });
        flushDebounce();

        expect(setCounter).not.toHaveBeenCalled();
        expect(input.value).toBe('1');
    });

    it('los botones + y - siguen moviendo el valor', () => {
        const { setCounter, input } = setup(2);
        const [restar, sumar] = screen.getAllByRole('button');

        fireEvent.click(sumar);
        expect(input.value).toBe('3');
        flushDebounce();
        expect(setCounter).toHaveBeenLastCalledWith(3);

        fireEvent.click(restar);
        flushDebounce();
        expect(setCounter).toHaveBeenLastCalledWith(2);
    });

    describe('en escritorio (>=900px) se comporta como el original', () => {
        beforeEach(() => {
            mockDimensions.mockReturnValue({ isMobileExperience: false });
        });

        it('vaciar el campo no avisa al padre y deja el valor anterior', () => {
            const { setCounter, input } = setup(5);

            fireEvent.change(input, { target: { value: '' } });
            flushDebounce();

            expect(setCounter).not.toHaveBeenCalled();
            expect(input.value).toBe('5');
        });

        it('un valor con letras al inicio se descarta entero', () => {
            const { setCounter, input } = setup(5);

            fireEvent.change(input, { target: { value: 'a12' } });
            flushDebounce();

            expect(setCounter).not.toHaveBeenCalled();
            expect(input.value).toBe('5');
        });

        it('acepta un valor escrito', () => {
            const { setCounter, input } = setup();

            fireEvent.change(input, { target: { value: '12' } });
            flushDebounce();

            expect(setCounter).toHaveBeenCalledWith(12);
        });

        it('no fija el ancho intrínseco de 3 caracteres ni el piso de 32px', () => {
            const { input } = setup();

            expect(input).not.toHaveAttribute('size');
            expect(input.style.minWidth).toBe('');
        });

    });
});
