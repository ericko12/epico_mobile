import { getWindowDimensions } from '@/features/common/domain/windowDimension/WindowDimension';
import { BreakpointEnum } from '@/features/common/domain/enums/Breakpoint';

// ─── Helpers ───────────────────────────────────────────────────────────────────

const setWindowWidth = (width: number) => {
    Object.defineProperty(window, 'innerWidth', { configurable: true, value: width });
    Object.defineProperty(window, 'innerHeight', { configurable: true, value: 800 });
};

const setScreenWidth = (width: number) => {
    Object.defineProperty(window.screen, 'width', { configurable: true, value: width });
};

afterEach(() => setScreenWidth(0)); // 0 = valor por defecto de jsdom (se ignora)

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('getWindowDimensions - isMobileExperience', () => {
    it('is true just below the mobileExperience breakpoint (899px)', () => {
        setWindowWidth(BreakpointEnum.mobileExperience - 1); // 899
        expect(getWindowDimensions().isMobileExperience).toBe(true);
    });

    it('is false exactly at the mobileExperience breakpoint (900px)', () => {
        setWindowWidth(BreakpointEnum.mobileExperience); // 900
        expect(getWindowDimensions().isMobileExperience).toBe(false);
    });

    it('is false on desktop widths (1280px)', () => {
        setWindowWidth(1280);
        expect(getWindowDimensions().isMobileExperience).toBe(false);
    });

    it('is true on a phone even if page zoom widens innerWidth past the breakpoint', () => {
        // Chrome Android recuerda el zoom por sitio: al recargar, innerWidth puede
        // reportar 1200px en un teléfono de 360px y caer en la vista de escritorio.
        setWindowWidth(1200);
        setScreenWidth(360);
        expect(getWindowDimensions().isMobileExperience).toBe(true);
    });

    it('ignores screen.width when it is not available (0) and trusts innerWidth', () => {
        setWindowWidth(1280);
        setScreenWidth(0);
        expect(getWindowDimensions().isMobileExperience).toBe(false);
    });

    it('stays desktop on a real desktop screen', () => {
        setWindowWidth(1280);
        setScreenWidth(1920);
        expect(getWindowDimensions().isMobileExperience).toBe(false);
    });
});

describe('getWindowDimensions - non-regression of legacy device flags', () => {
    it('keeps the phone breakpoint (isMobile) at <=480px, decoupled from isMobileExperience', () => {
        setWindowWidth(480);
        const dims = getWindowDimensions();
        expect(dims.isMobile).toBe(true);
        expect(dims.isMobileExperience).toBe(true);
    });

    it('classifies a tablet (768px) as not-mobile but within the mobile experience', () => {
        setWindowWidth(768);
        const dims = getWindowDimensions();
        // Tablet: por debajo de tablet(790) => isTablet; NO es isMobile (<=480)
        expect(dims.isMobile).toBe(false);
        expect(dims.isTablet).toBe(true);
        // pero SÍ recibe la experiencia móvil (<900)
        expect(dims.isMobileExperience).toBe(true);
    });

    it('classifies desktop (1280px) consistently across all flags', () => {
        setWindowWidth(1280);
        const dims = getWindowDimensions();
        expect(dims.isDesktop).toBe(true);
        expect(dims.isMobile).toBe(false);
        expect(dims.isTablet).toBe(false);
        expect(dims.isMobileAndTablet).toBe(false);
        expect(dims.isMobileExperience).toBe(false);
    });
});
