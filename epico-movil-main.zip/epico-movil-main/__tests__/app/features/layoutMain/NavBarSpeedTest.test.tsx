import { render, screen, act } from '@testing-library/react';
import { NavBarSpeedTest } from '@/features/layoutMain/infrastructure/ui/navbar/NavBarSpeedTest';
import { useAppSelector } from '@/features/common/application/redux/hooks';

jest.mock('@/features/common/application/redux/hooks');

const mockInsertLogRed = jest.fn();
jest.mock('@/features/seller/application/services/seller.services', () => ({
    sellersService: () => ({ InsertLogRed: mockInsertLogRed }),
}));

const SLOW_MESSAGE = /CONEXIÓN INESTABLE/;

/** Instala un `navigator.connection` simulado y devuelve el disparador del evento `change`. */
const mockConnection = (values: Record<string, unknown>) => {
    const listeners: Array<() => void> = [];
    const connection: Record<string, unknown> = {
        ...values,
        addEventListener: (_: string, cb: () => void) => { listeners.push(cb); },
        removeEventListener: jest.fn(),
    };
    Object.defineProperty(navigator, 'connection', { configurable: true, value: connection });
    return {
        connection,
        fireChange: () => act(() => { listeners.forEach((cb) => cb()); }),
    };
};

beforeEach(() => {
    jest.clearAllMocks();
    (useAppSelector as unknown as jest.Mock).mockReturnValue({
        userAuth: { name: 'Jorge', lastName: 'Quintero' },
    });
    global.fetch = jest.fn().mockResolvedValue({ json: async () => ({ ip: '10.0.0.1' }) });
});

afterEach(() => {
    Object.defineProperty(navigator, 'connection', { configurable: true, value: undefined });
});

describe('NavBarSpeedTest - monitoreo de red sin consumir datos', () => {
    it('no transfiere datos para medir: nunca instancia un speedtest', () => {
        // La regresión que este test protege: antes se descargaban ~MB cada 10 min
        // contra speed.cloudflare.com solo para estimar el ancho de banda.
        mockConnection({ effectiveType: '4g' });
        render(<NavBarSpeedTest />);
        expect(global.fetch).not.toHaveBeenCalledWith(
            expect.stringContaining('cloudflare'),
            expect.anything(),
        );
    });

    it('avisa cuando la conexión efectiva es lenta', () => {
        mockConnection({ effectiveType: '2g' });
        render(<NavBarSpeedTest />);
        expect(screen.getByText(SLOW_MESSAGE)).toBeInTheDocument();
    });

    it('no avisa en 4g', () => {
        mockConnection({ effectiveType: '4g' });
        render(<NavBarSpeedTest />);
        expect(screen.queryByText(SLOW_MESSAGE)).not.toBeInTheDocument();
    });

    it('reacciona al evento change del navegador', () => {
        const { connection, fireChange } = mockConnection({ effectiveType: '4g' });
        render(<NavBarSpeedTest />);
        expect(screen.queryByText(SLOW_MESSAGE)).not.toBeInTheDocument();

        connection.effectiveType = 'slow-2g';
        fireChange();
        expect(screen.getByText(SLOW_MESSAGE)).toBeInTheDocument();
    });

    it('con ahorro de datos activo avisa pero no envía el registro', () => {
        mockConnection({ effectiveType: '2g', saveData: true });
        render(<NavBarSpeedTest />);

        expect(screen.getByText(SLOW_MESSAGE)).toBeInTheDocument();
        expect(global.fetch).not.toHaveBeenCalled();
        expect(mockInsertLogRed).not.toHaveBeenCalled();
    });

    it('no hace nada si el navegador no implementa la API (Safari/iOS)', () => {
        render(<NavBarSpeedTest />);
        expect(screen.queryByText(SLOW_MESSAGE)).not.toBeInTheDocument();
        expect(global.fetch).not.toHaveBeenCalled();
    });
});
