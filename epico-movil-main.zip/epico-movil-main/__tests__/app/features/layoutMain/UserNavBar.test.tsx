import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { UserNavBar } from '@/features/layoutMain/infrastructure/ui/navbar/UserNavBar';

// ─── Mocks ───────────────────────────────────────────────────────────────────

const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

jest.mock('next/navigation', () => ({
    usePathname: () => '/Catalogo',
    useRouter: () => ({ push: jest.fn() }),
    useSearchParams: () => new URLSearchParams(),
}));

jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));

const mockDispatch = jest.fn();
jest.mock('@/features/common/application/redux/hooks', () => ({
    useAppDispatch: () => mockDispatch,
    useAppSelector: (selector: (state: unknown) => unknown) =>
        selector({
            localState: {
                authState: {
                    adminThird: false,
                    addProducts: true,
                    userAuth: { name: 'ana', lastName: 'lopez', position: 'vendedor', employeeId: 7 },
                },
            },
            sessionState: {
                checkOutsState: { checkOutList: [], selectedOrderSummary: null },
                customerInfoState: {
                    Cvid: 0, customer: null, contacts: [], creditStatus: null,
                    address: [], isCreatingCheckout: false, isCreatingCheckoutExternal: false,
                },
            },
        }),
}));

// Los modales que abren las acciones se sustituyen por centinelas.
jest.mock('@/features/layoutMain/infrastructure/ui/dialogs/BankAccountsModal', () => ({
    __esModule: true,
    default: () => <div data-testid="modal-bancos" />,
}));
jest.mock('@/features/products/infrastructure/ui/dialogs/ModalQuotation', () => ({
    __esModule: true,
    default: () => <div data-testid="modal-cotizador" />,
}));
jest.mock('@/features/products/infrastructure/ui/dialogs/ModalStockByRegion', () => ({
    __esModule: true,
    default: () => <div data-testid="modal-existencias" />,
}));

jest.mock('@/features/customer/application/service/customer.services', () => ({
    customerService: () => ({ getCustomersInfoByIds: jest.fn() }),
}));

// Estas acciones arrastran el service worker (@serwist/window, ESM) por la cadena
// de imports; no participan en lo que se prueba aquí.
jest.mock('@/features/customer/application/actions/validateCustomerInformation', () => ({
    validateCustomerInformation: jest.fn(),
}));
jest.mock('@/features/customer/application/actions/db/savePriceList', () => ({
    savePriceListData: jest.fn(),
}));
jest.mock('@/features/customer/application/actions/createCheckout', () => ({
    createCheckout: jest.fn(),
}));
jest.mock('@/features/checkout/application/actions/shipmentMiniCheckout', () => ({
    shipmentMiniCheckout: jest.fn(() => false),
}));
jest.mock('@/features/auth/application/closeSesion', () => ({
    closeSession: jest.fn(),
}));

const setMobile = () =>
    mockDimensions.mockReturnValue({ width: 375, height: 800, isMobile: true, isTablet: false, isDesktop: false, isMobileAndTablet: true, isMobileExperience: true });
const setDesktop = () =>
    mockDimensions.mockReturnValue({ width: 1280, height: 800, isMobile: false, isTablet: false, isDesktop: true, isMobileAndTablet: false, isMobileExperience: false });

/** Acciones que la barra debe ofrecer en ambas experiencias. */
const ACCIONES = [
    'Liga de expertos',
    'Existencias por region',
    'Cotizador',
    'Cuentas bancarias',
    'Notificaciones',
    'Detalle orden',
];

afterEach(() => jest.clearAllMocks());

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('UserNavBar - experiencia móvil', () => {
    it('colapsa las acciones en un menú detrás del avatar', () => {
        setMobile();
        render(<UserNavBar />);

        // Cerradas no se ven; el punto de entrada es un solo botón.
        expect(screen.queryByText('Cotizador')).not.toBeInTheDocument();

        fireEvent.click(screen.getByRole('button', { name: 'Más opciones' }));

        for (const accion of ACCIONES) {
            expect(screen.getByText(accion)).toBeInTheDocument();
        }
    });

    it('abre el modal de la acción elegida', () => {
        setMobile();
        render(<UserNavBar />);

        expect(screen.queryByTestId('modal-cotizador')).not.toBeInTheDocument();

        fireEvent.click(screen.getByRole('button', { name: 'Más opciones' }));
        fireEvent.click(screen.getByText('Cotizador'));

        expect(screen.getByTestId('modal-cotizador')).toBeInTheDocument();
    });

    it('muestra el nombre y el puesto del usuario', () => {
        setMobile();
        render(<UserNavBar />);
        fireEvent.click(screen.getByRole('button', { name: 'Más opciones' }));

        expect(screen.getByText('Ana Lopez')).toBeInTheDocument();
        expect(screen.getByText('Vendedor')).toBeInTheDocument();
    });
});

describe('UserNavBar - experiencia de escritorio', () => {
    it('conserva los íconos sueltos, sin menú', () => {
        setDesktop();
        render(<UserNavBar />);

        expect(screen.queryByRole('button', { name: 'Más opciones' })).not.toBeInTheDocument();
        // Seis acciones + cerrar sesión, cada una como su propio botón.
        // Nota: en escritorio los íconos no exponen nombre accesible (el tooltip
        // no lo aporta); por eso se cuentan en vez de buscarse por nombre.
        expect(screen.getAllByRole('button')).toHaveLength(ACCIONES.length + 1);
        expect(screen.getByRole('button', { name: 'checkout' })).toBeInTheDocument();
    });

    it('muestra el nombre y el puesto sin necesidad de abrir nada', () => {
        setDesktop();
        render(<UserNavBar />);

        expect(screen.getByText('Ana Lopez')).toBeInTheDocument();
        expect(screen.getByText('Vendedor')).toBeInTheDocument();
    });
});
