import React, { ReactElement, ReactNode } from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { GridColDef } from '@mui/x-data-grid';
import { ArticleCard } from '@/features/common/infrastructure/ui/cards/ArticleCard';
import { COLUMNS } from '@/features/checkout/infrastructure/ui/accordionDetailMiniCheckouts/AccordionDetailMiniCheckouts.data';
import { COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4 } from '@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4.data';
import { COLUMNS_MINI_CHECKOUT_DETAIL_PREVIEW, MAX_COUNTER_VALUE } from '@/features/checkout/infrastructure/ui/miniCheckoutsPreview/miniCheckoutDetailPreview/MiniCheckoutDetailPreview.data';
import { resolveMobileMiniCheckoutArticle, IMobileMiniCheckoutArticle } from '@/features/checkout/infrastructure/ui/miniCheckoutsPreview/miniCheckoutDetailPreview/mobileMiniCheckoutArticle';
import { NOTIFICATIONS_CHECKOUT } from '@/features/checkout/infrastructure/utils/messages/NotificationsCheckout';
import { PromotionTypesEnum } from '@/features/promotions/domain/enums/PromotionTypesEnum';
import { CoinFormatter } from '@/features/common/infrastructure/utils/models/CoinFormatter';
import { IconPromo } from '@/features/common/infrastructure/ui/icons/IconPromo';
import { BadgePriceSpecial } from '@/features/products/infrastructure/ui/badge/BadgePriceSpecial';
import GiftIcon from '@/features/common/infrastructure/ui/icons/GiftIcon';
import { IArticle } from '@/features/shipment/domain/interfaces/evaluatorSMC4/IArticle';

/**
 * Paridad tabla/tarjeta de los artículos de mini caja en el checkout.
 *
 * Tres pantallas —AccordionDetailMiniCheckouts, su variante SMC4 y
 * MiniCheckoutDetailPreview— resuelven los mismos datos DOS veces: en las columnas
 * del DataGrid (escritorio) y en la tarjeta de la rama móvil. Nada obliga a que
 * coincidan, así que este archivo **es el contrato**: fija qué debe mostrarse para
 * una fila dada y lo verifica contra las columnas, que son las exportables.
 *
 * En MiniCheckoutDetailPreview la derivación de la tarjeta vive en
 * `resolveMobileMiniCheckoutArticle`, así que ahí se verifican **los dos lados** contra
 * el mismo caso: la columna de escritorio (lo que pinta el DataGrid) y el resolvedor de la
 * tarjeta. En las otras dos pantallas la tarjeta se arma dentro del componente y solo se
 * verifica el lado tabla; el lado tarjeta queda fijado por `ArticleCard.test.tsx` (cómo
 * pinta). Si alguien toca una de las dos rutas y no la otra, este archivo es el que dice
 * cuál era el acuerdo.
 */

jest.mock('@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell', () => ({
    ImageCell: ({ producto }: { producto: string }) => <img alt={producto} data-testid="image-cell" />,
}));

jest.mock('@/features/products/application/actions/fetchImageProducts', () => ({
    fetchImageProducts: jest.fn(),
}));

jest.mock('@/features/common/infrastructure/ui/icons/GiftIcon', () => {
    const MockGiftIcon = () => <span data-testid="gift-icon" />;
    return { __esModule: true, GiftIcon: MockGiftIcon, default: MockGiftIcon };
});

/**
 * Evalúa el `renderCell` de una columna fuera del DataGrid, como hace la card.
 *
 * `rows` son las filas de la mini caja: desde la 8ª sincronización las columnas
 * "Existencia" y "Cantidad" de la vista previa leen todas las filas con
 * `params.api.getRowModels()` para sumar el SKU, así que aquí se les da un `api` que
 * devuelve esas filas.
 */
const renderColumn = (
    columns: GridColDef[],
    field: string,
    row: Record<string, unknown>,
    rows: Record<string, unknown>[] = [row],
): ReactNode => {
    const col = columns.find((c) => c.field === field);
    if (!col) throw new Error(`No existe la columna '${field}'`);
    if (typeof col.renderCell !== 'function') return row[field] as ReactNode;
    const api = { getRowModels: () => new Map(rows.map((r, index) => [index, r])) };
    return col.renderCell({ row, value: row[field], field, api } as never);
};

/** Texto que pinta un nodo devuelto por un `renderCell`. */
const textOf = (node: ReactNode): string => {
    const { container, unmount } = render(<div>{node}</div>);
    const text = container.textContent ?? '';
    unmount();
    return text;
};

const GENERICOS = [
    { producto: '1394000', descripcion: 'CINTA AISLANTE NEGRO 60 PIES PLASTICA', imagenUrl: 'https://x/1394000.jpg' },
] as never[];

/** La vista previa recibe el manejador de cantidad; estos casos no lo ejercitan. */
const noop = () => { };

describe('paridad tabla/tarjeta — artículos de mini caja', () => {
    describe('descripción: el genérico gana, la de la fila es el respaldo', () => {
        it('AccordionDetailMiniCheckouts usa la descripción del genérico', () => {
            const row = { producto: '1394000', descripcion: 'DESCRIPCION DE LA FILA', cantidad: 2 };

            const desdeTabla = renderColumn(COLUMNS({} as never, GENERICOS), 'descripcion', row);
            render(<ArticleCard code={row.producto} description={desdeTabla} quantity={row.cantidad} />);

            expect(screen.getByText('CINTA AISLANTE NEGRO 60 PIES PLASTICA')).toBeInTheDocument();
            expect(screen.queryByText('DESCRIPCION DE LA FILA')).not.toBeInTheDocument();
        });

        it('cae a la descripción de la fila cuando no hay genérico', () => {
            const row = { producto: '9999999', descripcion: 'DESCRIPCION DE LA FILA', cantidad: 1 };

            const desdeTabla = renderColumn(COLUMNS({} as never, GENERICOS), 'descripcion', row);
            render(<ArticleCard code={row.producto} description={desdeTabla} quantity={row.cantidad} />);

            expect(screen.getByText('DESCRIPCION DE LA FILA')).toBeInTheDocument();
        });

        /**
         * Desde la 8ª sincronización la columna SMC4 ya no devuelve el texto: lo envuelve
         * en un `div` recortado con puntos suspensivos y deja el texto completo en
         * `title`. El dato sigue siendo el de su gemela; la tarjeta móvil lo pinta
         * completo, sin recorte, así que el `title` no le hace falta.
         */
        it('SMC4 resuelve la descripción igual que su gemela', () => {
            const row = { producto: '1394000', descripcion: 'DESCRIPCION DE LA FILA', cantidad: 3 };

            const smc4 = renderColumn(COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(GENERICOS), 'descripcion', row);
            const legacy = renderColumn(COLUMNS({} as never, GENERICOS), 'descripcion', row);

            const { container } = render(<div>{smc4}</div>);
            expect(container.textContent).toBe(legacy);
            expect(container.querySelector('[title]')).toHaveAttribute('title', legacy as string);
        });

        it('SMC4 cae a la descripción de la fila sin genérico, también en el title', () => {
            const row = { producto: '9999999', descripcion: 'DESCRIPCION DE LA FILA', cantidad: 1 };

            const smc4 = renderColumn(COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(GENERICOS), 'descripcion', row);
            const { container } = render(<div>{smc4}</div>);

            expect(container.textContent).toBe('DESCRIPCION DE LA FILA');
            expect(container.querySelector('[title]')).toHaveAttribute('title', 'DESCRIPCION DE LA FILA');
        });

        it('la tarjeta pinta completa la descripción que la columna SMC4 recorta', () => {
            const larga = 'CINTA AISLANTE NEGRO 60 PIES PLASTICA DE USO RUDO PARA INSTALACIONES ELECTRICAS';
            render(<ArticleCard code="1394000" description={larga} quantity={1} />);

            const nodo = screen.getByText(larga);
            // El positivo prueba que los estilos de MUI sí se resuelven aquí, para que
            // los dos negativos de abajo no pasen en vacío.
            expect(nodo).toHaveStyle({ wordBreak: 'break-word' });
            expect(nodo).not.toHaveStyle({ textOverflow: 'ellipsis' });
            expect(nodo).not.toHaveStyle({ whiteSpace: 'nowrap' });
        });

        it('MiniCheckoutDetailPreview solo consulta el genérico cuando la sucursal es transitoria', () => {
            const row = { sku: '1394000', descripcion: 'DESCRIPCION DE LA FILA', cantidad: 1, existencias: 5 };
            const tarjeta = (isTransient: boolean) => resolveMobileMiniCheckoutArticle({
                row: row as unknown as IArticle,
                rows: [row as unknown as IArticle],
                isTransient,
                genericProductsDescriptions: GENERICOS,
                hasAppliedKms: false,
                hasDefaultBranchFlag: false,
                isTransferOption: false,
            }).description;

            // La columna pinta la descripción en un contenedor recortado con puntos
            // suspensivos (y la completa en `title`); lo que cuenta es el texto.
            const transitoria = textOf(renderColumn(
                COLUMNS_MINI_CHECKOUT_DETAIL_PREVIEW(true, GENERICOS, noop), 'descripcion', row));
            const normal = textOf(renderColumn(
                COLUMNS_MINI_CHECKOUT_DETAIL_PREVIEW(false, GENERICOS, noop), 'descripcion', row));

            expect(transitoria).toBe('CINTA AISLANTE NEGRO 60 PIES PLASTICA');
            expect(normal).toBe('DESCRIPCION DE LA FILA');
            expect(tarjeta(true)).toBe(transitoria);
            expect(tarjeta(false)).toBe(normal);
        });
    });

    describe('distintivo: regalo gana sobre promoción', () => {
        it('marca regalo cuando es gratis y del tipo ProductoRegalo', () => {
            const row = {
                producto: '1394000',
                gratis: true,
                tipoPromocionId: PromotionTypesEnum.ProductoRegalo,
                promocionID: 55,
            };

            const badge = renderColumn(COLUMNS({} as never, GENERICOS), 'promocionID', row);
            render(<ArticleCard code="1394000" description="x" quantity={1} badge={badge} />);

            expect(screen.getByTestId('gift-icon')).toBeInTheDocument();
        });

        it('no marca nada sin promoción ni regalo', () => {
            const row = { producto: '1394000', gratis: false, promocionID: undefined };

            const badge = renderColumn(COLUMNS({} as never, GENERICOS), 'promocionID', row);

            expect(badge).toBeNull();
        });

        it('SMC4 aplica la misma precedencia con su campo promocionId', () => {
            const regalo = renderColumn(
                COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(GENERICOS), 'promocionId',
                { producto: '1394000', gratis: true, tipoPromocionId: PromotionTypesEnum.ProductoRegalo, promocionId: 9 });
            const nada = renderColumn(
                COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(GENERICOS), 'promocionId',
                { producto: '1394000', gratis: false, promocionId: undefined });

            render(<div>{regalo}</div>);
            expect(screen.getByTestId('gift-icon')).toBeInTheDocument();
            expect(nada).toBeNull();
        });

        /** Qué distintivo devolvió la columna sin encabezado de la vista previa. */
        const distintivoDeTabla = (node: ReactNode): IMobileMiniCheckoutArticle['badge'] | 'desconocido' => {
            if (node === null || node === undefined) return null;
            const element = node as ReactElement<{ children?: ReactElement }>;
            if (element.type === BadgePriceSpecial) return 'precioEspecial';
            const child = element.props.children;
            if (child?.type === GiftIcon) return 'regalo';
            if (child?.type === IconPromo) return 'promocion';
            return 'desconocido';
        };

        it.each([
            ['regalo', { gratis: true, tipoPromocionId: PromotionTypesEnum.ProductoRegalo, promocionId: 9 }],
            ['promocion', { gratis: false, promocionId: 9 }],
            ['precioEspecial', { gratis: false, precioEspecialId: 5 }],
            [null, { gratis: false }],
        ] as const)('MiniCheckoutDetailPreview: la tarjeta marca %s igual que la columna', (esperado, extra) => {
            const row = { sku: '1394000', descripcion: 'x', cantidad: 1, existencias: 5, ...extra };

            const tabla = distintivoDeTabla(renderColumn(
                COLUMNS_MINI_CHECKOUT_DETAIL_PREVIEW(false, GENERICOS, noop), 'promotion', row));
            const tarjeta = resolveMobileMiniCheckoutArticle({
                row: row as unknown as IArticle,
                rows: [row as unknown as IArticle],
                isTransient: false,
                hasAppliedKms: false,
                hasDefaultBranchFlag: false,
                isTransferOption: false,
            }).badge;

            expect(tabla).toBe(esperado);
            expect(tarjeta).toBe(esperado);
        });
    });

    describe('importe con IVA', () => {
        it('la tabla y la tarjeta usan el mismo formato de moneda', () => {
            const row = { producto: '1394000', importeConIva: 1248.5 };
            const esperado = new CoinFormatter(row.importeConIva).coin;

            const desdeTabla = renderColumn(
                COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(GENERICOS), 'importeConIva', row);
            const tabla = render(<div>{desdeTabla}</div>);
            expect(tabla.container.textContent).toBe(esperado);
            tabla.unmount();

            const tarjeta = render(
                <ArticleCard code="1394000" description="x" quantity={1} amount={esperado} />);
            expect(tarjeta.getByText(esperado)).toBeInTheDocument();
        });
    });

    /**
     * Vista previa del mini checkout: existencia, contador y columna de traspasos.
     *
     * Cada caso es el contrato de UNA fila y se verifica dos veces: contra la columna
     * de escritorio (renderizando su celda) y contra el resolvedor de la tarjeta móvil.
     */
    describe('MiniCheckoutDetailPreview', () => {
        const ARTICULO = {
            productoId: 1,
            sku: '1394000',
            descripcion: 'x',
            cantidad: 3,
            existencias: 5,
            cantidadOriginal: 3,
            cantidadTraspasos: 0,
            gratis: false,
        };
        type Fila = Partial<typeof ARTICULO> & Record<string, unknown>;

        interface IBanderas {
            isTransient?: boolean;
            hasKms?: boolean;
            hasDefaultBranchFlag?: boolean;
            isTransferOption?: boolean;
            /** Resumen cargando o formulario pendiente: el `isDisabled` del contador. */
            isDisabledCounter?: boolean;
        }

        const columnas = (banderas: IBanderas, onChange: (count: number, article: IArticle) => void = noop) =>
            COLUMNS_MINI_CHECKOUT_DETAIL_PREVIEW(
                banderas.isTransient ?? false,
                GENERICOS,
                onChange,
                banderas.isDisabledCounter ?? false,
                () => banderas.hasKms ?? false,
                banderas.hasDefaultBranchFlag ?? false,
                banderas.isTransferOption ?? false,
            );

        const tarjeta = (row: Fila, otras: Fila[] = [], banderas: IBanderas = {}) => resolveMobileMiniCheckoutArticle({
            row: row as unknown as IArticle,
            rows: [row, ...otras] as unknown as IArticle[],
            isTransient: banderas.isTransient ?? false,
            genericProductsDescriptions: GENERICOS,
            hasAppliedKms: banderas.hasKms ?? false,
            hasDefaultBranchFlag: banderas.hasDefaultBranchFlag ?? false,
            isTransferOption: banderas.isTransferOption ?? false,
            isDisabledCounter: banderas.isDisabledCounter,
        });

        /** Abre el tooltip de un botón como lo hace el ratón y devuelve su texto (o nada). */
        const leerTooltip = async (boton: HTMLElement): Promise<string | undefined> => {
            fireEvent.mouseOver(boton);
            try {
                const tooltip = await screen.findByRole('tooltip', {}, { timeout: 400 });
                return tooltip.textContent ?? undefined;
            } catch {
                return undefined;
            }
        };

        /** Lo que un usuario de escritorio observa en la celda "Cantidad". */
        const contadorDeEscritorio = async (row: Fila, otras: Fila[] = [], banderas: IBanderas = {}) => {
            const onChange = jest.fn();
            const filas = [row, ...otras];
            render(<div>{renderColumn(columnas(banderas, onChange), 'cantidad', row, filas)}</div>);

            const aumento = screen.getByLabelText('increase');
            // El tope se lee tecleando un número enorme: el contador lo recorta a `max`.
            fireEvent.change(screen.getByRole('textbox'), { target: { value: String(MAX_COUNTER_VALUE) } });
            const max = onChange.mock.calls.at(-1)?.[0];

            return {
                aumentoBloqueado: aumento.getAttribute('aria-disabled') === 'true',
                max,
                motivoAumento: await leerTooltip(aumento),
            };
        };

        const existenciaDeEscritorio = (row: Fila, otras: Fila[] = [], banderas: IBanderas = {}) => {
            const valor = renderColumn(columnas(banderas), 'existencias', row, [row, ...otras]);
            const { container, unmount } = render(<div>{valor}</div>);
            const resultado = {
                texto: container.textContent,
                conflicto: container.querySelector('.MuiTypography-root') !== null,
            };
            unmount();
            return resultado;
        };

        describe('existencia', () => {
            const row = { ...ARTICULO, cantidad: 4, existencias: 2 };

            it('muestra un guion cuando la sucursal es transitoria', () => {
                const valor = renderColumn(columnas({ isTransient: true }), 'existencias', row);

                expect(valor).toBe('-');
                expect(tarjeta(row, [], { isTransient: true })).toMatchObject({ existencia: '-', hasStockConflict: false });
            });

            it('resalta la existencia cuando no alcanza para la cantidad pedida', () => {
                expect(existenciaDeEscritorio(row).conflicto).toBe(true);
                expect(tarjeta(row).hasStockConflict).toBe(true);
            });

            it('deja la existencia en texto plano cuando alcanza', () => {
                const valor = renderColumn(columnas({}), 'existencias', { ...row, existencias: 10 });

                expect(valor).toBe(10);
                expect(tarjeta({ ...row, existencias: 10 })).toMatchObject({ existencia: 10, hasStockConflict: false });
            });
        });

        /**
         * Reglas nuevas de la 8ª sincronización: la existencia en conflicto y el tope del
         * contador se cuentan por SKU sumando todas las filas de la mini caja; en la opción
         * de traspasos el tope no baja de la cantidad original; y el botón de aumento
         * bloqueado explica por qué (tooltip en escritorio, texto a la vista en la tarjeta).
         */
        interface ICaso {
            nombre: string;
            row: Fila;
            otras?: Fila[];
            banderas?: IBanderas;
            esperado: { conflicto: boolean; max: number; aumentoBloqueado: boolean; motivoAumento?: string };
        }

        const HASTA_EXISTENCIA = NOTIFICATIONS_CHECKOUT.MINI_CHECKOUT.TOOLTIP_INCREASE_BY_MAX_AMOUNT;
        const SOBRE_EXISTENCIA = NOTIFICATIONS_CHECKOUT.MINI_CHECKOUT.TOOLTIP_INCREASE_BY_ABOVE_MAX_AMOUNT;

        const CASOS: ICaso[] = [
            {
                nombre: 'una fila sola por debajo de la existencia',
                row: { ...ARTICULO, cantidad: 3, existencias: 5 },
                esperado: { conflicto: false, max: 5, aumentoBloqueado: false },
            },
            {
                nombre: 'la existencia del SKU se reparte entre sus filas',
                row: { ...ARTICULO, cantidad: 2, existencias: 6 },
                otras: [{ ...ARTICULO, productoId: 2, cantidad: 2, existencias: 6 }],
                esperado: { conflicto: false, max: 4, aumentoBloqueado: false },
            },
            {
                nombre: 'otra fila del mismo SKU agota la existencia',
                row: { ...ARTICULO, cantidad: 3, existencias: 5 },
                otras: [{ ...ARTICULO, productoId: 2, cantidad: 2, existencias: 5 }],
                esperado: { conflicto: false, max: 3, aumentoBloqueado: true, motivoAumento: HASTA_EXISTENCIA },
            },
            {
                nombre: 'conflicto por SKU aunque la fila sola alcance',
                row: { ...ARTICULO, cantidad: 3, existencias: 5 },
                otras: [{ ...ARTICULO, productoId: 2, cantidad: 4, existencias: 5 }],
                esperado: { conflicto: true, max: 1, aumentoBloqueado: true, motivoAumento: SOBRE_EXISTENCIA },
            },
            {
                nombre: 'una fila de otro SKU no cuenta',
                row: { ...ARTICULO, cantidad: 3, existencias: 5 },
                otras: [{ ...ARTICULO, productoId: 2, sku: '9999999', cantidad: 4, existencias: 5 }],
                esperado: { conflicto: false, max: 5, aumentoBloqueado: false },
            },
            {
                nombre: 'en la opción de traspasos el tope no baja de la cantidad original',
                row: { ...ARTICULO, cantidad: 3, cantidadOriginal: 6, existencias: 5 },
                otras: [{ ...ARTICULO, productoId: 2, cantidad: 4, existencias: 5 }],
                banderas: { isTransferOption: true },
                esperado: { conflicto: true, max: 6, aumentoBloqueado: false },
            },
            {
                nombre: 'en la opción de traspasos, con la original por debajo, manda el reparto',
                row: { ...ARTICULO, cantidad: 3, cantidadOriginal: 3, existencias: 5 },
                otras: [{ ...ARTICULO, productoId: 2, cantidad: 4, existencias: 5 }],
                banderas: { isTransferOption: true },
                esperado: { conflicto: true, max: 3, aumentoBloqueado: true, motivoAumento: SOBRE_EXISTENCIA },
            },
            {
                nombre: 'sucursal transitoria: tope general y sin existencia',
                row: { ...ARTICULO, cantidad: 3, existencias: 2 },
                banderas: { isTransient: true },
                esperado: { conflicto: false, max: MAX_COUNTER_VALUE, aumentoBloqueado: false },
            },
            {
                nombre: 'sucursal predefinida: tope general aunque pase de la existencia',
                row: { ...ARTICULO, cantidad: 10, existencias: 5 },
                banderas: { hasDefaultBranchFlag: true },
                esperado: { conflicto: true, max: MAX_COUNTER_VALUE, aumentoBloqueado: false },
            },
            /*
             * El tooltip de `Counter` sale con el botón bloqueado por la regla **o** con el
             * contador entero deshabilitado. En la opción de traspasos con la original por
             * encima, la regla no bloquea el aumento pero su texto existe: con el contador
             * deshabilitado escritorio lo enseña al pasar el ratón, así que la tarjeta también.
             */
            {
                nombre: 'contador deshabilitado: el motivo del aumento se ve aunque la regla no lo bloquee',
                row: { ...ARTICULO, cantidad: 3, cantidadOriginal: 6, existencias: 5 },
                otras: [{ ...ARTICULO, productoId: 2, cantidad: 4, existencias: 5 }],
                banderas: { isTransferOption: true, isDisabledCounter: true },
                esperado: { conflicto: true, max: 6, aumentoBloqueado: true, motivoAumento: SOBRE_EXISTENCIA },
            },
            {
                nombre: 'contador deshabilitado sin motivo de existencia: bloqueado y sin texto',
                row: { ...ARTICULO, cantidad: 3, existencias: 5 },
                banderas: { isDisabledCounter: true },
                esperado: { conflicto: false, max: 5, aumentoBloqueado: true },
            },
        ];

        describe.each(CASOS)('tope y conflicto por SKU — $nombre', ({ row, otras = [], banderas = {}, esperado }) => {
            it('escritorio: la celda de existencia y el contador', async () => {
                expect(existenciaDeEscritorio(row, otras, banderas).conflicto).toBe(esperado.conflicto);

                const contador = await contadorDeEscritorio(row, otras, banderas);

                expect(contador.max).toBe(esperado.max);
                expect(contador.aumentoBloqueado).toBe(esperado.aumentoBloqueado);
                expect(contador.motivoAumento).toBe(esperado.motivoAumento);
            });

            it('tarjeta: el resolvedor da lo mismo y pinta el motivo a la vista', () => {
                const article = tarjeta(row, otras, banderas);
                // Lo que la tarjeta le pasa a `Counter`: la regla y el deshabilitado general.
                const aumentoBloqueado = (banderas.isDisabledCounter ?? false) || article.disabledIncrease;

                expect(article.hasStockConflict).toBe(esperado.conflicto);
                expect(article.max).toBe(esperado.max);
                expect(aumentoBloqueado).toBe(esperado.aumentoBloqueado);
                // Lo que el tooltip muestra: nada si el botón está activo.
                expect(aumentoBloqueado ? article.increaseTooltip : undefined).toBe(esperado.motivoAumento);
                if (esperado.motivoAumento) {
                    expect(article.quantityHints).toContain(esperado.motivoAumento);
                } else {
                    expect(article.quantityHints).not.toContain(HASTA_EXISTENCIA);
                    expect(article.quantityHints).not.toContain(SOBRE_EXISTENCIA);
                }
            });
        });

        describe('columna «Por recibir en traspasos»', () => {
            const conTraspasos = { ...ARTICULO, cantidadTraspasos: 4 };

            it('no existe fuera de la sucursal predefinida y de la opción de traspasos', () => {
                expect(columnas({}).some((c) => c.field === 'cantidadTraspasos')).toBe(false);
                expect(tarjeta(conTraspasos).transfersQuantity).toBeUndefined();
            });

            it.each([
                ['la sucursal predefinida', { hasDefaultBranchFlag: true }],
                ['la opción de traspasos', { isTransferOption: true }],
            ] as const)('aparece con %s, con guion cuando no hay nada por recibir', (_, banderas) => {
                expect(textOf(renderColumn(columnas(banderas), 'cantidadTraspasos', conTraspasos))).toBe('4');
                expect(textOf(renderColumn(columnas(banderas), 'cantidadTraspasos', { ...conTraspasos, cantidadTraspasos: 0 }))).toBe('-');

                expect(tarjeta(conTraspasos, [], banderas).transfersQuantity).toBe(4);
                expect(tarjeta({ ...conTraspasos, cantidadTraspasos: 0 }, [], banderas).transfersQuantity).toBe('-');
            });

            it('la tarjeta la pinta en la ranura de detalles con el encabezado de la columna', () => {
                const article = tarjeta(conTraspasos, [], { isTransferOption: true });
                const encabezado = columnas({ isTransferOption: true }).find((c) => c.field === 'cantidadTraspasos')?.headerName;

                render(
                    <ArticleCard
                        code="1394000"
                        description="x"
                        quantity={3}
                        details={[{ label: 'Por recibir en traspasos', value: article.transfersQuantity }]}
                    />);

                expect(encabezado).toBe('Por recibir en traspasos');
                expect(screen.getByText('Por recibir en traspasos')).toBeInTheDocument();
                expect(screen.getByText('4')).toBeInTheDocument();
            });
        });

        /**
         * La cantidad de la vista previa se volvió editable (release 3.29.0 del proyecto
         * original). La rama móvil arma el mismo contador con las mismas reglas.
         */
        describe('cantidad editable', () => {
            const BASE = { ...ARTICULO, cantidad: 3, existencias: 10, cantidadOriginal: 3 };

            const renderCantidad = (row: Fila, banderas: IBanderas = {}) =>
                render(<div>{renderColumn(columnas(banderas), 'cantidad', row)}</div>);

            it('con promoción la cantidad es de solo lectura, sin contador', () => {
                renderCantidad({ ...BASE, promocionId: 77 });

                expect(screen.queryByLabelText('increase')).not.toBeInTheDocument();
                expect(screen.getByRole('textbox')).toHaveAttribute('readonly');
                expect(tarjeta({ ...BASE, promocionId: 77 })).toMatchObject({ isQuantityReadOnly: true, quantityHints: [] });
            });

            it('sin promoción la cantidad se edita con contador', () => {
                renderCantidad(BASE);

                expect(screen.getByLabelText('increase')).toBeInTheDocument();
                expect(screen.getByLabelText('reduce')).toBeInTheDocument();
                expect(tarjeta(BASE).isQuantityReadOnly).toBe(false);
            });

            it('no deja subir de la existencia en una sucursal normal', () => {
                renderCantidad({ ...BASE, cantidad: 10, existencias: 10 });

                // El botón ya no va `disabled`: queda enfocable para su tooltip y se marca
                // con `aria-disabled`, igual que el de disminuir.
                expect(screen.getByLabelText('increase')).toHaveAttribute('aria-disabled', 'true');
                expect(tarjeta({ ...BASE, cantidad: 10, existencias: 10 }).disabledIncrease).toBe(true);
            });

            it('el precio especial fija el piso para bajar, y el motivo se ve', async () => {
                const row = { ...BASE, cantidad: 2, precioEspecialId: 5, cantidadPrecioEspecial: 2 };
                renderCantidad(row);
                const reduce = screen.getByLabelText('reduce');

                expect(reduce).toHaveAttribute('aria-disabled', 'true');
                const motivo = await leerTooltip(reduce);
                expect(motivo).toBe(NOTIFICATIONS_CHECKOUT.MINI_CHECKOUT.TOOLTIP_DECREASE_BY_SPECIAL_PRICE);

                const article = tarjeta(row);
                expect(article).toMatchObject({ min: 2, disabledDecrease: true, decreaseTooltip: motivo });
                expect(article.quantityHints).toContain(motivo);
            });

            it('los KMS aplicados fijan el piso en la cantidad original', () => {
                const row = { ...BASE, cantidad: 3, cantidadOriginal: 3 };
                renderCantidad(row, { hasKms: true });

                expect(screen.getByLabelText('reduce')).toHaveAttribute('aria-disabled', 'true');
                expect(tarjeta(row, [], { hasKms: true })).toMatchObject({
                    min: 3,
                    disabledDecrease: true,
                    decreaseTooltip: NOTIFICATIONS_CHECKOUT.MINI_CHECKOUT.TOOLTIP_DECREASE_BY_APPLIED_KMS,
                });
            });

            it('sin regla que lo bloquee, el contador no lleva motivos', () => {
                expect(tarjeta(BASE).quantityHints).toEqual([]);
            });
        });
    });
});
