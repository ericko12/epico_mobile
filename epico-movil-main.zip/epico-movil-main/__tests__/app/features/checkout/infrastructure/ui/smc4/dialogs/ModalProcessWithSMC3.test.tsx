import React from 'react';
import { render, screen, fireEvent, act, within } from '@testing-library/react';
import { ModalProcessWithSMC3 } from '@/features/checkout/infrastructure/ui/smc4/dialogs/ModalProcessWithSMC3';
import { useAppSelector } from '@/features/common/application/redux/hooks';
import { SwitchToSMC3ReasonEnum } from '@/features/checkout/domain/enums/SwitchToSMC3ReasonEnum';

jest.mock('@/features/common/application/redux/hooks');

const mockShowSnackbar = jest.fn();
jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: mockShowSnackbar }),
}));

const mockPostSwitchToSMC3Log = jest.fn();
const mockGetSwitchToSMC3Reasons = jest.fn();
jest.mock('@/features/checkout/application/service/checkout.services', () => ({
    checkoutServices: () => ({ getSwitchToSMC3Reasons: mockGetSwitchToSMC3Reasons, postSwitchToSMC3Log: mockPostSwitchToSMC3Log }),
}));

const buildState = (lastEvaluationPedidoId = 100) => ({
    sessionState: {
        checkOutsState: { selectedOrderSummary: { pedidoID: 100 } },
        shipmentState: {
            miniCheckoutSMC4State: {
                resultSMC4: { uuid: 'uuid-result' },
                lastEvaluation: {
                    pedidoId: lastEvaluationPedidoId,
                    uuid: 'uuid-trace',
                    request: '{"pedido":{"pedidoId":100}}',
                    response: '{"id":"uuid-trace"}',
                },
            },
        },
    },
    localState: { authState: { userAuth: { userId: 7, employeeId: 55 } } },
});

const selectReason = (label: string) => {
    fireEvent.mouseDown(screen.getByRole('combobox'));
    fireEvent.click(within(screen.getByRole('listbox')).getByText(label));
};

const typeObservation = (text: string) => {
    const input = screen.getByLabelText(/Observación/);
    fireEvent.change(input, { target: { value: text } });
    fireEvent.blur(input);
};

const BACKEND_REASONS = [
    { motivoId: 1, descripcion: 'Las opciones mostradas están muy lejanas al cliente', activo: true },
    { motivoId: 2, descripcion: 'El cliente pide que se le envíe de otra sucursal', activo: true },
    { motivoId: 3, descripcion: 'Otro', activo: true },
];

describe('ModalProcessWithSMC3', () => {
    const onClose = jest.fn();
    const onConfirm = jest.fn();

    const renderModal = async () => {
        await act(async () => {
            render(<ModalProcessWithSMC3 open={true} onClose={onClose} onConfirm={onConfirm} />);
        });
    };

    beforeEach(() => {
        jest.clearAllMocks();
        (useAppSelector as jest.Mock).mockImplementation((selector: (state: unknown) => unknown) => selector(buildState()));
        mockPostSwitchToSMC3Log.mockResolvedValue({ statusCode: 201, data: 1, huboError: false, error: { mensaje: '', erroresValidaciones: [] } });
        mockGetSwitchToSMC3Reasons.mockResolvedValue({ statusCode: 200, data: BACKEND_REASONS, huboError: false, error: { mensaje: '', erroresValidaciones: [] } });
    });

    it('keeps "Continuar" disabled until reason and 3 words observation are captured', async () => {
        await renderModal();
        const btnContinue = screen.getByRole('button', { name: 'Continuar' });
        expect(btnContinue).toBeDisabled();

        selectReason('Otro');
        typeObservation('solo dos');
        expect(btnContinue).toBeDisabled();
        expect(screen.getByText('La observación debe tener al menos 3 palabras')).toBeInTheDocument();

        typeObservation('cliente pide recoger');
        expect(btnContinue).toBeEnabled();
    });

    it('does not count symbols as words', async () => {
        await renderModal();
        selectReason('Otro');
        typeObservation('uno - dos ...');
        expect(screen.getByRole('button', { name: 'Continuar' })).toBeDisabled();
    });

    it('sends the reason, observation, employee and SMC 4.0 trace and calls onConfirm', async () => {
        await renderModal();
        selectReason('Las opciones mostradas están muy lejanas al cliente');
        typeObservation('  la sucursal propuesta queda lejos  ');

        await act(async () => {
            fireEvent.click(screen.getByRole('button', { name: 'Continuar' }));
        });

        expect(mockPostSwitchToSMC3Log).toHaveBeenCalledWith(expect.objectContaining({
            pedidoId: 100,
            empleadoId: 55,
            usuarioId: 7,
            motivoId: SwitchToSMC3ReasonEnum.OPTIONS_TOO_FAR,
            observacion: 'la sucursal propuesta queda lejos',
            uuidSMC4: 'uuid-trace',
            requestSMC4: '{"pedido":{"pedidoId":100}}',
            responseSMC4: '{"id":"uuid-trace"}',
            fechaHora: expect.any(String),
        }));
        expect(onConfirm).toHaveBeenCalledTimes(1);
    });

    it('does not send a trace that belongs to another order', async () => {
        (useAppSelector as jest.Mock).mockImplementation((selector: (state: unknown) => unknown) => selector(buildState(999)));
        await renderModal();
        selectReason('Otro');
        typeObservation('uno dos tres');

        await act(async () => {
            fireEvent.click(screen.getByRole('button', { name: 'Continuar' }));
        });

        expect(mockPostSwitchToSMC3Log).toHaveBeenCalledWith(expect.objectContaining({
            uuidSMC4: 'uuid-result',
            requestSMC4: null,
            responseSMC4: null,
        }));
    });

    it('continues with SMC 3 and warns the user when the register fails', async () => {
        mockPostSwitchToSMC3Log.mockResolvedValue({ statusCode: 500, data: null, huboError: true, error: { mensaje: 'error', erroresValidaciones: [] } });
        mockGetSwitchToSMC3Reasons.mockResolvedValue({ statusCode: 200, data: BACKEND_REASONS, huboError: false, error: { mensaje: '', erroresValidaciones: [] } });
        await renderModal();
        selectReason('Otro');
        typeObservation('uno dos tres');

        await act(async () => {
            fireEvent.click(screen.getByRole('button', { name: 'Continuar' }));
        });

        expect(mockShowSnackbar).toHaveBeenCalledWith(expect.stringContaining('No fue posible registrar'), 'warning');
        expect(onConfirm).toHaveBeenCalledTimes(1);
    });

    it('shows only the active reasons returned by the backend', async () => {
        mockGetSwitchToSMC3Reasons.mockResolvedValue({
            statusCode: 200,
            data: [
                { motivoId: 2, descripcion: 'Motivo desde catálogo', activo: true },
                { motivoId: 3, descripcion: 'Motivo inactivo', activo: false },
            ],
            huboError: false,
            error: { mensaje: '', erroresValidaciones: [] },
        });
        await renderModal();
        fireEvent.mouseDown(screen.getByRole('combobox'));
        const listbox = within(screen.getByRole('listbox'));
        expect(listbox.getByText('Motivo desde catálogo')).toBeInTheDocument();
        expect(listbox.queryByText('Motivo inactivo')).not.toBeInTheDocument();
        expect(listbox.queryByText('Otro')).not.toBeInTheDocument();
    });

    it('keeps the local reasons when the catalog request fails', async () => {
        mockGetSwitchToSMC3Reasons.mockResolvedValue({ statusCode: 500, data: null, huboError: true, error: { mensaje: 'error', erroresValidaciones: [] } });
        await renderModal();
        fireEvent.mouseDown(screen.getByRole('combobox'));
        const listbox = within(screen.getByRole('listbox'));
        expect(listbox.getByText('Las opciones mostradas están muy lejanas al cliente')).toBeInTheDocument();
        expect(listbox.getByText('Otro')).toBeInTheDocument();
    });

    it('calls onClose when "Cancelar" is clicked', async () => {
        await renderModal();
        fireEvent.click(screen.getByRole('button', { name: 'Cancelar' }));
        expect(onClose).toHaveBeenCalledTimes(1);
        expect(mockPostSwitchToSMC3Log).not.toHaveBeenCalled();
    });
});
