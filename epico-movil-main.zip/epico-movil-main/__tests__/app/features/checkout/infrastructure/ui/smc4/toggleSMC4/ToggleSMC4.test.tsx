import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import ToggleSMC4 from '@/features/checkout/infrastructure/ui/smc4/toggleSMC4/ToggleSMC4';
import { useAppDispatch, useAppSelector } from '@/features/common/application/redux/hooks';
import { actionsAuth } from '@/features/auth/application/redux/authSlice';
import { setSMC4Preference } from '@/features/common/infrastructure/utils/smc4Preference';
import { resetStockSMC4Thunk } from '@/features/checkout/application/redux/checkOutThunks';
import { setResetSteps } from '@/features/shipment/application/redux/ShipmentSlice';

jest.mock('@/features/common/application/redux/hooks');

jest.mock('@/features/auth/application/redux/authSlice', () => ({
    actionsAuth: {
        setEngineSMC4: jest.fn((value) => ({ type: 'auth/setEngineSMC4', payload: value })),
    },
}));

jest.mock('@/features/common/infrastructure/utils/smc4Preference', () => ({
    setSMC4Preference: jest.fn(),
}));

jest.mock('@/features/checkout/application/redux/checkOutThunks', () => ({
    resetStockSMC4Thunk: jest.fn(() => () => Promise.resolve()),
}));

jest.mock('@/features/shipment/application/redux/ShipmentSlice', () => ({
    setResetSteps: jest.fn(() => ({ type: 'MOCK_RESET_STEP' })),
}));

const mockDispatch: jest.Mock = jest.fn((action) => {
    if (typeof action === 'function') return action(mockDispatch);
    return action;
});

const renderWithSelector = (engineSMC4 = false, permissionSMC4 = false) => {
    (useAppSelector as jest.Mock).mockImplementation((selector: any) =>
        selector({
            localState: {
                authState: {
                    userAuth: { engineSMC4, permissionSMC4 },
                },
            },
        })
    );
    return render(<ToggleSMC4 />);
};

describe('ToggleSMC4', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        (useAppDispatch as jest.Mock).mockReturnValue(mockDispatch);
    });

    it('renders "Usar SMC 4.0" label', () => {
        renderWithSelector();
        expect(screen.getByText('Usar SMC 4.0')).toBeInTheDocument();
    });

    it('switch is unchecked when engineSMC4 is false', () => {
        renderWithSelector(false);
        expect(screen.getByRole('checkbox')).not.toBeChecked();
    });

    it('switch is checked when engineSMC4 is true', () => {
        renderWithSelector(true);
        expect(screen.getByRole('checkbox')).toBeChecked();
    });

    it('switch is disabled when permissionSMC4 is true', () => {
        renderWithSelector(false, true);
        expect(screen.getByRole('checkbox')).toBeDisabled();
    });

    it('switch is enabled when permissionSMC4 is false', () => {
        renderWithSelector(false, false);
        expect(screen.getByRole('checkbox')).not.toBeDisabled();
    });

    it('activating switch dispatches setEngineSMC4(true), setSMC4Preference(true), resetStockSMC4Thunk and setResetSteps', async () => {
        renderWithSelector(false);

        await act(async () => {
            fireEvent.click(screen.getByRole('checkbox'));
        });

        expect(actionsAuth.setEngineSMC4).toHaveBeenCalledWith(true);
        expect(setSMC4Preference).toHaveBeenCalledWith(true);
        expect(resetStockSMC4Thunk).toHaveBeenCalled();
        expect(setResetSteps).toHaveBeenCalled();
    });

    it('deactivating switch dispatches setResetSteps, setSMC4Preference(false) and setEngineSMC4(false)', async () => {
        renderWithSelector(true);

        await act(async () => {
            fireEvent.click(screen.getByRole('checkbox'));
        });

        expect(setResetSteps).toHaveBeenCalled();
        expect(setSMC4Preference).toHaveBeenCalledWith(false);
        expect(actionsAuth.setEngineSMC4).toHaveBeenCalledWith(false);
    });

    it('resetStockSMC4Thunk is NOT called when deactivating', async () => {
        renderWithSelector(true);

        await act(async () => {
            fireEvent.click(screen.getByRole('checkbox'));
        });

        expect(resetStockSMC4Thunk).not.toHaveBeenCalled();
    });
});
