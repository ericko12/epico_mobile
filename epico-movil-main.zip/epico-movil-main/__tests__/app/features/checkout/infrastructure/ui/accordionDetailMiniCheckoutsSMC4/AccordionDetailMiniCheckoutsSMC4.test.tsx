import React from 'react';
import { render, screen } from '@testing-library/react';
import { GridColDef } from '@mui/x-data-grid';
import { AccordionDetailMiniCheckoutsSMC4 } from '@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4';
import { COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4 } from '@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/AccordionDetailMiniCheckoutsSMC4.data';
import { CHECKOUT_MESSAGES } from '@/features/checkout/domain/data/checkoutMessages.data';
import { ShippingMethodSMC4Enum } from '@/features/shipment/domain/enum/ShippingMethodSMC4Enum';
import useWindowDimensions from '@/features/common/infrastructure/hooks/getDimensions';
import { IMiniCheckoutDivision } from '@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision';
import { ICustomerPriceList } from '@/features/checkout/domain/interfaces/ICustomerPriceList';
import { GenericProduct } from '@/features/products/domain/interfaces/IGenericProductList';

/**
 * Detalle de la mini caja SMC4 (AccordionDetailMiniCheckoutsSMC4) en las dos
 * experiencias.
 *
 * En la 8ª sincronización el proyecto original le añadió a esta pantalla el aviso
 * "Incluye traspasos…" en la cabecera y el árbol de traspasos al pie de la tabla, y
 * cambió la columna de descripción. La rama móvil tiene su propia tarjeta y su
 * propia colocación de los traspasos, así que aquí se fija:
 *
 * - que la tarjeta resuelve la descripción con la misma regla que la columna;
 * - que los traspasos se montan una sola vez en cada experiencia (la rama móvil los
 *   coloca fuera del grid, y un descuido los pintaría dos veces);
 * - que los ajustes de la cabecera para 320px solo existen en móvil.
 */

jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: jest.fn(),
}));

const mockState = {
    sessionState: {
        checkOutsState: { selectedOrderSummary: { pedidoID: 1, clienteId: 10 } },
        shipmentState: {
            purchaseOrder: '',
            purchaseOrderError: false,
            formatoOrden: null,
            openPay: { MiniCheckoutsAll: {} },
            miniCheckoutDivision: { division: [] },
        },
        loyaltyPlanState: { customers: {} },
    },
    localState: {
        authState: {},
        telemarketingLeadState: { telemarketingLeads: {} },
    },
};

jest.mock('@/features/common/application/redux/hooks', () => ({
    useAppDispatch: () => jest.fn(),
    useAppSelector: (selector: (state: unknown) => unknown) => selector(mockState),
}));

jest.mock('@/features/shipment/application/redux/ShipmentSelectors', () => ({
    selectOrderShipmentById: () => () => undefined,
}));

jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));

jest.mock('@/features/checkout/application/service/checkout.services', () => ({
    checkoutServices: () => ({ postLogSmc4: jest.fn(), postOrderBranch: jest.fn(), getLinkStatus: jest.fn() }),
}));

jest.mock('@/features/orders/application/services/order.services', () => ({
    ordersService: () => ({ getPurchaseOrderRelation: jest.fn() }),
}));

jest.mock('@/features/loyaltyPlan/application/service/loyaltyPlanService', () => ({
    loyaltyPlanService: () => ({ getKmsConversion: jest.fn() }),
}));

jest.mock('@/features/openPay/application/services/paymentGateway.services', () => ({
    paymentGatewayService: () => ({ sendWebPay: jest.fn() }),
}));

jest.mock('@/features/products/application/service/product.services', () => ({
    ProductService: () => ({ InsertSpecialOrderTlc: jest.fn(), GetGenericsProductsTlcIds: jest.fn() }),
}));

jest.mock('@/features/common/application/handleRequestDto/handleRequestDto', () => ({
    handleRequestDto: jest.fn(),
}));

// El service worker (Serwist) no existe en jsdom: la cadena de imports lo alcanza por
// los thunks, y su paquete es ESM.
jest.mock('@/features/common/application/dbStoreMessage', () => ({ dbStoreMessage: jest.fn() }));

jest.mock('@/features/products/application/actions/fetchImageProducts', () => ({
    fetchImageProducts: jest.fn(),
}));

jest.mock('@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell', () => ({
    ImageCell: ({ producto }: { producto: string }) => <img alt={producto} data-testid="image-cell" />,
}));

// Lo que no es de esta prueba se sustituye por marcadores.
jest.mock('@/features/common/infrastructure/ui/tables/DataGridServerPagination', () => ({
    DataGridServerPagination: () => <div data-testid="data-grid" />,
}));

jest.mock('@/features/common/infrastructure/ui/accordion/accordionDetailsTransfer/AccordionDetailsTransfer', () => ({
    AccordionDetailsTransfer: () => <div data-testid="transfers" />,
}));

jest.mock('@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/accordionSubSummary/AccordionSubSummary', () => ({
    AccordionSubSummary: () => null,
}));

jest.mock('@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/miniCheckoutSummarySMC4/MiniCheckoutSummarySMC4', () => ({
    MiniCheckoutSummarySMC4: () => null,
}));

jest.mock('@/features/orders/infraestructure/ui/modalPurchaseOrders/ModalPurchaseOrder', () => ({ ModalPurchaseOrder: () => null }));
jest.mock('@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/ModalSendOrderSMC4', () => ({ ModalSendOrderSMC4: () => null }));
jest.mock('@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/ModalConfirmSMC4', () => ({ ModalConfirmSMC4: () => null }));
jest.mock('@/features/orders/infraestructure/ui/orderPlaced/OrderPlacedCorrectly', () => ({ __esModule: true, default: () => null }));
jest.mock('@/features/orders/infraestructure/ui/orderPlaced/OrderPlacedError', () => ({ __esModule: true, default: () => null }));
jest.mock('@/features/orders/infraestructure/ui/modalEndedOrder/ModalEndedOrder', () => ({ __esModule: true, default: () => null }));
jest.mock('@/features/common/infrastructure/ui/dialog/ModalGeneric', () => ({ ModalGeneric: () => null }));

const mockedDimensions = useWindowDimensions as jest.Mock;

const ROW = {
    id: 1,
    productoId: 77,
    producto: '1394000',
    descripcion: 'DESCRIPCION DE LA FILA',
    cantidad: 2,
    importeConIva: 1248.5,
    gratis: false,
    promocionId: null,
    tipoPromocionId: 0,
    precioEspecialId: 0,
};

const TRASPASO = {
    infoSucursalId: 2,
    sucursal: 'SUCURSAL NORTE',
    metodoEnvio: ShippingMethodSMC4Enum.Delivery,
    requiereTraspaso: true,
    concentrarPedido: false,
    esTransitorio: false,
    articulos: [{ productoId: 77, sku: '1394000', cantidad: 1, descripcion: 'x' }],
    traspasos: [],
};

const buildCheckout = (overrides: Partial<Record<string, unknown>> = {}): IMiniCheckoutDivision => ({
    pedidoDivididoId: 5,
    infoSucursalId: 1,
    sucursal: 'SUCURSAL CENTRO',
    metodoEnvio: ShippingMethodSMC4Enum.Delivery,
    enviado: false,
    concentrarPedido: true,
    total: 12345.67,
    subTotal: 10000,
    ivaTotal: 1600,
    puntosAplicadosPlanLealtad: 0,
    detalles: [ROW],
    traspasos: [TRASPASO],
    ...overrides,
} as unknown as IMiniCheckoutDivision);

const renderAccordion = (
    checkoutInfo: IMiniCheckoutDivision = buildCheckout(),
    genericProductsDescriptions: GenericProduct[] = [],
) =>
    render(
        <AccordionDetailMiniCheckoutsSMC4
            checkoutInfo={checkoutInfo}
            customerPriceList={{} as ICustomerPriceList}
            genericProductsDescriptions={genericProductsDescriptions}
        />
    );

/** Texto que pinta la columna de escritorio para una fila, fuera del DataGrid. */
const columnText = (genericos: GenericProduct[], field: string, row: Record<string, unknown>): string => {
    const col = COLUMNS_ACCORDION_DETAIL_MINI_CHECKOUTS_SMC4(genericos).find((c: GridColDef) => c.field === field)!;
    const { container, unmount } = render(<div>{col.renderCell!({ row, value: row[field], field } as never)}</div>);
    const text = container.textContent ?? '';
    unmount();
    return text;
};

describe('AccordionDetailMiniCheckoutsSMC4', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    describe('tarjeta móvil: mismos datos que la columna', () => {
        it('en móvil los artículos son tarjetas, no DataGrid', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            renderAccordion();

            expect(screen.queryByTestId('data-grid')).not.toBeInTheDocument();
            expect(screen.getByText('DESCRIPCION DE LA FILA')).toBeInTheDocument();
            expect(screen.getByText(ROW.producto)).toBeInTheDocument();
        });

        it('la descripción del genérico gana, igual que en la columna', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            const genericos = [{ producto: '1394000', descripcion: 'CINTA AISLANTE NEGRO 60 PIES' }] as GenericProduct[];
            renderAccordion(buildCheckout(), genericos);

            expect(columnText(genericos, 'descripcion', ROW)).toBe('CINTA AISLANTE NEGRO 60 PIES');
            expect(screen.getByText('CINTA AISLANTE NEGRO 60 PIES')).toBeInTheDocument();
            expect(screen.queryByText('DESCRIPCION DE LA FILA')).not.toBeInTheDocument();
        });

        /**
         * Desde la 8ª sincronización la columna de descripción compara con `===` y la de
         * imagen sigue con `==`. Con un código que llega como número, la columna ya no
         * toma la descripción del genérico (sí su imagen): la tarjeta tiene que hacer
         * exactamente lo mismo.
         */
        it('con el código como número: descripción de la fila e imagen del genérico, como la tabla', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            const genericos = [{ producto: 1394000, descripcion: 'CINTA AISLANTE NEGRO 60 PIES', imagenUrl: 'https://x/1394000.jpg' }] as unknown as GenericProduct[];
            const { container } = renderAccordion(buildCheckout(), genericos);

            expect(columnText(genericos, 'descripcion', ROW)).toBe('DESCRIPCION DE LA FILA');
            expect(screen.getByText('DESCRIPCION DE LA FILA')).toBeInTheDocument();
            expect(screen.queryByText('CINTA AISLANTE NEGRO 60 PIES')).not.toBeInTheDocument();
            expect(container.querySelector('img[src="https://x/1394000.jpg"]')).toBeInTheDocument();
        });
    });

    describe('árbol de traspasos: una sola vez en cada experiencia', () => {
        it.each([
            ['móvil', true],
            ['escritorio', false],
        ])('%s: se monta una vez con envío a domicilio y traspasos', (_, isMobileExperience) => {
            mockedDimensions.mockReturnValue({ isMobileExperience });
            renderAccordion();

            expect(screen.getAllByTestId('transfers')).toHaveLength(1);
        });

        it.each([
            ['móvil', true],
            ['escritorio', false],
        ])('%s: no se monta en pickup', (_, isMobileExperience) => {
            mockedDimensions.mockReturnValue({ isMobileExperience });
            renderAccordion(buildCheckout({ metodoEnvio: ShippingMethodSMC4Enum.Pickup }));

            expect(screen.queryByTestId('transfers')).not.toBeInTheDocument();
        });

        it('móvil: los traspasos van debajo de las tarjetas', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            renderAccordion();

            const tarjeta = screen.getByText('DESCRIPCION DE LA FILA');
            const traspasos = screen.getByTestId('transfers');
            expect(tarjeta.compareDocumentPosition(traspasos) & Node.DOCUMENT_POSITION_FOLLOWING).toBeTruthy();
        });
    });

    describe('cabecera a 320px', () => {
        it('el aviso de traspasos se ve en las dos experiencias', () => {
            for (const isMobileExperience of [true, false]) {
                mockedDimensions.mockReturnValue({ isMobileExperience });
                const { unmount } = renderAccordion();
                expect(screen.getByText(CHECKOUT_MESSAGES.includesTransfersWarning)).toBeInTheDocument();
                unmount();
            }
        });

        it('sin concentrar pedido no hay aviso', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            renderAccordion(buildCheckout({ concentrarPedido: false }));

            expect(screen.queryByText(CHECKOUT_MESSAGES.includesTransfersWarning)).not.toBeInTheDocument();
        });

        /**
         * La etiqueta del Chip se ajusta desde la raíz (`& .MuiChip-label`), una regla
         * más específica que la de MUI. jsdom no resuelve la especificidad al calcular
         * `white-space` (aplica la última regla que coincide, la de MUI), así que aquí
         * se lee la regla que emite el `sx`, que es la que gana en el navegador.
         */
        const labelOverride = (label: HTMLElement): CSSStyleDeclaration | undefined => {
            const rootClass = [...label.parentElement!.classList].find((c) => c.startsWith('css-'));
            const rules = [...document.styleSheets].flatMap((sheet) => [...sheet.cssRules]) as CSSStyleRule[];
            return rules.find((rule) => rule.selectorText === `.${rootClass} .MuiChip-label`)?.style;
        };

        it('móvil: la etiqueta del aviso envuelve en vez de recortarse', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            renderAccordion();

            const label = screen.getByText(CHECKOUT_MESSAGES.includesTransfersWarning);
            expect(labelOverride(label)?.getPropertyValue('white-space')).toBe('normal');
            expect(label.parentElement).toHaveStyle({ height: 'auto' });
        });

        it('escritorio: la etiqueta del aviso queda como en el original (un renglón)', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: false });
            renderAccordion();

            const label = screen.getByText(CHECKOUT_MESSAGES.includesTransfersWarning);
            // La regla existe (el original ya fija el peso de la etiqueta), pero sin
            // tocar `white-space`: queda el `nowrap` de MUI.
            expect(labelOverride(label)).toBeDefined();
            expect(labelOverride(label)?.getPropertyValue('white-space')).toBe('');
            expect(label).toHaveStyle({ whiteSpace: 'nowrap' });
            expect(label.parentElement).not.toHaveStyle({ height: 'auto' });
        });

        it('móvil: el total puede bajar de renglón y se queda a la derecha', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: true });
            renderAccordion();

            const fila = screen.getByText('(2 ARTÍCULOS)').parentElement!;
            expect(fila).toHaveStyle({ flexWrap: 'wrap' });
            expect(fila.children[1]).toHaveStyle({ marginLeft: 'auto' });
        });

        it('escritorio: la fila del total no envuelve, como en el original', () => {
            mockedDimensions.mockReturnValue({ isMobileExperience: false });
            renderAccordion();

            const fila = screen.getByText('(2 ARTÍCULOS)').parentElement!;
            expect(fila).not.toHaveStyle({ flexWrap: 'wrap' });
            expect(fila.children[1]).not.toHaveStyle({ marginLeft: 'auto' });
        });
    });
});
