import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import { ModalRememberSMC4 } from '@/features/checkout/infrastructure/ui/smc4/dialogs/ModalRememberSMC4';
import { useAppDispatch } from '@/features/common/application/redux/hooks';
import { actionsAuth } from '@/features/auth/application/redux/authSlice';
import { setSMC4Preference } from '@/features/common/infrastructure/utils/smc4Preference';
import { resetStockSMC4Thunk } from '@/features/checkout/application/redux/checkOutThunks';
import { BENEFITS_SMC4 } from '@/features/checkout/infrastructure/ui/smc4/dialogs/ModalRememberSMC4.data';

jest.mock('@/features/common/application/redux/hooks');

jest.mock('@/features/auth/application/redux/authSlice', () => ({
    actionsAuth: {
        setEngineSMC4: jest.fn((value) => ({ type: 'auth/setEngineSMC4', payload: value })),
    },
}));

jest.mock('@/features/common/infrastructure/utils/smc4Preference', () => ({
    setSMC4Preference: jest.fn(),
}));

jest.mock('@/features/checkout/application/redux/checkOutThunks', () => ({
    resetStockSMC4Thunk: jest.fn(() => () => Promise.resolve()),
}));

jest.mock('next/image', () => (props: React.ImgHTMLAttributes<HTMLImageElement>) => (
    // eslint-disable-next-line @next/next/no-img-element
    <img {...props} alt={props.alt ?? ''} />
));

const mockDispatch: jest.Mock = jest.fn((action) => {
    if (typeof action === 'function') return action(mockDispatch);
    return action;
});

describe('ModalRememberSMC4', () => {
    const onClose = jest.fn();
    const onActivate = jest.fn();

    beforeEach(() => {
        jest.clearAllMocks();
        (useAppDispatch as jest.Mock).mockReturnValue(mockDispatch);
    });

    it('does not render content when open is false', () => {
        render(<ModalRememberSMC4 open={false} onClose={onClose} onActivate={onActivate} />);
        expect(
            screen.queryByText('Ya está aquí la nueva versión de Sucursal Más Cercana')
        ).not.toBeInTheDocument();
    });

    it('renders modal title when open is true', () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);
        expect(
            screen.getByText('Ya está aquí la nueva versión de Sucursal Más Cercana')
        ).toBeInTheDocument();
    });

    it('renders "Ahora no" and "Activar SMC 4.0" buttons', () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);
        expect(screen.getByRole('button', { name: 'Ahora no' })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Activar SMC 4.0' })).toBeInTheDocument();
    });

    it('calls onClose when "Ahora no" is clicked', () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);
        fireEvent.click(screen.getByRole('button', { name: 'Ahora no' }));
        expect(onClose).toHaveBeenCalledTimes(1);
    });

    it('activating SMC4 dispatches setEngineSMC4(true), setSMC4Preference(true), resetStockSMC4Thunk and calls onActivate', async () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);

        await act(async () => {
            fireEvent.click(screen.getByRole('button', { name: 'Activar SMC 4.0' }));
        });

        expect(actionsAuth.setEngineSMC4).toHaveBeenCalledWith(true);
        expect(setSMC4Preference).toHaveBeenCalledWith(true);
        expect(resetStockSMC4Thunk).toHaveBeenCalled();
        expect(onActivate).toHaveBeenCalledTimes(1);
    });

    it('renders all benefits from BENEFITS_SMC4', () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);
        BENEFITS_SMC4.forEach((benefit) => {
            expect(screen.getByText(benefit)).toBeInTheDocument();
        });
    });

    it('renders deactivation info text', () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);
        expect(
            screen.getByText(/Podrás desactivar SMC 4\.0 y regresar a SMC 3/i)
        ).toBeInTheDocument();
    });

    it('does not call onClose when "Activar SMC 4.0" is clicked', async () => {
        render(<ModalRememberSMC4 open={true} onClose={onClose} onActivate={onActivate} />);

        await act(async () => {
            fireEvent.click(screen.getByRole('button', { name: 'Activar SMC 4.0' }));
        });

        expect(onClose).not.toHaveBeenCalled();
    });
});
