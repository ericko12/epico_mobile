import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { FormSendOrder } from '@/features/checkout/infrastructure/ui/accordionDetailMiniCheckoutsSMC4/dialogs/forms/FormSendOrder';
import { CHECKOUT_MESSAGES } from '@/features/checkout/domain/data/checkoutMessages.data';
import { SplitBill } from '@/features/common/domain/enums/SplitBill';
import useWindowDimensions from '@/features/common/infrastructure/hooks/getDimensions';
import { IMiniCheckoutDivision } from '@/features/shipment/domain/interfaces/miniCheckoutSMC4/IMiniCeckoutDivision';

/**
 * FormSendOrder (envío de la mini caja SMC4) en la experiencia móvil.
 *
 * El proyecto original bloqueó "Dividir facturas" cuando la mini caja incluye
 * traspasos y explica el motivo en un Tooltip. En táctil no hay hover: el aviso
 * tiene que verse a la vista en móvil, con el mismo texto, y escritorio no cambia.
 */

jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: jest.fn(),
}));

const mockState = {
    sessionState: {
        checkOutsState: { selectedOrderSummary: { pedidoID: 1, clienteId: 10 } },
        shipmentState: { purchaseOrder: '', openPay: { MiniCheckoutsAll: {} } },
    },
};

jest.mock('@/features/common/application/redux/hooks', () => ({
    useAppSelector: (selector: (state: unknown) => unknown) => selector(mockState),
}));

jest.mock('@/features/shipment/application/redux/ShipmentSelectors', () => ({
    selectOrderShipmentById: () => () => undefined,
}));

jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));

jest.mock('@/features/openPay/application/services/paymentGateway.services', () => ({
    paymentGatewayService: () => ({ getLinkStatus: jest.fn().mockResolvedValue({ data: [] }) }),
}));

jest.mock('@/features/branch/application/actions/securityProjectService', () => ({
    SecurityProjectService: () => ({ ProjectActiveInSucursal: jest.fn().mockResolvedValue({ data: false }) }),
}));

jest.mock('@/features/common/application/handleRequestDto/handleRequestDto', () => ({
    handleRequestDto: jest.fn().mockResolvedValue(false),
}));

jest.mock('@/features/checkout/infrastructure/ui/sendCheckout/SendLinkOpenPayMiniCheckOutSMC4/SendLinkOpenPayMiniCheckOutSMC4', () => ({
    SendLinkOpenPayMiniCheckOutSMC4: () => null,
}));

const mockedDimensions = useWindowDimensions as jest.Mock;

const buildCheckout = (traspasos: unknown[] | null): IMiniCheckoutDivision => ({
    pedidoDivididoId: 5,
    infoSucursalId: 1,
    sucursal: 'SUCURSAL CENTRO',
    total: 8000,
    traspasos,
} as unknown as IMiniCheckoutDivision);

const renderForm = (traspasos: unknown[] | null) =>
    render(
        <FormSendOrder
            checkoutInfo={buildCheckout(traspasos)}
            formData={{ split: SplitBill.none, comment: '' }}
            setFormData={jest.fn()}
            handleChange={jest.fn()}
            checked={false}
            setChecked={jest.fn()}
        />
    );

describe('FormSendOrder — aviso de facturas sin dividir por traspasos', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('en móvil pinta a la vista el motivo, con el mismo texto del tooltip', async () => {
        mockedDimensions.mockReturnValue({ isMobileExperience: true });
        renderForm([{ infoSucursalId: 2 }]);

        expect(await screen.findByText(CHECKOUT_MESSAGES.cannotSplitWithTransfers)).toBeInTheDocument();
    });

    it('en escritorio no añade nada: el motivo sigue solo en el tooltip', async () => {
        mockedDimensions.mockReturnValue({ isMobileExperience: false });
        renderForm([{ infoSucursalId: 2 }]);

        await waitFor(() => expect(screen.getByText('Dividir facturas')).toBeInTheDocument());
        expect(screen.queryByText(CHECKOUT_MESSAGES.cannotSplitWithTransfers)).not.toBeInTheDocument();
    });

    it('en móvil sin traspasos no hay aviso', async () => {
        mockedDimensions.mockReturnValue({ isMobileExperience: true });
        renderForm([]);

        await waitFor(() => expect(screen.getByText('Dividir facturas')).toBeInTheDocument());
        expect(screen.queryByText(CHECKOUT_MESSAGES.cannotSplitWithTransfers)).not.toBeInTheDocument();
    });

    it('con traspasos las tres opciones de división quedan deshabilitadas también en móvil', async () => {
        mockedDimensions.mockReturnValue({ isMobileExperience: true });
        renderForm([{ infoSucursalId: 2 }]);

        await screen.findByText(CHECKOUT_MESSAGES.cannotSplitWithTransfers);
        expect(screen.getByLabelText('No dividir')).toBeDisabled();
        expect(screen.getByLabelText('Montos de $2,000.00')).toBeDisabled();
        expect(screen.getByLabelText('Montos de $5,000.00')).toBeDisabled();
    });
});
