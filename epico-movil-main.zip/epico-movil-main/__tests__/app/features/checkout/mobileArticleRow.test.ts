import { resolveMobileArticleRow, IMobileArticleRowInput } from '@/features/checkout/infrastructure/ui/checkoutDetail/mobileArticleRow';
import { IOrderSummaryDetail } from '@/features/checkout/domain/interfaces/IOrderSummaryDetail';
import { PriceType } from '@/features/common/infrastructure/utils/priceUtils';

/**
 * El renglón compacto del detalle de la caja en móvil muestra un resumen de lo que la
 * hoja de edición enseña completo. Lo que se resume tiene que decir la verdad: un
 * artículo que se paga con Kms no puede verse igual que uno que se cobra en dinero, y la
 * marca de existencia insuficiente tiene que seguir la misma regla que pinta la fila roja
 * en escritorio. Eso es lo que fijan estos casos.
 */
describe('resolveMobileArticleRow', () => {
    const ARTICULO = {
        pedidoDetalleId: 1,
        producto: '1394000',
        descripcion: 'CINTA AISLANTE NEGRO 60 PIES PLASTICA',
        cantidad: 3,
        importeIVA: 179.88,
        promocionID: 0,
        precioEspecialId: 0,
        gratis: false,
        pickUp: false,
        ahorroPorcentaje: 0,
        stockEnSucursal: 50,
        stockNacional: 500,
        stockEnSMC: 50,
    } as unknown as IOrderSummaryDetail;

    const BASE: IMobileArticleRowInput = {
        detail: ARTICULO,
        engineSMC4: false,
        mostrarExistenciasSMC4: false,
        pendingStockNational: false,
        kmsAplicados: false,
        pagoTotalConKms: false,
        kmsDelArticulo: 0,
    };

    const resolver = (extra: Partial<IMobileArticleRowInput> = {}, detail: Partial<IOrderSummaryDetail> = {}) =>
        resolveMobileArticleRow({ ...BASE, ...extra, detail: { ...ARTICULO, ...detail } as IOrderSummaryDetail });

    describe('descripción', () => {
        it('la del genérico gana sobre la de la fila', () => {
            expect(resolver({ descripcionGenerico: 'DESCRIPCIÓN DEL GENÉRICO' }).descripcion)
                .toBe('DESCRIPCIÓN DEL GENÉRICO');
        });

        it('cae a la de la fila cuando el genérico no trae descripción', () => {
            expect(resolver({ descripcionGenerico: null }).descripcion)
                .toBe('CINTA AISLANTE NEGRO 60 PIES PLASTICA');
        });
    });

    describe('pago con Kms', () => {
        it('sin Kms aplicados muestra el importe normal y no lo tacha', () => {
            const row = resolver();

            expect(row.importe).toBe(179.88);
            expect(row.kmsAplicados).toBe(false);
            expect(row.importeTachado).toBe(false);
        });

        it('con pago total en Kms tacha el importe y usa el valor recalculado', () => {
            const row = resolver({
                kmsAplicados: true,
                pagoTotalConKms: true,
                importeConKms: 0,
                kmsDelArticulo: 5996,
            });

            expect(row.importeTachado).toBe(true);
            expect(row.importe).toBe(0);
            expect(row.kms).toBe(5996);
        });

        it('con pago parcial marca los Kms pero no tacha el importe', () => {
            const row = resolver({ kmsAplicados: true, pagoTotalConKms: false, kmsDelArticulo: 2000 });

            expect(row.kmsAplicados).toBe(true);
            expect(row.importeTachado).toBe(false);
            expect(row.importe).toBe(179.88);
        });
    });

    describe('distintivos', () => {
        it('reconoce promoción, precio especial y regalo', () => {
            const row = resolver({}, { promocionID: 77, precioEspecialId: 5, gratis: true, ahorroPorcentaje: 15 });

            expect(row.tienePromocion).toBe(true);
            expect(row.tienePrecioEspecial).toBe(true);
            expect(row.esRegalo).toBe(true);
            expect(row.ahorro).toBe(15);
        });

        it('el distintivo de pickup exclusivo solo aplica con SMC 4.0', () => {
            expect(resolver({ engineSMC4: false }, { pickUp: true }).esPickupExclusivo).toBe(false);
            expect(resolver({ engineSMC4: true }, { pickUp: true }).esPickupExclusivo).toBe(true);
        });

        it('marca el mejor precio solo cuando el tipo de precio es Final', () => {
            expect(resolver({}, { tipoPrecio: PriceType.Final }).tieneMejorPrecio).toBe(true);
            expect(resolver({}, { tipoPrecio: PriceType.Especial }).tieneMejorPrecio).toBe(false);
            expect(resolver({}, { tipoPrecio: PriceType.Promocion }).tieneMejorPrecio).toBe(false);
            expect(resolver({}, { tipoPrecio: null }).tieneMejorPrecio).toBe(false);
            expect(resolver().tieneMejorPrecio).toBe(false);
        });
    });

    describe('existencia insuficiente — misma regla que la fila roja de escritorio', () => {
        it('sin SMC 4.0 marca cuando la sucursal no alcanza', () => {
            expect(resolver({}, { stockEnSucursal: 2, cantidad: 3 }).existenciaInsuficiente).toBe(true);
        });

        it('sin SMC 4.0 marca también cuando la existencia SMC no alcanza', () => {
            expect(resolver({}, { stockEnSMC: 0 }).existenciaInsuficiente).toBe(true);
        });

        it('sin SMC 4.0 no marca cuando ambas alcanzan', () => {
            expect(resolver().existenciaInsuficiente).toBe(false);
        });

        it('con SMC 4.0 manda la existencia nacional', () => {
            const input = { engineSMC4: true, mostrarExistenciasSMC4: true };

            expect(resolver(input, { stockNacional: 1, cantidad: 3, stockEnSucursal: 999 }).existenciaInsuficiente).toBe(true);
            expect(resolver(input, { stockNacional: 999, cantidad: 3, stockEnSucursal: 0 }).existenciaInsuficiente).toBe(false);
        });

        it('con SMC 4.0 no marca mientras las existencias nacionales se están cargando', () => {
            const row = resolver(
                { engineSMC4: true, mostrarExistenciasSMC4: true, pendingStockNational: true },
                { stockNacional: 0 }
            );

            expect(row.existenciaInsuficiente).toBe(false);
        });

        it('con SMC 4.0 no marca si las existencias no se están mostrando', () => {
            const row = resolver({ engineSMC4: true, mostrarExistenciasSMC4: false }, { stockNacional: 0 });

            expect(row.existenciaInsuficiente).toBe(false);
        });
    });
});
