import React from 'react';
import { act, fireEvent, render, screen, within } from '@testing-library/react';
import { IProduct } from '@/features/products/domain/interfaces/IProduct';
import { Compatibility } from '@/features/products/domain/interfaces/ICompatibilityCar';

/**
 * Visto en producción: al entrar al detalle desde el catálogo la pestaña APLICACIONES
 * salía «sin información», y desde un producto relacionado sí cargaba.
 *
 * El detalle hereda `tieneAplicaciones` de la tarjeta de origen (ProductDetailsView la
 * conserva), y con el buscador nuevo esa bandera podía llegar en falso para productos
 * que sí tienen aplicaciones. La pestaña se fiaba de ella para decidir si preguntar.
 *
 * Estos casos fijan el comportamiento de `useProductApplications` dentro de la pestaña:
 * pregunta a VehiculosCompatibles al abrir APLICACIONES, una vez por producto, sin
 * mirar la bandera, y pinta lo que responda.
 */

let state: { sessionState: { productState: { productSelected: IProduct | null } } };
const getCompatibilityCar = jest.fn();
const vacio = () => Promise.resolve({ statusCode: 204, data: null, huboError: false, error: { mensaje: '' } });

jest.mock('@/features/common/application/redux/hooks', () => ({
    useAppSelector: (selector: (s: typeof state) => unknown) => selector(state),
}));
jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));
jest.mock('@/features/products/application/service/product.services', () => ({
    ProductService: () => ({
        getCompatibilityCar,
        getProductTechnicalSheet: vacio,
        sendProductTechnicalSheet: vacio,
        sendProductOtherDocuments: vacio,
        getProductReferences: vacio,
    }),
}));
// El acordeón real no se prueba aquí: solo qué aplicaciones le llegan. Con una lista
// vacía el real no pinta nada, y por eso la pestaña no debe llegar a montarlo así.
jest.mock('@/features/products/infrastructure/ui/productDetails/productDetailsAccordion/ProductDetailsAccordion', () => ({
    ProductDetailsAccordion: ({ applications }: { applications: Compatibility[] }) => (
        <div data-testid="acordeon">{applications.map((a) => a.armadora).join(',')}</div>
    ),
}));

// eslint-disable-next-line @typescript-eslint/no-require-imports
const { ProductDetailsTabs } = require('@/features/products/infrastructure/ui/productDetails/productTabs/ProductDetailsTabs');

const SIN_INFO = 'Información no disponible';

const producto = (productoID: number | undefined, tieneAplicaciones: boolean): IProduct =>
    ({ productoID, producto: String(productoID), descripcion: 'Balata', tieneAplicaciones } as IProduct);

const conArmadoras = (...nombres: string[]) => ({
    statusCode: 200,
    huboError: false,
    data: { armadoras: nombres.map((armadora, i) => ({ armadoraId: i + 1, armadora })) },
});
const sinContenido = { statusCode: 204, data: null, huboError: false };

const seleccionar = (p: IProduct | null) => { state.sessionState.productState.productSelected = p; };
const abrirAplicaciones = () => fireEvent.click(screen.getByText('APLICACIONES'));
const panel = () => within(screen.getByRole('tabpanel', { hidden: false }));
const esperarRespuestas = () => act(async () => { });

describe('ProductDetailsTabs — aplicaciones', () => {
    beforeEach(() => {
        getCompatibilityCar.mockReset();
        state = { sessionState: { productState: { productSelected: null } } };
    });

    it('con la bandera en falso pregunta igual y pinta lo que devuelve el servicio', async () => {
        // El caso de producción: la tarjeta del buscador nuevo trae `false` y el
        // producto sí tiene aplicaciones.
        seleccionar(producto(5942335, false));
        getCompatibilityCar.mockResolvedValue(conArmadoras('CHEVROLET'));

        render(<ProductDetailsTabs />);
        abrirAplicaciones();

        expect(getCompatibilityCar).toHaveBeenCalledWith(5942335);
        expect(await screen.findByTestId('acordeon')).toHaveTextContent('CHEVROLET');
    });

    it.each([
        ['bandera en falso', false],
        // Antes quedaba un panel en blanco: la bandera montaba el acordeón con una
        // lista vacía, que no pinta nada.
        ['bandera en verdadero', true],
    ])('sin aplicaciones en el servicio dice «sin información» (%s)', async (_caso, bandera) => {
        seleccionar(producto(1, bandera));
        getCompatibilityCar.mockResolvedValue(sinContenido);

        render(<ProductDetailsTabs />);
        abrirAplicaciones();
        await esperarRespuestas();

        expect(getCompatibilityCar).toHaveBeenCalledWith(1);
        expect(screen.queryByTestId('acordeon')).not.toBeInTheDocument();
        expect(panel().getByText(SIN_INFO)).toBeInTheDocument();
    });

    it('con la bandera en verdadero y aplicaciones, pinta el acordeón como siempre', async () => {
        seleccionar(producto(2, true));
        getCompatibilityCar.mockResolvedValue(conArmadoras('NISSAN'));

        render(<ProductDetailsTabs />);
        abrirAplicaciones();

        expect(await screen.findByTestId('acordeon')).toHaveTextContent('NISSAN');
    });

    it('mientras llega la respuesta enseña que carga, no «sin información»', async () => {
        let resolver: (v: unknown) => void = () => { };
        getCompatibilityCar.mockImplementation(() => new Promise((r) => { resolver = r; }));
        seleccionar(producto(3, false));

        render(<ProductDetailsTabs />);
        abrirAplicaciones();

        expect(panel().getByLabelText('Cargando aplicaciones')).toBeInTheDocument();
        expect(panel().queryByText(SIN_INFO)).not.toBeInTheDocument();

        await act(async () => { resolver(conArmadoras('MAZDA')); });
        expect(screen.getByTestId('acordeon')).toHaveTextContent('MAZDA');
    });

    it('no pregunta hasta que se abre la pestaña, y una sola vez por producto', async () => {
        // Preguntar al montar habría sumado una petición a cada detalle abierto.
        seleccionar(producto(4, true));
        getCompatibilityCar.mockResolvedValue(conArmadoras('KIA'));

        render(<ProductDetailsTabs />);
        await esperarRespuestas();
        expect(getCompatibilityCar).not.toHaveBeenCalled();

        abrirAplicaciones();
        await screen.findByTestId('acordeon');
        fireEvent.click(screen.getByText('DESCRIPCIÓN'));
        abrirAplicaciones();
        await screen.findByTestId('acordeon');

        expect(getCompatibilityCar).toHaveBeenCalledTimes(1);
    });

    it('el mismo producto con otro objeto (la versión completa de getProduct) no repite la petición', async () => {
        seleccionar(producto(5, false));
        getCompatibilityCar.mockResolvedValue(conArmadoras('HONDA'));
        const { rerender } = render(<ProductDetailsTabs />);
        abrirAplicaciones();
        await screen.findByTestId('acordeon');

        seleccionar({ ...producto(5, false), descripcion: 'Balata delantera' });
        rerender(<ProductDetailsTabs />);
        await esperarRespuestas();

        expect(getCompatibilityCar).toHaveBeenCalledTimes(1);
        expect(screen.getByTestId('acordeon')).toHaveTextContent('HONDA');
    });

    it('la respuesta tardía del producto anterior no pisa la del actual', async () => {
        // En el detalle se puede saltar a un relacionado antes de que llegue la respuesta.
        let resolverA: (v: unknown) => void = () => { };
        getCompatibilityCar.mockImplementation((id: number) =>
            id === 10
                ? new Promise((resolve) => { resolverA = resolve; })
                : Promise.resolve(conArmadoras('FORD'))
        );

        seleccionar(producto(10, true));
        const { rerender } = render(<ProductDetailsTabs />);
        abrirAplicaciones();

        seleccionar(producto(20, true));
        rerender(<ProductDetailsTabs />);
        expect(await screen.findByTestId('acordeon')).toHaveTextContent('FORD');

        await act(async () => { resolverA(conArmadoras('VOLKSWAGEN')); });
        expect(screen.getByTestId('acordeon')).toHaveTextContent('FORD');
        // Sin la guarda la respuesta vieja se guardaría como la última, la pestaña
        // dejaría de ver las del producto actual y volvería a pedirlas: un parpadeo y
        // una petición de más.
        expect(getCompatibilityCar).toHaveBeenCalledTimes(2);
    });

    it('al cambiar de producto no se quedan las aplicaciones del anterior', async () => {
        seleccionar(producto(30, true));
        getCompatibilityCar.mockResolvedValueOnce(conArmadoras('TOYOTA'));
        const { rerender } = render(<ProductDetailsTabs />);
        abrirAplicaciones();
        expect(await screen.findByTestId('acordeon')).toHaveTextContent('TOYOTA');

        getCompatibilityCar.mockResolvedValueOnce(sinContenido);
        seleccionar(producto(40, false));
        rerender(<ProductDetailsTabs />);
        await esperarRespuestas();

        expect(screen.queryByTestId('acordeon')).not.toBeInTheDocument();
        expect(panel().getByText(SIN_INFO)).toBeInTheDocument();
    });

    it('sin productoID no pregunta y dice «sin información»', async () => {
        seleccionar(producto(undefined, true));

        render(<ProductDetailsTabs />);
        abrirAplicaciones();
        await esperarRespuestas();

        expect(getCompatibilityCar).not.toHaveBeenCalled();
        expect(panel().getByText(SIN_INFO)).toBeInTheDocument();
    });

    it('un 404 es una respuesta: dice «sin información» y no reintenta', async () => {
        seleccionar(producto(60, true));
        getCompatibilityCar.mockResolvedValue({ statusCode: 404, data: null, huboError: true, error: { mensaje: 'No encontrado' } });

        render(<ProductDetailsTabs />);
        abrirAplicaciones();
        await esperarRespuestas();
        expect(panel().getByText(SIN_INFO)).toBeInTheDocument();

        fireEvent.click(screen.getByText('DESCRIPCIÓN'));
        abrirAplicaciones();
        await esperarRespuestas();
        expect(getCompatibilityCar).toHaveBeenCalledTimes(1);
    });

    it.each([
        ['sin red', 0],
        ['un 500', 500],
    ])('con %s dice que no se pudieron cargar y reintenta al volver a la pestaña', async (_caso, statusCode) => {
        // Antes se guardaba como «no tiene aplicaciones» hasta cambiar de producto.
        seleccionar(producto(70, true));
        getCompatibilityCar
            .mockResolvedValueOnce({ statusCode, data: null, huboError: true, error: { mensaje: 'error' } })
            .mockResolvedValueOnce(conArmadoras('AUDI'));

        render(<ProductDetailsTabs />);
        abrirAplicaciones();
        expect(await panel().findByText(/No se pudieron cargar las aplicaciones/)).toBeInTheDocument();
        expect(getCompatibilityCar).toHaveBeenCalledTimes(1);

        fireEvent.click(screen.getByText('DESCRIPCIÓN'));
        abrirAplicaciones();

        expect(await screen.findByTestId('acordeon')).toHaveTextContent('AUDI');
        expect(getCompatibilityCar).toHaveBeenCalledTimes(2);
    });
});

describe('useProductApplications', () => {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { useProductApplications } = require('@/features/products/infrastructure/hooks/useProductApplications');
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const { renderHook, waitFor } = require('@testing-library/react');

    beforeEach(() => getCompatibilityCar.mockReset());

    it('en StrictMode, con la pestaña abierta desde el inicio, se queda con la respuesta buena', async () => {
        // El doble efecto de desarrollo descarta la primera petición; la segunda es la
        // que cuenta y no se puede perder.
        getCompatibilityCar.mockResolvedValue(conArmadoras('SEAT'));

        const { result } = renderHook(() => useProductApplications(80, true), { wrapper: React.StrictMode });

        expect(result.current.cargando).toBe(true);
        await waitFor(() => expect(result.current.aplicaciones.map((a: Compatibility) => a.armadora)).toEqual(['SEAT']));
        expect(result.current.cargando).toBe(false);
        expect(result.current.fallo).toBe(false);
    });

    it('con la pestaña cerrada no pregunta ni dice que carga', () => {
        const { result } = renderHook(() => useProductApplications(90, false));

        expect(getCompatibilityCar).not.toHaveBeenCalled();
        expect(result.current).toEqual({ aplicaciones: [], cargando: false, fallo: false });
    });
});
