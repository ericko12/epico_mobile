import { REHYDRATE } from 'redux-persist';
import reducer, { setLoading, setProducts } from '@/features/products/application/redux/ProductSlice';

/**
 * `productState` se persiste completo en sessionStorage, incluida la bandera
 * transitoria `loadingProducts`. Estos casos fijan que no sobreviva a un reinicio.
 */
describe('ProductSlice - loadingProducts', () => {
    it('se enciende con setLoading y se apaga con setProducts', () => {
        const cargando = reducer(undefined, setLoading(true));
        expect(cargando.loadingProducts).toBe(true);

        const resuelto = reducer(cargando, setProducts([]));
        expect(resuelto.loadingProducts).toBe(false);
    });

    it('vuelve en false al rehidratar aunque se haya persistido en true', () => {
        // Escenario real: el usuario busca en el catálogo con datos móviles y la app
        // muere antes de la respuesta. sessionStorage guardó loadingProducts: true.
        const persistido = { products: [], loadingProducts: true };

        const estado = reducer(undefined, {
            type: REHYDRATE,
            payload: { productState: persistido },
        });

        expect(estado.loadingProducts).toBe(false);
    });

    it('conserva el resto del estado persistido al rehidratar', () => {
        const persistido = {
            products: [{ producto: 'ABC123' }],
            loadingProducts: true,
            viewList: true,
        };

        const estado = reducer(undefined, {
            type: REHYDRATE,
            payload: { productState: persistido },
        });

        expect(estado.products).toEqual([{ producto: 'ABC123' }]);
        expect(estado.viewList).toBe(true);
    });

    it('ignora un REHYDRATE sin productState (otro árbol persistido)', () => {
        const previo = reducer(undefined, setLoading(true));

        const estado = reducer(previo, {
            type: REHYDRATE,
            payload: { authState: { userAuth: null } },
        });

        expect(estado).toBe(previo);
    });
});
