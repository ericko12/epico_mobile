import React from 'react';
import { act, render, screen } from '@testing-library/react';
import { Compatibility } from '@/features/products/domain/interfaces/ICompatibilityCar';

/**
 * El modal de aplicaciones que abre el botón de la tarjeta. Ese botón se enciende con
 * la bandera `tieneAplicaciones`, que puede dar un falso positivo; sin aplicaciones el
 * modal quedaba en blanco. Ahora dice «sin información», pero solo cuando ya respondió
 * el servicio: antes de la respuesta no debe anunciar que no hay nada.
 */

const getCompatibilityCar = jest.fn();

jest.mock('@/features/products/application/service/product.services', () => ({
    ProductService: () => ({ getCompatibilityCar }),
}));
// `handleRequestDto` real pinta snackbars y maneja el 401; aquí solo importa que el
// éxito entregue las armadoras.
jest.mock('@/features/common/application/handleRequestDto/handleRequestDto', () => ({
    handleRequestDto: ({ response, onSuccess }: { response: { statusCode: number }; onSuccess?: () => void }) => {
        if (response.statusCode === 200) onSuccess?.();
    },
}));
jest.mock('@/features/common/infrastructure/ui/img/CachedImage', () => ({ CachedImage: () => null }));
jest.mock('@/features/products/application/actions/fetchImageProducts', () => ({ fetchImageProducts: jest.fn() }));
// Se cuenta cada vez que se pinta: el parpadeo dura un fotograma, entre el primer
// pintado y el efecto, y para cuando la prueba mira el DOM ya no está.
const pintadosSinInfo = jest.fn();
jest.mock('@/features/common/infrastructure/ui/view/NoInfoView/NoInfoView', () => ({
    NoInfoView: () => { pintadosSinInfo(); return <div>Información no disponible</div>; },
}));
jest.mock('@/features/products/infrastructure/ui/compatibility/compatibilityAccordion', () => ({
    CompatilibityAccordion: ({ compatibility }: { compatibility: Compatibility }) => <div data-testid="armadora">{compatibility.armadora}</div>,
}));

// eslint-disable-next-line @typescript-eslint/no-require-imports
const { VehiculeCompatibility } = require('@/features/products/infrastructure/ui/compatibility/vehiculeCompatibility/VehiculeCompatibility');

const SIN_INFO = 'Información no disponible';
const pintar = () => render(
    <VehiculeCompatibility id={1} onClose={jest.fn()} product="Balata" image="" productId="5942335" />
);

describe('VehiculeCompatibility — sin aplicaciones', () => {
    beforeEach(() => { getCompatibilityCar.mockReset(); pintadosSinInfo.mockReset(); });

    it('antes de la respuesta no dice «sin información»', async () => {
        let resolver: (v: unknown) => void = () => { };
        getCompatibilityCar.mockImplementation(() => new Promise((r) => { resolver = r; }));

        pintar();

        expect(pintadosSinInfo).not.toHaveBeenCalled();
        expect(screen.queryByText(SIN_INFO)).not.toBeInTheDocument();
        await act(async () => { resolver({ statusCode: 200, data: { armadoras: [{ armadoraId: 1, armadora: 'CHEVROLET' }] } }); });
        expect(screen.getByTestId('armadora')).toHaveTextContent('CHEVROLET');
    });

    it('con el servicio vacío dice «sin información» en vez de quedar en blanco', async () => {
        getCompatibilityCar.mockResolvedValue({ statusCode: 204, data: null, huboError: false });

        pintar();
        await act(async () => { });

        expect(screen.getByText(SIN_INFO)).toBeInTheDocument();
        expect(screen.queryByTestId('armadora')).not.toBeInTheDocument();
    });
});
