import React from 'react';
import { render, screen } from '@testing-library/react';
import MassiveUploadProductCard from '@/features/products/infrastructure/ui/modalMassiveUpload/massiveLoadTabs/MassiveUploadProductCard';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';

jest.mock('@/features/common/infrastructure/ui/img/CachedImage', () => ({
    CachedImage: ({ alt }: { alt: string }) => <img alt={alt} data-testid="cached-image" />,
}));

jest.mock('@/features/products/application/actions/fetchImageProducts', () => ({
    fetchImageProducts: jest.fn(),
}));

const baseProduct = {
    productoId: 1,
    producto: 'PROD001',
    imagen: '/img/prod.png',
    descripcion: 'Producto de prueba',
    productoError: undefined,
    errorPrecioEspecial: false,
};

describe('MassiveUploadProductCard', () => {
    describe('modo correcto (isError = false)', () => {
        it('renderiza la imagen, descripción, marca y cantidad', () => {
            render(<MassiveUploadProductCard product={baseProduct} />);

            expect(screen.getByTestId('cached-image')).toBeInTheDocument();
            expect(screen.getByText('PROD001')).toBeInTheDocument();
            expect(screen.getByText('Producto de prueba')).toBeInTheDocument();
            expect(screen.getByText('MARCA')).toBeInTheDocument();
            expect(screen.getByText('1')).toBeInTheDocument();
        });

        it('no muestra borde rojo cuando errorPrecioEspecial es false', () => {
            const { container } = render(<MassiveUploadProductCard product={baseProduct} />);

            const grid = container.firstChild as HTMLElement;
            expect(grid).not.toHaveStyle(`border: 1px solid ${ColorsEpico.ColorRed}`);
        });

        it('muestra borde rojo cuando errorPrecioEspecial es true', () => {
            const product = { ...baseProduct, errorPrecioEspecial: true };
            const { container } = render(<MassiveUploadProductCard product={product} />);

            const grid = container.firstChild as HTMLElement;
            expect(grid).toHaveStyle(`border: 1px solid ${ColorsEpico.ColorRed}`);
        });

        it('muestra el nombre del producto con errorPrecioEspecial y sigue mostrando imagen', () => {
            const product = { ...baseProduct, errorPrecioEspecial: true };
            render(<MassiveUploadProductCard product={product} />);

            expect(screen.getByTestId('cached-image')).toBeInTheDocument();
            expect(screen.getByText('PROD001')).toBeInTheDocument();
        });
    });

    describe('modo error (isError = true)', () => {
        it('no renderiza la imagen del producto', () => {
            const product = { ...baseProduct, productoError: 'Producto no encontrado' };
            render(<MassiveUploadProductCard product={product} isError />);

            expect(screen.queryByTestId('cached-image')).not.toBeInTheDocument();
        });

        it('muestra el mensaje de error del producto', () => {
            const product = { ...baseProduct, productoError: 'Producto no encontrado' };
            render(<MassiveUploadProductCard product={product} isError />);

            expect(screen.getByText('Producto no encontrado')).toBeInTheDocument();
        });

        it('no muestra MARCA ni cantidad', () => {
            const product = { ...baseProduct, productoError: 'Código inválido' };
            render(<MassiveUploadProductCard product={product} isError />);

            expect(screen.queryByText('MARCA')).not.toBeInTheDocument();
            expect(screen.queryByText('1')).not.toBeInTheDocument();
        });

        it('con errorPrecioEspecial sigue mostrando el borde rojo', () => {
            const product = { ...baseProduct, productoError: 'Error', errorPrecioEspecial: true };
            const { container } = render(<MassiveUploadProductCard product={product} isError />);

            const grid = container.firstChild as HTMLElement;
            expect(grid).toHaveStyle(`border: 1px solid ${ColorsEpico.ColorRed}`);
        });
    });
});
