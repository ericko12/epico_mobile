import React, { useState } from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { SearchBar } from '@/features/products/infrastructure/ui/searchBar/SearchBar';

jest.mock('next/navigation', () => ({
    usePathname: () => '/Pedidos/PedidosExternos',
}));

jest.mock('@/features/common/application/redux/hooks', () => ({
    useAppSelector: (selector: (state: unknown) => unknown) =>
        selector({
            localState: { authState: { userAuth: null } },
            sessionState: { productState: { loadingProducts: false } },
        }),
}));

jest.mock('@/features/products/application/service/product.services', () => ({
    ProductService: () => ({ getProductSearchSuggestions: jest.fn() }),
}));

jest.mock('@/features/common/infrastructure/ui/dialog/microphone/ModalMicrophone', () => ({
    ModalMicrophone: () => <div data-testid="modal-microphone" />,
}));

jest.mock('@/features/auth/infrastructure/ui/freshChatWidget/startFreshchat', () => ({
    startFreshchat: jest.fn(),
}));

/**
 * Envoltura con estado: SearchBar es un componente controlado y sin un padre que
 * conserve el valor no se puede observar qué caracteres sobreviven al filtro.
 */
const SearchBarHarness = ({ onlyDigits, loading }: { onlyDigits: boolean; loading?: boolean }) => {
    const [searchQuery, setSearchQuery] = useState('');
    return (
        <SearchBar
            label={onlyDigits ? 'Buscar por ID de cliente' : 'Buscar'}
            variant="outlined"
            size="small"
            buttonText="Buscar"
            onSearch={() => { }}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onlyDigits={onlyDigits}
            loading={loading}
            fullWidth
        />
    );
};

const getInput = () => screen.getByRole('textbox') as HTMLInputElement;

describe('SearchBar', () => {
    describe('onlyDigits (Pedidos externos: se filtra por ClienteId numérico)', () => {
        it('abre el teclado numérico en móvil', () => {
            render(<SearchBarHarness onlyDigits />);

            // Sin inputMode, Android abre el teclado alfabético y todo lo que el
            // usuario escribe se descarta en silencio: el campo parece muerto.
            expect(getInput()).toHaveAttribute('inputmode', 'numeric');
        });

        it('descarta las letras y conserva los dígitos', async () => {
            const user = userEvent.setup();
            render(<SearchBarHarness onlyDigits />);

            await user.type(getInput(), 'Juan123');

            expect(getInput().value).toBe('123');
        });

        it('deja el campo vacío si solo se escriben letras', async () => {
            const user = userEvent.setup();
            render(<SearchBarHarness onlyDigits />);

            await user.type(getInput(), 'Juan Perez');

            expect(getInput().value).toBe('');
        });
    });

    describe('sin onlyDigits (catálogo)', () => {
        it('no fuerza el teclado numérico', () => {
            render(<SearchBarHarness onlyDigits={false} />);

            expect(getInput()).not.toHaveAttribute('inputmode', 'numeric');
        });

        it('acepta texto', async () => {
            const user = userEvent.setup();
            render(<SearchBarHarness onlyDigits={false} />);

            await user.type(getInput(), 'balata');

            expect(getInput().value).toBe('balata');
        });
    });

    describe('estado de carga (lo decide la pantalla, no el slice de productos)', () => {
        // Sin `searchSuggestions` el componente renderiza un único botón. No se
        // consulta por nombre porque al cargar el texto se sustituye por el spinner
        // y el botón se queda sin nombre accesible.
        const getSearchButton = () => screen.getByRole('button');

        it('habilita el botón con una consulta válida cuando la pantalla no está cargando', async () => {
            const user = userEvent.setup();
            render(<SearchBarHarness onlyDigits={false} />);

            await user.type(getInput(), 'balata');

            expect(getSearchButton()).toBeEnabled();
        });

        it('lo deshabilita mientras la pantalla resuelve su búsqueda', async () => {
            const user = userEvent.setup();
            render(<SearchBarHarness onlyDigits={false} loading />);

            await user.type(getInput(), 'balata');

            expect(getSearchButton()).toBeDisabled();
        });

        it('no depende del estado de productos: sin prop loading el botón vive', async () => {
            // Regresión: el botón leía `loadingProducts` del slice de productos, así
            // que una búsqueda de catálogo interrumpida lo dejaba muerto en pantallas
            // ajenas al catálogo (Pedidos Externos).
            const user = userEvent.setup();
            render(<SearchBarHarness onlyDigits />);

            await user.type(getInput(), '12345');

            expect(getSearchButton()).toBeEnabled();
        });
    });
});
