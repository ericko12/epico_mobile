import { mapSearchProductToIProduct } from '@/features/products/application/actions/mapSearchProductToIProduct';
import { mapSearchFacetsToProductFilters } from '@/features/products/application/actions/mapSearchFacetsToProductFilters';
import { ISearchFacet, ISearchProductDto } from '@/features/products/domain/interfaces/ISearchProducts';
import { getPrice, getCrossedPrice, PriceType } from '@/features/common/infrastructure/utils/priceUtils';

/**
 * El mapeo es la frontera entre dos contratos, y sus errores son silenciosos: un
 * campo mal traducido no rompe `tsc`, simplemente deja la tarjeta con un dato
 * equivocado. Los casos de abajo son productos reales medidos en producción.
 */

/** Producto real: `0530500`, balata Bosch para Chevy, sin promoción. */
const CHEVY: ISearchProductDto = {
    productoId: 2066,
    codigo: '0530500',
    descripcion: 'BALATA DE FRENO DE DISCO DELANTERA CHEVROLET CHEVY, C2, TIGRA, PEUGEOT 306 BOSCH F 03B 150 265 ',
    marcaId: 344, marca: 'BOSCH',
    familiaId: 23, familia: 'Balata',
    clasificacionId: 2, clasificacion: 'Servicio ligero',
    divisionId: 18, division: 'Sistema mecanico',
    grupoId: 59, grupo: 'de freno de disco',
    especificaciones: ['2 Juegos de 2 Piezas '],
    caracteristicas: ['Lado Delantera'],
    vehiculos: ['2000 Chevrolet Chevy 4 cil-1.4L', '2005 Chevrolet Chevy 4 cil-1.6L'],
    referencias: ['F 03B 150 265', 'F 03B 150 265 8HG'],
    imagenes: ['https://resources.qbhparts.com/imagenes/0530500.webp'],
    imagenPrincipal: 'https://resources.qbhparts.com/imagenes/0530500.webp',
    porReferencia: false,
    precio: 489.5,
    precioConIva: 567.82,
    promocion: null,
    tienePromocion: false,
    existencia: 6,
};

/** Producto real: `2753303`, con promoción de precio (1490.52 sobre 1754.44). */
const CON_PROMOCION: ISearchProductDto = {
    ...CHEVY,
    productoId: 108783,
    codigo: '2753303',
    precio: 1754.44,
    precioConIva: 2035.15,
    promocion: 1490.52,
    tienePromocion: true,
    existencia: 1,
};

describe('mapSearchProductToIProduct', () => {
    it('traduce los identificadores y el código', () => {
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.productoID).toBe(2066);
        expect(p.productoId).toBe(2066);
        expect(p.producto).toBe('0530500');
    });

    it('recorta el espaciado que el catálogo trae en la descripción', () => {
        expect(mapSearchProductToIProduct(CHEVY).descripcion.endsWith('265')).toBe(true);
    });

    it('mapea `clasificacion` a `especialidad`, que es la misma dimensión', () => {
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.especialidadId).toBe(2);
        expect(p.especialidad).toBe('Servicio ligero');
    });

    it('deriva `tieneAplicaciones` de que haya aplicaciones en texto', () => {
        expect(mapSearchProductToIProduct(CHEVY).tieneAplicaciones).toBe(true);
        expect(mapSearchProductToIProduct({ ...CHEVY, vehiculos: [] }).tieneAplicaciones).toBe(false);
    });

    it('sintetiza `imagenMarca` en el único formato que CachedImage sabe leer', () => {
        // El componente extrae el número con /\/(\d+)\.png$/ y con él busca el logo
        // en IndexedDB; cualquier otro formato deja la marca en el placeholder.
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.imagenMarca).toBe('/344.png');
        expect(p.imagenMarca).toMatch(/\/(\d+)\.png$/);
    });

    it('pone las referencias en `oems` y la primera en `referencia`', () => {
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.oems).toEqual(['F 03B 150 265', 'F 03B 150 265 8HG']);
        expect(p.referencia).toBe('F 03B 150 265');
    });

    it('sin promoción, el precio que se pinta es el de lista y no hay tachado', () => {
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.precioRevista).toBe(0);
        // `getPrice` devuelve **[importe, tipo]** desde que existe el precio final.
        // El tipo se afirma a propósito: un producto del buscador sin promoción y
        // sin precio final tiene que quedar como precio de lista, y no colarse como
        // «final» por traer `mejorPrecio` en cero.
        expect(getPrice(p)).toEqual([489.5, PriceType.Lista]);
        expect(getCrossedPrice(p)).toBe(0);
    });

    it('con promoción, `promocion` pasa a `precioRevista` y es el importe que se cobra', () => {
        // Es la regla de oro del precio en EPICO: `getPrice` toma `precioRevista`
        // cuando es > 0 y `getCrossedPrice` deja el de lista tachado.
        const p = mapSearchProductToIProduct(CON_PROMOCION);
        expect(p.precioRevista).toBe(1490.52);
        expect(getPrice(p)).toEqual([1490.52, PriceType.Promocion]);
        expect(getCrossedPrice(p)).toBe(1754.44);
        expect(getPrice(p)[0]).toBeLessThan(getCrossedPrice(p));
        expect(p.tienePromociones).toBe(true);
    });

    it('rellena con ceros y nulos lo que el buscador no tiene, sin inventar', () => {
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.esNuevo).toBe(false);
        expect(p.notaTecnica).toBeNull();
        expect(p.categoriaId).toBe(0);
        expect(p.categoria).toBe('');
        expect(p.promocionID).toBeNull();
    });

    it('conserva las dimensiones nuevas del índice', () => {
        const p = mapSearchProductToIProduct(CHEVY);
        expect(p.divisionId).toBe(18);
        expect(p.grupo).toBe('de freno de disco');
        expect(p.vehiculos).toHaveLength(2);
        expect(p.porReferencia).toBe(false);
    });

    it('no pinta el distintivo OEM: el detector del servicio cuenta 1/4 y 70 como referencias', () => {
        const p = mapSearchProductToIProduct({ ...CHEVY, porReferencia: true });
        expect(p.highlights).toBeUndefined();
    });

    it('sobrevive a un producto sin ningún dato comercial', () => {
        const p = mapSearchProductToIProduct({
            ...CHEVY, precio: null, precioConIva: null, promocion: null, existencia: null,
        });
        expect(p.precio).toBe(0);
        expect(p.precioIva).toBe(0);
        expect(p.existencias).toBe(0);
    });
});

describe('mapSearchFacetsToProductFilters', () => {
    const FACETAS: ISearchFacet[] = [
        { campo: 'marca', etiqueta: 'Marca', valores: [{ valor: 'bosch', conteo: 145, ids: [344] }] },
        { campo: 'familia', etiqueta: 'Familia', valores: [{ valor: 'balata', conteo: 138, ids: [23, 1739] }] },
        { campo: 'clasificacion', etiqueta: 'Especialidad', valores: [{ valor: 'servicio ligero', conteo: 151, ids: [2] }] },
        { campo: 'grupo', etiqueta: 'Grupo', valores: [{ valor: 'de freno de disco', conteo: 118, ids: [59] }] },
        { campo: 'division', etiqueta: 'División', valores: [{ valor: 'sistema mecanico', conteo: 164, ids: [18] }] },
    ];

    it('capitaliza los valores, que el servicio devuelve en minúsculas', () => {
        const f = mapSearchFacetsToProductFilters(FACETAS);
        expect(f.marcas[0].nombre).toBe('Bosch');
        expect(f.tipoVehiculos[0].nombre).toBe('Servicio Ligero');
    });

    it('usa el primer id, conserva el conteo y se lleva TODOS los ids del valor', () => {
        // `idsRelacionados` no es un extra: un valor de familia puede estar
        // respaldado por varios ids, y filtrar con uno solo devuelve de menos.
        // Medido contra produccion: familiaId ["96","1729"] da 1289 y ["96"] da
        // 1286. `valor` es la forma cruda, para reconocer la misma opcion entre
        // dos respuestas sin depender de que `ids[0]` no cambie.
        const f = mapSearchFacetsToProductFilters(FACETAS);
        expect(f.familias[0]).toEqual({
            id: 23,
            nombre: 'Balata',
            cantidad: 138,
            valor: 'balata',
            idsRelacionados: [23, 1739],
        });
    });

    it('lleva `clasificacion` a `tipoVehiculos`, que es lo que pinta la tarjeta Especialidad', () => {
        expect(mapSearchFacetsToProductFilters(FACETAS).tipoVehiculos).toHaveLength(1);
    });

    it('deja categorías vacía y los precios en cero: el índice no tiene esas dimensiones', () => {
        const f = mapSearchFacetsToProductFilters(FACETAS);
        expect(f.categorias).toEqual([]);
        expect(f.precioMinimo).toBe(0);
        expect(f.precioMaximo).toBe(0);
    });

    it('descarta un valor sin ids, porque su checkbox no podría filtrar nada', () => {
        const f = mapSearchFacetsToProductFilters([
            { campo: 'marca', etiqueta: 'Marca', valores: [{ valor: 'sin id', conteo: 5, ids: [] }] },
        ]);
        expect(f.marcas).toEqual([]);
    });

    it('devuelve las cinco listas aunque no llegue ninguna faceta', () => {
        const f = mapSearchFacetsToProductFilters([]);
        expect(f.marcas).toEqual([]);
        expect(f.familias).toEqual([]);
        expect(f.grupos).toEqual([]);
        expect(f.tipoVehiculos).toEqual([]);
        expect(f.categorias).toEqual([]);
    });
});
