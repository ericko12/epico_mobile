import { IProduct } from '@/features/products/domain/interfaces/IProduct';
import { PriceType } from '@/features/common/infrastructure/utils/priceUtils';

/**
 * La hidratación es el paso que puede perder resultados sin que nadie se entere:
 * si el merge recorriera la respuesta de `productoservice` en vez de la del
 * buscador, se perdería el orden del ranking —que es lo único que aporta el
 * buscador— y los códigos que no vuelven desaparecerían de la pantalla.
 */

const getProductsByCodes = jest.fn();

jest.mock('@/features/products/application/service/product.services', () => ({
    ProductService: () => ({ getProductsByCodes }),
}));

// eslint-disable-next-line @typescript-eslint/no-require-imports
const { hydrateSearchProducts } = require('@/features/products/application/actions/hydrateSearchProducts');

/**
 * Producto mínimo con la forma que devuelve el mapper del buscador.
 *
 * @param codigo - Código del producto.
 * @param extra - Campos a sobreescribir.
 */
const desdeBuscador = (codigo: string, extra: Partial<IProduct> = {}): IProduct => ({
    productoID: Number(codigo),
    producto: codigo,
    descripcion: `producto ${codigo}`,
    precio: 100,
    precioIva: 116,
    // El buscador no trae precio final; lo pone la hidratación.
    mejorPrecio: 0,
    tipoMejorPrecio: PriceType.Lista,
    precioRevista: 0,
    tienePromociones: false,
    existencias: 0,
    esNuevo: false,
    tieneAplicaciones: true,
    vehiculos: ['2005 Chevrolet Chevy 4 cil-1.6L'],
    porReferencia: true,
    grupo: 'de freno de disco',
    highlights: { referencias: ['F 03B 150 265'] },
    imagenMarca: '/344.png',
    oems: [],
    imagenes: [],
    imagen: null,
    marca: 'BOSCH', marcaId: 344,
    familia: 'Balata', familiaId: 23,
    especialidad: 'Servicio ligero', especialidadId: 2,
    categoria: '', categoriaId: 0,
    tipoVehiculo: '', tipoVehiculoId: 0,
    referencia: null, fechaAlta: '', formulaDescripcion: '', notaTecnica: null,
    preciolista: null, promocionID: null, promocionId: null,
    permitePrecioEspecial: false, precioPromocion: null,
    cantidad: null, esGratis: null, costoIntegrado: null, cantidadSecuencia: null,
    ...extra,
});

/**
 * Producto como lo devuelve `productoservice`: con lo comercial de verdad y sin
 * nada de lo que aporta el buscador.
 *
 * @param codigo - Código del producto.
 * @param extra - Campos a sobreescribir.
 */
const desdeServicio = (codigo: string, extra: Partial<IProduct> = {}): IProduct => ({
    ...desdeBuscador(codigo),
    precio: 1754.44,
    precioRevista: 1490.52,
    tienePromociones: true,
    existencias: 7,
    esNuevo: true,
    agotarExistencia: 'N',
    notaTecnica: 'Par de balatas',
    highlights: undefined,
    vehiculos: undefined,
    porReferencia: undefined,
    grupo: undefined,
    ...extra,
});

describe('hydrateSearchProducts', () => {
    beforeEach(() => getProductsByCodes.mockReset());

    it('no llama a nada si no hay productos', async () => {
        const r = await hydrateSearchProducts([], 541037, 1);
        expect(r.products).toEqual([]);
        expect(getProductsByCodes).not.toHaveBeenCalled();
    });

    it('pide el bloque de promociones, sin el cual no vendría `precioRevista`', async () => {
        getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A')] });
        await hydrateSearchProducts([desdeBuscador('A')], 541037, 9);

        const [clienteId, codigos, stockParam] = getProductsByCodes.mock.calls[0];
        expect(clienteId).toBe(541037);
        expect(codigos).toEqual(['A']);
        expect(stockParam).toMatchObject({
            SucursalId: 9,
            RecuperarExistencia: true,
            RecuperarTienePromociones: true,
            AplicarRevistaPromocion: true,
            // El listado detallado lo pide el modal cuando el usuario toca la «P».
            RecuperarListadoPromociones: false,
        });
    });

    it('si el bloque de promociones falla, reintenta sin él en vez de quedarse sin precio', async () => {
        // El bloque `promociones` de este endpoint nunca se había enviado en toda
        // la aplicación, así que puede no estar soportado. Perder el precio de
        // revista es mucho menos grave que dejar la pantalla con todo en cero.
        getProductsByCodes
            .mockResolvedValueOnce({ huboError: true, data: null, error: { mensaje: 'campo no soportado' } })
            .mockResolvedValueOnce({ huboError: false, data: [desdeServicio('A')] });

        const r = await hydrateSearchProducts([desdeBuscador('A')], 1, 1);

        expect(getProductsByCodes).toHaveBeenCalledTimes(2);
        // El segundo intento va con el cuerpo que el resto de la app sí usa hoy.
        const segundo = getProductsByCodes.mock.calls[1][2];
        expect(segundo).toEqual({ RecuperarExistencia: true, SucursalId: 1 });
        expect(r.failed).toBe(false);
        expect(r.withoutPromotions).toBe(true);
        expect(r.products[0].precio).toBe(1754.44);
    });

    it('con el primer intento bueno no reintenta', async () => {
        getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A')] });
        const r = await hydrateSearchProducts([desdeBuscador('A')], 1, 1);
        expect(getProductsByCodes).toHaveBeenCalledTimes(1);
        expect(r.withoutPromotions).toBe(false);
    });

    it('CONSERVA el orden del ranking aunque el servicio devuelva otro', async () => {
        getProductsByCodes.mockResolvedValue({
            huboError: false,
            data: [desdeServicio('C'), desdeServicio('A'), desdeServicio('B')],
        });
        const r = await hydrateSearchProducts(
            [desdeBuscador('A'), desdeBuscador('B'), desdeBuscador('C')], 1, 1
        );
        expect(r.products.map((p: IProduct) => p.producto)).toEqual(['A', 'B', 'C']);
    });

    it('toma lo comercial del servicio', async () => {
        getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A')] });
        const r = await hydrateSearchProducts([desdeBuscador('A')], 1, 1);
        expect(r.products[0].precioRevista).toBe(1490.52);
        expect(r.products[0].existencias).toBe(7);
        expect(r.products[0].esNuevo).toBe(true);
        expect(r.products[0].notaTecnica).toBe('Par de balatas');
    });

    it('NO pisa lo que solo tiene el buscador', async () => {
        // Con un spread ingenuo (`{...buscador, ...servicio}`) se perderían las
        // aplicaciones, el resaltado OEM y las dimensiones nuevas.
        getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A')] });
        const r = await hydrateSearchProducts([desdeBuscador('A')], 1, 1);
        expect(r.products[0].vehiculos).toEqual(['2005 Chevrolet Chevy 4 cil-1.6L']);
        expect(r.products[0].highlights).toEqual({ referencias: ['F 03B 150 265'] });
        expect(r.products[0].porReferencia).toBe(true);
        expect(r.products[0].grupo).toBe('de freno de disco');
    });

    it('un código que el servicio no devuelve NO desaparece de la pantalla', async () => {
        getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A')] });
        const r = await hydrateSearchProducts([desdeBuscador('A'), desdeBuscador('B')], 1, 1);
        expect(r.products.map((p: IProduct) => p.producto)).toEqual(['A', 'B']);
        expect(r.missing).toEqual(['B']);
        // El que no volvió se queda con lo que dio el buscador.
        expect(r.products[1].precioRevista).toBe(0);
    });

    it('si nada se puede hidratar, se sirven los productos del buscador y se dice el motivo', async () => {
        getProductsByCodes.mockResolvedValue({ huboError: true, data: null, error: { mensaje: 'boom' } });
        const r = await hydrateSearchProducts([desdeBuscador('A')], 1, 1);
        expect(r.failed).toBe(true);
        // El motivo se propaga: un aviso que no explica nada no se puede accionar.
        expect(r.errorMessage).toBe('boom');
        expect(r.products).toHaveLength(1);
        expect(r.products[0].precio).toBe(100);
    });

    it('UN producto inactivo no deja sin precio a los demas', async () => {
        // Medido en produccion: este endpoint valida producto por producto y
        // rechaza el lote entero con «El producto que se desea ingresar esta
        // inactivo». Sin aislar, un codigo malo dejaba los 30 en $0.00.
        const MALO = 'INACTIVO';
        const todos = ['A', 'B', 'C', 'D', 'E', 'F', MALO];

        getProductsByCodes.mockImplementation((_c: number, codigos: string[]) => {
            if (codigos.includes(MALO)) {
                return Promise.resolve({ huboError: true, data: null, error: { mensaje: 'inactivo' } });
            }
            return Promise.resolve({ huboError: false, data: codigos.map((x) => desdeServicio(x)) });
        });

        const r = await hydrateSearchProducts(todos.map((x) => desdeBuscador(x)), 1, 1);

        expect(r.failed).toBe(false);
        // Los seis buenos con precio real, y el orden del ranking intacto.
        expect(r.products.map((p: IProduct) => p.producto)).toEqual(todos);
        expect(r.products.slice(0, 6).every((p: IProduct) => p.precioRevista === 1490.52)).toBe(true);
        // El malo se queda, marcado, y sin inventarle un importe.
        const malo = r.products[6];
        expect(malo.producto).toBe(MALO);
        expect(malo.sinPrecio).toBe(true);
        expect(r.missing).toEqual([MALO]);
        // Y los buenos no se marcan.
        expect(r.products[0].sinPrecio).toBeUndefined();
    });

    it('con códigos duplicados en el catálogo gana el primero, que es el mejor puntuado', async () => {
        getProductsByCodes.mockResolvedValue({
            huboError: false,
            data: [desdeServicio('A', { existencias: 111 }), desdeServicio('A', { existencias: 222 })],
        });
        const r = await hydrateSearchProducts([desdeBuscador('A')], 1, 1);
        expect(r.products[0].existencias).toBe(111);
    });

    describe('tieneAplicaciones: basta un `true` de cualquiera de las dos fuentes', () => {
        // Visto en producción: el detalle no cargaba aplicaciones al entrar desde el
        // catálogo, y sí desde un producto relacionado. El detalle hereda esta
        // bandera de la tarjeta, y con `??` un `false` de v3 anulaba los vehículos
        // del índice. `desdeServicio` hereda `tieneAplicaciones: true` del buscador,
        // por eso aquí cada caso fija las dos fuentes a mano: con la fixture por
        // defecto el defecto nunca se veía.
        const VEHICULOS = ['2005 Chevrolet Chevy 4 cil-1.6L'];
        const sinBandera = (codigo: string) => {
            const producto: Partial<IProduct> = desdeServicio(codigo);
            delete producto.tieneAplicaciones;
            return producto as IProduct;
        };

        it.each([
            ['v3 false con vehículos en el índice', { tieneAplicaciones: false }, VEHICULOS, true],
            ['v3 null con vehículos en el índice', { tieneAplicaciones: null as unknown as boolean }, VEHICULOS, true],
            ['v3 null sin vehículos en el índice', { tieneAplicaciones: null as unknown as boolean }, [], false],
            ['v3 true sin vehículos en el índice', { tieneAplicaciones: true }, [], true],
            ['v3 false sin vehículos en el índice', { tieneAplicaciones: false }, [], false],
            ['v3 false y el índice sin el campo', { tieneAplicaciones: false }, undefined, false],
        ])('%s', async (_caso, deV3, vehiculos, esperado) => {
            getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A', deV3)] });
            const r = await hydrateSearchProducts([desdeBuscador('A', { vehiculos })], 1, 1);
            expect(r.products[0].tieneAplicaciones).toBe(esperado);
        });

        it('v3 sin el campo cae a los vehículos del índice', async () => {
            getProductsByCodes.mockResolvedValue({ huboError: false, data: [sinBandera('A')] });
            const conVehiculos = await hydrateSearchProducts([desdeBuscador('A', { vehiculos: VEHICULOS })], 1, 1);
            expect(conVehiculos.products[0].tieneAplicaciones).toBe(true);

            getProductsByCodes.mockResolvedValue({ huboError: false, data: [sinBandera('A')] });
            const sinVehiculos = await hydrateSearchProducts([desdeBuscador('A', { vehiculos: [], tieneAplicaciones: false })], 1, 1);
            expect(sinVehiculos.products[0].tieneAplicaciones).toBe(false);
        });

        it('un código que v3 no devuelve conserva la bandera del índice', async () => {
            getProductsByCodes.mockResolvedValue({ huboError: false, data: [desdeServicio('A')] });
            const r = await hydrateSearchProducts([desdeBuscador('A'), desdeBuscador('B', { tieneAplicaciones: true })], 1, 1);
            expect(r.products[1].tieneAplicaciones).toBe(true);
            expect(r.products[1].sinPrecio).toBe(true);
        });
    });
});
