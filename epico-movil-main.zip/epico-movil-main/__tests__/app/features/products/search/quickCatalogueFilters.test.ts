import {
    buildQuickFilters,
    CatalogueFilterDimensionEnum,
    estaSeleccionada,
    idsDeOpcion,
    nombresAplicados,
    toggleQuickFilter,
} from '@/features/products/application/actions/quickCatalogueFilters';
import { IProductFilter, IProductFilters, IProductSearch } from '@/features/products/domain/interfaces/IProduct';

/**
 * Las insignias de filtro rápido: las tres familias y las tres marcas con más
 * resultados, sacadas de las facetas que el buscador ya devolvía y que hasta ahora
 * solo alimentaban el sidebar.
 *
 * Los números de estas pruebas **no son inventados**: son los que devolvió
 * producción para la consulta «foco», y son los mismos que se ven en la
 * implementación de referencia. Filtrar por `faro` devuelve exactamente 1289, y
 * ahí está la razón de que se pueda pintar el conteo.
 */

const opcion = (id: number, nombre: string, cantidad: number, ids?: number[]): IProductFilter => ({
    id,
    nombre,
    cantidad,
    valor: nombre.toLowerCase(),
    idsRelacionados: ids ?? [id],
});

/** Lo que devolvió el servicio para «foco», tal cual. */
const FAMILIAS = [
    opcion(96, 'Faro', 1289, [96, 1729]),
    opcion(100, 'Foco', 895, [100, 1731]),
    opcion(67, 'Conector', 139),
    opcion(209, 'Unidad', 90),
];
const MARCAS = [
    opcion(375, 'Depo', 1003),
    opcion(246, 'Qbh Star', 621),
    opcion(415, 'Importado', 159),
    opcion(489, 'Bresser-Lkw', 128),
];

const filtros = (extra: Partial<IProductFilters> = {}): IProductFilters => ({
    categorias: [],
    familias: FAMILIAS,
    grupos: [],
    marcas: MARCAS,
    tipoVehiculos: [],
    precioMaximo: 0,
    precioMinimo: 0,
    ...extra,
});

const params = (extra: Partial<IProductSearch> = {}): IProductSearch => ({
    CadenaBusqueda: 'foco',
    Paginado: { Pagina: 3, RegistrosPagina: 15, Ordenamiento: 'relevance', TipoOrdenamiento: 'asc' },
    ...extra,
} as IProductSearch);

describe('idsDeOpcion y estaSeleccionada', () => {
    it('una familia puede tener varios ids, y se cuentan todos', () => {
        // Medido: familiaId ["96","1729"] devuelve 1289; solo ["96"] devuelve 1286.
        // Perder un id es perder productos.
        expect(idsDeOpcion(FAMILIAS[0])).toEqual([96, 1729]);
    });

    it('la selección se resuelve por el valor entero, no por el primer id', () => {
        // El contrato no promete el orden de `ids` entre respuestas. Si cambiara y
        // se comparara por el escalar, el filtro quedaria puesto con la insignia
        // apagada, y el toque siguiente lo anadiria en vez de quitarlo.
        expect(estaSeleccionada(FAMILIAS[0], [1729])).toBe(true);
        expect(estaSeleccionada(FAMILIAS[0], [96])).toBe(true);
        expect(estaSeleccionada(FAMILIAS[0], [412])).toBe(false);
        expect(estaSeleccionada(FAMILIAS[0], [])).toBe(false);
        expect(estaSeleccionada(FAMILIAS[0], undefined)).toBe(false);
    });
});

describe('buildQuickFilters', () => {
    it('saca las tres de cada dimensión con su conteo', () => {
        const grupos = buildQuickFilters(filtros(), params());
        expect(grupos.map((g) => g.etiqueta)).toEqual(['Familia', 'Marca']);
        expect(grupos[0].opciones.map((o) => [o.nombre, o.cantidad])).toEqual([
            ['Faro', 1289], ['Foco', 895], ['Conector', 139],
        ]);
        expect(grupos[1].opciones.map((o) => [o.nombre, o.cantidad])).toEqual([
            ['Depo', 1003], ['Qbh Star', 621], ['Importado', 159],
        ]);
        expect(grupos.every((g) => g.opciones.every((o) => !o.seleccionada))).toBe(true);
    });

    it('ordena por conteo aunque lleguen desordenadas', () => {
        // El servicio ya las manda ordenadas, pero «las 3 con mas resultados» no
        // puede depender de una promesa que no esta en el contrato.
        const desordenadas = [FAMILIAS[2], FAMILIAS[0], FAMILIAS[1]];
        const grupos = buildQuickFilters(filtros({ familias: desordenadas }), params());
        expect(grupos[0].opciones.map((o) => o.nombre)).toEqual(['Faro', 'Foco', 'Conector']);
    });

    it('con el mismo conteo desempata por nombre en español', () => {
        const empate = [opcion(1, 'Zapata', 200), opcion(2, 'Ámbar', 200), opcion(3, 'Buje', 10)];
        const grupos = buildQuickFilters(filtros({ familias: empate }), params());
        expect(grupos[0].opciones.map((o) => o.nombre)).toEqual(['Ámbar', 'Zapata', 'Buje']);
    });

    it('marca la que está aplicada, aunque el filtro lleve solo uno de sus ids', () => {
        const grupos = buildQuickFilters(filtros(), params({ FamiliaIdProducto: [1729] }));
        expect(grupos[0].opciones[0]).toMatchObject({ nombre: 'Faro', seleccionada: true });
    });

    it('una aplicada que se cayó del podio se antepone, y el podio sigue entero', () => {
        // Si no, la fila dejaria de ser la via para quitar ese filtro: habria que
        // abrir el sidebar. Adaptar no puede quitar una accion.
        const grupos = buildQuickFilters(filtros(), params({ MarcaIdProducto: [489] }));
        expect(grupos[1].opciones.map((o) => o.nombre)).toEqual([
            'Bresser-Lkw', 'Depo', 'Qbh Star', 'Importado',
        ]);
        expect(grupos[1].opciones[0].seleccionada).toBe(true);
        expect(grupos[1].ocultas).toBe(0);
    });

    it('con muchas aplicadas fuera del podio, el podio no se lo comen', () => {
        const muchas = [
            ...MARCAS,
            opcion(500, 'Gonher', 40),
            opcion(501, 'Hql', 30),
            opcion(502, 'Tyc', 20),
        ];
        const grupos = buildQuickFilters(
            filtros({ marcas: muchas }),
            params({ MarcaIdProducto: [489, 500, 501, 502] })
        );
        // Las tres ofertas siguen ahí; solo cabe una de las aplicadas de fuera.
        expect(grupos[1].opciones.map((o) => o.nombre)).toEqual([
            'Bresser-Lkw', 'Depo', 'Qbh Star', 'Importado',
        ]);
        expect(grupos[1].ocultas).toBe(3);
    });

    it('sin filtros no hay nada que pintar', () => {
        expect(buildQuickFilters(undefined, params())).toEqual([]);
    });

    it('una dimensión vacía no deja un rótulo huérfano', () => {
        const grupos = buildQuickFilters(filtros({ marcas: [] }), params());
        expect(grupos.map((g) => g.etiqueta)).toEqual(['Familia']);
    });

    it('una sola opción sin aplicar no se pinta: no acota nada', () => {
        // Es el caso de buscar por numero de parte: una familia, un resultado.
        const grupos = buildQuickFilters(
            filtros({ familias: [opcion(7, 'Balata', 1)], marcas: [] }),
            params()
        );
        expect(grupos).toEqual([]);
    });

    it('una sola opción SÍ se pinta si está aplicada: es la vía de quitarla', () => {
        const grupos = buildQuickFilters(
            filtros({ familias: [FAMILIAS[0]], marcas: [] }),
            params({ FamiliaIdProducto: [96, 1729] })
        );
        expect(grupos).toHaveLength(1);
        expect(grupos[0].opciones[0]).toMatchObject({ nombre: 'Faro', seleccionada: true });
    });
});

describe('toggleQuickFilter', () => {
    it('al encender manda TODOS los ids del valor y vuelve a la página 1', () => {
        const nuevos = toggleQuickFilter(params(), CatalogueFilterDimensionEnum.Familia, FAMILIAS[0]);
        expect(nuevos.FamiliaIdProducto).toEqual([96, 1729]);
        expect(nuevos.Paginado.Pagina).toBe(1);
        // El orden elegido no se toca.
        expect(nuevos.Paginado.Ordenamiento).toBe('relevance');
    });

    it('al apagar quita todos sus ids y respeta los de otros valores', () => {
        const p = params({ FamiliaIdProducto: [96, 1729, 67] });
        const nuevos = toggleQuickFilter(p, CatalogueFilterDimensionEnum.Familia, FAMILIAS[0]);
        expect(nuevos.FamiliaIdProducto).toEqual([67]);
    });

    it('al quedarse vacío escribe undefined, nunca una lista vacía', () => {
        // `expandFacetIds` y el boton de limpiar leen `undefined` como «sin
        // filtro»; una lista vacia se colaria como filtro aplicado.
        const p = params({ MarcaIdProducto: [375] });
        const nuevos = toggleQuickFilter(p, CatalogueFilterDimensionEnum.Marca, MARCAS[0]);
        expect(nuevos.MarcaIdProducto).toBeUndefined();
    });

    it('apaga aunque el filtro llevara solo uno de los ids del valor', () => {
        const p = params({ FamiliaIdProducto: [1729] });
        const nuevos = toggleQuickFilter(p, CatalogueFilterDimensionEnum.Familia, FAMILIAS[0]);
        expect(nuevos.FamiliaIdProducto).toBeUndefined();
    });

    it('no duplica ids al encender dos valores distintos', () => {
        const p = params({ FamiliaIdProducto: [96, 1729] });
        const nuevos = toggleQuickFilter(p, CatalogueFilterDimensionEnum.Familia, FAMILIAS[1]);
        expect(nuevos.FamiliaIdProducto).toEqual([96, 1729, 100, 1731]);
    });

    it('familia y marca no se pisan', () => {
        const p = params({ FamiliaIdProducto: [96, 1729] });
        const nuevos = toggleQuickFilter(p, CatalogueFilterDimensionEnum.Marca, MARCAS[0]);
        expect(nuevos.FamiliaIdProducto).toEqual([96, 1729]);
        expect(nuevos.MarcaIdProducto).toEqual([375]);
    });
});

describe('nombresAplicados', () => {
    it('devuelve los nombres marcados, para poder nombrarlos en el recuento', () => {
        const grupos = buildQuickFilters(
            filtros(),
            params({ FamiliaIdProducto: [96], MarcaIdProducto: [375] })
        );
        expect(nombresAplicados(grupos)).toEqual(['Faro', 'Depo']);
    });

    it('sin nada aplicado devuelve vacío', () => {
        expect(nombresAplicados(buildQuickFilters(filtros(), params()))).toEqual([]);
    });
});
