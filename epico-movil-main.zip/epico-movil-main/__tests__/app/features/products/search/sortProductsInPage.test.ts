import { isPageScopedSorting, sortProductsInPage } from '@/features/products/application/actions/sortProductsInPage';
import { ProductOrdering, SortingProducts } from '@/features/products/domain/enums/ProductsEnums';
import { IProduct } from '@/features/products/domain/interfaces/IProduct';

/**
 * El buscador nuevo no ordena, así que el selector actúa sobre la página ya
 * hidratada. Lo que estos casos fijan es que ordenar por relevancia **no toca
 * nada** —el orden del buscador *es* la relevancia— y que el precio que decide el
 * orden es el mismo que la tarjeta pinta.
 */

const producto = (codigo: string, precio: number, precioRevista = 0): IProduct =>
    ({ producto: codigo, precio, precioRevista } as IProduct);

describe('sortProductsInPage', () => {
    const LISTA = [producto('C', 300), producto('A', 100), producto('B', 200)];

    it('por relevancia devuelve la lista intacta: reordenar destruiría el ranking', () => {
        const r = sortProductsInPage(LISTA, ProductOrdering.relevance, SortingProducts.desc);
        expect(r.map((p) => p.producto)).toEqual(['C', 'A', 'B']);
        expect(r).toBe(LISTA);
    });

    it('ordena de menor a mayor precio', () => {
        const r = sortProductsInPage(LISTA, ProductOrdering.price, SortingProducts.asc);
        expect(r.map((p) => p.producto)).toEqual(['A', 'B', 'C']);
    });

    it('ordena de mayor a menor precio', () => {
        const r = sortProductsInPage(LISTA, ProductOrdering.price, SortingProducts.desc);
        expect(r.map((p) => p.producto)).toEqual(['C', 'B', 'A']);
    });

    it('coloca un producto en promoción por el importe que se cobra, no por el de lista', () => {
        // Si se comparara `precio` a secas, este producto saldría al final aunque
        // sea el más barato de la página, que es lo contrario de lo que se ve.
        const lista = [producto('A', 100), producto('CARO', 900, 50)];
        const r = sortProductsInPage(lista, ProductOrdering.price, SortingProducts.asc);
        expect(r.map((p) => p.producto)).toEqual(['CARO', 'A']);
    });

    it('no muta la lista original', () => {
        const lista = [...LISTA];
        sortProductsInPage(lista, ProductOrdering.price, SortingProducts.asc);
        expect(lista.map((p) => p.producto)).toEqual(['C', 'A', 'B']);
    });
});

describe('isPageScopedSorting', () => {
    it('avisa cuando el orden es por precio, que es el que solo actúa en la página', () => {
        expect(isPageScopedSorting(ProductOrdering.price)).toBe(true);
    });

    it('no avisa con relevancia, que sí es el orden de toda la búsqueda', () => {
        expect(isPageScopedSorting(ProductOrdering.relevance)).toBe(false);
    });
});
