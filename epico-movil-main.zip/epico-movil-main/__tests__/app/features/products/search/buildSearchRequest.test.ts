import { buildSearchRequest, canUseNewSearch } from '@/features/products/application/actions/buildSearchRequest';
import { IProductSearch } from '@/features/products/domain/interfaces/IProduct';
import { ISearchFacet, SearchModeEnum } from '@/features/products/domain/interfaces/ISearchProducts';

/**
 * El cuerpo de la búsqueda es donde un error no se ve: `tsc` no sabe que el
 * servicio exige el año en cuatro dígitos, que los cilindros no discriminan o que
 * un valor de faceta puede estar respaldado por varios ids. Estos casos fijan lo
 * que se midió contra el servicio.
 */

const BASE: IProductSearch = {
    ClienteID: 0,
    CadenaBusqueda: 'balatas delanteras',
    BusquedaInexacta: false,
    EsReferencia: false,
    Paginado: { Pagina: 2, RegistrosPagina: 30, Ordenamiento: 'relevancia', TipoOrdenamiento: 'desc' },
};

const params = (extra: Partial<IProductSearch> = {}): IProductSearch => ({ ...BASE, ...extra });

describe('canUseNewSearch', () => {
    const OLD_ENV = process.env.NEXT_PUBLIC_BUSQUEDA_NUEVA_ACTIVA;
    beforeEach(() => { process.env.NEXT_PUBLIC_BUSQUEDA_NUEVA_ACTIVA = 'true'; });
    afterAll(() => { process.env.NEXT_PUBLIC_BUSQUEDA_NUEVA_ACTIVA = OLD_ENV; });

    it('atiende una búsqueda con texto suficiente', () => {
        expect(canUseNewSearch(params())).toBe(true);
    });

    it('no atiende una consulta de menos de 3 caracteres, que daría 400', () => {
        expect(canUseNewSearch(params({ CadenaBusqueda: 'ba' }))).toBe(false);
    });

    it('no atiende una búsqueda sin texto: navegar por familia se queda con productoservice', () => {
        expect(canUseNewSearch(params({ CadenaBusqueda: '', FamiliaIdProducto: [23] }))).toBe(false);
    });

    it('no atiende una búsqueda de solo vehículo, que tampoco tiene pieza que entender', () => {
        expect(canUseNewSearch(params({ CadenaBusqueda: '   ', Marca: 'Chevrolet', Modelo: 'Chevy', Año: 2005 }))).toBe(false);
    });

    it('está apagada si la bandera lo está, aunque haya texto', () => {
        process.env.NEXT_PUBLIC_BUSQUEDA_NUEVA_ACTIVA = 'false';
        expect(canUseNewSearch(params())).toBe(false);
    });
});

describe('buildSearchRequest', () => {
    it('traduce lo mínimo: consulta recortada, página y tamaño', () => {
        const body = buildSearchRequest(params({ CadenaBusqueda: '  balatas  ' }));
        expect(body.consulta).toBe('balatas');
        expect(body.pagina).toBe(2);
        expect(body.tamanoPagina).toBe(30);
        expect(body.modo).toBe(SearchModeEnum.Normal);
    });

    it('no pide composición comercial: el precio se hidrata en productoservice', () => {
        const body = buildSearchRequest(params());
        expect(body.incluirPrecios).toBeUndefined();
        expect(body.incluirPromociones).toBeUndefined();
        expect(body.incluirExistencias).toBeUndefined();
        expect(body.clienteId).toBeUndefined();
    });

    it('manda el vehículo en texto, con el año de cuatro dígitos como cadena', () => {
        const body = buildSearchRequest(params({ Marca: 'Chevrolet', Modelo: 'Chevy', Año: 2005, Litros: '1.6' }));
        expect(body.vehiculo).toEqual({ marca: 'Chevrolet', modelo: 'Chevy', anio: '2005', litros: '1.6' });
    });

    it('descarta un año que no tenga cuatro dígitos, porque el servicio devolvería 400', () => {
        const body = buildSearchRequest(params({ Marca: 'Chevrolet', Año: 0 }));
        expect(body.vehiculo).toEqual({ marca: 'Chevrolet' });
    });

    it('no manda cilindros: medido, no discriminan', () => {
        const body = buildSearchRequest(params({ Marca: 'Chevrolet', Cilindro: '4', CilindroID: 4 }));
        expect(JSON.stringify(body)).not.toContain('cilindro');
        expect(body.vehiculo).toEqual({ marca: 'Chevrolet' });
    });

    it('omite el vehículo cuando no hay ningún dato', () => {
        expect(buildSearchRequest(params()).vehiculo).toBeUndefined();
    });

    it('convierte los ids de los chips a cadenas en los campos por id', () => {
        const body = buildSearchRequest(params({
            MarcaIdProducto: [344],
            FamiliaIdProducto: [23],
            clasificacionId: [2],
        }));
        expect(body.filtros).toEqual({
            marcaId: ['344'],
            familiaId: ['23'],
            clasificacionId: ['2'],
        });
    });

    it('expande un valor de faceta a TODOS sus ids', () => {
        // Caso real: la familia `faro` son el 96 (3 576 productos) y el 1729 (28).
        // Mandar solo el 96 devolvería menos productos de los que el chip promete.
        const facets: ISearchFacet[] = [{
            campo: 'familia',
            etiqueta: 'Familia',
            valores: [{ valor: 'faro', conteo: 3604, ids: [96, 1729] }],
        }];
        const body = buildSearchRequest(params({ FamiliaIdProducto: [96] }), facets);
        expect(body.filtros?.familiaId).toEqual(['96', '1729']);
    });

    it('sin facetas manda el id tal cual, sin inventar', () => {
        const body = buildSearchRequest(params({ FamiliaIdProducto: [96] }));
        expect(body.filtros?.familiaId).toEqual(['96']);
    });

    it('omite `filtros` cuando no hay ningún chip marcado', () => {
        expect(buildSearchRequest(params()).filtros).toBeUndefined();
    });

    it('propaga el modo IA', () => {
        const body = buildSearchRequest(params(), undefined, SearchModeEnum.Ia);
        expect(body.modo).toBe(SearchModeEnum.Ia);
    });
});
