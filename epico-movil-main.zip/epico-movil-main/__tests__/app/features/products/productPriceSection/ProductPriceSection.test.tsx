import { render, screen } from '@testing-library/react';
import { ProductPriceSection } from '@/features/products/infrastructure/ui/productPriceSection/ProductPriceSection';
import { PriceType } from '@/features/common/infrastructure/utils/priceUtils';

jest.mock('next/navigation', () => ({
    usePathname: () => '/Catalogo',
}));

/**
 * `ProductPriceSection` pinta el precio en las cuatro tarjetas de producto —cuadrícula y
 * lista del catálogo, historial de compras y detalle— y desde el release 3.22.0 del
 * original recibe una tupla `[precio, tipoDePrecio]` y añade la insignia de mejor precio.
 *
 * En la tarjeta de cuadrícula de móvil el ancho útil baja de 150px, así que estos casos
 * fijan las dos cosas que ahí se rompen: que la insignia aparezca solo cuando toca, y que
 * el precio tachado no se pinte cuando no supera al precio cobrado (si no, se ven dos
 * cifras iguales, una tachada, y encima se desborda el renglón).
 */
describe('ProductPriceSection', () => {
    it('muestra el precio de la tupla', () => {
        render(<ProductPriceSection price={[1234.56, PriceType.Lista]} />);

        expect(screen.getByText('$1,234.56')).toBeInTheDocument();
    });

    it('pinta la insignia de mejor precio solo cuando el tipo de precio es Final', () => {
        const { container, rerender } = render(
            <ProductPriceSection price={[900, PriceType.Final]} crossedPrice={1000} />
        );
        expect(container.querySelector('svg')).toBeInTheDocument();

        rerender(<ProductPriceSection price={[900, PriceType.Promocion]} crossedPrice={1000} />);
        expect(container.querySelector('svg')).not.toBeInTheDocument();
    });

    it('tacha el precio de lista solo cuando es mayor que el que se cobra', () => {
        const { rerender } = render(
            <ProductPriceSection price={[900, PriceType.Final]} crossedPrice={1000} />
        );
        expect(screen.getByText('$1,000.00')).toBeInTheDocument();

        rerender(<ProductPriceSection price={[900, PriceType.Final]} crossedPrice={900} />);
        expect(screen.queryByText('$900.00')).toBeInTheDocument();
        expect(screen.queryAllByText('$900.00')).toHaveLength(1);
    });

    it('sin precio tachado ni mejor precio solo queda la cifra', () => {
        const { container } = render(<ProductPriceSection price={[450.5, PriceType.Lista]} />);

        expect(screen.getByText('$450.50')).toBeInTheDocument();
        expect(container.querySelector('svg')).not.toBeInTheDocument();
    });
});
