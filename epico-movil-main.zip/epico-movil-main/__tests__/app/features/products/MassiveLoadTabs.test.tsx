import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import MassiveLoadTabs from '@/features/products/infrastructure/ui/modalMassiveUpload/massiveLoadTabs/MassiveLoadTabs';

jest.mock('@/features/common/infrastructure/ui/tabs/TabGeneric', () => ({
    TabGeneric: ({ options, handleChangeTab }: { options: { label: string; index: number }[]; handleChangeTab: (e: React.SyntheticEvent, newValue: number) => void }) => (
        <div>
            {options.map((opt) => (
                <button key={opt.index} onClick={(e) => handleChangeTab(e as unknown as React.SyntheticEvent, opt.index)}>
                    {opt.label}
                </button>
            ))}
        </div>
    ),
}));

jest.mock('@/features/products/infrastructure/ui/modalMassiveUpload/massiveLoadTabs/MassiveUploadProductCard', () => ({
    __esModule: true,
    default: ({ product, isError }: { product: { productoId: number }; isError?: boolean }) => (
        <div
            data-testid={`product-card-${product.productoId}`}
            data-is-error={isError ? 'true' : 'false'}
        />
    ),
}));

const baseProduct = {
    productoId: 1,
    producto: 'PROD001',
    imagen: '/img/prod.png',
    descripcion: 'Producto de prueba',
    errorPrecioEspecial: false,
};

const errorProduct = {
    productoId: 2,
    producto: 'PROD002',
    imagen: '/img/prod2.png',
    descripcion: 'Producto con error',
    productoError: 'Producto no encontrado',
    errorPrecioEspecial: false,
};

describe('MassiveLoadTabs', () => {
    describe('pestañas', () => {
        it('renderiza las dos pestañas correctamente', () => {
            render(<MassiveLoadTabs correctItems={[]} errorItems={[]} />);

            expect(screen.getByText('ARTICULOS CORRECTOS')).toBeInTheDocument();
            expect(screen.getByText('ARTICULOS ERRORES')).toBeInTheDocument();
        });

        it('muestra los artículos correctos en la primera pestaña por defecto', () => {
            render(<MassiveLoadTabs correctItems={[baseProduct]} errorItems={[]} />);

            expect(screen.getByTestId('product-card-1')).toBeInTheDocument();
        });

        it('al cambiar a la pestaña de errores muestra los artículos con error', () => {
            render(<MassiveLoadTabs correctItems={[baseProduct]} errorItems={[errorProduct]} />);

            fireEvent.click(screen.getByText('ARTICULOS ERRORES'));

            expect(screen.getByTestId('product-card-2')).toBeInTheDocument();
        });

        it('al cambiar a la pestaña de errores oculta los artículos correctos', () => {
            render(<MassiveLoadTabs correctItems={[baseProduct]} errorItems={[errorProduct]} />);

            fireEvent.click(screen.getByText('ARTICULOS ERRORES'));

            expect(screen.queryByTestId('product-card-1')).not.toBeInTheDocument();
        });
    });

    describe('aviso de errorPrecioEspecial', () => {
        it('muestra el aviso cuando al menos un artículo correcto tiene errorPrecioEspecial', () => {
            const productWithError = { ...baseProduct, errorPrecioEspecial: true };
            render(<MassiveLoadTabs correctItems={[productWithError]} errorItems={[]} />);

            expect(screen.getByText('Los productos señalados se cargaran al pedido pero no se solicitarán token')).toBeInTheDocument();
        });

        it('muestra el asterisco rojo cuando hay errorPrecioEspecial', () => {
            const productWithError = { ...baseProduct, errorPrecioEspecial: true };
            render(<MassiveLoadTabs correctItems={[productWithError]} errorItems={[]} />);

            expect(screen.getByText('*')).toBeInTheDocument();
        });

        it('no muestra el aviso cuando ningún artículo tiene errorPrecioEspecial', () => {
            render(<MassiveLoadTabs correctItems={[baseProduct]} errorItems={[]} />);

            expect(screen.queryByText('Los productos señalados se cargaran al pedido pero no se solicitarán token')).not.toBeInTheDocument();
        });

        it('no muestra el aviso cuando correctItems está vacío', () => {
            render(<MassiveLoadTabs correctItems={[]} errorItems={[]} />);

            expect(screen.queryByText('Los productos señalados se cargaran al pedido pero no se solicitarán token')).not.toBeInTheDocument();
        });

        it('muestra el aviso cuando solo uno de varios artículos tiene errorPrecioEspecial', () => {
            const products = [
                { ...baseProduct, productoId: 1, errorPrecioEspecial: false },
                { ...baseProduct, productoId: 2, errorPrecioEspecial: true },
            ];
            render(<MassiveLoadTabs correctItems={products} errorItems={[]} />);

            expect(screen.getByText('Los productos señalados se cargaran al pedido pero no se solicitarán token')).toBeInTheDocument();
        });
    });

    describe('renderizado de tarjetas', () => {
        it('renderiza una tarjeta por cada artículo correcto', () => {
            const products = [
                { ...baseProduct, productoId: 1 },
                { ...baseProduct, productoId: 2 },
                { ...baseProduct, productoId: 3 },
            ];
            render(<MassiveLoadTabs correctItems={products} errorItems={[]} />);

            expect(screen.getByTestId('product-card-1')).toBeInTheDocument();
            expect(screen.getByTestId('product-card-2')).toBeInTheDocument();
            expect(screen.getByTestId('product-card-3')).toBeInTheDocument();
        });

        it('renderiza una tarjeta por cada artículo con error en la pestaña de errores', () => {
            const errors = [
                { ...errorProduct, productoId: 10 },
                { ...errorProduct, productoId: 11 },
            ];
            render(<MassiveLoadTabs correctItems={[]} errorItems={errors} />);

            fireEvent.click(screen.getByText('ARTICULOS ERRORES'));

            expect(screen.getByTestId('product-card-10')).toBeInTheDocument();
            expect(screen.getByTestId('product-card-11')).toBeInTheDocument();
        });

        it('no muestra ninguna tarjeta cuando correctItems está vacío', () => {
            render(<MassiveLoadTabs correctItems={[]} errorItems={[errorProduct]} />);

            expect(screen.queryByTestId('product-card-1')).not.toBeInTheDocument();
        });
    });
});
