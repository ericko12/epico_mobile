import { render, screen, within } from '@testing-library/react';
import TableCustomers from '@/features/customer/infrastructure/ui/customerlist/table/TableCustomers';
import {
    COLUMNS_CLIENTES,
    COLUMNS_CLIENTES_TARJETA,
} from '@/features/customer/infrastructure/ui/customerlist/table/TableCustomers.data';
import { ICustomer } from '@/features/customer/domain/interface/ICustomer';

const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

// La rama de escritorio se sustituye por un centinela que guarda las columnas recibidas.
const mockDesktopGrid = jest.fn();
jest.mock('@/features/common/infrastructure/ui/tables/DataGridServerPagination', () => ({
    DataGridServerPagination: (props: unknown) => {
        mockDesktopGrid(props);
        return <div data-testid="desktop-grid" />;
    },
}));

jest.mock('next/navigation', () => ({
    useRouter: () => ({ push: jest.fn() }),
}));

jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));

/**
 * Clientes usa `AdaptiveDataGrid` con la tarjeta derivada de las columnas. El original
 * agregó la columna "Teléfono" con un aviso cuando el número se repite con otro cliente,
 * y ese aviso vive en un `Tooltip`: en táctil no hay hover, así que la tarjeta lo pinta a
 * la vista. Estos casos fijan esa paridad y que escritorio siga con sus columnas intactas.
 */
describe('Clientes — aviso de teléfono repetido en la tarjeta móvil', () => {
    const AVISO = 'El teléfono también está registrado en otro cliente con RFC distinto';

    const CLIENTE_BASE: ICustomer = {
        clienteID: 713115,
        nombre: 'REFACCIONARIA DEL VALLE',
        apellidoPaterno: '',
        apellidoMaterno: '',
        clasificacion: 'Taller',
        subClasificacion: 'Mecánico',
        fechaAlta: '2024-01-15',
        total: 1,
        statusCredito: 'Al corriente',
        clienteVendedorId: 991,
        vendedorId: 12,
        nombreVendedor: 'JUAN PÉREZ',
        sucursalId: 1,
        sucursal: 'GUADALAJARA',
        esCorporativo: false,
        rfc: 'RDV010101AAA',
        referenciaBancaria: 123456,
    };

    const pintar = (rows: ICustomer[], isMobileExperience: boolean) => {
        mockDimensions.mockReturnValue({ isMobileExperience });
        return render(
            <TableCustomers
                loading={false}
                data={rows}
                total={rows.length}
                paginationModel={{ page: 0, pageSize: 10 }}
                onPaginationModelChange={jest.fn()}
                searchText="3312345678"
                initialSearch={false}
            />
        );
    };

    beforeEach(() => jest.clearAllMocks());

    it('la tarjeta muestra el teléfono y el texto del aviso a la vista', () => {
        pintar([{ ...CLIENTE_BASE, telefono: '3312345678', advertenciaTelefono: AVISO }], true);

        expect(screen.getByText('Teléfono')).toBeInTheDocument();
        expect(screen.getByText('3312345678')).toBeInTheDocument();
        // Sin hover: el texto del Tooltip de escritorio tiene que estar pintado.
        expect(screen.getByText(AVISO)).toBeInTheDocument();
    });

    it('sin aviso no pinta nada extra, y sin teléfono pinta la raya de vacío', () => {
        pintar([
            { ...CLIENTE_BASE, clienteVendedorId: 1, telefono: '3398765432', advertenciaTelefono: null },
            { ...CLIENTE_BASE, clienteVendedorId: 2, nombre: 'AUTOPARTES DOS', telefono: null },
        ], true);

        expect(screen.getByText('3398765432')).toBeInTheDocument();
        expect(screen.queryByText(AVISO)).not.toBeInTheDocument();

        const tarjetaSinTelefono = screen.getByText('AUTOPARTES DOS').closest('.MuiPaper-root') as HTMLElement;
        const etiqueta = within(tarjetaSinTelefono).getByText('Teléfono');
        expect(etiqueta.nextElementSibling).toHaveTextContent('—');
    });

    it('la tarjeta conserva todas las columnas de escritorio, en el mismo orden', () => {
        const escritorio = COLUMNS_CLIENTES().map((col) => col.field);
        const tarjeta = COLUMNS_CLIENTES_TARJETA().map((col) => col.field);

        expect(tarjeta).toEqual(escritorio);
        expect(tarjeta).toContain('telefono');
    });

    it('escritorio recibe las columnas del original, con el aviso en Tooltip', async () => {
        pintar([{ ...CLIENTE_BASE, telefono: '3312345678', advertenciaTelefono: AVISO }], false);

        // El grid de escritorio se carga con `next/dynamic`: llega en un tick posterior.
        expect(await screen.findByTestId('desktop-grid')).toBeInTheDocument();
        const { columns } = mockDesktopGrid.mock.calls[0][0] as { columns: ReturnType<typeof COLUMNS_CLIENTES> };
        expect(columns.map((col) => col.field)).toEqual(COLUMNS_CLIENTES().map((col) => col.field));

        // La celda de escritorio es la de ellos: el aviso no se pinta hasta el hover.
        const telefono = columns.find((col) => col.field === 'telefono')!;
        const celda = telefono.renderCell!({
            value: '3312345678',
            row: { ...CLIENTE_BASE, telefono: '3312345678', advertenciaTelefono: AVISO },
        } as never);
        render(<>{celda}</>);
        expect(screen.getByText('3312345678')).toBeInTheDocument();
        expect(screen.queryByText(AVISO)).not.toBeInTheDocument();
    });
});
