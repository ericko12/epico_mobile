import { render, screen } from '@testing-library/react';
import { SearchAndFilter } from '@/features/customer/infrastructure/ui/customerlist/form/SearchAndFilter';

const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));

jest.mock('@/features/branch/application/actions/fetchBranchesAction', () => ({
    fetchBranchesAction: jest.fn().mockResolvedValue([]),
}));

// Los filtros no participan en lo que se prueba aquí: se sustituyen por centinelas.
jest.mock('@/features/branch/infrastructure/ui/selects/AutoCompleteBranch', () => ({
    AutoCompleteBranch: () => <div data-testid="filtro-sucursal" />,
}));
jest.mock('@/features/customer/infrastructure/ui/customerlist/form/AutoCompleteClassification', () => ({
    AutoCompleteClassification: () => <div data-testid="filtro-clasificacion" />,
}));
jest.mock('@/features/common/infrastructure/ui/datePicker/DatePickerGeneric', () => ({
    DatePickerGeneric: () => <div data-testid="filtro-fecha" />,
}));
jest.mock('@/features/common/infrastructure/ui/tables/CustomExportButton/CustomExportButton', () => ({
    CustomExportButton: () => <div data-testid="exportar" />,
}));

/**
 * El original alargó el placeholder del buscador de clientes para anunciar la búsqueda por
 * teléfono. A 320px el campo deja ~140px de texto y el placeholder se cortaba antes de
 * llegar a "teléfono(10 dígitos)": en móvil el placeholder es corto y la lista completa de
 * lo que se puede buscar se pinta debajo del campo. Escritorio conserva su placeholder.
 */
describe('Clientes — pista del buscador', () => {
    const PISTA = 'Buscar por id, nombre, vendedor, rfc, ref. bancaria o teléfono(10 dígitos)';

    beforeEach(() => jest.clearAllMocks());

    it('en móvil el placeholder es corto y la pista completa se ve debajo del campo', async () => {
        mockDimensions.mockReturnValue({ isMobileExperience: true });
        render(<SearchAndFilter searchText="" />);

        expect(await screen.findByPlaceholderText('Buscar cliente')).toBeInTheDocument();
        expect(screen.getByText(PISTA)).toBeInTheDocument();
    });

    it('en escritorio el placeholder es el del original y no hay pista aparte', async () => {
        mockDimensions.mockReturnValue({ isMobileExperience: false });
        render(<SearchAndFilter searchText="" />);

        expect(await screen.findByPlaceholderText(PISTA)).toBeInTheDocument();
        expect(screen.queryByText(PISTA)).not.toBeInTheDocument();
    });
});
