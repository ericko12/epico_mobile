import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import ModalConflictStock from '@/features/shipment/infrastructure/ui/ShipmentFooterSectionSMC4/Dialogs/ModalConflictStock';
import { NOTIFICATIONS_SHIPMENT } from '@/features/common/infrastructure/utils/messages/notificationShipment';

// Controla el branching responsivo del modal.
const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

const setMobile = () =>
    mockDimensions.mockReturnValue({ width: 320, height: 700, isMobile: true, isTablet: false, isDesktop: false, isMobileAndTablet: true, isMobileExperience: true });
const setDesktop = () =>
    mockDimensions.mockReturnValue({ width: 1280, height: 800, isMobile: false, isTablet: false, isDesktop: true, isMobileAndTablet: false, isMobileExperience: false });

const { STOCK_CONFLICT_MODAL_MESSAGE, STOCK_CONFLICT_MODAL_MESSAGE_OPTION_TRANSFER } = NOTIFICATIONS_SHIPMENT.SMC.SMC4_FOOTER;

afterEach(() => jest.clearAllMocks());

describe('ModalConflictStock', () => {
    it('muestra el mensaje general cuando conflictStockDefault es true', () => {
        setDesktop();
        render(<ModalConflictStock open onClose={jest.fn()} onConfirm={jest.fn()} conflictStockDefault />);
        expect(screen.getByText(STOCK_CONFLICT_MODAL_MESSAGE)).toBeInTheDocument();
        expect(screen.queryByText(STOCK_CONFLICT_MODAL_MESSAGE_OPTION_TRANSFER)).not.toBeInTheDocument();
    });

    it('muestra el mensaje de traspasos cuando conflictStockDefault es false', () => {
        setDesktop();
        render(<ModalConflictStock open onClose={jest.fn()} onConfirm={jest.fn()} conflictStockDefault={false} />);
        expect(screen.getByText(STOCK_CONFLICT_MODAL_MESSAGE_OPTION_TRANSFER)).toBeInTheDocument();
        expect(screen.queryByText(STOCK_CONFLICT_MODAL_MESSAGE)).not.toBeInTheDocument();
    });

    it('conserva la acción de recalcular en móvil y la dispara al tocarla', () => {
        setMobile();
        const onConfirm = jest.fn();
        render(<ModalConflictStock open onClose={jest.fn()} onConfirm={onConfirm} conflictStockDefault />);
        fireEvent.click(screen.getByRole('button', { name: 'Recalcular opciones' }));
        expect(onConfirm).toHaveBeenCalledTimes(1);
    });

    it('en móvil el botón toma el renglón y en escritorio conserva sus 191px', () => {
        setMobile();
        const { unmount } = render(<ModalConflictStock open onClose={jest.fn()} onConfirm={jest.fn()} conflictStockDefault />);
        expect(screen.getByRole('button', { name: 'Recalcular opciones' })).toHaveStyle({ width: '100%' });
        unmount();

        setDesktop();
        render(<ModalConflictStock open onClose={jest.fn()} onConfirm={jest.fn()} conflictStockDefault />);
        expect(screen.getByRole('button', { name: 'Recalcular opciones' })).toHaveStyle({ width: '191px' });
    });
});
