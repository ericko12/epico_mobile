import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import FormShippingProviderSMC4 from '@/features/shipment/infrastructure/ui/formShippingProviderSMC4/FormShippingProviderSMC4';
import { useAppDispatch, useAppSelector } from '@/features/common/application/redux/hooks';
import { ShippingMethodSMC4Enum } from '@/features/shipment/domain/enum/ShippingMethodSMC4Enum';

jest.mock('@/features/common/application/redux/hooks');
jest.mock('@/context/snackBar/SnackBarContext', () => ({ useSnackbar: () => ({ showSnackbar: jest.fn() }) }));

// Controla el branching responsivo del formulario.
const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

// Lo que se prueba es la tira de pestañas: las peticiones del arranque se resuelven
// vacías y las piezas pesadas de abajo se sustituyen.
jest.mock('@/features/shipment/application/hooks/useShippingMethod', () => ({
    useShippingMethod: () => ({ errors: {}, validateForm: jest.fn(), resetForm: jest.fn() }),
}));
jest.mock('@/features/address/application/service/AddressService', () => ({ addressService: () => ({}) }));
jest.mock('@/features/branch/application/services/branch.services', () => ({
    branchService: () => ({ getBranchOnRegionByCustomerId: jest.fn().mockResolvedValue({ data: [] }) }),
}));
jest.mock('@/features/common/application/handleRequestDto/handleRequestDto', () => ({ handleRequestDto: jest.fn() }));
jest.mock('@/features/shipment/application/actions/fetchCustomerAddressesAction', () => ({
    fetchCustomerAddressesAction: jest.fn().mockResolvedValue([]),
}));
jest.mock('@/features/shipment/application/actions/fetchContactsAction', () => ({
    fetchContactsAction: jest.fn().mockResolvedValue([]),
}));
jest.mock('@/features/customer/application/actions/db/CustomersRepository', () => ({
    fetchCustomerIndexDBByCustomerSeller: jest.fn().mockResolvedValue(null),
}));
jest.mock('@/features/common/application/action/fetchParameter', () => ({
    fetchParameter: jest.fn().mockResolvedValue({ value: 'true' }),
}));
jest.mock('@/features/shipment/application/actions/fetchEvaluateOrderAlgorithmSMC4', () => ({ fetchEvaluateOrderAlgorithmSMC4: jest.fn() }));
jest.mock('@/features/shipment/application/actions/fetchValidateExcepcionAddress', () => ({ fetchValidateExcepcionAddress: jest.fn() }));
jest.mock('@/features/products/application/actions/fetchPostDeniedProducts', () => ({ fetchPostDeniedProducts: jest.fn() }));
jest.mock('@/features/orders/application/actions/fetchOrdersAction', () => ({ UpdateOrderService: jest.fn() }));
jest.mock('@/features/shipment/application/redux/ShipmentThunks', () => ({
    handleMultiInfoShippingChangeThunk: jest.fn(() => ({ type: 'MOCK_MULTI' })),
}));
// La cadena de acciones llega al service worker (@serwist/window, ESM, que Jest no
// transforma); no participa en lo que se prueba aquí.
jest.mock('@/features/common/application/dbStoreMessage', () => ({ dbStoreMessage: jest.fn() }));
jest.mock('@/features/checkout/infrastructure/ui/miniCheckoutsPreview/MiniCheckoutsPreview', () => ({
    __esModule: true,
    default: () => <div data-testid="mini-checkouts-preview" />,
}));
jest.mock('@/features/shipment/infrastructure/ui/formShippingProviderSMC4/forms/FormShippingContactDetails', () => ({
    __esModule: true,
    default: () => null,
}));
jest.mock('@/features/shipment/infrastructure/ui/formShippingProviderSMC4/dialog/ModalSegment', () => ({ ModalSegment: () => null }));
jest.mock('@/features/shipment/infrastructure/ui/formShippingProviderSMC4/dialog/ModalChangeShippingMethod', () => ({
    ModalChangeShippingMethod: () => null,
}));
jest.mock('next/image', () => ({
    __esModule: true,
    default: ({ alt }: { alt: string }) => <span data-testid={alt} />,
}));

const setMobile = () =>
    mockDimensions.mockReturnValue({ width: 320, height: 700, isMobile: true, isTablet: false, isDesktop: false, isMobileAndTablet: true, isMobileExperience: true });
const setDesktop = () =>
    mockDimensions.mockReturnValue({ width: 1280, height: 800, isMobile: false, isTablet: false, isDesktop: true, isMobileAndTablet: false, isMobileExperience: false });

const MOTIVO_SIN_DOMICILIO = 'Este pedido no es elegible para envío a domicilio';

/** Estado mínimo: pedido en Pickup con la vista previa de mini cajas abierta. */
const buildState = (allArticlesExclusivePickup: boolean) => ({
    localState: { authState: { userAuth: {} } },
    sessionState: {
        shipmentState: {
            formPendingFields: false,
            formValidatedFields: false,
            miniCheckoutSMC4State: { loadingMiniCheckoutSMC4: false },
            miniCheckoutDivision: { loadingDivision: false },
            orderShipmentSMC4: [
                { pedidoID: 1, MetodoEnvio: ShippingMethodSMC4Enum.Pickup, isPreviewMiniCheckouts: true, allArticlesExclusivePickup },
            ],
        },
        loyaltyPlanState: { customers: {} },
        checkOutsState: { selectedOrderSummary: { pedidoID: 1, clienteId: 999999, clienteVendedorId: 1, detalles: [] } },
        branchesState: { branchesList: [] },
    },
});

const renderForm = async (allArticlesExclusivePickup: boolean) => {
    const state = buildState(allArticlesExclusivePickup);
    (useAppSelector as jest.Mock).mockImplementation((selector: (s: typeof state) => unknown) => selector(state));
    const utils = render(<FormShippingProviderSMC4 />);
    // Mientras carga, la tira deshabilita todas las pestañas (y los contactos tardan 1s
    // a propósito): se espera a que PICKUP se habilite para que el estado de la otra
    // pestaña diga algo.
    await waitFor(() => expect(getTab('PICKUP')).not.toBeDisabled(), { timeout: 3000 });
    return utils;
};

/** Pestaña por su texto (el nombre accesible lo pisa el aria-label del tooltip). */
const getTab = (label: string) =>
    screen.getAllByRole('tab').find((tab) => tab.textContent?.includes(label));
const getDeliveryTab = () => getTab('ENVÍO A DOMICILIO');

beforeEach(() => {
    jest.clearAllMocks();
    (useAppDispatch as jest.Mock).mockReturnValue(jest.fn());
});

describe('FormShippingProviderSMC4 - motivo de la pestaña deshabilitada', () => {
    it('en móvil pinta a la vista el motivo que en escritorio va en tooltip', async () => {
        setMobile();
        await renderForm(true);
        expect(getDeliveryTab()).toBeDisabled();
        expect(screen.getByText(MOTIVO_SIN_DOMICILIO)).toBeInTheDocument();
    });

    it('en escritorio no añade la línea: el motivo sigue en el tooltip', async () => {
        setDesktop();
        await renderForm(true);
        expect(getDeliveryTab()).toBeDisabled();
        expect(screen.queryByText(MOTIVO_SIN_DOMICILIO)).not.toBeInTheDocument();
    });

    it('no pinta el motivo en móvil cuando envío a domicilio está disponible', async () => {
        setMobile();
        await renderForm(false);
        expect(getDeliveryTab()).not.toBeDisabled();
        expect(screen.queryByText(MOTIVO_SIN_DOMICILIO)).not.toBeInTheDocument();
    });
});
