import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import SelectStateCityPickup from '@/features/shipment/infrastructure/ui/formShippingProviderSMC4/forms/select/SelectStateCityPickup';
import { useAppDispatch, useAppSelector } from '@/features/common/application/redux/hooks';
import { fetchProcessBranchAddressesToStateCity } from '@/features/checkout/application/actions/fetchProcessBranchAddressesToStateCity';
import { handleInfoShippingChangeThunk, handleMultiInfoShippingChangeThunk } from '@/features/shipment/application/redux/ShipmentThunks';

jest.mock('@/features/common/application/redux/hooks');
jest.mock('@/features/checkout/application/actions/fetchProcessBranchAddressesToStateCity');
jest.mock('@/features/shipment/application/redux/ShipmentThunks', () => ({
    handleInfoShippingChangeThunk: jest.fn(() => ({ type: 'MOCK_INFO' })),
    handleMultiInfoShippingChangeThunk: jest.fn(() => ({ type: 'MOCK_MULTI' })),
}));

const mockDispatch = jest.fn();

const mockStateCityData = [
    {
        estadoId: 14,
        estado: 'Jalisco',
        cuidades: [
            { ciudadId: 101, municipioId: 0, ciudad: 'Guadalajara' },
            { ciudadId: 102, municipioId: 0, ciudad: 'Zapopan' },
        ],
    },
    {
        estadoId: 19,
        estado: 'Nuevo León',
        cuidades: [
            { ciudadId: 201, municipioId: 0, ciudad: 'Monterrey' },
        ],
    },
];

const mockSelector = (shipmentOverride?: any) => (selector: any) =>
    selector({
        sessionState: {
            checkOutsState: {
                selectedOrderSummary: { pedidoID: 123, clienteId: 999 },
            },
            shipmentState: {
                orderShipmentSMC4: shipmentOverride ?? [
                    { pedidoID: 123, StateId: undefined, CityId: undefined },
                ],
            },
        },
    });

describe('SelectStateCityPickup', () => {
    beforeEach(() => {
        jest.clearAllMocks();
        (useAppDispatch as jest.Mock).mockReturnValue(mockDispatch);
        (useAppSelector as jest.Mock).mockImplementation(mockSelector());
        (fetchProcessBranchAddressesToStateCity as jest.Mock).mockResolvedValue(mockStateCityData);
    });

    it('renders the Estado and Ciudad autocompletes', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        expect(await screen.findByText('Estado')).toBeInTheDocument();
        expect(screen.getByText('Ciudad')).toBeInTheDocument();
    });

    it('loads and shows states from fetchProcessBranchAddressesToStateCity', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        // Wait for loading to finish
        await waitFor(() => {
            const inputs = screen.getAllByRole('combobox');
            expect(inputs[0]).not.toBeDisabled();
        });

        const stateInput = screen.getAllByRole('combobox')[0];
        fireEvent.change(stateInput, { target: { value: 'Jal' } });

        expect(await screen.findByRole('option', { name: 'Jalisco' })).toBeInTheDocument();
    });

    it('ciudad autocomplete is disabled until a state is selected', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            const inputs = screen.getAllByRole('combobox');
            expect(inputs[0]).not.toBeDisabled();
        });

        const cityInput = screen.getAllByRole('combobox')[1];
        expect(cityInput).toBeDisabled();
    });

    it('shows filtered cities after selecting a state', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            expect(screen.getAllByRole('combobox')[0]).not.toBeDisabled();
        });

        // Select state "Jalisco"
        const stateInput = screen.getAllByRole('combobox')[0];
        fireEvent.change(stateInput, { target: { value: 'Jalisco' } });
        const jaliscoOption = await screen.findByRole('option', { name: 'Jalisco' });
        fireEvent.click(jaliscoOption);

        // Ciudad should now be enabled with Jalisco's cities
        const cityInput = screen.getAllByRole('combobox')[1];
        await waitFor(() => expect(cityInput).not.toBeDisabled());

        fireEvent.change(cityInput, { target: { value: 'Gua' } });
        expect(await screen.findByRole('option', { name: 'Guadalajara' })).toBeInTheDocument();
    });

    it('dispatches handleMultiInfoShippingChangeThunk with StateId and CityId: undefined when state changes', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            expect(screen.getAllByRole('combobox')[0]).not.toBeDisabled();
        });

        const stateInput = screen.getAllByRole('combobox')[0];
        fireEvent.change(stateInput, { target: { value: 'Jalisco' } });
        const jaliscoOption = await screen.findByRole('option', { name: 'Jalisco' });
        fireEvent.click(jaliscoOption);

        expect(handleMultiInfoShippingChangeThunk).toHaveBeenCalledWith(
            { StateId: 14, CityId: undefined },
            123
        );
        expect(mockDispatch).toHaveBeenCalled();
    });

    it('dispatches handleInfoShippingChangeThunk with CityId when city is selected', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            expect(screen.getAllByRole('combobox')[0]).not.toBeDisabled();
        });

        // Select state first
        const stateInput = screen.getAllByRole('combobox')[0];
        fireEvent.change(stateInput, { target: { value: 'Jalisco' } });
        fireEvent.click(await screen.findByRole('option', { name: 'Jalisco' }));

        // Now select city
        const cityInput = screen.getAllByRole('combobox')[1];
        await waitFor(() => expect(cityInput).not.toBeDisabled());
        fireEvent.change(cityInput, { target: { value: 'Guadalajara' } });
        fireEvent.click(await screen.findByRole('option', { name: 'Guadalajara' }));

        expect(handleInfoShippingChangeThunk).toHaveBeenCalledWith('CityId', 101, 123);
        expect(mockDispatch).toHaveBeenCalled();
    });

    it('resets city when a different state is selected', async () => {
        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            expect(screen.getAllByRole('combobox')[0]).not.toBeDisabled();
        });

        // Select Jalisco first
        const stateInput = screen.getAllByRole('combobox')[0];
        fireEvent.change(stateInput, { target: { value: 'Jalisco' } });
        fireEvent.click(await screen.findByRole('option', { name: 'Jalisco' }));

        // Select Guadalajara city
        const cityInput = screen.getAllByRole('combobox')[1];
        await waitFor(() => expect(cityInput).not.toBeDisabled());
        fireEvent.change(cityInput, { target: { value: 'Guadalajara' } });
        fireEvent.click(await screen.findByRole('option', { name: 'Guadalajara' }));

        // Now change state to Nuevo León — CityId should reset
        fireEvent.change(stateInput, { target: { value: 'Nuevo León' } });
        fireEvent.click(await screen.findByRole('option', { name: 'Nuevo León' }));

        expect(handleMultiInfoShippingChangeThunk).toHaveBeenLastCalledWith(
            { StateId: 19, CityId: undefined },
            123
        );
    });

    it('shows stateId error message when errors.stateId is provided', async () => {
        render(
            <SelectStateCityPickup
                errors={{ stateId: ['El estado es requerido'] }}
            />
        );

        expect(await screen.findByText('El estado es requerido')).toBeInTheDocument();
    });

    it('shows cityId error message when errors.cityId is provided', async () => {
        render(
            <SelectStateCityPickup
                errors={{ cityId: ['La ciudad es requerida'] }}
            />
        );

        expect(await screen.findByText('La ciudad es requerida')).toBeInTheDocument();
    });

    it('initializes with pre-selected state and city from Redux', async () => {
        (useAppSelector as jest.Mock).mockImplementation(
            mockSelector([{ pedidoID: 123, StateId: 14, CityId: 101 }])
        );

        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            expect(screen.getByDisplayValue('Jalisco')).toBeInTheDocument();
        });

        await waitFor(() => {
            expect(screen.getByDisplayValue('Guadalajara')).toBeInTheDocument();
        });
    });

    it('shows "Sin opciones" when fetchProcessBranchAddressesToStateCity returns null', async () => {
        (fetchProcessBranchAddressesToStateCity as jest.Mock).mockResolvedValue(null);

        render(<SelectStateCityPickup errors={{}} />);

        await waitFor(() => {
            expect(screen.getAllByRole('combobox')[0]).not.toBeDisabled();
        });

        const stateInput = screen.getAllByRole('combobox')[0];
        fireEvent.change(stateInput, { target: { value: 'any' } });

        expect(await screen.findByText('Sin opciones')).toBeInTheDocument();
    });
});
