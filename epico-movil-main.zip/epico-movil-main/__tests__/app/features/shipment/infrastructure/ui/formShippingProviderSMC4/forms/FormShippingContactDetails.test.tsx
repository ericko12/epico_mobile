import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import FormShippingContactDetails from '@/features/shipment/infrastructure/ui/formShippingProviderSMC4/forms/FormShippingContactDetails';
import { useAppSelector } from '@/features/common/application/redux/hooks';
import { ShippingMethodSMC4Enum, ShippingMethodSMC4EnumIndex } from '@/features/shipment/domain/enum/ShippingMethodSMC4Enum';
import { TipoPersonaRecogera } from '@/features/checkout/domain/enums/TipoPersonaRecogera';
import { FormShippingContactDetailsProps } from '@/features/shipment/infrastructure/ui/formShippingProviderSMC4/forms/FormShippingContactDetails.types';
import { IContact } from '@/features/customer/domain/interface/contact/IContact';

jest.mock('@/features/common/application/redux/hooks');
// Los dos componentes de dirección de clientes invitados arrastran Google Maps y no
// son parte de lo que se prueba aquí.
jest.mock('@/features/common/infrastructure/ui/google/map/SearchAddressMaps', () => ({
    __esModule: true,
    default: () => <div data-testid="search-address-maps" />,
}));
jest.mock('@/features/shipment/infrastructure/ui/formShippingProviderSMC4/forms/select/SelectStateCityPickup', () => ({
    __esModule: true,
    default: () => <div data-testid="select-state-city" />,
}));

// Controla el branching responsivo del formulario.
const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

const setMobile = () =>
    mockDimensions.mockReturnValue({ width: 320, height: 700, isMobile: true, isTablet: false, isDesktop: false, isMobileAndTablet: true, isMobileExperience: true });
const setDesktop = () =>
    mockDimensions.mockReturnValue({ width: 1280, height: 800, isMobile: false, isTablet: false, isDesktop: true, isMobileAndTablet: false, isMobileExperience: false });

const MOTIVO_SIN_CONTACTOS = 'El cliente no cuenta con contactos';

/** Radio de "Persona que recogerá" por su valor. */
const getRadio = (value: TipoPersonaRecogera) =>
    document.querySelector(`input[name="person-who-collects"][value="${value}"]`);

const mockSelector = (selector: (state: unknown) => unknown) =>
    selector({
        sessionState: {
            checkOutsState: {
                // Cliente que no es de mostrador: se pinta el selector de direcciones.
                selectedOrderSummary: { pedidoID: 123, clienteId: 999999 },
            },
            shipmentState: {
                orderShipmentSMC4: [
                    { pedidoID: 123, MetodoEnvio: ShippingMethodSMC4Enum.Pickup, TipoPersonaRecogera: TipoPersonaRecogera.Cliente },
                ],
            },
        },
    });

const renderForm = (overrides: Partial<FormShippingContactDetailsProps> = {}) =>
    render(
        <FormShippingContactDetails
            customerAddresses={[]}
            numTabSelected={ShippingMethodSMC4EnumIndex.Pickup}
            listContacts={[]}
            errors={{}}
            forceNormalize={false}
            shouldValidateForm
            handleInfoShippingChange={jest.fn()}
            handleMultiInfoShippingChange={jest.fn()}
            {...overrides}
        />,
    );

beforeAll(() => {
    // jsdom no trae ResizeObserver y SelectGeneric lo usa para detectar truncado.
    (globalThis as unknown as { ResizeObserver?: unknown }).ResizeObserver ??= class {
        observe() { }
        unobserve() { }
        disconnect() { }
    };
});

beforeEach(() => {
    jest.clearAllMocks();
    (useAppSelector as jest.Mock).mockImplementation(mockSelector);
});

describe('FormShippingContactDetails - motivo de la opción deshabilitada', () => {
    it('en móvil pinta a la vista el motivo que en escritorio va en tooltip', async () => {
        setMobile();
        renderForm();
        // Sin contactos, "Cliente" se deshabilita al montar y el motivo tiene que verse.
        expect(await screen.findByText(MOTIVO_SIN_CONTACTOS)).toBeInTheDocument();
    });

    it('en escritorio no añade la línea: el motivo sigue en el tooltip', async () => {
        setDesktop();
        renderForm();
        // Se espera a que el efecto deshabilite la opción antes de mirar. (El tooltip le
        // pone el motivo como aria-label, por eso se busca el radio por su valor.)
        await waitFor(() => expect(getRadio(TipoPersonaRecogera.Cliente)).toBeDisabled());
        expect(screen.queryByText(MOTIVO_SIN_CONTACTOS)).not.toBeInTheDocument();
    });

    it('no pinta el motivo en móvil cuando la opción está habilitada', () => {
        setMobile();
        renderForm({
            listContacts: [{ contactoId: 1, contacto: 'JUAN PEREZ', principal: true } as unknown as IContact],
        });
        expect(getRadio(TipoPersonaRecogera.Cliente)).not.toBeDisabled();
        expect(screen.queryByText(MOTIVO_SIN_CONTACTOS)).not.toBeInTheDocument();
    });
});

describe('FormShippingContactDetails - datos de contacto', () => {
    it('el teléfono declara el teclado telefónico porque descarta lo que no es dígito', () => {
        setMobile();
        renderForm();
        expect(document.getElementById('textfield-phone')).toHaveAttribute('inputmode', 'tel');
    });

    it('el asterisco de correo y teléfono depende de shouldValidateForm', () => {
        setMobile();
        const { unmount } = renderForm({ shouldValidateForm: true });
        // Dirección + persona que recogerá + correo + teléfono.
        expect(screen.getAllByText('*')).toHaveLength(4);
        unmount();

        renderForm({ shouldValidateForm: false });
        expect(screen.getAllByText('*')).toHaveLength(2);
    });
});
