import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { ShipmentFooterSectionSMC4 } from '@/features/shipment/infrastructure/ui/ShipmentFooterSectionSMC4/ShipmentFooterSectionSMC4';
import { useAppDispatch, useAppSelector } from '@/features/common/application/redux/hooks';
import { ShipmentSteps } from '@/features/shipment/domain/enum/ShipmentSteps';
import { setTriggerRecalculation } from '@/features/shipment/application/redux/ShipmentSlice';

jest.mock('@/features/common/application/redux/hooks');
jest.mock('next/navigation', () => ({ useRouter: () => ({ push: jest.fn() }) }));
jest.mock('@/context/snackBar/SnackBarContext', () => ({ useSnackbar: () => ({ showSnackbar: jest.fn() }) }));
jest.mock('@/features/loyaltyPlan/application/service/loyaltyPlanService', () => ({
    loyaltyPlanService: () => ({ getKmsConversion: jest.fn() }),
}));
jest.mock('@/features/shipment/application/redux/ShipmentThunks', () => ({
    handleInfoShippingChangeThunk: jest.fn(() => ({ type: 'MOCK_INFO' })),
    handleMultiInfoShippingChangeThunk: jest.fn(() => ({ type: 'MOCK_MULTI' })),
    resetSummarySMC4Thunk: jest.fn(() => ({ type: 'MOCK_RESET' })),
    setWaitingDebounceSMC4Thunk: jest.fn(() => ({ type: 'MOCK_WAITING' })),
}));
// La cadena de acciones del pie llega al service worker (@serwist/window, ESM, que Jest
// no transforma); no participa en lo que se prueba aquí.
jest.mock('@/features/common/application/dbStoreMessage', () => ({
    dbStoreMessage: jest.fn(),
}));
// Los modales no se abren en estas pruebas; se sustituyen para no arrastrar sus dependencias.
jest.mock('@/features/shipment/infrastructure/ui/retentions/RetentionsModal', () => ({
    RetentionsModal: () => null,
}));
jest.mock('@/features/shipment/infrastructure/ui/ShipmentFooterSectionSMC4/Dialogs/modalPickupPerson/ModalPickupPerson', () => ({
    __esModule: true,
    default: () => null,
}));

const mockDispatch = jest.fn();

/** Estado mínimo del pie: paso de envío con la vista previa de mini cajas abierta. */
const buildState = (recalculationRequired: boolean) => ({
    localState: { authState: { userAuth: { userId: 1 } } },
    sessionState: {
        checkOutsState: {
            selectedOrderSummary: { pedidoID: 1, clienteId: 999999, estatusID: 0, subTotalIVA: 116, subTotal: 100, ivaCalculado: 16 },
        },
        shipmentState: {
            shipmentsSteps: { 1: { activeStep: ShipmentSteps.SendMethod } },
            formPendingFields: false,
            formValidatedFields: false,
            miniCheckoutSMC4State: {
                resultSMC4: {
                    recomendada: [{ infoSucursalId: 10, articulos: [{ sku: 'A1', cantidad: 1 }], recalculationRequired }],
                    opcional: [],
                    articulosSinStock: [],
                },
                summary: { apply: false, loadingSummary: false, total: 0 },
                loadingMiniCheckoutSMC4: false,
                waitingDebounce: false,
            },
            miniCheckoutDivision: { loadingDivision: false },
            orderShipmentSMC4: [{ pedidoID: 1, isPreviewMiniCheckouts: true, optionChecked: 1 }],
        },
        branchesState: { branchesList: [] },
        loyaltyPlanState: { customers: {} },
    },
});

const renderFooter = (recalculationRequired: boolean) => {
    const state = buildState(recalculationRequired);
    (useAppSelector as jest.Mock).mockImplementation((selector: any) => selector(state));
    return render(<ShipmentFooterSectionSMC4 handleBackSMC={jest.fn()} />);
};

beforeEach(() => {
    jest.clearAllMocks();
    (useAppDispatch as jest.Mock).mockReturnValue(mockDispatch);
});

describe('ShipmentFooterSectionSMC4 - botón Recalcular', () => {
    it('con una opción que pide recalcular, el botón principal dice Recalcular y dispara el recálculo', () => {
        renderFooter(true);
        expect(screen.getByRole('button', { name: 'Regresar' })).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Recalcular' }));
        expect(mockDispatch).toHaveBeenCalledWith(setTriggerRecalculation(true));
    });

    it('sin recálculo pendiente conserva Continuar', () => {
        renderFooter(false);
        expect(screen.getByRole('button', { name: 'Continuar' })).toBeInTheDocument();
        expect(screen.queryByRole('button', { name: 'Recalcular' })).not.toBeInTheDocument();
    });
});
