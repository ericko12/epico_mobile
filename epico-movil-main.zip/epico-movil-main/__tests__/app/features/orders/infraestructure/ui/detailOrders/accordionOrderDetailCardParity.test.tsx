import { render, screen, within } from '@testing-library/react';
import AccordionOrderDetail from '@/features/orders/infraestructure/ui/detailOrders/accordionOrder/AccordionOrderDetail';
import { COLUMNS } from '@/features/orders/infraestructure/ui/detailOrders/accordionOrder/accordionOrderDetail.data';
import { CoinFormatter } from '@/features/common/infrastructure/utils/models/CoinFormatter';
import { IDepartureBranch } from '@/features/branch/domain/interfaces/branch/IDepartureBranch';

const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

jest.mock('@/features/common/infrastructure/ui/tables/DataGridServerPagination', () => ({
    DataGridServerPagination: () => <div data-testid="desktop-grid" />,
}));

// Estado mínimo: cliente sin plan de lealtad, así que la columna de Kms se filtra.
jest.mock('@/features/common/application/redux/hooks', () => ({
    useAppSelector: (selector: (state: unknown) => unknown) =>
        selector({
            sessionState: {
                customerInfoState: { customer: { clienteId: 713115 } },
                loyaltyPlanState: { customers: {} },
            },
        }),
}));

jest.mock('@/features/loyaltyPlan/application/service/loyaltyPlanService', () => ({
    loyaltyPlanService: () => ({ getKmsConversion: jest.fn() }),
}));

jest.mock('@/features/orders/application/services/order.services', () => ({
    ordersService: () => ({ getOrderMonitoringDetails: jest.fn() }),
}));

jest.mock('@/context/snackBar/SnackBarContext', () => ({
    useSnackbar: () => ({ showSnackbar: jest.fn() }),
}));

jest.mock('@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell', () => ({
    ImageCell: () => <span data-testid="imagen-partida" />,
}));

jest.mock('@/features/common/infrastructure/ui/summary/SummaryGeneric', () => ({
    __esModule: true,
    default: () => <div data-testid="sumario" />,
}));

jest.mock('@/features/common/infrastructure/ui/dialog/ModalGeneric', () => ({
    ModalGeneric: () => null,
}));

/**
 * El detalle de pedido compone su tarjeta móvil con `renderCard`, pero deriva los renglones
 * de datos de las columnas ya filtradas. El original agregó "P.U" (precio unitario con
 * descuentos, `precioUnitario * cantidad = precio`): estos casos fijan que la tarjeta lo
 * gane sin tocarla, con el mismo formato que la celda de escritorio.
 */
describe('Detalle de pedido — paridad de la tarjeta de partida', () => {
    const PARTIDA: IDepartureBranch = {
        productoId: 501,
        producto: 'BAL-1234',
        imagen: 'BAL-1234',
        descripcion: 'BALATA DELANTERA',
        marcaId: 7,
        marca: 'FRENOSA',
        cantidad: 4,
        precio: 1234.4,
        kmsAplicados: 0,
        precioUnitario: 308.6,
    };

    const pintarEnMovil = (dataTable: IDepartureBranch[]) => {
        mockDimensions.mockReturnValue({ isMobileExperience: true });
        return render(
            <AccordionOrderDetail
                summary={{ total: 0, descuento: 0, montoTotal: 0, pagoPuntual: 0, impuestosIVA: 0, kmsUsados: 0 }}
                dataTable={dataTable}
                deliveryMethod="RECOGER EN SUCURSAL"
                branch="GUADALAJARA"
                paymentMethod="CONTADO"
                address={null}
                addressBranch={null}
                addressDelivery={null}
                observaciones={null}
                orderId={9001}
                branchId={1}
            />
        );
    };

    const valorDe = (tarjeta: HTMLElement, etiqueta: string) =>
        within(tarjeta).getByText(etiqueta).nextElementSibling as HTMLElement;

    beforeEach(() => jest.clearAllMocks());

    it('la tarjeta muestra el P.U con el mismo formato que la celda', () => {
        pintarEnMovil([PARTIDA]);

        const tarjeta = screen.getByText('BALATA DELANTERA').closest('.MuiPaper-root') as HTMLElement;
        expect(valorDe(tarjeta, 'P.U')).toHaveTextContent(new CoinFormatter(308.6).coin);
        expect(valorDe(tarjeta, 'Precio')).toHaveTextContent(new CoinFormatter(1234.4).coin);
    });

    it('sin precio unitario pinta la raya, como en escritorio', () => {
        pintarEnMovil([{ ...PARTIDA, precioUnitario: null }]);

        const tarjeta = screen.getByText('BALATA DELANTERA').closest('.MuiPaper-root') as HTMLElement;
        expect(valorDe(tarjeta, 'P.U')).toHaveTextContent('-');
    });

    it('cada columna con encabezado, salvo imagen y descripción, es un renglón de la tarjeta', () => {
        pintarEnMovil([PARTIDA]);

        const tarjeta = screen.getByText('BALATA DELANTERA').closest('.MuiPaper-root') as HTMLElement;
        COLUMNS
            .filter((col) => !['imagen', 'descripcion', 'kmsPagados'].includes(col.field))
            .forEach((col) => expect(within(tarjeta).getByText(col.headerName!)).toBeInTheDocument());
    });
});
