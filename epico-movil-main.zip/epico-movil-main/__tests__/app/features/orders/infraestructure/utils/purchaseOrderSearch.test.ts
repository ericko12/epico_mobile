import { isMeaningfulPurchaseOrder, MAX_PURCHASE_ORDER_LENGTH, MIN_PURCHASE_ORDER_LENGTH } from '@/features/orders/infraestructure/utils/purchaseOrderSearch';

describe('purchaseOrderSearch', () => {
    describe('isMeaningfulPurchaseOrder', () => {
        it('accepts an alphanumeric purchase order', () => {
            expect(isMeaningfulPurchaseOrder('OC-2024-0155')).toBe(true);
        });

        it('accepts a numeric purchase order', () => {
            expect(isMeaningfulPurchaseOrder('4500219877')).toBe(true);
        });

        it('trims surrounding spaces before evaluating', () => {
            expect(isMeaningfulPurchaseOrder('  OC-2024-0155  ')).toBe(true);
        });

        it('rejects null', () => {
            expect(isMeaningfulPurchaseOrder(null)).toBe(false);
        });

        it('rejects undefined', () => {
            expect(isMeaningfulPurchaseOrder(undefined)).toBe(false);
        });

        it('rejects an empty string', () => {
            expect(isMeaningfulPurchaseOrder('')).toBe(false);
        });

        it('rejects a string of only spaces', () => {
            expect(isMeaningfulPurchaseOrder('   ')).toBe(false);
        });

        it('rejects a single dot', () => {
            expect(isMeaningfulPurchaseOrder('.')).toBe(false);
        });

        it('rejects a single zero', () => {
            expect(isMeaningfulPurchaseOrder('0')).toBe(false);
        });

        it('rejects a filler made only of zeros', () => {
            expect(isMeaningfulPurchaseOrder('0000')).toBe(false);
        });

        it('rejects a filler made only of dashes', () => {
            expect(isMeaningfulPurchaseOrder('----')).toBe(false);
        });

        it('accepts a purchase order that merely starts with zeros', () => {
            expect(isMeaningfulPurchaseOrder('0012A')).toBe(true);
        });
    });

    describe('length rules', () => {
        it('caps the purchase order at the VARCHAR(20) of the database', () => {
            expect(MAX_PURCHASE_ORDER_LENGTH).toBe(20);
        });

        it('requires at least 4 characters to search, same as the capture screen', () => {
            expect(MIN_PURCHASE_ORDER_LENGTH).toBe(4);
        });
    });
});
