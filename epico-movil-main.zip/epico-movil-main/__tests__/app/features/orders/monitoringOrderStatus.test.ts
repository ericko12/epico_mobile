import { resolveMonitoringOrderStatus } from '@/features/orders/infraestructure/ui/monitoring/tableOrderMonitoring/monitoringOrderStatus';
import { StatusOrderEnum } from '@/features/checkout/domain/enums/StatusOrderEnum';
import { ColorsEpico } from '@/features/common/domain/enums/ColorsEpico';

/**
 * En el monitoreo móvil el estatus se lee por color —franja de la tarjeta y píldora—
 * antes que por texto. Lo que no puede pasar es que el color invente un estatus: la
 * etiqueta siempre es la que manda el servidor, y un id desconocido se pinta neutro sin
 * perder su texto.
 */
describe('resolveMonitoringOrderStatus', () => {
    it('conserva la etiqueta del servidor', () => {
        expect(resolveMonitoringOrderStatus(StatusOrderEnum.Activo, 'Activo').etiqueta).toBe('Activo');
        expect(resolveMonitoringOrderStatus(StatusOrderEnum.Cancelado, 'Cancelado').etiqueta).toBe('Cancelado');
    });

    it('da un color propio a cada estatus conocido', () => {
        const activo = resolveMonitoringOrderStatus(StatusOrderEnum.Activo, 'Activo');
        const facturado = resolveMonitoringOrderStatus(StatusOrderEnum.Facturado, 'Facturado');
        const retenido = resolveMonitoringOrderStatus(StatusOrderEnum.Retenido, 'Retenido');

        expect(activo.color).toBe(ColorsEpico.ColorDodgerBlue);
        expect(facturado.color).toBe(ColorsEpico.ColorGreenStatusOrders);
        expect(retenido.color).toBe(ColorsEpico.ColorRedStatusOrders);
        expect(new Set([activo.color, facturado.color, retenido.color]).size).toBe(3);
    });

    it('un estatus desconocido se pinta neutro pero conserva su texto', () => {
        const raro = resolveMonitoringOrderStatus(9999, 'En revisión');

        expect(raro.etiqueta).toBe('En revisión');
        expect(raro.color).toBe(ColorsEpico.ColorDarkCharcoal);
    });

    it('sin texto del servidor muestra un guion, no una cadena vacía', () => {
        expect(resolveMonitoringOrderStatus(StatusOrderEnum.Activo, '').etiqueta).toBe('-');
    });
});
