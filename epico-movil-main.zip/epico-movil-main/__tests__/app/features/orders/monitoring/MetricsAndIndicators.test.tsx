import { fireEvent, render, screen, within } from '@testing-library/react';
import { MetricsAndIndicators } from '@/features/orders/infraestructure/ui/monitoring/metrisAndIndicatorsOrderMonitoring/MetricsAndIndicators';
import { cardBoxSx, cardIconSx, cardLabelSx, cardValueSx } from '@/features/orders/infraestructure/ui/monitoring/metrisAndIndicatorsOrderMonitoring/MetricsAndInidicatorsCards';
import { FontSizesEnum } from '@/features/common/domain/enums/FontSizes';
import { IUserPedidosSucursalesResponse } from '@/features/orders/domain/interfaces/IUserPedidosSucursalesResponse';

/**
 * La cabecera del monitoreo la rehízo el original en la release 3.39.0: siete tarjetas
 * con su explicación en un Tooltip. En móvil van dos por renglón y, como un Tooltip no
 * existe en táctil, las explicaciones se pintan en una leyenda plegable.
 *
 * Estos casos fijan lo que no puede perderse con ese acomodo: los siete indicadores con
 * su número, que un resumen incompleto se lea como cero, y que la leyenda diga
 * **exactamente** lo mismo que los Tooltips de escritorio.
 */
describe('MetricsAndIndicators', () => {
    const ETIQUETAS = [
        'Pedidos Creados',
        'Pedidos surtidos con retraso',
        'Pedidos surtidos en tiempo',
        'Pedidos sin surtir',
        'Pedidos Mostrador',
        'Pedidos sin trazabilidad surtidos',
        'Pedidos Finalizados',
    ];

    const RESUMEN = {
        usuarioPedidos: [],
        cantidadRegistros: 12,
        pedidosAtrasados: 4,
        pedidosATiempo: 9,
        pedidosSinSurtir: 3,
        pedidosMostrador: 5,
        pedidosSinTrazabilidad: 2,
        pedidosFinalizados: 7,
    } as IUserPedidosSucursalesResponse;

    /** Lo que llega cuando el resumen viene sin conteos: la lista y nada más. */
    const SIN_CONTEOS = { usuarioPedidos: [] } as unknown as IUserPedidosSucursalesResponse;

    it('muestra los siete indicadores con su valor', () => {
        render(<MetricsAndIndicators dataRequests={RESUMEN} />);

        // Cada etiqueta sale dos veces: en su tarjeta y en la leyenda (oculta en escritorio).
        ETIQUETAS.forEach((etiqueta) => expect(screen.getAllByText(etiqueta)).toHaveLength(2));
        ['12', '4', '9', '3', '5', '2', '7'].forEach((valor) => expect(screen.getByText(valor)).toBeInTheDocument());
    });

    it('un resumen vacío se lee como siete ceros', () => {
        render(<MetricsAndIndicators dataRequests={SIN_CONTEOS} />);

        expect(screen.getAllByText('0')).toHaveLength(7);
        expect(screen.queryByText('NaN')).not.toBeInTheDocument();
    });

    it('la leyenda móvil está cerrada al entrar y se abre con su botón', () => {
        render(<MetricsAndIndicators dataRequests={RESUMEN} />);

        const boton = screen.getByRole('button', { name: '¿Qué mide cada indicador?' });
        const leyenda = document.getElementById('leyenda-indicadores-monitoreo');
        // Siempre en el DOM, para que `aria-controls` apunte a algo que existe.
        expect(leyenda).not.toBeNull();
        expect(boton).toHaveAttribute('aria-controls', 'leyenda-indicadores-monitoreo');
        expect(boton).toHaveAttribute('aria-expanded', 'false');
        expect(leyenda).toHaveAttribute('hidden');

        fireEvent.click(boton);

        expect(boton).toHaveAttribute('aria-expanded', 'true');
        expect(leyenda).not.toHaveAttribute('hidden');
    });

    it('la leyenda dice lo mismo que los Tooltips de escritorio, indicador por indicador', () => {
        render(<MetricsAndIndicators dataRequests={RESUMEN} />);
        fireEvent.click(screen.getByRole('button', { name: '¿Qué mide cada indicador?' }));
        const leyenda = document.getElementById('leyenda-indicadores-monitoreo') as HTMLElement;

        // El Tooltip de MUI deja su texto en el `aria-label` de la tarjeta mientras está
        // cerrado: es la misma cadena que se mostraría al pasar el ratón.
        ETIQUETAS.forEach((etiqueta) => {
            const tarjeta = screen.getAllByText(etiqueta)[0].closest('[aria-label]');
            const tooltip = tarjeta?.getAttribute('aria-label')?.trim();
            const termino = within(leyenda).getByText(etiqueta);
            const definicion = termino.nextElementSibling?.textContent?.trim();

            expect(tooltip).toBeTruthy();
            expect(definicion).toBe(tooltip);
        });
    });

    it('en escritorio las tarjetas conservan los valores del original', () => {
        // Nada más protege "escritorio idéntico": el tratamiento móvil vive en estos
        // mismos objetos, y un `md` cambiado no lo vería ningún otro test.
        expect(cardBoxSx.padding.md).toBe('20px');
        expect(cardBoxSx.height.md).toBe('132px');
        expect(cardLabelSx.fontSize.md).toBe(FontSizesEnum.Gamma);
        expect(cardLabelSx.minHeight.md).toBe('2.4em');
        expect(cardLabelSx.display.md).toBe('-webkit-box');
        expect(cardLabelSx.WebkitLineClamp.md).toBe(2);
        expect(cardValueSx.fontSize.md).toBe(FontSizesEnum.Lota);
        expect(cardIconSx.fontSize.md).toBe(FontSizesEnum.Eta);
    });
});
