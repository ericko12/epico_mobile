import { render, screen, fireEvent } from '@testing-library/react';
import { AdaptiveDataGrid } from '@/features/common/infrastructure/ui/tables/adaptiveDataGrid/AdaptiveDataGrid';
import { COLUMNS_PAYMENT_PROCESSING } from '@/features/billing/infrastructure/ui/paymentProcessing/PaymentProcessing.data';
import { IPoolListPreReconciliation } from '@/features/pool/domain/interface/pool/IPoolListPreReconciliationResponse';
import { OrigenEnum } from '@/features/common/domain/enums/OrigenEnum';

const mockDimensions = jest.fn();
jest.mock('@/features/common/infrastructure/hooks/getDimensions', () => ({
    __esModule: true,
    default: () => mockDimensions(),
}));

jest.mock('@/features/common/infrastructure/ui/tables/DataGridServerPagination', () => ({
    DataGridServerPagination: () => <div data-testid="desktop-grid" />,
}));

/**
 * Cobranza (procesamiento de pagos) usa `AdaptiveDataGrid` **sin** `cardOptions`: la
 * tarjeta móvil se arma sola a partir de las mismas columnas del grid. Eso es lo que hace
 * que una columna nueva del proyecto original aparezca en móvil sin tocar nada —pasó con
 * "Origen" en el release 3.33.0—, y es justo lo que dejaría de cumplirse si alguien
 * cambiara esta pantalla por una tarjeta a medida.
 *
 * Estos casos fijan ese trato: cada columna con encabezado se ve en la tarjeta con el
 * valor que pinta su `renderCell`, y la columna sin encabezado sigue siendo una acción
 * que se puede tocar.
 */
describe('Cobranza — paridad entre la fila y la tarjeta móvil', () => {
    const verPrecuadre = jest.fn();

    const FILA: IPoolListPreReconciliation = {
        idPreCuadre: 88123,
        idCliente: 713115,
        nombreCliente: 'REFACCIONARIA DEL VALLE',
        fechaSolicitud: new Date('2026-08-19T10:30:00'),
        formaPago: 'Transferencia',
        estatus: 'Pagado',
        monto: 4820.5,
        urlPrecuadre: 'https://resources.apymsa.com.mx/precuadre.pdf',
        clienteVendedorId: 991,
        origenId: OrigenEnum.Web,
    };

    const pintarEnMovil = () => {
        mockDimensions.mockReturnValue({ isMobileExperience: true });

        return render(
            <AdaptiveDataGrid
                columns={COLUMNS_PAYMENT_PROCESSING(verPrecuadre, false)}
                rows={[FILA]}
                rowCount={1}
                getRowId={(row: IPoolListPreReconciliation) => row.idPreCuadre}
            />
        );
    };

    beforeEach(() => jest.clearAllMocks());

    it('la tarjeta muestra todas las columnas con encabezado', () => {
        pintarEnMovil();

        // La primera columna es el título de la tarjeta: se ve su valor, no su etiqueta.
        expect(screen.getByText(String(FILA.idPreCuadre))).toBeInTheDocument();

        ['ID Cliente', 'Nombre del cliente', 'Origen', 'Fecha solicitud', 'Forma de pago', 'Estatus', 'Monto pagado']
            .forEach((etiqueta) => expect(screen.getByText(etiqueta)).toBeInTheDocument());
    });

    it('el origen se pinta con el nombre, no con el id', () => {
        pintarEnMovil();

        expect(screen.getByText('WEB APYMSA')).toBeInTheDocument();
        expect(screen.queryByText(String(OrigenEnum.Web))).not.toBeInTheDocument();
    });

    it('los valores salen del renderCell de cada columna', () => {
        pintarEnMovil();

        expect(screen.getByText('REFACCIONARIA DEL VALLE')).toBeInTheDocument();
        expect(screen.getByText('Transferencia')).toBeInTheDocument();
        expect(screen.getByText('19/08/2026 10:30 am')).toBeInTheDocument();
    });

    it('la columna sin encabezado sigue siendo una acción que se puede tocar', () => {
        pintarEnMovil();

        // El botón de la acción es el que lleva el ícono de abrir; los demás botones de
        // la vista son los de la paginación.
        const abrir = screen.getByTestId('LaunchIcon').closest('button');
        expect(abrir).toBeInTheDocument();

        fireEvent.click(abrir!);
        expect(verPrecuadre).toHaveBeenCalledWith(
            { folio: FILA.idPreCuadre, urlSolicitudPrecuadrePdf: FILA.urlPrecuadre },
            FILA.clienteVendedorId
        );
    });

    // El grid de escritorio se carga con un import dinámico —para que no viaje al
    // teléfono—, así que aparece en el siguiente tick.
    it('en escritorio se delega en el grid de siempre', async () => {
        mockDimensions.mockReturnValue({ isMobileExperience: false });

        render(
            <AdaptiveDataGrid
                columns={COLUMNS_PAYMENT_PROCESSING(verPrecuadre, false)}
                rows={[FILA]}
                rowCount={1}
                getRowId={(row: IPoolListPreReconciliation) => row.idPreCuadre}
            />
        );

        expect(await screen.findByTestId('desktop-grid')).toBeInTheDocument();
    });
});
