import { REHYDRATE } from 'redux-persist';
import reducer, {
    addChatMessage,
    dismissGreeting,
    resetChat,
    setAniaPosition,
    setAssistantName,
    setChatLoading,
    setChatOpen,
    setChatSession,
    setVozActiva,
} from '@/features/aiSearch/application/redux/aiSearchSlice';
import { ChatRoleEnum } from '@/features/aiSearch/domain/enums/ChatEnums';
import { IAiSearchState, IChatMessage } from '@/features/aiSearch/domain/interfaces/IAiSearchState';

/**
 * El estado del asistente se persiste cifrado en `sessionStorage`, y eso trae dos
 * reglas que no se ven leyendo el reducer: las banderas transitorias no pueden
 * sobrevivir a un reinicio, y el hilo no puede crecer sin tope porque cada
 * escritura vuelve a cifrar el árbol completo.
 */

const mensaje = (id: string): IChatMessage => ({
    id,
    rol: ChatRoleEnum.User,
    texto: 'balatas para un chevy 2005',
});

/** Estado inicial real del slice. */
const inicial = (): IAiSearchState => reducer(undefined, { type: '@@INIT' });

describe('aiSearchSlice', () => {
    it('arranca cerrado, sin conversación y con la voz encendida', () => {
        const s = inicial();
        expect(s.isOpen).toBe(false);
        expect(s.isLoading).toBe(false);
        expect(s.sessionId).toBeNull();
        expect(s.messages).toEqual([]);
        expect(s.vozActiva).toBe(true);
        expect(s.position).toBeNull();
    });

    it('abrir el chat cuenta como haber visto el saludo', () => {
        // Si no, al cerrarlo volvería a salir el globo de presentación como si
        // fuera la primera vez.
        const s = reducer(inicial(), setChatOpen(true));
        expect(s.isOpen).toBe(true);
        expect(s.greetingDismissed).toBe(true);
    });

    it('descartar el saludo no abre el chat', () => {
        const s = reducer(inicial(), dismissGreeting());
        expect(s.greetingDismissed).toBe(true);
        expect(s.isOpen).toBe(false);
    });

    it('acumula mensajes en orden', () => {
        let s = reducer(inicial(), addChatMessage(mensaje('a')));
        s = reducer(s, addChatMessage(mensaje('b')));
        expect(s.messages.map((m) => m.id)).toEqual(['a', 'b']);
    });

    it('el hilo tiene tope: cada escritura vuelve a cifrar el árbol entero', () => {
        let s = inicial();
        for (let i = 0; i < 60; i++) s = reducer(s, addChatMessage(mensaje(`m${i}`)));
        expect(s.messages).toHaveLength(40);
        // Se conservan los últimos, que son los que el usuario está leyendo.
        expect(s.messages[0].id).toBe('m20');
        expect(s.messages[39].id).toBe('m59');
    });

    it('reiniciar vacía el hilo, la conversación y la espera', () => {
        let s = reducer(inicial(), addChatMessage(mensaje('a')));
        s = reducer(s, setChatSession('abc123'));
        s = reducer(s, setChatLoading(true));
        s = reducer(s, resetChat());
        expect(s.messages).toEqual([]);
        expect(s.sessionId).toBeNull();
        expect(s.isLoading).toBe(false);
    });

    it('guarda la posición del robot y el nombre que da el servicio', () => {
        let s = reducer(inicial(), setAniaPosition({ right: 120, bottom: 340 }));
        s = reducer(s, setAssistantName('Ania'));
        expect(s.position).toEqual({ right: 120, bottom: 340 });
        expect(s.assistantName).toBe('Ania');
    });

    it('el silencio de la voz se recuerda', () => {
        // Vivía en estado local del componente, así que salir del catálogo y
        // volver hacía que la aplicación empezara a hablar sola otra vez.
        const s = reducer(inicial(), setVozActiva(false));
        expect(s.vozActiva).toBe(false);
    });

    it('al rehidratar, la espera se apaga aunque venga encendida', () => {
        // `isLoading` es transitoria y el estado se persiste completo: si la app
        // muere mientras espera un turno del agente —cinco segundos son mucho en
        // datos móviles— la bandera revivía en `true` y el chat se quedaba con los
        // tres puntos girando para siempre.
        const guardado: IAiSearchState = {
            ...inicial(),
            isLoading: true,
            isOpen: true,
            sessionId: 'abc123',
            messages: [mensaje('a')],
            vozActiva: false,
        };
        const s = reducer(inicial(), { type: REHYDRATE, payload: { aiSearchState: guardado } });
        expect(s.isLoading).toBe(false);
        // Lo que no es transitorio sí sobrevive.
        expect(s.sessionId).toBe('abc123');
        expect(s.messages).toHaveLength(1);
        expect(s.vozActiva).toBe(false);
    });

    it('una rehidratación sin este slice no toca nada', () => {
        const s = reducer(inicial(), { type: REHYDRATE, payload: { productState: {} } });
        expect(s).toEqual(inicial());
    });
});
