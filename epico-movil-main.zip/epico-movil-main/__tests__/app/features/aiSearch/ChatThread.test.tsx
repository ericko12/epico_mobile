import React from 'react';
import { fireEvent, render, screen } from '@testing-library/react';
import { ChatThread } from '@/features/aiSearch/infrastructure/ui/aniaPanel/ChatThread';
import { ChatRoleEnum } from '@/features/aiSearch/domain/enums/ChatEnums';
import { IChatMessage, IContextoPrecios } from '@/features/aiSearch/domain/interfaces/IAiSearchState';
import { IProduct } from '@/features/products/domain/interfaces/IProduct';

/**
 * `contextoPrecios.test.ts` fija **cuándo** hay que avisar; esto fija que el hilo
 * de verdad lo pinta, que es lo que se rompe al mover un `sx` o una guarda.
 *
 * Y fija sobre todo lo contrario: que el aviso de «confirma la aplicación» sigue
 * siendo **una sola caja**. El hilo ya puede apilar el chip de la marca, el aviso
 * de búsqueda aproximada y el de marca no reconocida; a 320 px una cuarta caja
 * empuja la primera fila de precios fuera de la pantalla.
 *
 * `ProductCard` se sustituye porque monta media docena de selectores de Redux, un
 * BroadcastChannel y dos modales: aquí no se prueba la tarjeta, se prueba el hilo.
 * El sustituto solo expone el aviso de «se abrió el detalle», para poder tocarlo.
 */
jest.mock('@/features/products/infrastructure/ui/table/productTable/productCard/ProductCard', () => ({
    ProductCard: ({ product, onOpenDetail }: { product: IProduct; onOpenDetail?: () => void }) => (
        <div data-testid="tarjeta" onClick={() => onOpenDetail?.()}>{product.productoID}</div>
    ),
}));

const CLIENTE_X: IContextoPrecios = { clienteId: 4210, sucursalId: 7, clienteNombre: 'FERRETERÍA EL TORNILLO' };
const CLIENTE_Y: IContextoPrecios = { clienteId: 999, sucursalId: 7, clienteNombre: 'REFACCIONES LUNA' };

const conTarjetas = (contextoPrecios?: IContextoPrecios): IChatMessage => ({
    id: 'a1',
    rol: ChatRoleEnum.Assistant,
    texto: 'Esto es lo que encontré.',
    productos: [{ productoID: 11 } as IProduct, { productoID: 22 } as IProduct],
    contextoPrecios,
});

const pintar = (
    messages: IChatMessage[],
    contextoActual: IContextoPrecios,
    onOpenDetail: () => void = jest.fn()
) =>
    render(
        <ChatThread
            messages={messages}
            contextoActual={contextoActual}
            loading={false}
            onClickCompatibility={jest.fn()}
            onShowDiscounts={jest.fn()}
            onSeeAllInCatalogue={jest.fn()}
            onOpenDetail={onOpenDetail}
            onAceptarOferta={jest.fn()}
            onEscribirAMano={jest.fn()}
            keyboardInset={0}
        />
    );

/** El aviso que sale bajo TODA respuesta con productos. */
const AVISO_APLICACION = /Confirma la aplicación en cada pieza/;

describe('ChatThread — tarjetas hidratadas con otro cliente', () => {
    it('con el mismo cliente no dice nada del cliente', () => {
        pintar([conTarjetas(CLIENTE_X)], CLIENTE_X);
        expect(screen.getAllByTestId('tarjeta')).toHaveLength(2);
        expect(screen.getByText(AVISO_APLICACION)).toBeInTheDocument();
        expect(screen.queryByText(/son de/)).not.toBeInTheDocument();
    });

    it('al cambiar de cliente nombra al de la búsqueda', () => {
        // El caso que originó el cambio: el vendedor busca con X, se cambia a Y, y
        // las tarjetas de X siguen en pantalla con el precio de X.
        pintar([conTarjetas(CLIENTE_X)], CLIENTE_Y);
        expect(screen.getByText(/FERRETERÍA EL TORNILLO/)).toBeInTheDocument();
        expect(screen.getByText(/Vuelve a preguntarme/)).toBeInTheDocument();
    });

    it('el aviso y la advertencia van en la MISMA caja', () => {
        // Lo que protege el presupuesto vertical del panel. Si alguien saca el
        // aviso a un Alert propio, esto se pone rojo.
        const { container } = pintar([conTarjetas(CLIENTE_X)], CLIENTE_Y);
        expect(container.querySelectorAll('.MuiAlert-root')).toHaveLength(1);
        const alerta = container.querySelector('.MuiAlert-root');
        expect(alerta?.textContent).toMatch(/FERRETERÍA EL TORNILLO/);
        expect(alerta?.textContent).toMatch(AVISO_APLICACION);
    });

    it('un hilo de antes del cambio no se llena de avisos', () => {
        // Mensajes ya persistidos en `sessionStorage`, sin sello. No se puede
        // afirmar de quién eran esos precios, así que no se afirma.
        pintar([conTarjetas(undefined)], CLIENTE_Y);
        expect(screen.getByText(AVISO_APLICACION)).toBeInTheDocument();
        expect(screen.queryByText(/Vuelve a preguntarme/)).not.toBeInTheDocument();
    });

    it('un turno de solo texto no lleva ninguna caja', () => {
        const soloTexto: IChatMessage = {
            id: 'a2',
            rol: ChatRoleEnum.Assistant,
            texto: 'No encontré piezas con esa descripción.',
            contextoPrecios: CLIENTE_X,
        };
        const { container } = pintar([soloTexto], CLIENTE_Y);
        expect(container.querySelectorAll('.MuiAlert-root')).toHaveLength(0);
    });

    it('la burbuja del vendedor tampoco', () => {
        const suyo: IChatMessage = { id: 'u1', rol: ChatRoleEnum.User, texto: 'focos QBH' };
        const { container } = pintar([suyo], CLIENTE_Y);
        expect(container.querySelectorAll('.MuiAlert-root')).toHaveLength(0);
    });

    it('solo se marcan los mensajes desfasados, no el hilo entero', () => {
        // Tras cambiar de cliente, el vendedor pregunta otra vez: el turno nuevo
        // está al día y no puede salir marcado.
        pintar([conTarjetas(CLIENTE_X), { ...conTarjetas(CLIENTE_Y), id: 'a2' }], CLIENTE_Y);
        expect(screen.getAllByText(AVISO_APLICACION)).toHaveLength(2);
        expect(screen.getAllByText(/Vuelve a preguntarme/)).toHaveLength(1);
    });

    it('cambiar solo de sucursal habla de existencias, no de precios', () => {
        pintar([conTarjetas({ ...CLIENTE_X, sucursalId: 3 })], CLIENTE_X);
        expect(screen.getByText(/Estas existencias son de otra sucursal/)).toBeInTheDocument();
    });
});

describe('ChatThread — abrir el detalle desde el hilo', () => {
    it('tocar una tarjeta avisa al panel para que se quite de en medio', () => {
        // Sin el aviso la tarjeta sí navegaba, pero al detalle **detrás** del velo
        // del panel: en el teléfono parecía que tocar el producto no hacía nada.
        const onOpenDetail = jest.fn();
        pintar([conTarjetas(CLIENTE_X)], CLIENTE_X, onOpenDetail);
        fireEvent.click(screen.getAllByTestId('tarjeta')[1]);
        expect(onOpenDetail).toHaveBeenCalledTimes(1);
    });
});

describe('ChatThread — a dónde se lleva la vista', () => {
    // jsdom no maqueta: se le dan las medidas que tendría el teléfono. El hilo
    // empieza en y=100 y la respuesta en y=500, dentro de un contenido de 2000.
    beforeEach(() => {
        jest.spyOn(window, 'requestAnimationFrame').mockImplementation((cb) => { cb(0); return 1; });
        jest.spyOn(Element.prototype, 'getBoundingClientRect').mockImplementation(function (this: Element) {
            const top = this.getAttribute('data-mensaje-id') === 'a1' ? 500 : 100;
            return { top, bottom: top, left: 0, right: 0, width: 0, height: 0, x: 0, y: top, toJSON: () => ({}) } as DOMRect;
        });
        jest.spyOn(HTMLElement.prototype, 'scrollHeight', 'get').mockReturnValue(2000);
    });
    afterEach(() => jest.restoreAllMocks());

    const hiloDe = (container: HTMLElement) => container.firstElementChild as HTMLElement;
    const suyo: IChatMessage = { id: 'u1', rol: ChatRoleEnum.User, texto: 'balatas chevy 2005' };

    it('al llegar la respuesta se queda en su principio, no en el final', () => {
        const { container } = pintar([suyo, conTarjetas(CLIENTE_X)], CLIENTE_X);
        // 400 de distancia menos los 8 de aire: la burbuja de Ania arriba.
        expect(hiloDe(container).scrollTop).toBe(392);
    });

    it('con el mensaje del vendedor al final, baja al final', () => {
        const { container } = pintar([conTarjetas(CLIENTE_X), suyo], CLIENTE_X);
        expect(hiloDe(container).scrollTop).toBe(2000);
    });
});
