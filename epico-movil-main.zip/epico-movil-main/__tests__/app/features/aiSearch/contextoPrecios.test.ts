import {
    avisoDeMensaje,
    evaluarContextoPrecios,
    sellarContextoPrecios,
    textoAvisoContexto,
} from '@/features/aiSearch/application/actions/contextoPrecios';
import { ChatRoleEnum, ContextoPreciosEnum } from '@/features/aiSearch/domain/enums/ChatEnums';
import { IChatMessage, IContextoPrecios } from '@/features/aiSearch/domain/interfaces/IAiSearchState';
import { ICheckOut } from '@/features/checkout/domain/interfaces/checkOut/ICheckOut';
import { IOrderSummary } from '@/features/checkout/domain/interfaces/checkOut/IOrderSummary';
import { IProduct } from '@/features/products/domain/interfaces/IProduct';

/**
 * El caso que originó este código: el vendedor busca con el Cliente X, se cambia
 * al Cliente Y, y las tarjetas que quedaron en el hilo siguen enseñando el precio
 * y la existencia de X. El dinero acaba bien —`ProductCard` revalida contra el
 * cliente activo antes de agregar—, pero el vendedor canta en voz alta el número
 * equivocado.
 *
 * Estas pruebas fijan las dos cosas que no se pueden comprobar de un vistazo:
 * **cuándo** se avisa (y sobre todo cuándo NO, que es lo que evita que el hilo se
 * llene de cajas) y **qué** dice cada aviso.
 */

const pedido = (campos: Partial<IOrderSummary>): IOrderSummary => campos as IOrderSummary;

const caja = (clienteId: number, cliente: string): ICheckOut => ({ clienteId, cliente } as ICheckOut);

const conProductos = (contextoPrecios?: IContextoPrecios): IChatMessage => ({
    id: 'm1',
    rol: ChatRoleEnum.Assistant,
    texto: 'Esto es lo que encontré.',
    productos: [{ productoID: 1 } as IProduct],
    contextoPrecios,
});

describe('sellarContextoPrecios', () => {
    it('sin pedido activo sella el cero que de verdad se envía', () => {
        // La búsqueda manda `clienteId ?? 0` y la existencia `SucursalId ?? 0`. Si
        // el sello guardara `undefined`, la comparación diría «otro cliente» en
        // cuanto no hubiera pedido.
        expect(sellarContextoPrecios(null)).toEqual({
            clienteId: 0,
            sucursalId: 0,
            clienteNombre: undefined,
        });
        expect(sellarContextoPrecios(undefined)).toEqual({
            clienteId: 0,
            sucursalId: 0,
            clienteNombre: undefined,
        });
    });

    it('nunca sella un NaN, venga de donde venga', () => {
        // `InitOrderSummary` los deja así, y `NaN` ni sobrevive a `JSON.stringify`
        // —se persistiría como `null`— ni se compara consigo mismo.
        const c = sellarContextoPrecios(pedido({ clienteId: NaN, sucursalIdDestino: NaN }));
        expect(c.clienteId).toBe(0);
        expect(c.sucursalId).toBe(0);
    });

    it('guarda cliente, sucursal y nombre del pedido', () => {
        const c = sellarContextoPrecios(
            pedido({ clienteId: 4210, sucursalIdDestino: 7, cliente: 'FERRETERÍA EL TORNILLO' })
        );
        expect(c).toEqual({ clienteId: 4210, sucursalId: 7, clienteNombre: 'FERRETERÍA EL TORNILLO' });
    });

    it('tira los rellenos que el proyecto guarda como nombre', () => {
        // `InitOrderSummary` deja `cliente: "NA"`. Sin este filtro el aviso diría
        // «estos precios son de "NA"».
        expect(sellarContextoPrecios(pedido({ clienteId: 1, cliente: 'NA' })).clienteNombre).toBeUndefined();
        expect(sellarContextoPrecios(pedido({ clienteId: 1, cliente: 'n/a' })).clienteNombre).toBeUndefined();
        expect(sellarContextoPrecios(pedido({ clienteId: 1, cliente: '   ' })).clienteNombre).toBeUndefined();
    });

    it('rescata el nombre de la caja cuando el del pedido no sirve', () => {
        // `ICheckOut.cliente` es obligatorio; `IOrderSummary.cliente` no.
        const c = sellarContextoPrecios(
            pedido({ clienteId: 4210, cliente: 'NA' }),
            [caja(99, 'OTRO'), caja(4210, 'REFACCIONES LUNA')]
        );
        expect(c.clienteNombre).toBe('REFACCIONES LUNA');
    });

    it('el nombre del pedido gana al de la caja', () => {
        const c = sellarContextoPrecios(
            pedido({ clienteId: 4210, cliente: 'FERRETERÍA EL TORNILLO' }),
            [caja(4210, 'REFACCIONES LUNA')]
        );
        expect(c.clienteNombre).toBe('FERRETERÍA EL TORNILLO');
    });

    it('sin cliente no rebusca en las cajas', () => {
        // Un `find` sobre `clienteId === 0` engancharía cualquier caja mal formada
        // y le pondría nombre a una búsqueda que no tenía cliente.
        expect(sellarContextoPrecios(null, [caja(0, 'CAJA ROTA')]).clienteNombre).toBeUndefined();
    });
});

describe('evaluarContextoPrecios', () => {
    const actual: IContextoPrecios = { clienteId: 4210, sucursalId: 7 };

    it('sin sello no se afirma nada', () => {
        // Un hilo que ya estaba en `sessionStorage` antes de este cambio. No se
        // puede decir de quién eran unos precios que nadie fechó.
        expect(evaluarContextoPrecios(undefined, actual)).toBe(ContextoPreciosEnum.Desconocido);
    });

    it('el mismo cliente y la misma sucursal no avisan', () => {
        expect(evaluarContextoPrecios({ clienteId: 4210, sucursalId: 7 }, actual)).toBe(
            ContextoPreciosEnum.Vigente
        );
    });

    it('otro cliente', () => {
        expect(evaluarContextoPrecios({ clienteId: 999, sucursalId: 7 }, actual)).toBe(
            ContextoPreciosEnum.OtroCliente
        );
    });

    it('el mismo cliente en otra sucursal avisa por la existencia', () => {
        expect(evaluarContextoPrecios({ clienteId: 4210, sucursalId: 3 }, actual)).toBe(
            ContextoPreciosEnum.OtraSucursal
        );
    });

    it('cuando cambian los dos manda el cliente', () => {
        // Su texto ya nombra precios y existencias, así que un quinto estado sería
        // una rama sin redacción propia.
        expect(evaluarContextoPrecios({ clienteId: 999, sucursalId: 3 }, actual)).toBe(
            ContextoPreciosEnum.OtroCliente
        );
    });

    it('dos pedidos sin sucursal de destino no son «otra sucursal»', () => {
        // Es el caso normal, y sin normalizar los dos lados avisaría siempre.
        expect(evaluarContextoPrecios({ clienteId: 4210 }, { clienteId: 4210 })).toBe(
            ContextoPreciosEnum.Vigente
        );
    });

    it('sin sucursal y con la cero son la misma sucursal', () => {
        // No es una sutileza: `hydrateSearchProducts` pide la existencia con
        // `SucursalId: branchId ?? 0`, así que los dos preguntan lo mismo. Avisar
        // ahí sería avisar de un cambio que no ocurrió.
        expect(evaluarContextoPrecios({ clienteId: 4210 }, { clienteId: 4210, sucursalId: 0 })).toBe(
            ContextoPreciosEnum.Vigente
        );
        expect(evaluarContextoPrecios({ clienteId: 4210, sucursalId: 0 }, { clienteId: 4210 })).toBe(
            ContextoPreciosEnum.Vigente
        );
    });

    it('un NaN no marca el hilo entero para siempre', () => {
        // `InitOrderSummary` deja `clienteId` y `sucursalIdDestino` en `NaN`, y
        // `??` no lo atrapa. Sin la red, `NaN !== NaN` es cierto y TODOS los
        // mensajes saldrían marcados sin que nada hubiera cambiado.
        const conNaN: IContextoPrecios = { clienteId: NaN, sucursalId: NaN };
        expect(evaluarContextoPrecios(conNaN, conNaN)).toBe(ContextoPreciosEnum.Vigente);
        expect(evaluarContextoPrecios(conNaN, { clienteId: 0, sucursalId: 0 })).toBe(
            ContextoPreciosEnum.Vigente
        );
    });

    it('quedarse sin pedido activo también es cambiar de cliente', () => {
        expect(evaluarContextoPrecios({ clienteId: 4210 }, { clienteId: 0 })).toBe(
            ContextoPreciosEnum.OtroCliente
        );
    });

    it('volver al cliente original apaga el aviso solo', () => {
        const sello: IContextoPrecios = { clienteId: 4210, sucursalId: 7 };
        expect(evaluarContextoPrecios(sello, { clienteId: 999, sucursalId: 7 })).toBe(
            ContextoPreciosEnum.OtroCliente
        );
        expect(evaluarContextoPrecios(sello, { clienteId: 4210, sucursalId: 7 })).toBe(
            ContextoPreciosEnum.Vigente
        );
    });
});

describe('avisoDeMensaje', () => {
    const actual: IContextoPrecios = { clienteId: 999 };
    const viejo: IContextoPrecios = { clienteId: 4210 };

    it('la burbuja del vendedor nunca avisa', () => {
        // No afirma ningún precio. Marcarla llenaría el hilo de cajas.
        const suyo: IChatMessage = { id: 'u1', rol: ChatRoleEnum.User, texto: 'focos QBH' };
        expect(avisoDeMensaje(suyo, actual)).toBe(ContextoPreciosEnum.Vigente);
    });

    it('un turno de solo texto tampoco', () => {
        const texto: IChatMessage = {
            id: 'a1',
            rol: ChatRoleEnum.Assistant,
            texto: 'No encontré piezas con esa descripción.',
            contextoPrecios: viejo,
        };
        expect(avisoDeMensaje(texto, actual)).toBe(ContextoPreciosEnum.Vigente);
        expect(avisoDeMensaje({ ...texto, productos: [] }, actual)).toBe(ContextoPreciosEnum.Vigente);
    });

    it('las tarjetas de otro cliente sí', () => {
        expect(avisoDeMensaje(conProductos(viejo), actual)).toBe(ContextoPreciosEnum.OtroCliente);
    });

    it('las tarjetas sin sello se callan', () => {
        expect(avisoDeMensaje(conProductos(undefined), actual)).toBe(ContextoPreciosEnum.Desconocido);
    });
});

describe('textoAvisoContexto', () => {
    /** El pedido activo mientras se lee el aviso. */
    const HAY_CLIENTE: IContextoPrecios = { clienteId: 999 };

    it('lo que no hay que avisar no lleva texto', () => {
        // `Desconocido` incluido: es la garantía de que un hilo viejo persistido no
        // se llena de avisos al desplegar.
        expect(textoAvisoContexto(ContextoPreciosEnum.Vigente, HAY_CLIENTE)).toBeNull();
        expect(textoAvisoContexto(ContextoPreciosEnum.Desconocido, HAY_CLIENTE, { clienteId: 4210 })).toBeNull();
    });

    it('nombra al cliente cuando se sabe quién era', () => {
        const t = textoAvisoContexto(ContextoPreciosEnum.OtroCliente, HAY_CLIENTE, {
            clienteId: 4210,
            clienteNombre: 'FERRETERÍA EL TORNILLO',
        });
        expect(t).toContain('FERRETERÍA EL TORNILLO');
        expect(t).toContain('Vuelve a preguntarme');
    });

    it('sin nombre no se inventa uno', () => {
        const t = textoAvisoContexto(ContextoPreciosEnum.OtroCliente, HAY_CLIENTE, { clienteId: 4210 });
        expect(t).toBe(
            'Estos precios y existencias son de otro cliente. Vuelve a preguntarme para verlos con el cliente de ahora.'
        );
        // Y nunca el identificador crudo: no le dice nada a quien lo lee.
        expect(t).not.toContain('4210');
    });

    it('una búsqueda sin cliente no se llama «otro cliente»', () => {
        // Eran precios de lista; no había ningún cliente al que atribuirlos.
        expect(textoAvisoContexto(ContextoPreciosEnum.OtroCliente, HAY_CLIENTE, { clienteId: 0 })).toContain(
            'sin cliente'
        );
    });

    it('sin pedido activo no remite a «el cliente de ahora», porque no lo hay', () => {
        // Cerrar la última caja deja `selectedOrderSummary` en `null`
        // (checkOutThunks.ts:49). Mandar al vendedor a mirar «con el cliente de
        // ahora» sería mandarlo a mirar con nadie.
        const sinPedido: IContextoPrecios = { clienteId: 0 };
        const t = textoAvisoContexto(ContextoPreciosEnum.OtroCliente, sinPedido, {
            clienteId: 4210,
            clienteNombre: 'FERRETERÍA EL TORNILLO',
        });
        expect(t).toContain('FERRETERÍA EL TORNILLO');
        expect(t).not.toContain('el cliente de ahora');
        expect(t).toContain('al día');
    });

    it('la sucursal solo caduca la existencia, y lo dice así', () => {
        const t = textoAvisoContexto(ContextoPreciosEnum.OtraSucursal, HAY_CLIENTE, { clienteId: 4210, sucursalId: 3 });
        expect(t).toContain('existencias');
        expect(t).toContain('los precios sí son de este cliente');
    });

    it('ningún aviso promete que el precio se recalcule al agregar', () => {
        // `ProductCard` apaga «Agregar» cuando el `sinPrecio` congelado dice que no
        // había precio, así que esa promesa se incumpliría justo en el peor caso.
        const todos = [
            textoAvisoContexto(ContextoPreciosEnum.OtroCliente, HAY_CLIENTE, { clienteId: 4210, clienteNombre: 'X' }),
            textoAvisoContexto(ContextoPreciosEnum.OtroCliente, HAY_CLIENTE, { clienteId: 4210 }),
            textoAvisoContexto(ContextoPreciosEnum.OtroCliente, HAY_CLIENTE, { clienteId: 0 }),
            textoAvisoContexto(ContextoPreciosEnum.OtraSucursal, HAY_CLIENTE, { clienteId: 4210 }),
        ];
        todos.forEach((t) => {
            expect(t).not.toBeNull();
            expect(t).not.toMatch(/al agregar/i);
            expect(t).toMatch(/Vuelve a preguntarme/);
        });
    });
});

describe('sellarContextoPrecios — sin caja activa', () => {
    // Visto en producción: el chat pedía precios con el cliente 0 y el servicio
    // respondía «Entidad ClienteId (0) no encontrada». El catálogo, en el mismo caso,
    // pide con el cliente mostrador si se entró desde el menú.
    it('entrando desde el menú usa el cliente mostrador, y lo sella', () => {
        const c = sellarContextoPrecios(null, [], true);
        expect(c.clienteId).toBe(1);
        expect(c.clienteNombre).toBe('cliente mostrador');
    });

    it('sin entrar desde el menú se queda en 0, como el catálogo', () => {
        expect(sellarContextoPrecios(null, [], false).clienteId).toBe(0);
    });

    it('con caja activa manda el cliente de la caja aunque se haya entrado desde el menú', () => {
        expect(sellarContextoPrecios(pedido({ clienteId: 4210 }), [], true).clienteId).toBe(4210);
    });

    it('el sello y el contexto actual coinciden: no avisa de "otro cliente" sin motivo', () => {
        const sello = sellarContextoPrecios(null, [], true);
        const actual = sellarContextoPrecios(null, [], true);
        expect(evaluarContextoPrecios(sello, actual)).toBe(ContextoPreciosEnum.Vigente);
    });
});

