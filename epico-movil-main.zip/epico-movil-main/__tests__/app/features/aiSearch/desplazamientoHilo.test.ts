import { destinoDelHilo } from '@/features/aiSearch/application/actions/desplazamientoHilo';
import { ChatRoleEnum } from '@/features/aiSearch/domain/enums/ChatEnums';
import { IChatMessage } from '@/features/aiSearch/domain/interfaces/IAiSearchState';

/**
 * Fija cuándo el hilo baja al final y cuándo se queda en el principio de la
 * respuesta. Lo segundo es lo que pidió el negocio: con tarjetas debajo, bajar al
 * final dejaba el texto de Ania por encima de la vista.
 */
const suyo: IChatMessage = { id: 'u1', rol: ChatRoleEnum.User, texto: 'balatas chevy 2005' };
const deAnia: IChatMessage = { id: 'a1', rol: ChatRoleEnum.Assistant, texto: 'Esto es lo que encontré.' };

describe('destinoDelHilo', () => {
    it('al enviar, el vendedor ve su mensaje: al final', () => {
        expect(destinoDelHilo([deAnia, suyo], false)).toEqual({ tipo: 'final' });
    });

    it('mientras se espera, los puntos de «buscando…»: al final', () => {
        // El último sigue siendo una respuesta vieja; lo que manda es que se espera.
        expect(destinoDelHilo([suyo, deAnia], true)).toEqual({ tipo: 'final' });
    });

    it('al llegar la respuesta, a su principio', () => {
        expect(destinoDelHilo([suyo, deAnia], false)).toEqual({ tipo: 'mensaje', id: 'a1' });
    });

    it('un hilo vacío no tiene a dónde ir más que al final', () => {
        expect(destinoDelHilo([], false)).toEqual({ tipo: 'final' });
    });
});
