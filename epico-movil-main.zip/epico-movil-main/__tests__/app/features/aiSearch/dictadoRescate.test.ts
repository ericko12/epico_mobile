import {
    construirHipotesis,
    normalizarComparacion,
    prefijarDictado,
    sustituirToken,
    tokenizar,
} from '@/features/aiSearch/application/actions/dictadoHipotesis';
import { localizarMarcaDicha } from '@/features/aiSearch/application/actions/marcaDictada';
import {
    elegirCandidatas,
    reconstruirDeletreo,
} from '@/features/aiSearch/application/actions/candidatosDictado';
import {
    decidirOferta,
    leerConfirmacion,
    ofertaVigente,
    planearRescate,
} from '@/features/aiSearch/application/actions/ofertaRescate';
import { ConfirmacionEnum, ModoDictadoEnum, MotivoOfertaEnum } from '@/features/aiSearch/domain/enums/DictadoEnums';
import { ICandidataDictado, IDictado, ISondeo } from '@/features/aiSearch/domain/interfaces/IDictado';

/**
 * El defecto que originó todo esto, textual: se dictó «¿Tienes focos de la marca
 * QBH?» y se transcribió «...de la marca QH»; se dictó otra vez y se transcribió
 * «...de la marca Kuhn». Verificado contra producción, el servicio devuelve cero
 * resultados con las dos y no corrige ninguna.
 *
 * Estas pruebas fijan sobre todo lo que **no** debe pasar. Los casos negativos son
 * mayoría a propósito: una corrección equivocada es peor que una transcripción
 * mala, porque el usuario no se entera y acaba pidiendo la refacción de otra marca.
 */

const dictado = (texto: string, alternativas: string[] = [], modo = ModoDictadoEnum.Libre): IDictado => ({
    texto,
    alternativas,
    modo,
});

const sondeo = (texto: string, total: number, marcaDetectada: string | null, ok = true): ISondeo => ({
    texto,
    ok,
    total,
    marcaDetectada,
});

const entrada = (extra: Partial<Parameters<typeof planearRescate>[0]> = {}) => ({
    dictado: dictado('tienes focos de la marca QH', ['tienes focos de la marca QBH']),
    textoEnviado: 'tienes focos de la marca QH',
    porVoz: true,
    rescateActivo: true,
    ok: true,
    total: 0,
    marcaDetectada: null,
    ...extra,
});

describe('normalizarComparacion y tokenizar', () => {
    it('iguala acentos, mayúsculas y espacios de más', () => {
        expect(normalizarComparacion('  Pregunté   POR  Focos ')).toBe('pregunte por focos');
    });

    it('quita los signos de los bordes, que si no cambiarían la palabra', () => {
        // «¿Tienes» y «Tienes» son la misma palabra, y «QH?» y «QH» la misma marca.
        expect(tokenizar('¿Tienes focos de la marca QH?').map((t) => t.crudo)).toEqual([
            'Tienes', 'focos', 'de', 'la', 'marca', 'QH',
        ]);
    });
});

describe('construirHipotesis', () => {
    it('INVARIANTE: la principal es lo que ya se enviaba, byte a byte', () => {
        // De esto depende que subir `maxAlternatives` no cambie lo que viaja: el
        // hook concatenaba las hipótesis [0] sin separador y recortaba al final.
        const segmentos = [['tienes focos de la '], ['marca QH']];
        const crudo = segmentos.map((s) => s[0]).join('');
        expect(construirHipotesis(segmentos).texto).toBe(crudo.trim());
    });

    it('compone las alternativas variando un segmento a la vez', () => {
        const d = construirHipotesis([
            ['tienes focos ', 'tienes faros '],
            ['de la marca QH', 'de la marca QBH'],
        ]);
        expect(d.texto).toBe('tienes focos de la marca QH');
        // Nunca el producto cartesiano: no aparece «faros ... QBH».
        expect(d.alternativas).toEqual([
            'tienes faros de la marca QH',
            'tienes focos de la marca QBH',
        ]);
    });

    it('con una sola hipótesis no hay alternativas, y todo queda inerte', () => {
        // Es el caso de la ruta de reconocimiento en dispositivo, que devuelve
        // siempre una, y también el de las frases cortas en la ruta de red.
        expect(construirHipotesis([['focos de la marca qh']]).alternativas).toEqual([]);
    });

    it('no repite una alternativa que solo difiere en acentos o mayúsculas', () => {
        const d = construirHipotesis([['Pregunté por focos', 'pregunte por focos']]);
        expect(d.alternativas).toEqual([]);
    });

    it('respeta el tope de alternativas', () => {
        const fila = ['a0', 'a1', 'a2', 'a3', 'a4', 'a5'];
        expect(construirHipotesis([fila, ['b0', 'b1', 'b2']], ModoDictadoEnum.Libre, 3).alternativas).toHaveLength(3);
    });

    it('sin segmentos no revienta', () => {
        expect(construirHipotesis([]).texto).toBe('');
    });
});

describe('prefijarDictado y sustituirToken', () => {
    it('lo escrito va delante de la principal y de todas las alternativas', () => {
        // El hueco de la marca se localiza sobre el texto que viajó, y ese texto es
        // lo escrito más lo dictado.
        const d = prefijarDictado(dictado('un Chevy 2005 marca QH', ['un Chevy 2005 marca QBH']), 'balatas para ');
        expect(d.texto).toBe('balatas para un Chevy 2005 marca QH');
        expect(d.alternativas).toEqual(['balatas para un Chevy 2005 marca QBH']);
    });

    it('sin nada escrito, el dictado se queda igual', () => {
        const d = dictado('focos marca QH');
        expect(prefijarDictado(d, '   ')).toBe(d);
    });

    it('sustituir una palabra conserva los signos que la rodean', () => {
        expect(sustituirToken('¿Tienes focos de la marca QH?', 5, 'QBH')).toBe(
            '¿Tienes focos de la marca QBH?'
        );
    });
});

describe('localizarMarcaDicha', () => {
    it('encuentra la marca detrás de «de la marca»', () => {
        expect(localizarMarcaDicha('¿Tienes focos de la marca QH?')).toEqual({ palabra: 'QH', indice: 5 });
    });

    it('salta el verbo en «la marca es QBH»', () => {
        expect(localizarMarcaDicha('la marca es QBH')?.palabra).toBe('QBH');
    });

    it('PREGUNTAR POR LAS MARCAS NO ES NOMBRAR UNA', () => {
        // Es la pregunta más común del mostrador. Detrás de «marca» viene «tienes»,
        // que es palabra de corte: no hay marca dicha, así que no hay nota, ni
        // sonda, ni oferta.
        expect(localizarMarcaDicha('De qué marca tienes balatas para un Tsuru')).toBeNull();
    });

    it('«DE» NO ES DISPARADOR: el sustantivo de la pieza es intocable', () => {
        // «de» + sustantivo es la forma normal de nombrar la pieza en refacciones.
        expect(localizarMarcaDicha('Ponme un juego de balatas')).toBeNull();
        expect(localizarMarcaDicha('Necesito un retén de aceite')).toBeNull();
    });

    it('sin la palabra «marca» no se detecta nada, y es el precio de no equivocarse', () => {
        expect(localizarMarcaDicha('Focos QBH para un Tsuru')).toBeNull();
        expect(localizarMarcaDicha('Focos de ese lado del Tsuru')).toBeNull();
    });

    it('un token de solo cifras detrás de «marca» no es una marca', () => {
        expect(localizarMarcaDicha('balatas marca 2012')).toBeNull();
    });

    it('«marca» al final de la frase no tiene nada detrás', () => {
        expect(localizarMarcaDicha('dime la marca')).toBeNull();
    });

    it('con dos disparadores se juzga el último', () => {
        expect(localizarMarcaDicha('balatas marca Bosch y focos marca QH')?.palabra).toBe('QH');
    });
});

describe('elegirCandidatas', () => {
    const marca = { palabra: 'QH', indice: 5 };
    const enviado = 'tienes focos de la marca QH';

    it('acepta la alternativa que solo cambia la marca', () => {
        const c = elegirCandidatas(dictado(enviado, ['tienes focos de la marca QBH']), enviado, marca);
        expect(c).toEqual([
            { texto: 'tienes focos de la marca QBH', palabraAntes: 'QH', palabraDespues: 'QBH' },
        ]);
    });

    it('descarta la que cambia dos palabras', () => {
        const c = elegirCandidatas(dictado(enviado, ['tienes faros de la marca QBH']), enviado, marca);
        expect(c).toEqual([]);
    });

    it('descarta la que cambia una palabra que NO es la marca', () => {
        // Si no, una alternativa que cambia el modelo o el lado se ofrecería
        // etiquetada como corrección de marca.
        const c = elegirCandidatas(dictado(enviado, ['tienes faros de la marca QH']), enviado, marca);
        expect(c).toEqual([]);
    });

    it('EL AÑO NO SE TOCA: ningún token con cifras', () => {
        // «Aveo 2012» → «Aveo 2010» con un conteo tranquilizador son balatas del
        // año equivocado. Eso no es un error de catálogo, es un freno mal surtido.
        const enviadoAnio = 'balatas para Aveo 2012 marca QH';
        const m = { palabra: '2012', indice: 3 };
        const c = elegirCandidatas(dictado(enviadoAnio, ['balatas para Aveo 2010 marca QH']), enviadoAnio, m);
        expect(c).toEqual([]);
    });

    it('descarta la candidata demasiado corta antes de gastar la petición', () => {
        // Por debajo de tres caracteres el servicio devuelve 400.
        const c = elegirCandidatas(dictado('qh', ['qb']), 'qh', { palabra: 'qh', indice: 0 });
        expect(c).toEqual([]);
    });

    it('descarta la candidata demasiado larga', () => {
        const largo = `tienes focos de la marca ${'x'.repeat(300)}`;
        const c = elegirCandidatas(dictado(enviado, [largo]), enviado, marca);
        expect(c).toEqual([]);
    });

    it('descarta la que es la misma frase enviada con otros acentos', () => {
        const c = elegirCandidatas(dictado(enviado, ['Tienes focos de la marca qh']), enviado, marca);
        expect(c).toEqual([]);
    });

    it('respeta el tope de candidatas', () => {
        const c = elegirCandidatas(
            dictado(enviado, [
                'tienes focos de la marca QBH',
                'tienes focos de la marca QB',
                'tienes focos de la marca Q',
            ]),
            enviado,
            marca,
            2
        );
        expect(c).toHaveLength(2);
    });
});

describe('reconstruirDeletreo', () => {
    it('recompone nombres de letra', () => {
        expect(reconstruirDeletreo('cu be hache')).toBe('QBH');
    });

    it('recompone letras sueltas', () => {
        expect(reconstruirDeletreo('Q B H')).toBe('QBH');
    });

    it('entiende las formas con las que se distingue la be de la ve', () => {
        expect(reconstruirDeletreo('cu be grande hache')).toBe('QBH');
        expect(reconstruirDeletreo('ve chica equis')).toBe('VX');
    });

    it('acepta cifras deletreadas', () => {
        expect(reconstruirDeletreo('te ese ka uno')).toBe('TSK1');
    });

    it('un deletreo mal oído da otro acrónimo, y ahí se para', () => {
        // «be» oída como «ve». No se busca «la marca más parecida a QVH»: no hay
        // ninguna lista contra la que parecerse. Lo dirá la sonda.
        expect(reconstruirDeletreo('que ve ache')).toBe('QVH');
    });

    it('lo que no es un deletreo devuelve null', () => {
        expect(reconstruirDeletreo('pues la de siempre')).toBeNull();
        expect(reconstruirDeletreo('')).toBeNull();
    });

    it('una sola letra no es un acrónimo', () => {
        expect(reconstruirDeletreo('cu')).toBeNull();
    });
});

describe('planearRescate: cuándo NO se gasta nada', () => {
    it('con la bandera apagada, ni una petición', () => {
        expect(planearRescate(entrada({ rescateActivo: false }))).toBeNull();
    });

    it('lo escrito a mano no se toca nunca', () => {
        expect(planearRescate(entrada({ porVoz: false }))).toBeNull();
        expect(planearRescate(entrada({ dictado: null }))).toBeNull();
    });

    it('si el servicio falló, sondearlo otra vez es tirar peticiones', () => {
        expect(planearRescate(entrada({ ok: false }))).toBeNull();
    });

    it('SI EL SERVICIO RECONOCIÓ LA MARCA, NO HAY NADA QUE RESCATAR', () => {
        // Aquí es donde «GM» deja de correr peligro de convertirse en «GMB», y
        // donde «QH» dicha a propósito (Quinton Hazell) se respeta.
        const p = planearRescate(entrada({
            marcaDetectada: 'QH',
            total: 40,
            dictado: dictado('tienes focos de la marca QH', ['tienes focos de la marca QBH']),
        }));
        expect(p).toBeNull();
    });

    it('si no se nombró ninguna marca, no se rescata', () => {
        expect(planearRescate(entrada({
            textoEnviado: 'balatas para Chirey Tiggo 8 dos mil veinticuatro',
            dictado: dictado('balatas para Chirey Tiggo 8 dos mil veinticuatro'),
        }))).toBeNull();
    });
});

describe('planearRescate: cuándo sí', () => {
    it('cero resultados con marca nombrada: se planea y hay candidata', () => {
        const p = planearRescate(entrada());
        expect(p?.motivo).toBe(MotivoOfertaEnum.SinResultados);
        expect(p?.marca.palabra).toBe('QH');
        expect(p?.candidatas.map((c) => c.palabraDespues)).toEqual(['QBH']);
    });

    it('con resultados pero sin marca reconocida, el motivo es otro', () => {
        // Devolvió piezas de cualquier marca: parecen buenos resultados y no lo son.
        const p = planearRescate(entrada({ total: 644 }));
        expect(p?.motivo).toBe(MotivoOfertaEnum.MarcaNoReconocida);
    });

    it('EL CASO «KUHN»: se planea, pero sin candidatas y sin sondas', () => {
        // «Kuhn» es una palabra que el modelo sí conoce, con la que sustituyó una
        // que no conoce. Si «QBH» no está en su léxico, no aparece a ninguna
        // profundidad, y este plan NO la inventa: solo deja de fallar en silencio.
        const p = planearRescate(entrada({
            textoEnviado: 'pregunte por focos de la marca Kuhn',
            dictado: dictado('pregunte por focos de la marca Kuhn'),
        }));
        expect(p?.marca.palabra).toBe('Kuhn');
        expect(p?.candidatas).toEqual([]);
    });
});

describe('decidirOferta', () => {
    const candidatas: ICandidataDictado[] = [
        { texto: 'tienes focos de la marca QBH', palabraAntes: 'QH', palabraDespues: 'QBH' },
    ];
    const principal = sondeo('tienes focos de la marca QH', 0, null);

    it('ofrece cuando la candidata hace que el índice reconozca la marca', () => {
        const o = decidirOferta(
            candidatas,
            MotivoOfertaEnum.SinResultados,
            'tienes focos de la marca QH',
            principal,
            [sondeo('tienes focos de la marca QBH', 18, 'QBH')],
            1000
        );
        expect(o).toMatchObject({ palabraAntes: 'QH', palabraDespues: 'QBH', total: 18 });
    });

    it('MÁS RESULTADOS NO ES EVIDENCIA', () => {
        // Perder la marca ENSANCHA la búsqueda: aceptar por conteo premiaría
        // exactamente el fallo que se quiere arreglar.
        const o = decidirOferta(
            candidatas,
            MotivoOfertaEnum.SinResultados,
            'tienes focos de la marca QH',
            principal,
            [sondeo('tienes focos de la marca QBH', 5000, null)],
            1000
        );
        expect(o).toBeNull();
    });

    it('si el índice sí reconocía la marca original, no se ofrece nada', () => {
        // La transcripción estaba bien y el fallo fue del agente.
        const o = decidirOferta(
            candidatas,
            MotivoOfertaEnum.SinResultados,
            'tienes focos de la marca QH',
            sondeo('tienes focos de la marca QH', 40, 'QH'),
            [sondeo('tienes focos de la marca QBH', 18, 'QBH')],
            1000
        );
        expect(o).toBeNull();
    });

    it('una sonda con cero resultados no se ofrece aunque reconozca marca', () => {
        const o = decidirOferta(
            candidatas,
            MotivoOfertaEnum.SinResultados,
            'tienes focos de la marca QH',
            principal,
            [sondeo('tienes focos de la marca QBH', 0, 'QBH')],
            1000
        );
        expect(o).toBeNull();
    });

    it('una sonda que no corresponde a ninguna candidata se ignora', () => {
        const o = decidirOferta(
            candidatas,
            MotivoOfertaEnum.SinResultados,
            'tienes focos de la marca QH',
            principal,
            [sondeo('otra frase cualquiera', 18, 'Bosch')],
            1000
        );
        expect(o).toBeNull();
    });
});

describe('ofertaVigente', () => {
    it('caduca, para que un «sí» de dos minutos después no reenvíe nada', () => {
        const o = {
            textoAnterior: 'a', textoNuevo: 'b', palabraAntes: 'QH', palabraDespues: 'QBH',
            total: 18, motivo: MotivoOfertaEnum.SinResultados, creada: 1000,
        };
        expect(ofertaVigente(o, 5000)).toBe(true);
        expect(ofertaVigente(o, 40000)).toBe(false);
        expect(ofertaVigente(null, 1000)).toBe(false);
    });
});

describe('leerConfirmacion', () => {
    it('acepta las formas con las que se dice sí en el mostrador', () => {
        ['sí', 'si', 'esa sí', 'correcto', 'órale', 'dale', 'ok'].forEach((f) =>
            expect(leerConfirmacion(f)).toBe(ConfirmacionEnum.Si)
        );
    });

    it('reconoce el no', () => {
        ['no', 'esa no', 'negativo', 'déjalo'].forEach((f) =>
            expect(leerConfirmacion(f)).toBe(ConfirmacionEnum.No)
        );
    });

    it('LA OFERTA NO SECUESTRA EL MICRÓFONO', () => {
        // Cualquier cosa fuera del vocabulario cerrado se trata como turno nuevo:
        // el usuario nunca queda atrapado en un diálogo de confirmación.
        expect(leerConfirmacion('dame los de doce volts')).toBe(ConfirmacionEnum.Nada);
        expect(leerConfirmacion('sí, pero de doce volts')).toBe(ConfirmacionEnum.Nada);
        expect(leerConfirmacion('')).toBe(ConfirmacionEnum.Nada);
    });
});
