import {
    IVoiceLike,
    pickVoice,
    prosodyFor,
    rankVoices,
    scoreVoice,
    splitForSpeech,
    SPEECH_CHUNK_MAX,
    textToSpeak,
    voiceGender,
    VoiceGenderEnum,
} from '@/features/aiSearch/application/actions/pickVoice';

/**
 * La queja que originó este código fue «la voz se escucha muy robótica y
 * preferiría que fuera de mujer», y la causa era tomar la primera voz `es-MX` de
 * la lista: en Windows eso es Microsoft Raúl, masculina y de las locales.
 *
 * Estas pruebas fijan el criterio, porque no se puede verificar de oído en CI: qué
 * voz gana, con qué prosodia se le habla y cómo se le entrega el texto.
 */

const voz = (name: string, lang = 'es-MX', localService = true): IVoiceLike => ({
    name,
    lang,
    localService,
});

/** Lo que trae un Windows con Chrome, en el orden en que lo devuelve. */
const WINDOWS_CHROME: IVoiceLike[] = [
    voz('Microsoft David - English (United States)', 'en-US'),
    voz('Microsoft Raul - Spanish (Mexico)'),
    voz('Microsoft Sabina - Spanish (Mexico)'),
    voz('Google español de México', 'es-MX', false),
    voz('Google US English', 'en-US', false),
];

describe('voiceGender', () => {
    it('reconoce mujeres y hombres por el nombre propio', () => {
        expect(voiceGender('Microsoft Sabina - Spanish (Mexico)')).toBe(VoiceGenderEnum.Femenina);
        expect(voiceGender('Microsoft Raul - Spanish (Mexico)')).toBe(VoiceGenderEnum.Masculina);
    });

    it('no inventa cuando el nombre no dice nada', () => {
        // La API del navegador no expone el género: si el nombre no lo delata, no
        // hay de dónde sacarlo.
        expect(voiceGender('Google español de México')).toBe(VoiceGenderEnum.Desconocido);
        expect(voiceGender('')).toBe(VoiceGenderEnum.Desconocido);
    });
});

describe('scoreVoice', () => {
    it('descarta lo que no habla español', () => {
        expect(scoreVoice(voz('Microsoft David - English (United States)', 'en-US'))).toBeLessThan(0);
    });

    it('una femenina gana a una masculina del mismo motor', () => {
        expect(scoreVoice(voz('Microsoft Sabina - Spanish (Mexico)'))).toBeGreaterThan(
            scoreVoice(voz('Microsoft Raul - Spanish (Mexico)'))
        );
    });

    it('una neuronal de España gana a una local de México', () => {
        // Es lo contrario de lo que sugiere el acento, y es a propósito: lo que se
        // oye como robótico es el motor, no el acento.
        //
        // Se prueba con Paulina y no con Sabina: Sabina es una de las voces
        // elegidas a mano para Ania, así que gana por decisión y no por puntuación,
        // y usarla aquí mediría otra cosa.
        const neuronalEs = voz('Microsoft Elvira Online (Natural) - Spanish (Spain)', 'es-ES', false);
        const localMx = voz('Paulina');
        expect(scoreVoice(neuronalEs)).toBeGreaterThan(scoreVoice(localMx));
    });
});

describe('pickVoice', () => {
    it('en Windows con Chrome no elige a Raúl', () => {
        // El caso exacto que provocó la queja: se tomaba la primera voz es-MX de la
        // lista, que en Windows es Raúl.
        const elegida = pickVoice(WINDOWS_CHROME);
        expect(elegida?.name).not.toContain('Raul');
        expect(elegida?.name).toContain('Sabina');
    });

    it('en Edge gana la neuronal femenina', () => {
        const edge: IVoiceLike[] = [
            voz('Microsoft Raul - Spanish (Mexico)'),
            voz('Microsoft Sabina - Spanish (Mexico)'),
            voz('Microsoft Dalia Online (Natural) - Spanish (Mexico)', 'es-MX', false),
            voz('Microsoft Jorge Online (Natural) - Spanish (Mexico)', 'es-MX', false),
        ];
        expect(pickVoice(edge)?.name).toBe('Microsoft Dalia Online (Natural) - Spanish (Mexico)');
    });

    it('DALIA gana a todo cuando el dispositivo la trae', () => {
        // Es la voz decidida para Ania. No hay selector: si está, es esta.
        const conDalia: IVoiceLike[] = [
            ...WINDOWS_CHROME,
            voz('Microsoft Dalia Online (Natural) - Spanish (Mexico)', 'es-MX', false),
        ];
        expect(pickVoice(conDalia)?.name).toContain('Dalia');
    });

    it('sin Dalia gana SABINA, que es la segunda elegida', () => {
        // Es el caso de Chrome sobre Windows: las voces «Online (Natural)» de
        // Microsoft solo las expone Edge. Sabina es local y mas dura, pero esta en
        // cualquier Windows y gana a la de Google por decision tomada, no por
        // puntuacion.
        expect(pickVoice(WINDOWS_CHROME)?.name).toBe('Microsoft Sabina - Spanish (Mexico)');
    });

    it('con las dos delante, Dalia gana a Sabina', () => {
        const edge: IVoiceLike[] = [
            voz('Microsoft Sabina - Spanish (Mexico)'),
            voz('Microsoft Dalia Online (Natural) - Spanish (Mexico)', 'es-MX', false),
        ];
        expect(pickVoice(edge)?.name).toContain('Dalia');
    });

    it('sin ninguna de las dos elegidas, decide la puntuación', () => {
        // Android e iOS: ahi no existe ni Dalia ni Sabina.
        const android: IVoiceLike[] = [
            voz('Microsoft Raul - Spanish (Mexico)'),
            voz('Google español de México', 'es-MX', false),
        ];
        expect(pickVoice(android)?.name).toBe('Google español de México');
    });

    it('sin voces en español devuelve nada, y el navegador usa la del sistema', () => {
        expect(pickVoice([voz('Microsoft David', 'en-US')])).toBeUndefined();
        expect(pickVoice([])).toBeUndefined();
    });

    it('el orden que se le ofrece al usuario solo trae español', () => {
        const orden = rankVoices(WINDOWS_CHROME);
        expect(orden).toHaveLength(3);
        expect(orden.every((v) => v.lang.startsWith('es'))).toBe(true);
    });
});

describe('prosodyFor', () => {
    it('a una voz neuronal no se le toca el tono', () => {
        // Trae su propia entonación aprendida; moverle el `pitch` es justo lo que
        // la vuelve metálica.
        expect(prosodyFor(voz('Microsoft Dalia Online (Natural)', 'es-MX', false)).pitch).toBe(1);
    });

    it('a una local se le sube un poco el tono y se le baja la velocidad', () => {
        const p = prosodyFor(voz('Microsoft Sabina - Spanish (Mexico)'));
        expect(p.pitch).toBeGreaterThan(1);
        expect(p.rate).toBeLessThan(1);
    });

    it('sin voz elegida no se pasa de la raya', () => {
        const p = prosodyFor(null);
        expect(p.rate).toBeGreaterThan(0.5);
        expect(p.rate).toBeLessThanOrEqual(1);
    });
});

describe('textToSpeak', () => {
    it('convierte el salto de renglón en pausa', () => {
        expect(textToSpeak('Encontré tres balatas\nTe dejo las más vendidas')).toBe(
            'Encontré tres balatas. Te dejo las más vendidas.'
        );
    });

    it('no duplica el punto si el renglón ya venía cerrado', () => {
        expect(textToSpeak('Encontré tres balatas.\nTe dejo las más vendidas.')).toBe(
            'Encontré tres balatas. Te dejo las más vendidas.'
        );
    });

    it('quita los signos que el motor pronuncia', () => {
        // Las comillas y los asteriscos se leen literalmente en varios motores.
        const dicho = textToSpeak('La **balata** «delantera» (original) te sirve');
        expect(dicho).not.toMatch(/[«»*()]/);
        expect(dicho).toContain('balata');
        expect(dicho).toContain('original');
    });

    it('cierra la frase, porque sin punto la última palabra se corta', () => {
        expect(textToSpeak('Dime la marca')).toBe('Dime la marca.');
        expect(textToSpeak('¿Qué modelo es?')).toBe('¿Qué modelo es?');
    });

    it('un texto vacío no dice nada', () => {
        expect(textToSpeak('   ')).toBe('');
        expect(textToSpeak('\n\n')).toBe('');
    });
});

describe('splitForSpeech', () => {
    it('lo corto va de una pieza', () => {
        expect(splitForSpeech('Encontré tres balatas.')).toEqual(['Encontré tres balatas.']);
    });

    it('trocea lo largo sin pasar del tope', () => {
        // Chrome deja de hablar a media frase con las voces de red cuando la
        // locución es larga; por eso se encola por partes.
        const largo = textToSpeak(
            Array.from({ length: 14 }, (_, i) => `Esta es la recomendación número ${i + 1} del catálogo.`).join(' ')
        );
        const trozos = splitForSpeech(largo);
        expect(trozos.length).toBeGreaterThan(1);
        trozos.forEach((t) => expect(t.length).toBeLessThanOrEqual(SPEECH_CHUNK_MAX));
        // Nada se pierde en el camino.
        expect(trozos.join(' ').replace(/\s+/g, ' ')).toBe(largo.replace(/\s+/g, ' '));
    });

    it('nunca parte una palabra por la mitad', () => {
        // Una sola frase larguísima obliga a cortar por espacios; ahí es donde se
        // parte una palabra si el corte se hace a ciegas por longitud.
        const frase = `${'alternador '.repeat(40)}final.`;
        const trozos = splitForSpeech(frase);
        expect(trozos.length).toBeGreaterThan(1);
        const palabras = new Set(['alternador', 'final.']);
        trozos.forEach((t) => t.split(' ').forEach((w) => expect(palabras.has(w)).toBe(true)));
        expect(trozos.join(' ')).toContain('final.');
    });

    it('vacío no produce trozos', () => {
        expect(splitForSpeech('')).toEqual([]);
    });
});
