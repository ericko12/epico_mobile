import {
    elegirConsultaCatalogo,
    familiaPrincipal,
} from '@/features/aiSearch/application/actions/consultaCatalogo';
import { ISearchFacet } from '@/features/products/domain/interfaces/ISearchProducts';

/**
 * El caso real que originó esto, medido contra producción:
 *
 * - `modo: ia`, «que tipo de cintas tienes» → `total: 66`.
 * - `modo: normal`, la misma frase → **`total: 0`**, y `terminoCorregido: null`.
 * - `modo: normal`, `cinta` → `total: 66`.
 *
 * El botón «Ver los 66 resultados en el catálogo» mandaba la frase tal cual y
 * llevaba a una pantalla vacía. El servicio no dice qué buscó el agente; lo único
 * que lo delata son las facetas.
 */

const facetas = (campo: string, valores: Array<[string, number]>): ISearchFacet => ({
    campo,
    // `etiqueta` es obligatoria en el contrato —la que se pinta, «Especialidad» para
    // `clasificacion`—, aunque a `familiaPrincipal` le da igual: busca por `campo`.
    etiqueta: campo,
    valores: valores.map(([valor, conteo]) => ({ valor, conteo, ids: [] })),
});

/** Las facetas reales que devolvió el servicio para «que tipo de cintas tienes». */
const FACETAS_CINTAS: ISearchFacet[] = [
    facetas('marca', [['qbh star', 30], ['3m', 20], ['importado', 16]]),
    facetas('familia', [['cinta', 60], ['luz', 4], ['autoadherible', 2]]),
];

describe('familiaPrincipal', () => {
    it('saca la familia con más resultados', () => {
        expect(familiaPrincipal(FACETAS_CINTAS)).toBe('cinta');
    });

    it('no se fía del orden: manda el conteo', () => {
        const desordenadas = [facetas('familia', [['luz', 4], ['cinta', 60]])];
        expect(familiaPrincipal(desordenadas)).toBe('cinta');
    });

    it('sin faceta de familia no inventa nada', () => {
        expect(familiaPrincipal([facetas('marca', [['3m', 20]])])).toBeUndefined();
        expect(familiaPrincipal([facetas('familia', [])])).toBeUndefined();
        expect(familiaPrincipal([])).toBeUndefined();
        expect(familiaPrincipal(undefined)).toBeUndefined();
    });
});

describe('elegirConsultaCatalogo', () => {
    it('la frase manda cuando el índice la entiende', () => {
        // «balatas chevy 2005» es más específica que su familia: cambiarla por
        // «balata» le quitaría al catálogo justo lo que hace útil el enlace.
        const r = elegirConsultaCatalogo('balatas chevy 2005', { ok: true, total: 31 }, 'balata', {
            ok: true,
            total: 4200,
        });
        expect(r).toEqual({ consulta: 'balatas chevy 2005', total: 31 });
    });

    it('cae a la familia cuando la frase no encuentra nada', () => {
        // El caso medido: la pregunta conversacional da cero, la familia da 66.
        const r = elegirConsultaCatalogo(
            'que tipo de cintas tienes',
            { ok: true, total: 0 },
            'cinta',
            { ok: true, total: 66 }
        );
        expect(r).toEqual({ consulta: 'cinta', total: 66 });
    });

    it('el total que devuelve es el de la consulta elegida, no el del chat', () => {
        // Es lo que hace honesto el rótulo del botón: lleva a una pantalla con
        // exactamente ese número.
        const r = elegirConsultaCatalogo('x y z', { ok: true, total: 0 }, 'cinta', {
            ok: true,
            total: 66,
        });
        expect(r?.total).toBe(66);
    });

    it('sin nada que encuentre resultados no se ofrece botón', () => {
        // Mejor no dar salida que llevar a una pantalla vacía, que es el defecto
        // que esto arregla.
        expect(elegirConsultaCatalogo('x', { ok: true, total: 0 })).toBeNull();
        expect(
            elegirConsultaCatalogo('x', { ok: true, total: 0 }, 'cinta', { ok: true, total: 0 })
        ).toBeNull();
        expect(elegirConsultaCatalogo('x')).toBeNull();
    });

    it('un sondeo que fallo no cuenta como resultado', () => {
        // `ok: false` es que el servicio no pudo servir la consulta. Tratarlo como
        // cero llevaría a la familia sin saber si la frase servía.
        expect(elegirConsultaCatalogo('cinta', { ok: false, total: 66 })).toBeNull();
        expect(
            elegirConsultaCatalogo('x', { ok: true, total: 0 }, 'cinta', { ok: false, total: 66 })
        ).toBeNull();
    });

    it('recorta la frase, porque es lo que viaja al catálogo', () => {
        expect(elegirConsultaCatalogo('  cintas  ', { ok: true, total: 66 })?.consulta).toBe('cintas');
    });
});
