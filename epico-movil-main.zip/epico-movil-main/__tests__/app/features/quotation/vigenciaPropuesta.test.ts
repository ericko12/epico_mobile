import {
    VigenciaPropuestaEnum,
    mapearEstatusDelBack,
    resolverVigencia,
} from '@/features/quotation/infraestructure/ui/fixtures/vigenciaPropuesta';

/**
 * The back-end state wins and the local calculation is only a fallback; unknown values must not break anything.
 */
describe('mapearEstatusDelBack', () => {
    it('reconoce los cuatro valores del contrato', () => {
        expect(mapearEstatusDelBack('Vigente')).toBe(VigenciaPropuestaEnum.Vigente);
        expect(mapearEstatusDelBack('Próxima a vencer')).toBe(VigenciaPropuestaEnum.PorVencer);
        expect(mapearEstatusDelBack('Vencida')).toBe(VigenciaPropuestaEnum.Caducada);
        expect(mapearEstatusDelBack('Concluida')).toBe(VigenciaPropuestaEnum.Concluida);
    });

    it('tolera acentos ausentes, mayúsculas y espacios sobrantes', () => {
        // An accent or case difference must not be treated as a contract change.
        expect(mapearEstatusDelBack('  PROXIMA A VENCER ')).toBe(VigenciaPropuestaEnum.PorVencer);
        expect(mapearEstatusDelBack('vencida')).toBe(VigenciaPropuestaEnum.Caducada);
    });

    it('devuelve undefined ante un valor desconocido o vacío', () => {
        // `undefined` signals the fallback, not an error.
        expect(mapearEstatusDelBack('En negociación')).toBeUndefined();
        expect(mapearEstatusDelBack('')).toBeUndefined();
        expect(mapearEstatusDelBack(undefined)).toBeUndefined();
    });
});

describe('resolverVigencia', () => {
    const enDias = (dias: number): string =>
        new Date(Date.now() + dias * 24 * 60 * 60 * 1000).toISOString();

    it('prefiere el estado del back sobre la fecha', () => {
        // The date would say "Vigente" but the back-end says "Vencida"; the back-end wins.
        expect(resolverVigencia('Vencida', enDias(20))).toBe(VigenciaPropuestaEnum.Caducada);
    });

    it('cae al cálculo local cuando el back no manda el campo', () => {
        expect(resolverVigencia(undefined, enDias(20))).toBe(VigenciaPropuestaEnum.Vigente);
        expect(resolverVigencia(undefined, enDias(2))).toBe(VigenciaPropuestaEnum.PorVencer);
        expect(resolverVigencia(undefined, enDias(-1))).toBe(VigenciaPropuestaEnum.Caducada);
    });

    it('cae al cálculo local cuando el back manda un valor que no reconoce', () => {
        expect(resolverVigencia('Escalada a gerente', enDias(2))).toBe(VigenciaPropuestaEnum.PorVencer);
    });

    it('respeta la precedencia de Concluida en el respaldo local', () => {
        // A converted quotation never reads as expired, even if the date has passed.
        expect(resolverVigencia(undefined, enDias(-40), true)).toBe(VigenciaPropuestaEnum.Concluida);
    });

    it('devuelve undefined cuando no hay ni estado ni fecha', () => {
        // The cell degrades to a dash; no state is invented.
        expect(resolverVigencia(undefined, undefined)).toBeUndefined();
    });
});
