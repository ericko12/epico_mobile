import { adaptarCotizacionDelBack } from '@/features/quotation/application/adapters/adaptarCotizacionDelBack';
import { OrigenCotizacionEnum } from '@/features/quotation/domain/enum/OrigenCotizacionEnum';
import { IQuotes } from '@/features/quotation/domain/interfaces/IQuotes';

/**
 * Minimal quotation as it arrives from the service; each test overrides only what it needs.
 */
const cotizacion = (extra: Partial<IQuotes> = {}): IQuotes => ({
    idCotizacion: 229048,
    razonSocial: 'ARRONIZ CABRERA SANTIAGO',
    sucursal: 'Tesistan',
    fechaDeCreacion: new Date('2026-09-22T16:55:40'),
    clasificacion: 'Refaccionaria',
    subtotal: 4969.65,
    permitirEditar: true,
    fechaModificacion: '2026-09-22T16:56:40',
    origenCotizacion: OrigenCotizacionEnum.Cotizacion,
    ...extra,
});

describe('adaptarCotizacionDelBack — derivaciones del contrato', () => {
    it('marca como propuesta cuando propuestaComercialId es mayor que cero', () => {
        const [q] = adaptarCotizacionDelBack([cotizacion({ propuestaComercialId: 2 })]);
        expect(q.origenCotizacion).toBe(OrigenCotizacionEnum.PropuestaComercial);
    });

    it('trata el id ausente, nulo o cero como cotización tradicional', () => {
        // The contract declares `propuestaComercialId` as nullable and uses 0 for "no proposal".
        const casos = [undefined, 0, '0', ''] as (number | string | undefined)[];
        casos.forEach((propuestaComercialId) => {
            const [q] = adaptarCotizacionDelBack([cotizacion({ propuestaComercialId })]);
            expect(q.origenCotizacion).toBe(OrigenCotizacionEnum.Cotizacion);
        });
    });

    it('toma la fecha de vencimiento del campo del contrato', () => {
        const [q] = adaptarCotizacionDelBack([cotizacion({
            propuestaComercialId: 2,
            propuestaComercialVencimiento: '2026-10-22',
        })]);
        expect(q.fechaCaducidadPrecio).toBe('2026-10-22');
    });
});

describe('adaptarCotizacionDelBack — permitirEditar se pasa tal cual', () => {
    /**
     * `permitirEditar` comes from the server as-is; the adapter must not override it.
     */
    it('no altera el valor del back en una cotización vencida', () => {
        const [q] = adaptarCotizacionDelBack([cotizacion({
            propuestaComercialId: 2,
            statusPropuestaComercial: 'Vencida',
            permitirEditar: false,
        })]);
        expect(q.permitirEditar).toBe(false);
    });

    it('tampoco lo altera cuando la cotización sigue viva', () => {
        const [q] = adaptarCotizacionDelBack([cotizacion({
            propuestaComercialId: 2,
            statusPropuestaComercial: 'Próxima a vencer',
            permitirEditar: true,
        })]);
        expect(q.permitirEditar).toBe(true);
    });
});
