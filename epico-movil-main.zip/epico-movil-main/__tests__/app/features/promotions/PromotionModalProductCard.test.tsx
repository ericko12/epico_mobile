import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import PromotionModalProductCard from '@/features/promotions/infrastructure/ui/promotionModalTableRow/PromotionModalProductCard';
import PromotionModalTableRow from '@/features/promotions/infrastructure/ui/promotionModalTableRow/PromotionModalTableRow';
import { useAppSelector } from '@/features/common/application/redux/hooks';

jest.mock('@/features/common/application/redux/hooks');

jest.mock('@/features/common/infrastructure/ui/tables/CustomImageCell/ImageCell', () => ({
    ImageCell: () => <span data-testid="image-cell" />,
}));

const PRODUCT = {
    productoID: 1,
    productoId: 1,
    producto: '3641510',
    descripcion: 'SENSOR MAF 12V TEMPERATURA MASA AIRE INFINITI, NISSAN',
    precio: 1154.29,
    precioPromocion: 0,
    cantidad: 0,
    secuencia: 1,
    cantidadSecuencia: 1,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
} as any;

const PRODUCT_STATE = {
    // tipoPromocionId sin caso especial: el contador no tiene tope
    promotionSelected: { tipoPromocionId: 999, promotionConfig: { sequenceSelected: 1 } },
    productsPromotionStock: [{ producto: '3641510', existencia: 5 }],
};

/** Props compartidas por la fila de tabla y la tarjeta. */
const buildProps = (handleCounterChange: jest.Mock) => ({
    product: PRODUCT,
    loadingStock: false,
    handleDetail: jest.fn(),
    handleCounterChange,
    style: {},
    disableCounter: false,
    maxGiftMultiplyFactor: 0,
    giftProductSequenceIndex: 0,
    setOpenModalScales: jest.fn(),
    setProductRowSelected: jest.fn(),
});

beforeEach(() => {
    jest.clearAllMocks();
    (useAppSelector as unknown as jest.Mock).mockImplementation(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (selector: any) => selector({ sessionState: { productState: PRODUCT_STATE } }),
    );
});

describe('PromotionModalProductCard - paridad funcional con la fila de tabla', () => {
    it('propaga el incremento del contador con el mismo handler que la fila de tabla', async () => {
        const handleCounterChange = jest.fn();
        render(<PromotionModalProductCard {...buildProps(handleCounterChange)} />);

        // CatalogueCounter renderiza [restar, sumar]
        const [, addButton] = screen.getAllByRole('button');
        fireEvent.click(addButton);

        await waitFor(() => expect(handleCounterChange).toHaveBeenCalledWith(PRODUCT, 1));
    });

    it('la fila de tabla dispara exactamente la misma llamada', async () => {
        const handleCounterChange = jest.fn();
        render(
            <table><tbody>
                <PromotionModalTableRow {...buildProps(handleCounterChange)} />
            </tbody></table>,
        );

        const [, addButton] = screen.getAllByRole('button');
        fireEvent.click(addButton);

        await waitFor(() => expect(handleCounterChange).toHaveBeenCalledWith(PRODUCT, 1));
    });

    it('respeta disableCounter deshabilitando el botón de sumar', () => {
        const handleCounterChange = jest.fn();
        render(
            <PromotionModalProductCard {...buildProps(handleCounterChange)} disableCounter />,
        );

        const [, addButton] = screen.getAllByRole('button');
        expect(addButton).toBeDisabled();
    });

    it('muestra código, descripción completa y existencia', () => {
        render(<PromotionModalProductCard {...buildProps(jest.fn())} />);

        expect(screen.getByText('3641510')).toBeInTheDocument();
        expect(screen.getByText(PRODUCT.descripcion)).toBeInTheDocument();
        expect(screen.getByText(/Existencia:/)).toHaveTextContent('Existencia: 5');
    });
});
