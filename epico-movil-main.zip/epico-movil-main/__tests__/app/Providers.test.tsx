import fs from 'fs';
import path from 'path';

/**
 * El contrato que protege este test:
 *
 * `PersistGate loading={null}` es lo que hoy evita los errores de hidratación de toda la
 * aplicación. Mientras rehidrata, PersistGate renderiza `loading`; con `null`, el HTML del
 * servidor y el primer render del cliente coinciden (ambos vacíos) y el árbol real se monta
 * después, cuando `useWindowDimensions` ya conoce el ancho real.
 *
 * Cambiarlo por un spinner —o quitar el PersistGate— provocaría mismatches simultáneos en
 * todo lo que ramifica por `isMobileExperience`: el drawer del layout, la navbar y todas las
 * tablas adaptativas, porque en servidor ese valor es `false` y en cliente puede ser `true`.
 *
 * Es una verificación sobre el texto del archivo a propósito: lo que hay que impedir es la
 * edición descuidada, y renderizar PersistGate en jsdom no distinguiría el caso.
 */
describe('Providers - contrato de hidratación', () => {
    const source = fs.readFileSync(
        path.join(process.cwd(), 'app', 'Providers.tsx'),
        'utf8',
    );

    it('mantiene PersistGate con loading={null}', () => {
        expect(source).toMatch(/<PersistGate\s+loading=\{null\}/);
    });

    it('documenta por qué loading={null} no se puede cambiar a la ligera', () => {
        expect(source).toMatch(/hidrataci[oó]n/i);
    });
});
