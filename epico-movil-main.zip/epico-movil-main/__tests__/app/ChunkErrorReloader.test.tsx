import React from 'react';
import { render } from '@testing-library/react';
import { ChunkErrorReloader } from '@/app/ChunkErrorReloader';

const reload = jest.fn();

beforeAll(() => {
    Object.defineProperty(window, 'location', {
        configurable: true,
        value: { ...window.location, reload },
    });
});

beforeEach(() => {
    reload.mockClear();
    sessionStorage.clear();
});

/** Emite un rechazo no capturado como lo haría un import diferido que falla. */
const emitRejection = (reason: unknown) => {
    const event = new Event('unhandledrejection') as PromiseRejectionEvent;
    Object.defineProperty(event, 'reason', { value: reason });
    window.dispatchEvent(event);
};

/** Emite un error global. */
const emitError = (error: unknown) => {
    const event = new Event('error') as ErrorEvent;
    Object.defineProperty(event, 'error', { value: error });
    window.dispatchEvent(event);
};

const chunkError = () => {
    const error = new Error('Loading chunk 4821 failed. (missing: /_next/static/chunks/4821.js)');
    error.name = 'ChunkLoadError';
    return error;
};

describe('ChunkErrorReloader', () => {
    it('recarga cuando un chunk diferido ya no existe en el servidor', () => {
        render(<ChunkErrorReloader />);

        emitRejection(chunkError());

        expect(reload).toHaveBeenCalledTimes(1);
    });

    it('también atiende el error global, no solo el rechazo', () => {
        render(<ChunkErrorReloader />);

        emitError(chunkError());

        expect(reload).toHaveBeenCalledTimes(1);
    });

    it('reconoce el fallo de un módulo dinámico aunque no se llame ChunkLoadError', () => {
        render(<ChunkErrorReloader />);

        emitRejection(new Error('Failed to fetch dynamically imported module: /_next/static/x.js'));

        expect(reload).toHaveBeenCalledTimes(1);
    });

    it('no recarga por cualquier otro error', () => {
        render(<ChunkErrorReloader />);

        emitRejection(new Error('Request failed with status code 500'));
        emitError(new TypeError('undefined is not a function'));

        expect(reload).not.toHaveBeenCalled();
    });

    it('no entra en bucle: una sola recarga dentro de la ventana de enfriamiento', () => {
        render(<ChunkErrorReloader />);

        emitRejection(chunkError());
        emitRejection(chunkError());
        emitRejection(chunkError());

        expect(reload).toHaveBeenCalledTimes(1);
    });

    it('deja de escuchar al desmontar', () => {
        const { unmount } = render(<ChunkErrorReloader />);
        unmount();

        emitRejection(chunkError());

        expect(reload).not.toHaveBeenCalled();
    });
});
