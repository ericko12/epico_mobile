import { render } from '@testing-library/react';
import RootPage from '@/app/page';
import { redirect } from 'next/navigation';

jest.mock('next/navigation', () => ({
    redirect: jest.fn(() => {
        throw new Error('NEXT_REDIRECT'); // Next.js throws this exception
    }),
}));

describe('RootPage', () => {
    it('RootPage redirect correctly a /Login', () => {
        // Capture the error thrown by redirect
        expect(() => {
            render(<RootPage />);
        }).toThrow();

        // Verify that redirect was called with '/Login'
        expect(redirect).toHaveBeenCalledWith('/Login');
    });

    // Clear mocks after each test
    afterEach(() => {
        jest.clearAllMocks();
    });
});