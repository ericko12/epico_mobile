/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import { JSX, useEffect, useState } from "react";
import { Providers } from "@/app/Providers";
import { ThemeProvider } from "@mui/material";
import { muiTheme } from "@/config/theme/muiTheme";
import "./globals.css";
import { CleanCachedBackgroundSync } from "@/app/CleanCachedBackgroudSync";
import { ChunkErrorReloader } from "@/app/ChunkErrorReloader";
import { customerService } from "@/features/customer/application/service/customer.services";
import { IPoliticaComercialParam } from "@/features/customer/domain/interface/IPoliticaComercialParam";
import { PwaInstallerModal } from "@/features/auth/infrastructure/ui/modal/PwaInstallerModal";
import { SerwistProvider } from "@serwist/turbopack/react";

// Desde nov-2026 esta app atiende también la URL del original (epico.apymsa.com.mx):
// ya no es una PWA de prueba aparte y se llama igual que él. Va en pareja con `name` y
// `short_name` de public/manifest.webmanifest.
const APP_NAME = 'Epico'
const APP_DESCRIPTION = 'Sistema de ...'

/**
 * RootLayout component that wraps the entire application with a layout structure.
 * It sets up global font styles and includes app-wide Providers for state management.
 *
 * @function RootLayout
 * @param {Object} props - Component properties.
 * @param {React.ReactNode} props.children - React children to render inside the layout.
 * @returns {JSX.Element} The root HTML structure of the application.
 */
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>): JSX.Element {
  const [comercialParameter, setComercialParameter] = useState<IPoliticaComercialParam | null>(null);
  //#services 
  const { getComercialParameter } = customerService();

  useEffect(() => {
    const fetchParameter = async () => {
      const parameter = await getComercialParameter(process.env.NEXT_PUBLIC_PARAMETRO_COMERCIAL_PWA ?? "EpicoPwa");
      setComercialParameter(parameter.data);
    }
    fetchParameter();
  }, []);

  return (
    <html lang='es' dir='ltr' data-lt-installed="true" suppressHydrationWarning={true}>
      <head>
        <meta name='viewport' content='width=device-width, initial-scale=1, viewport-fit=cover' />
        <meta name='application-name' content={APP_NAME} />
        <meta name='apple-mobile-web-app-capable' content='yes' />
        <meta name='apple-mobile-web-app-status-bar-style' content='default' />
        <meta name='apple-mobile-web-app-title' content={APP_NAME} />
        <meta name='description' content={APP_DESCRIPTION} />
        <meta name='format-detection' content='telephone=no' />
        <meta name='mobile-web-app-capable' content='yes' />
        <meta name='theme-color' content='#FFFFFF' />
        <title>{APP_NAME}</title>

        <link rel='apple-touch-icon' sizes='180x180' href='/icons/apple-touch-icon.png' />
        <link rel='manifest' href='/manifest.webmanifest' />
        <link rel='shortcut icon' href='/favicon/favicon.ico' />

      </head>
      <ChunkErrorReloader />
      <CleanCachedBackgroundSync />
      <ThemeProvider theme={muiTheme}>
        <body
          className={`antialiased`}
        >
          {/* cacheOnNavigation apagado: con el valor por defecto del Provider (true) cada
              navegación le pide al worker "cachear" la URL, y como worker/index.ts no cachea
              documentos fuera de una navegación real, eso es una descarga completa de la
              página que se tira. En datos móviles medidos no se paga. @serwist/next lo traía
              apagado; así se conserva el comportamiento que tenía la PWA antes de Next 16. */}
          <SerwistProvider
            swUrl="/serwist/sw.js"
            cacheOnNavigation={false}
            options={{ type: "classic", scope: "/" }}
          >
            <Providers>{children}</Providers>
          </SerwistProvider>
          {comercialParameter?.valor === 'True' ? (
            <>
              <PwaInstallerModal />
            </>
          ) : null}
        </body >
      </ThemeProvider >
    </html >
  );
}

