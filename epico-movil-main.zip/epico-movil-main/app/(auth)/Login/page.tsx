'use client'
import dynamic from 'next/dynamic';
import { JSX } from 'react';
const LoginTemplate = dynamic(() => import('@/features/auth/infrastructure/ui/template/LoginTemplate'), {
    ssr: false,
});

/**
 * LoginPage: Component for dynamically loading and displaying the login form.
 * 
 * Features:
 * - Utilizes dynamic import to load the `LoginForm` component.
 * - Enhances performance by splitting the code for the login form into a separate chunk.
 * - Renders the login form as the main content of the page.
 *
 * @returns {JSX.Element} The login page component.
 */


const LoginPage = (): JSX.Element => {
    return <LoginTemplate />;
};

export default LoginPage;
