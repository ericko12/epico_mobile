"use client"

import { SnackbarProvider } from '@/context/snackBar/SnackBarContext';
import { persistor, store } from '@/features/common/application/redux/store';
import { BreadcrumbProvider } from '@/features/common/infrastructure/hooks/useBreadcrumb';
import { JSX } from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';

/**
 * Wraps child components with the Redux Provider for global state access.
 *
 * @function Providers
 * @param {Object} props - Component properties.
 * @param {React.ReactNode} props.children - React children components to be wrapped by the Provider.
 * @returns {JSX.Element} The Redux Provider wrapping the children components.
 */
export function Providers({ children }: { children: React.ReactNode }): JSX.Element {
    return (
        <Provider store={store}>
            {/*
              * `loading={null}` NO es solo estética: es lo que hoy evita los errores de
              * hidratación de toda la aplicación. PersistGate renderiza `loading` hasta que
              * termina de rehidratar, así que el servidor y el primer render del cliente
              * emiten ambos `null` y coinciden. El árbol real se monta después, en un render
              * de cliente normal, cuando `useWindowDimensions` ya conoce el ancho.
              *
              * Si se cambia por un spinner o se quita el PersistGate, aparecerán mismatches
              * simultáneos en todo lo que ramifica por `isMobileExperience`: el drawer del
              * layout, la navbar y todas las tablas adaptativas — porque en servidor ese
              * valor es `false` (escritorio) y en cliente puede ser `true`.
              *
              * Cubierto por __tests__/app/Providers.test.tsx.
              */}
            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
            <PersistGate loading={null} persistor={persistor as any}>
                <SnackbarProvider>
                    <BreadcrumbProvider>
                        {children}
                    </BreadcrumbProvider>
                </SnackbarProvider>
            </PersistGate>
        </Provider>
    );
}
