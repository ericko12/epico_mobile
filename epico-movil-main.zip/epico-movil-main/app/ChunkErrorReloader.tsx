"use client";
import { useEffect } from "react";

/** Marca en sessionStorage del último recargado, para no entrar en bucle. */
const RELOAD_MARK = "epico_chunk_reload_at";

/**
 * Ventana durante la cual no se vuelve a recargar. Si tras recargar el chunk
 * sigue sin existir, el problema no es de versión y recargar en bucle solo
 * gastaría datos del usuario: se deja que el error llegue a la consola.
 */
const RELOAD_COOLDOWN_MS = 30 * 1000;

/**
 * Detecta el fallo de carga de un chunk de Next.
 *
 * webpack y Turbopack lanzan un `ChunkLoadError`, pero según el navegador puede llegar
 * como error genérico: se cubren también los mensajes conocidos de los dos empaquetadores,
 * incluidos los de CSS.
 *
 * @param {unknown} reason - Error o motivo de rechazo capturado.
 * @returns {boolean} `true` si corresponde a un chunk que no se pudo cargar.
 */
const isChunkLoadError = (reason: unknown): boolean => {
    if (!reason) return false;
    const name = (reason as Error)?.name ?? "";
    const message = (reason as Error)?.message ?? String(reason);
    return (
        name === "ChunkLoadError" ||
        /ChunkLoadError/i.test(message) ||
        /Loading chunk [^\s]+ failed/i.test(message) ||
        /Loading CSS chunk/i.test(message) ||
        // Turbopack (el empaquetador por defecto desde Next 16): "Failed to load chunk <url> from …".
        /Failed to load chunk/i.test(message) ||
        /Failed to fetch dynamically imported module/i.test(message)
    );
};

/**
 * Recarga la pestaña cuando un chunk deja de existir en el servidor.
 *
 * `self.skipWaiting()` + `clients.claim()` entregan el service worker nuevo a
 * pestañas que siguen ejecutando el JS del build anterior. En cuanto esa pestaña
 * pide un chunk diferido —una tabla, el exportador de Excel— pide un hash que el
 * despliegue nuevo ya no sirve (`Dockerfile.prod` copia solo el `.next/static`
 * del build vigente) y la pantalla revienta con `ChunkLoadError`, sin más salida
 * que cerrar la app.
 *
 * Recargar resuelve el caso: el documento se sirve `NetworkFirst`, así que la
 * recarga trae el HTML nuevo con los hashes nuevos.
 *
 * @returns {null} No renderiza nada.
 * @component
 */
export const ChunkErrorReloader = () => {
    useEffect(() => {
        /** Recarga una sola vez por ventana de enfriamiento. */
        const reloadOnce = () => {
            try {
                const last = Number(sessionStorage.getItem(RELOAD_MARK) ?? 0);
                if (Date.now() - last < RELOAD_COOLDOWN_MS) return;
                sessionStorage.setItem(RELOAD_MARK, String(Date.now()));
            } catch {
                // Modo privado o storage bloqueado: sin marca no se arriesga el bucle.
                return;
            }
            window.location.reload();
        };

        const onError = (event: ErrorEvent) => {
            if (isChunkLoadError(event.error ?? event.message)) reloadOnce();
        };

        const onRejection = (event: PromiseRejectionEvent) => {
            if (isChunkLoadError(event.reason)) reloadOnce();
        };

        window.addEventListener("error", onError);
        window.addEventListener("unhandledrejection", onRejection);

        return () => {
            window.removeEventListener("error", onError);
            window.removeEventListener("unhandledrejection", onRejection);
        };
    }, []);

    return null;
};
