import { NextRequest, NextResponse } from "next/server";

/**
 * Handles POST requests to the logred API route.
 * 
 * Extracts the client's IP address from the request headers, prioritizing the
 * "x-forwarded-for" header, then "x-real-ip", and defaults to "0.0.0.0" if none are found.
 * Parses the request body as JSON and responds with a JSON object containing
 * the extracted IP address and an "ok" status.
 * 
 * @param req - The incoming Next.js request object.
 * @returns A Next.js JSON response with the client's IP address and status.
 */
export async function POST(req: NextRequest) {
  const forwardedFor = req.headers.get("x-forwarded-for");
  const ip =
    forwardedFor?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "0.0.0.0";

  // const body = await req.json();
  return NextResponse.json({ ok: true, ip });
}