import { NextRequest, NextResponse } from "next/server";
import axios from "axios";
import https from "https";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { getSession } from "@/app/api/auth/sessionStore";

const SESSION_COOKIE_NAME = "epico_session";

/**
 * Builds the gateway target URL for the requested path.
 */
const buildTargetUrl = (req: NextRequest, baseUrl: string) => {
    const pathname = req.nextUrl.pathname.replace(/^\/api\/proxy/, "");
    const search = req.nextUrl.search;
    return `${baseUrl}${pathname}${search}`;
};

/**
 * Builds outbound headers, injecting Authorization when a session exists.
 */
const buildHeaders = (req: NextRequest, token?: string) => {
    const headers: Record<string, string> = {
        Accept: req.headers.get("accept") ?? "application/json",
        "X-OrigenId": `${OrigenEnum.Epico}`,
        "X-ExodusDev": `${OrigenEnum.Epico}`,
        "X-OrigenIdSMC": `${OrigenEnum.Epico}`,
    };

    const contentType = req.headers.get("content-type");
    if (contentType) {
        headers["Content-Type"] = contentType;
    }

    if (token) {
        headers.Authorization = `Bearer ${token}`;
    }

    return headers;
};

/**
 * Proxies a request to the API gateway using the session token from Redis.
 */
const proxyRequest = async (req: NextRequest) => {
    const baseUrl = process.env.BASE_APIGATEWAY;
    if (!baseUrl) {
        return NextResponse.json({ message: "Gateway no configurado." }, { status: 500 });
    }

    const sessionId = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    const session = await getSession(sessionId);
    const token = session?.token;
    const httpsAgent =
        process.env.NODE_ENV === "development"
            ? new https.Agent({ rejectUnauthorized: false })
            : undefined;

    const method = req.method.toUpperCase();
    const data =
        ["GET", "HEAD"].includes(method)
            ? undefined
            : Buffer.from(await req.arrayBuffer());

    const response = await axios.request({
        url: buildTargetUrl(req, baseUrl),
        method,
        data,
        headers: buildHeaders(req, token),
        httpsAgent,
        validateStatus: () => true,
        responseType: "arraybuffer",
    });

    const contentType = String(response.headers["content-type"] ?? "");
    const contentDisposition = String(response.headers["content-disposition"] ?? "");

    if (response.status === 204) {
        return new NextResponse(null, { status: 204 });
    }

    const responseHeaders: Record<string, string> = {};

    if (contentType) {
        responseHeaders["Content-Type"] = contentType;
    }
    if (contentDisposition) {
        responseHeaders["Content-Disposition"] = contentDisposition;
    }
    const contentLength = response.headers["content-length"];
    if (contentLength) {
        responseHeaders["Content-Length"] = String(contentLength);
    }

    if (contentType.includes("application/json")) {
        const text = Buffer.from(response.data as ArrayBuffer).toString("utf-8");
        if (!text) {
            return new NextResponse(null, { status: response.status, headers: responseHeaders });
        }

        try {
            const json = JSON.parse(text);
            return NextResponse.json(json, { status: response.status });
        } catch {
            return new NextResponse(text, { status: response.status, headers: responseHeaders });
        }
    }

    return new NextResponse(response.data as ArrayBuffer, {
        status: response.status,
        headers: responseHeaders,
    });
};

export async function GET(req: NextRequest) {
    return proxyRequest(req);
}

/**
 * Proxies POST requests to the API gateway.
 */
export async function POST(req: NextRequest) {
    return proxyRequest(req);
}

/**
 * Proxies PUT requests to the API gateway.
 */
export async function PUT(req: NextRequest) {
    return proxyRequest(req);
}

/**
 * Proxies PATCH requests to the API gateway.
 */
export async function PATCH(req: NextRequest) {
    return proxyRequest(req);
}

/**
 * Proxies DELETE requests to the API gateway.
 */
export async function DELETE(req: NextRequest) {
    return proxyRequest(req);
}
