import { NextRequest, NextResponse } from "next/server";
import axios from "axios";
import https from "https";
import { UrlGetAuthentication } from "@/features/auth/infrastructure/api/authUrl";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { createSession } from "@/app/api/auth/sessionStore";

const GENERIC_ERROR_MESSAGE = "Ha ocurrido un error, intente de nuevo mas tarde.";
const SESSION_COOKIE_NAME = "epico_session";
const TOKEN_COOKIE_NAME = "token";

/**
 * Decodes a JWT payload without verifying signature.
 */
const decodeJwtPayload = (token: string): { sub?: string; exp?: number } => {
    try {
        const payload = token.split(".")[1];
        const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
        const decoded = Buffer.from(normalized, "base64").toString("utf8");
        return JSON.parse(decoded);
    } catch {
        return {};
    }
};

/**
 * Exchanges user credentials for an IDS4 token and creates an opaque session.
 */
export async function POST(req: NextRequest) {
    try {
        const baseUrl = process.env.BASE_APIGATEWAY;
        const clientId = process.env.IDS4_CLIENT_ID;
        const clientSecret = process.env.IDS4_CLIENT_SECRET;
        const grantType = process.env.IDS4_GRANT_TYPE;
        if (!baseUrl || !clientId || !clientSecret || !grantType) {
            return NextResponse.json(
                {
                    statusCode: 500,
                    data: null,
                    huboError: true,
                    error: { mensaje: GENERIC_ERROR_MESSAGE, erroresValidaciones: [] },
                },
                { status: 500 }
            );
        }

        const body = await req.json();
        const username = body?.user ?? "";
        const password = body?.password ?? "";

        if (!username || !password) {
            return NextResponse.json(
                {
                    statusCode: 400,
                    data: null,
                    huboError: true,
                    error: { mensaje: "Credenciales requeridas.", erroresValidaciones: [] },
                },
                { status: 400 }
            );
        }

        const details = new URLSearchParams({
            grant_type: grantType,
            client_id: clientId,
            client_secret: clientSecret,
            username,
            password,
        }).toString();

        const authUrl = `${baseUrl}${UrlGetAuthentication()}`;
        const httpsAgent =
            process.env.NODE_ENV === "development"
                ? new https.Agent({ rejectUnauthorized: false })
                : undefined;

        const response = await axios.post(authUrl, details, {
            headers: {
                Accept: "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "X-OrigenId": `${OrigenEnum.Epico}`,
                "X-ExodusDev": `${OrigenEnum.Epico}`,
            },
            httpsAgent,
            validateStatus: () => true,
        });

        const data = response.data ?? null;

        if (response.status >= 400) {
            const message = data?.error_description ?? GENERIC_ERROR_MESSAGE;
            return NextResponse.json(
                {
                    statusCode: response.status,
                    data: null,
                    huboError: true,
                    error: { mensaje: message, erroresValidaciones: [] },
                },
                { status: response.status }
            );
        }

        const token = data?.access_token ?? "";
        if (!token) {
            return NextResponse.json(
                {
                    statusCode: 500,
                    data: null,
                    huboError: true,
                    error: { mensaje: GENERIC_ERROR_MESSAGE, erroresValidaciones: [] },
                },
                { status: 500 }
            );
        }
        const payload = token ? decodeJwtPayload(token) : {};
        const userId = payload.sub ? parseInt(payload.sub, 10) : 0;
        const expiresIn = typeof data?.expires_in === "number" ? data.expires_in : 0;
        const sessionId = await createSession(token, expiresIn, userId);

        const res = NextResponse.json(
            {
                statusCode: 200,
                data: {
                    userId,
                    expires_in: expiresIn,
                },
                huboError: false,
                error: { mensaje: "", erroresValidaciones: [] },
            },
            { status: 200 }
        );

        res.cookies.set({
            name: SESSION_COOKIE_NAME,
            value: sessionId,
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            path: "/",
            maxAge: expiresIn || undefined,
        });
        res.cookies.set({
            name: TOKEN_COOKIE_NAME,
            value: "",
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "lax",
            path: "/",
            maxAge: 0,
        });

        return res;
    } catch (error) {
        console.error("IDS4 auth proxy error", error);
        const message = error instanceof Error ? error.message : GENERIC_ERROR_MESSAGE;
        return NextResponse.json(
            {
                statusCode: 0,
                data: null,
                huboError: true,
                error: { mensaje: message, erroresValidaciones: [] },
            },
            { status: 500 }
        );
    }
}
