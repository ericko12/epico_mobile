import { NextRequest, NextResponse } from "next/server";
import { getSession } from "@/app/api/auth/sessionStore";

const SESSION_COOKIE_NAME = "epico_session";

/**
 * Returns whether the opaque session is still valid.
 */
export async function GET(req: NextRequest) {
    const sessionId = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    const session = await getSession(sessionId);
    return NextResponse.json({ valid: Boolean(session) }, { status: 200 });
}
