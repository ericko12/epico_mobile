import crypto from "crypto";
import { createClient } from "redis";

type SessionData = {
    token: string;
    expiresAt: number;
    userId: number;
};

const SESSION_KEY_PREFIX = "epico:session:";

/**
 * Parses HOST_DISTRIBUTED_CACHE into redis connection parts.
 */
const parseDistributedCache = () => {
    const raw = process.env.HOST_DISTRIBUTED_CACHE;
    if (!raw) return {} as Partial<{
        host: string;
        port: number;
        username: string;
        password: string;
    }>;

    const parts = raw.split(",").map((part) => part.trim()).filter(Boolean);
    const first = parts[0] ?? "";
    const hostPart = first.includes("=") ? "" : first;
    const kvParts = first.includes("=") ? parts : parts.slice(1);

    const config: Partial<{ host: string; port: number; username: string; password: string }> = {};

    if (hostPart) {
        const portIndex = hostPart.lastIndexOf(":");
        if (portIndex > 0) {
            config.host = hostPart.slice(0, portIndex);
            const portValue = Number(hostPart.slice(portIndex + 1));
            if (!Number.isNaN(portValue)) config.port = portValue;
        } else {
            config.host = hostPart;
        }
    }

    kvParts.forEach((entry) => {
        const [keyRaw, valueRaw] = entry.split("=");
        const key = keyRaw?.trim();
        const value = valueRaw?.trim();
        if (!key || !value) return;
        if (key === "user") config.username = value;
        if (key === "password") config.password = value;
    });

    return config;
};

const distributedCache = parseDistributedCache();
const REDIS_HOST = distributedCache.host ?? process.env.REDIS_HOST;
const REDIS_PORT = distributedCache.port ?? (Number(process.env.REDIS_PORT) || 6379);
const REDIS_DB = Number(process.env.REDIS_DB) || 1;
const REDIS_PASSWORD = distributedCache.password ?? (process.env.REDIS_PASSWORD || undefined);
const REDIS_USERNAME = distributedCache.username ?? (process.env.REDIS_USERNAME || undefined);

const redisClient = createClient({
    socket: {
        host: REDIS_HOST,
        port: REDIS_PORT,
        keepAlive: 5000,
        connectTimeout: 10000,
        // Reintenta con backoff (máx. 5s) en lugar de abandonar la conexión.
        reconnectStrategy: (retries) => Math.min(retries * 200, 5000),
    },
    // Mantiene viva la conexión para que firewalls/balanceadores no la corten por inactividad.
    pingInterval: 60000,
    database: REDIS_DB,
    ...(REDIS_PASSWORD ? { password: REDIS_PASSWORD } : {}),
    ...(REDIS_USERNAME ? { username: REDIS_USERNAME } : {}),
});

// Sin este listener, un ECONNRESET se emite como 'error' no manejado y tumba el proceso (uncaughtException).
redisClient.on("error", (error: NodeJS.ErrnoException) => {
    console.error("[redis] connection error:", error.code ?? error.message);
});

let redisReady: ReturnType<typeof redisClient.connect> | null = null;

const getNowSeconds = () => Math.floor(Date.now() / 1000);

/**
 * Ensures a single shared Redis connection is established.
 */
const ensureRedis = async () => {
    if (redisClient.isOpen) return;
    if (!redisReady) {
        // Si el primer connect falla, se limpia la promesa para no reutilizar un rechazo para siempre.
        redisReady = redisClient.connect().catch((error) => {
            redisReady = null;
            throw error;
        });
    }
    await redisReady;
};

/**
 * Builds a Redis key for the session id.
 */
const getSessionKey = (sessionId: string) => `${SESSION_KEY_PREFIX}${sessionId}`;

/**
 * Creates a session record in Redis and returns the opaque session id.
 */
export const createSession = async (token: string, expiresIn: number, userId: number) => {
    await ensureRedis();
    const sessionId = crypto.randomUUID();
    const ttl = Math.max(expiresIn || 0, 0);
    const expiresAt = ttl ? getNowSeconds() + ttl : 0;
    const payload: SessionData = { token, userId, expiresAt };
    const key = getSessionKey(sessionId);

    if (ttl) {
        await redisClient.set(key, JSON.stringify(payload), { EX: ttl });
    } else {
        await redisClient.set(key, JSON.stringify(payload));
    }

    return sessionId;
};

/**
 * Retrieves a session from Redis and validates expiration.
 */
export const getSession = async (sessionId?: string | null) => {
    if (!sessionId) return null;
    await ensureRedis();
    const key = getSessionKey(sessionId);
    const raw = await redisClient.get(key);
    if (!raw) return null;

    try {
        const session = JSON.parse(raw) as SessionData;
        if (session.expiresAt && session.expiresAt <= getNowSeconds()) {
            await redisClient.del(key);
            return null;
        }
        return session;
    } catch {
        await redisClient.del(key);
        return null;
    }
};

/**
 * Deletes a session from Redis.
 */
export const deleteSession = async (sessionId?: string | null) => {
    if (!sessionId) return;
    await ensureRedis();
    await redisClient.del(getSessionKey(sessionId));
};
