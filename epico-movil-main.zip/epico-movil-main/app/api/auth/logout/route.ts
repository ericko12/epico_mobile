import { NextRequest, NextResponse } from "next/server";
import { deleteSession } from "@/app/api/auth/sessionStore";

const SESSION_COOKIE_NAME = "epico_session";
const TOKEN_COOKIE_NAME = "token";

/**
 * Clears the opaque session and removes related cookies.
 */
export async function POST(req: NextRequest) {
    const sessionId = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    await deleteSession(sessionId);

    const res = NextResponse.json({ ok: true }, { status: 200 });
    res.cookies.set({
        name: SESSION_COOKIE_NAME,
        value: "",
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: 0,
    });
    res.cookies.set({
        name: TOKEN_COOKIE_NAME,
        value: "",
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        path: "/",
        maxAge: 0,
    });
    return res;
}
