import { NextRequest, NextResponse } from "next/server";
import axios from "axios";
import { OrigenEnum } from "@/features/common/domain/enums/OrigenEnum";
import { getSession } from "@/app/api/auth/sessionStore";

/**
 * Ruta propia hacia el microservicio `IApymsa.Search`.
 *
 * Existe porque el API Gateway **todavía no publica** `/api/v1/BusquedaProductos`
 * y sin ella no hay forma de probar el buscador nuevo desde el navegador. En
 * cuanto infraestructura la publique, se cambia `NEXT_PUBLIC_BUSQUEDA_NUEVA_VIA`
 * a `gateway` y la petición vuelve a salir por `/api/proxy` sin tocar código;
 * este archivo se puede retirar entonces.
 *
 * Diferencias deliberadas con `app/api/proxy/[...path]/route.ts`:
 *
 * - **Exige sesión.** El microservicio no valida el `Authorization` que recibe
 *   (solo tiene `app.UseAuthorization()` sin esquemas), así que si esta ruta no
 *   comprobara la cookie sería un relé abierto al catálogo desde internet. Se
 *   pide sesión válida y se responde `401` sin ella.
 * - **No reenvía el token.** El servicio lo ignoraría y mandarlo a un
 *   destino que no lo valida es filtrarlo sin motivo.
 * - **Solo `GET` y `POST`.** Es lo único que el servicio expone.
 *
 * Lo que sí se conserva del proxy: `X-OrigenId`, que viaja a la bitácora del
 * servicio y **se propaga a `PromocionService`**, que lo valida — con un origen
 * que no reconoce, las promociones no llegan.
 */

const SESSION_COOKIE_NAME = "epico_session";

/** Prefijo que se recorta antes de reenviar. */
const ROUTE_PREFIX = /^\/api\/search/;

/**
 * Compone la URL de destino conservando el resto del path y la querystring.
 *
 * @param {NextRequest} req - Petición entrante.
 * @param {string} baseUrl - Base del microservicio.
 * @returns {string} URL absoluta del microservicio.
 */
const buildTargetUrl = (req: NextRequest, baseUrl: string): string => {
    const pathname = req.nextUrl.pathname.replace(ROUTE_PREFIX, "");
    const search = req.nextUrl.search;
    return `${baseUrl.replace(/\/+$/, "")}${pathname}${search}`;
};

/**
 * Reenvía la petición al microservicio de búsqueda.
 *
 * @param {NextRequest} req - Petición entrante.
 * @returns {Promise<NextResponse>} Respuesta del microservicio, o el error propio.
 */
const forwardRequest = async (req: NextRequest): Promise<NextResponse> => {
    const baseUrl = process.env.IAPYMSA_SEARCH_BASE;
    if (!baseUrl) {
        return NextResponse.json(
            { succeeded: false, message: "Buscador no configurado.", errors: "", data: null },
            { status: 500 }
        );
    }

    // Sin sesión no se reenvía nada: ver la nota de arriba.
    const sessionId = req.cookies.get(SESSION_COOKIE_NAME)?.value;
    const session = await getSession(sessionId);
    if (!session?.token) {
        return NextResponse.json(
            { succeeded: false, message: "Sesión no válida.", errors: "", data: null },
            { status: 401 }
        );
    }

    const method = req.method.toUpperCase();
    const data = method === "GET" ? undefined : Buffer.from(await req.arrayBuffer());

    const headers: Record<string, string> = {
        Accept: req.headers.get("accept") ?? "application/json",
        "X-OrigenId": `${OrigenEnum.Epico}`,
    };
    const contentType = req.headers.get("content-type");
    if (contentType) headers["Content-Type"] = contentType;

    try {
        const response = await axios.request({
            url: buildTargetUrl(req, baseUrl),
            method,
            data,
            headers,
            // El modo IA tarda ~5 s por turno; con el timeout por defecto de axios
            // (ninguno) una caída dejaría la petición colgada, y con 10 s el chat
            // fallaría siempre.
            timeout: 90000,
            validateStatus: () => true,
            responseType: "arraybuffer",
        });

        const respContentType = String(response.headers["content-type"] ?? "");
        const text = Buffer.from(response.data as ArrayBuffer).toString("utf-8");

        if (respContentType.includes("application/json")) {
            if (!text) return new NextResponse(null, { status: response.status });
            try {
                return NextResponse.json(JSON.parse(text), { status: response.status });
            } catch {
                return new NextResponse(text, {
                    status: response.status,
                    headers: { "Content-Type": respContentType },
                });
            }
        }

        // `GET /` responde texto plano con la versión desplegada.
        return new NextResponse(text, {
            status: response.status,
            headers: respContentType ? { "Content-Type": respContentType } : undefined,
        });
    } catch {
        // El buscador caído no debe romper la pantalla: se devuelve el sobre que
        // los adaptadores de EPICO ya saben leer, con `succeeded: false`.
        return NextResponse.json(
            {
                succeeded: false,
                message: "El buscador no respondió.",
                errors: "",
                data: null,
            },
            { status: 502 }
        );
    }
};

/**
 * Reenvía `GET` (versión del servicio y recuperar conversación).
 *
 * @param {NextRequest} req - Petición entrante.
 * @returns {Promise<NextResponse>} Respuesta del microservicio.
 */
export async function GET(req: NextRequest): Promise<NextResponse> {
    return forwardRequest(req);
}

/**
 * Reenvía `POST` (búsqueda normal, modo IA y consulta por ids).
 *
 * @param {NextRequest} req - Petición entrante.
 * @returns {Promise<NextResponse>} Respuesta del microservicio.
 */
export async function POST(req: NextRequest): Promise<NextResponse> {
    return forwardRequest(req);
}
