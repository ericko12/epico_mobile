import { createSerwistRoute } from "@serwist/turbopack";

const MAX_PRECACHE_FILE_BYTES = 50 * 1024 * 1024; // 50 MiB: assets WASM de OCR/imagen

export const {
    dynamic,
    dynamicParams,
    revalidate,
    generateStaticParams,
    GET,
} = createSerwistRoute({
    swSrc: "worker/index.ts",
    maximumFileSizeToCacheInBytes: MAX_PRECACHE_FILE_BYTES,
    useNativeEsbuild: true,
});
