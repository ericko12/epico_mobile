'use client';
import { ForbiddenView } from "@/features/common/infrastructure/ui/view/statusView/ForbiddenView";

/**
 * Page that displays the Forbidden view
 *
 * @component
 */
const ForbiddenPage = () => {
    return (
        <ForbiddenView />
    )
}

export default ForbiddenPage;
