"use client";
import { useEffect } from "react";
/**
 * React hook that periodically sends a message to the service worker to clean cached images.
 *
 * @function CleanCachedBackgroundSync
 * @returns {null} This hook does not render anything.
 */
export const CleanCachedBackgroundSync = () => {
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then((registration) => {
        setInterval(() => {
          registration.active?.postMessage({ action: 'cleancachedimages' });
          console.log('Mensaje enviado al SW para limpiar imágenes');
        }, 2 * 60 * 60 * 1000); // 2 hours interval
      });
    }
  }, []);

  return null;
};
