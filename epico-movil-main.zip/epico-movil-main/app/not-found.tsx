'use client';
import { NotFoundView } from "@/features/common/infrastructure/ui/view/statusView/NotFoundView";

/**
 * Page that displays the Not Found view
 *
 * @component
 */
const NotFoundPage = () => {
    return (
        <NotFoundView />
    )
}

export default NotFoundPage;
