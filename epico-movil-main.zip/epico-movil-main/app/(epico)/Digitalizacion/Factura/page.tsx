"use client"
import dynamic from 'next/dynamic';
const InvoiceDigitization = dynamic(() => import('@/features/digitization/infrastructure/ui/InvoiceDigitization/InvoiceDigitization'), { ssr: false });

/**
 * Page that displays the invoice digitization view.
 *
 * @component
 */
const page = () => {
    return (
        <InvoiceDigitization />
    )
}

export default page