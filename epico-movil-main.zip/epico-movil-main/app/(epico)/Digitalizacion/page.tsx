"use client"
import dynamic from 'next/dynamic';
const Digitization = dynamic(() => import('@/features/digitization/infrastructure/ui/Digitization'), { ssr: false });

/**
 * Page that displays the digitalizar entrega view.
 *
 * @component
 */
const page = () => {
    return (
        <Digitization />
    )
}

export default page