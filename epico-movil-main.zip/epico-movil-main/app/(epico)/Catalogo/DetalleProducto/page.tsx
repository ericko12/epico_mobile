import dynamic from 'next/dynamic';
const ProductDetailsView = dynamic(() => import('@/features/products/infrastructure/ui/productDetails/productDetailsView/ProductDetailsView'));

/**
 * Page that displays the product details view.
 * @component
 * @return {JSX.Element}
 */
const page = () => {
  return (
    <ProductDetailsView />
  )
}

export default page