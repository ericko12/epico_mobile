"use client";

import { ReactNode } from "react";
import { AniaLauncher } from "@/features/aiSearch/infrastructure/ui/aniaLauncher/AniaLauncher";

/**
 * Layout del catálogo.
 *
 * Existe solo para montar el asistente Ania en las pantallas donde tiene contexto
 * útil —el catálogo, el detalle de producto y las promociones— y **no** en el
 * resto de la aplicación, donde flotaría sobre el checkout, las cotizaciones y la
 * digitalización sin saber nada de lo que el usuario está haciendo.
 *
 * Ponerlo en el layout y no en cada página tiene una consecuencia buena y
 * deliberada: en el App Router un layout **no se vuelve a montar** al navegar
 * entre sus páginas, así que la conversación sobrevive a ir del listado al detalle
 * de un producto y volver.
 *
 * @param {object} props - Propiedades del componente.
 * @param {ReactNode} props.children - Página del catálogo.
 * @returns {JSX.Element} La página con el asistente montado encima.
 */
const CatalogoLayout = ({ children }: { children: ReactNode }) => {
    return (
        <>
            {children}
            <AniaLauncher />
        </>
    );
};

export default CatalogoLayout;
