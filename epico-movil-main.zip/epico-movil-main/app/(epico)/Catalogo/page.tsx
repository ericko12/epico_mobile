"use client";

import React from 'react'
import Catalogue from '@/features/catalogue/infrastructure/ui/Catalogue';

/**
 * Page that displays the catalogue view.
 *
 * @component
 */
const page = () => {
  return (
    <Catalogue />
  )
}

export default page