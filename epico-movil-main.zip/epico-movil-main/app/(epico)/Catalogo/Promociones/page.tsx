import { NextPage } from "next";
// -- components
import { ProductDiscounts } from "@/features/promotions/infrastructure/ui";
/**
 * Next Page for the Promotions view
 * @returns {JSX.Element}
 */
const PromotionsPage: NextPage = () => {
    return (
        <ProductDiscounts />
    )
}

export default PromotionsPage