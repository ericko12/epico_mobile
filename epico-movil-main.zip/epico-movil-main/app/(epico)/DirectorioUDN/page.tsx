"use client"

import dynamic from 'next/dynamic';
const DirectoryUDN = dynamic(() => import('@/features/branch/infrastructure/ui/directoryUDN/DirectoryUDN').then(module => module.DirectoryUDN), { ssr: false });

/**
 * Page that displays the list of warranties and returns view.
 *
 * @component
 */
const page = () => {
    return (
        <DirectoryUDN />
    )
}

export default page