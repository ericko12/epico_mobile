'use client'

import { Box } from "@mui/material"
import { NextPage } from "next"

import dynamic from "next/dynamic"
const MyPerformance = dynamic(() => import('@/features/performanceInsights/infrastructure/ui/myPerformance/MyPerformance'), { ssr: false });

/**
 * Page that displays the payment processing
 *
 * @component
 */
const page: NextPage = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
            pb: "80px",
        }}>
            <MyPerformance />
        </Box>
    )
}

export default page