import Shipment from '@/features/shipment/infrastructure/ui/Shipment'
import { Box } from '@mui/material'
import React from 'react'

/**
 * Page component that displays the Shipment section of the Checkout flow.
 * 
 * This page handles the shipping details and options for the current order.
 * It is part of the checkout process where users can select shipping methods
 * and enter delivery information.
 * 
 * @component
 * @returns {JSX.Element} The shipment page component
 */

const page = () => {
    return (
        <Box>
            <Shipment />
        </Box>
    )
}

export default page