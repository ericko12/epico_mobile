import { Box } from '@mui/material'
import React from 'react'
import dynamic from 'next/dynamic';
const CheckoutView = dynamic(() => import("@/features/checkout/infrastructure/ui/checkoutDetail/Checkout").then(module => module.CheckoutView));

/**
 * Page that displays the Checkout.
 *
 * @component
 */
const page = () => {
    return (
        <Box>
            <CheckoutView />
        </Box>
    )
}

export default page