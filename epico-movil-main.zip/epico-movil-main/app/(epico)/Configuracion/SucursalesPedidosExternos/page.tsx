'use client'

import { Box } from "@mui/material"
import { NextPage } from "next"

import dynamic from "next/dynamic"
const BranchExternalOrder = dynamic(() => import('@/features/branch/infrastructure/ui/branchExternalOrders/BranchExternalOrder'), { ssr: false });

/**
 * Page that displays the payment processing
 *
 * @component
 */
const page: NextPage = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "38px",
        }}>
            <BranchExternalOrder />
        </Box>
    )
}

export default page