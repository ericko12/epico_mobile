'use client'
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';

const RoleList = dynamic(() => import('@/features/roles/infrastructure/ui/roles/RoleList'), { ssr: false });

/**
 * List of roles page
 *
 * @returns {*} 
 */
export default function RolePage() {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <RoleList />
        </Box>
    );
}