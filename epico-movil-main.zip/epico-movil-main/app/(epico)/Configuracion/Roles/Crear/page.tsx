"use client"
import { Box } from "@mui/material";
import dynamic from "next/dynamic";
const CreateRol = dynamic(() => import('@/features/roles/infrastructure/ui/createRol/CreateRol'), { ssr: false });

/**
 * Roles page
 *
 * @returns {*} 
 */
const page = () => {

    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <CreateRol />
        </Box>
    )
}

export default page