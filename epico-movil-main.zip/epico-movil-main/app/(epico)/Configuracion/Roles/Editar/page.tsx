"use client"
import { Box } from "@mui/material";
import dynamic from "next/dynamic";
const EditRol = dynamic(() => import('@/features/roles/infrastructure/ui/editRol/EditRol'), { ssr: false });

/**
 * Edit roles page
 *
 * @returns {*} 
 */
const page = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <EditRol />
        </Box>
    )
}

export default page