'use client'
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';

const UsuariosTemplate = dynamic(() => import('@/features/users/infrastructure/ui/users/UsersList'), { ssr: false });

/**
 * Users page
 * @returns {*} 
 */
export default function Users() {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <UsuariosTemplate />
        </Box>
    );
}