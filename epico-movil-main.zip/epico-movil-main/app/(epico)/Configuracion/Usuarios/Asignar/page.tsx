'use client'
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';

const AssignRole = dynamic(() => import('@/features/users/infrastructure/ui/assignRol/AssingRol'), { ssr: false });

/**
 * User role assignment page
 *
 * @returns {*} 
 */
export default function RolePage() {

    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <AssignRole />
        </Box>
    );


}