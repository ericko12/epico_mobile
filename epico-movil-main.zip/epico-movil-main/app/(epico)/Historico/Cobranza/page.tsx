'use client'

import { Box } from "@mui/material";
import { NextPage } from "next";
import dynamic from "next/dynamic"
const PaymentProcessing = dynamic(() => import('@/features/billing/infrastructure/ui/paymentProcessing/PaymentProcessing'), { ssr: false });

/**
 * Page that displays the payment processing
 *
 * @component
 */
const page: NextPage = () => {
    return (
        <Box sx={{
            pb: "80px",
        }}>
            <PaymentProcessing />
        </Box>
    )
}

export default page