'use client'
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';
const Monitoring = dynamic(() => import('@/features/orders/infraestructure/ui/monitoring/Monitoring'), { ssr: false });

/**
 * MonitoringPage component that serves as the main page for oders monitoring.
 *
 * @component
 * @returns {JSX.Element} The rendered monitoring page.
 */
export default function MonitoringPage() {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <Monitoring />
        </Box>
    );
}