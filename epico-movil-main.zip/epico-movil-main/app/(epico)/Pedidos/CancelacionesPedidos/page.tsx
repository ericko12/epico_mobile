import { OrdersCancellation } from "@/features/orders/infraestructure/ui/Cancellation/OrdersCancellation";

/**
 * OrderCancellationPage component that serves as the main page for oders monitoring.
 *
 * @component
 * @returns {JSX.Element} The rendered monitoring page.
 */
export default function OrderCancellationPage() {
    return (
        <OrdersCancellation />
    )
}