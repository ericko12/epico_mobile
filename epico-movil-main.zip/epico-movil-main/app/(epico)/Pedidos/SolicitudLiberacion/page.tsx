"use client";
import OrderRelease from "@/features/orders/infraestructure/ui/orderRelease/OrderRelease"
import { Box } from "@mui/material";

/**
 * Page that displays the external orders list view.
 *
 * @component
 */
const page = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <OrderRelease />
        </Box>
    )
}

export default page