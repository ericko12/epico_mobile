"use client";

import ExternalOrdersTemplate from '@/features/orders/infraestructure/ui/externalOrders/externalOrders';
import React from 'react'

/**
 * Page that displays the external orders list view.
 *
 * @component
 */
const page = () => {
    return (
        <ExternalOrdersTemplate />
    )
}

export default page