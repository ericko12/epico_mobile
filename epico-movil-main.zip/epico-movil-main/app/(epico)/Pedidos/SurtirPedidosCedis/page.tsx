'use client'
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';
const SupplyOrders = dynamic(() => import('@/features/orders/infraestructure/ui/supplyOrdersCedis/SupplyOrders'), { ssr: false });

/**
 * SupplyOrdersPage component that serves as the main page for supply orders.
 *
 * @component
 * @returns {JSX.Element} The rendered supply orders page.
 */
export default function SupplyOrdersPage() {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
        }}>
            <SupplyOrders />
        </Box>
    );
}