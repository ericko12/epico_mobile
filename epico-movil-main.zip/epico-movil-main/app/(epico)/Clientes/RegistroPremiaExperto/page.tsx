'use client'

import dynamic from 'next/dynamic';

const PremiaExpertosRegistrationContent = dynamic(
    () => import('@/features/customer/infrastructure/ui/PremiaExpertosRegistration/PremiaExpertosRegistrationContent'),
    { ssr: false }
);

/**
 * Page component for registering a new Premia Expertos customer.
 * @returns {JSX.Element} - The page component for registering a new customer.
 */
const Page = () => {
    return <PremiaExpertosRegistrationContent />;
};

export default Page;
