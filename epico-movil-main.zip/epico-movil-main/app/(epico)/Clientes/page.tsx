import CustomersList from '@/features/customer/infrastructure/ui/customerlist/CustomersList';
import { Box } from '@mui/material';
/**
 * Page that displays the list of clients.
 *
 * @component
 */
const page = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
            pb: "80px",
        }}>
            <CustomersList />
        </Box>
    )
}

export default page