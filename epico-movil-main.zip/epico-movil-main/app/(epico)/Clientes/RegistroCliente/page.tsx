'use client'

import dynamic from 'next/dynamic';
const CustomerRegistration = dynamic(() => import('@/features/customer/infrastructure/ui/customerRegistration/CustomerRegistration'), { ssr: false });

/**
 * Page component for registering a new customer.
 * @returns {JSX.Element} - The page component for registering a new customer.
 */
const Page = () => {
    return (
        <CustomerRegistration />
    );
}

export default Page;