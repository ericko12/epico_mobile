"use client"
import dynamic from 'next/dynamic';
const Quotation = dynamic(() => import('@/features/quotation/infraestructure/ui/Quotation'), { ssr: false });

/**
 * Page that displays the list of quotation.
 *
 * @component
 */
function RolePage() {

    return (
        <Quotation />
    );

}

export default (RolePage);
