'use client'

import { Box } from "@mui/material";
import dynamic from "next/dynamic";
const EditQuotation = dynamic(() => import('@/features/quotation/infraestructure/ui/editQuotation/EditQuotation').then((mod) => mod.EditQuotation), { ssr: false });

export default function EditQuotationPage() {

    return (
        <Box>
            <EditQuotation />
        </Box>
    )
}
