'use client';
import { Box } from "@mui/material";
import dynamic from "next/dynamic";

const LoyaltyPlanMovementsHistory = dynamic(() => import("@/features/loyaltyPlan/infrastructure/ui/loyaltyPlanMovementHistory/loyaltyPlanMovementHistory"), { ssr: false });

/**
 * Page that displays the loyalty plan movements history.
 *
 * @component
 */
const page = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
            pb: "80px",
        }}>
            <LoyaltyPlanMovementsHistory />
        </Box>
    )
}

export default page;