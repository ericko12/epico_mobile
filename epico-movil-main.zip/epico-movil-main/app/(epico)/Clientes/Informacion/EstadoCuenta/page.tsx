'use client'
import dynamic from "next/dynamic";
const AccountStatement = dynamic(() => import('@/features/credit/infrastructure/ui/accountStatement/AccountStatement'), { ssr: false });

/**
 * Page that displays the customer account statement
 *
 * @component
 */
export default function AccountStatementPage() {
    return <AccountStatement />
}