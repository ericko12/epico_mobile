'use client'
import dynamic from "next/dynamic"
const WarrantiesReturnsCreate = dynamic(() => import('@/features/warrantiesReturns/infrastructure/ui/WarrantiesReturnsCreate/WarrantiesReturnsCreate'), {ssr: false});

/**
 * Page that displays the form to create warranties and returns view.
 *
 * @component
 */
const page = () => {
    return (
        <WarrantiesReturnsCreate />
    )
}

export default page