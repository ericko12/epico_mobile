"use client"
import dynamic from 'next/dynamic';
const WarrantiesReturnList = dynamic(() => import('@/features/warrantiesReturns/infrastructure/ui/warrantiesReturnsList/WarrantiesReturnList'), { ssr: false });

/**
 * Page that displays the list of warranties and returns view.
 *
 * @component
 */
const page = () => {
    return (
        <WarrantiesReturnList />
    )
}

export default page