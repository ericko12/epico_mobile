"use client"
import dynamic from 'next/dynamic';
const DetailOrders = dynamic(() => import('@/features/orders/infraestructure/ui/detailOrders/DetailOrders'), { ssr: false });

/**
 * Page that displays the list of orders view.
 *
 * @component
 */
const page = () => {
    return (
        <DetailOrders />
    )
}

export default page