"use client"
import { Box } from '@mui/material';
import dynamic from 'next/dynamic';
const PurchaseHistory = dynamic(() => import('@/features/orders/infraestructure/ui/salesInformation/SalesInformation'), { ssr: false });

/**
 * Page that displays the list of orders view.
 *
 * @component
 */
const page = () => {
    return (
        <Box sx={{
            px: { xs: "12px", md: "32px" },
            pt: "24px",
            pb: "80px",
        }}>
            <PurchaseHistory />
        </Box>

    )
}

export default page