'use client'
import dynamic from "next/dynamic";
const ClienteInformacionTemplate = dynamic(() => import('@/features/customer/infrastructure/ui/customerInfo/CustomerInformation'), { ssr: false });

/**
 * Page that displays the list of clients.
 *
 * @component
 */
const page = () => {
    return (
        <ClienteInformacionTemplate />
    )
}

export default page