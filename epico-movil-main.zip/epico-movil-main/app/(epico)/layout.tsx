"use client";
import Cookies from 'js-cookie';
import React, { JSX, PropsWithChildren, useState, useEffect } from "react";
import {
    Box,
    CssBaseline,
    Drawer,
    List,
    IconButton,
    Avatar,
    ListItem,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Typography,
} from "@mui/material";
import { FreshchatWidget } from "@/features/auth/infrastructure/ui/freshChatWidget/FreshchatWidget";
import { NavBarSpeedTest } from "@/features/layoutMain/infrastructure/ui/navbar/NavBarSpeedTest";
import { menuItems } from "@/features/layoutMain/domain/data/menuItems.data";
import logoApymsa from "@/public/img/logoApymsa.webp";
import ApymsaIcon from "@/public/Icons/ApymsaIcon";
import { ColorsEpico } from "@/features/common/domain/enums/ColorsEpico";
import dynamic from "next/dynamic";
import { MenuItems } from "@/features/layoutMain/infrastructure/ui/sideMenu/MenuItems";
import Image from "next/image";
import { SetSubheader } from "@/features/checkout/infrastructure/ui/checkoutBar/SetSubHeader";
import { redirect, usePathname } from "next/navigation";
import { validatePermissions } from "@/features/layoutMain/application/actions/validatePermissions";
import { PATH_PAGE } from "@/routes/paths";
import useZoom from "@/features/common/infrastructure/hooks/useZoom";
import { useSnackbar } from "@/context/snackBar/SnackBarContext";
import { GENERIC_ERROR_MESSAGE_RESOLUTION } from "@/features/common/infrastructure/utils/messages/genericMessage";
import { setTelemarketingLeadsModal } from "@/features/teleMarketingLead/application/redux/telemarketingLeadSlice";
import useWindowDimensions from "@/features/common/infrastructure/hooks/getDimensions";
import { Close, Logout } from "@mui/icons-material";
import { useAppDispatch, useAppSelector } from "@/features/common/application/redux/hooks";
import { formatUserName } from "@/features/common/infrastructure/utils/formatUserName";
import { FontSizesEnum } from "@/features/common/domain/enums/FontSizes";
import { FontWeightEnum } from "@/features/common/domain/enums/FontWeight";
import { PersonAddOutlined } from "@mui/icons-material";
import { SetIsEnableZoomOut } from "@/features/configuration/application/redux/ConfigurationThunks";
import { MobileSubmenu } from "@/features/layoutMain/infrastructure/ui/mobileSubmenu/MobileSubmenu";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { closeSession } from "@/features/auth/application/closeSesion";
import { decodeBase64WithKey } from "@/features/common/infrastructure/utils/encodeAndDecode";
import { PATH_AUTH } from "@/routes/paths";
import { setTabId } from "@/features/common/application/redux/windowSlice";
import { getNotificationPermission } from "@/features/common/infrastructure/utils/permissions/notificationsPermission";
import { ModalGeneric } from "@/features/common/infrastructure/ui/dialog/ModalGeneric";
import { actionsAuth } from '@/features/auth/application/redux/authSlice'
import { useSubscribeUserToPushNotification } from '@/features/common/infrastructure/hooks/subscribeUserToPushNotification';
import { INotification } from '@/features/common/domain/interfaces/notification/INotification';
import { PermissionStatusEnum } from '@/features/common/domain/enums/PermissionStatusEnum';
import { subscriptionExists } from "@/features/common/application/service/sw/subscriptionExists";
import { TypesNotificationsEnum } from '@/features/common/domain/enums/TypesNotificationsEnum';
import { ModalDraggable } from "@/features/common/infrastructure/ui/modal/draggable/ModalDraggable";
import { closeTelemarketingLeadsFormModalThunk } from '@/features/teleMarketingLead/application/redux/telemarketingLeadThunk';

const NavBarContent = dynamic(() => import('@/features/layoutMain/infrastructure/ui/navbar/NavBarContent').then((mod) => mod.NavBarContent), { ssr: true });

// Drawer dimensions
const drawerWidth = 300;
const drawerWidthClose = 88;

/**
 * Layout component providing a responsive sidebar navigation menu and main content area.
 *
 * @component
 * @param {PropsWithChildren} props - React props that include children components.
 * @return {JSX.Element} A responsive layout with a sidebar and main content.
 */
function Layout({ children }: PropsWithChildren): JSX.Element {
    //States
    const [isDrawerOpen, setisDrawerOpen] = useState<boolean>(false);
    const [openModalNotification, setOpenModalNotification] = useState(false);
    const [loadingPermissionNotification, setLoadingPermissionNotification] = useState(false);
    const [localStorageData, setLocalStorageData] = useState<string | null>("");
    const [isLocalStorageReady, setIsLocalStorageReady] = useState(false);
    const { isMobileExperience } = useWindowDimensions();
    const dispatch = useAppDispatch();

    // Redux state for user information
    const authState = useAppSelector(state => state.localState.authState);
    const { userAuth, subscriptionId } = authState;

    // Variables for profile image
    const imageBucket = process.env.NEXT_PUBLIC_IMAGE_BUCKET;
    const imgSrc = `${imageBucket!}/${userAuth?.employeeId ?? ''}.jpg`;

    /** Toggle open / close drawer */
    const toggleDrawer = () => {
        setisDrawerOpen((prev) => !prev);
    };

    /** Close drawer */
    const closeDrawer = () => {
        setisDrawerOpen(false);
    };

    //Hooks
    const subscribeUserToPushNotification = useSubscribeUserToPushNotification();
    const pathname = usePathname();
    const { isCurrentWidthScreen, MIN_RESOLUTION } = useZoom();
    const { showSnackbar } = useSnackbar();

    //Redux
    const { telemarketingLeadsModal, telemarketingLeads, telemarketingLeadsFormModal } = useAppSelector(state => state.localState.telemarketingLeadState);
    const { loading, checkOutList } = useAppSelector(state => state.sessionState.checkOutsState);
    const { tabId } = useAppSelector(state => state.sessionState.windowState);

    const setZoomOut = async () => {
        await dispatch(SetIsEnableZoomOut(!isMobileExperience));
    }

    // Mobile menu handlers
    const handleCloseSession = async () => {
        if (window.fcWidget) {
            window.fcWidget.user.clear().then(console.log).catch(console.log);
        }
        closeSession().finally(() => {
            window.location.href = PATH_AUTH.login.root;
        });
    };

    useEffect(() => {
        setZoomOut();
    }, [isMobileExperience])

    useEffect(() => {
        const rawMR = localStorage.getItem("Epico_MR");
        const decodedMR = rawMR ? decodeBase64WithKey(rawMR) : null;
        if (!decodedMR) {
            closeSession();
            window.location.href = PATH_AUTH.login.root;
            return;
        }

        setLocalStorageData(rawMR);
        setIsLocalStorageReady(true);

        initEpico();

        const permission = getNotificationPermission();
        if (permission === PermissionStatusEnum.Default) {
            setOpenModalNotification(true);
            return;
        }

        if (permission === PermissionStatusEnum.Granted) {
            //Check if you do not have an active subscription, if not, subscribe
            verifySubscription();
        }

    }, []);


    useEffect(() => {
        if (!isLocalStorageReady) return;
        if (!localStorageData) return;
        const listener = (event: MessageEvent) => {
            handleShowNotificationOrderExternal(event);
        };

        navigator.serviceWorker.addEventListener("message", listener);

        return () => {
            navigator.serviceWorker.removeEventListener("message", listener);
        };

    }, [isLocalStorageReady, localStorageData]);

    useEffect(() => {
        if (!localStorageData) return;
        const hasPermission = validatePermissions(localStorageData, pathname);
        if (!hasPermission) {
            redirect(PATH_PAGE.page403);
        }
    }, [localStorageData, pathname]);

    useEffect(() => {
        if (!loading) {
            checkLeadInfoToShow();
        }
    }, [pathname, loading, checkOutList, telemarketingLeads]);

    /**
     * Verifies if a push subscription exists;
     * subscribes user if missing.
     */
    const verifySubscription = async () => {
        try {
            const subscription = await subscriptionExists();

            const currentSubscriptionId = Cookies.get("subscriptionId");

            if (!currentSubscriptionId && subscription === null) {
                await subscribeUserToPushNotification(true, userAuth?.userId ?? 0, subscriptionId);
            }
        } catch (error) {
            console.error("Error al verificar suscripción push:", error);
        }
    }

    /**
     * Handles manual push subscription flow.
     * Updates loading state, subscribes user,
     * and closes modal.
     */
    const handleSubscribeToPush = async () => {
        setLoadingPermissionNotification(true);
        await subscribeUserToPushNotification(false, userAuth?.userId ?? 0, subscriptionId);
        setLoadingPermissionNotification(false);
        setOpenModalNotification(false)
    };

    /**
     * Handles external order push notification event.
     * Maps payload to INotification and updates store.
     */
    const handleShowNotificationOrderExternal = async (event: MessageEvent) => {
        if (event.data?.payload) {
            let save: boolean = true;
            const payload = event.data.payload;
            const notification: INotification = {
                esNativa: payload.EsNativa,
                icono: payload.Icono,
                openUrl: payload.OpenUrl,
                tiempoPosponer: payload.TiempoPosponer,
                tipo: payload.Tipo,
                cuerpo: payload.Cuerpo,
                titutlo: payload.Titulo,
                colorBotonUrl: payload.ColorBotonUrl,
                ColorFondo: payload.ColorFondo
            };

            if (notification.tipo === TypesNotificationsEnum.pedidosExternos) {
                if (!localStorageData) return;
                save = validatePermissions(localStorageData, notification.openUrl);
            }

            if (save)
                dispatch(actionsAuth.addOrUpdateNotification(notification));

        }
    };

    /**
     * Initializes the EPICO application by assigning a unique tab identifier (tabId) if it does not already exist.
     * Uses crypto.randomUUID() to generate the identifier and stores it in the global state via dispatch.
     *
     * @function initEpico
     * @returns {void}
     */
    const initEpico = () => {
        dispatch(closeTelemarketingLeadsFormModalThunk());
        if (!tabId) {
            dispatch(setTabId(crypto.randomUUID()));
        }
    }

    /**
     * Validates and updates the state related to the "Showroom" (Telemarketing Leads Modal).
     *
     * - If not on the client information view (`/Clientes/Informacion`), deactivates the new contact modal and the reminder,
     *   and filters the telemarketing leads list to include only those leads who have an associated checkout in `checkOutList`.
     * - If also not on the client information view and there are no checkouts or telemarketing leads,
     *   clears the telemarketing leads list and closes the telemarketing modal, resetting its state.
     * - If there is an active checkout and the client is not 1, closes the telemarketing modal and resets its state.
     * - If the active checkout corresponds to client 1 and there is a matching telemarketing lead,
     *   opens the telemarketing modal, maintaining contact detail state if already active, and handles modal positioning.
     *
     * @returns {void}
     */
    const checkLeadInfoToShow = (): void => {
        if (!pathname.includes(PATH_PAGE.clientes.informacion) && telemarketingLeadsFormModal.open) {
            dispatch(closeTelemarketingLeadsFormModalThunk());
        }
        if (!pathname.includes(PATH_PAGE.clientes.informacion) && (checkOutList.length === 0 || telemarketingLeads.length === 0)) {
            //If there are no checkouts, we clear everything
            dispatch(setTelemarketingLeadsModal({
                openModal: false,
                viewDetailContact: false,
                selectedCvid: 0,
                selectedCheckoutId: '',
                position: {
                    x: 0,
                    y: 0,
                },
            }));
            return;
        }

        const checkoutActive = checkOutList.find(checkout => checkout.active);
        const clientCustomers = [Number(process.env.NEXT_PUBLIC_CLIENTE_MOSTRADOR), Number(process.env.NEXT_PUBLIC_CLIENTE_MOSTRADOR_CC)];
        if (checkoutActive && !clientCustomers.includes(checkoutActive.clienteId)) {
            dispatch(setTelemarketingLeadsModal({
                openModal: false,
                viewDetailContact: false,
                selectedCvid: 0,
                selectedCheckoutId: '',
                position: {
                    x: 0,
                    y: 0,
                },
            }));
        }
        if (checkoutActive && clientCustomers.includes(checkoutActive.clienteId)) {
            const searchInfoCustomer = telemarketingLeads.find(lead => lead.checkoutId === checkoutActive.pedidoID);
            const isActive = telemarketingLeadsModal.selectedCvid === searchInfoCustomer?.cvid;
            if (!searchInfoCustomer) {
                dispatch(setTelemarketingLeadsModal({
                    openModal: false,
                    viewDetailContact: false,
                    selectedCvid: 0,
                    selectedCheckoutId: '',
                    position: {
                        x: 0,
                        y: 0,
                    },
                }));
                return;
            }
            dispatch(setTelemarketingLeadsModal({
                openModal: true,
                viewDetailContact: isActive ? telemarketingLeadsModal.viewDetailContact : false,
                selectedCvid: checkoutActive.clienteVendedorId,
                selectedCheckoutId: checkoutActive.pedidoID,
                position: {
                    x: isActive ? telemarketingLeadsModal.position.x : 0,
                    y: isActive ? telemarketingLeadsModal.position.y : 0,
                },
            }));
        }
    }

    /**
     * Checks if the current screen width is less than the minimum resolution.
     * If it is, a snackbar message is displayed (only on desktop/tablet).
     */
    useEffect(() => {
        if (!isMobileExperience && isCurrentWidthScreen < MIN_RESOLUTION) {
            showSnackbar(GENERIC_ERROR_MESSAGE_RESOLUTION, 'error');
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isCurrentWidthScreen, isMobileExperience])

    return (
        <div id="__Zoom_container__">
            <Box sx={{ display: "flex" }}>
                <FreshchatWidget />
                <CssBaseline />
                <NavBarContent
                    isDrawerOpen={isDrawerOpen}
                    toggleDrawer={toggleDrawer}
                />
                <Drawer
                    variant={isMobileExperience ? "temporary" : "permanent"}
                    open={isMobileExperience ? isDrawerOpen : true}
                    onClose={isMobileExperience ? closeDrawer : undefined}
                    id="drawermain"
                    className={isDrawerOpen ? "drawer-open" : "drawer-close"}
                    sx={{
                        // Por breakpoint, en pareja con #main-content-container.
                        // `variant` sí depende del flag de JS, y en el primer render de
                        // hidratación ese flag dice escritorio: el drawer se monta
                        // PERMANENTE y ocupa sitio real en la fila flex. Con el contenedor
                        // ya en `width: 100%` por CSS, los 88px del drawer se sumaban en vez
                        // de descontarse (88 + 368 = 456 en un teléfono de 368), el
                        // documento no cabía y Chrome se alejaba para hacerlo caber — de ahí
                        // innerWidth 457 contra un clientWidth de 368. En `xs` no ocupa nada.
                        width: { xs: 0, md: isDrawerOpen ? drawerWidth : drawerWidthClose },
                        flexShrink: 0,
                        overflow: "hidden",
                        [`& .MuiDrawer-paper`]: {
                            width: { xs: drawerWidth, md: isDrawerOpen ? drawerWidth : drawerWidthClose },
                            boxSizing: "border-box",
                            backgroundColor: ColorsEpico.ColorPrimary,
                            color: ColorsEpico.ColorMenuWhite,
                            transition: "width 0.3s",
                            ...(isMobileExperience && {
                                position: 'fixed',
                                top: 0,
                                left: 0,
                                height: '100%',
                                zIndex: 1200,
                            }),
                        },
                    }}
                >
                    {/* Close button only visible on mobile */}
                    {isMobileExperience && (
                        <Box sx={{
                            display: 'flex',
                            justifyContent: 'flex-end',
                            p: 1,
                            position: 'absolute',
                            top: 0,
                            right: 0,
                            zIndex: 1
                        }}>
                            <IconButton
                                onClick={closeDrawer}
                                sx={{
                                    color: ColorsEpico.ColorMenuWhite,
                                    '&:hover': {
                                        backgroundColor: ColorsEpico.ColorMenuClose,
                                    }
                                }}
                            >
                                <Close />
                            </IconButton>
                        </Box>
                    )}

                    {/* On mobile: user information, on desktop: logo */}
                    {isMobileExperience ? (
                        <Box sx={{
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'center',
                            p: 2,
                            mt: 4 // Space for the close button
                        }}>
                            {/* User avatar */}
                            {!authState?.adminThird ? (
                                <Avatar
                                    src={imgSrc}
                                    alt=""
                                    sx={{
                                        width: 60,
                                        height: 60,
                                        mr: 2,
                                        border: `2px solid ${ColorsEpico.ColorMenuWhite}`
                                    }}
                                />
                            ) : (
                                <Box sx={{ position: 'relative', mr: 2 }}>
                                    <Avatar
                                        src={imgSrc}
                                        alt=""
                                        sx={{
                                            width: 60,
                                            height: 60,
                                            border: `2px solid ${ColorsEpico.ColorMenuWhite}`
                                        }}
                                    />
                                    <Box sx={{
                                        backgroundColor: ColorsEpico.ColorSecondary,
                                        textAlign: "center",
                                        width: "20px",
                                        height: "20px",
                                        justifyContent: "center",
                                        display: "flex",
                                        borderRadius: "10px",
                                        position: "absolute",
                                        zIndex: "20",
                                        marginLeft: "-10px",
                                        marginTop: "-5px"
                                    }}>
                                        <PersonAddOutlined sx={{ fontSize: FontSizesEnum.Gamma, marginTop: "2px", color: ColorsEpico.ColorWhite }} />
                                    </Box>
                                </Box>
                            )}

                            {/* User information to the right of the avatar */}
                            <Box sx={{
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'center',
                                width: "100%"
                            }}>
                                {/* User name */}
                                <Typography
                                    fontWeight={FontWeightEnum.Bold}
                                    fontSize={FontSizesEnum.Delta}
                                    color={ColorsEpico.ColorMenuWhite}
                                >
                                    {formatUserName(userAuth?.name ?? '') + " " + formatUserName(userAuth?.lastName ?? '')}
                                </Typography>

                                {/* User role/position */}
                                <Typography
                                    fontWeight={FontWeightEnum.Regular}
                                    fontSize={FontSizesEnum.Epsilon}
                                    color={ColorsEpico.ColorMenuWhite}
                                    sx={{ mb: 1 }}
                                >
                                    {authState?.adminThird ? 'Admin' : formatUserName(userAuth?.position ?? '')}
                                </Typography>

                                {/* VER OBJETIVOS button */}
                                <Box sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    cursor: 'pointer',
                                    placeContent: 'space-between',
                                    '&:hover': {
                                        opacity: 0.8
                                    }
                                }}>
                                    <Typography
                                        fontWeight={FontWeightEnum.Regular}
                                        fontSize={FontSizesEnum.Epsilon}
                                        color={ColorsEpico.ColorMenuWhite}
                                        sx={{ mr: 1 }}
                                    >
                                        VER OBJETIVOS
                                    </Typography>
                                    <ArrowForwardIosIcon sx={{ color: ColorsEpico.ColorMenuWhite, fontSize: FontSizesEnum.Epsilon }} />
                                </Box>
                            </Box>
                        </Box>
                    ) : (
                        // Original logo for desktop/tablet
                        isDrawerOpen ? (
                            <Image
                                src={logoApymsa.src}
                                style={{ width: "65%", margin: "20px 0", alignSelf: "center" }}
                                alt="logotipo Apymsa"
                                height={150}
                                width={150}
                            />
                        ) : (
                            <ApymsaIcon style={{ margin: "20px 0", alignSelf: "center" }} />
                        )
                    )}
                    <Box sx={{ overflowY: "auto" }}>
                        <List sx={{ height: "auto", overflow: "hidden" }}>
                            <MenuItems isDrawerOpen={isDrawerOpen} items={menuItems()} onNavigate={closeDrawer} />

                            {/* Mobile Logout Button - Only visible on mobile */}
                            {isMobileExperience && (
                                <ListItem disablePadding>
                                    <ListItemButton onClick={handleCloseSession}>
                                        <ListItemIcon sx={{ placeContent: 'center' }}>
                                            <Logout fontSize="small" sx={{ color: ColorsEpico.ColorMenuWhite }} />
                                        </ListItemIcon>
                                        <ListItemText
                                            primary="Cerrar sesión"
                                            sx={{ color: ColorsEpico.ColorMenuWhite }}
                                        />
                                    </ListItemButton>
                                </ListItem>
                            )}
                        </List>
                    </Box>
                </Drawer>
                <Box
                    id="main-content-container"
                    sx={{
                        // Es hijo de un contenedor flex. Sin minWidth:0 su ancho mínimo
                        // automático es el min-content de TODO lo que contiene, así que en
                        // una pantalla más angosta que el elemento más ancho de la página el
                        // contenedor se queda grande y la app entera se maqueta a ese ancho:
                        // se ve "con zoom", como si la pantalla fuera más ancha. No se notaba
                        // porque el QA móvil se hizo a 360px y nada bajaba de ahí.
                        // En escritorio es position:absolute (no es flex item) y no aplica.
                        minWidth: 0,
                        // Breakpoints de CSS, NO el flag de JS. `isMobileExperience` sale de
                        // useSyncExternalStore, y React usa getServerSnapshot tanto en el
                        // servidor como en el primer render de hidratación: ahí vale false,
                        // o sea escritorio. Con el flag, el primer pintado en un teléfono
                        // ponía el contenido en left:88px y calc(100% - 88px) —en 320px son
                        // 232px corridos a la derecha— y recién después saltaba a móvil.
                        // Eso es el "primero se ve grande y después se ajusta".
                        // El CSS ya es correcto en el primer pintado, sin JavaScript.
                        position: { xs: "relative", md: "absolute" },
                        top: { xs: "60px", md: "70px" },
                        left: { xs: 0, md: isDrawerOpen ? `${drawerWidth}px` : `${drawerWidthClose}px` },
                        width: { xs: "100%", md: `calc(100% - ${isDrawerOpen ? drawerWidth : drawerWidthClose}px)` },
                        transition: "left 0.3s, width 0.3s",
                    }}
                >
                    <NavBarSpeedTest />
                    <SetSubheader />
                    <Box
                        id="main-content"
                        component="main"
                        sx={{
                            position: "relative",
                            backgroundColor: ColorsEpico.ColorWhite,
                            // Espacio para el submenú móvil + safe-area inferior (notch/gestos).
                            // Por breakpoint y no por el flag, para que el primer pintado ya
                            // reserve el hueco y el contenido no salte.
                            paddingBottom: { xs: "calc(70px + env(safe-area-inset-bottom))", md: 0 },
                        }}
                    >
                        {telemarketingLeadsModal.openModal && <ModalDraggable />}
                        {children}
                    </Box>
                </Box>


                {openModalNotification && (
                    <ModalGeneric
                        titulo="Sin acceso a Notificaciones"
                        btnTextSave="Aceptar"
                        openModal={openModalNotification}
                        onSave={handleSubscribeToPush}
                        isLoading={loadingPermissionNotification}
                        onClose={() => {
                            setOpenModalNotification(false);
                        }}
                        borderModal={`2px solid ${ColorsEpico.ColorVibrantYellow} !important`}
                    >
                        <Typography>
                            Para recibir actualizaciones de pedidos es necesario activar las
                            notificaciones
                        </Typography>
                    </ModalGeneric>
                )}
            </Box>

            {/* Mobile submenu sticky at the bottom */}
            <MobileSubmenu />
        </div >
    );
}

export default Layout;
